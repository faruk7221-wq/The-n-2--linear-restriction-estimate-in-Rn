**Revision 0.59 — corrected localized normal-geometry certification.**

The localized restriction interface now retains common-tangent closeness and a
proved uniform normalized joint normal-space bound on actual localized charts.
The main conclusions remain conditional on eight explicit borrowed inputs.
See [REVISION_59.md](REVISION_59.md) for the repaired gap and exact trust boundary,
and `Certification.lean` for the final Lean entry point. Run `./scripts/check.sh`
to rebuild and audit all inventories plus that entry point.

The audited inventory contains **843 main + 1,660 continuation = 2,503 named results**.

The v59 verification record distinguishes fresh affected-module compilation from
retained reports for unchanged sources. Earlier revision counts and claims below
are historical and are superseded where the v59 correction applies.

## Historical revision 58 record

# Lean project for the (n-2)-linear restriction estimate

**Revision 0.58: both named main targets are proved relative to explicit certified borrowed inputs.**

Entry: `N2Restriction.mainGoals_of_certified_borrowed_inputs` in `continuation/CertifiedMainGlobalV58.lean`.

**843 main + 1655 continuation = 2,498 distinct checked results.** This revision adds **33 results in 23 modules**.

Proved exact support-based localization of full extended-surface Fourier integrals to actual compact graph pieces, with both graph-image inclusion and ambient local coverage retained. Constructed arbitrarily small compact affine slicing rectangles and the affine nonstationary inverse-frequency estimate. Combined the covered curved and nonnormal phase boxes to prove actual local full-surface half-decay in every unit physical direction. Constructed finite spatial covers and smooth partitions, then a finite angular cover with a common frequency-independent coefficient. Normalized physical vectors, used the actual L1 bound at bounded radius, and proved the full (1+norm x)^(-1/2) test-density estimate (8.4), relative to the standard graph area formula. SurfaceTestDecay is now proved internally in the nonempty-original-support branch. Applied the retained certified local theorem and external epsilon removal to prove MainGlobalGoal, handling empty original supports through the existing zero-product branch. Both named main goals are now proved relative to the explicit certified borrowed inputs; this is not an unconditional proof of those external theorems or a claim that every ancillary article statement has been independently audited for exact correspondence. Also checked a symmetric invertible four-dimensional matrix whose compression to a coordinate two-plane is zero, isolating the pointwise linear-algebra obstruction behind the article's curvature caution; no explicit hypersurface family is claimed by that example.

External inputs are unchanged: standard smooth graph area formula, weighted Kakeya, uniform localized restriction on full certified measured atlases, tangent cuts, projected polynomial partition/generic transversality, polynomial tube covering, dimension-zero point count, and surface epsilon removal. These are explicit theorem arguments, not project axioms. The article-side Fourier decay, energy estimates, recurrence, descent, original-support assembly, and named local/global conclusions are proved internally. Standard-axiom checks certify these implications, not the borrowed mathematical theorems themselves.

Read `CONTINUATION_HANDOFF.md`, `EXTERNAL_INPUT_POLICY.md` and `verification/theorem-contracts-v58.json` for exact scope. The complete ancillary statement-by-statement article audit is not claimed.

## Build

Pinned versions:

- Lean: `leanprover/lean4:v4.24.0`
- Mathlib: `f897ebcf72cd16f89ab4577d0c826cd14afaafc7` (v4.24.0)

Install Lean using the [official instructions](https://lean-lang.org/install/), extract this directory, and run from its root:

```bash
lake exe cache get
lake build
python3 scripts/audit.py
python3 scripts/audit-continuation.py
```

`lake exe cache get` downloads the pinned dependencies and their compiled Mathlib cache. Internet access and sufficient disk space are required on the first run. Python 3 is used only for the audit script; the mathematical proofs are checked by Lean.

On Linux/macOS, after fetching the cache, `./scripts/check.sh` runs the build and both audits. On Windows, run the four commands above in a terminal. Open the extracted project folder in VS Code with the Lean 4 extension to inspect proof states.

The included GitHub Actions workflow runs the build and both main/continuation audits on pushes and pull requests. The workflow file is provided; a hosted GitHub Actions run has not been performed here.

33 new results in 23 modules individually compiled and axiom-audited without warnings or admissions. All 1010 prior Lean sources are unchanged, as are retained source/report hashes for 1622 continuation results. Final combined, default-build and main-audit outcomes are recorded in verification/session-v58.json.

Run `lake env lean verification/AuditV58.lean` to check the new-result dependency closure after the continuation interfaces have been built.

Run `python3 scripts/audit-continuation.py` after `lake build` to reproduce the separate continuation checks. The continuation declarations are outside the 843-result main inventory. The continuation audit emits Lean interfaces in inventory order so later continuation files can import earlier checked files; it also rejects name overlap with the main inventory. Both audits allow only `propext`, `Classical.choice`, and `Quot.sound`; no `sorry`, `admit`, or project-specific axioms are used.
