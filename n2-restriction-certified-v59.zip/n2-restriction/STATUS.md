**Revision 0.59 — corrected localized normal-geometry certification.**

The localized restriction interface now retains common-tangent closeness and a
proved uniform normalized joint normal-space bound on actual localized charts.
The main conclusions remain conditional on eight explicit borrowed inputs.
See [REVISION_59.md](REVISION_59.md) for the repaired gap and exact trust boundary,
and `Certification.lean` for the final Lean entry point. Run `./scripts/check.sh`
to rebuild and audit all inventories plus that entry point.

The v59 verification record distinguishes fresh affected-module compilation from
retained reports for unchanged sources. Earlier revision counts and claims below
are historical and are superseded where the v59 correction applies.

## Historical revision 58 record

# Formalization status — revision 0.58

Proved exact support-based localization of full extended-surface Fourier integrals to actual compact graph pieces, with both graph-image inclusion and ambient local coverage retained. Constructed arbitrarily small compact affine slicing rectangles and the affine nonstationary inverse-frequency estimate. Combined the covered curved and nonnormal phase boxes to prove actual local full-surface half-decay in every unit physical direction. Constructed finite spatial covers and smooth partitions, then a finite angular cover with a common frequency-independent coefficient. Normalized physical vectors, used the actual L1 bound at bounded radius, and proved the full (1+norm x)^(-1/2) test-density estimate (8.4), relative to the standard graph area formula. SurfaceTestDecay is now proved internally in the nonempty-original-support branch. Applied the retained certified local theorem and external epsilon removal to prove MainGlobalGoal, handling empty original supports through the existing zero-product branch. Both named main goals are now proved relative to the explicit certified borrowed inputs; this is not an unconditional proof of those external theorems or a claim that every ancillary article statement has been independently audited for exact correspondence. Also checked a symmetric invertible four-dimensional matrix whose compression to a coordinate two-plane is zero, isolating the pointwise linear-algebra obstruction behind the article's curvature caution; no explicit hypersurface family is claimed by that example.

External inputs are unchanged: standard smooth graph area formula, weighted Kakeya, uniform localized restriction on full certified measured atlases, tangent cuts, projected polynomial partition/generic transversality, polynomial tube covering, dimension-zero point count, and surface epsilon removal. These are explicit theorem arguments, not project axioms. The article-side Fourier decay, energy estimates, recurrence, descent, original-support assembly, and named local/global conclusions are proved internally. Standard-axiom checks certify these implications, not the borrowed mathematical theorems themselves.

33 new results in 23 modules individually compiled and axiom-audited without warnings or admissions. All 1010 prior Lean sources are unchanged, as are retained source/report hashes for 1622 continuation results. Final combined, default-build and main-audit outcomes are recorded in verification/session-v58.json.

## Remaining review

- Review exact correspondence for ancillary statements and examples if a statement-by-statement edition of the entire article is desired. Both named main targets and the previously pending surface decay obligation are now proved relative to the stated external inputs.
- External theorem proofs remain deliberately out of scope under the user's instruction. A proof with no external theorem arguments would require separately providing those inputs.

## Historical record (superseded)

# Formalization status — revision 0.57

Proved smoothness and positivity of the normalized graph Jacobian and the actual compact surface-test/partition amplitude. Introduced the standard smooth graph area formula as an explicit borrowed theorem argument, with the Hausdorff normalization retained; no Fourier estimate or article-side decay is part of that input. Proved exact orthogonal surface measure transport, actual Hausdorff Fourier-integral transfer, product coordinates, amplitude/derivative budgets and uniform curved surface-chart half-decay. Proved actual nonstationary interval inverse-frequency decay by parameter-independent regularization bounds and removal of a quadratic error, then derived compact direction/phase budgets and actual nonstationary Hausdorff surface-chart decay. Constructed nonnormal full phase boxes, slicing-axis rotations, curved compact product boxes, both normal signs, and exact horizontal affine determinant and extension transfers. Constructed finite smooth spatial partitions and proved exact weighted full-surface reconstruction and finite decay assembly. Retained actual local surface coverage when globalizing graph germs. Full-surface SurfaceTestDecay and the global theorem remain open at chart-localization and finite spatial/angular cover assembly. The named local theorem remains unchanged relative to its certified borrowed inputs.

The standard smooth graph area formula is now an explicit borrowed input, SmoothGraphAreaFormulaInput, as authorized by the user to assume external inputs. It states the actual normalized Hausdorff measure identity for every smooth graph over a compact coordinate set. It contains no Fourier decay, oscillatory estimate, restriction bound, partition construction or article theorem. All Jacobian regularity, amplitude budgets, exact Fourier transfers and decay estimates are proved internally from it. It is a theorem argument, not a project axiom. The previous weighted Kakeya, certified localized restriction, tangent-cut, partition/transversality, covering/counting and conditional epsilon-removal interfaces are retained unchanged.

56 new results in 33 modules individually compiled and standard-axiom audited without warnings or admissions. All 976 previous Lean files and the source/report hashes for 1566 prior continuation results are unchanged. The main 843-result axiom audit is retained. New aggregate/build records are in verification/session-v57.json.

## Remaining work

- At each supported surface point and normalized physical direction, combine the covered graph germ with the curved or nonnormal phase box. Align the slicing vector, shrink the whole product box into the actual surface germ, and retain local coverage by a smaller ambient neighborhood.
- For a test density times a spatial weight supported in that ambient neighborhood, prove exact equality of its full extended-surface integral and the corresponding compact chart integral. Do not silently replace the full surface by an arbitrary graph piece.
- For each fixed direction, use compactness of the full test-supported surface portion to obtain finitely many such charts and one common angular neighborhood; apply the constructed smooth spatial partition. Then use compactness of the unit sphere to select finitely many direction neighborhoods and one frequency-independent coefficient.
- Combine the proved inverse-frequency nonstationary chart bounds with the curved half-decay bounds at frequencies >=1. Normalize x as norm(x) times its unit direction, handle bounded frequencies with the actual test L1 bound, and match C*(1+norm x)^(-1/2).
- Prove SurfaceTestDecay relative to the explicit standard area-formula input, then instantiate mainGlobalGoal_of_certified_inputs_and_nonempty_decay. Full-surface (8.4) and MainGlobalGoal remain open until this is done.

## Historical record (superseded)

# Formalization status — revision 0.56

Proved the sharp one-dimensional frequency^(-1/2) bound for actual curved oscillatory integrals, with explicit amplitude coefficients, a frequency-independent coefficient and no upper-curvature hypothesis. The proof uses the actual Cauchy-kernel primitive, sign-independent kernel integral bounds, smooth inverse regularization, exact main/remainder decomposition and square-root optimization. Proved its Fubini consequence for actual product integrals. Constructed compact auxiliary SmoothPatches for every ambient compact test density on the full extended surface, proved exact equality of the original Hausdorff-surface Fourier integral with this compact restriction, proved its finite mass and actual test-density integrability, and constructed its finite regular graph cover. Proved the tangent lift in existing oblique graphs, globally smooth representatives of local graph germs, actual graph curves realizing any tangent, and regular full graph germs at all extended-surface points. Proved phase-curvature identities and joint parameter continuity; constructed full graph germs with a common curved parameter box directly from GeometricHypotheses. The certified local theorem from revision 55 is retained unchanged. Full-surface SurfaceTestDecay, smooth Hausdorff-Jacobian/partition amplitudes, nonstationary angular assembly and MainGlobalGoal remain open. The full surface estimate (8.4) is not claimed.

43 new results in 27 modules individually compiled and axiom-audited without warnings or admissions. All 948 previous Lean files and the source/report hashes for 1523 prior continuation results are unchanged. The main 843-result audit is retained; the new aggregate audit and fresh default build are recorded in verification/session-v56.json.

## Remaining work

- Choose a smaller full graph box on which the globalized height equals the actual local surface height. Put the nonzero curved horizontal direction into linear product coordinates, retaining its constant change-of-variables factor.
- Prove the actual smooth Hausdorff graph Jacobian formula and its C1 bounds for the localized test-density/partition amplitude. The existing bounded measurable graph density used for L2 energy does not supply this smoothness.
- Instantiate curved_fubini_half_decay on those actual chart amplitudes, with all amplitude and derivative budgets chosen before the frequency and uniformly in normalized physical direction.
- Complete the nonstationary oscillatory estimate away from the normal line. Actual tangent detection and graph curves with positive first phase derivative are checked, but the uniform full-chart first-derivative estimate and its integral bound remain.
- Construct the finite smooth spatial/angular partition, combine all chart estimates with low-frequency L1 control, and prove full-surface SurfaceTestDecay (and the stronger surface version of article (8.4)).
- Instantiate mainGlobalGoal_of_certified_inputs_and_nonempty_decay with the proved article-side decay. Borrowed epsilon removal remains an explicit argument.

## Historical record (superseded)

# Formalization coverage and outstanding obligations

Current revision: **0.58**, with **843 main results** and **1650 separately audited continuation results**. MainLocalGoal is proved relative to certified borrowed inputs. Global decay and MainGlobalGoal remain open.

The revision 54 atlas-provenance gap is closed in the new route. Classical.choice is now applied to a full certified atlas type whose every inhabitant retains measured-chart and normal-coordinate geometry. The reduced atlas is obtained by a proved forgetful construction. The new named local theorem does not use CanonicalLocalizedRestrictionInput or an arbitrary inhabitant of the reduced atlas type.

| Stable ID | Status | Entry / scope |
|---|---|---|
| N2-ATLAS-055-001 | Proved | Full certified measured localization atlas and reduced forgetful adapter; v54 provenance gap closed |
| N2-LOCAL-055-001 | Proved relative to borrowed inputs | mainLocalGoal_of_certified_borrowed_inputs; complete original surfaces and critical endpoint |
| N2-SLICE-055-001 | Proved | Actual implicit curved normal slice and uniform near-normal phase curvature |
| N2-OSC-055-001 | Proved | Actual interval integration-by-parts, stationary sublevel measure/integral, regularized amplitude and integral estimates |
| N2-DECAY-055-OPEN | Open | Optimize frequency power; aligned full chart integration and SurfaceTestDecay |
| N2-GLOBAL-055-OPEN | Conditional | Certified local proof instantiated internally; article-side decay premise remains |

Read verification/theorem-contracts-v55.json.

## Historical status (superseded)

# Formalization coverage and outstanding obligations

## Final scope review — authoritative

Final assumption review: mainLocalGoal_of_borrowed_inputs is a checked implication from its stated interfaces. CanonicalLocalizedRestrictionInput is assumed on canonicalArticleLocalizationAtlas, defined by Classical.choice of Nonempty ArticleLocalizationAtlas. That reduced structure forgets full measured-chart provenance. The present source therefore does not yet certify that this interface is exactly an instance of article External input 1. Restore a data-bearing atlas constructor retaining its full MeasuredTubularChart/ChartNormalCoordinates certificates, and specialize the borrowed theorem there. Until then, the named local goal is CONDITIONAL on the stated localized interface, not fully certified relative only to the intended borrowed theorems. Original-support assembly and endpoint arguments themselves are proved. Global SurfaceTestDecay (8.4) also remains open.

The following milestones are to be read subject to this qualification; earlier completion wording is superseded.


Current revision: **0.55**, with **843 main results** and **1523 separately audited continuation results**. The named local implication is checked under the stated interfaces; certification of the localized atlas input remains open. MainGlobalGoal remains open at article-side test-density decay (8.4). No unconditional main theorem is asserted.

The named local implication is checked under the stated interfaces; certification of the localized atlas input remains open. The SAME directional subdivision now retains its relative-interior cover throughout the terminal/mass/growth chain. Actual compact core patches with positive collars cover the original supports; a proved fixed-loss finite-cover estimate preserves their exact surface measures and norms. Endpoint passage and raising exponents give local restriction for every p at least critical. The global theorem is assembled conditionally on the article-side nonempty-case SurfaceTestDecay; that decay is still OPEN and is not classified as an external input. Individual two-plane coercivity now yields actual nonzero and unit tangent Hessian directions, quantitative persistence, and a finite uniform curvature cover. Actual normal graph and scalar phase second derivatives are checked, with positive curvature bounds uniform in a graph interval and a normal-direction neighborhood.

## Current stable milestone ledger

| Stable ID | Status | Checked entry / remaining obligation |
|---|---|---|
| N2-COVER-054-001 | Proved | SAME subdivision interiors retained through ten wrappers; actual compact core families and positive tuple margins |
| N2-ASSEMBLY-054-001 | Proved | finite_surface_cover_fixed_loss; original_surface_fixed_loss with original measures and input norms |
| N2-LOCAL-054-001 | Conditional: atlas-input certification open | mainLocalGoal_of_borrowed_inputs; original_surface_local_range for all p>=critical |
| N2-GLOBAL-054-001 | Conditional | mainGlobalGoal_of_borrowed_inputs_and_nonempty_decay; local estimate internally proved |
| N2-CURVE-054-001 | Proved | Individual/unit Hessian directions, compact uniform cover, graph and physical phase second derivatives, near-normal phase lower bounds |
| N2-DECAY-054-OPEN | Open article contribution | SurfaceTestDecay / (8.4): graph chart measure integration and actual oscillatory estimate |

Read `verification/theorem-contracts-v54.json` and `verification/next-steps-v54.json` for current obligations. Earlier ledgers below are historical.

## Historical revision 0.53 ledger (superseded)

All rows below are relative to their explicit theorem hypotheses and existing borrowed-input contracts; no row proves the named main theorem.

| Stable ID | Proved result | Principal dependencies | Remaining scope limit |
|---|---|---|---|
| N2-REC-053-001 | Exact same-chart all-packet extension reconstruction and err=0 initial actual stage | `PacketGraphAtlas.packet_hasSum`, selected-series reindexing, chart reconstruction | Chart graph support and its exact extension identity are explicit hypotheses, supplied internally by the strongest mass theorem |
| N2-DESC-053-001 | Actual grouped step and finite packet-preserving dimension iteration | v52 cut preparation, true-stage classification, contracting partition; grouped budget and well-founded induction | Iteration outputs cellular mass or actual terminal/zero stages; the next row applies their estimates |
| N2-MASS-053-001 | `exists_constructed_origin_mass_descent` | Exact initialization, actual finite iteration, same constructed terminal data, dimension-zero point count | Chosen directional piece margin classes; compatible complete original-support transfer is not concluded |
| N2-GROW-053-001 | `exists_constructed_subpatch_margin_growth` and actual all-center subpatch estimates | Original-input mass, real coefficient conversion, separate-scale scalar closure, small-parameter choice | Strict critical-to-baseline range; subdivision may depend on the chosen loss |
| N2-COVER-053-001 | Joint rank/Kakeya subdivision with relative open interiors, finite buffered compact cores, common positive tuple margin and exact core surface measures | Compact open-cover construction, old joint rank/Kakeya factory, subpatch definition | The relative cover certificate still must be carried through the terminal wrapper chain and instantiated in refined-cover assembly |
| N2-MAIN-053-OPEN | Named main local/global goals remain unproved | Fixed-loss refined-cover norm assembly, endpoint passage, global epsilon removal and surface test decay | See `verification/remaining-main-goals-v53.json` and `verification/wrapper-threading-v53.json` |

## Classification

- **Proved**: a Lean proof is present and accepted by the compiler, with the statement's explicit hypotheses.
- **Conditional**: a general mathematical implication is proved, while a substantive hypothesis still needs to be established for this article.
- **Defined**: an object or proposition is specified, but the proposition has not been proved.
- **Unfinished**: a needed result has no Lean proof in this project.
- **External/unimported**: the paper invokes an external theorem; this project has neither proved nor assumed it as an axiom.

## Retained coverage ledger

Earlier rows record historical interfaces and partial milestones. The current revision summary and `verification/theorem-contracts-v53.json` are authoritative for the new finite iteration, mass recurrence and subpatch estimates.

### Coverage by paper location

| Stable ID | Paper location | Status and precise scope | Lean declarations / module |
|---|---|---|---|
| N2-DEF-001 | (1.3) | Defined concrete complex-valued Fourier integral over a measured frequency space, with Euclidean physical and frequency vectors | `extension`, `extensionProduct` |
| N2-DEF-002 | (1.4)-(1.6) | Defined a regular-level-set presentation of smooth patches, quantitative Gram-determinant transversality, and coercivity of the actual differentiated normal | `SmoothPatch`, `GeometricHypotheses` in `Targets` |
| N2-GEO-001 | (1.5) | Proved dimension n-k and orthogonality for independent normals; proved dimension two when n=k+2; proved the converse membership criterion from inner products with all normals | `commonTangent_finrank`, `commonTangent_two`, `commonTangent_orthogonal`, `mem_commonTangent_of_normal_orthogonality` |
| N2-GEO-002 | (1.4) to (1.5) | Proved independence from a nonzero Gram determinant, and the two-plane assertion from the defined quantitative hypotheses | `normals_independent_of_gram`, `geometric_commonTangent_two` |
| N2-GEO-003 | Ellipticity after Theorem 1.1 | Proved the stated compression bound using actual orthogonal projection and the inner product | `elliptic_compression` |
| N2-EXP-001 | (1.2) | Proved all inequalities 0<2/k<pc<q0<=1, the numerical examples, and expected(k+2,k)=pc | `exponent_range`, `expected_n2`; examples in `Exponents` |
| N2-ANA-001 | (2.1) | Proved finite positive-sum rpow subadditivity, valid for p<=1 and infinite values | `positive_sum_rpow_le` |
| N2-EXT-001 | External input 1 | Explicit borrowed localized restriction input; article-side localization and Corollary 4.3 are proved relative to it | `ArticleLocalizationAtlas.UniformLocalizedInput`; `ArticleTangentIntegralV38` |
| N2-EXT-002 | External input 2 | Proved for every ambient dimension and k >= 2, with compact uniformity and the unlocalized subensemble; external hypothesis discharged in Section 3 applications | `weighted_kakeya_external_all_dimensions`; revision 0.36 addendum |
| N2-EXT-003 | External input 3 | Explicit borrowed uniform partitioning/generic-transversality, tangent-cut, tube-cover and dimension-zero point-count interfaces are all applied to actual stages. Their external proofs are outside the user scope. | v51-v53 contracts and external-input policy |
| N2-EXT-004 | External input 4 | Explicit borrowed epsilon-removal assumption. Its local restriction and surface-test-decay hypotheses remain article-side obligations | `SurfaceEpsilonRemovalInput`, `AssumedEpsilonRemovalV38` |
| N2-ANA-002 | Lemma 3.1, Linfinity part | Proved actual L1-to-Linfinity and finite-measure L2-to-Linfinity estimates with the explicit surface-mass constant | `extension_le_L1`, `extension_le_L2` |
| N2-GAP-001 | Lemma 3.1, local L2 part | Proved for every fixed SmoothPatch, original L2 or MemLp input, all centers and R ≥ 0; no graph-cover hypothesis remains. Uniform varying-family constants are separate | `SurfacePlancherel` |
| N2-GAP-002 | Lemma 3.2 | Partially proved: actual torus Fourier synthesis, concrete cutoff multiplication and exact atom energies, overlap budgets, Euclidean smooth scaled cutoffs with all-order bounds, support-margin transfer, explicit translated l2 lattice weights, and uniform extension reconstruction. Uniform integration-by-parts decay is now proved for smooth compact amplitude/phase families. Exact graph rescaling and normalized atom energy are proved. Revision 0.10 constructs the smooth Taylor remainder through radius zero, extends local smooth phases, compares coordinate offsets with round finite tubes, and proves rapid selected and finite-cap tails for these local graph packets. Revision 0.11 proves the scaled coordinate cap-to-torus identification, actual cap coefficients, exact normalization and Euclidean L2 cutoff reconstruction. Revision 0.12 connects these coefficients to graph packets, exact energies, per-cap almost orthogonality, uniform extension reconstruction and rapid selected tails. Revision 0.13 constructs the coordinate cap partition, count, overlap, original-input budgets, single-index unconditional reconstruction and rapid tails. Revision 0.14 constructs actual Hausdorff graph packets with original surface inputs, density-ratio energy bounds, uniform reconstruction and rapid tails. The graph cover is constructed. Actual atlas packet synthesis, uniform extension recovery, energy, margins and normal alignment are proved in revision 0.17; the complete article-level Lemma 3.2 statement remains unfinished | `CutoffFourierPackets`, `ScaledCutoff`, `CapEnergy`, `TranslatedLatticeWeights`, `ExtensionSynthesis`, `OscillatoryDecay`, `GraphPackets`, `ParaboloidPackets`, `CapPacketTails`, `LocalGraphPackets`, `LocalGraphTails`; no full proof of Lemma 3.2 |
| N2-ENE-001 | (3.3)-(3.4), counting uses | Proved finite positive-energy counting and propagation of a supplied synthesis bound. This does not construct packets or prove their synthesis bound | `energy_sum_of_multiplicity`, `selected_norm_budget`, `selection_preserves_budget` |
| N2-GAP-003 | Lemma 3.3 | Conditional: actual whole-grid covering and integral comparison proved; exact original packet weights and volume cancellation checked. The external weighted Kakeya inequality remains an explicit hypothesis | `actual_packet_lattice_energy_of_kakeya`; not an unconditional proof of (3.6) |
| N2-GEO-004 | Initial operator step of Lemma 4.1 | Proved an actual continuous inverse of the projected shape operator with norm at most 1/kappa, and stability with bound 2/kappa after a half-kappa perturbation | `projected_shape_inverse`, `inverse_after_perturbation` |
| N2-GAP-004 | Lemma 4.1, Remark 4.2, Corollary 4.3 | Partially proved: nearby-plane submersions and smooth local charts, shape symmetry, exact (4.2), quantitative normal-space separation, finite measure of compact thin pieces, compact Stiefel-frame presentation, uniform distance correction (4.1) across supported tuples and nearby planes, one positive lower bound for the nearby-plane normal Gram determinant over all supported tuples, admissible frames, and surface indices, and one positive lower bound for the defining differential on the supported patches. Every fixed finite derivative order of the normal and defining functions, and every shape operator, has one bound common to all supported patches and frequencies. Common implicit-chart radii, all-order bounds in both coordinate directions, uniformly finite atlases, and injective immersed Euclidean slices are now proved. Small residual corrections retain these charts in the fixed extension. The uniform localized restriction estimate (4.3) remains unfinished | `ThinNormalSpace`, `UniformTransversality`, `FrameCurvatureCorrection`, `CompactFrames`, `CompactGramBound`, `NearbyWedge`, `CompactTupleWedge`, `UniformImplicit`, `FiniteImplicitAtlas`, `FrameImplicit`, `ImplicitSlices`, `UniformThinCharts`, `ThinChartTangents`; assembly of all extension-region transversality requirements and Corollary 4.3 remains unfinished |
| N2-GAP-005 | Lemmas 5.1–5.2 | ODE/cut/wall mechanisms and actual trimmed-cell tube counts are proved in the continuation chain; full stage assembly remains unfinished | v38–v41 continuation modules; current handoff |
| N2-ENE-002 | Markov selection in (6.8)-(6.9) | Proved simultaneous selection of one cell satisfying all normalized energy bounds, including a quantitative factor card(I)+1. Incidence counts and substantial-mass selection remain needed | `exists_simultaneous_good_cell`, `simultaneous_markov_selection` |
| N2-GAP-006 | Proposition 6.1 and dimension descent | Actual grouped stage alternative and finite original-packet-preserving iteration proved, with uniform budget and finite cellular error before R. Actual terminations are applied in the origin-mass theorem on chosen piece classes. | `uniform_grouped_atlas_step`, `uniform_actual_atlas_descent`, `exists_constructed_origin_mass_descent` |
| N2-EXP-002 | (6.5), (6.11)–(6.14) | Proved feasible counts from actual nonzero selected atlas mass and exhaustive zero/terminal/negative-exponent classification, with a uniform angular threshold | `atlas_nonzero_mass_feasible_counts`, `atlas_selected_stage_alternatives` |
| N2-EXP-003 | Degree choice after (6.10) | Proved contraction of the actual same-class non-wall coefficient with degree chosen before R, plus one degree across a fixed finite table of old constants | `admissible_nonwall_contraction`, `uniform_nonwall_contracting_degree` |
| N2-GAP-007 | Lemma 7.1 geometric step | Proved radius-independent multiplicity for nontangent witnesses in separated balls from the angular-uniform external tube-cover input. Actual lattice packet classification, energy summation, errors and local-constant assembly remain open | `nontangent_ball_multiplicity`; no full proof of (7.4) |
| N2-ZERO-001 | (6.15) | Proved same-class finite-point integral bound at lambda R^(1/2+tau), with child range and margin positivity discharged. Actual finite-point representation/cardinality and stage assembly remain explicit | `eventually_atlas_zero_dimensional_child_mass` |
| N2-ANA-003 | Sequence inequality in Lemma 7.1 | Proved the entire finite sequence Holder estimate for p>=2/k, including exponents below one | `finite_lp_monotone`, `nontangent_sequence_bound` |
| N2-GAP-008 | Lemma 7.2 | Unfinished. Constructed HQ,l, quantitative closeness, witness selection and tangent-cap support control | No proof of (7.7) |
| N2-ANA-004 | Holder portion of (7.9) | Proved product Holder for the same selected positive functions Gi | `product_holder_integral` |
| N2-GAP-009 | Proposition 7.3 endpoint inputs | Unfinished. Actual Ftan/Gi, lattice-ball counts, local Plancherel and energy summation must yield (7.8)-(7.10) | No full proof of Proposition 7.3 |
| N2-ANA-005 | (7.16)-(7.17) | Proved integral and quasi-norm interpolation and substitution of supplied endpoint bounds on exactly the same positive function; proved the scalar exponent cancellation | `tangential_integral_interpolation`, `tangential_norm_interpolation`, `tangential_norm_bound`, `tangential_loss_identity` |
| N2-ANA-006 | Raising p after (7.17) | Proved the lower-integral inequality under a pointwise bound | `raise_exponent` |
| N2-SCL-001 | (8.1) | Proved simultaneous child support-margin inequalities, encoded essential-support admissibility, and transferred the support of actual R^(-1/2) cutoffs from a cap anchor to every child radius in [1,R/2] | `SupportMargins`, `eventually_frequencyCutoff_children` |
| N2-GAP-010 | Proposition 8.1 | Actual original-input mass inequality, scalar conversion and separate-scale scalar closure proved on chosen subpatch margin classes. Strict-range subpatch growth/operator estimates derived. Compatible full original-support transfer remains open; the legacy exact single-C MarginRecurrences predicate is not asserted. | `exists_constructed_origin_mass_descent`, `margin_power_of_descent_Lp_mass`, `exists_constructed_subpatch_margin_growth` |
| N2-IND-001 | Radius induction after (8.2) | Conditional: proved full scalar growth theorem from the explicit three-child recurrence and local boundedness; child scales and threshold choice are proved, with no monotonicity assumption | `power_recurrence_growth`, `close_radius_recurrence`, `eventually_children` |
| N2-IND-002 | Conversion of powers in (8.3) | Proved taking the positive pth root with explicit constant and exponent conversion | `growth_from_power_bound` |
| N2-ANA-007 | Endpoint passage to (1.7) | Conditional endpoint implication fully proved for the actual extension operators on finite measured patches: ball-volume scaling, uniformity in the center, continuity and finite-volume Holder are established, and strict-range local estimates imply the endpoint | `localRestriction_endpoint`, `ball_volume_rpow`, `ball_norm_comparison` |
| N2-GAP-011 | (8.4), deduction of (1.8) | Global conclusion proved conditional on local restriction, surface test decay and assumed epsilon removal. The first two remain unfinished | `surface_global_of_local_and_external_removal`; `SurfaceTestDecay` |
| N2-EXP-004 | (9.1) and example (6,3) | Proved exact lower-multilinearity obstruction and positivity | `next_range_identity`, `next_range_obstruction`; example |
| N2-TGT-001 | Theorem 1.1 local conclusion | Defined only, in the regular-level-set presentation; unproved | `MainLocalGoal` |
| N2-TGT-002 | Theorem 1.1 global conclusion | Defined only, in the regular-level-set presentation; unproved | `MainGlobalGoal` |
| N2-ANA-008 | Regularity of (1.3) | Proved oscillatory-integrand integrability and continuity of the extension and product for measurable parametrizations and finite L2 patches | `ExtensionRegularity` |
| N2-ANA-009 | Bounded-scale initialization in Section 8 | Proved the actual best local constant is finite, controls every input including zero inputs, is monotone in radius, and has locally bounded pth power | `LocalConstant` |
| N2-IND-003 | Assembly of local conclusion in Section 8 | Conditional: actual strict-range recurrences imply all local exponents p>=pc, with no additional supplied norm comparisons or bounded-radius assumptions | `RestrictionRecurrences`, `local_range_of_recurrences` |
| N2-ANA-010 | Raising the exponent | Proved local and global monotonicity in exponent by interpolation with the actual L2-to-Linfinity bound. Does not provide a first global estimate or epsilon removal | `LocalRestriction.mono_exponent`, `GlobalRestriction.mono_exponent` |
| N2-ANA-011 | Translation of balls | Proved exact modulation identity, preservation of L2 input norms and transfer of an origin-centered bound to every center with the same constant | `Translation` |
| N2-GEO-005 | Tangency of the shape operator | Proved from the differentiated unit-normal identity, for the actual `SmoothPatch.shape` | `SmoothPatch.shape_orthogonal_normal` |
| N2-GEO-006 | Linear transversality in Lemma 4.1 | Proved quantitative ambient decomposition and that original normals plus shape images span the ambient space with disjoint summands at H=W. Uniform wedge bounds for nearby H over all supported tuples are proved in `CompactTupleWedge` | `shape_decomposition`, `geometric_normal_transversality` |
| N2-GEO-007 | Nearby-plane step of Lemma 4.1 | Proved coercivity and inverse bounds for W to H when projection gap times shape norm is at most kappa/2; the projected inverse has norm at most 2/kappa | `NearbyPlanes` |
| N2-GEO-008 | Local form of (4.1) | Proved local distance correction to the actual thin-support zero set, at a base point already on that zero set. Constant and neighborhood may depend on the base point and H | `nearby_thin_support_correction` |
| N2-GEO-009 | Implicit geometry of Lemma 4.1 | Proved smooth implicit parametrizations for nearby planes and the n-3 kernel dimension | `exists_smooth_nearby_thin_parametrization`, `nearby_thin_kernel_dimension` |
| N2-MEA-001 | Surface measure in (1.3) | Proved finite (n-1)-dimensional Hausdorff mass of every compact SmoothPatch support for n>=1, using local inverse charts and compactness | `SmoothPatch.finite_surface_mass`, `SmoothPatch.isFiniteMeasure_surfaceMeasure` |
| N2-MEA-002 | Thin-support measure | Proved finite (n-3)-dimensional Hausdorff mass for compact thin zero sets satisfying the stated regularity at every point. No uniform bound across the family is asserted | `thin_support_finite_mass` |
| N2-PKT-001 | Fourier-series part of Lemma 3.2 | Proved unconditional orthogonal synthesis, exact energy identities for arbitrary selections, and finite truncation errors; instantiated on actual torus Fourier coefficients | `HilbertPackets`, `FourierPackets` |
| N2-PKT-002 | Absolute-tail mechanism of Lemma 3.2 | Conditional on pointwise coefficient times l2-weight domination: proved absolute summability and a bound for every subcollection. Concrete radial weights and their domination by uniform translated lattice weights are now proved in revision 0.9; realization for general surface packets remains open | `PacketTails` |
| N2-ENE-003 | Infinite versions of (3.3)-(3.4) and incidence budgets | Proved infinite positive-energy multiplicity counting, disjoint splitting, partitions and reselection, including the norm budget for actual bounded Hilbert synthesis | `InfiniteEnergy`, `PacketBudgets` |
| N2-ANA-012 | Extension of packet expansions | Proved that actual extension evaluation is bounded on L2 and every unconditional L2 expansion reconstructs its extension uniformly over the entire physical space | `ExtensionSynthesis` |
| N2-IND-004 | Conditional local target | Proved the exact named local goal from strict-range recurrences for actual Hausdorff surface measures; no extra mass-finiteness assumption | `mainLocalGoal_of_surface_recurrences` |
| N2-GEO-010 | (4.2) | Proved differentiability of the normal scale, tangent Hessian identity, shape symmetry, and the exact orthogonal-complement description of the thin differential kernel | `ShapeSymmetry`, `ThinNormalSpace` |
| N2-GEO-011 | Perturbed normal spaces in Lemma 4.1 | Proved reverse compression with inverse norm at most 2/kappa, complementary normal summands, and uniform quantitative sum bounds on compact frequency sets | `NearbyNormalTransversality`, `UniformTransversality` |
| N2-GEO-012 | Uniform distance estimate (4.1) | Proved the correction for all supported geometric tuples and nearby two-planes, with a common raw projection-gap threshold, residual threshold, and distance constant. The proof constructs the compact Stiefel-frame family, recovers the exact projected-normal zero set through its frame equivalences, and uniformizes constants across the finite patch tuple. A uniform nearby-plane normal wedge bound over all supported tuples and surface indices is now proved. Common chart radii, all-order coordinate bounds, finite atlases, and correction-retained Euclidean charts are now proved; the localized restriction input remains open | `CompactCorrection`, `ParameterCorrection`, `FrameCurvatureCorrection`, `CompactFrames`, `CompactTupleWedge`, `UniformTransversality`, `UniformThinCharts` |
| N2-PKT-003 | Cutoff step in Lemma 3.2 | Proved actual cutoff L2 operators, exact atom norm and energy identities, arbitrary-subcollection almost orthogonality and cap-overlap energy budgets | `CutoffOperator`, `CutoffFourierPackets`, `CapEnergy` |
| N2-PKT-004 | Scaled symbols in Lemma 3.2 | Constructed Euclidean smooth cutoffs, proved uniform all-order derivative bounds B_q*r^(-q), support and inner-cap preservation, and child-margin transfer | `ScaledCutoff` |
| N2-PKT-005 | Lattice summation in Lemma 3.2 | Constructed explicit polynomial l2 weights, with norms uniformly bounded over all real centers. Radial decay now implies this domination, absolute convergence and uniform tails. Compact smooth phase families and actual local smooth-graph packets supply the radial decay; the full surface-measure decomposition remains unfinished | `LatticeWeights`, `TranslatedLatticeWeights` |
| N2-IND-005 | Margin class (8.1) and induction | Encoded essential support and the radius-dependent best constant; proved finiteness, zero-input handling, bounded-scale initialization and scalar induction with no radius-monotonicity hypothesis | `SupportMargins`, `MarginLocalConstant` |
| N2-IND-006 | Return to original supports | Conditional: margin recurrences on larger patches imply all local exponents on original Hausdorff supports, through zero extension and the proved endpoint passage | `surface_local_range_of_margin_recurrences` |
| N2-GEO-013 | Uniform charts in Lemma 4.1 | Proved common chart radii, smoothness on a fixed inverse domain, all-order coordinate bounds, explicit finite atlases and a uniform chart-count bound | `UniformImplicit`, `FiniteImplicitAtlas`, `FrameImplicit` |
| N2-GEO-014 | Actual thin-set parametrizations | Proved injective smooth immersed Euclidean slices of dimension n-3, local level-set coverage, uniform charts retained after small residual corrections into the fixed extension, and common charts for every admissible zero tuple in a fixed surface buffer | `ImplicitSlices`, `UniformThinCharts` |
| N2-GEO-015 | Chart tangent and normal spaces | Proved that immersed chart derivatives have range equal to the constraint kernel under the explicit expected-dimension condition, and hence recover (4.2) | `ThinChartTangents` |
| N2-GEO-016 | Fixed-extension room | Constructed larger compact surface supports with one positive buffer width, preserving defining functions, normals and the geometric hypotheses | `ExtendedPatch` |
| N2-PKT-006 | Integration by parts in Lemma 3.2 | Proved uniform inverse-polynomial decay for actual Euclidean oscillatory integrals whose amplitude and nonlinear phase form a globally smooth family over a compact parameter set, with common compact amplitude support. All derivative L1 bounds are derived | `OscillatoryDecay` |
| N2-PKT-007 | Lattice tails in Lemma 3.2 | Proved radial-to-product-weight comparison, absolute convergence, norm bounds for selected sums, and rapid tails absorbing any polynomial loss. Constants are uniform over real centers and arbitrary selections | `RadialPacketTails`, `PacketRapidDecay` |
| N2-PKT-008 | Graph rescaling and normalization | Proved the exact coordinate Lebesgue change of variables and graph phase identity; constructed actual extension inputs with exact scale-independent L2 mass, coefficient energy, compact support and L2 membership. The original compact-remainder criterion is now discharged for globally smooth graphs and, using cutoff extensions, local graph patches in revision 0.10 | `GraphPackets`, `GraphAtomEnergy` |
| N2-PKT-009 | Concrete curved packet localization | Proved the scale-R pointwise packet bound and rapid absolute tails for paraboloid graph packets whose physical axis offset is at least R^(1/2+tau)/10, uniformly in cap centers and selections and with absolute convergence. Revision 0.10 proves the perpendicular-distance comparison and finite-segment versions, and generalizes decay to local smooth graph phases. The full surface packet lemma remains unfinished | `PacketRapidDecay`, `ParaboloidPackets` |
| N2-PKT-010 | Summation across caps | Proved finite-cap tail assembly with square-root cardinality loss and original summed input energy; connected bounded-overlap cutoff energy and applied the assembly to actual paraboloid packets, including a full finite-cap rapid bound under explicit polynomial cardinality and input-energy hypotheses. The same assembly is now proved for local smooth-graph packets. The coordinate cap partition and its radius-dependent count are constructed in revision 0.13; fixed-graph Hausdorff transfer is proved in revision 0.14, while the general surface cover remains open | `CapPacketTails`, `LocalGraphTails` |

| N2-PKT-011 | Euclidean tube geometry | Proved offset/perpendicular-distance comparisons, the exact distance between axis points, uniform finite segment length bounds, and round finite tube versions of packet decay | `EuclideanTubes`, `RoundTubePackets` |
| N2-PKT-012 | General graph Taylor rescaling | Proved compact-interval differentiation and all-order smoothness; constructed the exact integral Taylor remainder jointly smooth in center, scale and frequency, including scale zero | `SmoothCompactIntegral`, `SmoothGraphRemainder` |
| N2-PKT-013 | General smooth graph localization | Proved actual-gradient packet decay and rapid selected tails, uniform over compact centers and bounded scales; round finite tube localization and uniform axis-length bounds | `SmoothGraphPackets`, `SmoothGraphTails` |
| N2-PKT-014 | Local graph patch localization | Constructed global smooth phase extensions on smaller balls and common cap-radius/physical-scale thresholds independent of decay order; proved round-tube rapid selected and finite-cap absolute tails. Coordinate Lebesgue measure and fixed cutoff; count/energy hypotheses explicit | `LocalGraphPackets`, `LocalGraphTails` |

## Dependency chain that remains open

The main missing chain is:

1. Formalize the four external inputs, or state precise externally supplied hypotheses in a separately named relative result.
2. Construct wave packets and establish local Plancherel with all uniformity and support margins.
3. Use the proved common implicit-chart radii, all-order coordinate bounds, finite atlases, and compact surface buffers to formalize the tubular-coordinate/Jacobian arguments and uniform analytic localized restriction input. The nearby-plane normal Gram lower bound is uniform over supported frequency tuples and all surface indices. Small-residual corrections now retain the common thin-set charts in the fixed extension; the remaining extension-region transversality and analytic assembly must still be checked.
4. Formalize projection lifting, trimmed-cell counting and selected-data dimension descent.
5. Establish both endpoint estimates on the actual Ftan, and the nontangent input budgets.
6. Deduce the recurrence for the actual best local constants, including zero inputs, centers, support margins and rapid-decrease errors.
7. Both the fixed-patch and radius-dependent-margin induction interfaces are proved. `surface_local_range_of_margin_recurrences` handles the original Hausdorff supports and all local exponents. The recurrence hypothesis in step 6 still has to be established.
8. Prove the decay input and apply epsilon removal for the global strict range.

The existing scalar, positive-function and concrete extension lemmas can be used in these steps. They do not bypass them. The finite-measure condition is now proved for the compact smooth surface supports with their specified Hausdorff measures.

## Presentation and verification limits

`Targets.lean` uses compact supports in extended smooth regular level sets, measured by codimension-one Hausdorff measure. The normal is smooth and unit, and its defining-function differential relation is explicit. The shape operator is `-fderiv normal`. An equivalence between this presentation and every abstract smooth patch in the paper has not yet been formalized. Support margins are expressed using ambient-frequency distance to the complement of an open domain, with essential support appropriate to L2 equivalence classes. The comparison with the article's particular coordinate-domain boundary distance, including chart constants, remains part of the coordinate construction.

The nontangent sequence inequality is currently a finite version. Energy counting and Hilbert synthesis cover infinite families and arbitrary subcollections, and actual extension evaluations reconstruct uniformly from an L2 expansion. Smooth scaled cutoffs and their support bounds are proved. Revision 0.10 constructs the general Taylor remainder, proves smoothness through zero radius, and supplies a cutoff extension for local phases. Actual local graph packets now have round finite tube localization, absolute convergence and rapid tails with a common scale threshold independent of decay order. Revision 0.11 proves the scaled-torus identification for actual coordinate cap inputs, including zero-extended cutoff reconstruction. Revision 0.13 constructs the coordinate cap partition/count and original-input packet assembly. Revision 0.14 constructs the Hausdorff measure transfer and original-input surface packets for a fixed Lipschitz graph. Revision 0.15 proves ambient packet margin loss and child-radius transfer under explicit center-margin hypotheses. The remaining packet obligations are the general level-set graph cover, construction of those support anchors, uniform family constants and complete article-level surface decomposition.

The build and axiom audit establish correctness of the Lean statements proved here. They do not certify the unformalized portions of the paper, nor do they imply that the full article has been formalized.

## Concrete continuation points after revision 0.15

1. **Complete the surface packet transfer (N2-GAP-002).** The coordinate cap-to-torus map, exact Fourier normalization, smooth separated cap partition, cap count and overlap, original-input energy budget, unconditional packet reconstruction, uniform extension reconstruction and rapid selected tails are now proved. The actual Hausdorff density, surface input/energy transfer, graph packet reconstruction and tails are now proved for each fixed graph. Assemble the original level-set graph cover, prove constants uniform over the required surface families, and connect the support buffers. The fixed-graph results do not prove full Lemma 3.2.
2. **Establish the uniform localized restriction input (N2-GAP-004).** Common chart radii, all-order bounds in both coordinate directions, uniformly finite atlases, and Euclidean immersed parametrizations are now proved. Corrected zero points retain those bounds, and actual compact surface buffers are constructed. Formalize the tubular coordinate changes and their surface-measure Jacobians, verify the extension-region transversality needed by the localized ensemble, and prove the stability/recursion arguments in External input 1. Compactness and smooth charts alone do not establish that analytic theorem.
3. **Complete local Plancherel assembly (N2-GAP-001).** Slice and iterated-slab bounds now hold for arbitrary compactly supported L2 inputs on globally smooth graph charts, including actual Hausdorff inputs. Relate these to ambient Euclidean balls, identify the level-set graph charts and retain uniform constants across the required chart family. The regularity of the input is no longer an assumption in the slice bound.
4. **Prove the geometric recurrence (N2-GAP-010).** `MarginAdmissible`, `marginLocalConstant`, and `MarginRecurrences` now represent (8.1)-(8.2). `surface_local_range_of_margin_recurrences` proves the entire subsequent passage to the original supports and the endpoint. The selected-data descent, tangential and nontangential estimates, support-anchor construction, and rapid errors still have to establish the recurrence itself.

These are unproved continuation tasks, not hypotheses silently inserted into an unconditional proof of Theorem 1.1.

## Geometry implementation and the remaining analytic step

`CompactFrames.lean` implements the finite-dimensional Stiefel route. The orthonormal-pair set is closed and compact; every two-plane of dimension two has a representative, and its coordinate map is a continuous linear equivalence onto `ℝ × ℝ`. Explicit rank-two projections identify those coordinates with the plane projection, with the frame residual bounded by the projected-normal norm. Retaining frames for both planes makes the projection-gap condition closed. Intersecting it with support, tangency, and all fixed-coordinate curvature inequalities gives a compact admissible family. `exists_frameFrequencyAdmissible_for_geometricTuple_and_plane` represents every dimension-two plane at a supported geometric tuple that meets the gap bound. `geometric_tuple_uniform_nearby_plane_correction_of_gap` supplies common gap, residual, and distance constants and puts the corrected point on the exact projected-normal zero set. `UniformTransversality.lean` bounds every fixed finite derivative order of the normal field on compact subsets of the extension neighborhood.

`CompactGramBound.lean` proves that the Gram determinant of any continuous compact family of independent vectors has a positive common lower bound. `NearbyWedge.lean` applies it at each fixed tuple. `CompactTupleWedge.lean` then includes the supported frequency tuple, a frame for its common tangent, and the nearby-plane frame in one closed subset of a compact product. Reverse curvature coercivity gives pointwise independence; compactness gives one positive constant across all supported tuples, admissible nearby planes, and surface indices. The same module sums the per-patch compact bounds to provide common bounds across the finite patch collection for each fixed derivative order of the normal and defining functions, and for the shape operators. It also derives one positive lower bound for the operator norm of the defining differentials on all supported patches.

This uses compact frames rather than a separate topological Grassmannian development.

Revision 0.8 supplies the chart construction. `smooth_inverse_neighborhood` obtains one open smooth inverse domain independent of derivative order. `compact_controlled_submersion_charts` gives a common positive radius and a bound sequence for both inverse derivatives and forward derivatives evaluated on the corresponding inverse-image region. `compact_finite_controlled_atlas` retains an explicit finite set of chart models. `uniform_frameFrequencyAdmissible_finite_atlases` gives common radii, derivative bounds, and a chart-count bound across all patch indices.

`parameter_euclidean_parametrization` keeps the parameter exactly fixed, proves local coverage, injectivity and derivative injectivity, and converts the vertical kernel isometrically to the Euclidean space of the expected dimension. Consequently `geometric_uniform_thin_charts` supplies ordinary Euclidean thin-set parametrizations at supported zeros. `geometric_uniform_correction_and_thin_charts` additionally corrects every sufficiently small projected-normal residual to a zero in the fixed extension while retaining a common chart radius and all-order derivative bounds. `ThinChartTangents` identifies the chart derivative range with the thin differential kernel when its expected dimension is supplied; nearby-plane regularity already provides that dimension at the admissible supported centers.

`exists_buffered_geometric_family` constructs larger compact surface supports with a common positive buffer. It preserves the full extended-surface geometric hypotheses, which in this project already quantify over every tuple in those fixed extensions. `geometric_uniform_thin_charts_on_surface_buffer` applies the chart theorem throughout the resulting common surface neighborhood of the original supports.

Still unproved: the full localized restriction theorem, the tubular surface-measure/Jacobian implementation, the remaining extension-region transversality assembly, and the recursion proving a common analytic constant in Remark 4.2. No version of External input 1 is inserted as an axiom.

## Revision 0.11: coordinate-cap Fourier construction

| Stable ID | Scope | Checked modules |
|---|---|---|
| N2-PKT-015 | Two-way L2 equivalence between unit cube, torus, and normalized scaled cap; exact affine Jacobian | `CubeTorus`, `ScaledCube` |
| N2-PKT-016 | Coefficients extracted from each actual cap input; Parseval and exact ordinary Lebesgue normalization | `CapFourier`, `CapNormalization`, `CapLebesgue` |
| N2-PKT-017 | Exact lattice character and graph-atom phase/2π factors; concrete cutoff support inside the cube | `CapCharacters`, `CapSupport` |
| N2-PKT-018 | Cutoff synthesis, total energy and arbitrary subcollection bound on the actual cap | `CapCutoffFourier` |
| N2-PKT-019 | Zero-extension isometry and reconstruction of ordinary cap inputs in full Euclidean L2 | `ZeroExtension`, `EuclideanCapSynthesis` |

These 65 additional results address the coordinate Fourier construction. They do not prove the cap partition, surface Jacobian, full Lemma 3.2, localized restriction, induction recurrence or Theorem 1.1.

## Revision 0.12: actual coordinate packets

| Stable ID | Scope | Checked modules |
|---|---|---|
| N2-PKT-020 | Actual normalized coefficient and full-space graph-mode identity; unit center phase | `ActualPacketCoefficients`, `GlobalGraphModes`, `ActualGraphPackets` |
| N2-PKT-021 | Exact total packet energy and positive dimensional cutoff constant; frequency support | `EuclideanPacketEnergy`, `ActualPacketEnergy` |
| N2-PKT-022 | Arbitrary selected L2 sums and per-cap almost orthogonality in actual packet energies | `ActualPacketSynthesis` |
| N2-PKT-023 | Reconstruction of the original cap extension uniformly over physical space | `CapExtensionSynthesis`, `ActualPacketExtension` |
| N2-PKT-024 | Pointwise decay, absolute selected tails and rapid round finite-tube tails with actual coefficients | `ActualPacketTails` |
| N2-PKT-025 | Finite-cap energy and rapid tails under explicit cap-count and input-energy budgets | `ActualFiniteCapPackets` |

These 47 new named results include the three anonymous continuation examples from revision 0.11, now promoted into the audited project. Reconstruction assumes the input is supported in the inner radius-r ball; packet energies and selected L2 convergence do not require that hypothesis. Decay uses a locally smooth graph phase on nested balls, compact cap centers, and one radius threshold chosen before all decay orders. At revision 0.12 no bounded-overlap cap partition was constructed, and the cross-cap version of (3.4) was not in the named inventory; both coordinate obligations are addressed in revision 0.13. Surface-measure transfer, full Lemma 3.2 and Theorem 1.1 remain unproved.

## Revision 0.13: constructed coordinate cap partition and complete input assembly

| Stable ID | Scope | Checked modules |
|---|---|---|
| N2-PKT-026 | Promoted support preservation and cross-cap energy under actual overlap | `CrossCapPackets` |
| N2-PKT-027 | Finite compact covers with centers in K and separation greater than r/2 | `FiniteCapCover` |
| N2-PKT-028 | Disjoint-ball packing; cap count O(r^(-d)); enlarged-cap overlap at most 9^d | `CapPacking` |
| N2-PKT-029 | Constructed smooth finite partition with radius-r supports and squared-weight budget one | `CapPartition`, `QuantitativeCapPartition` |
| N2-PKT-030 | Original L2 input split into actual restricted cap inputs, exact recovery and energy budget | `RestrictedInput`, `PartitionInputs` |
| N2-PKT-031 | Constructed coordinate packet families and cross-cap selected bounds with geometric overlap discharged | `PartitionPackets`, `CoordinatePacketFamily` |
| N2-PKT-032 | Families chosen before decay orders; rapid tails with constructed counts/energies and absolute convergence | `CoordinatePacketTails` |
| N2-PKT-033 | Single-index unconditional L2 reconstruction and arbitrary subcollection convergence | `FinitePacketIndexing` |
| N2-PKT-034 | Common finite frequency support and uniform reconstruction of the original full-space extension | `SupportedExtensionSynthesis`, `CoordinateExtension` |

All 56 new named results are included in the default build and full axiom inventory. The three revision 0.12 continuation files are promoted and removed as redundant standalone files. No separate unchecked continuation result is counted.

The family is constructed for compact coordinate supports and positive radii at most one. At scale r=R^(-1/2), the cap count is O(R^(d/2)); the choice of family is independent of every decay order. Rapid graph tails assume the explicit nested-ball smoothness hypotheses and compact centers inside the smaller ball. Surface Hausdorff transfer, full Lemma 3.2, local Plancherel, uniform localized restriction, the geometric recurrence and Theorem 1.1 remain unproved. The selected energy theorem uses a family of selected lattice sets, one for each cap; arbitrary subsets of the product index are separately proved unconditionally summable.

In revision 0.13, four anonymous density-transfer examples were separately compiled without warnings. They establish extension cancellation, inverse-density energy identity, a lower-density energy bound, and weighted L2 membership. They were outside the 621 named results at that revision. In revision 0.14 they are promoted into the main inventory, and the graph-density construction supplies their surface-measure connection.

## Revision 0.14: actual graph surface measure and surface packets

This revision adds 75 named results, for 696 in 126 modules. All 112 pre-existing main modules are unchanged. The four revision 0.13 continuation examples are promoted into `DensityTransfer` and their redundant standalone file is removed.

| Stable ID | Proved scope | Modules |
|---|---|---|
| N2-PKT-035 | Density cancellation, exact inverse-density energy, weighted L2 membership | `DensityTransfer` |
| N2-PKT-036 | Bounded linear inverse-density transfer; forward energy; inverse identities and support | `DensityL2`, `DensityForward`, `DensitySynthesis`, `DensityPackets` |
| N2-MEA-003 | Comparable sigma-finite measures have a measurable bounded finite density | `BoundedDensity` |
| N2-MEA-004 | Explicit Hausdorff normalization; graph pullback measure comparison and constructed density | `HausdorffDensity`, `GraphSurfaceDensity` |
| N2-MEA-005 | Smooth compactly supported Lipschitz extensions of local phases, with graph density | `LocalGraphDensity` |
| N2-MEA-006 | Isometric graph lift/pullback, extension integral identity and frequency support | `GraphMeasureTransfer` |
| N2-PKT-037 | Original weighted-input packet reconstruction, energy and uniform extension | `DensityPackets` |
| N2-PKT-038 | Constructed actual Hausdorff graph packets; L2 and uniform extension reconstruction; total energy and ambient support | `SurfaceGraphPackets` |
| N2-PKT-039 | Density-ratio cross-cap selected energy on the actual graph surface | `DensityAlmostOrthogonal` |
| N2-PKT-040 | Surface rapid tails and absolute convergence, with original surface-input norm | `SurfaceGraphTails` |
| N2-MEA-007 | Constructed local graph charts and exact original local graph patch measure | `LocalSurfaceGraph` |

The surface measure in `SurfaceGraphChart` is defined by pushing forward its constructed density and is proved equal to Hausdorff measure restricted to the graph. This equality is a proved theorem, not an assumption left to the packet estimates. `exists_surfaceGraphChart` constructs the chart from a Lipschitz phase; `exists_local_surfaceGraphChart` constructs one from the nested-ball smoothness hypotheses.

These are fixed-graph results. The existing `SmoothPatch` regular-level-set geometry has not yet been assembled into a compatible graph cover with the article's support margins and required uniform constants. The main restriction estimate, geometric recurrence and Theorem 1.1 remain unproved. Rapid-tail and absolute-convergence scale thresholds are separately stated and can be enlarged to their maximum. Selected energy is indexed by one lattice subset per cap; arbitrary product-index subsets are separately proved unconditionally summable.

Six further anonymous examples were separately compiled without warnings. Four in `continuation/SurfaceMarginsV14.lean` handle compact patch mass, ambient support-margin loss, child-radius margin transfer and preservation under arbitrary selected sums. Two in `continuation/GraphPatchInputV14.lean` handle original inputs measured on a restricted graph patch, including energy and uniform extension reconstruction. At revision 0.14 they were not included in its 696 named results or default build/axiom inventory. Revision 0.15 promotes all six into the main inventory. Their hypotheses still require the chosen graph support to lie in the specified ambient margin region.

## Revision 0.15: graph-slice Plancherel for rough inputs

This revision adds **52 named results**, for **748 in 136 modules**. All 126 earlier main modules are unchanged. The six previous continuation examples are promoted into the main build and named axiom inventory.

| Stable ID | Proved scope | Modules |
|---|---|---|
| N2-PKT-041 | Ambient surface-packet margin loss; child-radius transfer; preservation under selected L2 sums | `SurfaceGraphMargins` |
| N2-MEA-008 | Finite compact graph-patch measure; zero-extension bridge for original restricted inputs; integrability, continuous extension and unconditional reconstruction | `GraphPatchInput`, `SurfaceGraphMargins` |
| N2-ANA-012 | Fourier conjugation and Parseval pairing; Euclidean Plancherel under explicit integrability hypotheses and for Schwartz inputs; exact unnormalized `(2π)^d` factor | `FourierPlancherel` |
| N2-ANA-013 | Exact smooth compact graph-slice identity and interval-height identity; genuine finite slice energy and L2 membership | `GraphSlicePlancherel`, `SmoothSliceL2` |
| N2-PKT-042 | Smooth compact representatives of actual packets and finite sums; constructed sequence with strong L2 convergence, energy convergence and pointwise extension convergence | `PacketRegularity`, `PacketApproximation` |
| N2-ANA-014 | Fatou closure of the slice bound for arbitrary compactly supported coordinate L2 inputs; actual L2 membership and real energy bound | `CompactGraphPlancherel` |
| N2-ANA-015 | Exact density-weighted coordinate extension; surface slice bound for rough compact Hausdorff inputs; original restricted-patch bound and iterated slab bound | `SurfaceSlicePlancherel`, `CompactSurfacePlancherel` |

The rough coordinate bound is `∫ |E f(u,t)|² du ≤ (2π)^d ‖f‖²`. The surface bound multiplies this constant by the constructed density upper bound. Neither requires a smooth representative of the original input. The phase in these final slice theorems is globally smooth; local phases can use the already-constructed extension, but the general level-set cover and uniform ambient-ball assembly remain unfinished. The iterated slab theorem is stated as an iterated integral, not as an already-identified ambient-volume integral. No equality for arbitrary rough Fourier inputs, full Lemma 3.1, full Lemma 3.2, or Theorem 1.1 is claimed.

### Separately checked ambient-ball continuation

`continuation/GraphCoordinatesV15.lean` proves that `(t,u) ↦ graphPoint u t` preserves Euclidean volume, bounds a ball integral by its horizontal slices, and gives the actual estimate at every ball center:

`∫_{B(x₀,R)} |E g|² ≤ 2 R (2π)^d density.upper ‖g‖²`, for `R ≥ 0`.

The last theorem retains the original L2 norm for inputs defined only on the restricted Hausdorff graph patch. These six graph-coordinate results are outside the default build and the 748 named main results. They were compiled and checked against the same standard axiom allowlist separately; their source contains reproducible `#print axioms` commands. This advances the fixed-graph ambient-ball step beyond the main inventory's slice/slab statements. General level-set graph identification and uniform family assembly remain open.

`local_graph_patch_ball_estimate_v15` also removes the global-phase assumption: a phase smooth on an open neighborhood with the stated nested balls gives one constant for the original compact Hausdorff graph-patch input, all centers and all nonnegative radii. `continuation/OrthogonalExtensionV15.lean` adds three separately checked rotation results: extension covariance, unchanged ambient-ball energy and preserved restricted Hausdorff measure. There are **nine separately compiled and axiom-checked continuation results**, excluded from the 748 main results. The general level-set graph cover and family-uniform bounds remain open.

### Next concrete promotion and assembly steps

1. Promote the nine separately audited continuation results into the main modules; their proofs need no new analytic assumptions.
2. Use the orthogonal covariance identities together with the existing measure-preserving L2 pullback to transport original surface inputs through rotated graph coordinates.
3. Construct a finite graph cover of each supported regular-level-set patch, combine its input partition with the local graph estimate, and record a common density/cover constant. This is the outstanding passage from the fixed/local graph results to the article's general small hypersurface patches.
4. Continue with the independent localized restriction and geometric recurrence obligations; the local Plancherel checkpoint does not prove those estimates.

## Revision 0.16: ball estimates, rotations and finite graph-cover assembly

This revision adds **32 named results**, for **780 in 143 modules**. The 136 earlier main modules are unchanged. All nine revision 0.15 continuation results are promoted into `GraphBallPlancherel` and `OrthogonalExtension`; their version suffixes and redundant standalone files are removed.

| Stable ID | Proved scope | Modules |
|---|---|---|
| N2-ANA-016 | Volume-preserving slice coordinates; ball/slab comparison; original local Hausdorff graph-patch ball estimate for all centers and R ≥ 0 | `GraphBallPlancherel` |
| N2-MEA-009 | Orthogonal covariance of extension and restricted Hausdorff measure; isometric and surjective original-input transport; unchanged ball energy | `OrthogonalExtension`, `RotatedPatchPlancherel` |
| N2-ANA-017 | Local graph ball estimates pass to rotated graph patches and arbitrary measurable restrictions with no constant loss | `RotatedPatchPlancherel`, `FinitePatchPlancherel` |
| N2-ANA-018 | Finite physical-sum energy and supported-piece assembly; common-constant chart-count loss | `FinitePatchPlancherel` |
| N2-MEA-010 | Constructed disjoint measurable refinement, actual L2 chart inputs, exact reconstruction and original input-energy budget | `FiniteCoverInputs` |
| N2-ANA-019 | Finite-cover bound for the original restricted surface measure; common constant from finitely many local constants | `CoverBallEstimate` |
| N2-ANA-020 | Concrete local graph data imply compact carriers and actual Hausdorff ball bounds; conditional assembly for `SmoothPatch` | `LocalGraphCover` |

For m charts with one local constant C, the assembled estimate is `∫_{B(x₀,R)} |E g|² ≤ m C R ‖g‖²`. The chart assignment is constructed from disjointed indicators; reconstruction and the bound `Σ ‖g_j‖² ≤ ‖g‖²` are proved, not assumed. The measure may initially be infinite; the restricted target measure must be finite, which is already proved for `SmoothPatch`.

The remaining hypothesis of `SmoothPatch.ball_bound_of_graph_cover` is an actual finite cover of `S.support` by rotated local smooth graph patches. Producing this cover from the defining function and nonvanishing normal is not in the main inventory. Its existence is not hidden in an axiom or a structure field that asserts the desired analytic bound. Constants here are for a fixed finite cover; uniformity over the article's geometric families remains open. Theorem 1.1 and the independent localized-restriction/recurrence obligations remain unproved.

## Revision 0.17: buffered atlas packets

The default build contains **807 named results in 151 modules**. Of the 27 additions to the main inventory, 22 were already checked in revision 0.16 and are now promoted; five are new buffered-graph results. All 143 pre-existing main modules are byte-for-byte unchanged. The 36 new continuation results are separate from the main inventory. These are supporting Lean statements, not 843 distinct claims in the article.

Both fixed-patch estimates of **Lemma 3.1** are now in the default build, in `SurfacePlancherel`: one positive constant works for every original L2 input, all physical centers and all nonnegative radii. `RegularGraphCover` constructs the finite graph atlas from the regular-level-set hypotheses, so no graph-cover assumption remains in these estimates. `SurfaceAtlasInputs`, `AtlasInputs`, `AtlasSeries`, and `GraphAtlasMargins` contain the promoted input and conditional-series results.

`BufferedGraphChart` extends each local phase to a smooth global graph that agrees on a ball strictly larger than the original chart support. `SmoothPatch.exists_packet_buffered_atlas` constructs a common positive cap-radius threshold and a common positive ambient margin. Enlarged cap supports stay on the actual extended surface. These choices precede the input, cap family, and decay order.

### Actual packet construction in separately audited continuation

`continuation/AtlasPacketsV17.lean` contains 36 compiler- and axiom-audited results. `PacketGraphAtlas` has geometric data only, and its existence is proved from `SmoothPatch`; no decomposition estimate is an assumed field.

- Original surface inputs give full graph inputs with total squared norm at most the original squared norm. Their actual rotated extension integrals sum to the original extension.
- Equal-measure transport, graph zero extension, and rotation give linear isometries into one common ambient Hausdorff L2 space.
- The actual graph packets form one unconditional series indexed by a dependent sum of the chart-specific cap and lattice indices. The common atlas buffer is compact and has finite Hausdorff measure.
- `PacketGraphAtlas.packet_decomposition` constructs the cap families, bounds their total polynomial count, proves a scale-independent total packet-energy bound, and recovers the original surface extension uniformly over all physical space.
- `PacketGraphAtlas.packet_selected_energy` controls arbitrary cap/mode selections across charts. The extra loss is a fixed finite-atlas constant, not a radius-dependent loss.
- Every actual packet stays in the extended surface with a fixed positive margin. Orthogonal tube transport preserves the rapid-tail bounds, with the scale threshold chosen before every decay order.
- Differentiating the original defining function proves graph-tangent orthogonality. `PacketGraphAtlas.packet_axis_normal` identifies the actual surface normal as a nonzero scalar multiple of the rotated graph packet-axis vector at every cap center.

`PacketGraphAtlas.rapid_tail` combines the per-chart tails: one R₀ works for all decay orders N, all cap families satisfying the explicit polynomial count bound, and every collection of graph inputs. Its bound uses the square root of the total chart-input energy. `PacketGraphAtlas.rapid_tail_on_ball` specializes this bound to one original physical-space ball and charges it to the original input norm whenever the explicit chart-energy budget and cap-count bounds hold. The constructed inputs and cap families provide these budgets; their final bundling with the exact original L2 identity remains open.

The L2 series is currently proved to converge to the finite sum of the transported graph inputs; this sum has exactly the original extension integral. **Its equality in ambient Hausdorff L2 with the zero extension of the original input is not yet a packaged theorem.** The complete statement of Lemma 3.2 is therefore not claimed.

| Stable ID | Status and dependency boundary | Modules / declarations |
|---|---|---|
| N2-MEA-011 | Promoted: constructed regular-level-set graph atlas | `VerticalLevelGraph`, `RegularGraphCover` |
| N2-ANA-021 | Promoted: both fixed-patch Lemma 3.1 bounds | `SurfacePlancherel` |
| N2-MEA-012 | Promoted: original chart-input support, energy and reconstruction | `AtlasInputs`, `SurfaceAtlasInputs` |
| N2-PKT-043 | Promoted: conditional assembly of supplied chart series | `AtlasSeries` |
| N2-MEA-013 | Promoted: positive fixed-atlas margin | `GraphAtlasMargins` |
| N2-MEA-014 | Main: global graph extensions with a cap buffer and a positive common margin | `BufferedGraphChart` |
| N2-MEA-015 | Continuation: exact isometric transfer into common Hausdorff L2 | `ambientInput`, `rotatedAmbientInput` |
| N2-MEA-016 | Continuation: nested zero extension equals direct zero extension on the intersection | `zeroExtendL2_nested` |
| N2-PKT-044 | Continuation: constructed actual atlas packets, count, synthesis and uniform original extension recovery | `packet_decomposition`, `packet_hasSum` |
| N2-PKT-045 | Continuation: total and arbitrary-selection energy | `packet_total_energy`, `packet_selected_energy` |
| N2-PKT-046 | Continuation: actual extended-surface support and fixed margin | `packet_surface_margin` |
| N2-PKT-047 | Continuation: per-chart rapid tails outside rotated tube segments | `rotated_packet_rapid_tail` |
| N2-PKT-048 | Continuation: one fixed-atlas threshold for every decay order, compatible with the cap buffer | `PacketGraphAtlas.rapid_tail` |
| N2-PKT-049 | Continuation: common physical-ball rapid tails with the original input energy budget | `PacketGraphAtlas.rapid_tail_on_ball` |
| N2-GEO-017 | Continuation: actual surface-normal/packet-axis alignment | `graph_tangent_normal`, `packet_axis_normal` |

### Remaining obligations

1. Identify the constructed ambient L2 sum with the zero-extended original surface input, then bundle the same indexed family, selected-energy estimates, tube geometry, support and rapid tails into the full Lemma 3.2 statement.
2. Package explicit common cap-diameter and finite-tube radius/length bounds for the same indexed family, and combine the proved normal alignment and original-ball rapid tails with the exact L2 reconstruction.
3. Prove constants uniform over the varying nearby-plane families. A fixed finite atlas and its margin do not establish this uniformity.
4. Prove localized restriction (4.3), the geometric recurrence and dimension descent, and epsilon removal. **Theorem 1.1 remains unproved.**

### Reproducing verification

Run `lake build`, `python3 scripts/audit.py`, and `python3 scripts/audit-continuation.py`. The continuation script checks source hashes, exact declaration coverage, compiler diagnostics and the same standard-axiom allowlist as the main audit. Main and continuation inventories are disjoint. No admissions or project-specific axioms are used. No clean-dependency rebuild or hosted CI run is claimed.

### Concrete L2 identity handoff

Strengthen `SurfaceGraphChart.rotated_patch_input` to retain the identity between `G.rotatedAmbientInput A f` and the zero extension of the original rotated-patch input. Its existing proof already constructs `f` by pulling the original input back through `rotatedInput_surjective` and then zero-extending it to the graph. `zeroExtendL2_nested` now proves the nested zero-extension identity after identifying the restricted measures. Prove that zero extension commutes with orthogonal measure transport, then carry both identities through that construction. This avoids needing a new Fourier-injectivity theorem.

Then retain this identity in `PacketGraphAtlas.input_decomposition` and apply the already-proved `atlasPatchInput_L2_reconstruction`. `finite_dependent_fiber_hasSum` and `PacketGraphAtlas.packet_hasSum` provide the actual chart-dependent packet synthesis. Keep the input and cap-family choices fixed when assembling `packet_selected_energy`, `packet_surface_margin`, `packet_axis_normal`, and `rapid_tail_on_ball`. The latter accepts any cap family satisfying the count bound, so it can use the same constructed family as `packet_decomposition`.

For the remaining geometric packaging, transport `SurfaceGraphChart.packet_ambient_support` through `rotatedAmbientInput` to obtain the cap diameter. Bound graph slopes on each compact cap-center set using `compact_graphGradient_bound`, take a finite-atlas bound, and use the proved `packetSegment` geometry for one tube-length constant. No dependence on the physical radius or decay order should enter these fixed geometric constants.


## Revision 0.18: exact transport and common packet geometry

The main build contains **843 named results in 152 modules**. All 36 previously separate revision 0.17 results are promoted into `AtlasPackets`; all 151 earlier main modules are byte-for-byte unchanged. This revision adds **18 new supporting results**, kept in separately compiler- and axiom-audited continuation. Counts distinguish promotions from new proofs and supporting statements from article claims.

The remaining original-input L2 identity is still open. The higher-level cast proof was attempted but did not complete verification, so it is excluded from the delivered Lean inventory.

The checked transport results prove compatibility of equal-measure casts, zero extension, orthogonal input transport, and nested zero extension. The actual rotated packets have ambient frequency-cap support with one fixed atlas constant. Graph slopes, finite axis lengths, and round-tube diameters also have common constants independent of the physical radius. Every axis lies on an affine line in the article's actual surface-normal direction. The axes are compact and the round tubes are closed. The packet width is at most R for the relevant tau range.

| Stable ID | Checked scope |
|---|---|
| N2-MEA-017 | Equal-measure and orthogonal zero-extension identities |
| N2-PKT-051 | Actual cap support and common cap/tube geometric bounds |
| N2-GEO-018 | Affine normal lines, compact finite axes, closed round tubes |

The original fixed-patch Lemma 3.1 bounds remain proved. The promoted main results already establish actual atlas packet synthesis, original-extension reconstruction, total and arbitrary-selection energy bounds, support margins, normal alignment and rapid tails on the original physical ball, with a threshold chosen before the decay order.

### Remaining obligations

1. Finish `SurfaceGraphChart.ambientInput_patch` and the rotated patch-input identity, retaining exact zero extension in `PacketGraphAtlas.input_decomposition`. The checked general measure-transport lemmas supply the algebraic identities; the remaining issue is the concrete dependent cast instantiation.
2. Express arbitrary subcollections of the single dependent packet index by the nested chart/cap selections, retaining unconditional L2 convergence and the proved selected-energy bound.
3. Establish constants uniform over varying nearby-plane families, localized restriction (4.3), the geometric recurrence/dimension descent, and epsilon removal. **Theorem 1.1 remains unproved.**

### Verification

`lake build`, `python3 scripts/audit.py`, and `python3 scripts/audit-continuation.py` reproduce the checks. Both inventories use only `propext`, `Classical.choice`, and `Quot.sound`; there are no admissions or project-specific axioms. No clean-dependency rebuild or hosted CI run is claimed. The revision delta records all promotion provenance and unchanged-source hashes.


## Revision 0.19: checked transport and arbitrary packet selections

**843 main results; 35 separate continuation results; 17 new results; no promotions.** All 152 main modules and both prior continuation files are unchanged. This section supersedes historical revision boundaries.

N2-MEA-018 proves exact ambient graph-patch zero extension, exact orthogonal transport to rotated Hausdorff patches, equal-measure cast cancellation, transported-input surjectivity and norm preservation, and an abstract norm-preserving lifting theorem. These are in `continuation/OriginalPacketInputV19.lean`.

N2-PKT-052 closes the arbitrary single-index selection gap: `selected_packet_hasSum` proves unconditional convergence for every subset of the dependent chart/cap/modulation index; `selected_packet_energy_reindex` proves exact scalar-energy reindexing; `arbitrary_selected_packet_energy` proves the selected L2 bound. The source is `continuation/SelectedAtlasV19.lean`.

N2-PKT-053 proves one O(R^(d/2)) total and per-chart cap-count constant in `continuation/PhysicalCapsV19.lean`.

The concrete `SurfaceGraphChart.rotated_patch_input_L2` instantiation hit a **kernel deterministic timeout**. It and the subsequent original-atlas reconstruction and joint decomposition are **unverified**, excluded from all checked counts, and retained only as text in `drafts/`. N2-PKT-050 remains open. The direct concrete `rotatedAmbientInput_patch` equality is checked; the remaining obstruction is efficient kernel checking of the original-input existential instantiation.

The project was rebuilt successfully: 2,964 jobs, no warnings. All continuation declarations were freshly compiled and checked against the standard axiom allowlist, with exact declaration coverage and no overlap with the main inventory. The prior main axiom report is retained because every main source is unchanged; the redundant fresh main audit was stopped to allocate time to new proofs. No fresh main axiom rerun is claimed.

Remaining work: finish the concrete original-input L2 reconstruction; combine the same input/cap choices with normal tube geometry, margins and rapid tails into the full fixed-surface Lemma 3.2 statement; prove varying-family uniformity, localized restriction (4.3), recurrence/dimension descent and epsilon removal. **Theorem 1.1 remains unproved.**


## Revision 0.20 — original-input reconstruction and physical packets

This section supersedes earlier open-status descriptions of the original-input L2 kernel bottleneck and fixed-atlas physical packet assembly. There are **843 main results plus 62 separate continuation results (905 distinct)**; **27 are new in this revision**. The main modules and all five older continuation files are unchanged.

| Stable ID | Checked scope | Source |
|---|---|---|
| N2-PKT-050 | Exact norm-preserving rotated-patch lift; original atlas L2 identity; unconditional packet synthesis to the original input; joint count/energy/uniform-extension reconstruction | `continuation/OriginalInputV20.lean`, `continuation/AtlasInputV20.lean` |
| N2-MEA-019 | Generic finite-cover L2 lifting and faithful isometric ambient embedding of the original surface input | `continuation/AtlasInputV20.lean` |
| N2-PKT-054 | Same physical cap families and original-input choices: counts, cap support, positive margins, normal tube axes, tube diameter, total/selected energy and rapid tails; one threshold before all exponents | `continuation/PhysicalInputV20.lean` |
| N2-PKT-055 | Arbitrary single-index selections: sum/extension interchange, absolute convergence, exact norm-sum reindexing and rapid tails for their actual extension | `continuation/SelectedExtensionV20.lean` |

`PacketGraphAtlas.physical_original_input_data` assumes `0 < τ ≤ 1/2`, which covers the article's `0 < τ < 1/20`. Constants depend on the fixed atlas and τ, not R or the input. The actual round tube radius is `R^(1/2+τ)/10`; its diameter is bounded by `L*R`, and its axis lies on the original surface-normal line at the cap centre. All properties refer to the same chosen cap families and chart inputs. Arbitrary nested selections encode arbitrary chart/cap/modulation subsets; `arbitrary_packet_rapid_tail` additionally states the estimate directly for the single dependent index and the extension of its L2 sum.

`SmoothPatch.physical_original_input_data` also constructs the atlas, so the final surface-level statement assumes only the original smooth patch and the tau bounds.

The canonical `SmoothPatch.hausdorffInput` is proved isometric and norm-preserving. Its extension equals the original extension. Thus reconstruction in ambient Hausdorff L2 preserves the original input, not merely its Fourier integral. `finite_cover_lift_L2` isolates the measure casts at generic measures; `rotated_patch_input_L2` retains the transport equality in its original form to avoid costly kernel conversion. No checker is disabled.

Validation: incremental default build passed (2,964 jobs reported). All 62 continuation results were freshly compiled this session and checked against the exact source inventory, allowing only `propext`, `Classical.choice`, and `Quot.sound`. The prior 843-result main axiom audit is retained because every main module is byte-for-byte unchanged. No proof admissions or custom axioms are counted. Historical failed attempts in `drafts/` remain outside the Lean inventory and are superseded by these checked files.

Remaining obligations: constants uniform over the varying nearby-plane family; the localized restriction estimate (4.3); the geometric recurrence and dimension descent; the external Section 2 inputs; and epsilon removal. **Theorem 1.1 is not proved.**


## Revision 0.21 — grid energy reduction and Kakeya dimension condition

**843 main results + 116 separately audited continuation results = 959 distinct checked results; 54 new.** All 152 main modules and all nine older continuation files are byte-for-byte unchanged from revision 0.20. The header count of 61 in the previous STATUS file was stale; the v20 source inventory and audit correctly contained 62.

| Stable ID | Checked scope | Source |
|---|---|---|
| N2-PKT-056 | Half-open cube volume, disjoint lattice covering, exact finite meeting-grid bound, actual packet-to-infinite-tube covering with fixed width multiple | `continuation/GridGeometryV21.lean` |
| N2-ANA-022 | Disjoint-cell integral comparison, actual whole-grid reduction on the enlarged ball, conditional weighted-Kakeya energy assembly, exact amplitude and scale factors | `continuation/GridEnergyV21.lean` |
| N2-GEO-019 | Exact projection rank loss, independent-vector count in any subspace, identity and inequality (2.4), actual geometric-normal application | `continuation/KakeyaDimensionV21.lean` |
| N2-PKT-057 | Full axis equals actual normal line; original L2 packet weights and arbitrary selected synthesis match the Kakeya weights | `continuation/PacketKakeyaV21.lean` |
| N2-ANA-023 | Finite truncation convergence and extension of a supplied finite-family Kakeya bound to enumerated and arbitrary countable families | `continuation/KakeyaTruncationV21.lean`, `continuation/KakeyaCountableV21.lean` |
| N2-PKT-058 | Polynomial count for b≥1, R≥1, and rapid-error summation over every grid cell meeting the ball | `continuation/GridErrorsV21.lean` |
| N2-ANA-024 | Original-input joint grid estimate, with constants before the inputs and the same chart inputs at every cap scale; weighted Kakeya remains an explicit hypothesis | `continuation/OriginalGridV21.lean` |
| N2-SCL-002 | For fixed enlargement factors and 0<tau<1/2, one threshold gives 1≤b≤Db<R and a fixed enlarged integration ball | `continuation/GridScalesV21.lean` |

The cube definition uses coordinate intervals (q_j-b/2,q_j+b/2]. The integral region is the closed ball of radius R+sqrt(n)b. If w≤Db and a tube meets the C-dilated cube, the full axis tube of radius (D+sqrt(n)(1+C)/2)b covers the cube. For w=r/10 and b=λr, λ≥1, D=1/10 suffices. The complete grid is finite without an assumed finite truncation; its cardinality is at most (2 ceil(R/b+sqrt(n)/2)+1)^n (with the integer-to-natural convention in Lean). At b,R≥1 the real cardinality is at most (sqrt(n)+5)^n R^n.

The integral reduction allows arbitrary packet index sets and infinite nonnegative energies. The finite-to-countable Kakeya passage requires measurable tubes and finite total energy in each family, both matching the actual packet setting. No weighted Kakeya axiom has been added. `actual_packet_lattice_energy_of_kakeya` assumes the explicit weighted integral bound on the enlarged ball and enlarged tubes. The normalization lemma identifies R^eta b^(n-eta)=b^n(R/b)^eta; the positive volume factor is cancelled by a proved nonzero/finite argument. The normal dimension inequality alone does not prove external input 2 or its small-neighborhood uniformity.

**N2-GAP-003 is now conditional with its geometric reduction proved; it is not unconditionally closed. N2-EXT-002 remains external/unimported. Theorem 1.1 remains unproved.** The final section supersedes earlier descriptions of the unformalized cube-covering step. Other remaining obligations include uniform nearby-plane analytic estimates, localized restriction (4.3), the actual recurrence and dimension descent, and epsilon removal.


## Revision 0.22: directional subdivision and explicit Kakeya interface

This revision adds **45** checked results in eleven continuation files. The exact inventory is **843 main + 161 separate = 1004 distinct results**. All 152 main modules and all 18 earlier continuation files are byte-identical to v21. Every continuation result was freshly compiled and axiom-audited. Only `propext`, `Classical.choice`, and `Quot.sound` occur; no admitted proofs or project axioms are present.

| Stable ID | Checked scope | Sources |
|---|---|---|
| N2-GEO-020 | Finite compact subpatches, full-neighborhood normal variation, inherited normal/shape and quantitative geometric hypotheses; reference Gram bound, independence and Kakeya dimension condition | `DirectionalSubdivisionV22.lean` |
| N2-ANA-025 | Actual subpatch-measure input energy and exact extension/L2 reconstruction; finite product expansion; all-positive-exponent integral/seminorm bounds; reductions of local and global restriction | `SubdivisionInputsV22.lean`, `SubdivisionProductV22.lean`, `SubdivisionRestrictionV22.lean` |
| N2-PKT-059 | Constructed buffered atlases, original-normal support of every packet, unit actual axis directions, and straight-tube identity | `DirectionalPacketsV22.lean`, `DirectionalKakeyaV22.lean` |
| N2-ANA-026 | Finite-weight finite-family Kakeya input passes to countable actual packets and the original-input grid estimate | `DirectionalKakeyaV22.lean`, `DirectionalGridV22.lean` |
| N2-ANA-027 | Neighborhood transfer and compact uniformity over supported normal tuples, preserving all external scale parameters; simultaneous geometric subdivision | `UniformDirectionalKakeyaV22.lean` |
| N2-ANA-028 | Literal external-input proposition, open-to-closed integration-region transfer, fixed dilation factor and exact grid loss, eventual open-ball scale admissibility | `ExternalKakeyaInterfaceV22.lean`, `DilatedKakeyaGridV22.lean` |
| N2-ANA-029 | Complete conditional assembly from geometric hypotheses and External input 2 to constructed subdivisions, atlases and the original-input grid estimate | `GeometricOriginalGridV22.lean` |

All listed sources are under `continuation/`. The actual local/global assembly includes empty finite covers and zero inputs through ENNReal arithmetic. For p<=1 the finite-sum factor is 1; for p>1 it is m^(p-1), with m the number of directional tuples. The original L2 input is allocated by the checked disjoint finite-cover construction on each piece's own Hausdorff surface measure.

The compact uniformity argument is not an inference from pointwise finiteness alone: it first proves that a directional estimate transfers to nearby reference tuples after shrinking its directional radius. Compact induction then takes minima of positive radii and maxima of constants. The local external hypothesis retains every scale parameter before this argument is applied. `geometric_subdivision_from_external_kakeya` fixes its subdivision and constant for a chosen positive loss exponent before all admissible R,b and all inputs.

`FiniteDirectionalKakeya` requires each weight to be finite. Finite total actual packet energy supplies that condition on every finite truncation; the previously proved countable passage supplies the full packet family. The external goal uses open balls; the grid integral on a closed ball is covered by a strictly larger open ball, without assuming equality of ball boundaries.

The dilation calculation is
`(alpha R)^eta (beta b)^(n-eta) = alpha^eta beta^(n-eta) b^n (R/b)^eta`.
Thus `directional_packet_grid_dilated_kakeya` displays the fixed dilation factors and cancels the cube volume. For b=lambda R^(1/2+tau), fixed lambda,beta>=1 and 0<tau<1/2, the eventual scale theorem gives admissible tube width and the open ball of radius 2(1+sqrt(n))R. Existing v21 amplitude and input-budget identities give the q0 and P(f)^q0 factors. `geometric_original_grid_bound_from_external_kakeya` joins the construction into one theorem: it chooses subdivision and atlases, then energy constants, then chart inputs, before arbitrary cap scales and admissible physical-grid parameters. Its only external analytic hypothesis is `WeightedKakeyaExternalGoal`; the actual packet integral and directional data are proved. Its conclusion factors the squared energy budgets into a fixed product of energy constants and the original input-norm product raised to q0.

**N2-EXT-002 remains external/unimported; no external Kakeya axiom has been added. N2-GAP-003 remains conditional on that theorem.** The local/global subdivision reductions do not prove restriction for any directional tuple. The nearby-plane analytic uniformity in Remark 4.2 and Corollary 4.3 is a different issue and remains open, as do the geometric recurrence, dimension descent, algebraic external inputs, epsilon removal, and Theorem 1.1.

The final revision section supersedes historical statements that directional subdivision or directional-constant compact uniformization are wholly absent. Build and final inventory verification are recorded in `verification/build-v22.txt`, `verification/new-sources-audit-v22.txt`, and `verification/continuation-audit-final-v22.txt`.


### Next proof boundary after revision 0.22

The next internal analytic obligation is Corollary 4.3. The existing `geometric_uniform_thin_charts_on_surface_buffer` and `geometric_uniform_correction_and_thin_charts` results provide the correction/chart framework; `ThinChartAt.exists_parametrization_normal_space` identifies the actual normal space. To use External input 1 uniformly, the remaining work is to control the surface-measure Jacobians of the tubular coordinates, retain the transverse normal-space bound on the extension regions used by those coordinates, and formalize the stability/recursion argument described in Remark 4.2. The compact directional transfer proved in this revision addresses the Kakeya constant only; it does not supply the missing analytic recursion.

The finite product and local/global assembly in `SubdivisionRestrictionV22.lean` can be reused once those chart-level estimates are proved. The external input and the chart-level estimate must retain their quantifier order: choose geometric charts and constants before the admissible plane, localization thickness, physical radius, and inputs. No new assertion of Corollary 4.3 is made here.


## Revision 0.23: buffered thin charts, Jacobians and stable transversality

This revision adds **35 checked results** in nine continuation files: **843 main + 196 separate = 1039 distinct results**. All 152 main modules and all 29 earlier continuation files are byte-identical to v22. Every continuation result was freshly compiled and its axiom dependencies checked. Only `propext`, `Classical.choice` and `Quot.sound` occur. There are no admitted proofs or project axioms.

| Stable ID | Checked scope | Sources |
|---|---|---|
| N2-GEO-021 | Uniform compact buffer with wedge bound; small-residual correction stays in it; rectangular Jacobian bounds; parameter-preserving inverse differential; actual free Euclidean parametrizations with two-sided derivative and all-order bounds; uniform Jacobian charts and fixed extension buffers | `BufferedThinGeometryV23.lean`, `SliceJacobianV23.lean`, `ParameterSliceJacobianV23.lean`, `ActualThinJacobianV23.lean`, `UniformThinJacobianV23.lean` |
| N2-ANA-030 | Compact buffered thin zero sets; admissible projected-normal regions lie in a C*rho thickening; essential frequency-support transfer for arbitrary measured inputs | `ThinSupportLocalizationV23.lean` |
| N2-GEO-022 | Actual thin-chart normal space together with the other k-1 normals spans the ambient space | `ThinChartTransversalityV23.lean` |
| N2-GEO-023 | Uniform Gram lower bounds survive frequency movement in fixed extension regions; explicit coordinate-size condition for controlled charts; retained Gram implies transversality at a moved point of the same chart | `WedgeStabilityV23.lean`, `MovedChartTransversalityV23.lean` |

All listed sources are under `continuation/`. `geometric_thin_input_localization` uses the explicit set `admissibleThinRegion`: each frequency has a supported tuple witnessing the curvature-scaled plane gap. It does not assert correction for an arbitrary plane. The constants and compact buffers are chosen before plane, thickness and input. Setting rho=C0*mu is permitted when C0*mu is below the fixed threshold.

`sliceJacobian A` is the square root of the determinant of the Gram matrix of the images of the standard Euclidean orthonormal basis under A. Bounded differentials with a common lower norm bound form a compact operator family; this gives positive lower and finite upper Jacobian bounds. `physical_parametrization_bounds` constructs the actual chart, retaining its local coverage, injectivity, all-order derivative bounds and uniform two-sided first-derivative estimates. The external-parameter derivative vanishes along the free slice, so dropping that parameter does not change the relevant norm. `JacobianThinChartAt.to_thinChartAt` checks compatibility with the earlier chart interface.

`geometric_uniform_thin_jacobian_charts_on_buffer` chooses buffer width, chart radius, derivative bounds and positive Jacobian bounds before supported tuples, nearby extended tuples, index and plane. Its plane-gap hypothesis is explicit. Separately, `geometric_buffered_wedge_stability` starts at an admissible original zero-frame tuple and retains its positive Gram bound under small movements; no plane-gap hypothesis is imposed at the moved tuple. `geometric_thin_chart_wedge_persistence` gives the coordinate condition norm(t)<=eta/(M+1) when norm(D phi)<=M. `thin_parametrization_transverse_of_gram` applies the retained nonzero determinant to the actual chart derivative at the moved point. The normal-space dimension and direct-sum checks give the dimensions 3 and k-1 required by External input 1. These statements do not claim that every small-residual correction automatically satisfies a fresh plane-gap inequality.

### Remaining analytic boundary

The proved Jacobians belong to the **n-3-dimensional thin-zero-set slices**. The **n-1-dimensional tubular surface coordinates and their Hausdorff-measure change-of-variables/Fubini identity are not proved**. No equality between the computed Gram Jacobian and a surface density is assumed or asserted. The retained Gram lower bound uses the original normals and two shape images of the plane frame; Pointwise positivity for an actual orthonormal three-frame of the chart normal space is proved; obtaining a common positive lower bound for these normalized determinants still needs an explicit connection (the existing shape-norm bounds are available). Uniform analytic stability and the recursion described in Remark 4.2, including the localized and unlocalized transverse ensembles, are also outstanding. Consequently External input 1 and Corollary 4.3 are not proved by this revision.

The finite product/local/global assembly from v22 remains available. External input 2, the actual geometric recurrence and dimension descent, algebraic external inputs, epsilon removal and Theorem 1.1 remain open. The final revision section is authoritative; earlier coverage sections are historical.

Verification: `verification/build-v23.txt` records the successful default build (2964 jobs). `verification/continuation-audit-run-v23.txt` records the first 185 results in the fresh ordered audit; `WedgeStabilityV23.txt` and `MovedChartTransversalityV23.txt` record the final eleven fresh checks. `verification/continuation-audit-final-v23.txt` validates the complete 196-result inventory. The unchanged 843-result main axiom report is retained after source and audit-script byte comparison, rather than described as rerun.


## Revision 0.24: normalized normals and measured tubular surface charts

This revision adds **35 results in 18 continuation files**: **843 main + 231 separate = 1074 distinct checked results**. All 152 main modules and all 38 earlier continuation files are byte-identical to v23. The full 231-result continuation inventory was freshly compiled and axiom-audited. This section supersedes the earlier descriptions of the current proof boundary.

| Stable ID | Checked scope | Main entry points |
|---|---|---|
| N2-GEO-024 | A uniform raw Gram bound and bounded frame reconstruction coefficients yield a uniform normalized normal-space bound; fixed extension buffers and moved actual thin-chart points are included | `geometric_buffered_normalized_normal_bound`, `geometric_moved_chart_normalized_bound` |
| N2-GEO-025 | Full n-1-dimensional tubular charts, exact affine projected-normal coordinates, uniform surjectivity control, all-order and positive Gram-Jacobian bounds, local coverage, fixed buffers, exact thin strips and n-3-dimensional fibers | `uniform_tubular_chart_bounds`, `geometric_uniform_tubular_charts_on_buffer`, `tubular_normal_strip_preimage`, `tubular_coordinate_kernel_dimension`, `tubular_thin_zero_image` |
| N2-ANA-031 | Uniform shrinking to bi-Lipschitz compact charts; positive bounded measurable coordinate densities with an actual pushforward identity to restricted Hausdorff surface measure | `uniform_controlled_chart_surface_density`, `uniform_tubular_surface_densities`, `uniform_frame_measured_tubular_charts` |

### Quantifiers and geometric scope

The normalized normal-space lower bound is chosen before the index, original supported tuple, admissible frame, moved tuple and orthonormal normal-space basis. The raw normal/shape frame reconstructs from the normalized frame with bounded coefficients. Compactness gives a common positive Gram lower bound. Normal-space membership of the selected normal and shape vectors follows by differentiating the actual thin-level identity. At moved points no fresh plane-gap inequality is required for this normalized bound; a retained raw Gram bound from the original admissible tuple is used.

The tubular coordinate construction works in dimension n-1, fixing the external parameter and the defining-function coordinate while varying both projected-normal coordinates and the n-3 free coordinates. A fixed finite-dimensional coordinate equivalence, uniformly scaled once, provides contraction and lower norm bounds independent of the chart. The resulting linear projected-normal coordinate R satisfies norm(R)<=1 and has preimage witnesses v with norm(v)<=L*norm(w), with common L. The physical inverse slice retains all-order bounds. Its local coverage is proved for every positive coordinate radius, so the subsequent common shrinking preserves local surface coverage.

`geometric_uniform_tubular_charts_on_buffer` requires the curvature-scaled plane-gap condition at the buffered tuple. This is distinct from the moved-chart normalized bound, which uses the original admissible frame and retains its raw wedge by continuity. No claim is made that arbitrary small-residual correction automatically preserves that gap.

### Measure identity and remaining analytic boundary

A bound on the second iterated derivative and a lower first-derivative bound at the center give a common positive shrinking radius and a lower distance bound on the entire coordinate ball. Upper and lower Lipschitz bounds compare the pulled-back Hausdorff measure to Euclidean volume on that compact domain. Radon-Nikodym then supplies a measurable NNReal density bounded above and bounded away from zero almost everywhere. Its pushforward equals Hausdorff measure restricted to the image of the actual parametrization. The density uses the explicit Mathlib Hausdorff normalization factor. It is **not asserted to equal sqrt(det(Gram(D phi)))**.

The density theorem concerns full-dimensional surface measure, unlike v23's n-3-dimensional thin-chart Jacobians. `uniform_frame_measured_tubular_charts` chooses both radii, the all-order control sequence, density bounds and normal-coordinate inverse bound before the frame or frequency. The smaller compact chart also contains a local parametrization of the surface near its center. The density is measurable in its chart coordinate; no joint measurable choice in external plane parameters is asserted.

The projected-normal strip now has an exact linear-coordinate pullback, including the affine center shift. At zero centers the thin zero set in the chart image equals the image of ker(R), whose dimension is n-3. The bounded right-inverse witnesses now yield a continuous linear section valued in the orthogonal complement of the kernel and a product continuous linear equivalence, with both operator norms bounded by L+1. Still open are the coordinate disintegration/Fubini and L2 slicing needed to obtain the thickness gain, their finite chart/input assembly, and the uniform localized restriction argument of External input 1 and Remark 4.2. For q0<=1, ordinary Banach-space Minkowski is not available. Corollary 4.3 and Theorem 1.1 remain unproved, as do the other external-input, recurrence and epsilon-removal gaps recorded earlier.

### Verification

`build-v24.txt` records the default build (2964 jobs). `continuation-audit-run-v24.txt` records a fresh check of all 196 retained continuation results. `new-audit-run-v24.txt` records 29 new results, and `TubularThinCoordinatesV24.txt` the three thin-coordinate checks, and `NormalCoordinateConditioningV24.txt` the three final conditioning/decomposition results. `continuation-audit-final-v24.txt` validates the complete 231-result inventory, source hashes, declaration coverage and standard axiom dependencies. All logs are under `verification/`. The 843-result main report is retained only after byte-for-byte comparison of every main module and the root/audit/toolchain files against v23.


## Revision 0.25: measured normal-coordinate slicing and thickness

This revision adds **44 results in 20 continuation files**: **843 main + 275 separate = 1118 distinct checked results**. All 152 main modules and all 56 prior continuation files are byte-identical to v24. All 275 continuation results were freshly compiled and axiom-audited. This section supersedes earlier statements about disintegration being entirely open.

| Stable ID | Checked scope | Main entry points |
|---|---|---|
| N2-ANA-032 | Exact positive Haar factor for linear coordinates; uniform two-sided bounds; fixed n-3-dimensional kernel coordinates; weighted Tonelli and complex Fubini | `map_linear_coordinates`, `uniform_tubular_product_measure_coordinates`, `normal_fiber_energy_identity`, `integral_normal_coordinates` |
| N2-ANA-033 | Zero-extended measured chart inputs; exact surface energy and integral identities; finite L2 fibers; affine support and scalar thickness gain; density multiplier and actual Haar-weighted amplitude bounds | `measured_chart_normal_slicing`, `measured_chart_integral_slicing`, `measured_chart_density_amplitude_bound`, `actual_amplitude_thickness_bound`, `measured_compact_chart_L2_integrable` |
| N2-GEO-026 | Compact actual thin-fiber domains, exact projected-normal levels, inherited injectivity and uniform derivative bounds | `normalFiberDomain_compact`, `tubular_fiber_normal_identity`, `tubular_fiber_injOn`, `tubular_fiber_derivative_bounds`, `level_chart_normal_contains_adjoint_shape` |

### Coordinate factors and uniformity

Write e for the linear equivalence from full surface coordinates to the pair (u,v), with u in R x R and v in R^(n-3). Its first component is exactly R. The varying kernel is replaced by a fixed Euclidean space using an orthonormal basis; this does not enlarge either operator bound. Both norms are bounded by L+1, where L is the existing common bound for right-inverse witnesses. The construction works also when n=3 and the thin coordinate space has dimension zero.

`coordinateMeasureFactor e volume (volume.prod volume)` is a strictly positive finite NNReal c, and map(e,volume)=c*(product volume). Thus the full integral of h equals c times the iterated integral of h(e^{-1}(u,v)). The proof uses Haar uniqueness. Uniform upper and lower bounds come from the inclusions between fixed balls forced by the forward and inverse operator bounds, before choosing e. No unproved determinant or coarea identity is used.

### Surface inputs, weighted energy and extension amplitudes

A measurable density J on a compact chart K extends by zero to W on the full Euclidean domain. A measurable physical input g likewise gives F agreeing with g composed with the chart on K and zero outside K. Agreement is pointwise, including the boundary. The almost-everywhere density upper bound persists under this extension. The proved pushforward to restricted Hausdorff surface measure gives the exact identity

    surface energy = integral |F|^2 W dx
                   = c integral_u integral_v W(e^{-1}(u,v)) |F(e^{-1}(u,v))|^2 dv du.

Finite total energy gives finite fiber energy for almost every u. For integrable physical amplitudes the analogous complex-valued Fubini identity uses c W F in the product coordinates. A bounded density on a compact chart defines a finite measure, so an L2 surface input is integrable on that chart. The stated chart-transfer theorems take measurable representatives; a global quotient-space L2 operator and finite partition assembly are not claimed here.

### The checked scalar thickness gain

An affine projected-normal identity Q(phi(x))=a+R(x), together with strip support of g, forces F(e^{-1}(u,v)) to vanish outside the normal-coordinate ball centered at -a. The max-norm ball in R x R has area (2r)^2. Cauchy-Schwarz therefore bounds the integral of square roots of fiber energies by 2r times the square root of the total energy. This holds for extended nonnegative integrals and needs no Banach-space Minkowski inequality.

The distinction between weighted energy and the actual amplitude is explicit. The extension amplitude contains the density W, so its squared energy contains W^2. The upper bound W<=C gives integral |WF|^2 <= C integral W|F|^2. `measured_chart_density_amplitude_bound` expresses the resulting thickness bound using the original Hausdorff surface energy. `actual_amplitude_thickness_bound` also places c in the complex amplitude: its bound has the additional factor sqrt(b), for any upper bound c<=b. The previous theorem supplies such a b uniformly.

### Actual fibers and remaining boundary

The actual fiber domain is {v : e^{-1}(u,v) in K}. It is compact, including when it is empty. Its physical parametrization has exact projected-normal level a+u and inherits injectivity from the full chart. `tubular_fiber_derivative_bounds` proves pointwise smoothness, all-order bounds B(m)*L^m and the lower first-derivative bound with constant L*M, uniformly over u, wherever the full chart satisfies its controls. `level_chart_normal_contains_adjoint_shape` additionally proves that at arbitrary projected-normal levels the physical normal and the adjoint shape images of H belong to the parametrized level normal space. There is no zero-projection hypothesis. Two further lemmas show that the adjoint shape annihilates N and, on tangent inputs, differs from the ordinary shape only by a multiple of N. They do not prove a uniform raw Gram bound for the new frame on arbitrary nonzero levels. The corresponding quantitative transversality and analytic estimates for the nonzero level family remain open. The integrals on these fibers use Euclidean thin-coordinate measure with the explicit full-chart weight. No equality with intrinsic thin-fiber Hausdorff measure is asserted.

Still required are the full uniform analytic eligibility and estimates for the nonzero fiber family, the localized multilinear restriction theorem (External input 1), its perturbative Kakeya/recursion stability in Remark 4.2, and the supported-input and finite chart assembly of Corollary 4.3. Uniform geometry and the scalar Cauchy-Schwarz gain do not imply the multilinear Lq0 estimate. The main recurrence, external algebraic/Kakeya inputs, epsilon removal and Theorem 1.1 also remain open. No new axiom packages any of these gaps.

### Verification

`continuation-audit-run-v25.txt` records a fresh compilation and axiom check of all 231 retained continuation results. `new-audit-run-v25.txt` records the ordered fresh compilation of 41 new results; `NonzeroFiberNormalsV25.txt` records the three final nonzero-level/adjoint normal-space results. `continuation-audit-final-v25.txt` validates the full 275-result inventory, source hashes, declaration coverage and standard axiom dependencies. `build-v25.txt` records the passing default build (2964 jobs). The 843-result main axiom report is retained after every main module and the root/audit/toolchain sources were compared byte-for-byte with v24.


## Revision 0.26: measured nonzero fibers with uniform transversality

This section supersedes the v25 statement that quantitative transversality at nonzero levels is open. The analytic localized restriction estimate remains open.

There are **40 new results in 20 files**, giving **843 main + 315 separate = 1158 distinct checked results**. All 152 main modules and 76 prior continuation sources are byte-identical to v25. All 315 continuation results were freshly compiled and axiom-audited.

| Stable ID | Checked scope | Main entry points |
|---|---|---|
| N2-GEO-027 | Adjoint coercivity and inverse, arbitrary-level exact normal spaces, raw and normalized uniform Gram bounds | `nearby_reverse_adjoint_coercive`, `nearby_reverse_adjoint_inverse`, `thin_adjoint_normal_space`, `nearby_level_chart_normal_eq_adjoint_span`, `geometric_nonzero_chart_normalized_bound` |
| N2-GEO-028 | Prescribed frames and actual compact nonzero fiber geometry in one common measured family | `geometric_pairFrame_admissible`, `geometric_actual_fiber_normalized_bound`, `geometric_measured_transverse_fibers` |
| N2-ANA-034 | Strictly interior measured tubular charts with a prescribed physical image buffer | `uniform_tubular_surface_densities_shrunk`, `uniform_frame_measured_tubular_charts_shrunk` |

### Why the adjoint removes the zero-level restriction

Let W be the common tangent two-plane, H a nearby two-plane, and A the ambient shape operator. The existing quantitative inverse J of P_H A restricted to W has norm at most 2/kappa. Pairing P_W A†h with Jh gives norm(h)^2. Cauchy-Schwarz therefore proves

    (kappa/2) norm(h) <= norm(P_W A†h),  h in H.

This proof needs equal dimensions, the curvature lower bound on W and the curvature-scaled plane-gap condition. It does not need H tangent or the ambient operator A symmetric. It gives a quantitative reverse inverse and the direct-sum transversality of W-perp and A†(H).

The full frame consists of the k original normals and two adjoint shape images. Its independence follows by projection to W. The admissible frame set is compact without imposing projected-normal zero; continuity of adjoints and Gram determinants yields a common positive Gram lower bound. Uniform continuity extends the bound to nearby surface tuples without a fresh plane-gap condition at the moved tuple. Bounded frame expansion then gives a common lower bound after replacing the selected three normal vectors by any orthonormal basis of the actual fiber normal space.

`thin_adjoint_normal_space` proves that the constraint-kernel normal is exactly span(N) + A†(H) at arbitrary projected-normal levels. The parametrized versions identify this with the actual chart normal space when the derivative is injective and the kernel has the expected dimension. The geometric curvature assumptions supply that dimension. These statements do not identify A with its adjoint globally.

### The same actual fibers and measures

The affine normal-coordinate map is retained exactly. Frame-coordinate equality is proved equivalent to intrinsic thin-constraint equality. The sliced full chart is therefore locally a level chart at every interior full-chart point, including nonzero levels, and injectivity of its derivative follows from the full derivative and the linear coordinate equivalence.

The new measured chart construction accepts any positive physical buffer size. It first restricts to a radius controlled by the buffer size and the first-derivative bound, then applies the existing uniform surface-density construction. The resulting compact radius rho is strictly smaller than the smooth radius r, and the whole compact chart image lies in the requested buffer. Exact Hausdorff pushforward, common positive density bounds, all-order controls and local coverage are preserved. Strict containment is what justifies local derivative arguments on the compact domain boundary.

`geometric_measured_transverse_fibers` selects all constants before the supported frequency tuple, selected index, nearby frame and normal level. It constructs one full parametrization and one normal/thin linear equivalence with uniformly bounded forward/inverse norms and Haar factor. Its density pushes forward to the original restricted Hausdorff surface measure. For every normal level u the actual domain {v : e^{-1}(u,v) in closedBall(0,rho)} is compact and the restricted parametrization is injective. Every point has the exact affine normal level, uniform all-order bounds B(m)*(L+1)^m, a lower derivative bound with constant (L+1)*B(1)*L, and the common normalized Gram bound against the other factors' normals in the same buffer. Empty fibers are allowed, as is the zero-dimensional thin coordinate case n=3.

### Distance to the actual zero-level reference

`FiberZeroDistanceV26.lean` connects the same coordinates to spatial localization on the surface. At fixed thin coordinate v, the distance between fibers u and w is at most M*L*dist(u,w), where M bounds the full derivative and L bounds the inverse linear coordinate map. For affine center a, the actual zero projected-normal reference is u=-a. The theorem proves its intrinsic thin constraint is zero and gives physical distance at most M*L*delta when norm(a+u)<=delta. The zero reference remains in the full chart whenever the starting point is in radius rho and L*delta<=r-rho. This explicit margin condition is retained; it is not silently assumed for all thicknesses. `tubular_strip_infDist_zero_set` combines these facts into the distance-to-zero-set condition used in localized restriction. These four results are tracked by N2-GEO-029.

### Supported input transfer and conditional finite-chart assembly

`finiteCoverInput_inherits_support` and `atlasPatchInput_inherits_support` prove that disjoint chart assignment and transfer to the actual chart measure preserve any original frequency support condition, including a projected-normal strip. Each chart input has norm at most the original norm; the previously proved sum-of-squares budget is retained.

`atlas_product_reconstruction` expands the original product into the finite set of chart tuples. `atlas_product_integral_bound` integrates this identity with the explicit finite power loss, for every p>0. `atlas_assemble_local_estimates` consumes a stated estimate for every tuple and yields a bound using the original surface L2 norms. For p<=1 the finite power loss is one. This establishes the finite-sum assembly step for supplied chartwise estimates, without asserting those still-unproved estimates or an integral Minkowski inequality. `atlas_assemble_quasinorm_estimates` and `atlas_assemble_uniform_quasinorm_bound` give the corresponding quasi-norm statements, matching the article. A common local constant C gains the explicit factor (finitePowerLoss(number of tuples,p) * number of tuples)^(1/p), with original input norms. These results are tracked by N2-ANA-035.

### Remaining analytic boundary and verification

This is geometric and measure preparation for the uniform localized theorem, not a proof of that theorem. External input 1 and the perturbative Kakeya/wave-packet recursion of Remark 4.2 remain unformalized. The checked conditional finite-chart assembly still must be connected to an actual uniform localized estimate on the measured geometric family; finite geometric constants alone do not provide that estimate. Corollary 4.3 and Theorem 1.1 remain open. No continuous/quasi-Banach Minkowski step is assumed. No intrinsic thin-fiber Hausdorff formula or Gram-Jacobian/RN-density equality is introduced.

`continuation-audit-run-v26.txt` records the fresh 275-result retained audit; `new-audit-run-v26.txt` records the ordered 28-result geometry/measure compilation followed by eight atlas support/assembly results and four zero-reference distance/margin results (40 in total); `continuation-audit-final-v26.txt` validates the complete 315-result inventory, hashes, declaration coverage and standard axiom dependencies. `build-v26.txt` records the default build. The main 843-result audit is retained only after byte comparison with v25.


## Revision 0.27: uniform zero-reference localization and supported atlas assembly

This section is authoritative for the current revision. There are **27 new results in twelve files**, giving **843 main + 342 separate = 1185 distinct checked results**. All 152 main modules and 96 prior continuation sources are byte-identical to v26. All 342 continuation results were freshly compiled and axiom-audited. The default build passes.

| Stable ID | Checked scope | Main entry points |
|---|---|---|
| N2-GEO-030 | Explicit interior zero reference and one common localization threshold, with measured geometry | `normalReference_zero_localization`, `geometric_measured_localizing_fibers` |
| N2-GEO-031 | Actual fiber derivative differences and common finite-order perturbation thresholds | `tubular_fiber_jet_distance_bound`, `tubular_zero_reference_jet_bound`, `tubular_zero_reference_finite_jet_stability` |
| N2-GEO-032 | Compact controlled center cover and common physical coverage radius for a fixed model | `compact_controlled_center_cover`, `compact_affine_slice_uniform_coverage` |
| N2-ANA-036 | Physical strip support localization, actual atlas inputs and finite local cover extraction | `geometric_uniform_localized_support`, `atlasPatchInput_localized_support`, `geometric_finite_localization_atlas`, `geometric_localized_surface_inputs` |
| N2-ANA-037 | Selected-factor conditional assembly retaining a supplied thickness gain | `localized_atlas_thickness_assembly` |

### Interior reference on the same measured charts

For a linear normal/thin coordinate equivalence e and affine normal center a, define

    normalReference(e,a,t) = e^{-1}(-a, (e t).thin).

The map is continuous and idempotent. Its displacement is bounded by the inverse coordinate norm times norm(a + (e t).normal). A strict inequality L*delta < r-rho places it in the open smooth ball of radius r when t lies in the compact ball of radius rho. A common positive threshold is chosen simultaneously for this margin and the physical transversality buffer. The measured chart is shrunk into half the buffer; the reference displacement uses the remaining half.

`geometric_measured_localizing_fibers` selects all constants before the supported frequency tuple, selected index and nearby orthonormal frame. It retains the exact Hausdorff density identity, common positive density bounds, coordinate Haar-factor bounds, compact fiber domains, injectivity and local coverage. At every sufficiently small normal residual it gives the actual interior reference, intrinsic thin-constraint zero, physical distance bound and buffer membership. The zero fiber at that reference has uniform all-order derivatives, a quantitative lower derivative bound, and a normalized Gram lower bound against the other surface normals in the same buffer. The arbitrary nonzero fiber properties from v26 are retained.

### Quantitative derivative perturbations

On a convex full-chart domain, a bound M on the (m+1)-st derivative bounds variation of the m-th derivative by M times displacement. Restricting both full jets through the same affine thin slice costs at most L^m. Thus the actual sliced derivatives at two normal levels u and w satisfy

    norm(D^m psi_u(v) - D^m psi_w(v)) <= B(m+1) * L^(m+1) * dist(u,w).

The zero-reference version takes w=-a and uses the strip residual together with the explicit chart margin. `geometric_measured_localizing_fibers` includes this estimate at its actual zero reference. No unidentified model chart replaces the measured chart.

`exists_finite_jet_threshold` bounds any finite list of derivative constants using their absolute-value sum and chooses a common positive thickness below a prescribed geometric threshold. `tubular_zero_reference_finite_jet_stability` chooses its threshold before e and phi; it depends only on r, rho, L, B, the finite order N and tolerance epsilon. All derivatives through N are then epsilon-close. This is a geometric perturbation statement, not a proof that a restriction-estimate constant is stable under these perturbations.

### Support and finite atlas interface

The frame-coordinate norm uses the maximum norm on R x R. It is bounded by the Hilbert norm of the orthogonal projection; equality is not assumed. An original physical strip of width delta therefore satisfies the frame-coordinate threshold when delta <= tau.

`frequencySupport_restrict_transfer` combines chart membership almost everywhere with a pointwise support implication on that chart. `projected_strip_localized_support` uses actual reference witnesses to prove infDist(x,Z) <= D*delta on essential support. `atlasPatchInput_localized_support` applies this result after the disjoint chart assignment and transfer to the actual chart measure. The stronger `projected_strip_witness_support` and `atlasPatchInput_witness_support` retain an actual y in Z with dist(x,y) <= D*delta. The final analytic assembly and surface-input synthesis use this witness-based condition: when Z is empty it forces the piece to vanish almost everywhere. They do not rely on the convention infDist(x,empty)=0.

`geometric_uniform_localized_support` constructs compact physical chart images and sets of actual zero-reference points. Constants eta, tau and D precede the supported tuple, nearby frame, measure, delta and input function. Every target point lies on the extended surface, has zero thin constraint and stays in the common buffer. Relative local coverage of the original surface is retained.

`compact_localization_atlas` extracts a finite chart family from relative local coverage; it does not require the compact chart carriers themselves to be open. `geometric_finite_localization_atlas` applies this to a fixed selected support and frame. Its hypothesis explicitly requires the curvature-scaled gap for every tuple formed by varying the selected support point. It retains one common localization threshold and distance constant. Its chart count is finite but may depend on the frame; a uniform count for this particular measured/localized atlas is still to be proved. The earlier finite chart-model count is not silently identified with this new cover.

`compact_affine_slice_uniform_coverage` supplies the next coverage ingredient: for one fixed chart model and a compact set of centers inside its source, one positive physical radius works for every center and every affine slice with the common lower norm bound and exact chart formula. The radius is chosen before the slice map and parametrization. The proof uses uniform continuity at the compact center set and a positive source buffer. `compact_controlled_center_cover` now constructs the compact center refinement for a finite controlled atlas, retaining chart identity, all derivative bounds and half the original radius. It uses neighborhood stability of Controls and a finite compact refinement of the resulting open cover. To obtain the full uniform measured-atlas count, combine the finite family of coverage radii, retain the exact affine formula and measured data, and choose a fixed finite net of the physical support.

`geometric_localized_surface_inputs` completes the selected-factor decomposition on the article's actual surface measure. After choosing the finite atlas, it works for every delta below the common threshold and every L2 input in the physical strip. It constructs Hausdorff chart-measure L2 pieces with total squared norm at most the original squared norm, preserves original surface support, supplies zero-target neighborhood support, and exactly reconstructs the original extension. The chart family is chosen before delta and the input. This is unconditional geometric/input preparation under the stated curvature and gap hypotheses; it proves no local analytic bound.

### Conditional analytic assembly and the remaining boundary

`localized_atlas_thickness_assembly` requires a localized estimate for each chart tuple and each family of chart inputs whose selected factor has, at almost every nonzero input point, an actual zero-target witness within distance D*delta. The hypothesis includes a finite common local constant C times delta. The conclusion is the original extension-product quasi-norm bound with the original L2 norms, the same C*delta gain, and the explicit factor

    (finitePowerLoss(number of chart tuples,p) * number of chart tuples)^(1/p).

It works for every p>0, including p<=1, using the already checked finite-sum power argument. It assumes no continuous quasi-Banach Minkowski inequality. The localized estimate is a genuine hypothesis, not an axiom or a theorem proved by this revision.

The simplified finite-atlas and input-decomposition theorems retain compact carriers, zero-target localization and input identities; they do not yet bundle all parametrization and density data from the stronger measured-family theorem. The generic extraction theorem accepts an arbitrary property P, so that data can be retained in the next construction.

The selected-factor atlas must also be combined with subdivisions of the other factors inside the common transversality buffers. Its existence alone is not a joint transverse product atlas.

To obtain the plane-independent constant of Corollary 4.3, the measured/localized atlas still needs a uniform chart-count bound, and External input 1 needs its uniform analytic proof. Remark 4.2 specifically invokes stability of the perturbative Kakeya theorem and wave-packet recursion; the new finite-order geometric closeness does not replace those arguments. Theorem 1.1 and other previously listed external/recurrence/algebraic/epsilon-removal gaps remain open. No intrinsic thin-fiber Hausdorff or Gram-Jacobian/RN-density identity is introduced.

### Verification

`continuation-audit-run-v27.txt` records the fresh audit of 315 retained results. `new-audit-run-v27.txt` records the 27 new results compiled in dependency order. `continuation-audit-final-v27.txt` checks all 342 declaration inventories, source hashes, compiler outputs and axiom dependencies. `build-v27.txt` records the default build. The main 843-result audit is retained after byte comparison with v26; it is not described as a fresh main audit.


## Revision 0.28: uniformly finite measured product atlases

This section is authoritative for the current revision; earlier sections are historical. There are **25 new results in seventeen files**, for **843 main + 367 separate = 1210 distinct checked results**. All 152 main modules and 108 prior continuation sources are byte-identical to v27. All 367 continuation results were freshly compiled and axiom-audited; the default build passes.

| Stable ID | Checked scope | Main entry points |
|---|---|---|
| N2-GEO-033 | Uniform physical coverage and fixed finite count with measured charts retained | `finite_controlled_uniform_slice_coverage`, `uniform_frame_measured_covering_charts`, `uniform_measured_tubular_atlases` |
| N2-GEO-034 | Joint product-atlas transversality, measured coordinates and zero references | `geometric_uniform_measured_atlas`, `uniform_chart_normal_coordinates`, `uniform_bundled_zero_targets`, `ChartNormalCoordinates.compact_zeroTarget` |
| N2-ANA-038 | Finite frame-independent assembly cost on original surface measures, conditional on a local estimate | `finite_atlas_cost_mono`, `uniform_cardinality_thickness_assembly`, `measured_surface_thickness_assembly` |
| N2-ANA-039 | Actual chart L2 energy, almost-everywhere finite fibers and exact extension slicing | `MeasuredTubularChart.normal_slicing_L2`, `MeasuredTubularChart.extension_slicing_L2` |

### Uniform coverage without losing the measured chart

The v27 compact-center refinement is now combined over finitely many chart models. `finite_controlled_uniform_slice_coverage` supplies one positive physical radius before choosing the center, affine slice map or parametrization. The selected model retains Controls at half the original smooth radius. Empty model families are handled vacuously rather than taking a nonexistent minimum.

`AffineTubularSlice` retains the actual linear slice map, its norm and lower norm bound, its range inclusion for the relevant coordinate differences, and the exact formula for the actual parametrization. `uniform_tubular_chart_bounds_with_slice` and `uniform_tubular_surface_densities_with_slice` retain this witness through the full derivative and Hausdorff density construction. The physical coverage proof uses that witness, not a second unidentified parametrization.

`uniform_frame_measured_covering_charts` combines these ingredients over the compact admissible frame-frequency set. Its common physical radius delta is positive and selected before the frame-frequency point. Every extended-surface point within delta of the center lies in the image of the open parameter ball of radius rho. The larger smooth radius r, all derivative bounds, lower derivative bound, density bounds and exact pushforward identity are retained on the same chart.

`MeasuredTubularChart` bundles this data. Its carrier is the image of the closed rho-ball; the carrier is compact and lies on the extended surface when rho <= r. `uniform_measured_tubular_atlases` chooses a finite delta-net of each original compact support, then constructs a measured chart at each fixed center for every admissible frame. The centers, counts m_i and common N are chosen before the frame. Each m_i <= N and the actual chart carriers cover the original support. This closes the uniform measured-atlas count gap recorded in v27.

### Joint transversality and zero references

`ChartNormalCoordinates` retains the actual equivalence from full surface parameters to two normal coordinates and the remaining thin coordinates, the exact normal-coordinate identity, both operator bounds, and positive common lower/upper Haar-factor bounds. `uniform_chart_normal_coordinates` chooses the factor bounds before all chart choices.

`geometric_uniform_measured_atlas` first selects the physical transversality buffer eta and Gram bound a. It constructs all measured charts inside eta/2, then selects a common positive strip threshold tau and displacement constant D. For each sufficiently small normal residual, the same chart's explicit zero reference stays strictly inside the smooth radius r, lies on the extended surface, has zero thin constraint, is within D times the actual residual, and remains within eta of its center.

For any chart tuple and selected factor, the actual thin-fiber normal space has an orthonormal basis whose Gram determinant with the other surface normals is at least a. The other points range over their **actual chart carriers**, which lie inside eta/2. The selected fiber point may be outside its compact carrier but must lie in the open smooth chart and within eta of its center; the explicit zero reference satisfies these requirements. This closes the joint buffer-compatibility gap for these hypotheses.

The quantifiers matter. The geometric product-atlas theorem assumes every original support is nonempty and requires the curvature-scaled gap bound for every supported frequency tuple and every selected index. Its constants, fixed centers and counts precede the orthonormal frame q. No assertion is made that such a frame exists for arbitrary unsubdivided supports. Applying this theorem to the article's sufficiently small subdivisions still requires verifying the stated admissibility hypotheses there. Nonempty supports prevent deriving admissibility from a vacuous geometric tuple hypothesis. `surface_product_zero_of_empty_support` separately proves that if any original support is empty, the actual original extension product is identically zero for every family of L2 inputs. Thus this case does not need an admissible geometric atlas.

`ChartNormalCoordinates.zeroTarget` is the image of the explicit reference map over the compact parameter carrier restricted to the fixed maximal strip tau. The target is independent of the eventual smaller strip and input function. `uniform_bundled_zero_targets` gives intrinsic zero-level membership, buffer membership and actual nearby witnesses with common tau and D. `compact_zeroTarget` proves compactness whenever references remain in the smooth chart. The strip's closedness follows from the affine normal identity; no unsupported global regularity assumption on the extended normal field is used.

### Conditional assembly on the original surface measures

The number of chart tuples is at most N^k. `finite_atlas_cost_mono` bounds the finite-sum cost monotonically, and `finite_atlas_cost_ne_top` proves the explicit cost is finite for p>0. Thus the supplied local estimate assembles with cost

    A(N,k,p) = (finitePowerLoss(N^k,p) * N^k)^(1/p).

`uniform_cardinality_thickness_assembly` uses this common bound while transferring original projected-normal strip support to witness neighborhoods of the zero targets. It works for every p>0, including the quasi-Banach range, and preserves a supplied finite C*delta gain and the original L2 norms.

`measured_surface_thickness_assembly` instantiates that interface with the article's original Hausdorff surface measures, the bundled chart carriers, actual coordinate maps and their fixed zero targets. Compact carriers supply measurability and the checked original-surface finiteness theorem supplies the L2 input setting. The existing disjoint atlas-input construction supplies support transfer, norm budgets and exact extension reconstruction. The theorem does not replace these inputs with abstract unrelated chart functions.

Its remaining local hypothesis is explicit: for every chart tuple and every family of chart-measure L2 inputs with the selected factor supported within distance D*delta of an actual zero target, the extension-product quasi-norm is bounded by C*delta times the product of L2 norms. The conclusion is the original-surface estimate with A(N,k,p)*C*delta. To obtain Corollary 4.3, one must still prove this local hypothesis uniformly with the required scale/loss dependence and verify the article's admissibility setup. This is the analytic content of External input 1 and Remark 4.2, not a consequence of finite atlas extraction alone.

The uniform local analytic estimate, perturbative Kakeya and wave-packet recursion stability, Corollary 4.3 and Theorem 1.1 remain open. No intrinsic thin-fiber Hausdorff/Gram-Jacobian/Radon-Nikodym formula, global continuous normal-frame choice, joint measurable family selection, or new smooth frequency partition is asserted.

### Exact slicing of the actual chart inputs

`MeasuredTubularChart.finite_surface_carrier` proves that each actual chart carrier has finite Hausdorff measure in the article's dimension n-1. `surface_mass_le` additionally bounds the actual carrier mass by C times the volume of the fixed parameter ball, uniformly in the frame and center. This supplies a common mass constant for bounded-scale estimates; it does not supply the strip-thickness gain. The finiteness proof uses its bounded coordinate density and explicitly reconciles the natural-number dimension n-1 with real subtraction under 1 <= n.

`normal_slicing_L2` applies the measured normal-coordinate disintegration to every actual chart-measure L2 input. It constructs measurable coordinate data, preserves the original surface energy exactly with the Haar normalization, proves finite thin-fiber energy for almost every normal coordinate, and retains the scalar linear strip-width bound. This estimate concerns energy; it does not justify interchanging a quasi-Banach norm with a continuous integral.

`extension_slicing_L2` gives the exact complex-valued Fourier extension formula in the same normal/thin coordinates. It chooses one measurable density and input amplitude before the physical point x, agrees with the actual chart input on the compact parameter domain, and vanishes outside it. For every x the oscillatory coordinate amplitude is integrable and its iterated integral, with the exact Haar factor, equals the original chart extension. The phase uses the actual parametrization. This supplies the concrete coordinate input to the future local analytic proof without making an intrinsic thin-fiber Hausdorff identity claim.

### Verification

`continuation-audit-run-v28.txt` records the fresh audit of 342 retained results. `new-audit-run-v28.txt` records 25 new results compiled in dependency order. `continuation-audit-final-v28.txt` checks all 367 declaration inventories, hashes, compiler outputs and axiom dependencies. `build-v28.txt` records the default build. The 843-result main axiom report is retained after byte comparison, not described as a fresh main audit.


## Revision 0.29: actual strip inputs, bounded-scale gain and L2 fibers

This section is authoritative for the current revision; earlier sections are historical. There are **45 new results in nineteen files**, giving **843 main + 412 separate = 1255 distinct checked results**. All 152 main modules and 125 prior continuation sources are byte-identical to v28. All 412 continuation results were freshly compiled and axiom-audited; the default build passes.

| Stable ID | Checked scope | Main entry points |
|---|---|---|
| N2-GEO-035 | Compact physical strips, bounded coordinate support and quadratic strip volume/mass | `MeasuredTubularChart.compact_frame_strip`, `coordinate_strip_volume_le`, `MeasuredTubularChart.uniform_frame_strip_mass` |
| N2-ANA-040 | Essentially supported actual inputs and common coordinate amplitudes | `measurable_supported_representative`, `MeasuredTubularChart.projected_strip_representative`, `exists_strip_chart_amplitude`, `fixed_chart_amplitude_extension` |
| N2-ANA-041 | Uniform original-surface thickness gain at bounded scales | `uniform_surface_strip_extension_bound`, `uniform_surface_strip_product_bound`, `uniform_bounded_radius_strip_product`, `geometric_bounded_radius_strip_product` |
| N2-ANA-042 | Actual L2 thin-fiber inputs, norm budgets and integrable extension reconstruction | `StripChartAmplitude.fiberInput_energy_bound`, `StripChartAmplitude.fiberInput_thickness_bound`, `StripChartAmplitude.extension_fiberInput`, `StripChartAmplitude.fiber_extension_integrable` |

### Essential support is not pointwise support

The v25 density-amplitude estimate required a globally measurable function with pointwise strip support. The original data are L2 equivalence classes and have only essential support. This revision connects those settings explicitly.

`MeasuredTubularChart.compact_frame_strip` proves compactness of the physical chart strip by identifying it with the image of a compact parameter set. On the parameter ball the normal coordinate is exactly affine, so its strip is closed. No global measurability or continuity of the extended normal field is assumed.

`measurable_supported_representative` uses a measurable indicator to replace an essentially supported function by an everywhere supported representative, preserving its almost-everywhere class. `strip_representative` applies this to the actual Hausdorff chart measure and includes chart membership. `projected_strip_representative` starts with the article's orthogonal-projection condition and uses the inequality between the frame-coordinate norm and projected-normal norm. These norms are not assumed equal.

### One choice of coordinate data retains all identities

`StripChartAmplitude` bundles a pointwise supported representative, the zero-extended nonnegative density and complex coordinate input, their measurability and pointwise parameter identities, the almost-everywhere density bound, affine normal-strip support, exact original surface energy, the density-amplitude thickness bound, and the exact Fourier extension formula for every physical point. `exists_strip_chart_amplitude` constructs this bundle from an actual chart L2 input with essential frame-strip support.

All these statements concern the same coordinate functions. `fixed_chart_amplitude_extension` allows the exact Fubini formula to be applied to an already chosen density and amplitude, rather than introducing unrelated functions for the energy and extension statements. The representative has the same original L2 energy and extension by almost-everywhere equality. The coordinate functions are chosen before the physical point x.

`StripChartAmplitude.coordinate_support` bounds both normal and thin coordinates of every nonzero input point. If the normal coordinate is u and the thin coordinate is v, then

    norm(Q N(z) + u) <= epsilon,
    norm(v) <= (L+1)*rho.

The same thin ball works independently of the frame and input once the common chart constants have been selected. The density-multiplied fiber amplitudes have total Haar-normalized energy at most C times the original chart energy, and almost every fiber has finite L2 energy.

### Quadratic strip mass and a pointwise thickness gain

`coordinate_strip_volume_le` puts the image of the parameter strip inside the product of a normal closed ball and the fixed thin ball. Exact measure transport gives a Haar factor, and the two scalar normal coordinates use the maximum norm. Their ball has area exactly (2*epsilon)^2, interpreted with ENNReal.ofReal for arbitrary real epsilon.

`chart_restricted_mass_le` transfers the almost-everywhere upper density bound to any measurable physical set through its actual parameter preimage. Applying it to the compact physical strip yields

    surface_measure(chart_strip) <= M * ofReal(2*epsilon)^2,
    M = C * ofReal(beta) * volume(thin_closed_ball(0,(L+1)*rho)).

The common Haar upper bound beta removes dependence on the chosen coordinate equivalence. `chartStripMassConstant_ne_top` proves that M is finite. This improves the v28 full-chart mass bound to a quadratic bound for the strip itself.

`extension_enorm_le_support_mass` proves the L2-to-L-infinity estimate using only the square root of the essential support mass. Combining it with the quadratic strip mass gives the actual chart extension bound

    enorm(E_chart g(x)) <= ofReal(2*epsilon) * sqrt(M) * enorm(g).

The statement is pointwise in x and uniform in the frame. Zero-width strips and empty supports are included by the measure argument; no division by an input norm is used.

### Original surface inputs and bounded physical scales

`pointwise_atlas_assembly` uses the actual disjoint atlas inputs, their inherited essential support, norm budgets and exact extension reconstruction. Its explicit chart-count factor is bounded by the common count from v28. `uniform_surface_strip_extension_bound` consequently chooses a finite nonnegative constant A before the selected index, admissible frame, epsilon, input and physical point, and proves

    enorm(E_i g(x)) <= A * ofReal(2*epsilon) * enorm(g).

The admissibility hypothesis is explicit: the pair frame is orthonormal and its frame-frequency pair lies in the compact admissible image for every point of the selected original support. Empty supports are permitted. There is no unproved claim that every plane is admissible.

`extension_product_bound_selected` and `extension_product_quasinorm_selected` combine the selected-factor gain with ordinary L2-to-L-infinity bounds for the other factors. They never divide by zero norms and work at every p>0. `uniform_surface_strip_product_bound` absorbs the finitely many selected-factor mass constants into one finite C and gives

    eLpNorm'(product E_j g_j,p,sigma)
      <= C * ofReal(2*epsilon) * sigma(univ)^(1/p) * product enorm(g_j).

Thus `uniform_bounded_radius_strip_product` gives a common constant for all ball centers and all radii R <= R0, with R0 fixed in advance. The constant may depend on R0 and p. `geometric_bounded_radius_strip_product` verifies the admissible-image hypothesis from the article's curvature-scaled plane-gap hypothesis along every tuple obtained by varying the selected support point of a supported reference tuple.

This is an unconditional bounded-scale analytic estimate under its stated geometric/admissibility assumptions. It is not Corollary 4.3: on large balls the spatial-volume factor has the trivial scale growth corresponding to R^(n/p), rather than the required arbitrarily small power loss. Choosing R0 to equal the eventual radius would make the constant radius-dependent and would not fix this gap.

### Actual L2 fiber inputs

`fiberAmplitude` is the density-multiplied coordinate input on a thin fiber. `fiber_memLp_ae` proves that it is in L2 for almost every normal coordinate u. `fiberInput` turns these into actual elements of the thin-coordinate L2 space, setting exceptional fibers to zero. `fiberInput_coe_ae` proves the expected almost-everywhere equality of representatives. No arbitrary replacement on a positive-measure family of fibers is made.

Every fiber outside the translated normal strip is exactly zero. `fiberInput_parameter_support` and its normalized counterpart retain the actual slice of the compact parameter ball as essential support, so the smooth chart bounds apply on the input support; an enclosing thin ball alone would not be enough. `fiberInput_thin_support` gives essential support in the same fixed thin ball for every fiber, including exceptional fibers. The actual L2 inputs have the budgets

    h * integral_u enorm(fiberInput(u))^2 <= C * enorm(g)^2,
    sqrt(h) * integral_u enorm(fiberInput(u))
      <= ofReal(2*epsilon) * sqrt(C) * enorm(g),

where h is the exact positive Haar factor. The original chart input norm appears on the right; the density is already absorbed into each fiber amplitude.

`extension_fiberInput` proves the exact identity

    E_chart g(x) = h * integral_u E_(actual fiber parametrization)(fiberInput(u))(x).

`fiber_extension_integrable` proves that this is an integrable complex-valued normal-parameter function for every physical point. It follows from full-coordinate integrability, exact linear-coordinate transport, Fubini and the almost-everywhere fiber representative identities. This is stronger than a merely formal integral expression. It does not claim a joint measurable Lp-valued selection or an intrinsic thin-fiber Hausdorff density formula.

### Haar-normalized actual inputs

`normalizedFiberInput` multiplies each actual L2 fiber input by sqrt(h). Its integral squared norm is at most C times the original squared norm, and its integral norm is at most ofReal(2*epsilon)*sqrt(C)*enorm(g). The exact extension reconstruction then has only sqrt(h) outside the normal integral. Normalization preserves the actual sliced parameter support, the fixed thin-ball support, and vanishing outside the normal strip. The normalized fiber extensions remain integrable in the normal variable at each physical point. These statements use actual L2 elements, not merely scalar fiber energies. The common upper Haar bound controls the remaining square-root factor uniformly.

### Remaining analytic boundary

The bounded-scale starting estimate and actual L2 fiber preparation are now checked. The remaining sharp large-scale localized estimate still requires External input 1, including the uniform perturbative Kakeya and wave-packet recursion argument of Remark 4.2. The new fiber norm budget cannot be inserted into an unjustified continuous quasi-Banach Minkowski inequality. A uniform bound for the actual localized ensemble, with the correct radius/loss dependence, must still be proved and supplied to the conditional assembly theorem from v28.

Corollary 4.3 and Theorem 1.1 remain open. Previously recorded external, recurrence/dimension-descent, algebraic and epsilon-removal obligations remain. No global continuous normal-frame choice, intrinsic thin-fiber Hausdorff/Gram-Jacobian identity, smooth frequency partition, or joint measurable Lp-valued family is introduced.

### Verification

`continuation-audit-run-v29.txt` records the fresh audit of 367 retained results. `new-audit-run-v29.txt` records 45 new results compiled in dependency order. `continuation-audit-final-v29.txt` checks all 412 inventories, source hashes, compiler outputs and axiom dependencies. `build-v29.txt` records the default build. The 843-result main axiom report is retained after byte comparison with v28, not described as a fresh main audit.


## Revision 0.30: distance support, actual fiber geometry and coarse analytic bounds

This final section is authoritative for the current revision; earlier sections are historical. **43 new results in twenty files** give **843 main + 455 separate = 1298 distinct checked results**. All 152 main modules and 144 prior continuation files are byte-identical to v29. All 455 continuation results were freshly compiled and axiom-audited, and the default build passes.

| Stable ID | Checked scope | Main entry points |
|---|---|---|
| N2-GEO-036 | Uniform ambient normal Lipschitz buffers and distance-ready measured atlases | `SmoothPatch.normal_lipschitz_buffer`, `uniform_normal_lipschitz_buffers`, `uniform_distance_ready_atlases` |
| N2-ANA-043 | Exact distance-supported local input interface and bounded-radius product estimate | `MeasuredTubularChart.zeroTarget_support_to_strip`, `MeasuredTubularChart.zeroTarget_supported_amplitude`, `bounded_distance_chart_product` |
| N2-ANA-044 | Actual normalized input support geometry and measurable norm budgets | `geometric_normalizedFiberInput_transversality`, `actual_normalized_fiber_finite_jet_stability`, `StripChartAmplitude.integrable_normalizedFiberInput_norm` |
| N2-ANA-045 | Uniform coarse Plancherel-Holder bounds on actual surface products | `uniform_Plancherel_strip_product`, `uniform_critical_strip_product_coarse`, `geometric_coarse_strip_bounds`, `uniform_buffered_chart_Plancherel` |
| N2-ANA-046 | Quantitative phase and frequency-parametrization perturbation | `imaginary_exp_difference_bound`, `extension_phase_difference_bound`, `extension_parametrization_difference` |

### Closing the support interface

The earlier `measured_surface_thickness_assembly.hlocal` asks for inputs essentially supported within distance D*delta of the fixed chart zeroTarget. The v29 fiber construction began with affine normal-strip support. These are different hypotheses; this revision supplies the reverse conversion explicitly.

`SmoothPatch.normal_lipschitz_buffer` uses a compact thickening contained in the smooth neighborhood. The normal derivative is bounded there. Each ball of the common radius about a supported center is convex and lies in that thickening, so the mean-value theorem supplies a common normal Lipschitz constant. `uniform_normal_lipschitz_buffers` takes a common radius and constant for the finite family. The constants precede the plane, center and input.

Frame coordinates contract the ambient norm. Consequently, if x and a zero-target witness y belong to the common Lipschitz region, then

    norm(Q N(x)) = norm(Q(N(x)-N(y))) <= M*dist(x,y).

`normal_strip_of_zero_target_distance` proves this with explicit witnesses, avoiding problematic empty-set distance conventions. No measurability or nonemptiness of the target is required for this implication. `distance_support_to_strip` includes almost-everywhere membership in the actual measured chart carrier. `zeroTarget_support_to_strip` specializes it to the exact target of the assembly theorem:

    distance <= D*delta  implies  normal residual <= M*D*delta.

`zeroTarget_supported_amplitude` constructs the same amplitude bundle as v29 with this converted thickness. Thus all its actual L2 fibers, energy identities and extension reconstruction apply to these distance-supported inputs. The conversion does not replace the original input by an unrelated function or change the surface measure.

`uniform_distance_ready_atlases` constructs finite measured atlases whose normal buffers, fixed zero targets and forward strip-to-distance localization all have common constants. It requires orthonormality and explicit frame-frequency admissibility at the selected fixed centers. The family can have empty supports.

### Bounded local estimates on the exact support class

`zeroTarget_extension_bound` gives a pointwise extension estimate with factor ofReal(2*M*D*delta). `extension_product_quasinorm_common_mass` combines it with the common actual chart mass bound for the other factors. `distance_supported_chart_product` retains the physical-measure cost sigma(univ)^(1/p), for every p>0.

`bounded_distance_chart_product` absorbs this cost into one finite nonnegative constant for all centers and all R<=R0, with R0 fixed in advance. Its constant is chosen before the frame, selected factor, centers, actual measured charts, thickness and L2 inputs. The hypotheses retain the common chart constants, the selected normal Lipschitz bound and zero-target localization in that buffer.

This supplies a bounded-scale version of the exact `hlocal` input inequality. It does not supply a constant with the sharp large-radius dependence needed by the full assembly argument. The radius bound R0 must not be allowed to depend on the eventual radius while claiming a uniform constant.

### Geometry on actual normalized L2 input support

`normalizedFiberInput_regularity` transfers all-order smoothness, the bound B(m)*(L+1)^m, and the inverse derivative bound (L+1)*B(1)*L to almost every nonzero fiber-input frequency. `normalizedFiberInput_surface_support` retains membership in the actual carrier, the original extended surface, the common physical buffer and the exact affine normal-coordinate value.

`geometric_normalizedFiberInput_transversality` combines these actual support conditions with the previously proved geometric normal-space estimate. There are common positive eta and a before all frames, chart maps, inputs and fiber levels. For each fiber, at almost every nonzero input frequency, its actual thin-fiber normal space has an orthonormal basis of dimension three whose Gram determinant with the other surface normals is at least a. Other frequencies range over their actual chart carriers. The curvature-scaled frame-gap assumption at the supported center tuple and the physical buffer condition remain explicit. No measurably varying choice of normal basis is claimed.

`normalizedFiberInput_normal_support` and `normalizedFiberInput_residual_ae` account for both nonzero L2 classes and their possibly exceptional representatives. Under the compact-to-smooth parameter margin, `normalizedFiberInput_reference_inside` puts the zero-fiber reference strictly inside the smooth chart. `normalizedFiberInput_reference_jets` gives the error

    B(m+1)*(L+1)^(m+1)*epsilon

for the m-th thin-fiber jet on actual input support. `actual_normalized_fiber_finite_jet_stability` chooses one positive strip threshold before all charts and inputs so that every jet through a specified finite order is within a prescribed positive tolerance of the zero fiber. This is quantitative geometric preparation, not an analytic stability theorem.

### Measurability and integrability of the norm budgets

`measurable_fiber_energy` uses the actual jointly measurable coordinate amplitude and Tonelli. Its almost-everywhere identification with the square of the actual L2 fiber norm yields `aemeasurable_fiberInput_enorm`. Haar normalization preserves this property. The v29 energy and linear thickness budgets then prove that both the real norm function and its square are Bochner-integrable over the normal parameter.

These are scalar measurability and integrability statements. They do not assert that the L2-valued family itself is jointly or strongly measurable, and they do not justify continuous Minkowski when the target exponent is below one.

### Stronger coarse large-scale estimates

The previous pointwise argument paid the full physical-volume cost at the final exponent. `selected_product_holder_integral` instead puts one factor in L-infinity and the remaining k-1 factors in L2, using integral Holder on the erased finite index set. This remains valid when q0=2/(k-1)<1.

`HasBallEnergyBound.lintegral` converts the proved real local Plancherel bound into the lower-integral form used by Holder, retaining the original L2 norms. It does not assume a new Plancherel estimate. `uniform_Plancherel_strip_product` combines the selected original-surface strip bound with these unlocalized L2 bounds:

    norm(product E_j g_j, q0, B(x0,R))
      <= C * ofReal(2*epsilon) * ofReal(R)^((k-1)/2) * product enorm(g_j).

Here k>1, R>=0, the frame is orthonormal, and frame-frequency admissibility holds throughout the selected support. C depends on the fixed surfaces and the admissibility parameter, not the selected index, frame, epsilon, input, center or radius.

`uniform_Plancherel_product` proves the unlocalized estimate at 2/k with radius cost R^(k/2). Applying the already checked integral interpolation to the same original product gives `uniform_critical_strip_product_coarse`:

    norm(product E_j g_j, pc, B(x0,R))
      <= C * ofReal(2*epsilon)^theta * ofReal(R)^(1/pc) * product enorm(g_j),
    pc = 2*(k+1)/k^2,  theta = k/(k+1).

The input-norm product has exponent exactly one after interpolation, including zero norms. `geometric_coarse_strip_bounds` gives both estimates under GeometricHypotheses and the curvature-scaled nearby-plane condition along every supported tuple obtained by varying the selected point of a supported reference tuple.

`uniform_buffered_chart_Plancherel` separately proves a common L2 ball bound for every actual measured chart contained in a sufficiently small common surface buffer. It uses the already proved fixed-patch Plancherel theorem on a larger compact surface patch and then restricts the measure. Uniformity is derived from that fixed larger patch, not inferred from a family of unrelated constants.

### Quantitative phase and extension perturbation

`imaginary_exp_difference_bound` proves a global two-Lipschitz bound for real-phase complex exponentials. `extension_phase_difference_bound` consequently bounds phase variation by twice the physical-point norm times the frequency displacement.

`extension_parametrization_difference` compares two measurable frequency parametrizations on the same actual L2 input and finite frequency measure. If their distance is at most a on the input's essential support, their extension difference is at most

    ofReal(2*norm(x)*a) * enorm(g) * measure(univ)^(1/2).

The zero-input case and almost-everywhere support are included. This is a pointwise quantitative perturbation lemma. For actual normalized fibers, `normalizedFiberInput_reference_distance` bounds the displacement to the zero fiber by B(1)*(L+1)*epsilon on essential support, and `normalizedFiberInput_phase_difference` bounds the corresponding phase error by 2*norm(x) times that displacement. Integrating the generic finite-measure perturbation estimate over a full fiber family still requires the appropriate finite-domain restriction and measurable parametrizations; no sharp localized restriction stability follows from these estimates.

### Remaining boundary and next work

The new radius powers are positive and fixed. Neither R^((k-1)/2) at q0 nor R^(1/pc) at pc can be substituted for R^eta for arbitrary eta>0. Corollary 4.3 and Theorem 1.1 remain open.

The next analytic obligation is a uniform localized restriction recursion with the sharp loss, using the actual supported inputs, common derivative/normal-space bounds and bounded-scale estimates now available. Uniform perturbative Kakeya stability and the relevant wave-packet recursion must still be proved. No conclusion follows merely from compactness or finite-jet closeness. The remaining external, dimension-descent/recurrence, algebraic and epsilon-removal obligations recorded earlier also remain.

### Verification

`continuation-audit-run-v30.txt` records the fresh compilation and axiom audit of 412 retained results. `new-audit-run-v30.txt` records 43 new results compiled in dependency order. `continuation-audit-final-v30.txt` checks all 455 inventories, source hashes and axiom reports. `build-v30.txt` records the default build. The 843-result main axiom report is retained after byte comparison with v29, not presented as a fresh main audit. Only the standard Lean axioms occur; no admitted proofs or custom axioms are introduced.


## Revision 0.31: one actual zero-fiber input and quantitative replacement

This final section is authoritative for the current revision; earlier sections are historical. **38 new results in fifteen files** give **843 main + 493 separate = 1336 distinct checked results**. All 152 main modules and 164 earlier continuation sources are byte-identical to v30. All main axiom dependencies and all continuation proofs were freshly checked. The default build passes.

| Stable ID | Checked scope | Main entry points |
|---|---|---|
| N2-ANA-047 | Finite-support frequency perturbation and actual fiber integral comparison | `supported_extension_parametrization_difference`, `StripChartAmplitude.normalizedFiberInput_extension_difference` |
| N2-ANA-048 | Integrable zero-reference superposition and integrated error | `StripChartAmplitude.reference_fiber_extension_integrable`, `StripChartAmplitude.extension_zero_reference_error` |
| N2-ANA-049 | One actual zero-fiber L2 input, exact superposition identity, support and norm budget | `StripChartAmplitude.referenceInput_energy`, `StripChartAmplitude.extension_referenceInput`, `StripChartAmplitude.zeroFiberInput_enorm`, `StripChartAmplitude.zeroFiberInput_support` |
| N2-ANA-050 | Common perturbation coefficient and arbitrary physical centers | `referenceErrorCoefficient_ne_top`, `MeasuredTubularChart.translated_zero_reference_approximation` |
| N2-ANA-051 | Actual product replacement at the localized exponent | `replacement_product_error`, `translated_chart_product_approximation` |

### Finite support and measurable chart representatives

The v30 phase comparison applied pointwise on actual fiber support. Its generic integrated estimate required finite ambient frequency measure and globally measurable frequency maps. Neither property was automatically available for the original full thin-coordinate volume and arbitrary chart extension.

`supported_extension_parametrization_difference` restricts the same actual L2 input to a measurable finite-mass support set, uses the finite-measure estimate, and restores the exact original extension and norm. `measurable_param_representative` constructs a globally measurable map agreeing pointwise with the chart throughout its smooth closed parameter ball. Both the actual fiber and its zero reference lie in that ball on essential input support. `extension_congr_frequency_support` justifies replacing those maps only where the input is nonzero.

The resulting `normalizedFiberInput_extension_difference` bounds the actual fiber difference by

    2 * norm(x) * B(1) * (L+1) * epsilon * sqrt(V) * norm(normalizedFiberInput(u)),

where V is the volume of the common thin-coordinate ball. Empty supports, exceptional zero fibers and L2 representative null sets are included.

### A genuine outer integral and one actual L2 input

`reference_fiber_extension_integrable` proves integrability of the complex-valued zero-fiber superposition. It uses the globally measurable scalar amplitude and its full-coordinate integrability, followed by Fubini. No joint measurable choice of L2-valued representatives is postulated.

`normal_supported_integral_bound` proves scalar Cauchy-Schwarz on the two-dimensional normal ball. `normal_marginal_energy` combines this with Tonelli. The normal space uses the max norm, so its ball area is exactly ofReal(2*epsilon)^2.

`normalizedAmplitude` is the joint scalar representative of the normalized actual fibers. Its energy agrees almost everywhere with the already checked fiber energy. Integrating this amplitude in the normal variable defines `referenceAmplitude`; its energy is at most

    ofReal(2*epsilon)^2 * C * norm(original_input)^2.

This proves `referenceAmplitude_memLp` and constructs the actual equivalence class `referenceInput`. Scalar Fubini proves that its extension is exactly the earlier zero-fiber superposition. Its essential support remains in the fixed thin-coordinate ball and in the smooth zero-reference parameter domain. `zeroFiberInput_geometry` also proves membership in the original extended surface, vanishing projected normal, and all common thin-chart derivative and inverse-differential bounds. `zeroFiberInput_extension_continuous` proves continuity of the actual extension using its finite support and a measurable chart representative. Multiplying by the remaining square-root Haar factor defines `zeroFiberInput`.

### Quantitative approximation and quantifier order

Write h for the Haar coordinate factor, with h <= beta, and let

    V = volume(closedBall(0, (L+1)*rho)),
    D = sqrt(ofReal(beta)) * ofReal(2*B(1)*(L+1)) * sqrt(V) * 2 * sqrt(C).

`referenceErrorCoefficient` defines D with extended nonnegative factors and proves it finite. The new input has norm at most sqrt(ofReal(beta))*ofReal(2*epsilon)*sqrt(C)*norm(g). The approximation error is at most

    D * ofReal(norm(x)) * ofReal(epsilon)^2 * norm(g).

`zeroFiberInput_relative_error` makes the useful perturbative regime explicit: if norm(x)*epsilon <= theta, the error is at most D*ofReal(theta)*ofReal(epsilon)*norm(g). This condition cannot be omitted at large radii.

The assumptions retain rho <= r, nonnegative derivative bounds and the strict reference margin (L+1)*epsilon < r-rho. No regularity of the chart outside its smooth domain is assumed.

`modulateL2` is an actual L2 modulation preserving the norm and frequency support, with the exact spatial-translation identity. `translated_zero_reference_approximation` applies the construction to this modulated original input. For every physical center x0, it produces one input f, before choosing x or R, such that

    E_chart(g)(x) = E_zero(f)(x-x0) + error(x),
    enorm(error(x)) <= D * ofReal(dist(x,x0)) * ofReal(epsilon)^2 * enorm(g).

The coefficient is independent of center, frame and input whenever the stated chart bounds are common. The constructed f is allowed to depend on the original input and physical center. Its support and norm bounds hold for that same f.

### Product error, including the quasi-Banach range

`bounded_factor_product_holder` combines one essentially bounded error with a nonempty finite family of genuine L2 energy integrals. `replacement_product_error` rewrites the difference between the original product and the product with one selected factor replaced. At q0=2/(k-1), its quasi-norm is bounded by the uniform selected-factor error times the product of the other factors' ball L2 norms.

`translated_chart_product_approximation` instantiates this on the actual measured chart inputs. The selected zero-fiber input is chosen before R. On every ball B(x0,R), the error has the bound

    D * ofReal(R) * ofReal(epsilon)^2 * norm(g_selected)
      * product(other actual ball L2 norms).

No continuous Minkowski inequality is used at q0<1. The other factors are unchanged, and their integrals are the actual extension energies, not assumed surrogate quantities.

### Remaining analytic boundary

The approximation is perturbative and retains a fixed radius cost. With common Plancherel bounds for the other k-1 factors, the displayed error has coarse radius power (k+1)/2 and thickness squared. It is not a substitute for the requested linear-thickness estimate with arbitrary R^eta loss. Even a sharp estimate on the exact zero fiber would not by itself remove this error at the scales required in the article.

The paper's External input 1, Remark 4.2 and Corollary 4.3 still require a uniform localized restriction recursion, with valid perturbative Kakeya neighborhoods, common wave-packet bounds and the correct scale dependence. The current work supplies actual supported input data and a quantitative comparison; it does not prove that recursion. Intrinsic thin-surface Hausdorff-density conversion, where needed for a particular formulation of the external theorem, is not asserted by this coordinate-Lebesgue construction. The previously recorded descent, algebraic and epsilon-removal obligations also remain.

### Verification

`main-audit-run-v31.txt` records a fresh standard-axiom audit of all 843 main results. `continuation-audit-run-v31.txt` records fresh compilation and axiom checks for 455 retained results. `new-audit-run-v31.txt` records the 38 new results compiled in dependency order. `continuation-audit-final-v31.txt` validates all 493 continuation declarations, source hashes and axiom reports. `build-v31.txt` records the incremental default build. Counts exclude structures and definitions and contain no duplicated declarations.


## Revision 0.32: three-block inequalities and bounded-scale perturbed tubes

This final section is authoritative for the current revision; earlier sections are historical. **40 new results in 22 files** give **843 main + 533 separate = 1376 distinct checked results**. All 152 main modules and 179 earlier continuation sources are byte-identical to v31. Main axiom dependencies and all continuation proofs were freshly checked. The default build passes.

| Stable ID | Checked scope | Main entry points |
|---|---|---|
| N2-ANA-052 | Three-block Loomis–Whitney, actual L2 product bounds and integrability | `three_block_loomis_whitney`, `three_block_L2_product`, `linear_three_block_L2_integrable` |
| N2-ANA-053 | Countable weighted complementary cylinders; exact and uniform Haar transport | `three_block_weighted_cylinders`, `linear_weighted_cylinders`, `uniform_linear_weighted_cylinders` |
| N2-ANA-054 | Exact fifth-power width scaling and explicit perturbation radius cost | `block311_ball_mass`, `perturbed_311_cylinders`, `small_aperture_311_cylinders` |
| N2-ANA-055 | A common constant on arbitrary physical balls, including metric fiber tubes | `uniform_centered_small_aperture_311_cylinders`, `uniform_centered_small_aperture_311_metric_tubes` |
| N2-GEO-037 | Projection perturbation, center correction, distance attainment and measurability | `centered_perturbed_projection_cylinder_subset`, `affineFiberTube_eq_infDist`, `measurableSet_affineFiberTube` |

### The analytic core

For arbitrary sigma-finite measure blocks X, Y, Z and nonnegative measurable functions f(y,z), g(x,z), h(x,y), `three_block_loomis_whitney` proves

    integral_yz integral_x sqrt(f(y,z)*g(x,z)*h(x,y))
      <= sqrt(integral f)*sqrt(integral g)*sqrt(integral h).

The actual Lean statement assumes `SFinite`, a slightly more general condition than sigma-finiteness. The proof uses Cauchy–Schwarz in x, then Cauchy–Schwarz in (y,z), followed by Tonelli and factorization of a separated product. All integrals are nonnegative integrals, so infinite values and zero factors are handled by the extended-nonnegative arithmetic. No prior Brascamp–Lieb inequality is assumed.

Applying this to squared magnitudes gives the L2-to-L1 bound for actual `Lp` equivalence classes, not hypothetical energy variables. The resulting complex product is proved integrable over the full product measure. Its transported version is also integrable in physical coordinates. These are physical-space product estimates; this revision does not construct a Fourier transform on arbitrary L2 frequency data.

### Countable weighted cylinders and coordinates

For a countable family of measurable cross-sections U(t) with weights u(t), `tubeDensity_integral` proves the exact identity

    integral tubeDensity(U,u) = sum_t u(t)*measure(U(t)).

Disjointness is not required. A common cross-sectional volume bound then yields the weighted cylinder inequality. The families are invariant along their respective complementary blocks.

For an actual continuous linear equivalence

    e : Ambient n ≃L[ℝ] (Ambient b × Ambient c) × Ambient a,

the physical integral acquires exactly `coordinateMeasureFactor e volume ((volume.prod volume).prod volume)`. Both this factor and the normalization of the product Haar measure are retained. The existing two-sided coordinate bounds imply a common positive finite upper bound when the operator norms of e and its inverse are at most M. The uniform theorem chooses the constant before all functions, sets and weights.

### Perturbed projections and spatial centers

For projections P and Q with operator-norm difference at most delta, the elementary geometric estimate is

    B(0,R) intersect {x : norm(Px-z) <= w}
      subset {x : norm(Qx-z) <= w+delta*R}.

Each tube can have its own P and center z. On a ball centered at x0, the correct reference center is

    z + (Q-P)(x0).

`centered_perturbed_projection_cylinder_subset` proves this correction explicitly. Translation invariance of cross-sectional Haar measure removes the reference-center dependence from the volume bound. `localized_cylinder_comparison` transports these containments through countable weighted densities and the restricted physical integral. Thus the bound is uniform in x0 without any hidden dependence on its norm.

### The first localized case: n=5, k=3

The article's localized normal dimensions are 3,1,1 in this case. The complementary cross-sections have dimensions 2,4,4. Their product-ball volumes scale as r^2, r^4, r^4, respectively, so the product of their square roots scales as r^5. `block311VolumeConstant` records the positive finite product of the three unit-volume square roots; its finiteness and positivity are proved.

Let D_i be the weighted densities for the three families, and let U_i denote their total weights. The perturbed-cylinder theorem gives

    integral_B(x0,R) sqrt(D_1*D_2*D_3)
      <= HaarFactor * VolumeConstant * (w+delta*R)^5
         * sqrt(U_1)*sqrt(U_2)*sqrt(U_3).

If delta*R <= w, the fifth-power factor is at most 32*w^5. Under the common conditioning bound M, the final theorem has the quantifier order

    for every M >= 0, there exists K > 0, K finite,
    for every conditioned e, countable families, centers, weights,
    x0, R >= 0, w >= 0, delta >= 0 with delta*R <= w,
    integral_B(x0,R) sqrt(D_1*D_2*D_3)
      <= K*w^5*sqrt(U_1)*sqrt(U_2)*sqrt(U_3).

The constant K includes the fixed factor 32 and the volume normalization. This is a genuine uniform bounded-scale estimate. It is not uniform for a fixed nonzero delta as R/w tends to infinity.

### Genuine metric neighborhoods of affine fibers

`affineFiberTube P z w` consists of points x for which there is a point y with P(y)=z and dist(x,y)<=w. In a proper normed space, if the fiber is nonempty, the distance to the closed affine fiber is attained. `affineFiberTube_eq_infDist` therefore identifies this set with the usual closed metric neighborhood defined by infimum distance. The nonempty-fiber hypothesis matters because real-valued `infDist` has a special convention on the empty set.

Every such tube is measurable, including the empty-fiber case. If norm(P)<=L with L>=0, it lies in the projection cylinder of width L*w. Applying the uniform arbitrary-center comparison gives

    integral_B(x0,R) sqrt(D_1*D_2*D_3)
      <= K*(L*w)^5*sqrt(U_1)*sqrt(U_2)*sqrt(U_3),

under delta*R<=L*w and the stated projection-norm and conditioning assumptions. The constant K is chosen before L as well. No surjectivity, nonemptiness or dimension of the individual perturbed fibers is silently assumed.

### Remaining boundary

This revision proves the three-block flat analytic model and a controlled small-aperture perturbation. The article's theorem concerns all n>=5, hence k=n-2 blocks; the arbitrary-k analogue is not proved here. Nor is the conditioned common splitting yet constructed from the actual geometric normal-space data for this estimate.

`UniformFixedAperture311Kakeya` now states the next model obligation as an explicit Lean proposition. For every loss eta>0 it asks for a positive finite K and a positive aperture delta, both chosen before all families, centers, radii and widths, with bound K*R^eta*w^(5-eta). It is a definition of a proposition, not an axiom or a proved theorem, and is excluded from the result count.

Most importantly, the aperture delta in the comparison must shrink like width/R. The fixed directional neighborhoods required in Remark 4.2 need an induction-on-scales perturbative Kakeya theorem, not this one-step containment argument. `fixed_aperture_inflation_not_small_loss` verifies the obstruction for the coarse comparison factor: for every delta>0, eta<5 and C, some R>=1 satisfies C*R^eta < (1+delta*R)^5. It does not assert failure of the actual Kakeya inequality.

The new mixed-dimensional cylinders are relevant to the localized ensemble of External input 1; they do not prove External input 2, whose families are all line tubes. Actual chart wave-packet stability, the uniform localized restriction recursion and its arbitrary-small-loss conclusion remain open.

The v31 zero-fiber input and its quadratic-thickness perturbation error are unchanged. The new flat estimate does not remove that error's radius cost or establish Corollary 4.3. Intrinsic thin-surface density conversion where required, the previously recorded recurrence/descent and algebraic inputs, epsilon removal and Theorem 1.1 remain unproved. No new axiom is introduced.

### Concrete next proof decomposition

For the arbitrary-k flat inequality, use induction on the number of blocks rather than repeating the three-block proof. Integrating the last block first, Holder with k-1 factors replaces each of the first k-1 functions by its integral in that block. On the remaining product space, Holder with conjugate exponents k-1 and (k-1)/(k-2) separates the last function from the reduced product. The induction hypothesis then gives the desired exponent 1/(k-1). The base case of two blocks is Tonelli factorization. This is a proposed proof decomposition, not a checked theorem. The Lean work still includes dependent product measures, complement-index projections, Fubini equivalences and the endpoint/zero cases.

For the fixed-aperture target, a proof must control the loss across scales rather than replace each tube by one enlarged reference cylinder over the entire large ball. The current K is uniform under conditioning, and the small-aperture result supplies a bounded-scale starting estimate. The missing induction must choose a positive directional neighborhood once, before R/w, and account quantitatively for its iteration. The displayed coarse-factor obstruction prevents substituting the one-step comparison for that induction.

### Verification

`main-audit-run-v32.txt` records a fresh standard-axiom audit of all 843 main results. `continuation-audit-run-v32.txt` records fresh compilation and axiom checks for 493 retained results. `new-audit-run-v32.txt` records the 40 new results compiled in dependency order. `continuation-audit-final-v32.txt` validates all 533 continuation declarations, source hashes and axiom reports. `build-v32.txt` records the incremental default build. Counts exclude structures and definitions and contain no duplicate declarations.


## Revision 0.33: four-block analysis and actual normal coordinates

This final section is authoritative for the current revision; earlier sections are historical. **41 new results in 23 files** give **843 main + 574 separate = 1417 distinct checked results**. All 152 main modules and 201 earlier continuation sources are byte-identical to v32. Main axiom dependencies and all continuation proofs were freshly checked. The default build passes.

| Stable ID | Checked scope | Main entry points |
|---|---|---|
| N2-ANA-056 | Finite-factor Holder elimination and an explicit induction implication | `block_holder_lift`, `block_loomis_whitney_step` |
| N2-ANA-057 | Four-block Loomis–Whitney and actual L2-to-L^(2/3) product estimates | `four_block_loomis_whitney`, `four_block_L2_quasinorm`, `four_block_L2_memLp` |
| N2-ANA-058 | Countable weighted cylinders, local density comparison and coordinate transport | `four_block_weighted_cylinders`, `four_block_local_density_bound`, `linear_four_block_L2_quasinorm` |
| N2-ANA-059 | Dimension-six width scaling and bounded-scale metric tubes | `block3111_ball_mass`, `uniform_centered_small_aperture_3111_metric_tubes` |
| N2-GEO-038 | Uniform Gram coercivity and actual synthesis equivalences | `uniform_gram_synthesis_lower_bound`, `uniform_synthesis_equiv_of_gram` |
| N2-GEO-039 | Actual thin-normal coordinates, correct complementary kernel and bounded preimages | `uniform_thin_normal_synthesis_equiv`, `normalComplementProjection_ker`, `uniform_thin_normal_complement_projection` |
| N2-GEO-040 | Inverse-coordinate and frame-to-projection perturbation bounds | `coordinate_inverse_difference_norm_le`, `normalComplementProjection_frame_stability`, `uniform_normalComplementProjection_neighborhood` |

### A reusable block-elimination step

For m>=2, define p=1/m, r=1/(m-1) and q=(m-1)/m. Let f0 depend only on x and let f_i depend on (x,y), for i in Fin m. The checked `block_holder_lift` states

    integral_x integral_y (f0(x)*product_i f_i(x,y))^p
      <= (integral_x f0)^p
         * (integral_x product_i (integral_y f_i(x,y))^r)^q.

Holder in y uses m equal exponents. Holder in x then uses the conjugate weights p and q; the identity r*q=p restores the correct powers. The functions are measurable and nonnegative, and the integrated-out measure is SFinite. No finite-total-mass assumption is used.

`block_loomis_whitney_step` adds an explicit hypothesis bounding the remaining integral by product_i A_i^r. It then concludes the next block inequality with product_i A_i^p. **This is an induction implication, not a proof of the complete arbitrary-k product-measure theorem.** Dependent coordinate deletion and Fubini identifications are still needed to run the induction for all k.

For four blocks the remaining inequality is the already checked three-block theorem. `four_block_loomis_whitney` discharges the reduced hypothesis fully, with constant one and exponent 1/3. It allows arbitrary SFinite block measures X,Y,Z,W and arbitrary block dimensions. In the chosen ordering, f0 depends on X,Y,Z; f1 on Y,Z,W; f2 on X,Z,W; and f3 on X,Y,W.

### Actual quasi-Banach product estimates

`fourBlockProduct` is the product of four actual L2 representatives on their complementary three-block spaces. Applying four-block Loomis–Whitney to their squared magnitudes gives

    integral |fourBlockProduct|^(2/3)
      <= (norm(f0)*norm(f1)*norm(f2)*norm(f3))^(2/3).

The 3/2 power yields the L^(2/3) quasi-norm bound with constant one. Measurability and `MemLp` membership at exponent 2/3 are proved separately. These statements concern the actual product on the full four-block measure space, including infinite-volume blocks. No Banach-space triangle inequality, continuous Minkowski argument or assumed Fourier L2 extension operator is used.

For a linear coordinate equivalence e, the nonnegative integral acquires exactly the Haar scaling factor h. Consequently the physical quasi-norm has coefficient h^(3/2), not h. Both the physical power-integral estimate and actual physical `MemLp` membership are checked. The uniform linear-density theorem chooses a finite positive coefficient before the splitting and all four input densities, under common bounds for e and its inverse.

### Weighted cylinders and the six-dimensional model

Countable measurable cross-sectional families with nonnegative weights satisfy the four-block inequality through the exact weighted-mass identity proved in v32. Overlaps are allowed. `four_block_local_density_bound` transfers local pointwise domination by these complementary densities to a physical integral, retaining their actual mass budgets.

For individually perturbed projections, `centered_perturbed_cylinder_density_bound` makes the center correction explicit on any ball B(x0,R). The reference cross-section center is z+(Q-P)(x0), and its width is w+delta*R when norm(P-Q)<=delta. Applying the local density theorem gives a four-family estimate without losing uniformity in x0.

In dimension six with normal blocks 3,1,1,1, the complementary dimensions are 5,3,5,5. Their total 18 is divided by the density exponent denominator 3, so the width factor is exactly r^6. `block3111VolumeConstant` is the positive finite product-ball normalization, and `block3111_ball_mass` proves the exact scaling, including zero width and extended-nonnegative weights.

For weighted densities D_i and total weights U_i the estimate is

    integral_B(x0,R) (D0*D1*D2*D3)^(1/3)
      <= h * V * (w+delta*R)^6 * (U0*U1*U2*U3)^(1/3).

Under delta*R<=w, the sixth-power factor is at most 64*w^6. Bounded conditioning of e absorbs h*V*64 into one positive finite K chosen before all splittings, countable families, centers, weights, widths and radii.

The metric-tube version uses the previously checked affine-fiber neighborhoods. If the individual projection norms are at most L, the width cost is L*w and the aperture condition becomes delta*R<=L*w. The same K is chosen before L, and the final factor is (L*w)^6. Empty fibers remain allowed; their metric tubes are empty. As in v32, the individual fibers are not silently assumed surjective or of fixed dimension.

### From positive Gram bounds to uniform coordinates

This geometric part applies in every dimension, not only n=6. Let v be a finite frame with sup norm at most M and Gram determinant at least c>0. `uniform_gram_synthesis_lower_bound` chooses a>0 before v such that

    a*norm(x) <= norm(sum_i x_i*v_i)

for every coefficient vector x, where coefficients carry the finite Pi/max norm. The proof minimizes the synthesis norm over the compact set of bounded frames with Gram determinant >=c and unit coefficient vectors. Linear independence makes that norm positive. Homogeneity extends the bound from unit vectors to all vectors; zero coefficients are handled separately.

The elementary upper bound is card(I)*M*norm(x). When card(I)=n, the synthesis map is an actual continuous linear equivalence onto Ambient n. Its norm is at most card(I)*M and its inverse norm at most 1/a. A common positive B bounds both. The empty unit-sphere case and zero-dimensional spaces are included in the abstract result.

`uniform_thin_normal_synthesis_equiv` instantiates this with the normalized thin-normal frame already obtained from the article's geometry: the other k-1 unit normals, followed by an orthonormal basis of the selected three-dimensional normal space N. The raw normal/shape Gram bound, common shape bound, unit-frame bounds and membership of the three selected vectors in N are explicit hypotheses. The earlier normalized-Gram theorem supplies a common positive determinant bound. The coefficient index set is the disjoint sum of the other normals and Fin 3; its cardinality is checked to be k+2.

Thus B is chosen before the surfaces, frequency points, two-plane frame, normal space and its orthonormal basis. The resulting map is exactly the stated synthesis of the actual frame vectors, not an unspecified finite-dimensional isomorphism.

### The actual selected normal space and geometric stability

`normalComplementProjection` takes inverse synthesis coordinates and discards the selected normal block. Its operator norm is at most the inverse synthesis norm. `normal_synthesis_complement_iff` proves that all complementary coordinates vanish exactly when the physical vector belongs to N; `normalComplementProjection_ker` packages this as equality of submodules.

The reverse implication uses the orthonormal-basis expansion of the actual vector in N. Bounded preimages are obtained by assigning the desired complementary coefficients and setting the selected-normal coefficients to zero. The full synthesis bound controls their physical norm. `uniform_thin_normal_complement_projection` combines these facts into one uniform existence statement with the correct kernel, bounded projection norm and bounded preimages.

For two synthesis equivalences e and f, the exact identity

    e^{-1}-f^{-1} = e^{-1} (f-e) f^{-1}

is checked at the continuous-linear-map level. If both inverse norms are at most B, their difference is at most B^2*norm(e-f). Restricting to complementary coordinates cannot increase this norm. If the synthesis frames are u and v, their map difference is at most card(I)*norm(u-v). Hence

    norm(P_e-P_f) <= B^2*card(I)*norm(u-v).

Given a desired projection tolerance delta>0, one may choose

    epsilon = delta / (B^2*card(I)+1)

before both frames and equivalences. The theorem `uniform_normalComplementProjection_neighborhood` checks this quantifier order. It supplies a genuine uniform geometric neighborhood. It neither constructs a global continuous normal-frame choice nor proves an analytic Kakeya estimate on that neighborhood.

### Remaining boundary and next steps

The complete arbitrary-k Loomis–Whitney theorem remains open; the present work proves the finite-factor elimination and the fully instantiated four-block case. The next step is to implement dependent finite product spaces, coordinate-deletion maps and the Fubini identities needed to iterate `block_loomis_whitney_step`.

For the geometry-to-analysis connection, the actual synthesis coordinates use finite Pi coefficient spaces. They must still be grouped into the concrete Euclidean product blocks, with the fixed dimension-dependent norm and Haar conversions retained. The selected three-dimensional normal kernel is now identified, but simultaneous identification of every complementary block projection and its line-normal kernel in the concrete model is not yet complete. Frame-neighborhood arguments must use coherent local frame choices where continuity is needed.

A positive geometric neighborhood does not remove the analytic aperture restriction delta*R<=width. The fixed-aperture mixed-dimensional Kakeya theorem requires an induction across scales with aperture chosen before R/width. The v32 obstruction to absorbing one-step width inflation into arbitrary-small radius loss is unchanged. The new bounds do not establish External input 1, the uniform localized restriction recursion, Corollary 4.3 or Theorem 1.1, and they do not prove the all-line tube geometry of External input 2.

The actual zero-fiber construction and its radius-dependent perturbation error remain unchanged. The retained wave-packet stability, intrinsic thin-surface density conversion where required, recurrence/descent, algebraic and epsilon-removal obligations also remain open. No new axiom is introduced.

### Relation to Remark 4.2 of the article

The new geometric results support the paragraph on uniformly transverse linear data. They do not yet implement the finite-subcover argument for the cited perturbative analytic theorem.

| Step in Remark 4.2 | Current status after this revision |
|---|---|
| Common positive ambient normal-wedge bound | The earlier normalized Gram bound is retained and used as an explicit hypothesis/input. |
| Uniformly conditioned coordinates for the localized linear data | Actual synthesis maps and their inverse bounds are now proved, including the selected normal-space kernel. Grouping all blocks into the concrete analytic product model remains. |
| Common directional neighborhood | A common frame-to-projection tolerance is now proved. Applying it to varying charts still needs coherent local frames. |
| Common Kakeya constant on that neighborhood | Open at fixed aperture; the checked cylinder bounds require aperture times radius at most width. |
| Uniform wave packets and localized recursion | Open; neither the geometric tolerance nor the four-block product estimate supplies this step. |

This distinction follows the article's own separation between geometric compactness and stability of the analytic proof. In particular, the new neighborhood theorem is not recorded as a proof of the uniform estimate in Corollary 4.3.

### Verification

`main-audit-run-v33.txt` records a fresh standard-axiom audit of all 843 main results. `continuation-audit-run-v33.txt` records fresh compilation and axiom checks for 533 retained results. `new-audit-run-v33.txt` records the 41 new results compiled in dependency order. `continuation-audit-final-v33.txt` validates all 574 continuation declarations, source hashes and axiom reports. `build-v33.txt` records the incremental default build. Counts exclude structures and definitions and contain no duplicate declarations.
## Revision 0.34: general block inequalities and actual normal projections

This final section is authoritative; earlier revision sections are historical. This revision adds **61 results in 24 files**, giving **843 main + 635 continuation = 1478 distinct checked results**. All 152 main modules and all 224 earlier continuation sources are unchanged from v33. Theorem 1.1 remains unproved.

| Stable ID | Checked scope | Principal entry points |
|---|---|---|
| N2-GEO-041 | Simultaneous actual normal kernels and bounded preimages | `coordinateDeletion_ker`, `uniform_thin_normal_all_projections` |
| N2-GEO-042 | Euclidean block grouping and the actual six-dimensional configuration | `groupedLineProjection_ker`, `uniform_thin_normal_four_coordinates` |
| N2-GEO-043 | Simultaneous stability of all four concrete projections | `fourNormalCoordinates_frame_stability`, `uniform_fourNormalProjection_neighborhood` |
| N2-ANA-060 | Finite-product splitting, marginal mass and coordinate deletion | `finite_block_lintegral_split`, `finite_block_marginal_mass`, `finite_block_reduced_mass` |
| N2-ANA-061 | Arbitrary finite-block Loomis–Whitney, including different block spaces | `finite_block_loomis_whitney`, `dependent_block_loomis_whitney` |
| N2-ANA-062 | General L2-to-L^(2/(k-1)) product bounds and actual membership | `dependent_block_L2_power_integral`, `dependent_block_L2_quasinorm`, `dependent_block_L2_memLp` |
| N2-ANA-063 | General weighted cylinders and actual six-dimensional analytic applications | `dependent_block_weighted_cylinders`, `uniform_actual_normal_four_L2`, `uniform_actual_normal_four_metric_tubes` |
| N2-ANA-064 | Uniform physical transport in arbitrary Euclidean block dimensions | `linear_dependent_block_lintegral`, `uniform_linear_dependent_block_lintegral` |

### General block inequality: the induction is now discharged

Write k=n+2, with n>=0, and let X_i be nonempty measurable spaces carrying sigma-finite measures mu_i. Each f_i is a measurable nonnegative extended-real function on the product of all blocks except i. The checked theorem is

    integral_(product_i mu_i) (product_i f_i(x without coordinate i))^(1/(k-1))
      <= product_i (integral_(product_{j != i} mu_j) f_i)^(1/(k-1)).

The constant is one. The measures need not have finite total mass, and the block spaces need not have equal dimensions. Empty block spaces are not included in the dependent theorem: its statement uses `Inhabited (X i)`. All Euclidean block spaces relevant to the article meet this hypothesis. The measures are sigma-finite; the statement does not claim the more general SFinite class used by the previously checked special three- and four-block theorems.

`finite_block_lintegral_split` transports the finite dependent product measure exactly through `Fin.insertNth`. `finite_block_marginal_mass` swaps the two integrations and shows that the marginal preserves total mass. `finite_block_holder_elimination` applies the earlier Holder step to that actual finite product. These lemmas handle dependent coordinate spaces.

The recursive proof first uses a common carrier X, allowing different measures in its coordinates. Its base case is the exact two-block factorization. In the successor step, the first coordinate is integrated out. `removeNth_succ_cons` identifies each reduced factor with the appropriate coordinate deletion, and `finite_block_reduced_mass` identifies its complementary integral with the original one. The induction hypothesis now proves the reduced inequality rather than assuming it. The exponent identity restores 1/(k-1).

The final dependent-space theorem uses the disjoint union of the X_i as a common measurable carrier. Each X_i embeds measurably into that carrier, and its measure is pushed forward along that embedding. The pushforwards are sigma-finite. A measurable retraction onto X_i is the identity on its component and a chosen default elsewhere. Product measure preservation transports both the full integral and every complementary mass exactly. No comparison constant or dimension factor is introduced. The default values disappear on the embedded coordinates.

This closes the general flat block-inequality gap recorded in v33. It does not prove a perturbed fixed-aperture Kakeya theorem.

### Actual L2 inputs and countable weighted cylinders

For actual complex L2 equivalence classes f_i on their complementary product spaces, `dependentBlockProduct` is their product after coordinate deletion. Applying the block inequality to squared magnitudes proves

    integral |product_i f_i(x without i)|^(2/(k-1))
      <= (product_i norm(f_i))^(2/(k-1)).

The L^(2/(k-1)) quasi-norm is therefore at most the product of the L2 norms. Measurability and actual `MemLp` membership are checked, including the exponents below one. The proof uses nonnegative integration and monotonicity of real powers, not a quasi-Banach Minkowski inequality.

`dependent_block_weighted_cylinders` applies the same theorem to arbitrary countable families in each complementary block. With weights u_i,t and cross-sectional measures at most A_i, the right side is

    (product_i ((sum_t u_i,t) * A_i))^(1/(k-1)).

Overlaps are allowed. Extended-nonnegative weights and masses are allowed. There is no hidden disjointness or finite-total-weight assumption; infinite right sides are permitted by the statement.

### Uniform physical transport in arbitrary block dimensions

`linear_dependent_block_lintegral` transports the full dependent-block inequality through an arbitrary continuous linear equivalence from physical Euclidean space to the product of Euclidean blocks. It retains exactly the Haar scaling coefficient. `uniform_linear_dependent_block_lintegral` chooses a positive finite bound for that coefficient before all coordinate equivalences and input functions, assuming common forward and inverse operator-norm bounds. Thus the general physical measure-factor estimate is also proved. What remains in the general-k geometric application is assembling its particular actual normal blocks into these dependent Euclidean product coordinates with the simultaneous kernel identifications already available in scalar form.

### All actual normal kernels, using one synthesis map

For a synthesis equivalence e built from a full finite frame v, `coordinateDeletion e i` drops the ith coefficient of e^{-1}. Its kernel is exactly span{v_i}, its norm is at most norm(e^{-1}), and it has preimages bounded by norm(e) times the target norm. Both directions of the kernel equality are proved. These statements include the zero-dimensional complementary target.

`uniform_thin_normal_all_projections` applies these facts to the actual normalized thin-normal frame in every dimension k+2. One e simultaneously yields the selected three-dimensional normal-space kernel N and every other normal-line kernel. The same positive B controls e, e^{-1}, every projection and every preimage bound. B is chosen before the surfaces, frequency points, plane vectors, N and its orthonormal basis. The unit-normal, shape, membership and positive Gram assumptions remain explicit.

`groupNormalCoefficients` converts the selected scalar normal coefficients into an actual Euclidean normal block. The other scalar coordinates remain a finite Pi space. `groupedLineProjection_ker` identifies the corresponding line kernels after this conversion, and bounded preimages remain available. The regrouping has a fixed operator-norm cost independent of the geometric frame.

### Exact six-dimensional product coordinates

For k=4, `fourCoefficientGrouping` converts the coefficient space into exactly

    ((Ambient 1 x Ambient 1) x Ambient 3) x Ambient 1.

An explicit equivalence r orders the three other normals. In the notation of the existing four-block estimates:

| Projection | Actual kernel |
|---|---|
| `fourProjectionZero` | span of the normal indexed by r(2) |
| `fourProjectionOne` | the selected three-dimensional normal space N |
| `fourProjectionTwo` | span of the normal indexed by r(0) |
| `fourProjectionThree` | span of the normal indexed by r(1) |

All four equalities are checked simultaneously for the same coordinates. `uniform_thin_normal_four_coordinates` retains a common positive bound for the coordinate equivalence and its inverse, before the actual geometric data.

`uniform_actual_normal_four_L2` now instantiates the four-block physical L^(2/3) estimate on those actual kernels. Its positive finite coefficient is chosen before the geometric data and the four L2 inputs. The chosen coordinates precede the inputs. The coefficient includes the correct Haar scaling to the power 3/2; the input functions are physical cross-sectional L2 functions, not an assumed Fourier extension construction.

`uniform_actual_normal_four_metric_tubes` likewise instantiates the metric-fiber tube estimate on the actual configuration. A positive finite constant precedes the geometric data, countable families, weights, centers, radii, widths and projection-norm bound L. The estimate still requires

    delta * R <= L * w,

and has width factor (L*w)^6. It allows individually perturbed projections near the reference projections, arbitrary physical centers, and empty fibers. It does not assert that all perturbed fibers have the reference rank.

Thus the concrete geometry-to-flat-analysis identification gap is closed in dimension six. For general k, the block inequality and scalar normal kernels are proved, but their complete uniform physical-coordinate/measure assembly for the article's mixed-dimensional configuration has not yet been packaged into a corresponding general-k analytic theorem.

### Simultaneous projection stability

Coordinate deletion cannot increase the difference of inverse synthesis maps. After regrouping by the fixed map G, the concrete coordinate difference is at most

    norm(G) * B^2 * card(I) * norm(u-v)

when both inverse synthesis norms are at most B. Each of the four concrete projection differences is bounded by that coordinate difference. A common positive epsilon is chosen before both frames and maps to force all four differences below a prescribed delta>0.

This statement requires the frames to be close in the stated norm. It does not construct a global continuous orthonormal frame choice. Coherent local frames are still needed when applying it to varying geometric charts. A common geometric tolerance does not supply the fixed-aperture analytic Kakeya constant required in Remark 4.2.

### Remaining obligations

The general flat Loomis–Whitney inequality is no longer open for the nonempty sigma-finite block spaces used here. The six-dimensional actual normal-kernel identification and its bounded-scale analytic applications are also proved.

The remaining central analytic obligation is a mixed-dimensional perturbed estimate with a fixed aperture selected before R/width. The current tube theorem has a scale-dependent aperture and does not close that gap. Uniform wave-packet stability, the actual localized restriction recursion, and the retained intrinsic density/descent/algebraic/epsilon-removal obligations remain. Corollary 4.3, External input 1 and Theorem 1.1 are still unproved. The arbitrary-line tube geometry of External input 2 is not established by these complementary-block estimates.

### Concrete next implementation step

For the general-k actual geometric model, a useful next representation is the dependent block dimension `d j = if j = i then 3 else 1` on `Fin k`. Construct the fixed regrouping from the existing scalar coefficient index (the other normals disjoint-union Fin 3) into `forall j, Ambient (d j)`. The selected block receives its three basis coefficients; every other block receives its one scalar coefficient. Its inverse and operator bounds depend only on this fixed grouping. Then identify the deleted-block kernels using `normalComplementProjection_ker` and `coordinateDeletion_ker`, and apply `uniform_linear_dependent_block_lintegral`. This is a proposed assembly step, not a theorem claimed in this revision.

After that assembly, further flat inequalities alone will not supply the fixed-aperture result. The existing `UniformFixedAperture311Kakeya` remains a proposition, not a proved theorem. The next analytic proof must provide a multiscale estimate with its aperture chosen before the scale ratio, while retaining the actual weighted-family and norm budgets required by the localized restriction recursion.

### Candidate multiscale step for the fixed-aperture gap

A concrete next route is to partition the physical ball at side length comparable to R/A, with A fixed after the desired loss exponent and before R. For each family and cell, define the local weight as the sum of the weights of tubes meeting that cell. Apply the induction hypothesis to the local families on a ball containing each cell. The missing global budget is a bound for the sum over cells of the product of these local weights to the power 1/(k-1).

The new flat block theorem is intended to prove this budget: if a perturbed tube meets a cell, every point of that cell lies in a corresponding reference cylinder enlarged by the cell diameter, the tube width, and delta*R. Choosing delta of order 1/A makes the final error comparable to the cell width. For R/A at least the tube width, the flat cylinder estimate has a width factor of order (R/A)^(k+2). Dividing by the full cell volume should cancel that factor. This would give a recurrence constant independent of A, provided all partition, enlargement, overlap and coordinate constants are controlled uniformly.

To turn this route into a proof, formalize a finite disjoint cell cover with explicit full cell volumes and enclosing-ball radii; the tube-meeting-to-reference-cylinder implication on each entire cell; the countable weighted local-family identities; and the exact cancellation of the scale factor in the global cell budget. The scale reduction must include the cell-to-ball radius constant. Only after these lemmas are checked can A be chosen large enough for the desired power loss and the aperture chosen small enough relative to A. This is a proposed recurrence strategy, not a proved inequality or a claimed resolution of fixed-aperture Kakeya.

### Verification

All 843 main results were freshly axiom-audited. All 574 retained continuation results and all 61 new results were freshly compiled and axiom-audited, with no warnings or admissions. The default build passes. The final inventory check covers all 635 continuation results and rejects duplicate names, stale hashes and nonstandard axioms. Only `propext`, `Classical.choice` and `Quot.sound` are allowed. Continuation sources remain separate from the default 843-result main inventory.

## Revision 0.34: general block inequalities and actual normal projections

This final section is authoritative; earlier revision sections are historical. This revision adds **61 results in 24 files**, giving **843 main + 635 continuation = 1478 distinct checked results**. All 152 main modules and all 224 earlier continuation sources are unchanged from v33. Theorem 1.1 remains unproved.

| Stable ID | Checked scope | Principal entry points |
|---|---|---|
| N2-GEO-041 | Simultaneous actual normal kernels and bounded preimages | `coordinateDeletion_ker`, `uniform_thin_normal_all_projections` |
| N2-GEO-042 | Euclidean block grouping and the actual six-dimensional configuration | `groupedLineProjection_ker`, `uniform_thin_normal_four_coordinates` |
| N2-GEO-043 | Simultaneous stability of all four concrete projections | `fourNormalCoordinates_frame_stability`, `uniform_fourNormalProjection_neighborhood` |
| N2-ANA-060 | Finite-product splitting, marginal mass and coordinate deletion | `finite_block_lintegral_split`, `finite_block_marginal_mass`, `finite_block_reduced_mass` |
| N2-ANA-061 | Arbitrary finite-block Loomis–Whitney, including different block spaces | `finite_block_loomis_whitney`, `dependent_block_loomis_whitney` |
| N2-ANA-062 | General L2-to-L^(2/(k-1)) product bounds and actual membership | `dependent_block_L2_power_integral`, `dependent_block_L2_quasinorm`, `dependent_block_L2_memLp` |
| N2-ANA-063 | General weighted cylinders and actual six-dimensional analytic applications | `dependent_block_weighted_cylinders`, `uniform_actual_normal_four_L2`, `uniform_actual_normal_four_metric_tubes` |
| N2-ANA-064 | Uniform physical transport in arbitrary Euclidean block dimensions | `linear_dependent_block_lintegral`, `uniform_linear_dependent_block_lintegral` |

### General block inequality: the induction is now discharged

Write k=n+2, with n>=0, and let X_i be nonempty measurable spaces carrying sigma-finite measures mu_i. Each f_i is a measurable nonnegative extended-real function on the product of all blocks except i. The checked theorem is

    integral_(product_i mu_i) (product_i f_i(x without coordinate i))^(1/(k-1))
      <= product_i (integral_(product_{j != i} mu_j) f_i)^(1/(k-1)).

The constant is one. The measures need not have finite total mass, and the block spaces need not have equal dimensions. Empty block spaces are not included in the dependent theorem: its statement uses `Inhabited (X i)`. All Euclidean block spaces relevant to the article meet this hypothesis. The measures are sigma-finite; the statement does not claim the more general SFinite class used by the previously checked special three- and four-block theorems.

`finite_block_lintegral_split` transports the finite dependent product measure exactly through `Fin.insertNth`. `finite_block_marginal_mass` swaps the two integrations and shows that the marginal preserves total mass. `finite_block_holder_elimination` applies the earlier Holder step to that actual finite product. These lemmas handle dependent coordinate spaces.

The recursive proof first uses a common carrier X, allowing different measures in its coordinates. Its base case is the exact two-block factorization. In the successor step, the first coordinate is integrated out. `removeNth_succ_cons` identifies each reduced factor with the appropriate coordinate deletion, and `finite_block_reduced_mass` identifies its complementary integral with the original one. The induction hypothesis now proves the reduced inequality rather than assuming it. The exponent identity restores 1/(k-1).

The final dependent-space theorem uses the disjoint union of the X_i as a common measurable carrier. Each X_i embeds measurably into that carrier, and its measure is pushed forward along that embedding. The pushforwards are sigma-finite. A measurable retraction onto X_i is the identity on its component and a chosen default elsewhere. Product measure preservation transports both the full integral and every complementary mass exactly. No comparison constant or dimension factor is introduced. The default values disappear on the embedded coordinates.

This closes the general flat block-inequality gap recorded in v33. It does not prove a perturbed fixed-aperture Kakeya theorem.

### Actual L2 inputs and countable weighted cylinders

For actual complex L2 equivalence classes f_i on their complementary product spaces, `dependentBlockProduct` is their product after coordinate deletion. Applying the block inequality to squared magnitudes proves

    integral |product_i f_i(x without i)|^(2/(k-1))
      <= (product_i norm(f_i))^(2/(k-1)).

The L^(2/(k-1)) quasi-norm is therefore at most the product of the L2 norms. Measurability and actual `MemLp` membership are checked, including the exponents below one. The proof uses nonnegative integration and monotonicity of real powers, not a quasi-Banach Minkowski inequality.

`dependent_block_weighted_cylinders` applies the same theorem to arbitrary countable families in each complementary block. With weights u_i,t and cross-sectional measures at most A_i, the right side is

    (product_i ((sum_t u_i,t) * A_i))^(1/(k-1)).

Overlaps are allowed. Extended-nonnegative weights and masses are allowed. There is no hidden disjointness or finite-total-weight assumption; infinite right sides are permitted by the statement.

### Uniform physical transport in arbitrary block dimensions

`linear_dependent_block_lintegral` transports the full dependent-block inequality through an arbitrary continuous linear equivalence from physical Euclidean space to the product of Euclidean blocks. It retains exactly the Haar scaling coefficient. `uniform_linear_dependent_block_lintegral` chooses a positive finite bound for that coefficient before all coordinate equivalences and input functions, assuming common forward and inverse operator-norm bounds. Thus the general physical measure-factor estimate is also proved. What remains in the general-k geometric application is assembling its particular actual normal blocks into these dependent Euclidean product coordinates with the simultaneous kernel identifications already available in scalar form.

### All actual normal kernels, using one synthesis map

For a synthesis equivalence e built from a full finite frame v, `coordinateDeletion e i` drops the ith coefficient of e^{-1}. Its kernel is exactly span{v_i}, its norm is at most norm(e^{-1}), and it has preimages bounded by norm(e) times the target norm. Both directions of the kernel equality are proved. These statements include the zero-dimensional complementary target.

`uniform_thin_normal_all_projections` applies these facts to the actual normalized thin-normal frame in every dimension k+2. One e simultaneously yields the selected three-dimensional normal-space kernel N and every other normal-line kernel. The same positive B controls e, e^{-1}, every projection and every preimage bound. B is chosen before the surfaces, frequency points, plane vectors, N and its orthonormal basis. The unit-normal, shape, membership and positive Gram assumptions remain explicit.

`groupNormalCoefficients` converts the selected scalar normal coefficients into an actual Euclidean normal block. The other scalar coordinates remain a finite Pi space. `groupedLineProjection_ker` identifies the corresponding line kernels after this conversion, and bounded preimages remain available. The regrouping has a fixed operator-norm cost independent of the geometric frame.

### Exact six-dimensional product coordinates

For k=4, `fourCoefficientGrouping` converts the coefficient space into exactly

    ((Ambient 1 x Ambient 1) x Ambient 3) x Ambient 1.

An explicit equivalence r orders the three other normals. In the notation of the existing four-block estimates:

| Projection | Actual kernel |
|---|---|
| `fourProjectionZero` | span of the normal indexed by r(2) |
| `fourProjectionOne` | the selected three-dimensional normal space N |
| `fourProjectionTwo` | span of the normal indexed by r(0) |
| `fourProjectionThree` | span of the normal indexed by r(1) |

All four equalities are checked simultaneously for the same coordinates. `uniform_thin_normal_four_coordinates` retains a common positive bound for the coordinate equivalence and its inverse, before the actual geometric data.

`uniform_actual_normal_four_L2` now instantiates the four-block physical L^(2/3) estimate on those actual kernels. Its positive finite coefficient is chosen before the geometric data and the four L2 inputs. The chosen coordinates precede the inputs. The coefficient includes the correct Haar scaling to the power 3/2; the input functions are physical cross-sectional L2 functions, not an assumed Fourier extension construction.

`uniform_actual_normal_four_metric_tubes` likewise instantiates the metric-fiber tube estimate on the actual configuration. A positive finite constant precedes the geometric data, countable families, weights, centers, radii, widths and projection-norm bound L. The estimate still requires

    delta * R <= L * w,

and has width factor (L*w)^6. It allows individually perturbed projections near the reference projections, arbitrary physical centers, and empty fibers. It does not assert that all perturbed fibers have the reference rank.

Thus the concrete geometry-to-flat-analysis identification gap is closed in dimension six. For general k, the block inequality and scalar normal kernels are proved, but their complete uniform physical-coordinate/measure assembly for the article's mixed-dimensional configuration has not yet been packaged into a corresponding general-k analytic theorem.

### Simultaneous projection stability

Coordinate deletion cannot increase the difference of inverse synthesis maps. After regrouping by the fixed map G, the concrete coordinate difference is at most

    norm(G) * B^2 * card(I) * norm(u-v)

when both inverse synthesis norms are at most B. Each of the four concrete projection differences is bounded by that coordinate difference. A common positive epsilon is chosen before both frames and maps to force all four differences below a prescribed delta>0.

This statement requires the frames to be close in the stated norm. It does not construct a global continuous orthonormal frame choice. Coherent local frames are still needed when applying it to varying geometric charts. A common geometric tolerance does not supply the fixed-aperture analytic Kakeya constant required in Remark 4.2.

### Remaining obligations

The general flat Loomis–Whitney inequality is no longer open for the nonempty sigma-finite block spaces used here. The six-dimensional actual normal-kernel identification and its bounded-scale analytic applications are also proved.

The remaining central analytic obligation is a mixed-dimensional perturbed estimate with a fixed aperture selected before R/width. The current tube theorem has a scale-dependent aperture and does not close that gap. Uniform wave-packet stability, the actual localized restriction recursion, and the retained intrinsic density/descent/algebraic/epsilon-removal obligations remain. Corollary 4.3, External input 1 and Theorem 1.1 are still unproved. The arbitrary-line tube geometry of External input 2 is not established by these complementary-block estimates.

### Concrete next implementation step

For the general-k actual geometric model, a useful next representation is the dependent block dimension `d j = if j = i then 3 else 1` on `Fin k`. Construct the fixed regrouping from the existing scalar coefficient index (the other normals disjoint-union Fin 3) into `forall j, Ambient (d j)`. The selected block receives its three basis coefficients; every other block receives its one scalar coefficient. Its inverse and operator bounds depend only on this fixed grouping. Then identify the deleted-block kernels using `normalComplementProjection_ker` and `coordinateDeletion_ker`, and apply `uniform_linear_dependent_block_lintegral`. This is a proposed assembly step, not a theorem claimed in this revision.

After that assembly, further flat inequalities alone will not supply the fixed-aperture result. The existing `UniformFixedAperture311Kakeya` remains a proposition, not a proved theorem. The next analytic proof must provide a multiscale estimate with its aperture chosen before the scale ratio, while retaining the actual weighted-family and norm budgets required by the localized restriction recursion.

### Candidate multiscale step for the fixed-aperture gap

A concrete next route is to partition the physical ball at side length comparable to R/A, with A fixed after the desired loss exponent and before R. For each family and cell, define the local weight as the sum of the weights of tubes meeting that cell. Apply the induction hypothesis to the local families on a ball containing each cell. The missing global budget is a bound for the sum over cells of the product of these local weights to the power 1/(k-1).

The new flat block theorem is intended to prove this budget: if a perturbed tube meets a cell, every point of that cell lies in a corresponding reference cylinder enlarged by the cell diameter, the tube width, and delta*R. Choosing delta of order 1/A makes the final error comparable to the cell width. For R/A at least the tube width, the flat cylinder estimate has a width factor of order (R/A)^(k+2). Dividing by the full cell volume should cancel that factor. This would give a recurrence constant independent of A, provided all partition, enlargement, overlap and coordinate constants are controlled uniformly.

The local weights can be defined by restricting each original weight to tubes meeting the intersection of the cell and the original ball. For a point in that intersection, the restricted density equals the original density. For every point of the entire cell, a meeting witness gives the enlarged reference-cylinder bound. Thus the cell-budget argument should use finite additivity over disjoint cells and pointwise domination; no triangle inequality at the exponent below one is needed. The reference center correction must use the same global physical center for all cells. Taking a common upper bound for all perturbed projection norms avoids introducing a family-dependent constant. These observations specify the intended proof obligations; they have not been Lean-checked as a recurrence.

To turn this route into a proof, formalize a finite disjoint cell cover with explicit full cell volumes and enclosing-ball radii; the tube-meeting-to-reference-cylinder implication on each entire cell; the countable weighted local-family identities; and the exact cancellation of the scale factor in the global cell budget. The scale reduction must include the cell-to-ball radius constant. Only after these lemmas are checked can A be chosen large enough for the desired power loss and the aperture chosen small enough relative to A. This is a proposed recurrence strategy, not a proved inequality or a claimed resolution of fixed-aperture Kakeya.

### Verification

All 843 main results were freshly axiom-audited. All 574 retained continuation results and all 61 new results were freshly compiled and axiom-audited, with no warnings or admissions. The default build passes. The final inventory check covers all 635 continuation results and rejects duplicate names, stale hashes and nonstandard axioms. Only `propext`, `Classical.choice` and `Quot.sound` are allowed. Continuation sources remain separate from the default 843-result main inventory.
## Revision 0.35 — fixed-aperture Kakeya by cell induction

This section is the current status and supersedes historical statements that fixed-aperture complementary-block Kakeya is still open. **Theorem 1.1 remains unproved.**

Revision 0.35 adds **59 results in 31 continuation files**: **843 unchanged main results + 694 continuation results = 1537 distinct results**. No result is promoted into the main inventory, and definitions/instances are not counted as theorems.

### Closed analytic gap

For any k >= 2 complementary Euclidean blocks of dimensions d_i with sum d_i = m, a common coordinate equivalence with uniformly bounded forward and inverse norms gives positive constants C and delta, chosen before the coordinate map, all countable weighted families, centers and scales. Every eta > 0 admits the estimate

\[
\int_{B(x_0,R)}\Bigl(\prod_{i=1}^k\sum_t u_{i,t}\mathbf1_{T_{i,t}}(x)\Bigr)^{1/(k-1)}dx
\le C R^\eta w^{m-\eta}\Bigl(\prod_i\sum_tu_{i,t}\Bigr)^{1/(k-1)},\qquad R\ge w>0.
\]

The families may be projection cylinders or genuine metric neighborhoods of affine fibers, with the defining maps within delta of the complementary reference projections. The metric-tube version does not assume an additional operator-norm bound on each family: that bound follows from projection closeness. It covers the short-radius case by an elementary ball-volume estimate. Neither theorem requires delta*R <= L*w.

The abstract transfer theorem explicitly assumes a flat input. In the complementary Euclidean-block applications that input is **proved**, using the general block Loomis–Whitney theorem, physical Haar transport, exact complementary ball volumes and the identity sum_i sum_{j != i} d_j = (k-1)m.

### Proof chain and entry points

| Stable ID | Verified step | Main declarations |
|---|---|---|
| N2-ANA-065 | Preserve density after retaining meeting tubes; dominate total meeting weights on full cells; cancel equal positive finite cell volumes | `cellMeetingWeight_density_eq`, `cellMeetingWeight_sum_budget`, `finite_ball_cell_partition` |
| N2-ANA-066 | Cell recurrence, real-radius induction and a scale choice for every positive power loss | `cylinder_ball_recurrence`, `real_scale_induction`, `exists_power_contraction_scale`, `uniform_fixed_aperture_from_flat` |
| N2-ANA-067 | Proved flat input and fixed-aperture cylinder/metric estimates for arbitrary complementary Euclidean blocks | `uniform_flat_dependent_block_input`, `uniform_fixed_aperture_dependent_blocks`, `uniform_fixed_aperture_dependent_metric_tubes` |
| N2-ANA-068 | Exact prior five-dimensional target; concrete six-dimensional coordinates and actual normal kernels | `uniform_fixed_aperture_311_kakeya`, `uniform_actual_normal_four_fixed_aperture`, `uniform_actual_normal_four_fixed_aperture_metric` |
| N2-GEO-044 | Quantitative correction from a nearby line direction to an annihilating projection; actual closed metric neighborhoods | `directionAlignedProjection_norm_bound`, `affineLineTube_eq_infDist` |
| N2-ANA-069 | Fixed directional line-tube neighborhoods from flat input; unit references use canonical norm-one duals | `uniform_directional_line_kakeya_from_flat`, `uniform_unit_directional_line_kakeya_from_flat`, `uniform_directional_line_dependent_blocks` |

The local weight is the original weight if a tube meets the cell inside the large ball, and zero otherwise. Its density agrees with the original density on that intersection. If a tube meets the cell, the full cell lies in a corrected-center reference cylinder of width w + delta*R + M*diam(cell). At cell side b, the conditions w <= b and delta*R <= b reduce this to (2+M*sqrt(m))*b. Flat integration bounds the sum of cell weight products after exact cancellation of b^m.

Local estimates are applied to containing balls of radius c*b, with c >= max(1,sqrt(m)/2). Taking b=R/B and delta=1/B produces a fixed recurrence multiplier H and child ratio c/B. The choice H*(c/B)^eta <= 1 closes induction on dyadic upper bounds for real radii. The proof quantifies over all centers and all reweightings directly; it does not form a supremum over a class of families. It does not use quasi-norm Minkowski, discard boundary cells, or assume finite total weights.

For line directions the explicit correction is A = Q - ell tensor ((ell(v))^(-1) Q(v)). If Q(v0)=0, ell(v0)=1, and v is close enough to v0, then A(v)=0 and norm(A-Q) <= 2*N*M*norm(v-v0). This is the bridge between directional and operator perturbations. `affineLineTube_eq_infDist` proves exact agreement with the closed metric neighborhood of the entire affine line.

### Relation to the article and remaining work

`uniform_block_finite_directional_kakeya` connects the result to the existing `FiniteDirectionalKakeya` packet interface on open balls, with exact agreement between the old and new tube definitions.

`uniform_directional_line_dependent_blocks` discharges the flat input for line families around unit reference directions in complementary Euclidean blocks, with constants before the coordinate map and the reference directions.

The exact proposition `UniformFixedAperture311Kakeya`, introduced as an open target in revision 0.32, is now proved. The six-dimensional estimates are instantiated on the actual three-dimensional selected normal space and the other three normal lines, with the previously explicit unit-normal, shape, Gram and membership hypotheses. The analytic estimates use closed balls and all R >= w > 0, so the range is stronger than the R >= 1 restriction in the five-dimensional target.

The following are still unfinished:

1. Assemble arbitrary-dimensional actual thin-normal coordinates into the dependent Euclidean block model. The scalar simultaneous kernel result and the analytic theorem are proved separately; the general grouping/kernel correspondence is still required.
2. Fully instantiate External input 2 from an arbitrary independent tuple of reference lines. The new directional transfer proves the analytic implication from compatible flat data, but the general independent-line coordinate construction has not been supplied.
3. Construct the coherent local chart/frame-family applications needed by Remark 4.2. A global continuous frame is neither asserted nor needed.
4. Prove uniform wave-packet estimates and the actual localized restriction recursion of External input 1. Fixed-aperture Kakeya is a component, not the localized restriction theorem.
5. Complete the retained intrinsic density/atlas, descent/algebraic, Corollary 4.3 and epsilon-removal obligations, and Theorem 1.1.

### Verification

All **59 new results** were freshly compiled and their printed axiom dependencies checked. Only `propext`, `Classical.choice` and `Quot.sound` occur; no admitted proofs or extra axioms are introduced. The default incremental build passes.

All 152 main modules and 248 prior continuation sources, together with their retained audit outputs, are byte-identical to revision 0.34. Their saved audit outputs are revalidated. They were **not freshly recompiled in this session**. The continuation audit script can rebuild and audit the entire 694-result continuation inventory; it remains separate from the default main build.
## Revision 0.36 — proved external Kakeya and actual mixed chart families

This is the authoritative current addendum. Earlier revision sections describe the state at those revisions.

Revision 0.36 adds **71 results in 34 files**, bringing the separate continuation inventory to **765 results in 313 files** and the total to **1,608 distinct checked results**, including the unchanged 843 main results.

- **N2-ANA-070 / N2-EXT-002:** `weighted_kakeya_external_all_dimensions` proves the literal `WeightedKakeyaExternalGoal m k` for every `k ≥ 2`. Independent unit reference lines determine the aperture and coefficient before all radii, widths and finite weighted families. Basis completion handles arbitrary codimension. The codimension-two article case, the unlocalized subensemble, and common constants on compact independent unit tuples are proved. No external Kakeya axiom remains in these statements.
- **N2-ANA-071:** `geometric_subdivision_proved_kakeya` and `geometric_original_grid_bound_proved_kakeya` discharge the external Kakeya assumption in the existing Section 3 subdivision and original-input packet-grid estimate. Their other explicit geometric, packet and scale hypotheses remain.
- **N2-GEO-045:** General-dimensional coefficient regrouping yields one three-dimensional block and the remaining line blocks. The exact kernels are the selected actual normal space and the other actual normal lines, with common forward and inverse coordinate bounds.
- **N2-ANA-072:** `uniform_actual_normal_block_fixed_aperture_cylinders` and its metric-tube counterpart instantiate the proved analytic estimate in every article dimension. Constants precede the geometric data under the stated common shape and Gram bounds.
- **N2-GEO-046 / N2-ANA-073:** Orthogonal-projection perturbations give nearby-subspace estimates for genuine affine-subspace metric tubes. Witness tubes agree exactly with closed distance neighborhoods and are measurable. This removes auxiliary projection maps from the actual-normal conclusion.
- **N2-ANA-074:** `geometric_nonzero_chart_subspace_kakeya` gives a common buffer, aperture and finite coefficient over supported tuples, nearby frames, selected indices and moved thin charts at arbitrary normal levels. It uses the prior adjoint normal-space analysis and does not impose a projected-normal-zero condition.
- **N2-GEO-047 / N2-ANA-075:** A common inverse derivative bound and second derivative bound yield a common parameter radius controlling normal-plane variation. `geometric_mixed_chart_normal_kakeya` combines the actual thin chart and the other hypersurface charts, derives their center normal identities, and proves the countable weighted normal-tube estimate for sampled chart normals. The theorem assumes the stated common chart regularity and inverse bounds; it does not itself construct the chart family or prove Fourier restriction.

- **N2-ANA-076:** `uniform_linear_dependent_block_L2` and `uniform_actual_normal_block_L2` give the physical L2-to-L^(2/(k-1)) flat estimate in arbitrary complementary block dimensions and on the article's actual normal configuration, with constants before the splitting and the inputs. This extends the prior six-dimensional application.

**Verification.** All 71 new results are freshly compiled, with complete transitive axiom output and no warnings. Only `propext`, `Classical.choice` and `Quot.sound` occur. All 152 main source modules and 279 older continuation source modules, together with their retained audit output, are checked byte-for-byte against revision 0.35. Retained compiler output is revalidated; fresh compilation of unchanged earlier results is not claimed. The incremental default build passes. Continuation modules remain separate from the default main build.

**Still open.** External input 1, including the uniform localized Fourier restriction recursion and its localization gain; full article-level wave-packet and chart-partition assembly; Corollary 4.3; polynomial partitioning and geometric descent; the remaining tangent/nontangent packet estimates; epsilon removal; Theorem 1.1. The new normal-tube estimate supplies the Kakeya part of Remark 4.2, not the whole localized restriction argument.


## Revision 0.37 — localization recursion and actual chart bridges

Authoritative current count: **843 main + 817 continuation = 1,660 distinct checked results**. Added **52 results in 18 files**.

Uniform square-root recurrence closure with changing capped localization states and a Kakeya coefficient, conditional on the analytic recurrence, including additive-error absorption. Exact double-enlargement active-level and normalization bookkeeping. Actual measured thin-fiber chart construction and mixed normal-tube Kakeya. Full all-hypersurface subspace and chart Kakeya, with every factor retained. Finite normalized original-strip operator constants and exact polynomial initialization. Exact summable phase expansions and integration at the uncertainty scale. The vector-valued restriction reduction, actual Fourier recurrence, Corollary 4.3 and the main theorem remain open.

Stable IDs: N2-ANA-077 (changing-state scalar recursion); N2-ANA-078 (normalized original-strip operator and polynomial base); N2-ANA-079 (all-factor subspace/chart Kakeya); N2-ANA-080 (uncertainty-scale phase series); N2-GEO-048 (actual measured fiber charts); N2-GEO-049 (localization scale and active-level bookkeeping).

The unproved analytic inputs are stated as hypotheses, never axioms. No theorem identifies the original-strip best constant with the scale-dependent ensemble constant. The two normal configurations retain the same number of factors. The phase expansion does not by itself provide the missing vector-valued estimate.

52 new results freshly compiled and axiom-audited, with no warnings or admissions. The 843 main and 765 prior continuation results retain their v36 compiler audits: their source and log bytes are unchanged and all retained declaration/axiom reports are revalidated. The default incremental lake build passes. Continuation files are audited separately from the default build.

New sources: `continuation/LineSubspaceKakeyaV37.lean`, `continuation/CompactLineSubspaceV37.lean`, `continuation/PhaseSeriesV37.lean`, `continuation/IntegratedPhaseSeriesV37.lean`, `continuation/ExtensionPhaseSeriesV37.lean`, `continuation/PhaseSeriesSquareV37.lean`, `continuation/ExtensionPhaseSquareV37.lean`, `continuation/DistancePhaseSquareV37.lean`, `continuation/FullChartKakeyaV37.lean`, `continuation/LocalizationScalesV37.lean`, `continuation/LocalizationBookkeepingV37.lean`, `continuation/LocalizedOperatorConstantV37.lean`, `continuation/LocalizedPolynomialBaseV37.lean`, `continuation/SqrtScaleInductionV37.lean`, `continuation/LocalizedRecurrenceErrorV37.lean`, `continuation/LocalizedRecurrenceV37.lean`, `continuation/MeasuredFiberChartsV37.lean`, `continuation/MeasuredMixedKakeyaV37.lean`.


## Revision 0.38 — article contributions with external inputs assumed

This addendum supersedes earlier scope and open-task descriptions. **843 main + 883 continuation = 1,726 checked results**, including **66 new results in 20 files**.

Article-only continuation with explicit borrowed inputs. Uniform localization atlas and Corollary 4.3/integral applications relative to a specialized external chart estimate; both trimmed-cell counts for actual multivariate polynomial sign labels; bounded Hilbert packet cell-energy budgets; substantial-mass simultaneous energy selection; actual orthogonal pushforward of the reset density and its exact lifted-cell mass; conditional final epsilon-removal application. The segment-lift endpoint, displacement and avoidance-of-cuts implications are proved for a supplied continued path; its existence/continuation, complete descent/tangent assembly, decay and the main recurrence remain open.

| Stable ID | Checked contribution and precise boundary |
|---|---|
| N2-ANA-081 | Uniform atlas, C*mu strip and q0 integral assembly from the specialized external chart estimate; full chart-certificate packaging is still separate. |
| N2-GEO-050 | Both Lemma 5.2 counts on actual polynomial sign labels: degree+1 and M*(K+2)^n. The nontangent bound assumes only the stated external covering input and article witness hypotheses. Lemma 5.1 is still open. |
| N2-ANA-082 | Actual bounded Hilbert packet sums inherit these two cell multiplicity budgets. Full surface atlas/cap aggregation remains open. |
| N2-ANA-083 | Reset density is finite, projects absolutely continuously under the actual orthogonal projection, and has exactly the correct lifted-cell mass. |
| N2-ANA-084 | Substantial-mass cell selection satisfying simultaneous original energy budgets. |
| N2-GEO-051 | Segment-lift endpoint, uniform displacement and avoidance-of-cuts bounds for a supplied path; existence and continuation remain open. |
| N2-ANA-085 | Final epsilon-removal application relative to External input 4; local recurrence and surface test decay are not assumed as external results. |

The proofs of External input 1, the algebraic tools and epsilon removal are no longer project tasks. See `EXTERNAL_INPUT_POLICY.md`. External Kakeya was already proved and remains retained. The central article recurrence and both main theorem targets are still open.

All 66 new results in 20 files freshly compiled with complete axiom reports, no warnings and no admissions. The 843 main and 817 older continuation results retain their earlier audits: source and log bytes are unchanged from v37, and retained reports are revalidated. Default incremental build passes. Continuation modules remain separately audited.


## Revision 0.39 — local lifting and finite restart

Constructed the smooth tangent-kernel projection from a regular defining differential and its Gram operator; proved pointwise local level-set lifting, exact projected motion and speed bounds, finite terminal limits in the original admissible component, endpoint differentiability, curve gluing, and finite geometric restart. Maximal-lift assembly up to time one remains open, as do the dimension descent, tangent estimates, surface decay and actual main recurrence.

37 new results in 18 files freshly compiled with full standard-axiom audits, no admissions and no warnings. All 152 main modules rebuilt successfully. All 883 earlier continuation results retain unchanged source/log bytes and validated saved reports. The 843-result main saved axiom audit was retained and revalidated; a fresh audit is not claimed in this checkpoint.

The strongest entry points are `pointwise_regular_level_lift` and `finite_geometric_lift_restart`. The latter constructs a genuine extension of an already existing lift beyond any positive stopping time T≤1 under the geometric hypotheses. It does not construct a maximal lift or a solution on the entire unit interval. No external-input proof was added to the scope.


## Revision 0.40 — maximal lifting and wall descent

Constructed compatible chain unions and maximal lifts, proved component-local continuation past time one, and completed the short-segment lifting conclusion including a polynomial independent-gradient version of Lemma 5.1. Assembled wall-to-factor-intersection covering, measurable mass selection, transverse dimension loss with a Euclidean defining map, the stage constant update, and the same conclusions for the actual selected extension density. Full descent and the main restriction theorem remain open.

49 new results in 22 continuation files freshly compiled with complete standard-axiom reports, no admissions and no warnings. All 920 previous continuation source/log hashes were checked unchanged. All prior Lean sources are byte-identical to revision 39. Main sources retain their prior checked build and audit; no fresh main axiom audit is claimed.

Strongest entry points: `polynomial_lifting_lemma_5_1`, `geometric_unit_lift`, and `selected_extension_wall_dimension_drop`. The final theorem produces the regular lower-dimensional zero set and actual selected-integral comparison from explicit generic-cut transversality. It does not supply polynomial degree bookkeeping, the tangent-plane cut assignment, the non-wall cell branch, or the complete recurrence.


## Revision 0.41 — polynomial stages, plane assignment and cross-cap energy

Constructed literal bounded-degree polynomial wall stages and tangent-cut stages; proved finite plane nets, uniform measurable component-to-plane selection and its stage restriction; assembled actual cross-cap graph-packet near/far cell energy budgets without a cap-count loss. External cutting/transversality and tube covering remain explicit premises. Full non-wall analytic closure and the final restriction theorem remain open.

50 new results in 33 files freshly compiled and axiom-audited with no warnings or admissions. All 969 retained continuation source/log hashes and all 546 prior Lean sources are unchanged. No fresh main axiom audit is claimed.


## Revision 0.42 — actual surface atlas and cell analysis

Constructed actual surface-atlas cell energy budgets and their normal-axis near/far incidence adapters, all charged to original surface norms. Proved actual binary packet selection and stage reset, finite projected reset density, uniform trimmed-cell packet omissions, finite-buffer margin local estimates at R/2, an explicit product-error cell-mass estimate, and direct actual-atlas substantial-cell selection. Full substantial-cell/exponent/degree closure and the main restriction theorem remain open.

47 new results in 25 files freshly compiled and axiom-audited with no warnings or admissions. All 1019 retained continuation source/log hashes and all 580 prior Lean sources are unchanged. No fresh main axiom audit is claimed.


## Revision 0.43 — combined actual non-wall partition estimate

Assembled the actual reset-partition non-wall mass estimate: normal-axis near/far incidence, simultaneous substantial cell, original-norm degree powers, actual R/2 buffer local constant, arbitrarily rapid integrated error, and zero-mass branch. Proved the wall-or-cell retained-mass alternative and contraction for the resulting coefficient. External partition/tube-cover inputs stay explicit. Fixed-buffer versus changing-margin compatibility, terminal cases, full recurrence and main theorem remain open.

30 new results in 21 modules individually compiled and axiom-audited with no warnings or admissions. All 1066 retained continuation source/report hashes and all 606 prior Lean files are unchanged. No fresh main axiom audit claimed.


## Revision 0.44 — relative support and inherited-margin non-wall estimate

Proved essential-support-relative packet enlargement, support-preserving original atlas decomposition, all three Section 8 child-margin adapters, and the complete non-wall branch with inherited margins and rapid error. Added exact common-surface input and local-constant transfers. External inputs remain explicit. Constructed fixed compact surface classes and positive-margin domains, and proved the same-class local adapter for arbitrary admissible inputs. Propagation of this direct same-class bound through the entire mass/descent chain, Section 7 terminal assembly, and both main theorems remain open.

50 new results in 26 modules individually compiled and axiom-audited with no warnings or admissions. All 1096 retained continuation source/report hashes and all 628 prior Lean files are unchanged. No fresh main axiom audit claimed.


## Revision 0.45 — same-class contraction and feasible stage counts

Completed the actual non-wall mass branch on the same fixed surface class at parent and child scales, including arbitrary admissible inputs, constructed atlas/caps, rapid error, zero mass, and an integer degree chosen before R giving any prescribed contraction coefficient. Proved uniform robust near-plane rank, feasible near/far counts from actual nonzero selected mass, and exhaustive zero/terminal/negative-exponent stage classification. External inputs remain explicit. The angular-uniform external tube-cover interface also yields a scale-independent nontangent-ball multiplicity bound. The finite-point analytic bound at the actual dimension-zero child radius is also proved, conditional on finite-point coverage. Full external-partition invocation and multistage descent with uniform accumulated constants, terminal Section 7 and dimension-zero geometric assembly, MarginRecurrences, SurfaceTestDecay and the main local/global theorems remain open.

26 new results in 24 modules individually compiled and axiom-audited without warnings or admissions. All 1146 retained continuation source/report hashes and all 655 prior Lean files are unchanged. No fresh main axiom audit claimed.


## Revision 0.46 — terminal plane geometry and actual tangent packet strips

Proved the terminal two-plane geometry from actual atlas normal tuples, near-family angles, witness-plane gap, and the terminal dimension/count equality. The mixed projected normals span the witness plane; their orthogonal complement has dimension two and is uniformly close to all nearby common tangents. Proved equation (7.7) for the actual selected original packets meeting a dilated cube, from the article angular tangency condition and a nearby variety witness. Normal variation across caps, rotations, infinite selected sums, radius-uniform thresholds, and the b/rho scale identity are discharged. Failure of actual packet tangency also yields the witnesses and uniform separated-ball multiplicity in the geometric step of Lemma 7.1. Borrowed inputs remain explicit. A finite directional subdivision is constructed so plane closeness holds on every full open patch neighborhood; a curvature-weighted version supplies the precise geometric tolerance for the admissible-frame adapter. The actual descent must still supply its retained stage and witness data. The full Section 7 analytic estimates, wall/non-wall descent, dimension-zero geometric assembly, MarginRecurrences and main local/global theorems remain open.

38 new results in 23 modules individually compiled and axiom-audited without warnings or admissions. All 1172 retained continuation source/report hashes and all 680 prior Lean files are unchanged. No fresh main axiom audit claimed.


## Revision 0.47 — actual nontangent analytic estimate and terminal splitting

Proved Lemma 7.1 for the actual nontangent original-packet sum (7.2), relative only to the explicit borrowed angular-uniform algebraic tube cover and fixed common surface class. Cap families, finite lattice covering, dimension-only bounded overlap, admissible chart inputs, incidence, energy, child margins and quasi-Banach summation are constructed or proved internally. The final statement uses the article exponent range and exact packet width R^(1/2+tau)/10. Constants precede the radius, input and arbitrary retained stage. Also proved the exact retained tangent/nontangent L2 and extension split, the binary product expansion and majorant, the normal strip for the explicitly selected tangent cube packets, a scale-independent bound for how many covering balls meet each b-cube, a uniform rapid approximation of each original selected extension by its two retained pieces, and the corresponding product error charged to the original product of input norms. Proposition 7.3, the finite wall/non-wall descent, dimension-zero geometric assembly, MarginRecurrences and main local/global theorems remain open.

28 new results in 23 modules individually compiled and axiom-audited without warnings or admissions. All 1210 retained continuation source/report hashes and all 704 prior Lean files are unchanged. No fresh main axiom audit claimed.


## Revision 0.48 — actual tangent endpoints and localized cube estimate

Proved the actual positive tangent sum Ftan and its measurability; its uniform pointwise bound (7.10); exact ambient/surface transfer for localized restriction; admissible terminal ArticleFrame construction; and the actual tangent-cube localized integral (7.13), with its narrow normal-strip support and same-patch support derived from original selections and parent margins. Proved the linear O(R/rho+1) retention count for actual finite packet tubes, unique tangent/nontangent classification, the combined original-packet energy budget, and the exact square-function estimate (7.15). Holder and the bounded-overlap majorant prove (7.9) for the same Ftan under the explicit fixed-patch support invariant. The borrowed localized restriction input remains explicit. The (7.13) statement retains the harmless dimension-dependent containing-ball dilation, selected norms, a supplied admissible frame identifying the terminal plane, and actual stage witnesses. It does not yet include the omitted-cube rapid error or replace selected norms by Kakeya cube budgets. The frame construction and child-support invariant are separately proved. Proposition 7.3 still needs (7.8), its Kakeya/grid summation and rapid-error assembly; finite dimension descent, MarginRecurrences and main local/global theorems remain unproved.

31 new results in 27 modules individually compiled and axiom-audited without warnings or admissions. All 1238 retained continuation source/report hashes and all 728 prior Lean files are unchanged. No fresh main axiom audit claimed.


## Revision 0.49 — actual tangent grid and Kakeya assembly

Proved full per-product (7.13), including the omitted-cube rapid error and replacement of selected norms by a common original-packet cube energy. Proved bounded ball/binary summation for the actual positive Ftan on a cube, then summed over the exact physical meeting grid, charging rapid errors to one enlarged ball volume. Connected that actual Ftan integral to the borrowed finite directional Kakeya estimate, with all width/ball dilations and error terms explicit. Substituted the energy budgets of the already chosen chart inputs to obtain the original norm product, and proved the exact scale cancellation yielding the exponent of (7.8). Constants precede scales, selections and stage data. The terminal frame and witnesses remain an explicit geometric premise, with existing separate construction lemmas. The resulting integral theorem is not yet a final (7.8) norm theorem: instantiate the geometric data throughout the actual finite descent, specialize the external Kakeya estimate and scale range, absorb rapid error, and take the p-root. Proposition 7.3, finite dimension descent, MarginRecurrences and the main local/global theorems remain unproved. Borrowed analytic inputs are explicit arguments; no new global axioms or admissions.

30 new results in 24 modules individually compiled and axiom-audited without warnings or admissions. All 1269 retained continuation source/report hashes and all 756 prior Lean files are unchanged. No fresh main axiom audit claimed.


## Revision 0.50 — normalized actual tangential bounds and terminal recurrence

Proved the normalized actual tangent q0 bound (7.8), including all fixed dilation factors, arbitrary rapid-error normalization, finite coefficients, positive p-roots and the eventual Kakeya scale conditions. Specialized (7.9) to the article child radii with its positive-margin conditions derived. Combined these bounds for the same actual Ftan to prove the critical estimate and every above-critical estimate with exact loss sigma=k/(k+1)*(2*tau+epsilon). Constructed one directional subdivision compatible with borrowed Kakeya and all terminal admissible frames; handled empty subpatches by their zero contribution. Derived every active cube frame from actual terminal polynomial plane-witness regions and regular tangent dimensions. Proved the original selected-product decomposition into actual Fnt and Ftan with a single rapid error, without a total ball-count loss. Combined Lemma 7.1 and the new tangent estimates into a terminal selected-product recurrence bounded by a finite constant times (the same-class local constant at R^(1-tau) plus R^sigma) times the original norm product. Its constructed-data wrapper supplies original cap families, chart inputs with parent margins, and separated physical covering balls. The final mass bridge applies the bound to an actual PolynomialStage, preserving accumulated error and using a stage-coefficient ceiling fixed before R. The polynomial plane-witness region, near-reference classification, terminal count and borrowed uniform algebraic tube cover remain explicit stage invariants/inputs; constants precede R, original data and selected stages. Also proved reference-normal feasibility and classification with a tolerance fixed before all chart atlases, and a common Kakeya/frame/rank subdivision. Proved that modulation preserves the exact margin class and that origin-centered margin estimates bound all physical centers and the actual margin best constant. Full finite wall/non-wall descent, the zero-dimensional finite-point construction, the final MarginRecurrences and main local/global theorems remain unproved. Borrowed inputs are explicit arguments; no new global axioms or admissions.

42 new results in 34 modules individually compiled and axiom-audited without warnings or admissions. All 1299 retained continuation source/report hashes and all 781 prior Lean files are unchanged. No fresh main axiom audit claimed.


## Revision 0.51 — zero-dimensional outcome, common stage budgets and recurrence adapters

Constructed the actual zero-dimensional polynomial-stage finite-point cover from the article's literal borrowed External Input 3(4), with at most D^n points under a fixed degree ceiling. Regularity/nonemptiness internally gives m=n for such stages. Applied the existing finite-point child estimate to the actual selected inputs; proved the stage mass outcome and the rooted form (6.15), preserving accumulated error, with original cap families and chart inputs constructed internally. Width multipliers are bounded by a fixed ceiling, rather than required to equal it, so the child scale is common across stages without assuming radius monotonicity of the margin constant. Refined the complete terminal tangent/recurrence construction to use one subdivision supplying both Kakeya/admissible frames and reference-normal feasibility before all chart atlases. A combined theorem gives zero-dimensional and terminal mass outcomes for the same caps, chart decomposition, original packets and original norms. Proved fixed numerical stage budgets and propagation through actual wall drops, tangent-cut drops, plane selection and binary selection. The actual atlas binary selection returns literal subsets of the original packet indices. Proved finite hierarchy propagation, a common final ceiling, the ambient bound on the number of codimension-one drops, a contracting degree schedule chosen from old coefficient ceilings before R, and a well-founded descent assembly principle. The degree schedule still requires finite coefficient tables depending only on the old budget, and the descent principle still requires an internally proved one-step alternative; neither is an assumed external input or a completed actual descent. Proved the origin mass-to-margin-power adapters, including L2 equivalence-class representatives and all physical centers, the common algebraic envelope for the three termination branches, and the exact conditional adapter from assembled original-input mass estimates to MarginRecurrences. Also proved the 1-Lipschitz direction-angle estimate and the packet-to-reference near-angle transfer when the actual geometric tolerance gamma is at most iota/2. Nonzero actual selected mass supplies the cap witnesses, so the rank clause of the same initial subdivision gives feasible counts before any atlas-dependent rank tolerance. Auxiliary regular-zero-fiber isolation/discreteness is checked but is not used to prove the borrowed point-count theorem. The full actual one-partition/finite-descent instantiation, uniform external geometric-data packaging, the original-input mass recurrence and the main local/global theorems remain unproved. Borrowed inputs are explicit arguments; no new global axioms or admissions.

45 new results in 32 modules individually compiled and axiom-audited without warnings or admissions. All retained source/report hashes for the 1341 prior continuation results and all 816 prior Lean files are unchanged. No fresh main axiom audit claimed.


## Revision 0.52 — actual cut preparation and contracting one-partition alternative

Proved the actual cut-near/cut-away preparation step, including zero selected mass and an empty tangent-cut family. Literal borrowed tangent-cut bounds and the internal finite plane net are chosen uniformly before chart atlases, radius, original inputs and polynomial coefficients. The away branch constructs a plane-adapted stage and then actual near/far subsets of the original packet indices, preserving the actual equations, physical-region geometry, short-lift witnesses, accumulated error and explicit budget costs. Proved the actual prepared-stage classification using the same initial reference-rank subdivision: zero-mass exit, dimension zero, terminal count, or a nonterminal count gap with negative cellular exponent. Proved angular monotonicity of plane-witness regions and a terminal mass theorem whose only near-angle premises concern the actual selected packet axes; reference angles and their cap witnesses are derived internally. Packaged the literal borrowed projected partitioning/generic-transversality data and constructed its canonical trimmed cells with measurable geometry, wall separation, coverage and inherited balanced upper masses. Applied the proved selected-input nonwall estimate and the actual polynomial wall constructor to establish the one-partition analytic/dimension-drop alternative. Instantiated the degree-choice coefficient with the actual old stage mass ceiling, fixed half-ball cover and old geometry/energy constants. The contracting one-partition theorem chooses one degree before R, uniformly over all feasible nonterminal dimensions and far counts; it gives any prescribed cellular contraction plus the actual rapid error or a genuine factor-wall successor with fixed degree, width and mass ceilings. Supplied the partition certificate from an explicit degree-uniform borrowed partitioning input, proving all actual reset-density finiteness and absolute-continuity prerequisites internally. Supplied the actual polynomial tube-cover constants uniformly from literal External Input 3(3), with an internal exact fixed-angle specialization. Thus the strongest nonterminal one-partition theorem has no caller-supplied partition certificate, retained-cell-mass estimate, energy estimate or actual-variety tube-cover premise. These are proved applications relative to explicit borrowed algebraic inputs, not proofs of those external inputs. A fixed finite componentwise joined successor budget now accommodates both tangent-cut and prepared factor-wall successors, including changing selected inputs. The full finite iteration still needs to group preparation, classification, the contracting partition alternative and the proved zero/terminal exits into one admissible-stage successor rule, build a common numerical hierarchy and common threshold/error envelope, and apply the original-input MarginRecurrences adapter. The main local and global theorems remain unproved. No new global axioms or admissions.

25 new results in 20 modules individually compiled and axiom-audited without warnings or admissions. All retained source/report hashes for the 1386 prior continuation results and all 849 prior Lean files are unchanged. No fresh main axiom audit claimed.


## Revision 0.53 — actual finite descent, original-input mass and subpatch estimates

Proved exact full-packet reconstruction for the same graph-supported chart decomposition, and initialized the original-input polynomial stage with err=0. Grouped actual tangent-cut preparation, plane/binary subset selection, reference-rank classification and the contracting partition into one proved admissible-stage step. Both actual codimension-one successors and prepared terminal leaves fit one finite budget whose width is exactly 100 times the old width. Proved the original-packet-preserving finite iteration and instantiated it with that actual grouped step, obtaining a common finite degree/width/mass ceiling and a finite cellular error envelope before R. Combined the actual iteration with the constructed terminal estimate and assumed-point-count dimension-zero estimate to prove the original-input origin mass inequality on the chosen subpatch margin classes. The chart atlas is chosen internally; the same caps/charts/inputs are used throughout. Proved the exact ENNReal-to-real scalar adapter and scalar closure with separate analytic coefficient and child-radius multiplier, without radius monotonicity of the changing margin class. Chose the small parameters and proved R^delta growth and actual all-center MemLp operator estimates for every delta>0 on those chosen subpatch classes. Proved fixed-loss zero-extension and actual Hausdorff surface restriction adapters for compact original supports carried with a positive margin by a chosen piece. These results are relative to the existing explicit borrowed Kakeya/localized-restriction and bounded-degree algebraic inputs, with no new global axioms or admissions. The final compatibility of the directional subdivision with interior original-support covers, subsequent support/subdivision assembly, endpoint passage and global epsilon-removal/test-decay assembly remain open; the named main local/global theorems are not claimed. A separate directional subdivision constructor now retains its open relative-interior cover, but that cover has not yet been propagated through the joint rank/Kakeya/terminal constructor used by the strongest growth theorem. Counts are not completion percentages.
 Proved a finite compact-core construction with positive collars in doubled frequency balls, and applied it to the retained relative directional cover and buffered parent active-surface domain. The resulting cores cover the original compact support, lie in their labeled directional pieces, carry explicit positive margins, and their frequency balls satisfy the exact active-surface inclusion used by the recurrence. This is conditional on the SAME directional cover certificate; propagating that certificate through the terminal/growth wrapper chain and choosing a common tuple margin/realizing the cores as surface inputs are still pending.
 Proved the common positive margin for a finite core tuple and realization of each compact core as an actual SmoothPatch with the same extended surface and exact restricted Hausdorff measure. These helpers still need instantiation after the cover certificate is threaded through the terminal wrappers.

35 new results in 24 modules individually compiled and axiom-audited without warnings or admissions. All retained source/report hashes for the 1411 prior continuation results and all 870 prior Lean files are unchanged. No fresh main axiom audit claimed.


## Revision 0.54 — actual finite descent, original-input mass and subpatch estimates

The named local implication is checked under the stated interfaces; certification of the localized atlas input remains open. The SAME directional subdivision now retains its relative-interior cover throughout the terminal/mass/growth chain. Actual compact core patches with positive collars cover the original supports; a proved fixed-loss finite-cover estimate preserves their exact surface measures and norms. Endpoint passage and raising exponents give local restriction for every p at least critical. The global theorem is assembled conditionally on the article-side nonempty-case SurfaceTestDecay; that decay is still OPEN and is not classified as an external input. Individual two-plane coercivity now yields actual nonzero and unit tangent Hessian directions, quantitative persistence, and a finite uniform curvature cover. Actual normal graph and scalar phase second derivatives are checked, with positive curvature bounds uniform in a graph interval and a normal-direction neighborhood.

38 new results in 28 modules individually compiled and axiom-audited without warnings or admissions. All retained source/report hashes for the 1446 prior continuation results and all 895 prior Lean files are unchanged. No fresh main axiom audit claimed.


## Revision 0.54 authoritative theorem status

The named local implication is checked under the stated interfaces; certification of the localized atlas input remains open. The SAME directional subdivision now retains its relative-interior cover throughout the terminal/mass/growth chain. Actual compact core patches with positive collars cover the original supports; a proved fixed-loss finite-cover estimate preserves their exact surface measures and norms. Endpoint passage and raising exponents give local restriction for every p at least critical. The global theorem is assembled conditionally on the article-side nonempty-case SurfaceTestDecay; that decay is still OPEN and is not classified as an external input. Individual two-plane coercivity now yields actual nonzero and unit tangent Hessian directions, quantitative persistence, and a finite uniform curvature cover. Actual normal graph and scalar phase second derivatives are checked, with positive curvature bounds uniform in a graph interval and a normal-direction neighborhood.

Explicit borrowed inputs: weighted multilinear Kakeya; uniform localized restriction at baseline on the internally constructed canonical article localization atlas; uniform tangent cuts; projected polynomial partition/generic transversality; polynomial tube covering; dimension-zero point count. The global conditional route also uses the existing borrowed surface epsilon-removal theorem. CanonicalLocalizedRestrictionInput repackages the localized input ONLY on the actual internally chosen atlas; it does not assume restriction on every arbitrary reduced ArticleLocalizationAtlas. Internal energy, descent, recurrence, original-support assembly, MainLocalGoal and SurfaceTestDecay are not external inputs.


## Revision 0.55 — actual finite descent, original-input mass and subpatch estimates

Closed the revision 54 localization-atlas provenance gap by retaining the full measured-chart, normal-coordinate and common-constant geometry in a certified atlas type, and deriving its reduced analytic adapter. Proved the exact named MainLocalGoal relative to the certified borrowed inputs, including original-support assembly and the critical local endpoint; the internal descent/recurrence/local bound is not assumed. Reassembled the conditional global theorem using that proved local theorem. Constructed actual implicit curved normal surface slices and uniform phase curvature, instead of assuming a smooth graph curve. Proved actual oscillatory integration-by-parts and frequency-weighted integral bounds, sign-independent stationary sublevel measure and integral bounds, and smooth inverse regularization with explicit main/remainder integral estimates. A complete quantitative one-dimensional curved oscillatory estimate is proved; parameter optimization proves an actual 1/5 frequency-decay power. Full-surface test-density decay, its Hausdorff/Jacobian/Fubini assembly and the named MainGlobalGoal remain open. The article-specific 1/2 decay (8.4) is not claimed.

39 new results in 23 modules individually compiled and axiom-audited without warnings or admissions. All retained source/report hashes for the 1484 prior continuation results and all 924 prior Lean files are unchanged. No fresh main axiom audit claimed.


## Revision 0.56 — sharp half-decay and actual curved graph charts

Proved the sharp one-dimensional frequency^(-1/2) bound for actual curved oscillatory integrals, with explicit amplitude coefficients, a frequency-independent coefficient and no upper-curvature hypothesis. The proof uses the actual Cauchy-kernel primitive, sign-independent kernel integral bounds, smooth inverse regularization, exact main/remainder decomposition and square-root optimization. Proved its Fubini consequence for actual product integrals. Constructed compact auxiliary SmoothPatches for every ambient compact test density on the full extended surface, proved exact equality of the original Hausdorff-surface Fourier integral with this compact restriction, proved its finite mass and actual test-density integrability, and constructed its finite regular graph cover. Proved the tangent lift in existing oblique graphs, globally smooth representatives of local graph germs, actual graph curves realizing any tangent, and regular full graph germs at all extended-surface points. Proved phase-curvature identities and joint parameter continuity; constructed full graph germs with a common curved parameter box directly from GeometricHypotheses. The certified local theorem from revision 55 is retained unchanged. Full-surface SurfaceTestDecay, smooth Hausdorff-Jacobian/partition amplitudes, nonstationary angular assembly and MainGlobalGoal remain open. The full surface estimate (8.4) is not claimed.

43 new results in 27 modules individually compiled and axiom-audited without warnings or admissions. All retained source/report hashes for the 1523 prior continuation results and all 948 prior Lean files are unchanged. No fresh main axiom audit claimed.


## Revision 0.57 — sharp half-decay and actual curved graph charts

Proved smoothness and positivity of the normalized graph Jacobian and the actual compact surface-test/partition amplitude. Introduced the standard smooth graph area formula as an explicit borrowed theorem argument, with the Hausdorff normalization retained; no Fourier estimate or article-side decay is part of that input. Proved exact orthogonal surface measure transport, actual Hausdorff Fourier-integral transfer, product coordinates, amplitude/derivative budgets and uniform curved surface-chart half-decay. Proved actual nonstationary interval inverse-frequency decay by parameter-independent regularization bounds and removal of a quadratic error, then derived compact direction/phase budgets and actual nonstationary Hausdorff surface-chart decay. Constructed nonnormal full phase boxes, slicing-axis rotations, curved compact product boxes, both normal signs, and exact horizontal affine determinant and extension transfers. Constructed finite smooth spatial partitions and proved exact weighted full-surface reconstruction and finite decay assembly. Retained actual local surface coverage when globalizing graph germs. Full-surface SurfaceTestDecay and the global theorem remain open at chart-localization and finite spatial/angular cover assembly. The named local theorem remains unchanged relative to its certified borrowed inputs.

56 new results in 33 modules individually compiled and axiom-audited without warnings or admissions. All retained source/report hashes for the 1566 prior continuation results and all 976 prior Lean files are unchanged. No fresh main axiom audit claimed.


## Revision 0.58 — sharp half-decay and actual curved graph charts

Proved exact support-based localization of full extended-surface Fourier integrals to actual compact graph pieces, with both graph-image inclusion and ambient local coverage retained. Constructed arbitrarily small compact affine slicing rectangles and the affine nonstationary inverse-frequency estimate. Combined the covered curved and nonnormal phase boxes to prove actual local full-surface half-decay in every unit physical direction. Constructed finite spatial covers and smooth partitions, then a finite angular cover with a common frequency-independent coefficient. Normalized physical vectors, used the actual L1 bound at bounded radius, and proved the full (1+norm x)^(-1/2) test-density estimate (8.4), relative to the standard graph area formula. SurfaceTestDecay is now proved internally in the nonempty-original-support branch. Applied the retained certified local theorem and external epsilon removal to prove MainGlobalGoal, handling empty original supports through the existing zero-product branch. Both named main goals are now proved relative to the explicit certified borrowed inputs; this is not an unconditional proof of those external theorems or a claim that every ancillary article statement has been independently audited for exact correspondence.

28 new results in 22 modules individually compiled and axiom-audited without warnings or admissions. All retained source/report hashes for the 1622 prior continuation results and all 1010 prior Lean files are unchanged. No fresh main axiom audit claimed.
