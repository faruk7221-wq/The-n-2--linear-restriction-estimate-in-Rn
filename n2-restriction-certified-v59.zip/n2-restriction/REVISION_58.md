# Revision 0.58

Both named main goals now have checked proofs relative to the explicit external inputs. The new entry point is `N2Restriction.mainGoals_of_certified_borrowed_inputs` in `continuation/CertifiedMainGlobalV58.lean`.

The previously open step was full-surface Fourier decay. This revision proves exact chart localization, constructs the finite spatial and angular covers, and combines the actual curved and nonstationary estimates. It proves the full test-density bound with exponent 1/2, including bounded physical frequencies. That internally proved decay closes the named global theorem through the retained epsilon-removal interface.

The external inputs remain explicit theorem arguments: the standard smooth graph area formula, weighted Kakeya, localized restriction on full certified measured atlases, tangent cuts, projected polynomial partition/transversality, polynomial tube covering, dimension-zero point count, and epsilon removal. No external input was added in this revision. No article-side decay or main-theorem conclusion is assumed.

An additional checked symmetric four-by-four matrix example has an invertible full matrix and zero compression to a coordinate two-plane. It records the pointwise linear-algebra obstruction behind the article's curvature caution; it does not construct a family of hypersurfaces.

There are 33 new results in 23 modules, for 2,498 distinct checked results overall. All 1,010 previous Lean files are unchanged. Individual compilation, the combined new-result axiom audit, the exact theorem-boundary check, the default build, and saved continuation-report validation are recorded in `verification/session-v58.json`. The status of the optional full main-library audit rerun is recorded separately there; a retained audit must not be mistaken for a fresh one.

Exact theorem types are in `verification/main-goal-statements-v58.json`, `verification/theorem-contracts-v58.json`, and the compiled `verification/GoalBoundaryV58.lean`. The main theorem correspondence review is in `verification/article-correspondence-v58.json`.

The main goals are closed relative to the external inputs. A complete exact statement-by-statement audit of every ancillary article assertion is not claimed.
