# Revision 0.57: actual surface-chart decay

This revision adds **56 checked results in 33 modules**, for **843 main + 1,622 continuation = 2,465 distinct checked results**. All 976 previous Lean files remain byte-identical.

Actual Hausdorff surface-chart Fourier integrals now satisfy curved half-decay and nonstationary inverse-frequency decay, relative to an explicit standard smooth graph area-formula input. The local restriction theorem is retained unchanged. Full-surface `SurfaceTestDecay`, the full surface estimate (8.4), and the named global theorem remain open at localization and cover assembly.

## Borrowed standard input

`SmoothGraphAreaFormulaInput` states only the standard smooth graph area identity over compact coordinate sets:

```text
map (u -> graphPoint u (Phi u))
  ((volume restricted to K).withDensity (ofReal o J))
  = (HausdorffMeasure d) restricted to the graph image of K,

J(u) = coordinateHausdorffFactor d * sqrt(1 + norm(gradient Phi u)^2).
```

This formula is an explicit theorem argument, following the instruction to assume external results. It has not been proved internally. It contains no Fourier decay, oscillatory estimate, partition construction, restriction theorem, recurrence or descent. No new Lean axiom is introduced. The existing local theorem does not require this new input. Five new theorem statements explicitly take the area-formula argument; the remaining additions prove supporting analysis and geometry from their displayed mathematical hypotheses. The exact list is in `verification/assumption-audit-v57.json`.

## Internally proved contributions

The Jacobian is proved smooth and positive. The actual coordinate amplitude includes this Jacobian, the ambient test density, and its spatial partition weight. It is proved smooth and compactly supported; its global norm and vertical derivative budgets follow from compactness.

Exact integral identities transfer the actual Hausdorff surface Fourier integral to coordinates, then to a product integral. The physical phase is the project's `exp(i*inner(x,omega))`, with no extra `2*pi`. Scaled orthogonal alignment of the slicing direction retains its exact horizontal determinant factor `r^m`.

The actual curved chart estimate has one nonnegative coefficient selected before both physical direction and frequency. Its proof derives the amplitude and integrability budgets rather than assuming an oscillatory estimate. Entry points are `exists_actual_surface_chart_half_decay` and `exists_actual_affine_surface_chart_half_decay`.

For a nonstationary phase, `nonstationary_interval_inverse_decay` proves

```text
norm (integral A(t)*exp(i*freq*phi(t)))
  <= (2*M/c + integral norm(A')/c + M*integral abs(phi'')/c^2)/freq,
```

under `freq>0`, `a<=b`, `c>0`, `norm(A)<=M` and `abs(phi')>=c` on the interval. Nonvanishing outside the interval is not assumed. The proof uses a globally smooth regularization, bounds its main term independently of the smoothing parameter, bounds the error quadratically, and removes that error by a proved order argument. Compactness supplies uniform second-phase-derivative budgets for the actual chart version, `exists_actual_surface_chart_inverse_decay`.

Full parameter/angular nonstationary boxes are constructed from actual surface tangents. Orthogonal reflections align nonzero slicing directions with an axis, and a compact curved product box is constructed. The phase curvature argument now handles both normal signs.

Covered regular graph germs retain actual local coverage of the extended surface. Globalizing the height preserves that coverage in every smaller parameter neighborhood. This prevents replacing a locally covering chart by a one-sided graph inclusion.

Actual finite smooth nonnegative partition weights are constructed from a finite open cover of a compact set. Exact weighted reconstruction of the full extended-surface Fourier integral and finite summation of piece bounds are proved. These statements use the complete test-supported surface portion, not merely the original compact patch support.

## Remaining global assembly

1. Combine the covered graph germs, phase boxes and aligned product boxes into compatible actual chart pieces at each point and physical direction, shrinking the complete box into the original surface germ.
2. Prove exact localization of each full-surface weighted integral to its chart piece from the weight's support and the chart's actual local coverage.
3. Construct finite spatial covers and their smooth weights on a common angular neighborhood. Use compactness of the unit sphere to obtain finitely many direction neighborhoods and a uniform coefficient. An angular smooth partition appears unnecessary, but this simplification is a proof plan rather than a checked assembly.
4. Combine the two chart decay rates with the low-frequency L1 estimate to prove `SurfaceTestDecay`, then instantiate the retained conditional global theorem.

## Verification and ledger

Every new theorem was compiled individually and axiom-audited with only `propext`, `Classical.choice`, and `Quot.sound`, without warnings or admissions. The default build and the new combined audit are recorded in `verification/session-v57.json`. The main 843-result axiom report is retained; it was not rerun this session.

`verification/result-ledger-v57.json` records every new theorem's stable Lean identifier, exact hypotheses and conclusion, proof-source hash, import chain and axiom-audit report. Exact scope and open obligations are also in `verification/theorem-contracts-v57.json` and `CONTINUATION_HANDOFF.md`. Counts are not a completion percentage.
