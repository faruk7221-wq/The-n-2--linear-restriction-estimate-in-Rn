# Geometry proof map, updated through revision 0.37

The implicit-chart sections below record revision 0.8; the final section records revision 0.37. This document records what the Lean statements establish. It does not
claim a proof of Theorem 1.1 or of the localized restriction estimate (4.3).
All named declarations below are in the `N2Restriction` namespace.

## Common implicit charts: N2-GEO-013

`smooth_inverse_neighborhood` starts with a smooth forward map on an open
domain, a local homeomorphism, and an invertible derivative at one point.
Continuity of the derivative and openness of the invertible operators give
one open inverse domain on which the inverse is smooth to every finite order.
The neighborhood is chosen before the derivative order.

`local_controlled_submersion_charts` applies this construction to the actual
implicit-function coordinates of a submersion. Compact closed coordinate
balls give all-order derivative bounds for both the inverse and the forward
map evaluated on the inverse-image region. The free subspace is a genuine
derivative kernel at a regular point, and its dimension is recorded.

`compact_controlled_submersion_charts` has the quantifier order

\[
\exists r>0\;\exists B:\mathbb N\to[0,\infty)\;
\forall x\in K\;\exists\text{ a controlled chart at }x.
\]

Thus the radius is independent of the point and of the derivative order.
There is a separate bound \(B(m)\) for each order; no bound uniform in
\(m\) is claimed. Both the source and target radii are controlled.

`compact_finite_controlled_atlas` strengthens the conclusion to an explicit
finite set of chart models. A model remains valid at nearby base points after
halving the radius. Compact induction combines finitely many models, taking
the minimum radius and the maximum bound at each derivative order.

`inverse_derivative_bounds` bounds the inverse differential from above and
below, in the precise form

\[
\|D e^{-1}(y)v\|\le B(1)\|v\|,
\qquad
\|v\|\le B(1)\|D e^{-1}(y)v\|.
\]

These are coordinate-map estimates. The surface-measure Jacobian formula
needed in the localized restriction argument is not formalized here.

## Application to the frame-frequency family

`frameConstraint S (Q,z)` is the concrete pair

\[
(S.\mathrm{defining}(z),\;Q(S.\mathrm{normal}(z))).
\]

`frameFrequencyAdmissibleImage_vertical_regular` derives vertical
surjectivity at every point of the compact admissible family from curvature
and the projection-gap assumption. It does not assume that the normal
residual vanishes. `contDiffOn_frameConstraint` supplies joint smoothness in
the frequency and frame variables.

The parameter is added as an output coordinate. Consequently the inverse
charts preserve that parameter exactly. The output of
`uniform_frameFrequencyAdmissible_finite_atlases` includes one positive
radius, one all-order bound sequence, and one finite bound on the number of
charts for all surface indices. Compactness of the admissible family comes
from the previously proved orthonormal-frame construction, not from a new
compactness hypothesis inserted into the article's geometric conclusions.

## Euclidean thin-set charts: N2-GEO-014

`parameter_parametrization` fixes the parameter and constraint level in a
joint chart. Its free space is vertical: every vector has zero parameter
component. Projection to the physical frequency space is therefore an
isometry on that free space.

`parameter_euclidean_parametrization` uses an orthonormal basis of its image
to obtain ordinary Euclidean coordinates. This change preserves the radius
and derivative bounds. The resulting map is injective on the closed coordinate
ball, is smooth with injective derivative at every point of that ball, and
covers the level set locally at its center.

`geometric_uniform_thin_charts` applies this construction to every supported
frequency tuple and every two-plane satisfying the explicit curvature-scaled
projection-gap condition. At a projected-normal zero it gives a chart in
\(\mathbb R^{n-3}\) for the actual thin set.

`correct_and_recenter` changes the constraint level by less than

\[
\frac{r}{4(B(1)+1)}.
\]

The inverse Lipschitz bound controls the displacement, and the chart remains
controlled with radius \(r/2\). The theorem
`geometric_uniform_correction_and_thin_charts` combines this with the exact
frame-to-plane equivalence. It gives a zero in the fixed smooth extension,
the residual-to-distance bound, and common thin-set chart bounds at that
corrected zero. The corrected zero need not belong to the original support.

## Tangent spaces and extension room: N2-GEO-015 and N2-GEO-016

`parametrized_level_tangent_range` differentiates the level-set identity and
uses derivative injectivity together with the explicitly supplied kernel
dimension. It proves equality of the parametrization's derivative range
with the constraint kernel. The two `ThinChartAt.exists_parametrization_*`
theorems specialize this to the actual thin differential and normal-space
formula (4.2). At admissible supported centers, the required kernel dimension
is already proved by `nearby_thin_kernel_dimension`.

`exists_compact_surface_buffer` constructs a larger compact surface support
inside the fixed extension, containing all surface points within a positive
distance of the original support. `uniform_compact_surface_buffers` makes
that width common across the finite patch collection.

`exists_buffered_geometric_family` replaces the compact supports by those
larger sets while retaining the defining functions, normals, shape operators,
and extended surfaces. This preserves `GeometricHypotheses` because that
definition already quantifies over the whole fixed extended surfaces.

`geometric_uniform_thin_charts_on_surface_buffer` applies the uniform chart theorem to this enlarged compact family. It provides one positive surface buffer width and one chart radius for every admissible zero tuple in that buffer. The plane-gap and zero conditions are evaluated at the extended tuple itself; this theorem does not assume that an arbitrary plane admissible at one tuple remains admissible after moving that tuple.

## Remaining dependencies

The uniform localized restriction estimate in Corollary 4.3 still requires
the tubular coordinate changes and their surface-measure Jacobians, the
appropriate transversality assembly on the extension region, and the
stability and recursion arguments in the external localized restriction
theorem. The new compactness and chart results do not prove those analytic
steps.

The plane-gap condition is explicit at each tuple. The small common frequency partition and its compatibility with the later selected planes still belong to the unfinished analytic/geometric assembly. The new constants and finite atlas are existential; explicit numerical values or an effective chart-construction algorithm are not claimed.

Both fixed-patch local Plancherel bounds are now proved in revision 0.17. Actual rotated atlas packets, energy estimates, support margins, normal alignment, and rapid tails on the original physical ball are also checked; the full packet-decomposition statement still needs the exact original L2 identity and common cap/tube geometry packaged together. Selected-data dimension descent, the recurrence for the actual extension constants, and epsilon removal remain open. `MainLocalGoal` and `MainGlobalGoal` are unproved propositions, not theorems.


## Revision 0.17: packet-axis alignment, N2-GEO-017

`SmoothPatch.graph_tangent_normal` differentiates the original defining-function equation along a smooth rotated graph lying in the extended surface. The positive normal scale then gives orthogonality of every graph tangent to the article's actual normal field.

`graph_normal_axis` identifies the annihilator of those graph tangents algebraically. `SmoothPatch.graph_normal_axis` proves that the original unit normal is a nonzero scalar multiple of the rotated vector `graphPoint (-graphGradient φ u) 1`. `PacketGraphAtlas.packet_axis_normal` applies this identity at every cap center of the constructed buffered atlas. The nonzero scalar allows the unoriented tube direction; no arbitrary replacement normal field is introduced.

These four results are separately audited in `continuation/AtlasPacketsV17.lean`, outside the 807-result main inventory. The main modules `VerticalLevelGraph`, `RegularGraphCover`, and `BufferedGraphChart` construct the regular-level-set atlas and its buffers. Their constants concern a fixed surface, and do not claim uniformity over varying nearby-plane families.


## Revision 0.18: common packet geometry, N2-GEO-018

The revision 0.17 packet-axis alignment results are now in the 843-result main inventory in `AtlasPackets`. New separately checked results in `continuation/PacketGeometryV18.lean` give a common ambient cap-radius bound, a common graph-slope bound, finite segment-length and actual round-tube diameter bounds, and affine normal-line membership. Rotated finite segments are compact and their round tubes are closed. The tube diameter estimate assumes a nonnegative physical radius; the article's width is proved to be at most R in the stated tau range.

The original-input L2 reconstruction is still open; this geometry does not supply that measure-transport identity or the full Lemma 3.2 assembly. Varying nearby-family uniformity and the main restriction theorem remain unproved.


## Revision 0.20 — original-input reconstruction and physical packets

This section supersedes earlier open-status descriptions of the original-input L2 kernel bottleneck and fixed-atlas physical packet assembly. There are **843 main results plus 62 separate continuation results (905 distinct)**; **27 are new in this revision**. The main modules and all five older continuation files are unchanged.

| Stable ID | Checked scope | Source |
|---|---|---|
| N2-PKT-050 | Exact norm-preserving rotated-patch lift; original atlas L2 identity; unconditional packet synthesis to the original input; joint count/energy/uniform-extension reconstruction | `continuation/OriginalInputV20.lean`, `continuation/AtlasInputV20.lean` |
| N2-MEA-019 | Generic finite-cover L2 lifting and faithful isometric ambient embedding of the original surface input | `continuation/AtlasInputV20.lean` |
| N2-PKT-054 | Same physical cap families and original-input choices: counts, cap support, positive margins, normal tube axes, tube diameter, total/selected energy and rapid tails; one threshold before all exponents | `continuation/PhysicalInputV20.lean` |
| N2-PKT-055 | Arbitrary single-index selections: sum/extension interchange, absolute convergence, exact norm-sum reindexing and rapid tails for their actual extension | `continuation/SelectedExtensionV20.lean` |

`PacketGraphAtlas.physical_original_input_data` assumes `0 < τ ≤ 1/2`, which covers the article's `0 < τ < 1/20`. Constants depend on the fixed atlas and τ, not R or the input. The actual round tube radius is `R^(1/2+τ)/10`; its diameter is bounded by `L*R`, and its axis lies on the original surface-normal line at the cap centre. All properties refer to the same chosen cap families and chart inputs. Arbitrary nested selections encode arbitrary chart/cap/modulation subsets; `arbitrary_packet_rapid_tail` additionally states the estimate directly for the single dependent index and the extension of its L2 sum.

`SmoothPatch.physical_original_input_data` also constructs the atlas, so the final surface-level statement assumes only the original smooth patch and the tau bounds.

The canonical `SmoothPatch.hausdorffInput` is proved isometric and norm-preserving. Its extension equals the original extension. Thus reconstruction in ambient Hausdorff L2 preserves the original input, not merely its Fourier integral. `finite_cover_lift_L2` isolates the measure casts at generic measures; `rotated_patch_input_L2` retains the transport equality in its original form to avoid costly kernel conversion. No checker is disabled.

Validation: incremental default build passed (2,964 jobs reported). All 62 continuation results were freshly compiled this session and checked against the exact source inventory, allowing only `propext`, `Classical.choice`, and `Quot.sound`. The prior 843-result main axiom audit is retained because every main module is byte-for-byte unchanged. No proof admissions or custom axioms are counted. Historical failed attempts in `drafts/` remain outside the Lean inventory and are superseded by these checked files.

Remaining obligations: constants uniform over the varying nearby-plane family; the localized restriction estimate (4.3); the geometric recurrence and dimension descent; the external Section 2 inputs; and epsilon removal. **Theorem 1.1 is not proved.**


## Revision 0.21 — grid energy reduction and Kakeya dimension condition

**843 main results + 116 separately audited continuation results = 959 distinct checked results; 54 new.** All 152 main modules and all nine older continuation files are byte-for-byte unchanged from revision 0.20. The header count of 61 in the previous STATUS file was stale; the v20 source inventory and audit correctly contained 62.

| Stable ID | Checked scope | Source |
|---|---|---|
| N2-PKT-056 | Half-open cube volume, disjoint lattice covering, exact finite meeting-grid bound, actual packet-to-infinite-tube covering with fixed width multiple | `continuation/GridGeometryV21.lean` |
| N2-ANA-022 | Disjoint-cell integral comparison, actual whole-grid reduction on the enlarged ball, conditional weighted-Kakeya energy assembly, exact amplitude and scale factors | `continuation/GridEnergyV21.lean` |
| N2-GEO-019 | Exact projection rank loss, independent-vector count in any subspace, identity and inequality (2.4), actual geometric-normal application | `continuation/KakeyaDimensionV21.lean` |
| N2-PKT-057 | Full axis equals actual normal line; original L2 packet weights and arbitrary selected synthesis match the Kakeya weights | `continuation/PacketKakeyaV21.lean` |
| N2-ANA-023 | Finite truncation convergence and extension of a supplied finite-family Kakeya bound to enumerated and arbitrary countable families | `continuation/KakeyaTruncationV21.lean`, `continuation/KakeyaCountableV21.lean` |
| N2-PKT-058 | Polynomial count for b≥1, R≥1, and rapid-error summation over every grid cell meeting the ball | `continuation/GridErrorsV21.lean` |
| N2-ANA-024 | Original-input joint grid estimate, with constants before the inputs and the same chart inputs at every cap scale; weighted Kakeya remains an explicit hypothesis | `continuation/OriginalGridV21.lean` |
| N2-SCL-002 | For fixed enlargement factors and 0<tau<1/2, one threshold gives 1≤b≤Db<R and a fixed enlarged integration ball | `continuation/GridScalesV21.lean` |

The cube definition uses coordinate intervals (q_j-b/2,q_j+b/2]. The integral region is the closed ball of radius R+sqrt(n)b. If w≤Db and a tube meets the C-dilated cube, the full axis tube of radius (D+sqrt(n)(1+C)/2)b covers the cube. For w=r/10 and b=λr, λ≥1, D=1/10 suffices. The complete grid is finite without an assumed finite truncation; its cardinality is at most (2 ceil(R/b+sqrt(n)/2)+1)^n (with the integer-to-natural convention in Lean). At b,R≥1 the real cardinality is at most (sqrt(n)+5)^n R^n.

The integral reduction allows arbitrary packet index sets and infinite nonnegative energies. The finite-to-countable Kakeya passage requires measurable tubes and finite total energy in each family, both matching the actual packet setting. No weighted Kakeya axiom has been added. `actual_packet_lattice_energy_of_kakeya` assumes the explicit weighted integral bound on the enlarged ball and enlarged tubes. The normalization lemma identifies R^eta b^(n-eta)=b^n(R/b)^eta; the positive volume factor is cancelled by a proved nonzero/finite argument. The normal dimension inequality alone does not prove external input 2 or its small-neighborhood uniformity.

**N2-GAP-003 is now conditional with its geometric reduction proved; it is not unconditionally closed. N2-EXT-002 remains external/unimported. Theorem 1.1 remains unproved.** The final section supersedes earlier descriptions of the unformalized cube-covering step. Other remaining obligations include uniform nearby-plane analytic estimates, localized restriction (4.3), the actual recurrence and dimension descent, and epsilon removal.


## Revision 0.22: directional subdivision and explicit Kakeya interface

This revision adds **45** checked results in eleven continuation files. The exact inventory is **843 main + 161 separate = 1004 distinct results**. All 152 main modules and all 18 earlier continuation files are byte-identical to v21. Every continuation result was freshly compiled and axiom-audited. Only `propext`, `Classical.choice`, and `Quot.sound` occur; no admitted proofs or project axioms are present.

| Stable ID | Checked scope | Sources |
|---|---|---|
| N2-GEO-020 | Finite compact subpatches, full-neighborhood normal variation, inherited normal/shape and quantitative geometric hypotheses; reference Gram bound, independence and Kakeya dimension condition | `DirectionalSubdivisionV22.lean` |
| N2-ANA-025 | Actual subpatch-measure input energy and exact extension/L2 reconstruction; finite product expansion; all-positive-exponent integral/seminorm bounds; reductions of local and global restriction | `SubdivisionInputsV22.lean`, `SubdivisionProductV22.lean`, `SubdivisionRestrictionV22.lean` |
| N2-PKT-059 | Constructed buffered atlases, original-normal support of every packet, unit actual axis directions, and straight-tube identity | `DirectionalPacketsV22.lean`, `DirectionalKakeyaV22.lean` |
| N2-ANA-026 | Finite-weight finite-family Kakeya input passes to countable actual packets and the original-input grid estimate | `DirectionalKakeyaV22.lean`, `DirectionalGridV22.lean` |
| N2-ANA-027 | Neighborhood transfer and compact uniformity over supported normal tuples, preserving all external scale parameters; simultaneous geometric subdivision | `UniformDirectionalKakeyaV22.lean` |
| N2-ANA-028 | Literal external-input proposition, open-to-closed integration-region transfer, fixed dilation factor and exact grid loss, eventual open-ball scale admissibility | `ExternalKakeyaInterfaceV22.lean`, `DilatedKakeyaGridV22.lean` |
| N2-ANA-029 | Complete conditional assembly from geometric hypotheses and External input 2 to constructed subdivisions, atlases and the original-input grid estimate | `GeometricOriginalGridV22.lean` |

All listed sources are under `continuation/`. The actual local/global assembly includes empty finite covers and zero inputs through ENNReal arithmetic. For p<=1 the finite-sum factor is 1; for p>1 it is m^(p-1), with m the number of directional tuples. The original L2 input is allocated by the checked disjoint finite-cover construction on each piece's own Hausdorff surface measure.

The compact uniformity argument is not an inference from pointwise finiteness alone: it first proves that a directional estimate transfers to nearby reference tuples after shrinking its directional radius. Compact induction then takes minima of positive radii and maxima of constants. The local external hypothesis retains every scale parameter before this argument is applied. `geometric_subdivision_from_external_kakeya` fixes its subdivision and constant for a chosen positive loss exponent before all admissible R,b and all inputs.

`FiniteDirectionalKakeya` requires each weight to be finite. Finite total actual packet energy supplies that condition on every finite truncation; the previously proved countable passage supplies the full packet family. The external goal uses open balls; the grid integral on a closed ball is covered by a strictly larger open ball, without assuming equality of ball boundaries.

The dilation calculation is
`(alpha R)^eta (beta b)^(n-eta) = alpha^eta beta^(n-eta) b^n (R/b)^eta`.
Thus `directional_packet_grid_dilated_kakeya` displays the fixed dilation factors and cancels the cube volume. For b=lambda R^(1/2+tau), fixed lambda,beta>=1 and 0<tau<1/2, the eventual scale theorem gives admissible tube width and the open ball of radius 2(1+sqrt(n))R. Existing v21 amplitude and input-budget identities give the q0 and P(f)^q0 factors. `geometric_original_grid_bound_from_external_kakeya` joins the construction into one theorem: it chooses subdivision and atlases, then energy constants, then chart inputs, before arbitrary cap scales and admissible physical-grid parameters. Its only external analytic hypothesis is `WeightedKakeyaExternalGoal`; the actual packet integral and directional data are proved. Its conclusion factors the squared energy budgets into a fixed product of energy constants and the original input-norm product raised to q0.

**N2-EXT-002 remains external/unimported; no external Kakeya axiom has been added. N2-GAP-003 remains conditional on that theorem.** The local/global subdivision reductions do not prove restriction for any directional tuple. The nearby-plane analytic uniformity in Remark 4.2 and Corollary 4.3 is a different issue and remains open, as do the geometric recurrence, dimension descent, algebraic external inputs, epsilon removal, and Theorem 1.1.

The final revision section supersedes historical statements that directional subdivision or directional-constant compact uniformization are wholly absent. Build and final inventory verification are recorded in `verification/build-v22.txt`, `verification/new-sources-audit-v22.txt`, and `verification/continuation-audit-final-v22.txt`.


## Revision 0.23: buffered thin charts, Jacobians and stable transversality

This revision adds **35 checked results** in nine continuation files: **843 main + 196 separate = 1039 distinct results**. All 152 main modules and all 29 earlier continuation files are byte-identical to v22. Every continuation result was freshly compiled and its axiom dependencies checked. Only `propext`, `Classical.choice` and `Quot.sound` occur. There are no admitted proofs or project axioms.

| Stable ID | Checked scope | Sources |
|---|---|---|
| N2-GEO-021 | Uniform compact buffer with wedge bound; small-residual correction stays in it; rectangular Jacobian bounds; parameter-preserving inverse differential; actual free Euclidean parametrizations with two-sided derivative and all-order bounds; uniform Jacobian charts and fixed extension buffers | `BufferedThinGeometryV23.lean`, `SliceJacobianV23.lean`, `ParameterSliceJacobianV23.lean`, `ActualThinJacobianV23.lean`, `UniformThinJacobianV23.lean` |
| N2-ANA-030 | Compact buffered thin zero sets; admissible projected-normal regions lie in a C*rho thickening; essential frequency-support transfer for arbitrary measured inputs | `ThinSupportLocalizationV23.lean` |
| N2-GEO-022 | Actual thin-chart normal space together with the other k-1 normals spans the ambient space | `ThinChartTransversalityV23.lean` |
| N2-GEO-023 | Uniform Gram lower bounds survive frequency movement in fixed extension regions; explicit coordinate-size condition for controlled charts; retained Gram implies transversality at a moved point of the same chart | `WedgeStabilityV23.lean`, `MovedChartTransversalityV23.lean` |

All listed sources are under `continuation/`. `geometric_thin_input_localization` uses the explicit set `admissibleThinRegion`: each frequency has a supported tuple witnessing the curvature-scaled plane gap. It does not assert correction for an arbitrary plane. The constants and compact buffers are chosen before plane, thickness and input. Setting rho=C0*mu is permitted when C0*mu is below the fixed threshold.

`sliceJacobian A` is the square root of the determinant of the Gram matrix of the images of the standard Euclidean orthonormal basis under A. Bounded differentials with a common lower norm bound form a compact operator family; this gives positive lower and finite upper Jacobian bounds. `physical_parametrization_bounds` constructs the actual chart, retaining its local coverage, injectivity, all-order derivative bounds and uniform two-sided first-derivative estimates. The external-parameter derivative vanishes along the free slice, so dropping that parameter does not change the relevant norm. `JacobianThinChartAt.to_thinChartAt` checks compatibility with the earlier chart interface.

`geometric_uniform_thin_jacobian_charts_on_buffer` chooses buffer width, chart radius, derivative bounds and positive Jacobian bounds before supported tuples, nearby extended tuples, index and plane. Its plane-gap hypothesis is explicit. Separately, `geometric_buffered_wedge_stability` starts at an admissible original zero-frame tuple and retains its positive Gram bound under small movements; no plane-gap hypothesis is imposed at the moved tuple. `geometric_thin_chart_wedge_persistence` gives the coordinate condition norm(t)<=eta/(M+1) when norm(D phi)<=M. `thin_parametrization_transverse_of_gram` applies the retained nonzero determinant to the actual chart derivative at the moved point. The normal-space dimension and direct-sum checks give the dimensions 3 and k-1 required by External input 1. These statements do not claim that every small-residual correction automatically satisfies a fresh plane-gap inequality.

### Remaining analytic boundary

The proved Jacobians belong to the **n-3-dimensional thin-zero-set slices**. The **n-1-dimensional tubular surface coordinates and their Hausdorff-measure change-of-variables/Fubini identity are not proved**. No equality between the computed Gram Jacobian and a surface density is assumed or asserted. The retained Gram lower bound uses the original normals and two shape images of the plane frame; Pointwise positivity for an actual orthonormal three-frame of the chart normal space is proved; obtaining a common positive lower bound for these normalized determinants still needs an explicit connection (the existing shape-norm bounds are available). Uniform analytic stability and the recursion described in Remark 4.2, including the localized and unlocalized transverse ensembles, are also outstanding. Consequently External input 1 and Corollary 4.3 are not proved by this revision.

The finite product/local/global assembly from v22 remains available. External input 2, the actual geometric recurrence and dimension descent, algebraic external inputs, epsilon removal and Theorem 1.1 remain open. The final revision section is authoritative; earlier coverage sections are historical.

Verification: `verification/build-v23.txt` records the successful default build (2964 jobs). `verification/continuation-audit-run-v23.txt` records the first 185 results in the fresh ordered audit; `WedgeStabilityV23.txt` and `MovedChartTransversalityV23.txt` record the final eleven fresh checks. `verification/continuation-audit-final-v23.txt` validates the complete 196-result inventory. The unchanged 843-result main axiom report is retained after source and audit-script byte comparison, rather than described as rerun.


## Revision 0.24: normalized normals and measured tubular surface charts

This revision adds **35 results in 18 continuation files**: **843 main + 231 separate = 1074 distinct checked results**. All 152 main modules and all 38 earlier continuation files are byte-identical to v23. The full 231-result continuation inventory was freshly compiled and axiom-audited. This section supersedes the earlier descriptions of the current proof boundary.

| Stable ID | Checked scope | Main entry points |
|---|---|---|
| N2-GEO-024 | A uniform raw Gram bound and bounded frame reconstruction coefficients yield a uniform normalized normal-space bound; fixed extension buffers and moved actual thin-chart points are included | `geometric_buffered_normalized_normal_bound`, `geometric_moved_chart_normalized_bound` |
| N2-GEO-025 | Full n-1-dimensional tubular charts, exact affine projected-normal coordinates, uniform surjectivity control, all-order and positive Gram-Jacobian bounds, local coverage, fixed buffers, exact thin strips and n-3-dimensional fibers | `uniform_tubular_chart_bounds`, `geometric_uniform_tubular_charts_on_buffer`, `tubular_normal_strip_preimage`, `tubular_coordinate_kernel_dimension`, `tubular_thin_zero_image` |
| N2-ANA-031 | Uniform shrinking to bi-Lipschitz compact charts; positive bounded measurable coordinate densities with an actual pushforward identity to restricted Hausdorff surface measure | `uniform_controlled_chart_surface_density`, `uniform_tubular_surface_densities`, `uniform_frame_measured_tubular_charts` |

### Quantifiers and geometric scope

The normalized normal-space lower bound is chosen before the index, original supported tuple, admissible frame, moved tuple and orthonormal normal-space basis. The raw normal/shape frame reconstructs from the normalized frame with bounded coefficients. Compactness gives a common positive Gram lower bound. Normal-space membership of the selected normal and shape vectors follows by differentiating the actual thin-level identity. At moved points no fresh plane-gap inequality is required for this normalized bound; a retained raw Gram bound from the original admissible tuple is used.

The tubular coordinate construction works in dimension n-1, fixing the external parameter and the defining-function coordinate while varying both projected-normal coordinates and the n-3 free coordinates. A fixed finite-dimensional coordinate equivalence, uniformly scaled once, provides contraction and lower norm bounds independent of the chart. The resulting linear projected-normal coordinate R satisfies norm(R)<=1 and has preimage witnesses v with norm(v)<=L*norm(w), with common L. The physical inverse slice retains all-order bounds. Its local coverage is proved for every positive coordinate radius, so the subsequent common shrinking preserves local surface coverage.

`geometric_uniform_tubular_charts_on_buffer` requires the curvature-scaled plane-gap condition at the buffered tuple. This is distinct from the moved-chart normalized bound, which uses the original admissible frame and retains its raw wedge by continuity. No claim is made that arbitrary small-residual correction automatically preserves that gap.

### Measure identity and remaining analytic boundary

A bound on the second iterated derivative and a lower first-derivative bound at the center give a common positive shrinking radius and a lower distance bound on the entire coordinate ball. Upper and lower Lipschitz bounds compare the pulled-back Hausdorff measure to Euclidean volume on that compact domain. Radon-Nikodym then supplies a measurable NNReal density bounded above and bounded away from zero almost everywhere. Its pushforward equals Hausdorff measure restricted to the image of the actual parametrization. The density uses the explicit Mathlib Hausdorff normalization factor. It is **not asserted to equal sqrt(det(Gram(D phi)))**.

The density theorem concerns full-dimensional surface measure, unlike v23's n-3-dimensional thin-chart Jacobians. `uniform_frame_measured_tubular_charts` chooses both radii, the all-order control sequence, density bounds and normal-coordinate inverse bound before the frame or frequency. The smaller compact chart also contains a local parametrization of the surface near its center. The density is measurable in its chart coordinate; no joint measurable choice in external plane parameters is asserted.

The projected-normal strip now has an exact linear-coordinate pullback, including the affine center shift. At zero centers the thin zero set in the chart image equals the image of ker(R), whose dimension is n-3. The bounded right-inverse witnesses now yield a continuous linear section valued in the orthogonal complement of the kernel and a product continuous linear equivalence, with both operator norms bounded by L+1. Still open are the coordinate disintegration/Fubini and L2 slicing needed to obtain the thickness gain, their finite chart/input assembly, and the uniform localized restriction argument of External input 1 and Remark 4.2. For q0<=1, ordinary Banach-space Minkowski is not available. Corollary 4.3 and Theorem 1.1 remain unproved, as do the other external-input, recurrence and epsilon-removal gaps recorded earlier.

### Verification

`build-v24.txt` records the default build (2964 jobs). `continuation-audit-run-v24.txt` records a fresh check of all 196 retained continuation results. `new-audit-run-v24.txt` records 29 new results, and `TubularThinCoordinatesV24.txt` the three thin-coordinate checks, and `NormalCoordinateConditioningV24.txt` the three final conditioning/decomposition results. `continuation-audit-final-v24.txt` validates the complete 231-result inventory, source hashes, declaration coverage and standard axiom dependencies. All logs are under `verification/`. The 843-result main report is retained only after byte-for-byte comparison of every main module and the root/audit/toolchain files against v23.


## Revision 0.25: measured normal-coordinate slicing and thickness

This revision adds **44 results in 20 continuation files**: **843 main + 275 separate = 1118 distinct checked results**. All 152 main modules and all 56 prior continuation files are byte-identical to v24. All 275 continuation results were freshly compiled and axiom-audited. This section supersedes earlier statements about disintegration being entirely open.

| Stable ID | Checked scope | Main entry points |
|---|---|---|
| N2-ANA-032 | Exact positive Haar factor for linear coordinates; uniform two-sided bounds; fixed n-3-dimensional kernel coordinates; weighted Tonelli and complex Fubini | `map_linear_coordinates`, `uniform_tubular_product_measure_coordinates`, `normal_fiber_energy_identity`, `integral_normal_coordinates` |
| N2-ANA-033 | Zero-extended measured chart inputs; exact surface energy and integral identities; finite L2 fibers; affine support and scalar thickness gain; density multiplier and actual Haar-weighted amplitude bounds | `measured_chart_normal_slicing`, `measured_chart_integral_slicing`, `measured_chart_density_amplitude_bound`, `actual_amplitude_thickness_bound`, `measured_compact_chart_L2_integrable` |
| N2-GEO-026 | Compact actual thin-fiber domains, exact projected-normal levels, inherited injectivity and uniform derivative bounds | `normalFiberDomain_compact`, `tubular_fiber_normal_identity`, `tubular_fiber_injOn`, `tubular_fiber_derivative_bounds`, `level_chart_normal_contains_adjoint_shape` |

### Coordinate factors and uniformity

Write e for the linear equivalence from full surface coordinates to the pair (u,v), with u in R x R and v in R^(n-3). Its first component is exactly R. The varying kernel is replaced by a fixed Euclidean space using an orthonormal basis; this does not enlarge either operator bound. Both norms are bounded by L+1, where L is the existing common bound for right-inverse witnesses. The construction works also when n=3 and the thin coordinate space has dimension zero.

`coordinateMeasureFactor e volume (volume.prod volume)` is a strictly positive finite NNReal c, and map(e,volume)=c*(product volume). Thus the full integral of h equals c times the iterated integral of h(e^{-1}(u,v)). The proof uses Haar uniqueness. Uniform upper and lower bounds come from the inclusions between fixed balls forced by the forward and inverse operator bounds, before choosing e. No unproved determinant or coarea identity is used.

### Surface inputs, weighted energy and extension amplitudes

A measurable density J on a compact chart K extends by zero to W on the full Euclidean domain. A measurable physical input g likewise gives F agreeing with g composed with the chart on K and zero outside K. Agreement is pointwise, including the boundary. The almost-everywhere density upper bound persists under this extension. The proved pushforward to restricted Hausdorff surface measure gives the exact identity

    surface energy = integral |F|^2 W dx
                   = c integral_u integral_v W(e^{-1}(u,v)) |F(e^{-1}(u,v))|^2 dv du.

Finite total energy gives finite fiber energy for almost every u. For integrable physical amplitudes the analogous complex-valued Fubini identity uses c W F in the product coordinates. A bounded density on a compact chart defines a finite measure, so an L2 surface input is integrable on that chart. The stated chart-transfer theorems take measurable representatives; a global quotient-space L2 operator and finite partition assembly are not claimed here.

### The checked scalar thickness gain

An affine projected-normal identity Q(phi(x))=a+R(x), together with strip support of g, forces F(e^{-1}(u,v)) to vanish outside the normal-coordinate ball centered at -a. The max-norm ball in R x R has area (2r)^2. Cauchy-Schwarz therefore bounds the integral of square roots of fiber energies by 2r times the square root of the total energy. This holds for extended nonnegative integrals and needs no Banach-space Minkowski inequality.

The distinction between weighted energy and the actual amplitude is explicit. The extension amplitude contains the density W, so its squared energy contains W^2. The upper bound W<=C gives integral |WF|^2 <= C integral W|F|^2. `measured_chart_density_amplitude_bound` expresses the resulting thickness bound using the original Hausdorff surface energy. `actual_amplitude_thickness_bound` also places c in the complex amplitude: its bound has the additional factor sqrt(b), for any upper bound c<=b. The previous theorem supplies such a b uniformly.

### Actual fibers and remaining boundary

The actual fiber domain is {v : e^{-1}(u,v) in K}. It is compact, including when it is empty. Its physical parametrization has exact projected-normal level a+u and inherits injectivity from the full chart. `tubular_fiber_derivative_bounds` proves pointwise smoothness, all-order bounds B(m)*L^m and the lower first-derivative bound with constant L*M, uniformly over u, wherever the full chart satisfies its controls. `level_chart_normal_contains_adjoint_shape` additionally proves that at arbitrary projected-normal levels the physical normal and the adjoint shape images of H belong to the parametrized level normal space. There is no zero-projection hypothesis. Two further lemmas show that the adjoint shape annihilates N and, on tangent inputs, differs from the ordinary shape only by a multiple of N. They do not prove a uniform raw Gram bound for the new frame on arbitrary nonzero levels. The corresponding quantitative transversality and analytic estimates for the nonzero level family remain open. The integrals on these fibers use Euclidean thin-coordinate measure with the explicit full-chart weight. No equality with intrinsic thin-fiber Hausdorff measure is asserted.

Still required are the full uniform analytic eligibility and estimates for the nonzero fiber family, the localized multilinear restriction theorem (External input 1), its perturbative Kakeya/recursion stability in Remark 4.2, and the supported-input and finite chart assembly of Corollary 4.3. Uniform geometry and the scalar Cauchy-Schwarz gain do not imply the multilinear Lq0 estimate. The main recurrence, external algebraic/Kakeya inputs, epsilon removal and Theorem 1.1 also remain open. No new axiom packages any of these gaps.

### Verification

`continuation-audit-run-v25.txt` records a fresh compilation and axiom check of all 231 retained continuation results. `new-audit-run-v25.txt` records the ordered fresh compilation of 41 new results; `NonzeroFiberNormalsV25.txt` records the three final nonzero-level/adjoint normal-space results. `continuation-audit-final-v25.txt` validates the full 275-result inventory, source hashes, declaration coverage and standard axiom dependencies. `build-v25.txt` records the passing default build (2964 jobs). The 843-result main axiom report is retained after every main module and the root/audit/toolchain sources were compared byte-for-byte with v24.


## Revision 0.26: measured nonzero fibers with uniform transversality

This section supersedes the v25 statement that quantitative transversality at nonzero levels is open. The analytic localized restriction estimate remains open.

There are **40 new results in 20 files**, giving **843 main + 315 separate = 1158 distinct checked results**. All 152 main modules and 76 prior continuation sources are byte-identical to v25. All 315 continuation results were freshly compiled and axiom-audited.

| Stable ID | Checked scope | Main entry points |
|---|---|---|
| N2-GEO-027 | Adjoint coercivity and inverse, arbitrary-level exact normal spaces, raw and normalized uniform Gram bounds | `nearby_reverse_adjoint_coercive`, `nearby_reverse_adjoint_inverse`, `thin_adjoint_normal_space`, `nearby_level_chart_normal_eq_adjoint_span`, `geometric_nonzero_chart_normalized_bound` |
| N2-GEO-028 | Prescribed frames and actual compact nonzero fiber geometry in one common measured family | `geometric_pairFrame_admissible`, `geometric_actual_fiber_normalized_bound`, `geometric_measured_transverse_fibers` |
| N2-ANA-034 | Strictly interior measured tubular charts with a prescribed physical image buffer | `uniform_tubular_surface_densities_shrunk`, `uniform_frame_measured_tubular_charts_shrunk` |

### Why the adjoint removes the zero-level restriction

Let W be the common tangent two-plane, H a nearby two-plane, and A the ambient shape operator. The existing quantitative inverse J of P_H A restricted to W has norm at most 2/kappa. Pairing P_W A†h with Jh gives norm(h)^2. Cauchy-Schwarz therefore proves

    (kappa/2) norm(h) <= norm(P_W A†h),  h in H.

This proof needs equal dimensions, the curvature lower bound on W and the curvature-scaled plane-gap condition. It does not need H tangent or the ambient operator A symmetric. It gives a quantitative reverse inverse and the direct-sum transversality of W-perp and A†(H).

The full frame consists of the k original normals and two adjoint shape images. Its independence follows by projection to W. The admissible frame set is compact without imposing projected-normal zero; continuity of adjoints and Gram determinants yields a common positive Gram lower bound. Uniform continuity extends the bound to nearby surface tuples without a fresh plane-gap condition at the moved tuple. Bounded frame expansion then gives a common lower bound after replacing the selected three normal vectors by any orthonormal basis of the actual fiber normal space.

`thin_adjoint_normal_space` proves that the constraint-kernel normal is exactly span(N) + A†(H) at arbitrary projected-normal levels. The parametrized versions identify this with the actual chart normal space when the derivative is injective and the kernel has the expected dimension. The geometric curvature assumptions supply that dimension. These statements do not identify A with its adjoint globally.

### The same actual fibers and measures

The affine normal-coordinate map is retained exactly. Frame-coordinate equality is proved equivalent to intrinsic thin-constraint equality. The sliced full chart is therefore locally a level chart at every interior full-chart point, including nonzero levels, and injectivity of its derivative follows from the full derivative and the linear coordinate equivalence.

The new measured chart construction accepts any positive physical buffer size. It first restricts to a radius controlled by the buffer size and the first-derivative bound, then applies the existing uniform surface-density construction. The resulting compact radius rho is strictly smaller than the smooth radius r, and the whole compact chart image lies in the requested buffer. Exact Hausdorff pushforward, common positive density bounds, all-order controls and local coverage are preserved. Strict containment is what justifies local derivative arguments on the compact domain boundary.

`geometric_measured_transverse_fibers` selects all constants before the supported frequency tuple, selected index, nearby frame and normal level. It constructs one full parametrization and one normal/thin linear equivalence with uniformly bounded forward/inverse norms and Haar factor. Its density pushes forward to the original restricted Hausdorff surface measure. For every normal level u the actual domain {v : e^{-1}(u,v) in closedBall(0,rho)} is compact and the restricted parametrization is injective. Every point has the exact affine normal level, uniform all-order bounds B(m)*(L+1)^m, a lower derivative bound with constant (L+1)*B(1)*L, and the common normalized Gram bound against the other factors' normals in the same buffer. Empty fibers are allowed, as is the zero-dimensional thin coordinate case n=3.

### Distance to the actual zero-level reference

`FiberZeroDistanceV26.lean` connects the same coordinates to spatial localization on the surface. At fixed thin coordinate v, the distance between fibers u and w is at most M*L*dist(u,w), where M bounds the full derivative and L bounds the inverse linear coordinate map. For affine center a, the actual zero projected-normal reference is u=-a. The theorem proves its intrinsic thin constraint is zero and gives physical distance at most M*L*delta when norm(a+u)<=delta. The zero reference remains in the full chart whenever the starting point is in radius rho and L*delta<=r-rho. This explicit margin condition is retained; it is not silently assumed for all thicknesses. `tubular_strip_infDist_zero_set` combines these facts into the distance-to-zero-set condition used in localized restriction. These four results are tracked by N2-GEO-029.

### Supported input transfer and conditional finite-chart assembly

`finiteCoverInput_inherits_support` and `atlasPatchInput_inherits_support` prove that disjoint chart assignment and transfer to the actual chart measure preserve any original frequency support condition, including a projected-normal strip. Each chart input has norm at most the original norm; the previously proved sum-of-squares budget is retained.

`atlas_product_reconstruction` expands the original product into the finite set of chart tuples. `atlas_product_integral_bound` integrates this identity with the explicit finite power loss, for every p>0. `atlas_assemble_local_estimates` consumes a stated estimate for every tuple and yields a bound using the original surface L2 norms. For p<=1 the finite power loss is one. This establishes the finite-sum assembly step for supplied chartwise estimates, without asserting those still-unproved estimates or an integral Minkowski inequality. `atlas_assemble_quasinorm_estimates` and `atlas_assemble_uniform_quasinorm_bound` give the corresponding quasi-norm statements, matching the article. A common local constant C gains the explicit factor (finitePowerLoss(number of tuples,p) * number of tuples)^(1/p), with original input norms. These results are tracked by N2-ANA-035.

### Remaining analytic boundary and verification

This is geometric and measure preparation for the uniform localized theorem, not a proof of that theorem. External input 1 and the perturbative Kakeya/wave-packet recursion of Remark 4.2 remain unformalized. The checked conditional finite-chart assembly still must be connected to an actual uniform localized estimate on the measured geometric family; finite geometric constants alone do not provide that estimate. Corollary 4.3 and Theorem 1.1 remain open. No continuous/quasi-Banach Minkowski step is assumed. No intrinsic thin-fiber Hausdorff formula or Gram-Jacobian/RN-density equality is introduced.

`continuation-audit-run-v26.txt` records the fresh 275-result retained audit; `new-audit-run-v26.txt` records the ordered 28-result geometry/measure compilation followed by eight atlas support/assembly results and four zero-reference distance/margin results (40 in total); `continuation-audit-final-v26.txt` validates the complete 315-result inventory, hashes, declaration coverage and standard axiom dependencies. `build-v26.txt` records the default build. The main 843-result audit is retained only after byte comparison with v25.


## Revision 0.27: uniform zero-reference localization and supported atlas assembly

This section is authoritative for the current revision. There are **27 new results in twelve files**, giving **843 main + 342 separate = 1185 distinct checked results**. All 152 main modules and 96 prior continuation sources are byte-identical to v26. All 342 continuation results were freshly compiled and axiom-audited. The default build passes.

| Stable ID | Checked scope | Main entry points |
|---|---|---|
| N2-GEO-030 | Explicit interior zero reference and one common localization threshold, with measured geometry | `normalReference_zero_localization`, `geometric_measured_localizing_fibers` |
| N2-GEO-031 | Actual fiber derivative differences and common finite-order perturbation thresholds | `tubular_fiber_jet_distance_bound`, `tubular_zero_reference_jet_bound`, `tubular_zero_reference_finite_jet_stability` |
| N2-GEO-032 | Compact controlled center cover and common physical coverage radius for a fixed model | `compact_controlled_center_cover`, `compact_affine_slice_uniform_coverage` |
| N2-ANA-036 | Physical strip support localization, actual atlas inputs and finite local cover extraction | `geometric_uniform_localized_support`, `atlasPatchInput_localized_support`, `geometric_finite_localization_atlas`, `geometric_localized_surface_inputs` |
| N2-ANA-037 | Selected-factor conditional assembly retaining a supplied thickness gain | `localized_atlas_thickness_assembly` |

### Interior reference on the same measured charts

For a linear normal/thin coordinate equivalence e and affine normal center a, define

    normalReference(e,a,t) = e^{-1}(-a, (e t).thin).

The map is continuous and idempotent. Its displacement is bounded by the inverse coordinate norm times norm(a + (e t).normal). A strict inequality L*delta < r-rho places it in the open smooth ball of radius r when t lies in the compact ball of radius rho. A common positive threshold is chosen simultaneously for this margin and the physical transversality buffer. The measured chart is shrunk into half the buffer; the reference displacement uses the remaining half.

`geometric_measured_localizing_fibers` selects all constants before the supported frequency tuple, selected index and nearby orthonormal frame. It retains the exact Hausdorff density identity, common positive density bounds, coordinate Haar-factor bounds, compact fiber domains, injectivity and local coverage. At every sufficiently small normal residual it gives the actual interior reference, intrinsic thin-constraint zero, physical distance bound and buffer membership. The zero fiber at that reference has uniform all-order derivatives, a quantitative lower derivative bound, and a normalized Gram lower bound against the other surface normals in the same buffer. The arbitrary nonzero fiber properties from v26 are retained.

### Quantitative derivative perturbations

On a convex full-chart domain, a bound M on the (m+1)-st derivative bounds variation of the m-th derivative by M times displacement. Restricting both full jets through the same affine thin slice costs at most L^m. Thus the actual sliced derivatives at two normal levels u and w satisfy

    norm(D^m psi_u(v) - D^m psi_w(v)) <= B(m+1) * L^(m+1) * dist(u,w).

The zero-reference version takes w=-a and uses the strip residual together with the explicit chart margin. `geometric_measured_localizing_fibers` includes this estimate at its actual zero reference. No unidentified model chart replaces the measured chart.

`exists_finite_jet_threshold` bounds any finite list of derivative constants using their absolute-value sum and chooses a common positive thickness below a prescribed geometric threshold. `tubular_zero_reference_finite_jet_stability` chooses its threshold before e and phi; it depends only on r, rho, L, B, the finite order N and tolerance epsilon. All derivatives through N are then epsilon-close. This is a geometric perturbation statement, not a proof that a restriction-estimate constant is stable under these perturbations.

### Support and finite atlas interface

The frame-coordinate norm uses the maximum norm on R x R. It is bounded by the Hilbert norm of the orthogonal projection; equality is not assumed. An original physical strip of width delta therefore satisfies the frame-coordinate threshold when delta <= tau.

`frequencySupport_restrict_transfer` combines chart membership almost everywhere with a pointwise support implication on that chart. `projected_strip_localized_support` uses actual reference witnesses to prove infDist(x,Z) <= D*delta on essential support. `atlasPatchInput_localized_support` applies this result after the disjoint chart assignment and transfer to the actual chart measure. The stronger `projected_strip_witness_support` and `atlasPatchInput_witness_support` retain an actual y in Z with dist(x,y) <= D*delta. The final analytic assembly and surface-input synthesis use this witness-based condition: when Z is empty it forces the piece to vanish almost everywhere. They do not rely on the convention infDist(x,empty)=0.

`geometric_uniform_localized_support` constructs compact physical chart images and sets of actual zero-reference points. Constants eta, tau and D precede the supported tuple, nearby frame, measure, delta and input function. Every target point lies on the extended surface, has zero thin constraint and stays in the common buffer. Relative local coverage of the original surface is retained.

`compact_localization_atlas` extracts a finite chart family from relative local coverage; it does not require the compact chart carriers themselves to be open. `geometric_finite_localization_atlas` applies this to a fixed selected support and frame. Its hypothesis explicitly requires the curvature-scaled gap for every tuple formed by varying the selected support point. It retains one common localization threshold and distance constant. Its chart count is finite but may depend on the frame; a uniform count for this particular measured/localized atlas is still to be proved. The earlier finite chart-model count is not silently identified with this new cover.

`compact_affine_slice_uniform_coverage` supplies the next coverage ingredient: for one fixed chart model and a compact set of centers inside its source, one positive physical radius works for every center and every affine slice with the common lower norm bound and exact chart formula. The radius is chosen before the slice map and parametrization. The proof uses uniform continuity at the compact center set and a positive source buffer. `compact_controlled_center_cover` now constructs the compact center refinement for a finite controlled atlas, retaining chart identity, all derivative bounds and half the original radius. It uses neighborhood stability of Controls and a finite compact refinement of the resulting open cover. To obtain the full uniform measured-atlas count, combine the finite family of coverage radii, retain the exact affine formula and measured data, and choose a fixed finite net of the physical support.

`geometric_localized_surface_inputs` completes the selected-factor decomposition on the article's actual surface measure. After choosing the finite atlas, it works for every delta below the common threshold and every L2 input in the physical strip. It constructs Hausdorff chart-measure L2 pieces with total squared norm at most the original squared norm, preserves original surface support, supplies zero-target neighborhood support, and exactly reconstructs the original extension. The chart family is chosen before delta and the input. This is unconditional geometric/input preparation under the stated curvature and gap hypotheses; it proves no local analytic bound.

### Conditional analytic assembly and the remaining boundary

`localized_atlas_thickness_assembly` requires a localized estimate for each chart tuple and each family of chart inputs whose selected factor has, at almost every nonzero input point, an actual zero-target witness within distance D*delta. The hypothesis includes a finite common local constant C times delta. The conclusion is the original extension-product quasi-norm bound with the original L2 norms, the same C*delta gain, and the explicit factor

    (finitePowerLoss(number of chart tuples,p) * number of chart tuples)^(1/p).

It works for every p>0, including p<=1, using the already checked finite-sum power argument. It assumes no continuous quasi-Banach Minkowski inequality. The localized estimate is a genuine hypothesis, not an axiom or a theorem proved by this revision.

The simplified finite-atlas and input-decomposition theorems retain compact carriers, zero-target localization and input identities; they do not yet bundle all parametrization and density data from the stronger measured-family theorem. The generic extraction theorem accepts an arbitrary property P, so that data can be retained in the next construction.

The selected-factor atlas must also be combined with subdivisions of the other factors inside the common transversality buffers. Its existence alone is not a joint transverse product atlas.

To obtain the plane-independent constant of Corollary 4.3, the measured/localized atlas still needs a uniform chart-count bound, and External input 1 needs its uniform analytic proof. Remark 4.2 specifically invokes stability of the perturbative Kakeya theorem and wave-packet recursion; the new finite-order geometric closeness does not replace those arguments. Theorem 1.1 and other previously listed external/recurrence/algebraic/epsilon-removal gaps remain open. No intrinsic thin-fiber Hausdorff or Gram-Jacobian/RN-density identity is introduced.

### Verification

`continuation-audit-run-v27.txt` records the fresh audit of 315 retained results. `new-audit-run-v27.txt` records the 27 new results compiled in dependency order. `continuation-audit-final-v27.txt` checks all 342 declaration inventories, source hashes, compiler outputs and axiom dependencies. `build-v27.txt` records the default build. The main 843-result audit is retained after byte comparison with v26; it is not described as a fresh main audit.


## Revision 0.28: uniformly finite measured product atlases

This section is authoritative for the current revision; earlier sections are historical. There are **25 new results in seventeen files**, for **843 main + 367 separate = 1210 distinct checked results**. All 152 main modules and 108 prior continuation sources are byte-identical to v27. All 367 continuation results were freshly compiled and axiom-audited; the default build passes.

| Stable ID | Checked scope | Main entry points |
|---|---|---|
| N2-GEO-033 | Uniform physical coverage and fixed finite count with measured charts retained | `finite_controlled_uniform_slice_coverage`, `uniform_frame_measured_covering_charts`, `uniform_measured_tubular_atlases` |
| N2-GEO-034 | Joint product-atlas transversality, measured coordinates and zero references | `geometric_uniform_measured_atlas`, `uniform_chart_normal_coordinates`, `uniform_bundled_zero_targets`, `ChartNormalCoordinates.compact_zeroTarget` |
| N2-ANA-038 | Finite frame-independent assembly cost on original surface measures, conditional on a local estimate | `finite_atlas_cost_mono`, `uniform_cardinality_thickness_assembly`, `measured_surface_thickness_assembly` |
| N2-ANA-039 | Actual chart L2 energy, almost-everywhere finite fibers and exact extension slicing | `MeasuredTubularChart.normal_slicing_L2`, `MeasuredTubularChart.extension_slicing_L2` |

### Uniform coverage without losing the measured chart

The v27 compact-center refinement is now combined over finitely many chart models. `finite_controlled_uniform_slice_coverage` supplies one positive physical radius before choosing the center, affine slice map or parametrization. The selected model retains Controls at half the original smooth radius. Empty model families are handled vacuously rather than taking a nonexistent minimum.

`AffineTubularSlice` retains the actual linear slice map, its norm and lower norm bound, its range inclusion for the relevant coordinate differences, and the exact formula for the actual parametrization. `uniform_tubular_chart_bounds_with_slice` and `uniform_tubular_surface_densities_with_slice` retain this witness through the full derivative and Hausdorff density construction. The physical coverage proof uses that witness, not a second unidentified parametrization.

`uniform_frame_measured_covering_charts` combines these ingredients over the compact admissible frame-frequency set. Its common physical radius delta is positive and selected before the frame-frequency point. Every extended-surface point within delta of the center lies in the image of the open parameter ball of radius rho. The larger smooth radius r, all derivative bounds, lower derivative bound, density bounds and exact pushforward identity are retained on the same chart.

`MeasuredTubularChart` bundles this data. Its carrier is the image of the closed rho-ball; the carrier is compact and lies on the extended surface when rho <= r. `uniform_measured_tubular_atlases` chooses a finite delta-net of each original compact support, then constructs a measured chart at each fixed center for every admissible frame. The centers, counts m_i and common N are chosen before the frame. Each m_i <= N and the actual chart carriers cover the original support. This closes the uniform measured-atlas count gap recorded in v27.

### Joint transversality and zero references

`ChartNormalCoordinates` retains the actual equivalence from full surface parameters to two normal coordinates and the remaining thin coordinates, the exact normal-coordinate identity, both operator bounds, and positive common lower/upper Haar-factor bounds. `uniform_chart_normal_coordinates` chooses the factor bounds before all chart choices.

`geometric_uniform_measured_atlas` first selects the physical transversality buffer eta and Gram bound a. It constructs all measured charts inside eta/2, then selects a common positive strip threshold tau and displacement constant D. For each sufficiently small normal residual, the same chart's explicit zero reference stays strictly inside the smooth radius r, lies on the extended surface, has zero thin constraint, is within D times the actual residual, and remains within eta of its center.

For any chart tuple and selected factor, the actual thin-fiber normal space has an orthonormal basis whose Gram determinant with the other surface normals is at least a. The other points range over their **actual chart carriers**, which lie inside eta/2. The selected fiber point may be outside its compact carrier but must lie in the open smooth chart and within eta of its center; the explicit zero reference satisfies these requirements. This closes the joint buffer-compatibility gap for these hypotheses.

The quantifiers matter. The geometric product-atlas theorem assumes every original support is nonempty and requires the curvature-scaled gap bound for every supported frequency tuple and every selected index. Its constants, fixed centers and counts precede the orthonormal frame q. No assertion is made that such a frame exists for arbitrary unsubdivided supports. Applying this theorem to the article's sufficiently small subdivisions still requires verifying the stated admissibility hypotheses there. Nonempty supports prevent deriving admissibility from a vacuous geometric tuple hypothesis. `surface_product_zero_of_empty_support` separately proves that if any original support is empty, the actual original extension product is identically zero for every family of L2 inputs. Thus this case does not need an admissible geometric atlas.

`ChartNormalCoordinates.zeroTarget` is the image of the explicit reference map over the compact parameter carrier restricted to the fixed maximal strip tau. The target is independent of the eventual smaller strip and input function. `uniform_bundled_zero_targets` gives intrinsic zero-level membership, buffer membership and actual nearby witnesses with common tau and D. `compact_zeroTarget` proves compactness whenever references remain in the smooth chart. The strip's closedness follows from the affine normal identity; no unsupported global regularity assumption on the extended normal field is used.

### Conditional assembly on the original surface measures

The number of chart tuples is at most N^k. `finite_atlas_cost_mono` bounds the finite-sum cost monotonically, and `finite_atlas_cost_ne_top` proves the explicit cost is finite for p>0. Thus the supplied local estimate assembles with cost

    A(N,k,p) = (finitePowerLoss(N^k,p) * N^k)^(1/p).

`uniform_cardinality_thickness_assembly` uses this common bound while transferring original projected-normal strip support to witness neighborhoods of the zero targets. It works for every p>0, including the quasi-Banach range, and preserves a supplied finite C*delta gain and the original L2 norms.

`measured_surface_thickness_assembly` instantiates that interface with the article's original Hausdorff surface measures, the bundled chart carriers, actual coordinate maps and their fixed zero targets. Compact carriers supply measurability and the checked original-surface finiteness theorem supplies the L2 input setting. The existing disjoint atlas-input construction supplies support transfer, norm budgets and exact extension reconstruction. The theorem does not replace these inputs with abstract unrelated chart functions.

Its remaining local hypothesis is explicit: for every chart tuple and every family of chart-measure L2 inputs with the selected factor supported within distance D*delta of an actual zero target, the extension-product quasi-norm is bounded by C*delta times the product of L2 norms. The conclusion is the original-surface estimate with A(N,k,p)*C*delta. To obtain Corollary 4.3, one must still prove this local hypothesis uniformly with the required scale/loss dependence and verify the article's admissibility setup. This is the analytic content of External input 1 and Remark 4.2, not a consequence of finite atlas extraction alone.

The uniform local analytic estimate, perturbative Kakeya and wave-packet recursion stability, Corollary 4.3 and Theorem 1.1 remain open. No intrinsic thin-fiber Hausdorff/Gram-Jacobian/Radon-Nikodym formula, global continuous normal-frame choice, joint measurable family selection, or new smooth frequency partition is asserted.

### Exact slicing of the actual chart inputs

`MeasuredTubularChart.finite_surface_carrier` proves that each actual chart carrier has finite Hausdorff measure in the article's dimension n-1. `surface_mass_le` additionally bounds the actual carrier mass by C times the volume of the fixed parameter ball, uniformly in the frame and center. This supplies a common mass constant for bounded-scale estimates; it does not supply the strip-thickness gain. The finiteness proof uses its bounded coordinate density and explicitly reconciles the natural-number dimension n-1 with real subtraction under 1 <= n.

`normal_slicing_L2` applies the measured normal-coordinate disintegration to every actual chart-measure L2 input. It constructs measurable coordinate data, preserves the original surface energy exactly with the Haar normalization, proves finite thin-fiber energy for almost every normal coordinate, and retains the scalar linear strip-width bound. This estimate concerns energy; it does not justify interchanging a quasi-Banach norm with a continuous integral.

`extension_slicing_L2` gives the exact complex-valued Fourier extension formula in the same normal/thin coordinates. It chooses one measurable density and input amplitude before the physical point x, agrees with the actual chart input on the compact parameter domain, and vanishes outside it. For every x the oscillatory coordinate amplitude is integrable and its iterated integral, with the exact Haar factor, equals the original chart extension. The phase uses the actual parametrization. This supplies the concrete coordinate input to the future local analytic proof without making an intrinsic thin-fiber Hausdorff identity claim.

### Verification

`continuation-audit-run-v28.txt` records the fresh audit of 342 retained results. `new-audit-run-v28.txt` records 25 new results compiled in dependency order. `continuation-audit-final-v28.txt` checks all 367 declaration inventories, hashes, compiler outputs and axiom dependencies. `build-v28.txt` records the default build. The 843-result main axiom report is retained after byte comparison, not described as a fresh main audit.


## Revision 0.29: actual strip inputs, bounded-scale gain and L2 fibers

This section is authoritative for the current revision; earlier sections are historical. There are **45 new results in nineteen files**, giving **843 main + 412 separate = 1255 distinct checked results**. All 152 main modules and 125 prior continuation sources are byte-identical to v28. All 412 continuation results were freshly compiled and axiom-audited; the default build passes.

| Stable ID | Checked scope | Main entry points |
|---|---|---|
| N2-GEO-035 | Compact physical strips, bounded coordinate support and quadratic strip volume/mass | `MeasuredTubularChart.compact_frame_strip`, `coordinate_strip_volume_le`, `MeasuredTubularChart.uniform_frame_strip_mass` |
| N2-ANA-040 | Essentially supported actual inputs and common coordinate amplitudes | `measurable_supported_representative`, `MeasuredTubularChart.projected_strip_representative`, `exists_strip_chart_amplitude`, `fixed_chart_amplitude_extension` |
| N2-ANA-041 | Uniform original-surface thickness gain at bounded scales | `uniform_surface_strip_extension_bound`, `uniform_surface_strip_product_bound`, `uniform_bounded_radius_strip_product`, `geometric_bounded_radius_strip_product` |
| N2-ANA-042 | Actual L2 thin-fiber inputs, norm budgets and integrable extension reconstruction | `StripChartAmplitude.fiberInput_energy_bound`, `StripChartAmplitude.fiberInput_thickness_bound`, `StripChartAmplitude.extension_fiberInput`, `StripChartAmplitude.fiber_extension_integrable` |

### Essential support is not pointwise support

The v25 density-amplitude estimate required a globally measurable function with pointwise strip support. The original data are L2 equivalence classes and have only essential support. This revision connects those settings explicitly.

`MeasuredTubularChart.compact_frame_strip` proves compactness of the physical chart strip by identifying it with the image of a compact parameter set. On the parameter ball the normal coordinate is exactly affine, so its strip is closed. No global measurability or continuity of the extended normal field is assumed.

`measurable_supported_representative` uses a measurable indicator to replace an essentially supported function by an everywhere supported representative, preserving its almost-everywhere class. `strip_representative` applies this to the actual Hausdorff chart measure and includes chart membership. `projected_strip_representative` starts with the article's orthogonal-projection condition and uses the inequality between the frame-coordinate norm and projected-normal norm. These norms are not assumed equal.

### One choice of coordinate data retains all identities

`StripChartAmplitude` bundles a pointwise supported representative, the zero-extended nonnegative density and complex coordinate input, their measurability and pointwise parameter identities, the almost-everywhere density bound, affine normal-strip support, exact original surface energy, the density-amplitude thickness bound, and the exact Fourier extension formula for every physical point. `exists_strip_chart_amplitude` constructs this bundle from an actual chart L2 input with essential frame-strip support.

All these statements concern the same coordinate functions. `fixed_chart_amplitude_extension` allows the exact Fubini formula to be applied to an already chosen density and amplitude, rather than introducing unrelated functions for the energy and extension statements. The representative has the same original L2 energy and extension by almost-everywhere equality. The coordinate functions are chosen before the physical point x.

`StripChartAmplitude.coordinate_support` bounds both normal and thin coordinates of every nonzero input point. If the normal coordinate is u and the thin coordinate is v, then

    norm(Q N(z) + u) <= epsilon,
    norm(v) <= (L+1)*rho.

The same thin ball works independently of the frame and input once the common chart constants have been selected. The density-multiplied fiber amplitudes have total Haar-normalized energy at most C times the original chart energy, and almost every fiber has finite L2 energy.

### Quadratic strip mass and a pointwise thickness gain

`coordinate_strip_volume_le` puts the image of the parameter strip inside the product of a normal closed ball and the fixed thin ball. Exact measure transport gives a Haar factor, and the two scalar normal coordinates use the maximum norm. Their ball has area exactly (2*epsilon)^2, interpreted with ENNReal.ofReal for arbitrary real epsilon.

`chart_restricted_mass_le` transfers the almost-everywhere upper density bound to any measurable physical set through its actual parameter preimage. Applying it to the compact physical strip yields

    surface_measure(chart_strip) <= M * ofReal(2*epsilon)^2,
    M = C * ofReal(beta) * volume(thin_closed_ball(0,(L+1)*rho)).

The common Haar upper bound beta removes dependence on the chosen coordinate equivalence. `chartStripMassConstant_ne_top` proves that M is finite. This improves the v28 full-chart mass bound to a quadratic bound for the strip itself.

`extension_enorm_le_support_mass` proves the L2-to-L-infinity estimate using only the square root of the essential support mass. Combining it with the quadratic strip mass gives the actual chart extension bound

    enorm(E_chart g(x)) <= ofReal(2*epsilon) * sqrt(M) * enorm(g).

The statement is pointwise in x and uniform in the frame. Zero-width strips and empty supports are included by the measure argument; no division by an input norm is used.

### Original surface inputs and bounded physical scales

`pointwise_atlas_assembly` uses the actual disjoint atlas inputs, their inherited essential support, norm budgets and exact extension reconstruction. Its explicit chart-count factor is bounded by the common count from v28. `uniform_surface_strip_extension_bound` consequently chooses a finite nonnegative constant A before the selected index, admissible frame, epsilon, input and physical point, and proves

    enorm(E_i g(x)) <= A * ofReal(2*epsilon) * enorm(g).

The admissibility hypothesis is explicit: the pair frame is orthonormal and its frame-frequency pair lies in the compact admissible image for every point of the selected original support. Empty supports are permitted. There is no unproved claim that every plane is admissible.

`extension_product_bound_selected` and `extension_product_quasinorm_selected` combine the selected-factor gain with ordinary L2-to-L-infinity bounds for the other factors. They never divide by zero norms and work at every p>0. `uniform_surface_strip_product_bound` absorbs the finitely many selected-factor mass constants into one finite C and gives

    eLpNorm'(product E_j g_j,p,sigma)
      <= C * ofReal(2*epsilon) * sigma(univ)^(1/p) * product enorm(g_j).

Thus `uniform_bounded_radius_strip_product` gives a common constant for all ball centers and all radii R <= R0, with R0 fixed in advance. The constant may depend on R0 and p. `geometric_bounded_radius_strip_product` verifies the admissible-image hypothesis from the article's curvature-scaled plane-gap hypothesis along every tuple obtained by varying the selected support point of a supported reference tuple.

This is an unconditional bounded-scale analytic estimate under its stated geometric/admissibility assumptions. It is not Corollary 4.3: on large balls the spatial-volume factor has the trivial scale growth corresponding to R^(n/p), rather than the required arbitrarily small power loss. Choosing R0 to equal the eventual radius would make the constant radius-dependent and would not fix this gap.

### Actual L2 fiber inputs

`fiberAmplitude` is the density-multiplied coordinate input on a thin fiber. `fiber_memLp_ae` proves that it is in L2 for almost every normal coordinate u. `fiberInput` turns these into actual elements of the thin-coordinate L2 space, setting exceptional fibers to zero. `fiberInput_coe_ae` proves the expected almost-everywhere equality of representatives. No arbitrary replacement on a positive-measure family of fibers is made.

Every fiber outside the translated normal strip is exactly zero. `fiberInput_parameter_support` and its normalized counterpart retain the actual slice of the compact parameter ball as essential support, so the smooth chart bounds apply on the input support; an enclosing thin ball alone would not be enough. `fiberInput_thin_support` gives essential support in the same fixed thin ball for every fiber, including exceptional fibers. The actual L2 inputs have the budgets

    h * integral_u enorm(fiberInput(u))^2 <= C * enorm(g)^2,
    sqrt(h) * integral_u enorm(fiberInput(u))
      <= ofReal(2*epsilon) * sqrt(C) * enorm(g),

where h is the exact positive Haar factor. The original chart input norm appears on the right; the density is already absorbed into each fiber amplitude.

`extension_fiberInput` proves the exact identity

    E_chart g(x) = h * integral_u E_(actual fiber parametrization)(fiberInput(u))(x).

`fiber_extension_integrable` proves that this is an integrable complex-valued normal-parameter function for every physical point. It follows from full-coordinate integrability, exact linear-coordinate transport, Fubini and the almost-everywhere fiber representative identities. This is stronger than a merely formal integral expression. It does not claim a joint measurable Lp-valued selection or an intrinsic thin-fiber Hausdorff density formula.

### Haar-normalized actual inputs

`normalizedFiberInput` multiplies each actual L2 fiber input by sqrt(h). Its integral squared norm is at most C times the original squared norm, and its integral norm is at most ofReal(2*epsilon)*sqrt(C)*enorm(g). The exact extension reconstruction then has only sqrt(h) outside the normal integral. Normalization preserves the actual sliced parameter support, the fixed thin-ball support, and vanishing outside the normal strip. The normalized fiber extensions remain integrable in the normal variable at each physical point. These statements use actual L2 elements, not merely scalar fiber energies. The common upper Haar bound controls the remaining square-root factor uniformly.

### Remaining analytic boundary

The bounded-scale starting estimate and actual L2 fiber preparation are now checked. The remaining sharp large-scale localized estimate still requires External input 1, including the uniform perturbative Kakeya and wave-packet recursion argument of Remark 4.2. The new fiber norm budget cannot be inserted into an unjustified continuous quasi-Banach Minkowski inequality. A uniform bound for the actual localized ensemble, with the correct radius/loss dependence, must still be proved and supplied to the conditional assembly theorem from v28.

Corollary 4.3 and Theorem 1.1 remain open. Previously recorded external, recurrence/dimension-descent, algebraic and epsilon-removal obligations remain. No global continuous normal-frame choice, intrinsic thin-fiber Hausdorff/Gram-Jacobian identity, smooth frequency partition, or joint measurable Lp-valued family is introduced.

### Verification

`continuation-audit-run-v29.txt` records the fresh audit of 367 retained results. `new-audit-run-v29.txt` records 45 new results compiled in dependency order. `continuation-audit-final-v29.txt` checks all 412 inventories, source hashes, compiler outputs and axiom dependencies. `build-v29.txt` records the default build. The 843-result main axiom report is retained after byte comparison with v28, not described as a fresh main audit.


## Revision 0.30: distance support, actual fiber geometry and coarse analytic bounds

This final section is authoritative for the current revision; earlier sections are historical. **43 new results in twenty files** give **843 main + 455 separate = 1298 distinct checked results**. All 152 main modules and 144 prior continuation files are byte-identical to v29. All 455 continuation results were freshly compiled and axiom-audited, and the default build passes.

| Stable ID | Checked scope | Main entry points |
|---|---|---|
| N2-GEO-036 | Uniform ambient normal Lipschitz buffers and distance-ready measured atlases | `SmoothPatch.normal_lipschitz_buffer`, `uniform_normal_lipschitz_buffers`, `uniform_distance_ready_atlases` |
| N2-ANA-043 | Exact distance-supported local input interface and bounded-radius product estimate | `MeasuredTubularChart.zeroTarget_support_to_strip`, `MeasuredTubularChart.zeroTarget_supported_amplitude`, `bounded_distance_chart_product` |
| N2-ANA-044 | Actual normalized input support geometry and measurable norm budgets | `geometric_normalizedFiberInput_transversality`, `actual_normalized_fiber_finite_jet_stability`, `StripChartAmplitude.integrable_normalizedFiberInput_norm` |
| N2-ANA-045 | Uniform coarse Plancherel-Holder bounds on actual surface products | `uniform_Plancherel_strip_product`, `uniform_critical_strip_product_coarse`, `geometric_coarse_strip_bounds`, `uniform_buffered_chart_Plancherel` |
| N2-ANA-046 | Quantitative phase and frequency-parametrization perturbation | `imaginary_exp_difference_bound`, `extension_phase_difference_bound`, `extension_parametrization_difference` |

### Closing the support interface

The earlier `measured_surface_thickness_assembly.hlocal` asks for inputs essentially supported within distance D*delta of the fixed chart zeroTarget. The v29 fiber construction began with affine normal-strip support. These are different hypotheses; this revision supplies the reverse conversion explicitly.

`SmoothPatch.normal_lipschitz_buffer` uses a compact thickening contained in the smooth neighborhood. The normal derivative is bounded there. Each ball of the common radius about a supported center is convex and lies in that thickening, so the mean-value theorem supplies a common normal Lipschitz constant. `uniform_normal_lipschitz_buffers` takes a common radius and constant for the finite family. The constants precede the plane, center and input.

Frame coordinates contract the ambient norm. Consequently, if x and a zero-target witness y belong to the common Lipschitz region, then

    norm(Q N(x)) = norm(Q(N(x)-N(y))) <= M*dist(x,y).

`normal_strip_of_zero_target_distance` proves this with explicit witnesses, avoiding problematic empty-set distance conventions. No measurability or nonemptiness of the target is required for this implication. `distance_support_to_strip` includes almost-everywhere membership in the actual measured chart carrier. `zeroTarget_support_to_strip` specializes it to the exact target of the assembly theorem:

    distance <= D*delta  implies  normal residual <= M*D*delta.

`zeroTarget_supported_amplitude` constructs the same amplitude bundle as v29 with this converted thickness. Thus all its actual L2 fibers, energy identities and extension reconstruction apply to these distance-supported inputs. The conversion does not replace the original input by an unrelated function or change the surface measure.

`uniform_distance_ready_atlases` constructs finite measured atlases whose normal buffers, fixed zero targets and forward strip-to-distance localization all have common constants. It requires orthonormality and explicit frame-frequency admissibility at the selected fixed centers. The family can have empty supports.

### Bounded local estimates on the exact support class

`zeroTarget_extension_bound` gives a pointwise extension estimate with factor ofReal(2*M*D*delta). `extension_product_quasinorm_common_mass` combines it with the common actual chart mass bound for the other factors. `distance_supported_chart_product` retains the physical-measure cost sigma(univ)^(1/p), for every p>0.

`bounded_distance_chart_product` absorbs this cost into one finite nonnegative constant for all centers and all R<=R0, with R0 fixed in advance. Its constant is chosen before the frame, selected factor, centers, actual measured charts, thickness and L2 inputs. The hypotheses retain the common chart constants, the selected normal Lipschitz bound and zero-target localization in that buffer.

This supplies a bounded-scale version of the exact `hlocal` input inequality. It does not supply a constant with the sharp large-radius dependence needed by the full assembly argument. The radius bound R0 must not be allowed to depend on the eventual radius while claiming a uniform constant.

### Geometry on actual normalized L2 input support

`normalizedFiberInput_regularity` transfers all-order smoothness, the bound B(m)*(L+1)^m, and the inverse derivative bound (L+1)*B(1)*L to almost every nonzero fiber-input frequency. `normalizedFiberInput_surface_support` retains membership in the actual carrier, the original extended surface, the common physical buffer and the exact affine normal-coordinate value.

`geometric_normalizedFiberInput_transversality` combines these actual support conditions with the previously proved geometric normal-space estimate. There are common positive eta and a before all frames, chart maps, inputs and fiber levels. For each fiber, at almost every nonzero input frequency, its actual thin-fiber normal space has an orthonormal basis of dimension three whose Gram determinant with the other surface normals is at least a. Other frequencies range over their actual chart carriers. The curvature-scaled frame-gap assumption at the supported center tuple and the physical buffer condition remain explicit. No measurably varying choice of normal basis is claimed.

`normalizedFiberInput_normal_support` and `normalizedFiberInput_residual_ae` account for both nonzero L2 classes and their possibly exceptional representatives. Under the compact-to-smooth parameter margin, `normalizedFiberInput_reference_inside` puts the zero-fiber reference strictly inside the smooth chart. `normalizedFiberInput_reference_jets` gives the error

    B(m+1)*(L+1)^(m+1)*epsilon

for the m-th thin-fiber jet on actual input support. `actual_normalized_fiber_finite_jet_stability` chooses one positive strip threshold before all charts and inputs so that every jet through a specified finite order is within a prescribed positive tolerance of the zero fiber. This is quantitative geometric preparation, not an analytic stability theorem.

### Measurability and integrability of the norm budgets

`measurable_fiber_energy` uses the actual jointly measurable coordinate amplitude and Tonelli. Its almost-everywhere identification with the square of the actual L2 fiber norm yields `aemeasurable_fiberInput_enorm`. Haar normalization preserves this property. The v29 energy and linear thickness budgets then prove that both the real norm function and its square are Bochner-integrable over the normal parameter.

These are scalar measurability and integrability statements. They do not assert that the L2-valued family itself is jointly or strongly measurable, and they do not justify continuous Minkowski when the target exponent is below one.

### Stronger coarse large-scale estimates

The previous pointwise argument paid the full physical-volume cost at the final exponent. `selected_product_holder_integral` instead puts one factor in L-infinity and the remaining k-1 factors in L2, using integral Holder on the erased finite index set. This remains valid when q0=2/(k-1)<1.

`HasBallEnergyBound.lintegral` converts the proved real local Plancherel bound into the lower-integral form used by Holder, retaining the original L2 norms. It does not assume a new Plancherel estimate. `uniform_Plancherel_strip_product` combines the selected original-surface strip bound with these unlocalized L2 bounds:

    norm(product E_j g_j, q0, B(x0,R))
      <= C * ofReal(2*epsilon) * ofReal(R)^((k-1)/2) * product enorm(g_j).

Here k>1, R>=0, the frame is orthonormal, and frame-frequency admissibility holds throughout the selected support. C depends on the fixed surfaces and the admissibility parameter, not the selected index, frame, epsilon, input, center or radius.

`uniform_Plancherel_product` proves the unlocalized estimate at 2/k with radius cost R^(k/2). Applying the already checked integral interpolation to the same original product gives `uniform_critical_strip_product_coarse`:

    norm(product E_j g_j, pc, B(x0,R))
      <= C * ofReal(2*epsilon)^theta * ofReal(R)^(1/pc) * product enorm(g_j),
    pc = 2*(k+1)/k^2,  theta = k/(k+1).

The input-norm product has exponent exactly one after interpolation, including zero norms. `geometric_coarse_strip_bounds` gives both estimates under GeometricHypotheses and the curvature-scaled nearby-plane condition along every supported tuple obtained by varying the selected point of a supported reference tuple.

`uniform_buffered_chart_Plancherel` separately proves a common L2 ball bound for every actual measured chart contained in a sufficiently small common surface buffer. It uses the already proved fixed-patch Plancherel theorem on a larger compact surface patch and then restricts the measure. Uniformity is derived from that fixed larger patch, not inferred from a family of unrelated constants.

### Quantitative phase and extension perturbation

`imaginary_exp_difference_bound` proves a global two-Lipschitz bound for real-phase complex exponentials. `extension_phase_difference_bound` consequently bounds phase variation by twice the physical-point norm times the frequency displacement.

`extension_parametrization_difference` compares two measurable frequency parametrizations on the same actual L2 input and finite frequency measure. If their distance is at most a on the input's essential support, their extension difference is at most

    ofReal(2*norm(x)*a) * enorm(g) * measure(univ)^(1/2).

The zero-input case and almost-everywhere support are included. This is a pointwise quantitative perturbation lemma. For actual normalized fibers, `normalizedFiberInput_reference_distance` bounds the displacement to the zero fiber by B(1)*(L+1)*epsilon on essential support, and `normalizedFiberInput_phase_difference` bounds the corresponding phase error by 2*norm(x) times that displacement. Integrating the generic finite-measure perturbation estimate over a full fiber family still requires the appropriate finite-domain restriction and measurable parametrizations; no sharp localized restriction stability follows from these estimates.

### Remaining boundary and next work

The new radius powers are positive and fixed. Neither R^((k-1)/2) at q0 nor R^(1/pc) at pc can be substituted for R^eta for arbitrary eta>0. Corollary 4.3 and Theorem 1.1 remain open.

The next analytic obligation is a uniform localized restriction recursion with the sharp loss, using the actual supported inputs, common derivative/normal-space bounds and bounded-scale estimates now available. Uniform perturbative Kakeya stability and the relevant wave-packet recursion must still be proved. No conclusion follows merely from compactness or finite-jet closeness. The remaining external, dimension-descent/recurrence, algebraic and epsilon-removal obligations recorded earlier also remain.

### Verification

`continuation-audit-run-v30.txt` records the fresh compilation and axiom audit of 412 retained results. `new-audit-run-v30.txt` records 43 new results compiled in dependency order. `continuation-audit-final-v30.txt` checks all 455 inventories, source hashes and axiom reports. `build-v30.txt` records the default build. The 843-result main axiom report is retained after byte comparison with v29, not presented as a fresh main audit. Only the standard Lean axioms occur; no admitted proofs or custom axioms are introduced.


## Revision 0.31: one actual zero-fiber input and quantitative replacement

This final section is authoritative for the current revision; earlier sections are historical. **38 new results in fifteen files** give **843 main + 493 separate = 1336 distinct checked results**. All 152 main modules and 164 earlier continuation sources are byte-identical to v30. All main axiom dependencies and all continuation proofs were freshly checked. The default build passes.

| Stable ID | Checked scope | Main entry points |
|---|---|---|
| N2-ANA-047 | Finite-support frequency perturbation and actual fiber integral comparison | `supported_extension_parametrization_difference`, `StripChartAmplitude.normalizedFiberInput_extension_difference` |
| N2-ANA-048 | Integrable zero-reference superposition and integrated error | `StripChartAmplitude.reference_fiber_extension_integrable`, `StripChartAmplitude.extension_zero_reference_error` |
| N2-ANA-049 | One actual zero-fiber L2 input, exact superposition identity, support and norm budget | `StripChartAmplitude.referenceInput_energy`, `StripChartAmplitude.extension_referenceInput`, `StripChartAmplitude.zeroFiberInput_enorm`, `StripChartAmplitude.zeroFiberInput_support` |
| N2-ANA-050 | Common perturbation coefficient and arbitrary physical centers | `referenceErrorCoefficient_ne_top`, `MeasuredTubularChart.translated_zero_reference_approximation` |
| N2-ANA-051 | Actual product replacement at the localized exponent | `replacement_product_error`, `translated_chart_product_approximation` |

### Finite support and measurable chart representatives

The v30 phase comparison applied pointwise on actual fiber support. Its generic integrated estimate required finite ambient frequency measure and globally measurable frequency maps. Neither property was automatically available for the original full thin-coordinate volume and arbitrary chart extension.

`supported_extension_parametrization_difference` restricts the same actual L2 input to a measurable finite-mass support set, uses the finite-measure estimate, and restores the exact original extension and norm. `measurable_param_representative` constructs a globally measurable map agreeing pointwise with the chart throughout its smooth closed parameter ball. Both the actual fiber and its zero reference lie in that ball on essential input support. `extension_congr_frequency_support` justifies replacing those maps only where the input is nonzero.

The resulting `normalizedFiberInput_extension_difference` bounds the actual fiber difference by

    2 * norm(x) * B(1) * (L+1) * epsilon * sqrt(V) * norm(normalizedFiberInput(u)),

where V is the volume of the common thin-coordinate ball. Empty supports, exceptional zero fibers and L2 representative null sets are included.

### A genuine outer integral and one actual L2 input

`reference_fiber_extension_integrable` proves integrability of the complex-valued zero-fiber superposition. It uses the globally measurable scalar amplitude and its full-coordinate integrability, followed by Fubini. No joint measurable choice of L2-valued representatives is postulated.

`normal_supported_integral_bound` proves scalar Cauchy-Schwarz on the two-dimensional normal ball. `normal_marginal_energy` combines this with Tonelli. The normal space uses the max norm, so its ball area is exactly ofReal(2*epsilon)^2.

`normalizedAmplitude` is the joint scalar representative of the normalized actual fibers. Its energy agrees almost everywhere with the already checked fiber energy. Integrating this amplitude in the normal variable defines `referenceAmplitude`; its energy is at most

    ofReal(2*epsilon)^2 * C * norm(original_input)^2.

This proves `referenceAmplitude_memLp` and constructs the actual equivalence class `referenceInput`. Scalar Fubini proves that its extension is exactly the earlier zero-fiber superposition. Its essential support remains in the fixed thin-coordinate ball and in the smooth zero-reference parameter domain. `zeroFiberInput_geometry` also proves membership in the original extended surface, vanishing projected normal, and all common thin-chart derivative and inverse-differential bounds. `zeroFiberInput_extension_continuous` proves continuity of the actual extension using its finite support and a measurable chart representative. Multiplying by the remaining square-root Haar factor defines `zeroFiberInput`.

### Quantitative approximation and quantifier order

Write h for the Haar coordinate factor, with h <= beta, and let

    V = volume(closedBall(0, (L+1)*rho)),
    D = sqrt(ofReal(beta)) * ofReal(2*B(1)*(L+1)) * sqrt(V) * 2 * sqrt(C).

`referenceErrorCoefficient` defines D with extended nonnegative factors and proves it finite. The new input has norm at most sqrt(ofReal(beta))*ofReal(2*epsilon)*sqrt(C)*norm(g). The approximation error is at most

    D * ofReal(norm(x)) * ofReal(epsilon)^2 * norm(g).

`zeroFiberInput_relative_error` makes the useful perturbative regime explicit: if norm(x)*epsilon <= theta, the error is at most D*ofReal(theta)*ofReal(epsilon)*norm(g). This condition cannot be omitted at large radii.

The assumptions retain rho <= r, nonnegative derivative bounds and the strict reference margin (L+1)*epsilon < r-rho. No regularity of the chart outside its smooth domain is assumed.

`modulateL2` is an actual L2 modulation preserving the norm and frequency support, with the exact spatial-translation identity. `translated_zero_reference_approximation` applies the construction to this modulated original input. For every physical center x0, it produces one input f, before choosing x or R, such that

    E_chart(g)(x) = E_zero(f)(x-x0) + error(x),
    enorm(error(x)) <= D * ofReal(dist(x,x0)) * ofReal(epsilon)^2 * enorm(g).

The coefficient is independent of center, frame and input whenever the stated chart bounds are common. The constructed f is allowed to depend on the original input and physical center. Its support and norm bounds hold for that same f.

### Product error, including the quasi-Banach range

`bounded_factor_product_holder` combines one essentially bounded error with a nonempty finite family of genuine L2 energy integrals. `replacement_product_error` rewrites the difference between the original product and the product with one selected factor replaced. At q0=2/(k-1), its quasi-norm is bounded by the uniform selected-factor error times the product of the other factors' ball L2 norms.

`translated_chart_product_approximation` instantiates this on the actual measured chart inputs. The selected zero-fiber input is chosen before R. On every ball B(x0,R), the error has the bound

    D * ofReal(R) * ofReal(epsilon)^2 * norm(g_selected)
      * product(other actual ball L2 norms).

No continuous Minkowski inequality is used at q0<1. The other factors are unchanged, and their integrals are the actual extension energies, not assumed surrogate quantities.

### Remaining analytic boundary

The approximation is perturbative and retains a fixed radius cost. With common Plancherel bounds for the other k-1 factors, the displayed error has coarse radius power (k+1)/2 and thickness squared. It is not a substitute for the requested linear-thickness estimate with arbitrary R^eta loss. Even a sharp estimate on the exact zero fiber would not by itself remove this error at the scales required in the article.

The paper's External input 1, Remark 4.2 and Corollary 4.3 still require a uniform localized restriction recursion, with valid perturbative Kakeya neighborhoods, common wave-packet bounds and the correct scale dependence. The current work supplies actual supported input data and a quantitative comparison; it does not prove that recursion. Intrinsic thin-surface Hausdorff-density conversion, where needed for a particular formulation of the external theorem, is not asserted by this coordinate-Lebesgue construction. The previously recorded descent, algebraic and epsilon-removal obligations also remain.

### Verification

`main-audit-run-v31.txt` records a fresh standard-axiom audit of all 843 main results. `continuation-audit-run-v31.txt` records fresh compilation and axiom checks for 455 retained results. `new-audit-run-v31.txt` records the 38 new results compiled in dependency order. `continuation-audit-final-v31.txt` validates all 493 continuation declarations, source hashes and axiom reports. `build-v31.txt` records the incremental default build. Counts exclude structures and definitions and contain no duplicated declarations.


## Revision 0.32: three-block inequalities and bounded-scale perturbed tubes

This final section is authoritative for the current revision; earlier sections are historical. **40 new results in 22 files** give **843 main + 533 separate = 1376 distinct checked results**. All 152 main modules and 179 earlier continuation sources are byte-identical to v31. Main axiom dependencies and all continuation proofs were freshly checked. The default build passes.

| Stable ID | Checked scope | Main entry points |
|---|---|---|
| N2-ANA-052 | Three-block Loomis–Whitney, actual L2 product bounds and integrability | `three_block_loomis_whitney`, `three_block_L2_product`, `linear_three_block_L2_integrable` |
| N2-ANA-053 | Countable weighted complementary cylinders; exact and uniform Haar transport | `three_block_weighted_cylinders`, `linear_weighted_cylinders`, `uniform_linear_weighted_cylinders` |
| N2-ANA-054 | Exact fifth-power width scaling and explicit perturbation radius cost | `block311_ball_mass`, `perturbed_311_cylinders`, `small_aperture_311_cylinders` |
| N2-ANA-055 | A common constant on arbitrary physical balls, including metric fiber tubes | `uniform_centered_small_aperture_311_cylinders`, `uniform_centered_small_aperture_311_metric_tubes` |
| N2-GEO-037 | Projection perturbation, center correction, distance attainment and measurability | `centered_perturbed_projection_cylinder_subset`, `affineFiberTube_eq_infDist`, `measurableSet_affineFiberTube` |

### The analytic core

For arbitrary sigma-finite measure blocks X, Y, Z and nonnegative measurable functions f(y,z), g(x,z), h(x,y), `three_block_loomis_whitney` proves

    integral_yz integral_x sqrt(f(y,z)*g(x,z)*h(x,y))
      <= sqrt(integral f)*sqrt(integral g)*sqrt(integral h).

The actual Lean statement assumes `SFinite`, a slightly more general condition than sigma-finiteness. The proof uses Cauchy–Schwarz in x, then Cauchy–Schwarz in (y,z), followed by Tonelli and factorization of a separated product. All integrals are nonnegative integrals, so infinite values and zero factors are handled by the extended-nonnegative arithmetic. No prior Brascamp–Lieb inequality is assumed.

Applying this to squared magnitudes gives the L2-to-L1 bound for actual `Lp` equivalence classes, not hypothetical energy variables. The resulting complex product is proved integrable over the full product measure. Its transported version is also integrable in physical coordinates. These are physical-space product estimates; this revision does not construct a Fourier transform on arbitrary L2 frequency data.

### Countable weighted cylinders and coordinates

For a countable family of measurable cross-sections U(t) with weights u(t), `tubeDensity_integral` proves the exact identity

    integral tubeDensity(U,u) = sum_t u(t)*measure(U(t)).

Disjointness is not required. A common cross-sectional volume bound then yields the weighted cylinder inequality. The families are invariant along their respective complementary blocks.

For an actual continuous linear equivalence

    e : Ambient n ≃L[ℝ] (Ambient b × Ambient c) × Ambient a,

the physical integral acquires exactly `coordinateMeasureFactor e volume ((volume.prod volume).prod volume)`. Both this factor and the normalization of the product Haar measure are retained. The existing two-sided coordinate bounds imply a common positive finite upper bound when the operator norms of e and its inverse are at most M. The uniform theorem chooses the constant before all functions, sets and weights.

### Perturbed projections and spatial centers

For projections P and Q with operator-norm difference at most delta, the elementary geometric estimate is

    B(0,R) intersect {x : norm(Px-z) <= w}
      subset {x : norm(Qx-z) <= w+delta*R}.

Each tube can have its own P and center z. On a ball centered at x0, the correct reference center is

    z + (Q-P)(x0).

`centered_perturbed_projection_cylinder_subset` proves this correction explicitly. Translation invariance of cross-sectional Haar measure removes the reference-center dependence from the volume bound. `localized_cylinder_comparison` transports these containments through countable weighted densities and the restricted physical integral. Thus the bound is uniform in x0 without any hidden dependence on its norm.

### The first localized case: n=5, k=3

The article's localized normal dimensions are 3,1,1 in this case. The complementary cross-sections have dimensions 2,4,4. Their product-ball volumes scale as r^2, r^4, r^4, respectively, so the product of their square roots scales as r^5. `block311VolumeConstant` records the positive finite product of the three unit-volume square roots; its finiteness and positivity are proved.

Let D_i be the weighted densities for the three families, and let U_i denote their total weights. The perturbed-cylinder theorem gives

    integral_B(x0,R) sqrt(D_1*D_2*D_3)
      <= HaarFactor * VolumeConstant * (w+delta*R)^5
         * sqrt(U_1)*sqrt(U_2)*sqrt(U_3).

If delta*R <= w, the fifth-power factor is at most 32*w^5. Under the common conditioning bound M, the final theorem has the quantifier order

    for every M >= 0, there exists K > 0, K finite,
    for every conditioned e, countable families, centers, weights,
    x0, R >= 0, w >= 0, delta >= 0 with delta*R <= w,
    integral_B(x0,R) sqrt(D_1*D_2*D_3)
      <= K*w^5*sqrt(U_1)*sqrt(U_2)*sqrt(U_3).

The constant K includes the fixed factor 32 and the volume normalization. This is a genuine uniform bounded-scale estimate. It is not uniform for a fixed nonzero delta as R/w tends to infinity.

### Genuine metric neighborhoods of affine fibers

`affineFiberTube P z w` consists of points x for which there is a point y with P(y)=z and dist(x,y)<=w. In a proper normed space, if the fiber is nonempty, the distance to the closed affine fiber is attained. `affineFiberTube_eq_infDist` therefore identifies this set with the usual closed metric neighborhood defined by infimum distance. The nonempty-fiber hypothesis matters because real-valued `infDist` has a special convention on the empty set.

Every such tube is measurable, including the empty-fiber case. If norm(P)<=L with L>=0, it lies in the projection cylinder of width L*w. Applying the uniform arbitrary-center comparison gives

    integral_B(x0,R) sqrt(D_1*D_2*D_3)
      <= K*(L*w)^5*sqrt(U_1)*sqrt(U_2)*sqrt(U_3),

under delta*R<=L*w and the stated projection-norm and conditioning assumptions. The constant K is chosen before L as well. No surjectivity, nonemptiness or dimension of the individual perturbed fibers is silently assumed.

### Remaining boundary

This revision proves the three-block flat analytic model and a controlled small-aperture perturbation. The article's theorem concerns all n>=5, hence k=n-2 blocks; the arbitrary-k analogue is not proved here. Nor is the conditioned common splitting yet constructed from the actual geometric normal-space data for this estimate.

`UniformFixedAperture311Kakeya` now states the next model obligation as an explicit Lean proposition. For every loss eta>0 it asks for a positive finite K and a positive aperture delta, both chosen before all families, centers, radii and widths, with bound K*R^eta*w^(5-eta). It is a definition of a proposition, not an axiom or a proved theorem, and is excluded from the result count.

Most importantly, the aperture delta in the comparison must shrink like width/R. The fixed directional neighborhoods required in Remark 4.2 need an induction-on-scales perturbative Kakeya theorem, not this one-step containment argument. `fixed_aperture_inflation_not_small_loss` verifies the obstruction for the coarse comparison factor: for every delta>0, eta<5 and C, some R>=1 satisfies C*R^eta < (1+delta*R)^5. It does not assert failure of the actual Kakeya inequality.

The new mixed-dimensional cylinders are relevant to the localized ensemble of External input 1; they do not prove External input 2, whose families are all line tubes. Actual chart wave-packet stability, the uniform localized restriction recursion and its arbitrary-small-loss conclusion remain open.

The v31 zero-fiber input and its quadratic-thickness perturbation error are unchanged. The new flat estimate does not remove that error's radius cost or establish Corollary 4.3. Intrinsic thin-surface density conversion where required, the previously recorded recurrence/descent and algebraic inputs, epsilon removal and Theorem 1.1 remain unproved. No new axiom is introduced.

### Concrete next proof decomposition

For the arbitrary-k flat inequality, use induction on the number of blocks rather than repeating the three-block proof. Integrating the last block first, Holder with k-1 factors replaces each of the first k-1 functions by its integral in that block. On the remaining product space, Holder with conjugate exponents k-1 and (k-1)/(k-2) separates the last function from the reduced product. The induction hypothesis then gives the desired exponent 1/(k-1). The base case of two blocks is Tonelli factorization. This is a proposed proof decomposition, not a checked theorem. The Lean work still includes dependent product measures, complement-index projections, Fubini equivalences and the endpoint/zero cases.

For the fixed-aperture target, a proof must control the loss across scales rather than replace each tube by one enlarged reference cylinder over the entire large ball. The current K is uniform under conditioning, and the small-aperture result supplies a bounded-scale starting estimate. The missing induction must choose a positive directional neighborhood once, before R/w, and account quantitatively for its iteration. The displayed coarse-factor obstruction prevents substituting the one-step comparison for that induction.

### Verification

`main-audit-run-v32.txt` records a fresh standard-axiom audit of all 843 main results. `continuation-audit-run-v32.txt` records fresh compilation and axiom checks for 493 retained results. `new-audit-run-v32.txt` records the 40 new results compiled in dependency order. `continuation-audit-final-v32.txt` validates all 533 continuation declarations, source hashes and axiom reports. `build-v32.txt` records the incremental default build. Counts exclude structures and definitions and contain no duplicate declarations.


## Revision 0.33: four-block analysis and actual normal coordinates

This final section is authoritative for the current revision; earlier sections are historical. **41 new results in 23 files** give **843 main + 574 separate = 1417 distinct checked results**. All 152 main modules and 201 earlier continuation sources are byte-identical to v32. Main axiom dependencies and all continuation proofs were freshly checked. The default build passes.

| Stable ID | Checked scope | Main entry points |
|---|---|---|
| N2-ANA-056 | Finite-factor Holder elimination and an explicit induction implication | `block_holder_lift`, `block_loomis_whitney_step` |
| N2-ANA-057 | Four-block Loomis–Whitney and actual L2-to-L^(2/3) product estimates | `four_block_loomis_whitney`, `four_block_L2_quasinorm`, `four_block_L2_memLp` |
| N2-ANA-058 | Countable weighted cylinders, local density comparison and coordinate transport | `four_block_weighted_cylinders`, `four_block_local_density_bound`, `linear_four_block_L2_quasinorm` |
| N2-ANA-059 | Dimension-six width scaling and bounded-scale metric tubes | `block3111_ball_mass`, `uniform_centered_small_aperture_3111_metric_tubes` |
| N2-GEO-038 | Uniform Gram coercivity and actual synthesis equivalences | `uniform_gram_synthesis_lower_bound`, `uniform_synthesis_equiv_of_gram` |
| N2-GEO-039 | Actual thin-normal coordinates, correct complementary kernel and bounded preimages | `uniform_thin_normal_synthesis_equiv`, `normalComplementProjection_ker`, `uniform_thin_normal_complement_projection` |
| N2-GEO-040 | Inverse-coordinate and frame-to-projection perturbation bounds | `coordinate_inverse_difference_norm_le`, `normalComplementProjection_frame_stability`, `uniform_normalComplementProjection_neighborhood` |

### A reusable block-elimination step

For m>=2, define p=1/m, r=1/(m-1) and q=(m-1)/m. Let f0 depend only on x and let f_i depend on (x,y), for i in Fin m. The checked `block_holder_lift` states

    integral_x integral_y (f0(x)*product_i f_i(x,y))^p
      <= (integral_x f0)^p
         * (integral_x product_i (integral_y f_i(x,y))^r)^q.

Holder in y uses m equal exponents. Holder in x then uses the conjugate weights p and q; the identity r*q=p restores the correct powers. The functions are measurable and nonnegative, and the integrated-out measure is SFinite. No finite-total-mass assumption is used.

`block_loomis_whitney_step` adds an explicit hypothesis bounding the remaining integral by product_i A_i^r. It then concludes the next block inequality with product_i A_i^p. **This is an induction implication, not a proof of the complete arbitrary-k product-measure theorem.** Dependent coordinate deletion and Fubini identifications are still needed to run the induction for all k.

For four blocks the remaining inequality is the already checked three-block theorem. `four_block_loomis_whitney` discharges the reduced hypothesis fully, with constant one and exponent 1/3. It allows arbitrary SFinite block measures X,Y,Z,W and arbitrary block dimensions. In the chosen ordering, f0 depends on X,Y,Z; f1 on Y,Z,W; f2 on X,Z,W; and f3 on X,Y,W.

### Actual quasi-Banach product estimates

`fourBlockProduct` is the product of four actual L2 representatives on their complementary three-block spaces. Applying four-block Loomis–Whitney to their squared magnitudes gives

    integral |fourBlockProduct|^(2/3)
      <= (norm(f0)*norm(f1)*norm(f2)*norm(f3))^(2/3).

The 3/2 power yields the L^(2/3) quasi-norm bound with constant one. Measurability and `MemLp` membership at exponent 2/3 are proved separately. These statements concern the actual product on the full four-block measure space, including infinite-volume blocks. No Banach-space triangle inequality, continuous Minkowski argument or assumed Fourier L2 extension operator is used.

For a linear coordinate equivalence e, the nonnegative integral acquires exactly the Haar scaling factor h. Consequently the physical quasi-norm has coefficient h^(3/2), not h. Both the physical power-integral estimate and actual physical `MemLp` membership are checked. The uniform linear-density theorem chooses a finite positive coefficient before the splitting and all four input densities, under common bounds for e and its inverse.

### Weighted cylinders and the six-dimensional model

Countable measurable cross-sectional families with nonnegative weights satisfy the four-block inequality through the exact weighted-mass identity proved in v32. Overlaps are allowed. `four_block_local_density_bound` transfers local pointwise domination by these complementary densities to a physical integral, retaining their actual mass budgets.

For individually perturbed projections, `centered_perturbed_cylinder_density_bound` makes the center correction explicit on any ball B(x0,R). The reference cross-section center is z+(Q-P)(x0), and its width is w+delta*R when norm(P-Q)<=delta. Applying the local density theorem gives a four-family estimate without losing uniformity in x0.

In dimension six with normal blocks 3,1,1,1, the complementary dimensions are 5,3,5,5. Their total 18 is divided by the density exponent denominator 3, so the width factor is exactly r^6. `block3111VolumeConstant` is the positive finite product-ball normalization, and `block3111_ball_mass` proves the exact scaling, including zero width and extended-nonnegative weights.

For weighted densities D_i and total weights U_i the estimate is

    integral_B(x0,R) (D0*D1*D2*D3)^(1/3)
      <= h * V * (w+delta*R)^6 * (U0*U1*U2*U3)^(1/3).

Under delta*R<=w, the sixth-power factor is at most 64*w^6. Bounded conditioning of e absorbs h*V*64 into one positive finite K chosen before all splittings, countable families, centers, weights, widths and radii.

The metric-tube version uses the previously checked affine-fiber neighborhoods. If the individual projection norms are at most L, the width cost is L*w and the aperture condition becomes delta*R<=L*w. The same K is chosen before L, and the final factor is (L*w)^6. Empty fibers remain allowed; their metric tubes are empty. As in v32, the individual fibers are not silently assumed surjective or of fixed dimension.

### From positive Gram bounds to uniform coordinates

This geometric part applies in every dimension, not only n=6. Let v be a finite frame with sup norm at most M and Gram determinant at least c>0. `uniform_gram_synthesis_lower_bound` chooses a>0 before v such that

    a*norm(x) <= norm(sum_i x_i*v_i)

for every coefficient vector x, where coefficients carry the finite Pi/max norm. The proof minimizes the synthesis norm over the compact set of bounded frames with Gram determinant >=c and unit coefficient vectors. Linear independence makes that norm positive. Homogeneity extends the bound from unit vectors to all vectors; zero coefficients are handled separately.

The elementary upper bound is card(I)*M*norm(x). When card(I)=n, the synthesis map is an actual continuous linear equivalence onto Ambient n. Its norm is at most card(I)*M and its inverse norm at most 1/a. A common positive B bounds both. The empty unit-sphere case and zero-dimensional spaces are included in the abstract result.

`uniform_thin_normal_synthesis_equiv` instantiates this with the normalized thin-normal frame already obtained from the article's geometry: the other k-1 unit normals, followed by an orthonormal basis of the selected three-dimensional normal space N. The raw normal/shape Gram bound, common shape bound, unit-frame bounds and membership of the three selected vectors in N are explicit hypotheses. The earlier normalized-Gram theorem supplies a common positive determinant bound. The coefficient index set is the disjoint sum of the other normals and Fin 3; its cardinality is checked to be k+2.

Thus B is chosen before the surfaces, frequency points, two-plane frame, normal space and its orthonormal basis. The resulting map is exactly the stated synthesis of the actual frame vectors, not an unspecified finite-dimensional isomorphism.

### The actual selected normal space and geometric stability

`normalComplementProjection` takes inverse synthesis coordinates and discards the selected normal block. Its operator norm is at most the inverse synthesis norm. `normal_synthesis_complement_iff` proves that all complementary coordinates vanish exactly when the physical vector belongs to N; `normalComplementProjection_ker` packages this as equality of submodules.

The reverse implication uses the orthonormal-basis expansion of the actual vector in N. Bounded preimages are obtained by assigning the desired complementary coefficients and setting the selected-normal coefficients to zero. The full synthesis bound controls their physical norm. `uniform_thin_normal_complement_projection` combines these facts into one uniform existence statement with the correct kernel, bounded projection norm and bounded preimages.

For two synthesis equivalences e and f, the exact identity

    e^{-1}-f^{-1} = e^{-1} (f-e) f^{-1}

is checked at the continuous-linear-map level. If both inverse norms are at most B, their difference is at most B^2*norm(e-f). Restricting to complementary coordinates cannot increase this norm. If the synthesis frames are u and v, their map difference is at most card(I)*norm(u-v). Hence

    norm(P_e-P_f) <= B^2*card(I)*norm(u-v).

Given a desired projection tolerance delta>0, one may choose

    epsilon = delta / (B^2*card(I)+1)

before both frames and equivalences. The theorem `uniform_normalComplementProjection_neighborhood` checks this quantifier order. It supplies a genuine uniform geometric neighborhood. It neither constructs a global continuous normal-frame choice nor proves an analytic Kakeya estimate on that neighborhood.

### Remaining boundary and next steps

The complete arbitrary-k Loomis–Whitney theorem remains open; the present work proves the finite-factor elimination and the fully instantiated four-block case. The next step is to implement dependent finite product spaces, coordinate-deletion maps and the Fubini identities needed to iterate `block_loomis_whitney_step`.

For the geometry-to-analysis connection, the actual synthesis coordinates use finite Pi coefficient spaces. They must still be grouped into the concrete Euclidean product blocks, with the fixed dimension-dependent norm and Haar conversions retained. The selected three-dimensional normal kernel is now identified, but simultaneous identification of every complementary block projection and its line-normal kernel in the concrete model is not yet complete. Frame-neighborhood arguments must use coherent local frame choices where continuity is needed.

A positive geometric neighborhood does not remove the analytic aperture restriction delta*R<=width. The fixed-aperture mixed-dimensional Kakeya theorem requires an induction across scales with aperture chosen before R/width. The v32 obstruction to absorbing one-step width inflation into arbitrary-small radius loss is unchanged. The new bounds do not establish External input 1, the uniform localized restriction recursion, Corollary 4.3 or Theorem 1.1, and they do not prove the all-line tube geometry of External input 2.

The actual zero-fiber construction and its radius-dependent perturbation error remain unchanged. The retained wave-packet stability, intrinsic thin-surface density conversion where required, recurrence/descent, algebraic and epsilon-removal obligations also remain open. No new axiom is introduced.

### Relation to Remark 4.2 of the article

The new geometric results support the paragraph on uniformly transverse linear data. They do not yet implement the finite-subcover argument for the cited perturbative analytic theorem.

| Step in Remark 4.2 | Current status after this revision |
|---|---|
| Common positive ambient normal-wedge bound | The earlier normalized Gram bound is retained and used as an explicit hypothesis/input. |
| Uniformly conditioned coordinates for the localized linear data | Actual synthesis maps and their inverse bounds are now proved, including the selected normal-space kernel. Grouping all blocks into the concrete analytic product model remains. |
| Common directional neighborhood | A common frame-to-projection tolerance is now proved. Applying it to varying charts still needs coherent local frames. |
| Common Kakeya constant on that neighborhood | Open at fixed aperture; the checked cylinder bounds require aperture times radius at most width. |
| Uniform wave packets and localized recursion | Open; neither the geometric tolerance nor the four-block product estimate supplies this step. |

This distinction follows the article's own separation between geometric compactness and stability of the analytic proof. In particular, the new neighborhood theorem is not recorded as a proof of the uniform estimate in Corollary 4.3.

### Verification

`main-audit-run-v33.txt` records a fresh standard-axiom audit of all 843 main results. `continuation-audit-run-v33.txt` records fresh compilation and axiom checks for 533 retained results. `new-audit-run-v33.txt` records the 41 new results compiled in dependency order. `continuation-audit-final-v33.txt` validates all 574 continuation declarations, source hashes and axiom reports. `build-v33.txt` records the incremental default build. Counts exclude structures and definitions and contain no duplicate declarations.
## Revision 0.34: general block inequalities and actual normal projections

This final section is authoritative; earlier revision sections are historical. This revision adds **61 results in 24 files**, giving **843 main + 635 continuation = 1478 distinct checked results**. All 152 main modules and all 224 earlier continuation sources are unchanged from v33. Theorem 1.1 remains unproved.

| Stable ID | Checked scope | Principal entry points |
|---|---|---|
| N2-GEO-041 | Simultaneous actual normal kernels and bounded preimages | `coordinateDeletion_ker`, `uniform_thin_normal_all_projections` |
| N2-GEO-042 | Euclidean block grouping and the actual six-dimensional configuration | `groupedLineProjection_ker`, `uniform_thin_normal_four_coordinates` |
| N2-GEO-043 | Simultaneous stability of all four concrete projections | `fourNormalCoordinates_frame_stability`, `uniform_fourNormalProjection_neighborhood` |
| N2-ANA-060 | Finite-product splitting, marginal mass and coordinate deletion | `finite_block_lintegral_split`, `finite_block_marginal_mass`, `finite_block_reduced_mass` |
| N2-ANA-061 | Arbitrary finite-block Loomis–Whitney, including different block spaces | `finite_block_loomis_whitney`, `dependent_block_loomis_whitney` |
| N2-ANA-062 | General L2-to-L^(2/(k-1)) product bounds and actual membership | `dependent_block_L2_power_integral`, `dependent_block_L2_quasinorm`, `dependent_block_L2_memLp` |
| N2-ANA-063 | General weighted cylinders and actual six-dimensional analytic applications | `dependent_block_weighted_cylinders`, `uniform_actual_normal_four_L2`, `uniform_actual_normal_four_metric_tubes` |
| N2-ANA-064 | Uniform physical transport in arbitrary Euclidean block dimensions | `linear_dependent_block_lintegral`, `uniform_linear_dependent_block_lintegral` |

### General block inequality: the induction is now discharged

Write k=n+2, with n>=0, and let X_i be nonempty measurable spaces carrying sigma-finite measures mu_i. Each f_i is a measurable nonnegative extended-real function on the product of all blocks except i. The checked theorem is

    integral_(product_i mu_i) (product_i f_i(x without coordinate i))^(1/(k-1))
      <= product_i (integral_(product_{j != i} mu_j) f_i)^(1/(k-1)).

The constant is one. The measures need not have finite total mass, and the block spaces need not have equal dimensions. Empty block spaces are not included in the dependent theorem: its statement uses `Inhabited (X i)`. All Euclidean block spaces relevant to the article meet this hypothesis. The measures are sigma-finite; the statement does not claim the more general SFinite class used by the previously checked special three- and four-block theorems.

`finite_block_lintegral_split` transports the finite dependent product measure exactly through `Fin.insertNth`. `finite_block_marginal_mass` swaps the two integrations and shows that the marginal preserves total mass. `finite_block_holder_elimination` applies the earlier Holder step to that actual finite product. These lemmas handle dependent coordinate spaces.

The recursive proof first uses a common carrier X, allowing different measures in its coordinates. Its base case is the exact two-block factorization. In the successor step, the first coordinate is integrated out. `removeNth_succ_cons` identifies each reduced factor with the appropriate coordinate deletion, and `finite_block_reduced_mass` identifies its complementary integral with the original one. The induction hypothesis now proves the reduced inequality rather than assuming it. The exponent identity restores 1/(k-1).

The final dependent-space theorem uses the disjoint union of the X_i as a common measurable carrier. Each X_i embeds measurably into that carrier, and its measure is pushed forward along that embedding. The pushforwards are sigma-finite. A measurable retraction onto X_i is the identity on its component and a chosen default elsewhere. Product measure preservation transports both the full integral and every complementary mass exactly. No comparison constant or dimension factor is introduced. The default values disappear on the embedded coordinates.

This closes the general flat block-inequality gap recorded in v33. It does not prove a perturbed fixed-aperture Kakeya theorem.

### Actual L2 inputs and countable weighted cylinders

For actual complex L2 equivalence classes f_i on their complementary product spaces, `dependentBlockProduct` is their product after coordinate deletion. Applying the block inequality to squared magnitudes proves

    integral |product_i f_i(x without i)|^(2/(k-1))
      <= (product_i norm(f_i))^(2/(k-1)).

The L^(2/(k-1)) quasi-norm is therefore at most the product of the L2 norms. Measurability and actual `MemLp` membership are checked, including the exponents below one. The proof uses nonnegative integration and monotonicity of real powers, not a quasi-Banach Minkowski inequality.

`dependent_block_weighted_cylinders` applies the same theorem to arbitrary countable families in each complementary block. With weights u_i,t and cross-sectional measures at most A_i, the right side is

    (product_i ((sum_t u_i,t) * A_i))^(1/(k-1)).

Overlaps are allowed. Extended-nonnegative weights and masses are allowed. There is no hidden disjointness or finite-total-weight assumption; infinite right sides are permitted by the statement.

### Uniform physical transport in arbitrary block dimensions

`linear_dependent_block_lintegral` transports the full dependent-block inequality through an arbitrary continuous linear equivalence from physical Euclidean space to the product of Euclidean blocks. It retains exactly the Haar scaling coefficient. `uniform_linear_dependent_block_lintegral` chooses a positive finite bound for that coefficient before all coordinate equivalences and input functions, assuming common forward and inverse operator-norm bounds. Thus the general physical measure-factor estimate is also proved. What remains in the general-k geometric application is assembling its particular actual normal blocks into these dependent Euclidean product coordinates with the simultaneous kernel identifications already available in scalar form.

### All actual normal kernels, using one synthesis map

For a synthesis equivalence e built from a full finite frame v, `coordinateDeletion e i` drops the ith coefficient of e^{-1}. Its kernel is exactly span{v_i}, its norm is at most norm(e^{-1}), and it has preimages bounded by norm(e) times the target norm. Both directions of the kernel equality are proved. These statements include the zero-dimensional complementary target.

`uniform_thin_normal_all_projections` applies these facts to the actual normalized thin-normal frame in every dimension k+2. One e simultaneously yields the selected three-dimensional normal-space kernel N and every other normal-line kernel. The same positive B controls e, e^{-1}, every projection and every preimage bound. B is chosen before the surfaces, frequency points, plane vectors, N and its orthonormal basis. The unit-normal, shape, membership and positive Gram assumptions remain explicit.

`groupNormalCoefficients` converts the selected scalar normal coefficients into an actual Euclidean normal block. The other scalar coordinates remain a finite Pi space. `groupedLineProjection_ker` identifies the corresponding line kernels after this conversion, and bounded preimages remain available. The regrouping has a fixed operator-norm cost independent of the geometric frame.

### Exact six-dimensional product coordinates

For k=4, `fourCoefficientGrouping` converts the coefficient space into exactly

    ((Ambient 1 x Ambient 1) x Ambient 3) x Ambient 1.

An explicit equivalence r orders the three other normals. In the notation of the existing four-block estimates:

| Projection | Actual kernel |
|---|---|
| `fourProjectionZero` | span of the normal indexed by r(2) |
| `fourProjectionOne` | the selected three-dimensional normal space N |
| `fourProjectionTwo` | span of the normal indexed by r(0) |
| `fourProjectionThree` | span of the normal indexed by r(1) |

All four equalities are checked simultaneously for the same coordinates. `uniform_thin_normal_four_coordinates` retains a common positive bound for the coordinate equivalence and its inverse, before the actual geometric data.

`uniform_actual_normal_four_L2` now instantiates the four-block physical L^(2/3) estimate on those actual kernels. Its positive finite coefficient is chosen before the geometric data and the four L2 inputs. The chosen coordinates precede the inputs. The coefficient includes the correct Haar scaling to the power 3/2; the input functions are physical cross-sectional L2 functions, not an assumed Fourier extension construction.

`uniform_actual_normal_four_metric_tubes` likewise instantiates the metric-fiber tube estimate on the actual configuration. A positive finite constant precedes the geometric data, countable families, weights, centers, radii, widths and projection-norm bound L. The estimate still requires

    delta * R <= L * w,

and has width factor (L*w)^6. It allows individually perturbed projections near the reference projections, arbitrary physical centers, and empty fibers. It does not assert that all perturbed fibers have the reference rank.

Thus the concrete geometry-to-flat-analysis identification gap is closed in dimension six. For general k, the block inequality and scalar normal kernels are proved, but their complete uniform physical-coordinate/measure assembly for the article's mixed-dimensional configuration has not yet been packaged into a corresponding general-k analytic theorem.

### Simultaneous projection stability

Coordinate deletion cannot increase the difference of inverse synthesis maps. After regrouping by the fixed map G, the concrete coordinate difference is at most

    norm(G) * B^2 * card(I) * norm(u-v)

when both inverse synthesis norms are at most B. Each of the four concrete projection differences is bounded by that coordinate difference. A common positive epsilon is chosen before both frames and maps to force all four differences below a prescribed delta>0.

This statement requires the frames to be close in the stated norm. It does not construct a global continuous orthonormal frame choice. Coherent local frames are still needed when applying it to varying geometric charts. A common geometric tolerance does not supply the fixed-aperture analytic Kakeya constant required in Remark 4.2.

### Remaining obligations

The general flat Loomis–Whitney inequality is no longer open for the nonempty sigma-finite block spaces used here. The six-dimensional actual normal-kernel identification and its bounded-scale analytic applications are also proved.

The remaining central analytic obligation is a mixed-dimensional perturbed estimate with a fixed aperture selected before R/width. The current tube theorem has a scale-dependent aperture and does not close that gap. Uniform wave-packet stability, the actual localized restriction recursion, and the retained intrinsic density/descent/algebraic/epsilon-removal obligations remain. Corollary 4.3, External input 1 and Theorem 1.1 are still unproved. The arbitrary-line tube geometry of External input 2 is not established by these complementary-block estimates.

### Concrete next implementation step

For the general-k actual geometric model, a useful next representation is the dependent block dimension `d j = if j = i then 3 else 1` on `Fin k`. Construct the fixed regrouping from the existing scalar coefficient index (the other normals disjoint-union Fin 3) into `forall j, Ambient (d j)`. The selected block receives its three basis coefficients; every other block receives its one scalar coefficient. Its inverse and operator bounds depend only on this fixed grouping. Then identify the deleted-block kernels using `normalComplementProjection_ker` and `coordinateDeletion_ker`, and apply `uniform_linear_dependent_block_lintegral`. This is a proposed assembly step, not a theorem claimed in this revision.

After that assembly, further flat inequalities alone will not supply the fixed-aperture result. The existing `UniformFixedAperture311Kakeya` remains a proposition, not a proved theorem. The next analytic proof must provide a multiscale estimate with its aperture chosen before the scale ratio, while retaining the actual weighted-family and norm budgets required by the localized restriction recursion.

### Candidate multiscale step for the fixed-aperture gap

A concrete next route is to partition the physical ball at side length comparable to R/A, with A fixed after the desired loss exponent and before R. For each family and cell, define the local weight as the sum of the weights of tubes meeting that cell. Apply the induction hypothesis to the local families on a ball containing each cell. The missing global budget is a bound for the sum over cells of the product of these local weights to the power 1/(k-1).

The new flat block theorem is intended to prove this budget: if a perturbed tube meets a cell, every point of that cell lies in a corresponding reference cylinder enlarged by the cell diameter, the tube width, and delta*R. Choosing delta of order 1/A makes the final error comparable to the cell width. For R/A at least the tube width, the flat cylinder estimate has a width factor of order (R/A)^(k+2). Dividing by the full cell volume should cancel that factor. This would give a recurrence constant independent of A, provided all partition, enlargement, overlap and coordinate constants are controlled uniformly.

To turn this route into a proof, formalize a finite disjoint cell cover with explicit full cell volumes and enclosing-ball radii; the tube-meeting-to-reference-cylinder implication on each entire cell; the countable weighted local-family identities; and the exact cancellation of the scale factor in the global cell budget. The scale reduction must include the cell-to-ball radius constant. Only after these lemmas are checked can A be chosen large enough for the desired power loss and the aperture chosen small enough relative to A. This is a proposed recurrence strategy, not a proved inequality or a claimed resolution of fixed-aperture Kakeya.

### Verification

All 843 main results were freshly axiom-audited. All 574 retained continuation results and all 61 new results were freshly compiled and axiom-audited, with no warnings or admissions. The default build passes. The final inventory check covers all 635 continuation results and rejects duplicate names, stale hashes and nonstandard axioms. Only `propext`, `Classical.choice` and `Quot.sound` are allowed. Continuation sources remain separate from the default 843-result main inventory.

## Revision 0.34: general block inequalities and actual normal projections

This final section is authoritative; earlier revision sections are historical. This revision adds **61 results in 24 files**, giving **843 main + 635 continuation = 1478 distinct checked results**. All 152 main modules and all 224 earlier continuation sources are unchanged from v33. Theorem 1.1 remains unproved.

| Stable ID | Checked scope | Principal entry points |
|---|---|---|
| N2-GEO-041 | Simultaneous actual normal kernels and bounded preimages | `coordinateDeletion_ker`, `uniform_thin_normal_all_projections` |
| N2-GEO-042 | Euclidean block grouping and the actual six-dimensional configuration | `groupedLineProjection_ker`, `uniform_thin_normal_four_coordinates` |
| N2-GEO-043 | Simultaneous stability of all four concrete projections | `fourNormalCoordinates_frame_stability`, `uniform_fourNormalProjection_neighborhood` |
| N2-ANA-060 | Finite-product splitting, marginal mass and coordinate deletion | `finite_block_lintegral_split`, `finite_block_marginal_mass`, `finite_block_reduced_mass` |
| N2-ANA-061 | Arbitrary finite-block Loomis–Whitney, including different block spaces | `finite_block_loomis_whitney`, `dependent_block_loomis_whitney` |
| N2-ANA-062 | General L2-to-L^(2/(k-1)) product bounds and actual membership | `dependent_block_L2_power_integral`, `dependent_block_L2_quasinorm`, `dependent_block_L2_memLp` |
| N2-ANA-063 | General weighted cylinders and actual six-dimensional analytic applications | `dependent_block_weighted_cylinders`, `uniform_actual_normal_four_L2`, `uniform_actual_normal_four_metric_tubes` |
| N2-ANA-064 | Uniform physical transport in arbitrary Euclidean block dimensions | `linear_dependent_block_lintegral`, `uniform_linear_dependent_block_lintegral` |

### General block inequality: the induction is now discharged

Write k=n+2, with n>=0, and let X_i be nonempty measurable spaces carrying sigma-finite measures mu_i. Each f_i is a measurable nonnegative extended-real function on the product of all blocks except i. The checked theorem is

    integral_(product_i mu_i) (product_i f_i(x without coordinate i))^(1/(k-1))
      <= product_i (integral_(product_{j != i} mu_j) f_i)^(1/(k-1)).

The constant is one. The measures need not have finite total mass, and the block spaces need not have equal dimensions. Empty block spaces are not included in the dependent theorem: its statement uses `Inhabited (X i)`. All Euclidean block spaces relevant to the article meet this hypothesis. The measures are sigma-finite; the statement does not claim the more general SFinite class used by the previously checked special three- and four-block theorems.

`finite_block_lintegral_split` transports the finite dependent product measure exactly through `Fin.insertNth`. `finite_block_marginal_mass` swaps the two integrations and shows that the marginal preserves total mass. `finite_block_holder_elimination` applies the earlier Holder step to that actual finite product. These lemmas handle dependent coordinate spaces.

The recursive proof first uses a common carrier X, allowing different measures in its coordinates. Its base case is the exact two-block factorization. In the successor step, the first coordinate is integrated out. `removeNth_succ_cons` identifies each reduced factor with the appropriate coordinate deletion, and `finite_block_reduced_mass` identifies its complementary integral with the original one. The induction hypothesis now proves the reduced inequality rather than assuming it. The exponent identity restores 1/(k-1).

The final dependent-space theorem uses the disjoint union of the X_i as a common measurable carrier. Each X_i embeds measurably into that carrier, and its measure is pushed forward along that embedding. The pushforwards are sigma-finite. A measurable retraction onto X_i is the identity on its component and a chosen default elsewhere. Product measure preservation transports both the full integral and every complementary mass exactly. No comparison constant or dimension factor is introduced. The default values disappear on the embedded coordinates.

This closes the general flat block-inequality gap recorded in v33. It does not prove a perturbed fixed-aperture Kakeya theorem.

### Actual L2 inputs and countable weighted cylinders

For actual complex L2 equivalence classes f_i on their complementary product spaces, `dependentBlockProduct` is their product after coordinate deletion. Applying the block inequality to squared magnitudes proves

    integral |product_i f_i(x without i)|^(2/(k-1))
      <= (product_i norm(f_i))^(2/(k-1)).

The L^(2/(k-1)) quasi-norm is therefore at most the product of the L2 norms. Measurability and actual `MemLp` membership are checked, including the exponents below one. The proof uses nonnegative integration and monotonicity of real powers, not a quasi-Banach Minkowski inequality.

`dependent_block_weighted_cylinders` applies the same theorem to arbitrary countable families in each complementary block. With weights u_i,t and cross-sectional measures at most A_i, the right side is

    (product_i ((sum_t u_i,t) * A_i))^(1/(k-1)).

Overlaps are allowed. Extended-nonnegative weights and masses are allowed. There is no hidden disjointness or finite-total-weight assumption; infinite right sides are permitted by the statement.

### Uniform physical transport in arbitrary block dimensions

`linear_dependent_block_lintegral` transports the full dependent-block inequality through an arbitrary continuous linear equivalence from physical Euclidean space to the product of Euclidean blocks. It retains exactly the Haar scaling coefficient. `uniform_linear_dependent_block_lintegral` chooses a positive finite bound for that coefficient before all coordinate equivalences and input functions, assuming common forward and inverse operator-norm bounds. Thus the general physical measure-factor estimate is also proved. What remains in the general-k geometric application is assembling its particular actual normal blocks into these dependent Euclidean product coordinates with the simultaneous kernel identifications already available in scalar form.

### All actual normal kernels, using one synthesis map

For a synthesis equivalence e built from a full finite frame v, `coordinateDeletion e i` drops the ith coefficient of e^{-1}. Its kernel is exactly span{v_i}, its norm is at most norm(e^{-1}), and it has preimages bounded by norm(e) times the target norm. Both directions of the kernel equality are proved. These statements include the zero-dimensional complementary target.

`uniform_thin_normal_all_projections` applies these facts to the actual normalized thin-normal frame in every dimension k+2. One e simultaneously yields the selected three-dimensional normal-space kernel N and every other normal-line kernel. The same positive B controls e, e^{-1}, every projection and every preimage bound. B is chosen before the surfaces, frequency points, plane vectors, N and its orthonormal basis. The unit-normal, shape, membership and positive Gram assumptions remain explicit.

`groupNormalCoefficients` converts the selected scalar normal coefficients into an actual Euclidean normal block. The other scalar coordinates remain a finite Pi space. `groupedLineProjection_ker` identifies the corresponding line kernels after this conversion, and bounded preimages remain available. The regrouping has a fixed operator-norm cost independent of the geometric frame.

### Exact six-dimensional product coordinates

For k=4, `fourCoefficientGrouping` converts the coefficient space into exactly

    ((Ambient 1 x Ambient 1) x Ambient 3) x Ambient 1.

An explicit equivalence r orders the three other normals. In the notation of the existing four-block estimates:

| Projection | Actual kernel |
|---|---|
| `fourProjectionZero` | span of the normal indexed by r(2) |
| `fourProjectionOne` | the selected three-dimensional normal space N |
| `fourProjectionTwo` | span of the normal indexed by r(0) |
| `fourProjectionThree` | span of the normal indexed by r(1) |

All four equalities are checked simultaneously for the same coordinates. `uniform_thin_normal_four_coordinates` retains a common positive bound for the coordinate equivalence and its inverse, before the actual geometric data.

`uniform_actual_normal_four_L2` now instantiates the four-block physical L^(2/3) estimate on those actual kernels. Its positive finite coefficient is chosen before the geometric data and the four L2 inputs. The chosen coordinates precede the inputs. The coefficient includes the correct Haar scaling to the power 3/2; the input functions are physical cross-sectional L2 functions, not an assumed Fourier extension construction.

`uniform_actual_normal_four_metric_tubes` likewise instantiates the metric-fiber tube estimate on the actual configuration. A positive finite constant precedes the geometric data, countable families, weights, centers, radii, widths and projection-norm bound L. The estimate still requires

    delta * R <= L * w,

and has width factor (L*w)^6. It allows individually perturbed projections near the reference projections, arbitrary physical centers, and empty fibers. It does not assert that all perturbed fibers have the reference rank.

Thus the concrete geometry-to-flat-analysis identification gap is closed in dimension six. For general k, the block inequality and scalar normal kernels are proved, but their complete uniform physical-coordinate/measure assembly for the article's mixed-dimensional configuration has not yet been packaged into a corresponding general-k analytic theorem.

### Simultaneous projection stability

Coordinate deletion cannot increase the difference of inverse synthesis maps. After regrouping by the fixed map G, the concrete coordinate difference is at most

    norm(G) * B^2 * card(I) * norm(u-v)

when both inverse synthesis norms are at most B. Each of the four concrete projection differences is bounded by that coordinate difference. A common positive epsilon is chosen before both frames and maps to force all four differences below a prescribed delta>0.

This statement requires the frames to be close in the stated norm. It does not construct a global continuous orthonormal frame choice. Coherent local frames are still needed when applying it to varying geometric charts. A common geometric tolerance does not supply the fixed-aperture analytic Kakeya constant required in Remark 4.2.

### Remaining obligations

The general flat Loomis–Whitney inequality is no longer open for the nonempty sigma-finite block spaces used here. The six-dimensional actual normal-kernel identification and its bounded-scale analytic applications are also proved.

The remaining central analytic obligation is a mixed-dimensional perturbed estimate with a fixed aperture selected before R/width. The current tube theorem has a scale-dependent aperture and does not close that gap. Uniform wave-packet stability, the actual localized restriction recursion, and the retained intrinsic density/descent/algebraic/epsilon-removal obligations remain. Corollary 4.3, External input 1 and Theorem 1.1 are still unproved. The arbitrary-line tube geometry of External input 2 is not established by these complementary-block estimates.

### Concrete next implementation step

For the general-k actual geometric model, a useful next representation is the dependent block dimension `d j = if j = i then 3 else 1` on `Fin k`. Construct the fixed regrouping from the existing scalar coefficient index (the other normals disjoint-union Fin 3) into `forall j, Ambient (d j)`. The selected block receives its three basis coefficients; every other block receives its one scalar coefficient. Its inverse and operator bounds depend only on this fixed grouping. Then identify the deleted-block kernels using `normalComplementProjection_ker` and `coordinateDeletion_ker`, and apply `uniform_linear_dependent_block_lintegral`. This is a proposed assembly step, not a theorem claimed in this revision.

After that assembly, further flat inequalities alone will not supply the fixed-aperture result. The existing `UniformFixedAperture311Kakeya` remains a proposition, not a proved theorem. The next analytic proof must provide a multiscale estimate with its aperture chosen before the scale ratio, while retaining the actual weighted-family and norm budgets required by the localized restriction recursion.

### Candidate multiscale step for the fixed-aperture gap

A concrete next route is to partition the physical ball at side length comparable to R/A, with A fixed after the desired loss exponent and before R. For each family and cell, define the local weight as the sum of the weights of tubes meeting that cell. Apply the induction hypothesis to the local families on a ball containing each cell. The missing global budget is a bound for the sum over cells of the product of these local weights to the power 1/(k-1).

The new flat block theorem is intended to prove this budget: if a perturbed tube meets a cell, every point of that cell lies in a corresponding reference cylinder enlarged by the cell diameter, the tube width, and delta*R. Choosing delta of order 1/A makes the final error comparable to the cell width. For R/A at least the tube width, the flat cylinder estimate has a width factor of order (R/A)^(k+2). Dividing by the full cell volume should cancel that factor. This would give a recurrence constant independent of A, provided all partition, enlargement, overlap and coordinate constants are controlled uniformly.

The local weights can be defined by restricting each original weight to tubes meeting the intersection of the cell and the original ball. For a point in that intersection, the restricted density equals the original density. For every point of the entire cell, a meeting witness gives the enlarged reference-cylinder bound. Thus the cell-budget argument should use finite additivity over disjoint cells and pointwise domination; no triangle inequality at the exponent below one is needed. The reference center correction must use the same global physical center for all cells. Taking a common upper bound for all perturbed projection norms avoids introducing a family-dependent constant. These observations specify the intended proof obligations; they have not been Lean-checked as a recurrence.

To turn this route into a proof, formalize a finite disjoint cell cover with explicit full cell volumes and enclosing-ball radii; the tube-meeting-to-reference-cylinder implication on each entire cell; the countable weighted local-family identities; and the exact cancellation of the scale factor in the global cell budget. The scale reduction must include the cell-to-ball radius constant. Only after these lemmas are checked can A be chosen large enough for the desired power loss and the aperture chosen small enough relative to A. This is a proposed recurrence strategy, not a proved inequality or a claimed resolution of fixed-aperture Kakeya.

### Verification

All 843 main results were freshly axiom-audited. All 574 retained continuation results and all 61 new results were freshly compiled and axiom-audited, with no warnings or admissions. The default build passes. The final inventory check covers all 635 continuation results and rejects duplicate names, stale hashes and nonstandard axioms. Only `propext`, `Classical.choice` and `Quot.sound` are allowed. Continuation sources remain separate from the default 843-result main inventory.
## Revision 0.35 — fixed-aperture Kakeya by cell induction

This section is the current status and supersedes historical statements that fixed-aperture complementary-block Kakeya is still open. **Theorem 1.1 remains unproved.**

Revision 0.35 adds **59 results in 31 continuation files**: **843 unchanged main results + 694 continuation results = 1537 distinct results**. No result is promoted into the main inventory, and definitions/instances are not counted as theorems.

### Closed analytic gap

For any k >= 2 complementary Euclidean blocks of dimensions d_i with sum d_i = m, a common coordinate equivalence with uniformly bounded forward and inverse norms gives positive constants C and delta, chosen before the coordinate map, all countable weighted families, centers and scales. Every eta > 0 admits the estimate

\[
\int_{B(x_0,R)}\Bigl(\prod_{i=1}^k\sum_t u_{i,t}\mathbf1_{T_{i,t}}(x)\Bigr)^{1/(k-1)}dx
\le C R^\eta w^{m-\eta}\Bigl(\prod_i\sum_tu_{i,t}\Bigr)^{1/(k-1)},\qquad R\ge w>0.
\]

The families may be projection cylinders or genuine metric neighborhoods of affine fibers, with the defining maps within delta of the complementary reference projections. The metric-tube version does not assume an additional operator-norm bound on each family: that bound follows from projection closeness. It covers the short-radius case by an elementary ball-volume estimate. Neither theorem requires delta*R <= L*w.

The abstract transfer theorem explicitly assumes a flat input. In the complementary Euclidean-block applications that input is **proved**, using the general block Loomis–Whitney theorem, physical Haar transport, exact complementary ball volumes and the identity sum_i sum_{j != i} d_j = (k-1)m.

### Proof chain and entry points

| Stable ID | Verified step | Main declarations |
|---|---|---|
| N2-ANA-065 | Preserve density after retaining meeting tubes; dominate total meeting weights on full cells; cancel equal positive finite cell volumes | `cellMeetingWeight_density_eq`, `cellMeetingWeight_sum_budget`, `finite_ball_cell_partition` |
| N2-ANA-066 | Cell recurrence, real-radius induction and a scale choice for every positive power loss | `cylinder_ball_recurrence`, `real_scale_induction`, `exists_power_contraction_scale`, `uniform_fixed_aperture_from_flat` |
| N2-ANA-067 | Proved flat input and fixed-aperture cylinder/metric estimates for arbitrary complementary Euclidean blocks | `uniform_flat_dependent_block_input`, `uniform_fixed_aperture_dependent_blocks`, `uniform_fixed_aperture_dependent_metric_tubes` |
| N2-ANA-068 | Exact prior five-dimensional target; concrete six-dimensional coordinates and actual normal kernels | `uniform_fixed_aperture_311_kakeya`, `uniform_actual_normal_four_fixed_aperture`, `uniform_actual_normal_four_fixed_aperture_metric` |
| N2-GEO-044 | Quantitative correction from a nearby line direction to an annihilating projection; actual closed metric neighborhoods | `directionAlignedProjection_norm_bound`, `affineLineTube_eq_infDist` |
| N2-ANA-069 | Fixed directional line-tube neighborhoods from flat input; unit references use canonical norm-one duals | `uniform_directional_line_kakeya_from_flat`, `uniform_unit_directional_line_kakeya_from_flat`, `uniform_directional_line_dependent_blocks` |

The local weight is the original weight if a tube meets the cell inside the large ball, and zero otherwise. Its density agrees with the original density on that intersection. If a tube meets the cell, the full cell lies in a corrected-center reference cylinder of width w + delta*R + M*diam(cell). At cell side b, the conditions w <= b and delta*R <= b reduce this to (2+M*sqrt(m))*b. Flat integration bounds the sum of cell weight products after exact cancellation of b^m.

Local estimates are applied to containing balls of radius c*b, with c >= max(1,sqrt(m)/2). Taking b=R/B and delta=1/B produces a fixed recurrence multiplier H and child ratio c/B. The choice H*(c/B)^eta <= 1 closes induction on dyadic upper bounds for real radii. The proof quantifies over all centers and all reweightings directly; it does not form a supremum over a class of families. It does not use quasi-norm Minkowski, discard boundary cells, or assume finite total weights.

For line directions the explicit correction is A = Q - ell tensor ((ell(v))^(-1) Q(v)). If Q(v0)=0, ell(v0)=1, and v is close enough to v0, then A(v)=0 and norm(A-Q) <= 2*N*M*norm(v-v0). This is the bridge between directional and operator perturbations. `affineLineTube_eq_infDist` proves exact agreement with the closed metric neighborhood of the entire affine line.

### Relation to the article and remaining work

`uniform_block_finite_directional_kakeya` connects the result to the existing `FiniteDirectionalKakeya` packet interface on open balls, with exact agreement between the old and new tube definitions.

`uniform_directional_line_dependent_blocks` discharges the flat input for line families around unit reference directions in complementary Euclidean blocks, with constants before the coordinate map and the reference directions.

The exact proposition `UniformFixedAperture311Kakeya`, introduced as an open target in revision 0.32, is now proved. The six-dimensional estimates are instantiated on the actual three-dimensional selected normal space and the other three normal lines, with the previously explicit unit-normal, shape, Gram and membership hypotheses. The analytic estimates use closed balls and all R >= w > 0, so the range is stronger than the R >= 1 restriction in the five-dimensional target.

The following are still unfinished:

1. Assemble arbitrary-dimensional actual thin-normal coordinates into the dependent Euclidean block model. The scalar simultaneous kernel result and the analytic theorem are proved separately; the general grouping/kernel correspondence is still required.
2. Fully instantiate External input 2 from an arbitrary independent tuple of reference lines. The new directional transfer proves the analytic implication from compatible flat data, but the general independent-line coordinate construction has not been supplied.
3. Construct the coherent local chart/frame-family applications needed by Remark 4.2. A global continuous frame is neither asserted nor needed.
4. Prove uniform wave-packet estimates and the actual localized restriction recursion of External input 1. Fixed-aperture Kakeya is a component, not the localized restriction theorem.
5. Complete the retained intrinsic density/atlas, descent/algebraic, Corollary 4.3 and epsilon-removal obligations, and Theorem 1.1.

### Verification

All **59 new results** were freshly compiled and their printed axiom dependencies checked. Only `propext`, `Classical.choice` and `Quot.sound` occur; no admitted proofs or extra axioms are introduced. The default incremental build passes.

All 152 main modules and 248 prior continuation sources, together with their retained audit outputs, are byte-identical to revision 0.34. Their saved audit outputs are revalidated. They were **not freshly recompiled in this session**. The continuation audit script can rebuild and audit the entire 694-result continuation inventory; it remains separate from the default main build.
## Revision 0.36 — proved external Kakeya and actual mixed chart families

This is the authoritative current addendum. Earlier revision sections describe the state at those revisions.

Revision 0.36 adds **71 results in 34 files**, bringing the separate continuation inventory to **765 results in 313 files** and the total to **1,608 distinct checked results**, including the unchanged 843 main results.

- **N2-ANA-070 / N2-EXT-002:** `weighted_kakeya_external_all_dimensions` proves the literal `WeightedKakeyaExternalGoal m k` for every `k ≥ 2`. Independent unit reference lines determine the aperture and coefficient before all radii, widths and finite weighted families. Basis completion handles arbitrary codimension. The codimension-two article case, the unlocalized subensemble, and common constants on compact independent unit tuples are proved. No external Kakeya axiom remains in these statements.
- **N2-ANA-071:** `geometric_subdivision_proved_kakeya` and `geometric_original_grid_bound_proved_kakeya` discharge the external Kakeya assumption in the existing Section 3 subdivision and original-input packet-grid estimate. Their other explicit geometric, packet and scale hypotheses remain.
- **N2-GEO-045:** General-dimensional coefficient regrouping yields one three-dimensional block and the remaining line blocks. The exact kernels are the selected actual normal space and the other actual normal lines, with common forward and inverse coordinate bounds.
- **N2-ANA-072:** `uniform_actual_normal_block_fixed_aperture_cylinders` and its metric-tube counterpart instantiate the proved analytic estimate in every article dimension. Constants precede the geometric data under the stated common shape and Gram bounds.
- **N2-GEO-046 / N2-ANA-073:** Orthogonal-projection perturbations give nearby-subspace estimates for genuine affine-subspace metric tubes. Witness tubes agree exactly with closed distance neighborhoods and are measurable. This removes auxiliary projection maps from the actual-normal conclusion.
- **N2-ANA-074:** `geometric_nonzero_chart_subspace_kakeya` gives a common buffer, aperture and finite coefficient over supported tuples, nearby frames, selected indices and moved thin charts at arbitrary normal levels. It uses the prior adjoint normal-space analysis and does not impose a projected-normal-zero condition.
- **N2-GEO-047 / N2-ANA-075:** A common inverse derivative bound and second derivative bound yield a common parameter radius controlling normal-plane variation. `geometric_mixed_chart_normal_kakeya` combines the actual thin chart and the other hypersurface charts, derives their center normal identities, and proves the countable weighted normal-tube estimate for sampled chart normals. The theorem assumes the stated common chart regularity and inverse bounds; it does not itself construct the chart family or prove Fourier restriction.

- **N2-ANA-076:** `uniform_linear_dependent_block_L2` and `uniform_actual_normal_block_L2` give the physical L2-to-L^(2/(k-1)) flat estimate in arbitrary complementary block dimensions and on the article's actual normal configuration, with constants before the splitting and the inputs. This extends the prior six-dimensional application.

**Verification.** All 71 new results are freshly compiled, with complete transitive axiom output and no warnings. Only `propext`, `Classical.choice` and `Quot.sound` occur. All 152 main source modules and 279 older continuation source modules, together with their retained audit output, are checked byte-for-byte against revision 0.35. Retained compiler output is revalidated; fresh compilation of unchanged earlier results is not claimed. The incremental default build passes. Continuation modules remain separate from the default main build.

**Still open.** External input 1, including the uniform localized Fourier restriction recursion and its localization gain; full article-level wave-packet and chart-partition assembly; Corollary 4.3; polynomial partitioning and geometric descent; the remaining tangent/nontangent packet estimates; epsilon removal; Theorem 1.1. The new normal-tube estimate supplies the Kakeya part of Remark 4.2, not the whole localized restriction argument.


## Revision 0.37 — localization recursion and actual chart bridges

Authoritative current count: **843 main + 817 continuation = 1,660 distinct checked results**. Added **52 results in 18 files**.

Uniform square-root recurrence closure with changing capped localization states and a Kakeya coefficient, conditional on the analytic recurrence, including additive-error absorption. Exact double-enlargement active-level and normalization bookkeeping. Actual measured thin-fiber chart construction and mixed normal-tube Kakeya. Full all-hypersurface subspace and chart Kakeya, with every factor retained. Finite normalized original-strip operator constants and exact polynomial initialization. Exact summable phase expansions and integration at the uncertainty scale. The vector-valued restriction reduction, actual Fourier recurrence, Corollary 4.3 and the main theorem remain open.

Stable IDs: N2-ANA-077 (changing-state scalar recursion); N2-ANA-078 (normalized original-strip operator and polynomial base); N2-ANA-079 (all-factor subspace/chart Kakeya); N2-ANA-080 (uncertainty-scale phase series); N2-GEO-048 (actual measured fiber charts); N2-GEO-049 (localization scale and active-level bookkeeping).

The unproved analytic inputs are stated as hypotheses, never axioms. No theorem identifies the original-strip best constant with the scale-dependent ensemble constant. The two normal configurations retain the same number of factors. The phase expansion does not by itself provide the missing vector-valued estimate.

52 new results freshly compiled and axiom-audited, with no warnings or admissions. The 843 main and 765 prior continuation results retain their v36 compiler audits: their source and log bytes are unchanged and all retained declaration/axiom reports are revalidated. The default incremental lake build passes. Continuation files are audited separately from the default build.

New sources: `continuation/LineSubspaceKakeyaV37.lean`, `continuation/CompactLineSubspaceV37.lean`, `continuation/PhaseSeriesV37.lean`, `continuation/IntegratedPhaseSeriesV37.lean`, `continuation/ExtensionPhaseSeriesV37.lean`, `continuation/PhaseSeriesSquareV37.lean`, `continuation/ExtensionPhaseSquareV37.lean`, `continuation/DistancePhaseSquareV37.lean`, `continuation/FullChartKakeyaV37.lean`, `continuation/LocalizationScalesV37.lean`, `continuation/LocalizationBookkeepingV37.lean`, `continuation/LocalizedOperatorConstantV37.lean`, `continuation/LocalizedPolynomialBaseV37.lean`, `continuation/SqrtScaleInductionV37.lean`, `continuation/LocalizedRecurrenceErrorV37.lean`, `continuation/LocalizedRecurrenceV37.lean`, `continuation/MeasuredFiberChartsV37.lean`, `continuation/MeasuredMixedKakeyaV37.lean`.


## Revision 0.38 — article contributions with external inputs assumed

This addendum supersedes earlier scope and open-task descriptions. **843 main + 883 continuation = 1,726 checked results**, including **66 new results in 20 files**.

Article-only continuation with explicit borrowed inputs. Uniform localization atlas and Corollary 4.3/integral applications relative to a specialized external chart estimate; both trimmed-cell counts for actual multivariate polynomial sign labels; bounded Hilbert packet cell-energy budgets; substantial-mass simultaneous energy selection; actual orthogonal pushforward of the reset density and its exact lifted-cell mass; conditional final epsilon-removal application. The segment-lift endpoint, displacement and avoidance-of-cuts implications are proved for a supplied continued path; its existence/continuation, complete descent/tangent assembly, decay and the main recurrence remain open.

| Stable ID | Checked contribution and precise boundary |
|---|---|
| N2-ANA-081 | Uniform atlas, C*mu strip and q0 integral assembly from the specialized external chart estimate; full chart-certificate packaging is still separate. |
| N2-GEO-050 | Both Lemma 5.2 counts on actual polynomial sign labels: degree+1 and M*(K+2)^n. The nontangent bound assumes only the stated external covering input and article witness hypotheses. Lemma 5.1 is still open. |
| N2-ANA-082 | Actual bounded Hilbert packet sums inherit these two cell multiplicity budgets. Full surface atlas/cap aggregation remains open. |
| N2-ANA-083 | Reset density is finite, projects absolutely continuously under the actual orthogonal projection, and has exactly the correct lifted-cell mass. |
| N2-ANA-084 | Substantial-mass cell selection satisfying simultaneous original energy budgets. |
| N2-GEO-051 | Segment-lift endpoint, uniform displacement and avoidance-of-cuts bounds for a supplied path; existence and continuation remain open. |
| N2-ANA-085 | Final epsilon-removal application relative to External input 4; local recurrence and surface test decay are not assumed as external results. |

The proofs of External input 1, the algebraic tools and epsilon removal are no longer project tasks. See `EXTERNAL_INPUT_POLICY.md`. External Kakeya was already proved and remains retained. The central article recurrence and both main theorem targets are still open.

All 66 new results in 20 files freshly compiled with complete axiom reports, no warnings and no admissions. The 843 main and 817 older continuation results retain their earlier audits: source and log bytes are unchanged from v37, and retained reports are revalidated. Default incremental build passes. Continuation modules remain separately audited.
