# Revision 0.56: sharp interval decay and full curved graph germs

The new analysis proves the actual one-dimensional frequency power **1/2**. The full surface Fourier-decay assertion (8.4), `SurfaceTestDecay`, and the named global restriction theorem remain open. The certified local theorem from revision 55 is retained unchanged, relative to the agreed borrowed inputs.

This revision adds **43 results in 27 modules**: **843 main + 1,566 continuation = 2,409 distinct checked results**. Declaration counts describe the checked inventory; they are not a completion percentage.

## What changed

| Obligation | Revision 55 | Revision 56 |
|---|---|---|
| Actual one-dimensional oscillatory decay | Power 1/5, with upper derivative budgets | Power 1/2, explicit coefficient, no curvature upper bound |
| Coefficient before frequency | Explicit supplied budgets | A nonnegative coefficient also obtained from the actual fixed amplitude |
| Integration over remaining parameters | Assembly pending | Actual product-integral half-decay proved by Fubini under actual integrability and amplitude budgets |
| Curved surface geometry | Constructed normal slices | Constructed full regular graph germs and a curved horizontal slicing direction, with joint parameter/angular curvature bounds |
| Test density beyond the original compact support | Full-support scope issue identified | Actual compact auxiliary patch, exact original Hausdorff-integral restriction, finite mass, test integrability, finite graph cover |
| Away from the normal line | Pending | Actual tangent detection and graph curves with positive first phase derivative constructed; the integral estimate remains |
| Full surface estimate and global theorem | Open | Open |

## The checked interval estimate

Let the complex amplitude `A` be C1 and the real phase `φ` be C2 on the real line. Suppose `a ≤ b`, `freq > 0`, `c > 0`, `M ≥ 0`, and on `[a,b]`:

- `|φ''(t)| ≥ c`;
- `‖A(t)‖ ≤ M`.

Then `N2Restriction.curved_oscillatory_half_decay` proves

```text
norm (integral from a to b of A(t) * exp(i * freq * φ(t)))
  ≤ (((2 + 2*pi)*M + integral from a to b of norm(A'(t))) / sqrt(c))
      * freq^(-1/2).
```

There is no supplied oscillatory estimate and no upper bound on `φ''` in this theorem. `exists_uniform_curved_half_decay` chooses one nonnegative coefficient before `freq`. `curved_fubini_half_decay` applies the proved fiber estimate to an actual product integral; it still needs the actual chart amplitude and its budgets to be instantiated.

The sharp step is the kernel `K_e(z)=1/(z²+e²)`. Its arctangent primitive gives

```text
integral K_e(φ') * |φ''| ≤ pi/e,
integral K_e(φ') ≤ pi/(c*e).
```

The derivative sign is established from continuity and connectedness. For the regularized inverse `q_e(z)=z/(z²+e²)`, the checked bound `|q_e'(z)| ≤ K_e(z)` replaces the earlier coarse `e^(-2)` estimate. Actual integration by parts and the exact main/remainder decomposition yield

```text
norm(original integral)
  ≤ ((2+pi)*M + integral norm(A'))/(freq*e) + pi*M*e/c.
```

Choosing `e=sqrt(c)/sqrt(freq)` proves the stated half-decay.

## Surface geometry that is now available

`exists_geometric_curved_graph_phase_box` starts from `GeometricHypotheses`, with the retained all-original-supports-nonempty branch, and constructs a full graph germ. A horizontal line in that graph realizes an actual curved tangent. One positive second-phase-derivative lower bound holds on a full graph-parameter box and a neighborhood of the positive normal direction, chosen before frequency.

This uses the existing oblique graphs. The velocity-lift theorem follows from invertibility of the defining differential together with horizontal projection. The actual level-set identity, differentiated twice, determines scalar phase curvature without requiring acceleration to be parallel to the normal.

The globally smooth height equals the original height on a germ. The complete slicing box must still be shrunk into that germ before surface integration. The current box theorem is a curvature statement, not a surface-integral estimate.

For every compact ambient test density supported in the regular neighborhood, the entire intersection of its topological support with the extended surface is now a genuine compact `SmoothPatch`. Its Hausdorff measure, Fourier integral, finite mass and test-density integrability are proved with the original measure. It need not be contained in the original compact patch support.

## Remaining work

1. Put the nonzero curved horizontal direction into product coordinates and shrink the full box into the actual graph germ.
2. Establish the exact smooth Hausdorff graph density and its derivative bounds for the localized test amplitude. Preserve `coordinateHausdorffFactor d`; the retained bounded measurable density alone is insufficient.
3. Instantiate the checked Fubini estimate on those actual amplitudes.
4. Complete uniform nonstationary full-chart bounds away from both normal directions, and handle the negative-normal curved branch.
5. Assemble a finite smooth spatial/angular partition and low-frequency L1 control into `SurfaceTestDecay`, then instantiate the retained conditional global theorem.

No new borrowed assumptions or project axioms were added. Detailed contracts and implementation plans are in `verification/theorem-contracts-v56.json`, `verification/graph-slicing-plan-v56.json`, and `verification/smooth-density-interface-plan-v56.json`.

## Verification

All 43 new declarations compiled individually and passed a combined axiom audit using only `propext`, `Classical.choice`, and `Quot.sound`, with no warnings or admissions. The default project build passed (2,964 jobs). All 1,566 continuation source/report hashes were validated, and all 948 previous Lean files remain byte-identical. The main 843-result axiom report is retained; it was not rerun this session.

Exact run records are in `verification/session-v56.json`. The ordinary continuation audit recompiles continuation files; `--check-existing-output` checks saved reports and hashes only.
