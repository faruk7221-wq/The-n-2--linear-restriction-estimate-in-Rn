import continuation.CertifiedMainGlobalV58
import continuation.CertifiedNormalGeometryV59

/- Revision 59 certification entry. These are implications from explicitly
   named borrowed theorem statements; #print axioms does not prove premises. -/
#print N2Restriction.MainLocalGoal
#print N2Restriction.MainGlobalGoal
#print N2Restriction.CertifiedLocalizedRestrictionInput
#check N2Restriction.CertifiedArticleLocalizationAtlas.localized_normal_certificate
#check N2Restriction.mainGoals_of_certified_borrowed_inputs
#print axioms N2Restriction.CertifiedArticleLocalizationAtlas.localized_normal_certificate
#print axioms N2Restriction.mainGoals_of_certified_borrowed_inputs
