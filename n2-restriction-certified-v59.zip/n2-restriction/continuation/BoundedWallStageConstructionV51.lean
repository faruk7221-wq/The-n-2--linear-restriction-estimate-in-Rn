import continuation.WallStageConstructionV41
import continuation.PolynomialStageBudgetV51
namespace N2Restriction
open Set Metric MeasureTheory
open scoped BigOperators ENNReal

/-- The actual dimension-drop constructor propagates fixed degree, width
and mass ceilings, with no dependence on the physical radius. -/
theorem polynomial_wall_stage_with_budget {n k m D : ℕ} {I : Type*} [Fintype I] [Nonempty I]
    {μ : Fin k → Measure (Ambient n)} {g : Fin k → Ambient n → ℂ}
    {a R r : ℝ} {M₀ err : ENNReal} (S : PolynomialStage μ g a R r M₀ err m)
    (B : PolynomialStageBudget) (hB : S.withinBudget B)
    (p : I → MvPolynomial (Fin n) ℝ) (V : Submodule ℝ (Ambient n)) (P : I → V → ℝ)
    (cuts : Set (Ambient n)) (hc : IsClosed cuts)
    (hw : ∀ x ∈ S.region, Nonempty (ShortLiftWitness V (polynomialLevelMap S.equations)
      {x | polynomialLevelMap S.equations x = 0} cuts (S.multiplier*r) x))
    (heval : ∀ i x, MvPolynomial.eval (fun j => x j) (p i) = P i (V.orthogonalProjection x))
    (hp : ∀ i, (p i).totalDegree ≤ D)
    (ht : ∀ i x, polynomialLevelMap S.equations x = 0 → MvPolynomial.eval (fun j => x j) (p i) = 0 →
      ∃ v, fderiv ℝ (polynomialLevelMap S.equations) x v = 0 ∧
        fderiv ℝ (fun y : Ambient n => MvPolynomial.eval (fun j => y j) (p i)) x v ≠ 0)
    {θ : ENNReal} (hθ : θ ≠ 0) (hθfin : θ ≠ ⊤)
    (hpos : 0 < θ * (∫⁻ x in S.region, ‖extensionProduct μ (fun _ => id) g x‖ₑ ^ a))
    (hwall : θ * (∫⁻ x in S.region, ‖extensionProduct μ (fun _ => id) g x‖ₑ ^ a) ≤
      ∫⁻ x in S.region ∩ thickening (S.multiplier*r)
        {x | (∏ i, P i (V.orthogonalProjection x)) = 0},
        ‖extensionProduct μ (fun _ => id) g x‖ₑ ^ a) :
    m < n ∧ ∃ i, ∃ S' : PolynomialStage μ g a R r M₀ err (m+1),
      S'.equations = Fin.cons (p i) S.equations ∧
      S'.degreeBound = max S.degreeBound D ∧
      S'.multiplier = 5*S.multiplier ∧
      S'.constant = max 1 (S.constant*(Fintype.card I : ENNReal)/θ) ∧
      S'.region ⊆ S.region ∧
      S'.withinBudget (B.advance D 5 (by norm_num)
        ((Fintype.card I : ENNReal)/θ) (ENNReal.div_ne_top (by simp) hθ)) := by
  obtain ⟨hm,i,S',heq,hdeg,hmult,hconst,hsub⟩ := polynomial_wall_stage S p V P cuts hc hw heval hp ht hθ hθfin hpos hwall
  refine ⟨hm,i,S',heq,hdeg,hmult,hconst,hsub,?_⟩
  apply polynomial_stage_budget_update S S' B hB D 5 (by norm_num)
    ((Fintype.card I : ENNReal)/θ) (ENNReal.div_ne_top (by simp) hθ)
  · rw [hdeg]
  · rw [hmult]
  · rw [hconst]
    simp only [div_eq_mul_inv,mul_assoc,le_refl]

end N2Restriction
#print axioms N2Restriction.polynomial_wall_stage_with_budget
