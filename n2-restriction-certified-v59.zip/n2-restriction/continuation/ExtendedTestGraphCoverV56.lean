import continuation.ExtendedTestSupportV56
namespace N2Restriction
open Set MeasureTheory

/-- Concrete regular graph charts cover the entire test-supported portion of
the extended surface, without restricting the test to the old compact patch. -/
theorem SmoothPatch.exists_extended_test_graph_cover {d : ℕ} (S : SmoothPatch (d+1))
    (ψ : Ambient (d+1) → ℂ) (hψ : HasCompactSupport ψ)
    (hinside : tsupport ψ ⊆ S.neighborhood) :
    ∃ (m : ℕ) (P : Fin m → LocalGraphPatch d),
      (tsupport ψ ∩ S.extendedSurface ⊆ ⋃ j, (P j).carrier) ∧
      (∀ j, (P j).carrier ⊆ S.extendedSurface) ∧
      ∀ j u, u ∈ (P j).domain →
        (P j).rotation (graphPoint u ((P j).phase u)) ∈ S.extendedSurface := by
  obtain ⟨T,hT,hE,-,-⟩ := S.exists_extended_test_patch ψ hψ hinside
  obtain ⟨m,P,hcover,hcarrier,hdomain⟩ := T.exists_finite_graph_cover
  exact ⟨m,P,by simpa only [hT] using hcover,
    by simpa only [hE] using hcarrier,by simpa only [hE] using hdomain⟩
end N2Restriction
#print axioms N2Restriction.SmoothPatch.exists_extended_test_graph_cover
