import continuation.ActualNormalFourL2V34
import continuation.UniformMetricTubes3111V33

set_option maxHeartbeats 800000
namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal BigOperators
attribute [local instance] tripleProductHaar fourProductHaar

/-- Genuine metric tubes around the actual four normal subspaces. The
uniform constant precedes all geometric data, tube families and scales.
The scale-dependent aperture restriction remains explicit. -/
theorem uniform_actual_normal_four_metric_tubes (i : Fin 4)
    (M c : ℝ) (hM : 0 ≤ M) (hc : 0 < c) :
    ∃ K : ℝ≥0∞, 0 < K ∧ K ≠ ⊤ ∧ ∀ (S : Fin 4 → SmoothPatch (6))
      (z : Fin 4 → Ambient (6)) (q : Ambient (6) × Ambient (6))
      (N : Submodule ℝ (Ambient (6))) (_b : OrthonormalBasis (Fin 3) ℝ N),
      (∀ j, ‖(S j).normal (z j)‖ = 1) → ‖(S i).shape (z i)‖ ≤ M →
      ‖q.1‖ ≤ 1 → ‖q.2‖ ≤ 1 →
      (S i).normal (z i) ∈ N → (S i).shape (z i) q.1 ∈ N →
      (S i).shape (z i) q.2 ∈ N →
      c ≤ Matrix.det (Matrix.gram ℝ (nearbyWedgeVectors S z i q)) →
      ∃ C : Ambient 6 ≃L[ℝ] ((Ambient 1 × Ambient 1) × Ambient 3) × Ambient 1,
        FourNormalKernels S z i N C ∧
    ∀ (P₀ P₁ P₂ P₃ : Type) [Countable P₀] [Countable P₁] [Countable P₂] [Countable P₃]
    (A₀ : P₀ → Ambient 6 →L[ℝ] (Ambient 1 × Ambient 1) × Ambient 3)
    (A₁ : P₁ → Ambient 6 →L[ℝ] (Ambient 1 × Ambient 1) × Ambient 1)
    (A₂ : P₂ → Ambient 6 →L[ℝ] (Ambient 3 × Ambient 1) × Ambient 1)
    (A₃ : P₃ → Ambient 6 →L[ℝ] (Ambient 3 × Ambient 1) × Ambient 1)
    (z₀ : P₀ → (Ambient 1 × Ambient 1) × Ambient 3) (u₀ : P₀ → ℝ≥0∞)
    (z₁ : P₁ → (Ambient 1 × Ambient 1) × Ambient 1) (u₁ : P₁ → ℝ≥0∞)
    (z₂ : P₂ → (Ambient 3 × Ambient 1) × Ambient 1) (u₂ : P₂ → ℝ≥0∞)
    (z₃ : P₃ → (Ambient 3 × Ambient 1) × Ambient 1) (u₃ : P₃ → ℝ≥0∞)
    (x₀ : Ambient 6) (R w δ L : ℝ) (_hL : 0 ≤ L) (_hδ : 0 ≤ δ) (_hR : 0 ≤ R) (_hw : 0 ≤ w) (_hscale : δ * R ≤ L * w)
    (_hA₀ : ∀ t, ‖A₀ t - fourProjectionZero C‖ ≤ δ)
    (_hA₁ : ∀ t, ‖A₁ t - fourProjectionOne C‖ ≤ δ)
    (_hA₂ : ∀ t, ‖A₂ t - fourProjectionTwo C‖ ≤ δ)
    (_hA₃ : ∀ t, ‖A₃ t - fourProjectionThree C‖ ≤ δ)
    (_hN₀ : ∀ t, ‖A₀ t‖ ≤ L)
    (_hN₁ : ∀ t, ‖A₁ t‖ ≤ L)
    (_hN₂ : ∀ t, ‖A₂ t‖ ≤ L)
    (_hN₃ : ∀ t, ‖A₃ t‖ ≤ L)
    , (∫⁻ x in closedBall x₀ R, (tubeDensity (fun t => affineFiberTube (A₀ t) (z₀ t) w) u₀ x *
       tubeDensity (fun t => affineFiberTube (A₁ t) (z₁ t) w) u₁ x *
       tubeDensity (fun t => affineFiberTube (A₂ t) (z₂ t) w) u₂ x *
       tubeDensity (fun t => affineFiberTube (A₃ t) (z₃ t) w) u₃ x) ^ (1 / 3 : ℝ)) ≤
      K * ENNReal.ofReal (L * w) ^ 6 *
        ((∑' t, u₀ t) * (∑' t, u₁ t) * (∑' t, u₂ t) * (∑' t, u₃ t)) ^ (1 / 3 : ℝ) := by
  obtain ⟨B,hB,hcoord⟩ := uniform_thin_normal_four_coordinates i M c hM hc
  obtain ⟨K,hK,hfin,hbound⟩ := uniform_centered_small_aperture_3111_metric_tubes B hB.le
  refine ⟨K,hK,hfin,?_⟩
  intro S z q N b hunit hshape hq₁ hq₂ hN hA₁ hA₂ hG
  obtain ⟨C,he,hei,hker⟩ := hcoord S z q N b hunit hshape hq₁ hq₂ hN hA₁ hA₂ hG
  exact ⟨C,hker,hbound C he hei⟩

end N2Restriction

#print axioms N2Restriction.uniform_actual_normal_four_metric_tubes
