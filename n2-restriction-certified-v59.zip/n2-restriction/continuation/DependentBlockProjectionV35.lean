import continuation.LinearDependentBlockV34
import continuation.FlatCylinderBoundV35

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal BigOperators

/-- Complementary block projection in actual physical coordinates. -/
noncomputable def dependentBlockProjection {m n : ℕ} (d : Fin (n+2) → ℕ)
    (e : Ambient m ≃L[ℝ] (∀ i, Ambient (d i))) (i : Fin (n+2)) :
    Ambient m →L[ℝ] (∀ j, Ambient (d (i.succAbove j))) :=
  ContinuousLinearMap.pi (fun j =>
    (ContinuousLinearMap.proj (i.succAbove j)).comp e.toContinuousLinearMap)

/-- Deleting one block cannot increase the reference projection norm. -/
theorem dependentBlockProjection_norm_le {m n : ℕ} (d : Fin (n+2) → ℕ)
    (e : Ambient m ≃L[ℝ] (∀ i, Ambient (d i))) (i : Fin (n+2)) :
    ‖dependentBlockProjection d e i‖ ≤ ‖e.toContinuousLinearMap‖ := by
  apply ContinuousLinearMap.opNorm_le_bound _ (norm_nonneg _)
  intro x
  apply (pi_norm_le_iff_of_nonneg (by positivity)).mpr
  intro j
  exact (norm_le_pi_norm (e x) (i.succAbove j)).trans (e.toContinuousLinearMap.le_opNorm x)

/-- Sum of all complementary dimensions: each block occurs exactly k-1 times. -/
theorem sum_complementary_dimensions (n : ℕ) (d : Fin (n+2) → ℕ) :
    (∑ i : Fin (n+2), ∑ j : Fin (n+1), d (i.succAbove j)) =
      (n+1) * ∑ i, d i := by
  have hi (i : Fin (n+2)) : (∑ j : Fin (n+1), d (i.succAbove j)) + d i = ∑ j, d j := by
    simpa [add_comm] using (Fin.sum_univ_succAbove d i).symm
  have hs := Finset.sum_congr (s₁ := Finset.univ) rfl (fun i _ => hi i)
  rw [Finset.sum_add_distrib] at hs
  simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, smul_eq_mul] at hs
  nlinarith

/-- The cross-sectional product ball has exactly its expected dimension
power, with respect to the product of Euclidean volume measures. -/
theorem dependent_block_ball_volume (n : ℕ) (d : Fin (n+2) → ℕ) (i : Fin (n+2))
    (z : ∀ j, Ambient (d (i.succAbove j))) (r : ℝ) (hr : 0 ≤ r) :
    (Measure.pi (fun j => (volume : Measure (Ambient (d (i.succAbove j)))))) (closedBall z r) =
      ENNReal.ofReal r ^ (∑ j, d (i.succAbove j)) *
      (Measure.pi (fun j => (volume : Measure (Ambient (d (i.succAbove j)))))) (closedBall 0 1) := by
  rw [Measure.addHaar_closedBall' _ z hr]
  simp only [Module.finrank_pi_fintype, finrank_euclideanSpace, Fintype.card_fin, ENNReal.ofReal_pow hr]

end N2Restriction

#print axioms N2Restriction.dependentBlockProjection_norm_le
#print axioms N2Restriction.dependent_block_ball_volume
#print axioms N2Restriction.sum_complementary_dimensions
