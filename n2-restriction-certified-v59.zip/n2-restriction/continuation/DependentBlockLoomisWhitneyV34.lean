import continuation.SigmaBlockCoordinatesV34

namespace N2Restriction
open MeasureTheory
open scoped ENNReal BigOperators

/-- General finite-block Loomis–Whitney for different nonempty coordinate
spaces and sigma-finite measures, with constant one. The disjoint-union
carrier reduces the dependent product to the common-carrier induction. -/
theorem dependent_block_loomis_whitney (n : ℕ) (X : Fin (n+2) → Type*)
    [∀ i, MeasurableSpace (X i)] [∀ i, Inhabited (X i)]
    (μ : ∀ i, Measure (X i)) [∀ i, SigmaFinite (μ i)]
    (f : ∀ i : Fin (n+2), (∀ j, X (i.succAbove j)) → ℝ≥0∞)
    (hf : ∀ i, Measurable (f i)) :
    (∫⁻ x, (∏ i, f i (i.removeNth x)) ^ (1 / ((n : ℝ)+1)) ∂Measure.pi μ) ≤
      ∏ i, (∫⁻ y, f i y ∂Measure.pi (fun j => μ (i.succAbove j))) ^ (1 / ((n : ℝ)+1)) := by
  classical
  let ν : Fin (n+2) → Measure (Sigma X) := fun i => (μ i).map (Sigma.mk i)
  haveI (i : Fin (n+2)) : SigmaFinite (ν i) := (measurableEmbedding_sigmaBlock X i).sigmaFinite_map
  have hp (i : Fin (n+2)) : MeasurePreserving (Sigma.mk i) (μ i) (ν i) :=
    ⟨(measurableEmbedding_sigmaBlock X i).measurable,rfl⟩
  let g : Fin (n+2) → (Fin (n+1) → Sigma X) → ℝ≥0∞ :=
    fun i y => f i (fun j => sigmaBlockRetract X (i.succAbove j) (y j))
  have hg (i : Fin (n+2)) : Measurable (g i) :=
    (hf i).comp (measurable_pi_iff.mpr (fun j =>
      (measurable_sigmaBlockRetract X _).comp (measurable_pi_apply j)))
  have hb := finite_block_loomis_whitney n ν g hg
  have hm (i : Fin (n+2)) :
      (∫⁻ y, f i y ∂Measure.pi (fun j => μ (i.succAbove j))) =
      ∫⁻ y, g i y ∂Measure.pi (fun j => ν (i.succAbove j)) := by
    have h := (measurePreserving_pi (fun j => μ (i.succAbove j))
      (fun j => ν (i.succAbove j)) (fun j => hp (i.succAbove j))).lintegral_comp (hg i)
    simpa only [g, sigmaBlockRetract_mk] using h
  have hprod : Measurable (fun x : Fin (n+2) → Sigma X =>
      (∏ i, g i (i.removeNth x)) ^ (1 / ((n : ℝ)+1))) := by
    apply Measurable.pow_const
    apply Finset.measurable_prod
    intro i _
    exact (hg i).comp (measurable_pi_iff.mpr (fun j => measurable_pi_apply _))
  have ht := (measurePreserving_pi μ ν hp).lintegral_comp hprod
  have htot : (∫⁻ x, (∏ i, f i (i.removeNth x)) ^ (1 / ((n : ℝ)+1)) ∂Measure.pi μ) =
      ∫⁻ x, (∏ i, g i (i.removeNth x)) ^ (1 / ((n : ℝ)+1)) ∂Measure.pi ν := by
    simpa only [g, Fin.removeNth, sigmaBlockRetract_mk] using ht
  rw [htot]
  simp_rw [hm]
  exact hb

end N2Restriction

#print axioms N2Restriction.dependent_block_loomis_whitney
