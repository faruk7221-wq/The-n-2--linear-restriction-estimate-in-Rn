import continuation.SubspaceBlockKakeyaV36
import continuation.ThinNormalBlockCoordinatesV36

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal BigOperators

/-- The selected normal plane followed by the remaining normal lines. -/
def actualNormalSubspaces {n : ℕ} (S : Fin (n+2) → SmoothPatch (n+4))
    (z : Fin (n+2) → Ambient (n+4)) (i : Fin (n+2)) (N : Submodule ℝ (Ambient (n+4)))
    (r : Fin (n+1) ≃ {j : Fin (n+2) // j ≠ i}) : Fin (n+2) → Submodule ℝ (Ambient (n+4)) :=
  Fin.cases N (fun a => Submodule.span ℝ {(S (r a)).normal (z (r a))})

/-- Nearby-plane Kakeya on the actual normal configuration, with geometric
subspace neighborhoods and no coordinate maps in the conclusion. -/
theorem uniform_actual_normal_subspace_kakeya {n : ℕ} (i : Fin (n+2))
    (M c : ℝ) (hM : 0 ≤ M) (hc : 0 < c) (η : ℝ) (hη : 0 < η) :
    ∃ K : ℝ≥0∞, 0 < K ∧ K ≠ ⊤ ∧ ∃ ε : ℝ, 0 < ε ∧
    ∀ (S : Fin (n+2) → SmoothPatch (n+4)) (z : Fin (n+2) → Ambient (n+4))
      (q : Ambient (n+4) × Ambient (n+4)) (N : Submodule ℝ (Ambient (n+4)))
      (_b : OrthonormalBasis (Fin 3) ℝ N),
      (∀ j, ‖(S j).normal (z j)‖ = 1) → ‖(S i).shape (z i)‖ ≤ M →
      ‖q.1‖ ≤ 1 → ‖q.2‖ ≤ 1 →
      (S i).normal (z i) ∈ N → (S i).shape (z i) q.1 ∈ N →
      (S i).shape (z i) q.2 ∈ N →
      c ≤ Matrix.det (Matrix.gram ℝ (nearbyWedgeVectors S z i q)) →
      ∃ r : Fin (n+1) ≃ {j : Fin (n+2) // j ≠ i},
      ∀ (T : Fin (n+2) → Type) [∀ j, Countable (T j)]
      (V : ∀ j, T j → Submodule ℝ (Ambient (n+4))) (a : ∀ j, T j → Ambient (n+4)),
      (∀ j t, ‖(V j t).starProjection-(actualNormalSubspaces S z i N r j).starProjection‖ ≤ ε) →
      ∀ (u : ∀ j, T j → ℝ≥0∞) (x₀ : Ambient (n+4)) (R w : ℝ), 0 < w → w ≤ R →
      (∫⁻ x in closedBall x₀ R, (∏ j, tubeDensity
        (fun t => affineSubspaceTube (V j t) (a j t) w) (u j) x) ^ (1/((n:ℝ)+1))) ≤
        K * ENNReal.ofReal R^η * ENNReal.ofReal w^(((n+4:ℕ):ℝ)-η) * (∏ j, ∑' t, u j t)^(1/((n:ℝ)+1)) := by
  obtain ⟨B,hB,hcoord⟩ := uniform_thin_normal_block_coordinates i M c hM hc
  obtain ⟨K,hK,hKfin,ε,hε,hbound⟩ := uniform_subspace_block_kakeya (n+4) n (normalBlockDimensions n)
    (normalBlockDimensions_sum n) B hB.le η hη
  refine ⟨K,hK,hKfin,ε,hε,?_⟩
  intro S z q N b hunit hshape hq₁ hq₂ hN hA₁ hA₂ hG
  obtain ⟨C,he,hei,hker0,r,hkers⟩ := hcoord S z q N b hunit hshape hq₁ hq₂ hN hA₁ hA₂ hG
  refine ⟨r, hbound C he hei (actualNormalSubspaces S z i N r) ?_⟩
  intro j
  refine Fin.cases ?_ (fun a => ?_) j
  · exact hker0.ge
  · exact (hkers a).ge

end N2Restriction

#print axioms N2Restriction.uniform_actual_normal_subspace_kakeya
