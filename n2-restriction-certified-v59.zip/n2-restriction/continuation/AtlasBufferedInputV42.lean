import continuation.AtlasCellSupportV42
import N2Restriction.MarginLocalConstant

namespace N2Restriction
open MeasureTheory Set
open scoped BigOperators ENNReal

/-- Fixed finite surface measure containing every admissible atlas packet. -/
noncomputable def PacketGraphAtlas.bufferMeasure {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) : Measure (Ambient (d+1)) :=
  (Measure.hausdorffMeasure (d : ℝ)).restrict (⋃ j, T.buffer j)

instance PacketGraphAtlas.bufferMeasure_finite {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) : IsFiniteMeasure T.bufferMeasure := T.finite_buffer_measure

noncomputable def PacketGraphAtlas.bufferInput {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S)
    (g : Lp ℂ 2 (Measure.hausdorffMeasure (d : ℝ) : Measure (Ambient (d+1)))) :
    Lp ℂ 2 T.bufferMeasure := restrictInputL2 _ (⋃ j, T.buffer j) g

/-- Restricting the selected input to the common finite surface measure
loses no energy, since its support was proved from the actual packets. -/
theorem PacketGraphAtlas.bufferInput_cell_norm {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) {r : ℝ}
    (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r) (hr : 0 < r)
    (hsmall : r ≤ T.capRadius)
    (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
    (U : (j : Fin T.size) → (Q j).centers → Set (Fin d → ℤ)) :
    ‖T.bufferInput (T.cellInput Q hr f U)‖ = ‖T.cellInput Q hr f U‖ :=
  restrictInputL2_norm_of_support _ _
    (MeasurableSet.iUnion (fun j => (T.compact_buffer j).measurableSet)) _
    (T.cellInput_support Q hr hsmall f U)

/-- The finite-buffer input has exactly the original selected extension. -/
theorem PacketGraphAtlas.bufferInput_cell_extension {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) {r : ℝ}
    (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r) (hr : 0 < r)
    (hsmall : r ≤ T.capRadius)
    (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
    (U : (j : Fin T.size) → (Q j).centers → Set (Fin d → ℤ)) (x : Ambient (d+1)) :
    extension T.bufferMeasure id (T.bufferInput (T.cellInput Q hr f U)) x =
      extension (Measure.hausdorffMeasure (d : ℝ)) id (T.cellInput Q hr f U) x :=
  extension_restrictInput _ _
    (MeasurableSet.iUnion (fun j => (T.compact_buffer j).measurableSet)) _
    (T.cellInput_support Q hr hsmall f U) id x

/-- Every finite-buffer input has the fixed atlas margin and lies on the
original extended surface. This uses the construction of the buffer. -/
theorem PacketGraphAtlas.bufferInput_margin {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S)
    (g : Lp ℂ 2 (Measure.hausdorffMeasure (d : ℝ) : Measure (Ambient (d+1)))) :
    HasFrequencySupport T.bufferMeasure id (S.extendedSurface ∩ marginRegion S.neighborhood T.margin)
      (T.bufferInput g) := by
  filter_upwards [ae_restrict_mem (MeasurableSet.iUnion (fun j => (T.compact_buffer j).measurableSet))] with x hx _
  obtain ⟨j, hj⟩ := mem_iUnion.mp hx
  exact T.buffer_inside j hj

end N2Restriction
#print axioms N2Restriction.PacketGraphAtlas.bufferInput_cell_norm
#print axioms N2Restriction.PacketGraphAtlas.bufferInput_cell_extension
#print axioms N2Restriction.PacketGraphAtlas.bufferInput_margin
