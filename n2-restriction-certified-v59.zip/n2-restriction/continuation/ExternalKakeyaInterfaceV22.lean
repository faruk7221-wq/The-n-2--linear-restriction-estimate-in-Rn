import continuation.UniformDirectionalKakeyaV22

namespace N2Restriction
open MeasureTheory Set
open scoped ENNReal BigOperators

/-- The exact remaining finite-family external input (2.3), formulated on open balls.
It is only a proposition definition; no Kakeya theorem is asserted here. -/
def WeightedKakeyaExternalGoal (n k : ℕ) : Prop :=
  ∀ ref : Fin k → Ambient n, (∀ i, ‖ref i‖ = 1) → LinearIndependent ℝ ref →
  ∀ η : ℝ, 0 < η → ∃ ε C : ℝ, 0 < ε ∧ 0 ≤ C ∧
  ∀ R b : ℝ, 1 ≤ b → b < R →
    FiniteDirectionalKakeya (volume.restrict (Metric.ball 0 R)) ref ε b
      (1 / ((k : ℝ) - 1)) (ENNReal.ofReal (C * R ^ η * b ^ ((n : ℝ) - η)))

/-- Restricting the physical integration measure preserves a finite directional estimate. -/
theorem FiniteDirectionalKakeya.mono_measure {n : ℕ} {I : Type} [Fintype I]
    {μ ν : Measure (Ambient n)} {ref : I → Ambient n} {ε w p : ℝ} {K : ℝ≥0∞}
    (h : FiniteDirectionalKakeya ν ref ε w p K) (hμν : μ ≤ ν) :
    FiniteDirectionalKakeya μ ref ε w p K := by
  intro P _ b N e he hN
  exact (lintegral_mono' hμν le_rfl).trans (h P b N e he hN)

/-- A strictly larger open ball supplies the closed integration region used by the grid proof. -/
theorem FiniteDirectionalKakeya.closedBall_of_larger_ball {n : ℕ} {I : Type} [Fintype I]
    {ref : I → Ambient n} {ε w p R R' : ℝ} {K : ℝ≥0∞}
    (h : FiniteDirectionalKakeya (volume.restrict (Metric.ball 0 R')) ref ε w p K)
    (hR : R < R') :
    FiniteDirectionalKakeya (volume.restrict (Metric.closedBall 0 R)) ref ε w p K :=
  h.mono_measure (Measure.restrict_mono (Metric.closedBall_subset_ball hR) le_rfl)

/-- Conditional realization of Section 3's initial reduction from the literal external input.
For each loss exponent the subdivision and constant are fixed before all admissible radii. -/
theorem geometric_subdivision_from_external_kakeya {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) {ν κ : ℝ} (hgeo : GeometricHypotheses S ν κ)
    (hexternal : WeightedKakeyaExternalGoal (k + 2) k) {η : ℝ} (hη : 0 < η) :
    ∃ ε C : ℝ, 0 < ε ∧ 0 ≤ C ∧ ∃ D : ∀ i, DirectionalSubdivision (S i) ε,
      ∀ a : (∀ i, Fin (D i).size),
        GeometricHypotheses (fun i => (D i).piece (a i)) ν κ ∧
        ∀ R b : ℝ, 1 ≤ b → b < R →
          FiniteDirectionalKakeya (volume.restrict (Metric.ball 0 R))
            (fun i => (S i).normal ((D i).anchor (a i))) ε b (1 / ((k : ℝ) - 1))
            (ENNReal.ofReal (C * R ^ η * b ^ (((k + 2 : ℕ) : ℝ) - η))) := by
  let A := {s : ℝ × ℝ // 1 ≤ s.2 ∧ s.2 < s.1}
  let μ := fun s : A => volume.restrict (Metric.ball (0 : Ambient (k + 2)) s.val.1)
  let w := fun s : A => s.val.2
  let p := fun _ : A => 1 / ((k : ℝ) - 1)
  let L := fun s : A => ENNReal.ofReal (s.val.1 ^ η * s.val.2 ^ (((k + 2 : ℕ) : ℝ) - η))
  have hl (ref : Fin k → Ambient (k + 2)) (hunit : ∀ i, ‖ref i‖ = 1)
      (hindep : LinearIndependent ℝ ref) : ∃ ε C : ℝ, 0 < ε ∧ 0 ≤ C ∧ ∀ s : A,
      FiniteDirectionalKakeya (μ s) ref ε (w s) (p s) (ENNReal.ofReal C * L s) := by
    obtain ⟨ε, C, hε, hC, hb⟩ := hexternal ref hunit hindep η hη
    refine ⟨ε, C, hε, hC, fun s => ?_⟩
    simpa only [μ, w, p, L, ← ENNReal.ofReal_mul hC, mul_assoc] using
      hb s.val.1 s.val.2 s.property.1 s.property.2
  obtain ⟨ε, C, hε, hC, D, hb⟩ := geometric_directional_subdivisions_of_kakeya S hgeo μ w p L hl
  refine ⟨ε, C, hε, hC, D, fun a => ⟨(hb a).1, ?_⟩⟩
  intro R b hb1 hbR
  simpa only [μ, w, p, L, ← ENNReal.ofReal_mul hC, mul_assoc] using
    (hb a).2 (⟨(R, b), hb1, hbR⟩ : A)

end N2Restriction

#print axioms N2Restriction.FiniteDirectionalKakeya.closedBall_of_larger_ball
#print axioms N2Restriction.FiniteDirectionalKakeya.mono_measure
#print axioms N2Restriction.geometric_subdivision_from_external_kakeya
