import continuation.ActualRetainedSquareV48
import continuation.RetentionRadiusCancellationV48

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal NNReal

/-- Equation (7.15) for the exact ball-dependent square function, with a
coefficient independent of R and rho. The input support is the fixed-class
invariant established from the original margin, not an analytic assumption. -/
theorem PacketGraphAtlas.actual_retained_square_linear_bound {d : ℕ} {S : SmoothPatch (d+1)}
    (A : PacketGraphAtlas S) :
    ∃ C : ℝ≥0, ∃ B K : ℝ, 0 ≤ B ∧ 0 < K ∧ ∀ {L : ℕ} {R ρ θ w r : ℝ},
    0 ≤ R → 0 < ρ → ρ ≤ R → 0 < θ → w ≤ ρ →
    ∀ (Q : (j : Fin A.size) → CoordinateCapFamily (A.patch j).support r) (hr : 0 < r)
      (f : (j : Fin A.size) → Lp ℂ 2 (A.graph j).surfaceMeasure)
      (U : (j : Fin A.size) → (Q j).centers → Set (Fin d → ℤ))
      (Z : Set (Ambient (d+1))) (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1)))
      (c : Fin L → Ambient (d+1)) (b C₀ : ℝ) (Ω : Set (Ambient (d+1))),
    (∀ l t, l ≠ t → 2*(θ*ρ) ≤ dist (c l) (c t)) →
    (∀ ls : Fin L × Bool, HasFrequencySupport (Measure.hausdorffMeasure (d : ℝ)) id S.support
      (A.cellInput Q hr f (if ls.2 then A.actualTangentSelection Q U Z T (c ls.1) ρ b C₀ R w Ω else
        A.actualNontangentSelection Q U Z T (c ls.1) ρ b C₀ R w Ω))) →
    (∫⁻ x, A.actualRetainedSquare Q hr f U Z T c ρ b C₀ R w Ω x) ≤
      ((C : ENNReal)*ENNReal.ofReal B*ENNReal.ofReal ((2*K+2)*(3/θ+1)^(d+1))) *
        ENNReal.ofReal R * ENNReal.ofReal (∑ j, ‖f j‖^2) := by
  obtain ⟨C,B,K,hB,hK,hbound⟩ := A.actual_retained_square_integral
  refine ⟨C,B,K,hB,hK,?_⟩
  intro L R ρ θ w r hR hρ hρR hθ hw Q hr f U Z T c b C₀ Ω hsep hs
  apply (hbound hR hρ hθ hw Q hr f U Z T c b C₀ Ω hsep hs).trans
  have hc := retention_radius_cancellation_ennreal (n := d+1) hρ hρR hθ hK.le
  calc
    _ = ((C : ENNReal)*ENNReal.ofReal B)*
        (ENNReal.ofReal ρ*ENNReal.ofReal ((2*R*K/ρ+2)*(3/θ+1)^(d+1)))*
        ENNReal.ofReal (∑ j, ‖f j‖^2) := by ring
    _ ≤ ((C : ENNReal)*ENNReal.ofReal B)*
        (ENNReal.ofReal ((2*K+2)*(3/θ+1)^(d+1))*ENNReal.ofReal R)*
        ENNReal.ofReal (∑ j, ‖f j‖^2) := mul_le_mul_right' (mul_le_mul_left' hc _) _
    _ = _ := by ring

end N2Restriction
#print axioms N2Restriction.PacketGraphAtlas.actual_retained_square_linear_bound
