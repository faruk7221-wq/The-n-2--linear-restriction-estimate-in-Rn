import continuation.ZeroTargetSupportV30
import continuation.UniformMassProductV30
import continuation.UniformChartMassV28

namespace N2Restriction
open MeasureTheory Set Metric
open scoped NNReal ENNReal BigOperators

/-- Explicit common coefficient for distance-localized chart products. -/
noncomputable def distanceChartProductCoefficient (k n : ℕ) (C M : ℝ≥0)
    (β L ρ D : ℝ) : ℝ≥0∞ :=
  ENNReal.ofReal (2 * ((M : ℝ) * D)) *
    (chartStripMassConstant n C β ((L + 1) * ρ)) ^ (1 / 2 : ℝ) *
    (((C : ℝ≥0∞) * (volume : Measure (Ambient (n - 1))) (closedBall 0 ρ)) ^
      (1 / 2 : ℝ)) ^ (k - 1)

theorem distanceChartProductCoefficient_ne_top (k n : ℕ) (C M : ℝ≥0) (β L ρ D : ℝ) :
    distanceChartProductCoefficient k n C M β L ρ D ≠ ∞ := by
  apply ENNReal.mul_ne_top
  · exact ENNReal.mul_ne_top ENNReal.ofReal_ne_top
      (ENNReal.rpow_ne_top_of_nonneg (by norm_num) (chartStripMassConstant_ne_top _ _ _ _))
  · exact ENNReal.pow_ne_top (ENNReal.rpow_ne_top_of_nonneg (by norm_num)
      (ENNReal.mul_ne_top ENNReal.coe_ne_top (isCompact_closedBall _ _).measure_lt_top.ne))

/-- The exact distance-supported input class required by local assembly has
a uniform finite-measure product bound for every p>0. -/
theorem distance_supported_chart_product {k n : ℕ} (hn : 1 ≤ n)
    (S : Fin k → SmoothPatch n) {q : Ambient n × Ambient n} (hq : q ∈ orthonormalPairSet n)
    (z : Fin k → Ambient n) {δ r ρ s η L α β τ D : ℝ} {B : ℕ → ℝ} {c C M : ℝ≥0}
    (hρ : ρ ≤ r) (hs : s ≤ η)
    (F : ∀ i, MeasuredTubularChart (S i) (pairFrameMap q) (z i) δ r ρ s B c C L)
    (E : ∀ i, ChartNormalCoordinates (F i) α β) (i₀ : Fin k)
    (hN : LipschitzOnWith M (S i₀).normal (closedBall (z i₀) η))
    (hZ : ∀ y ∈ (E i₀).zeroTarget τ,
      thinConstraint (S i₀) (pairPlane q) y = 0 ∧ dist y (z i₀) ≤ η)
    (a : ℝ≥0)
    (g : ∀ i, Lp ℂ 2 ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict (F i).carrier))
    (hg : HasFrequencySupport ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict (F i₀).carrier)
      id {x | ∃ y ∈ (E i₀).zeroTarget τ, dist x y ≤ D * (a : ℝ)} (g i₀))
    (σ : Measure (Ambient n)) {p : ℝ} (hp : 0 < p) :
    eLpNorm' (fun x => ∏ i, extension
      ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict (F i).carrier) id (g i) x) p σ ≤
      (distanceChartProductCoefficient k n C M β L ρ D * (a : ℝ≥0∞) *
        (σ Set.univ) ^ (1 / p)) * ∏ i, ‖g i‖ₑ := by
  let μ := fun i => (Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict (F i).carrier
  have hmass : ∀ i, μ i Set.univ ≤
      (C : ℝ≥0∞) * (volume : Measure (Ambient (n - 1))) (closedBall 0 ρ) := by
    intro i
    simpa only [μ, Measure.restrict_apply_univ] using (F i).surface_mass_le hn hρ
  have hh := extension_product_quasinorm_common_mass μ g i₀
    (ENNReal.ofReal (2 * ((M : ℝ) * D * (a : ℝ))) *
      (chartStripMassConstant n C β ((L + 1) * ρ)) ^ (1 / 2 : ℝ)) _ hmass
    ((F i₀).zeroTarget_extension_bound hn hρ hs hq (E i₀) hN hZ (g i₀) hg) σ hp
  have he : ENNReal.ofReal (2 * ((M : ℝ) * D * (a : ℝ))) =
      ENNReal.ofReal (2 * ((M : ℝ) * D)) * (a : ℝ≥0∞) := by
    rw [← mul_assoc, ENNReal.ofReal_mul' a.coe_nonneg, ENNReal.ofReal_coe_nnreal]
  rw [he] at hh
  convert hh using 1
  dsimp [distanceChartProductCoefficient]
  ac_rfl

/-- A bounded-radius coefficient is finite and independent of the center,
frame, selected factor, chart choices, thickness and actual inputs. -/
theorem bounded_distance_chart_product {k n : ℕ} (hn : 1 ≤ n)
    (S : Fin k → SmoothPatch n) {δ r ρ s η L α β τ D : ℝ} {B : ℕ → ℝ} {c C M : ℝ≥0}
    (hρ : ρ ≤ r) (hs : s ≤ η) {p : ℝ} (hp : 0 < p) (R₀ : ℝ) :
    ∃ A : ℝ≥0, ∀ (q : Ambient n × Ambient n), q ∈ orthonormalPairSet n →
      ∀ (z : Fin k → Ambient n)
      (F : ∀ i, MeasuredTubularChart (S i) (pairFrameMap q) (z i) δ r ρ s B c C L)
      (E : ∀ i, ChartNormalCoordinates (F i) α β) (i₀ : Fin k),
      LipschitzOnWith M (S i₀).normal (closedBall (z i₀) η) →
      (∀ y ∈ (E i₀).zeroTarget τ,
        thinConstraint (S i₀) (pairPlane q) y = 0 ∧ dist y (z i₀) ≤ η) →
      ∀ (a : ℝ≥0) (R : ℝ), R ≤ R₀ → ∀ (x₀ : Ambient n)
      (g : ∀ i, Lp ℂ 2 ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict (F i).carrier)),
      HasFrequencySupport ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict (F i₀).carrier)
        id {x | ∃ y ∈ (E i₀).zeroTarget τ, dist x y ≤ D * (a : ℝ)} (g i₀) →
      eLpNorm' (fun x => ∏ i, extension
        ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict (F i).carrier) id (g i) x) p
        (volume.restrict (ball x₀ R)) ≤ ((A : ℝ≥0∞) * a) * ∏ i, ‖g i‖ₑ := by
  let A : ℝ≥0∞ := distanceChartProductCoefficient k n C M β L ρ D *
    (volume (ball (0 : Ambient n) R₀)) ^ (1 / p)
  have hA : A ≠ ∞ := ENNReal.mul_ne_top (distanceChartProductCoefficient_ne_top _ _ _ _ _ _ _ _)
    (ENNReal.rpow_ne_top_of_nonneg (by positivity) measure_ball_lt_top.ne)
  refine ⟨A.toNNReal, ?_⟩
  intro q hq z F E i₀ hN hZ a R hR x₀ g hg
  have hh := distance_supported_chart_product hn S hq z hρ hs F E i₀ hN hZ a g hg
    (volume.restrict (ball x₀ R)) hp
  rw [Measure.restrict_apply_univ, Measure.addHaar_ball_center volume x₀ R] at hh
  rw [ENNReal.coe_toNNReal hA]
  refine hh.trans ((mul_le_mul_right' (mul_le_mul_left'
    (ENNReal.rpow_le_rpow (measure_mono (ball_subset_ball hR)) (by positivity)) _) _).trans_eq ?_)
  dsimp [A]
  ac_rfl

end N2Restriction

#print axioms N2Restriction.bounded_distance_chart_product
#print axioms N2Restriction.distanceChartProductCoefficient_ne_top
#print axioms N2Restriction.distance_supported_chart_product
