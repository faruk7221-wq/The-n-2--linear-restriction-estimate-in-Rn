import continuation.PlancherelStripProductV30
import continuation.PlancherelProductV30
import N2Restriction.HigherExponents

namespace N2Restriction
open MeasureTheory Metric Set
open scoped NNReal ENNReal BigOperators

/-- A checked coarse critical-exponent estimate on the actual original
inputs. Interpolation gives thickness^(k/(k+1)) and radius^(1/critical k).
The positive radius power is retained explicitly; the main restriction
estimate and its arbitrarily small radius loss are not asserted. -/
theorem uniform_critical_strip_product_coarse {k : ℕ} (hk : 1 < k)
    (S : Fin k → SmoothPatch (k + 2)) {κ : ℝ} (hκ : 0 < κ) :
    ∃ C : ℝ≥0, ∀ i (q : Ambient (k + 2) × Ambient (k + 2)),
      q ∈ orthonormalPairSet (k + 2) →
      (∀ z ∈ (S i).support, (pairFrameMap q, z) ∈ frameFrequencyAdmissibleImage (S i) κ) →
      ∀ (ε : ℝ) (g : ∀ j, Lp ℂ 2 (S j).surfaceMeasure),
        HasFrequencySupport (S i).surfaceMeasure id
          {y | ‖(pairPlane q).orthogonalProjection ((S i).normal y)‖ ≤ ε} (g i) →
        ∀ (x₀ : Ambient (k + 2)) (R : ℝ), 0 ≤ R →
          eLpNorm' (fun x => ∏ j, extension (S j).surfaceMeasure id (g j) x)
            (critical (k : ℝ)) (volume.restrict (ball x₀ R)) ≤
            ((C : ℝ≥0∞) * (ENNReal.ofReal (2 * ε)) ^ theta (k : ℝ) *
              (ENNReal.ofReal R) ^ (1 / critical (k : ℝ))) * ∏ j, ‖g j‖ₑ := by
  obtain ⟨A, hA⟩ := uniform_Plancherel_strip_product hk S hκ
  obtain ⟨B, hB⟩ := uniform_Plancherel_product (by omega : 0 < k) S
  have hkR : (1 : ℝ) < k := by exact_mod_cast hk
  have hk0 : (0 : ℝ) < k := by linarith
  obtain ⟨hθ, hθ1⟩ := theta_range hk0
  have hθ' : 0 ≤ 1 - theta (k : ℝ) := by linarith
  let C : ℝ≥0∞ := (A : ℝ≥0∞) ^ theta (k : ℝ) * (B : ℝ≥0∞) ^ (1 - theta (k : ℝ))
  have hC : C ≠ ∞ := ENNReal.mul_ne_top
    (ENNReal.rpow_ne_top_of_nonneg hθ.le ENNReal.coe_ne_top)
    (ENNReal.rpow_ne_top_of_nonneg hθ' ENNReal.coe_ne_top)
  refine ⟨C.toNNReal, ?_⟩
  intro i q hq hadm ε g hg x₀ R hR
  let F := fun x => ∏ j, extension (S j).surfaceMeasure id (g j) x
  let μ := volume.restrict (ball x₀ R)
  have hF : Continuous F := by
    apply continuous_finset_prod
    intro j _
    haveI : IsFiniteMeasure (S j).surfaceMeasure := (S j).isFiniteMeasure_surfaceMeasure (by omega)
    exact continuous_extension measurable_id ((Lp.memLp (g j)).integrable (by norm_num))
  have hb0 := hA i q hq hadm ε g hg x₀ R hR
  have hcast : ((k - 1 : ℕ) : ℝ) = (k : ℝ) - 1 := by rw [Nat.cast_sub (by omega), Nat.cast_one]
  rw [hcast] at hb0
  have hh := tangential_norm_bound μ (fun x => ‖F x‖ₑ) hF.enorm.measurable.aemeasurable hkR
    hb0 (hB g x₀ R hR)
  change eLpNorm' F (critical (k : ℝ)) μ ≤ _ at hh
  rw [ENNReal.coe_toNNReal hC]
  refine hh.trans_eq ?_
  rw [interpolate_common_factor hθ.le hθ' (by ring)]
  simp only [ENNReal.mul_rpow_of_nonneg _ _ hθ.le, ENNReal.mul_rpow_of_nonneg _ _ hθ',
    ← ENNReal.rpow_mul]
  have hexp : (((k : ℝ) - 1) / 2) * theta (k : ℝ) +
      ((k : ℝ) / 2) * (1 - theta (k : ℝ)) = 1 / critical (k : ℝ) := by
    unfold theta critical
    field_simp
    ring
  have hfirst : 0 ≤ (((k : ℝ) - 1) / 2) * theta (k : ℝ) := mul_nonneg (div_nonneg (by linarith) (by norm_num)) hθ.le
  have hsecond : 0 ≤ ((k : ℝ) / 2) * (1 - theta (k : ℝ)) := mul_nonneg (by positivity) hθ'
  dsimp [C]
  calc
    _ = ((A : ℝ≥0∞) ^ theta (k : ℝ) * (B : ℝ≥0∞) ^ (1 - theta (k : ℝ)) *
        (ENNReal.ofReal (2 * ε)) ^ theta (k : ℝ) *
        ((ENNReal.ofReal R) ^ ((((k : ℝ) - 1) / 2) * theta (k : ℝ)) *
          (ENNReal.ofReal R) ^ (((k : ℝ) / 2) * (1 - theta (k : ℝ))))) * ∏ j, ‖g j‖ₑ := by ac_rfl
    _ = _ := by rw [← ENNReal.rpow_add_of_nonneg _ _ hfirst hsecond, hexp]

end N2Restriction

#print axioms N2Restriction.uniform_critical_strip_product_coarse
