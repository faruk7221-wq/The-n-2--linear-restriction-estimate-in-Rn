import continuation.DirectionalSubdivisionV22
import continuation.PacketKakeyaV21

namespace N2Restriction
open MeasureTheory Set

/-- Every buffered frequency has its original normal in the chosen directional neighborhood. -/
theorem DirectionalSubdivision.buffer_normals {d : ℕ} {S : SmoothPatch (d + 1)} {ε : ℝ}
    (D : DirectionalSubdivision S ε) (a : Fin D.size) (T : PacketGraphAtlas (D.piece a))
    (j : Fin T.size) {z : Ambient (d + 1)} (hz : z ∈ T.buffer j) :
    z ∈ S.extendedSurface ∧ dist (S.normal z) (S.normal (D.anchor a)) < ε := by
  have h := (T.buffer_inside j hz).1
  exact ⟨D.extended_subset a h, by simpa only [D.normal_eq] using D.normal_close a z h.1⟩

/-- Frequencies at chart cap centers are inside the buffered graph. -/
theorem PacketGraphAtlas.support_point_mem_buffer {d : ℕ} {S : SmoothPatch (d + 1)}
    (T : PacketGraphAtlas S) (j : Fin T.size) {u : Ambient d}
    (hu : u ∈ (T.patch j).support) :
    (T.patch j).rotation ((T.graph j).parametrization u) ∈ T.buffer j := by
  exact ⟨_, ⟨u, (Metric.closedBall_subset_closedBall (le_of_lt (T.inner_lt j)))
    ((T.patch j).support_inside hu), rfl⟩, rfl⟩

/-- The actual infinite packet axis has a unit direction close to the fixed reference normal. -/
theorem DirectionalSubdivision.axis_direction {d : ℕ} {S : SmoothPatch (d + 1)} {ε : ℝ}
    (D : DirectionalSubdivision S ε) (a : Fin D.size) (T : PacketGraphAtlas (D.piece a))
    (j : Fin T.size) {u : Ambient d} (hu : u ∈ (T.patch j).support) (v : Ambient d) :
    ∃ N : Ambient (d + 1), ‖N‖ = 1 ∧ dist N (S.normal (D.anchor a)) < ε ∧
      (T.patch j).rotation '' packetAxis (graphGradient (T.graph j).phase u) v =
        Set.range (fun t : ℝ => (T.patch j).rotation (graphPoint (-v) 0) + t • N) := by
  let z := (T.patch j).rotation ((T.graph j).parametrization u)
  have hz := D.buffer_normals a T j (T.support_point_mem_buffer j hu)
  refine ⟨S.normal z, S.normal_unit z hz.1.1, hz.2, ?_⟩
  simpa only [D.normal_eq] using T.axis_eq_normal_line j hu v

/-- All constructed packets stay in the original extended surface and the chosen normal cone. -/
theorem DirectionalSubdivision.packet_directional_support {d : ℕ}
    {S : SmoothPatch (d + 1)} {ε : ℝ} (D : DirectionalSubdivision S ε)
    (a : Fin D.size) (T : PacketGraphAtlas (D.piece a)) {r : ℝ}
    (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r)
    (hr : 0 < r) (hsmall : r ≤ T.capRadius)
    (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
    (j : Fin T.size) (c : (Q j).centers) (ν : Fin d → ℤ) :
    HasFrequencySupport (Measure.hausdorffMeasure (d : ℝ)) id
      (S.extendedSurface ∩ {z | dist (S.normal z) (S.normal (D.anchor a)) < ε})
      ((T.graph j).rotatedAmbientInput (T.patch j).rotation
        ((T.graph j).packet (Q j) hr (f j) c ν)) :=
  (T.packet_support Q hr hsmall f j c ν).mono (fun _ hz => D.buffer_normals a T j hz)

/-- Directional subdivision and buffered packet atlases can be constructed simultaneously. -/
theorem SmoothPatch.exists_directional_packet_atlases {d : ℕ} (S : SmoothPatch (d + 1))
    {ε : ℝ} (hε : 0 < ε) :
    ∃ D : DirectionalSubdivision S ε, Nonempty (∀ a, PacketGraphAtlas (D.piece a)) := by
  obtain ⟨D⟩ := S.exists_directionalSubdivision hε
  exact ⟨D, ⟨fun a => Classical.choice ((D.piece a).exists_packetGraphAtlas)⟩⟩

end N2Restriction

#print axioms N2Restriction.DirectionalSubdivision.axis_direction
#print axioms N2Restriction.DirectionalSubdivision.buffer_normals
#print axioms N2Restriction.DirectionalSubdivision.packet_directional_support
#print axioms N2Restriction.PacketGraphAtlas.support_point_mem_buffer
#print axioms N2Restriction.SmoothPatch.exists_directional_packet_atlases
