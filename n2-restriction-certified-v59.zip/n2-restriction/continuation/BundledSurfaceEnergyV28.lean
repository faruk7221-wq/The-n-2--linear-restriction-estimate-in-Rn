import continuation.ChartNormalCoordinatesV28
import continuation.SurfaceEnergySlicingV25
import continuation.CompactChartL2IntegrabilityV25

namespace N2Restriction
open MeasureTheory Set Metric
open scoped NNReal ENNReal

namespace MeasuredTubularChart
variable {n : ℕ} {S : SmoothPatch n} {Q : Ambient n →L[ℝ] ℝ × ℝ} {z : Ambient n}
  {δ r ρ s : ℝ} {B : ℕ → ℝ} {c C : ℝ≥0} {L : ℝ}

/-- The actual compact chart carrier has finite original-dimensional surface
measure, as follows from its bounded coordinate density. -/
theorem finite_surface_carrier (F : MeasuredTubularChart S Q z δ r ρ s B c C L)
    (hn : 1 ≤ n) :
    IsFiniteMeasure ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier) := by
  obtain ⟨J, _, hJ, hpush⟩ := F.density
  letI := compact_chart_density_finite (closedBall (0 : Ambient (n - 1)) ρ)
    (isCompact_closedBall _ _) J C (hJ.mono fun _ h => h.2)
  have hd : ((n - 1 : ℕ) : ℝ) = (n : ℝ) - 1 := by simp [Nat.cast_sub hn]
  rw [hd] at hpush
  change IsFiniteMeasure ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict (F.param '' closedBall 0 ρ))
  rw [← hpush]
  infer_instance

/-- Exact normal-coordinate energy slicing for every L2 input on a bundled
measured chart. The scalar strip estimate is an energy estimate, not a
quasi-Banach product-integral inequality. -/
theorem normal_slicing_L2 (F : MeasuredTubularChart S Q z δ r ρ s B c C L)
    (hn : 1 ≤ n) (hρ : ρ ≤ r) {α β : ℝ} (E : ChartNormalCoordinates F α β)
    (g : Lp ℂ 2 ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier)) :
    ∃ W : Ambient (n - 1) → ℝ≥0∞, ∃ f : Ambient (n - 1) → ℂ,
      Measurable W ∧ Measurable f ∧
      (∀ t ∈ closedBall (0 : Ambient (n - 1)) ρ, f t = g (F.param t)) ∧
      (∀ t ∉ closedBall (0 : Ambient (n - 1)) ρ, W t = 0 ∧ f t = 0) ∧
      (∫⁻ y, (‖g y‖ₑ)^2 ∂(Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier) =
        (coordinateMeasureFactor E.equiv volume (volume.prod volume) : ℝ≥0∞) *
          ∫⁻ u, ∫⁻ v, W (E.equiv.symm (u, v)) * (‖f (E.equiv.symm (u, v))‖ₑ)^2 ∧
      (∀ᵐ u ∂volume, (∫⁻ v, W (E.equiv.symm (u, v)) *
        (‖f (E.equiv.symm (u, v))‖ₑ)^2) < ∞) ∧
      ∀ a : ℝ × ℝ, ∀ ε : ℝ,
        (∫⁻ u in closedBall a ε,
          ((coordinateMeasureFactor E.equiv volume (volume.prod volume) : ℝ≥0∞) *
            ∫⁻ v, W (E.equiv.symm (u, v)) * (‖f (E.equiv.symm (u, v))‖ₑ)^2) ^ (1 / 2 : ℝ)) ≤
          ENNReal.ofReal (2 * ε) *
            (∫⁻ y, (‖g y‖ₑ)^2 ∂(Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier) ^ (1 / 2 : ℝ) := by
  let K := closedBall (0 : Ambient (n - 1)) ρ
  let φ : K → Ambient n := fun t => F.param t
  have hφ : Measurable φ := by
    apply Continuous.measurable
    exact continuousOn_iff_continuous_restrict.mp (fun t ht =>
      (F.bounds t (closedBall_subset_closedBall hρ ht)).2.2.1.continuousAt.continuousWithinAt)
  have hrange : Set.range φ = F.carrier := by
    ext y
    simp only [φ, K, carrier, Set.mem_range, Set.mem_image, Subtype.exists]
    constructor <;> rintro ⟨t, ht, he⟩ <;> exact ⟨t, ht, he⟩
  obtain ⟨J, hJ, _, hpush⟩ := F.density
  have hd : ((n - 1 : ℕ) : ℝ) = (n : ℝ) - 1 := by simp [Nat.cast_sub hn]
  have hp : (((volume : Measure (Ambient (n - 1))).comap (Subtype.val : K → Ambient (n - 1))).withDensity
      (fun t => (J t : ℝ≥0∞))).map φ =
      (Measure.hausdorffMeasure ((n - 1 : ℕ) : ℝ)).restrict (Set.range φ) := by
    simpa only [hrange] using hpush
  obtain ⟨W, f, hW, hf, hK, hzero, he, hs⟩ := measured_chart_normal_slicing
    K isClosed_closedBall.measurableSet φ hφ (fun t => (J t : ℝ≥0∞))
    hJ.coe_nnreal_ennreal hp g (Lp.stronglyMeasurable g).measurable E.equiv
  rw [hd, hrange] at he hs
  have hfin : (∫⁻ y, (‖g y‖ₑ)^2 ∂(Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier) < ∞ := by
    simpa using lintegral_rpow_enorm_lt_top_of_eLpNorm_lt_top
      (by norm_num : (2 : ℝ≥0∞) ≠ 0) (by norm_num : (2 : ℝ≥0∞) ≠ ∞) (Lp.memLp g).2
  rw [he] at hfin
  have hc : (coordinateMeasureFactor E.equiv volume (volume.prod volume) : ℝ≥0∞) ≠ 0 := by
    exact_mod_cast (coordinateMeasureFactor_pos E.equiv volume (volume.prod volume)).ne'
  have htotal : (∫⁻ u, ∫⁻ v, W (E.equiv.symm (u, v)) * (‖f (E.equiv.symm (u, v))‖ₑ)^2) < ∞ := by
    by_contra h
    have ht := top_unique (not_lt.mp h)
    rw [ht, ENNReal.mul_top hc] at hfin
    exact (lt_irrefl _ hfin)
  exact ⟨W, f, hW, hf, fun t ht => (hK ⟨t, ht⟩).2, hzero, he,
    ae_lt_top (by fun_prop) htotal.ne, hs⟩

end MeasuredTubularChart
end N2Restriction

#print axioms N2Restriction.MeasuredTubularChart.finite_surface_carrier
#print axioms N2Restriction.MeasuredTubularChart.normal_slicing_L2
