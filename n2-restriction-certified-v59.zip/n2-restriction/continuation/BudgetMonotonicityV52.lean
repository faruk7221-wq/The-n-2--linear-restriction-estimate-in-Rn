import continuation.PolynomialStageBudgetV51
namespace N2Restriction
open MeasureTheory
open scoped ENNReal

/-- Coarsen actual stage ceilings using componentwise numerical bounds. -/
theorem PolynomialStage.withinBudget_mono {n k m : ℕ}
    {μ : Fin k → Measure (Ambient n)} {g : Fin k → Ambient n → ℂ}
    {p R r : ℝ} {M₀ err : ENNReal} (S : PolynomialStage μ g p R r M₀ err m)
    {B C : PolynomialStageBudget} (hB : S.withinBudget B)
    (hD : B.degree ≤ C.degree) (hw : B.width ≤ C.width) (hM : B.mass ≤ C.mass) :
    S.withinBudget C := ⟨hB.1.trans hD,hB.2.1.trans hw,hB.2.2.trans hM⟩

/-- Replace a realized finite retention cost by a uniform upper cost fixed
before the stage, without changing its selected inputs or physical region. -/
theorem PolynomialStage.withinBudget_advance_cost_mono {n k m : ℕ}
    {μ : Fin k → Measure (Ambient n)} {g : Fin k → Ambient n → ℂ}
    {p R r : ℝ} {M₀ err : ENNReal} (S : PolynomialStage μ g p R r M₀ err m)
    (B : PolynomialStageBudget) (D : ℕ) (a : ℝ) (ha : 1 ≤ a)
    {F G : ENNReal} (hF : F ≠ ∞) (hG : G ≠ ∞) (hFG : F ≤ G)
    (hB : S.withinBudget (B.advance D a ha F hF)) :
    S.withinBudget (B.advance D a ha G hG) := by
  apply S.withinBudget_mono (C := B.advance D a ha G hG) hB le_rfl le_rfl
  exact mul_le_mul_left' (max_le_max le_rfl hFG) B.mass

end N2Restriction
#print axioms N2Restriction.PolynomialStage.withinBudget_mono
#print axioms N2Restriction.PolynomialStage.withinBudget_advance_cost_mono
