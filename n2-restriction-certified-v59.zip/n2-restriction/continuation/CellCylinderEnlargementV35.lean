import continuation.CellMeetingWeightsV35
import continuation.CenteredCylinderPerturbationV32
import continuation.AffineFiberTubesV32

namespace N2Restriction
open Set Metric
open scoped ENNReal

/-- If a perturbed cylinder meets a cell inside the large ball, every point
of the cell lies in a corrected-center reference cylinder. The cell need
not lie inside the large ball. -/
theorem meeting_cylinder_cell_subset {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    (A Q : E →L[ℝ] F) (z : F) (x₀ : E) (C : Set E)
    (R w δ D : ℝ) (hδ : 0 ≤ δ) (hA : ‖A - Q‖ ≤ δ)
    (hdiam : ∀ x ∈ C, ∀ y ∈ C, dist x y ≤ D)
    (hmeet : ((C ∩ closedBall x₀ R) ∩ A ⁻¹' closedBall z w).Nonempty) :
    C ⊆ Q ⁻¹' closedBall (z + (Q - A) x₀) (w + δ * R + ‖Q‖ * D) := by
  obtain ⟨x, ⟨hxC, hxR⟩, hxA⟩ := hmeet
  have hxQ := centered_perturbed_projection_cylinder_subset A Q x₀ z R w δ hδ hA ⟨hxR, hxA⟩
  intro y hy
  change dist (Q y) (z + (Q - A) x₀) ≤ _
  have hdist : dist (Q y) (Q x) ≤ ‖Q‖ * D := by
    rw [dist_eq_norm, ← map_sub]
    exact (Q.le_opNorm (y - x)).trans
      (mul_le_mul_of_nonneg_left (by simpa [dist_eq_norm] using hdiam y hy x hxC) (norm_nonneg _))
  exact (dist_triangle _ (Q x) _).trans (by
    change dist (Q x) (z + (Q - A) x₀) ≤ w + δ * R at hxQ
    linarith)

/-- The same cell enlargement for genuine metric neighborhoods of affine
fibers, with the projection norm cost visible. -/
theorem meeting_affineFiberTube_cell_subset {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    (A Q : E →L[ℝ] F) (z : F) (x₀ : E) (C : Set E)
    (R w δ D L : ℝ) (hδ : 0 ≤ δ) (hA : ‖A - Q‖ ≤ δ)
    (hL : 0 ≤ L) (hAL : ‖A‖ ≤ L)
    (hdiam : ∀ x ∈ C, ∀ y ∈ C, dist x y ≤ D)
    (hmeet : ((C ∩ closedBall x₀ R) ∩ affineFiberTube A z w).Nonempty) :
    C ⊆ Q ⁻¹' closedBall (z + (Q - A) x₀) (L * w + δ * R + ‖Q‖ * D) := by
  apply meeting_cylinder_cell_subset A Q z x₀ C R (L*w) δ D hδ hA hdiam
  obtain ⟨x, hx, ht⟩ := hmeet
  exact ⟨x, hx, affineFiberTube_subset_cylinder A z w L hL hAL ht⟩

/-- Total weight of metric tubes meeting a cell is controlled at every
point of that cell by the enlarged flat reference density. -/
theorem cellMeeting_affineFiberTube_density {E F T : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    (A : T → E →L[ℝ] F) (Q : E →L[ℝ] F) (z : T → F) (u : T → ℝ≥0∞)
    (x₀ : E) (C : Set E) (R w δ D L : ℝ)
    (hδ : 0 ≤ δ) (hA : ∀ t, ‖A t - Q‖ ≤ δ)
    (hL : 0 ≤ L) (hAL : ∀ t, ‖A t‖ ≤ L)
    (hdiam : ∀ x ∈ C, ∀ y ∈ C, dist x y ≤ D) {y : E} (hy : y ∈ C) :
    (∑' t, cellMeetingWeight (fun t => affineFiberTube (A t) (z t) w) u
      (C ∩ closedBall x₀ R) t) ≤
    tubeDensity (fun t => closedBall (z t + (Q - A t) x₀)
      (L*w + δ*R + ‖Q‖*D)) u (Q y) := by
  apply cellMeetingWeight_le_density
  intro t ht
  exact meeting_affineFiberTube_cell_subset (A t) Q (z t) x₀ C R w δ D L
    hδ (hA t) hL (hAL t) hdiam ht hy

end N2Restriction

#print axioms N2Restriction.cellMeeting_affineFiberTube_density
#print axioms N2Restriction.meeting_affineFiberTube_cell_subset
#print axioms N2Restriction.meeting_cylinder_cell_subset
