import continuation.ThreeBlockLoomisWhitneyV32

namespace N2Restriction
open MeasureTheory
open scoped ENNReal BigOperators

/-- Holder's block-elimination step for any finite number of remaining
factors. The reduced integral is retained explicitly for induction. -/
theorem block_holder_lift {X Y : Type*} [MeasurableSpace X] [MeasurableSpace Y]
    (μ : Measure X) (ν : Measure Y) [SFinite ν]
    {m : ℕ} (hm : 2 ≤ m) (f₀ : X → ℝ≥0∞) (f : Fin m → X × Y → ℝ≥0∞)
    (hf₀ : Measurable f₀) (hf : ∀ i, Measurable (f i)) :
    (∫⁻ x, ∫⁻ y, (f₀ x * ∏ i, f i (x,y)) ^ (1 / (m : ℝ)) ∂ν ∂μ) ≤
      (∫⁻ x, f₀ x ∂μ) ^ (1 / (m : ℝ)) *
      (∫⁻ x, ∏ i, (∫⁻ y, f i (x,y) ∂ν) ^ (1 / ((m : ℝ) - 1)) ∂μ) ^
        (((m : ℝ) - 1) / (m : ℝ)) := by
  have hmR : (2 : ℝ) ≤ m := by exact_mod_cast hm
  have hm0 : (0 : ℝ) < m := by linarith
  have hm1 : (0 : ℝ) < (m : ℝ) - 1 := by linarith
  let p : ℝ := 1 / (m : ℝ)
  let q : ℝ := ((m : ℝ) - 1) / (m : ℝ)
  let r : ℝ := 1 / ((m : ℝ) - 1)
  have hp : 0 ≤ p := by dsimp [p]; positivity
  have hq : 0 ≤ q := by dsimp [q]; positivity
  have hr : 0 ≤ r := by dsimp [r]; positivity
  have hpq : p + q = 1 := by dsimp [p,q]; field_simp; ring
  have hrq : r * q = p := by dsimp [r,q,p]; field_simp
  let G : Fin m → X → ℝ≥0∞ := fun i x => ∫⁻ y, f i (x,y) ∂ν
  have hG (i : Fin m) : Measurable (G i) := (hf i).lintegral_prod_right'
  have hpt (x : X) :
      (∫⁻ y, (f₀ x * ∏ i, f i (x,y)) ^ p ∂ν) ≤ f₀ x ^ p * ∏ i, G i x ^ p := by
    have hi := ENNReal.lintegral_prod_norm_pow_le Finset.univ
      (μ := ν) (f := fun i y => f i (x,y))
      (fun i _ => ((hf i).comp (measurable_const.prodMk measurable_id)).aemeasurable)
      (p := fun _ => p) (by simp [p, ne_of_gt hm0]) (fun _ _ => hp)
    simp_rw [ENNReal.mul_rpow_of_nonneg _ _ hp, ← ENNReal.prod_rpow_of_nonneg hp]
    rw [lintegral_const_mul _ (by fun_prop)]
    exact mul_le_mul_left' hi _
  refine (lintegral_mono hpt).trans ?_
  have hH : Measurable (fun x => ∏ i, G i x ^ r) := by fun_prop
  have ho := ENNReal.lintegral_mul_norm_pow_le (μ := μ) hf₀.aemeasurable hH.aemeasurable hp hq hpq
  simpa only [← ENNReal.prod_rpow_of_nonneg hq, ← ENNReal.rpow_mul, hrq] using ho

end N2Restriction

#print axioms N2Restriction.block_holder_lift
