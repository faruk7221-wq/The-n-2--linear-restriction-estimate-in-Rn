import continuation.AtlasSubstantialCellV42
import continuation.AtlasFarCellBudgetV42

namespace N2Restriction
open MeasureTheory
open scoped BigOperators ENNReal

/-- Actual normal-axis near/far geometry supplies the label budgets for the
simultaneous substantial-cell choice. External data consist of algebraic tube
covering and the reset partition's mass/count properties. -/
theorem atlas_geometric_cell_choice {d k : ℕ} (S : Fin k → SmoothPatch (d+1))
    (T : (i : Fin k) → PacketGraphAtlas (S i)) :
    ∃ B : Fin k → ℝ, (∀ i, 1 ≤ B i) ∧
      ∀ {m q H : ℕ} {C : Type*} [Fintype C] [Nonempty C] {r : ℝ}
        (Q : (i : Fin k) → (j : Fin (T i).size) → CoordinateCapFamily ((T i).patch j).support r)
        (hr : 0 < r) (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure)
        (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure),
      (∀ i, 0 < ‖g i‖) → (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
      ∀ (A : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ))
        (P : Fin m → MvPolynomial (Fin (d+1)) ℝ)
        (Z : Fin q → MvPolynomial (Fin (d+1)) ℝ) (cuts : Set (Ambient (d+1)))
        (V : Submodule ℝ (Ambient (d+1))) {γ K : ℝ}, 0 ≤ K →
      AlgebraicTubeCoverInput {x | polynomialLevelMap Z x = 0}
        (fun z => LinearMap.ker (fderiv ℝ (polynomialLevelMap Z) z).toLinearMap) γ H K →
      ∀ (Ω : Set (Ambient (d+1))) {b w : ℝ}, 0 < b → w < b →
      Ω ⊆ Metric.thickening b (planeWitnessSet Z cuts V (2*γ)) →
      ∀ (far : Finset (Fin k)),
      (∀ i ∈ far, ∀ j a ν, ν ∈ A i j a →
        4*γ < directionPlaneAngle ((T i).cellAxisDirection j a.val) V) →
      ∀ (label : C → (Fin m → Bool)), Function.Injective label →
      ∀ (mass : C → ℝ) {M θ E : ℝ}, 0 < M → 0 < θ → 0 < E →
      θ*M ≤ ∑ c, mass c → (∀ c, mass c ≤ E*M/Fintype.card C) →
      ∃ c, θ*M/(2*Fintype.card C) ≤ mass c ∧
        ∀ i, ‖(T i).cellInput (Q i) hr (f i)
          (fun j a => {ν | ν ∈ A i j a ∧ label c ∈ trimmedCellLabels P
            ((T i).cellAxisPoint j r ν) ((T i).cellAxisDirection j a.val) Ω b w})‖^2 <
          (2*E*((k : ℝ)+1)/(θ*Fintype.card C)) *
            (B i * (if i ∈ far then max 1 ((H : ℝ)*(K+2)^(d+1))
                    else ((∏ l, P l).totalDegree+1 : ℕ)) * ‖g i‖^2) := by
  classical
  obtain ⟨B, hB, hb⟩ := atlas_substantial_cell_selection S T
  refine ⟨B, hB, ?_⟩
  intro m q H C _ _ r Q hr g f hg he A P Z cuts V γ K hK hexternal Ω b w hbpos hw hregion far hangle label hinj mass M θ E hM hθ hE htotal hupper
  apply hb Q hr g f hg he A
    (fun i j a ν => trimmedCellLabels P ((T i).cellAxisPoint j r ν)
      ((T i).cellAxisDirection j a.val) Ω b w)
    (fun i => if i ∈ far then max 1 ((H : ℝ)*(K+2)^(d+1))
      else ((∏ l, P l).totalDegree+1 : ℕ))
    _ _ label hinj mass hM hθ hE htotal hupper
  · intro i
    dsimp only
    split_ifs
    · exact lt_of_lt_of_le zero_lt_one (le_max_left _ _)
    · positivity
  · intro i j a ν hν
    by_cases hi : i ∈ far
    · simp only [if_pos hi]
      have hwitness : ∀ x ∈ Ω, ∃ z ∈ {x | polynomialLevelMap Z x = 0}, dist x z < b ∧
          ‖(LinearMap.ker (fderiv ℝ (polynomialLevelMap Z) z).toLinearMap).starProjection -
            V.starProjection‖ < 2*γ := by
        intro x hx
        obtain ⟨z, hz, _, hn, hh⟩ := plane_region_near_tangent Z cuts V (hregion hx)
        exact ⟨z, hz, hn, hh⟩
      have hh := trimmedCellLabels_card_le_nontangent P _ _ V hK hexternal
        ((T i).cellAxisPoint j r ν) ((T i).cellAxisDirection j a.val)
        ((T i).cellAxisDirection_unit j ((Q i j).centers_mem a.property)) Ω hbpos hw.le hwitness
        (hangle i hi j a ν hν)
      have hh' : ((trimmedCellLabels P ((T i).cellAxisPoint j r ν)
          ((T i).cellAxisDirection j a.val) Ω b w).card : ENNReal) ≤
          ENNReal.ofReal ((H : ℝ)*(K+2)^(d+1)) := by
        exact_mod_cast ENNReal.ofReal_le_ofReal hh
      exact hh'.trans (ENNReal.ofReal_le_ofReal (le_max_right _ _))
    · simp only [if_neg hi]
      exact_mod_cast trimmedCellLabels_card_le_degree P _ _ Ω hw

end N2Restriction
#print axioms N2Restriction.atlas_geometric_cell_choice
