import continuation.BinaryExtensionSelectionV41

namespace N2Restriction
open MeasureTheory
open scoped BigOperators ENNReal

/-- Binary selection replaces the inputs and therefore resets the density.
The stage loses only the factor 2^k at exponents 0<p<=1. Geometry and the
existing error term are preserved. -/
theorem polynomial_binary_input_stage {n k m : ℕ}
    (μ : Fin k → Measure (Ambient n)) (f : Fin k → Bool → Ambient n → ℂ)
    (hf : ∀ i b, Integrable (f i b) (μ i)) {p R r : ℝ} {M₀ err : ENNReal}
    (hp : 0 < p) (hp1 : p ≤ 1)
    (S : PolynomialStage μ (fun i y => ∑ b, f i b y) p R r M₀ err m) :
    ∃ σ : Fin k → Bool,
    ∃ S' : PolynomialStage μ (fun i => f i (σ i)) p R r M₀ err m,
      S'.equations = S.equations ∧ S'.degreeBound = S.degreeBound ∧
      S'.region = S.region ∧ S'.multiplier = S.multiplier ∧
      S'.constant = max 1 (S.constant*(2^k : ENNReal)) := by
  obtain ⟨σ, hm⟩ := binary_extension_mass_selection μ f hf S.region hp hp1
  have hmass : M₀ ≤ (S.constant*(2^k : ENNReal))*
      (∫⁻ x in S.region, ‖extensionProduct μ (fun _ => id) (fun i => f i (σ i)) x‖ₑ ^ p) + err := by
    exact S.mass_bound.trans ((add_le_add_right (mul_le_mul_left' hm S.constant) err).trans_eq
      (by rw [mul_assoc]))
  let S' : PolynomialStage μ (fun i => f i (σ i)) p R r M₀ err m := {
    equations := S.equations
    degreeBound := S.degreeBound
    degree_le := S.degree_le
    regular := S.regular
    nonempty := S.nonempty
    region := S.region
    measurable := S.measurable
    in_ball := S.in_ball
    multiplier := S.multiplier
    multiplier_ge_one := S.multiplier_ge_one
    near := S.near
    constant := max 1 (S.constant*(2^k : ENNReal))
    constant_ge_one := le_max_left _ _
    constant_finite := ne_of_lt (max_lt (by simp)
      (lt_top_iff_ne_top.mpr (ENNReal.mul_ne_top S.constant_finite (by simp))))
    mass_bound := stage_mass_constant_normalization hmass }
  exact ⟨σ, S', rfl, rfl, rfl, rfl, rfl⟩

end N2Restriction
#print axioms N2Restriction.polynomial_binary_input_stage
