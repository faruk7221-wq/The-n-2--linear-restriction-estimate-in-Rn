import continuation.InteriorTubularDensityV26

namespace N2Restriction
open Metric Filter MeasureTheory
open scoped NNReal ENNReal

/-- Uniform measured tubular charts for the admissible geometric frame family.
The density is on the full surface, of dimension n-1, and the thin direction
is recorded by the exact affine projected-normal coordinates. -/
theorem uniform_frame_measured_tubular_charts_shrunk {k : ℕ} (hk : 0 < k)
    (S : Fin k → SmoothPatch (k + 2)) {κ : ℝ} (hκ : 0 < κ) (s : ℝ) (hs : 0 < s) :
    ∃ r ρ : ℝ, 0 < ρ ∧ ρ < r ∧ ρ ≤ s ∧ ∃ B : ℕ → ℝ, (∀ m, 0 ≤ B m) ∧
      ∃ c C : ℝ≥0, 0 < c ∧ ∃ L : ℝ, 1 ≤ L ∧ ∀ i,
      ∀ q ∈ frameFrequencyAdmissibleImage (S i) κ,
        ∃ (φ : Ambient (k + 2 - 1) → Ambient (k + 2))
          (R : Ambient (k + 2 - 1) →L[ℝ] ℝ × ℝ),
          φ 0 = q.2 ∧ Set.InjOn φ (closedBall 0 r) ∧ Function.Surjective R ∧
          ‖R‖ ≤ 1 ∧ (∀ w, ∃ v, R v = w ∧ ‖v‖ ≤ L * ‖w‖) ∧
          (∀ t ∈ closedBall 0 r, φ t ∈ (S i).extendedSurface ∧
            q.1 ((S i).normal (φ t)) = q.1 ((S i).normal q.2) + R t ∧
            ContDiffAt ℝ (⊤ : ℕ∞) φ t ∧ Function.Injective (fderiv ℝ φ t) ∧
            ‖fderiv ℝ φ t‖ ≤ B 1 * L ∧
            (∀ v, ‖v‖ ≤ (B 1 * L) * ‖fderiv ℝ φ t v‖)) ∧
          (∀ m t, t ∈ closedBall 0 r → ‖iteratedFDeriv ℝ m φ t‖ ≤ B m) ∧
          (∀ᶠ y in nhds q.2, y ∈ (S i).extendedSurface →
            ∃ t ∈ ball 0 ρ, φ t = y) ∧
          (∀ t ∈ closedBall (0 : Ambient (k + 2 - 1)) ρ, dist (φ t) q.2 ≤ s) ∧
          let K := closedBall (0 : Ambient (k + 2 - 1)) ρ
          let μ := (volume : Measure (Ambient (k + 2 - 1))).comap
            (Subtype.val : K → Ambient (k + 2 - 1))
          ∃ J : K → ℝ≥0, Measurable J ∧ (∀ᵐ t ∂μ, c ≤ J t ∧ J t ≤ C) ∧
            (μ.withDensity (fun t => (J t : ℝ≥0∞))).map (fun t : K => φ t) =
              (Measure.hausdorffMeasure ((k + 2 - 1 : ℕ) : ℝ)).restrict (φ '' K) := by
  obtain ⟨r, hr, B, hB, hb⟩ := uniform_frameFrequencyAdmissible_charts S hκ
  obtain ⟨ρ, hρ, hρr, hρs, c, C, hc, L, hL, hmeas⟩ :=
    uniform_tubular_surface_densities_shrunk (k + 2) (by omega) B hB r s hr hs
  refine ⟨r, ρ, hρ, hρr, hρs, B, hB, c, C, hc, L, hL, ?_⟩
  intro i q hq
  have hz : q.2 ∈ (S i).extendedSurface := by
    rcases hq with ⟨w, hw, rfl⟩
    exact SmoothPatch.support_in_extendedSurface (S i) w.2.2.2
  obtain ⟨K, e, hctrl⟩ := hb i q hq
  let chart : FrameChartModel (k + 2) := ⟨K, e⟩
  have hcontrols : chart.Controls (fun q => (q.1, frameConstraint (S i) q))
      (Set.univ ×ˢ (S i).neighborhood) q r B := hctrl
  obtain ⟨φ, R, h0, hi, hR, hRn, hRi, hφ, hd, hcov, hdist, hJ⟩ := hmeas _ chart _ _ q hcontrols
    (isOpen_univ.prod (S i).open_neighborhood)
  refine ⟨φ, R, h0, hi, hR, hRn, hRi, ?_, hd, ?_, ?_, hJ⟩
  · intro t ht
    obtain ⟨hU, hf, hs, hinj, hup, hlo, _⟩ := hφ t ht
    exact ⟨⟨hU.2, (congrArg Prod.fst hf).trans hz.2⟩,
      congrArg Prod.snd hf, hs, hinj, hup, hlo⟩
  · filter_upwards [hcov] with y hy hyS
    exact hy (hyS.2.trans hz.2.symm)

  · intro t ht
    simpa only [h0] using hdist t ht

end N2Restriction

#print axioms N2Restriction.uniform_frame_measured_tubular_charts_shrunk
