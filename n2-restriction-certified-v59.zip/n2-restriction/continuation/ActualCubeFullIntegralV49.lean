import continuation.ActualCubeKakeyaIntegralV49
import continuation.CubeProductIntegralErrorV49

namespace N2Restriction
open MeasureTheory Set Metric Filter
open scoped ENNReal NNReal

/-- Full (7.13) for an actual selected product with a tangent factor: the
common original Kakeya cube budget plus the integrated rapid cube-omission
error. The product in the conclusion is the uncut selected product. -/
theorem actual_tangent_cube_full_integral {k : ℕ}
    (S : Fin k → SmoothPatch (k+2)) (A : (i : Fin k) → PacketGraphAtlas (S i))
    {κ : ℝ} (B : ArticleLocalizationAtlas S κ)
    (V : Fin k → Set (Ambient (k+2))) (m : ℝ)
    (hS : ∀ i, (S i).extendedSurface ∩ V i ⊆ (S i).support) (hm : 0 < m)
    {p ε τ lam : ℝ} (hp : 0 < p) (hp1 : p ≤ 1) (hε : 0 < ε)
    (hexternal : B.UniformLocalizedInput p) (hτ : 0 < τ) (hτ' : τ < 1/4) (hlam : 0 < lam) :
    ∃ D : ℝ≥0, ∃ H M R₀ : ℝ, 0 ≤ H ∧ 1 ≤ M ∧ 1 ≤ R₀ ∧
    ∀ N : ℝ, ∃ Cerr : ℝ, 0 ≤ Cerr ∧ ∀ R : ℝ, R₀ ≤ R →
    ∀ (Q : (i : Fin k) → (j : Fin (A i).size) →
      CoordinateCapFamily ((A i).patch j).support (R^(-1/2 : ℝ)))
      (hr : 0 < R^(-1/2 : ℝ)), (∀ i, R^(-1/2 : ℝ) ≤ (A i).capRadius) →
    ∀ Bcap : ℝ, 0 ≤ Bcap →
    (∀ i j, ((Q i j).centers.card : ℝ) ≤ Bcap*R^(((k+1 : ℕ) : ℝ)/2)) →
    ∀ (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure)
      (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure),
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
    (∀ i j, HasFrequencySupport ((A i).graph j).surfaceMeasure ((A i).patch j).rotation
      (marginRegion (V i) (m-R^(-1/4 : ℝ))) (f i j)) →
    ∀ (i₀ : Fin k) (Z : Set (Ambient (k+2)))
      (T : Ambient (k+2) → Submodule ℝ (Ambient (k+2))) (F : Submodule ℝ (Ambient (k+2)))
      (center q x z : Ambient (k+2)) (C C₀ : ℝ) (Ω E : Set (Ambient (k+2)))
      (Ubase : (j : Fin (A i₀).size) → (Q i₀ j).centers → Set (Fin (k+1) → ℤ))
      (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin (k+1) → ℤ))
      (frame : ArticleFrame S κ),
    pairPlane frame.val = (T z ⊔ F)ᗮ →
    1 ≤ C → 1+Real.sqrt (k+2 : ℕ)*(1+C)/2 ≤ C₀ →
    z ∈ Z → x ∈ ball center (R^(1-τ)) → x ∈ gridCube q (lam*R^(1/2+τ)) →
    dist z x ≤ lam*R^(1/2+τ) → E ⊆ gridCube q (lam*R^(1/2+τ)) →
    MeasurableSet E → E ⊆ closedBall 0 R →
    U i₀ = (A i₀).actualTangentSelection (Q i₀) Ubase Z T center (R^(1-τ))
      (lam*R^(1/2+τ)) C₀ R (R^(1/2+τ)/10) Ω →
    (∫⁻ y in E, ‖extensionProduct (fun _ => Measure.hausdorffMeasure ((k+1 : ℕ) : ℝ))
      (fun _ => id) (fun i => (A i).cellInput (Q i) hr (f i) (U i)) y‖ₑ ^ p) ≤
      (((D : ENNReal)*ENNReal.ofReal (((1+Real.sqrt (k+2 : ℕ))*(lam*R^(1/2+τ)))^ε))^p *
        (ENNReal.ofReal (lam*R^(-1/2+2*τ)))^p) *
      ((ENNReal.ofReal H)^(p/2) *
        (∏ i, (A i).cubeEnergy (Q i) hr (f i) R (R^(1/2+τ)/10) C (lam*R^(1/2+τ)) q)^(p/2)) +
      (ENNReal.ofReal ((k : ℝ)*(Cerr*Real.sqrt Bcap*R^(-N))*M^k*∏ i, ‖g i‖))^p*volume E := by
  obtain ⟨D,H,hH,hlocal⟩ := eventually_actual_cube_kakeya_integral S A B V m hS hm hp hε hexternal hτ hτ' hlam
  obtain ⟨M,hM,Rerr,hRerr,htail⟩ := cube_product_integral_error S A hτ
  obtain ⟨T₀,hT₀⟩ := eventually_atTop.1 hlocal
  refine ⟨D,H,M,max Rerr T₀,hH,hM,hRerr.trans (le_max_left _ _),fun N => ?_⟩
  obtain ⟨Cerr,hCerr,herr⟩ := htail N
  refine ⟨Cerr,hCerr,?_⟩
  intro R hR Q hr hsmall Bcap hBcap hcount g f he hf i₀ Z T F center q x z C C₀ Ω E Ubase U frame
    hplane hC hC₀ hz hxb hxq hzx hE hEmeas hER hU
  have hRerr' := (le_max_left Rerr T₀).trans hR
  have hR0 : 0 ≤ R := zero_le_one.trans (hRerr.trans hRerr')
  have hb : 0 ≤ lam*R^(1/2+τ) := mul_nonneg hlam.le (Real.rpow_nonneg hR0 _)
  let W := fun i j a => U i j a ∩ {ν |
    ((A i).originalPacketTube j a (R^(-1/2 : ℝ)) ν R (R^(1/2+τ)/10) ∩
      gridCube q (C*(lam*R^(1/2+τ)))).Nonempty}
  have hWi : W i₀ = (fun j a => (A i₀).actualTangentSelection (Q i₀) Ubase Z T center (R^(1-τ))
      (lam*R^(1/2+τ)) C₀ R (R^(1/2+τ)/10) Ω j a ∩
      {ν | ((A i₀).originalPacketTube j a (R^(-1/2 : ℝ)) ν R (R^(1/2+τ)/10) ∩
        gridCube q (C*(lam*R^(1/2+τ)))).Nonempty}) := by
    dsimp [W]
    rw [hU]
  have hh := hT₀ R ((le_max_right Rerr T₀).trans hR) Q hr hsmall f hf i₀ Z T F
    center q x z C C₀ Ω E Ubase W frame hplane (zero_le_one.trans hC) hC₀ hz hxb hxq hzx hE hWi
    (fun _ _ _ _ hν => hν.2)
  have ht := herr R hRerr' Q hr hsmall Bcap hBcap hcount g f he U E q (lam*R^(1/2+τ)) C p
    hb hC hp hp1 hEmeas (fun y hy => ⟨hE hy,hER hy⟩)
  exact ht.trans (add_le_add_right hh _)

end N2Restriction
#print axioms N2Restriction.actual_tangent_cube_full_integral
