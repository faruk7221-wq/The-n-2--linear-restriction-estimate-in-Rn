import continuation.PolynomialZeroDimensionalMassV51
import continuation.UniformAtlasCapsV45
import continuation.AtlasSupportedDecompositionV44
namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal BigOperators

/-- Zero-dimensional outcome with original cap families and admissible chart inputs
constructed internally. All ceilings and constants precede the radius. -/
theorem exists_constructed_zero_dimensional_stage_mass {d k : ℕ}
    (S W : Fin k → SmoothPatch (d+1)) (T : (i : Fin k) → PacketGraphAtlas (S i))
    (V : Fin k → Set (Ambient (d+1))) (m : ℝ)
    (hW : ∀ i, (S i).extendedSurface ∩ V i ⊆ (W i).support)
    (hm : 0 < m) {τ lam : ℝ} (hτ : 0 < τ) (hτsmall : τ < 1/2) (hlam : 0 < lam)
    (hexternal : ZeroDimensionalPointCountInput (d+1)) (D : ℕ) (p : ℝ) (hp : 0 < p) (Cstage : ENNReal) (hCstage : Cstage ≠ ∞) :
    ∃ K : ENNReal, K ≠ ∞ ∧ ∃ Bcap : ℝ, 0 ≤ Bcap ∧
    ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ R : ℝ, R₀ ≤ R →
    ∃ Q : (i : Fin k) → (j : Fin (T i).size) →
      CoordinateCapFamily ((T i).patch j).support (R^(-1/2 : ℝ)),
    (∀ i, R^(-1/2 : ℝ) ≤ (T i).capRadius) ∧
    (∀ i j, ((Q i j).centers.card : ℝ) ≤ Bcap*R^((d : ℝ)/2)) ∧
    ∀ (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure),
    MarginAdmissible (fun i => (S i).surfaceMeasure) (fun _ => id) V m R (fun i => g i) →
    ∃ f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure,
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) ∧
    (∀ i j, HasFrequencySupport ((T i).graph j).surfaceMeasure id
      (((T i).graph j).parametrization '' ((T i).patch j).support) (f i j)) ∧
    (∀ i j, HasFrequencySupport ((T i).graph j).surfaceMeasure ((T i).patch j).rotation
      (marginRegion (V i) (m-R^(-1/4 : ℝ))) (f i j)) ∧
    (∀ i x, (∑ j, extension ((T i).graph j).surfaceMeasure ((T i).patch j).rotation (f i j) x) =
      extension (S i).surfaceMeasure id (g i) x) ∧
    ∀ (hr : 0 < R^(-1/2 : ℝ)),
    ∀ (A : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ))
      , ∀ {M₀ err : ENNReal} (mvar : ℕ)
      (Zs : PolynomialStage (fun _ => Measure.hausdorffMeasure (d : ℝ))
        (fun i => (T i).cellInput (Q i) hr (f i) (A i)) p R (R^(1/2+τ)) M₀ err mvar),
    (d+1)-mvar = 0 → Zs.degreeBound ≤ D → Zs.multiplier ≤ lam → Zs.constant ≤ Cstage →
    M₀ ≤ K * (marginLocalConstant (fun i => (W i).surfaceMeasure) (fun _ => id) V m p
      (lam*R^(1/2+τ)))^p * (∏ i, ENNReal.ofReal ‖g i‖)^p + err := by
  classical
  obtain ⟨K,hK,hb⟩ := eventually_polynomial_zero_dimensional_stage_mass S W T V m hW hm hτ hτsmall hlam hexternal D p hp Cstage hCstage
  obtain ⟨Bcap,hBcap,Rc,hRc,hcaps⟩ := exists_uniform_atlas_packet_caps S T
  obtain ⟨Rb,hRb⟩ := Filter.eventually_atTop.1 hb
  refine ⟨K,hK,Bcap,hBcap,max 1 (max Rc Rb),le_max_left _ _,?_⟩
  intro R hR
  have hRcR : Rc ≤ R := (le_max_left _ _).trans ((le_max_right _ _).trans hR)
  have hRbR : Rb ≤ R := (le_max_right _ _).trans ((le_max_right _ _).trans hR)
  obtain ⟨hsmall,Q,hcount⟩ := hcaps R hRcR
  refine ⟨Q,hsmall,hcount,?_⟩
  intro g hg
  choose f he hs hf hx using fun i => (T i).input_decomposition_supported (g i) _ (hg i)
  refine ⟨f,he,hs,hf,hx,?_⟩
  intro hr A M₀ err mvar Zs hzero hdegree hmult hconst
  exact hRb R hRbR Q hr hsmall g f he hf A mvar Zs hzero hdegree hmult hconst

end N2Restriction
#print axioms N2Restriction.exists_constructed_zero_dimensional_stage_mass
