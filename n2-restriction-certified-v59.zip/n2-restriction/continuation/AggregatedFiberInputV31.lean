import continuation.NormalMarginalEnergyV31
import continuation.FiberNormMeasurabilityV30

namespace N2Restriction
open MeasureTheory Set Metric
open scoped NNReal ENNReal

namespace StripChartAmplitude
variable {n : ℕ} {S : SmoothPatch n} {Q : Ambient n →L[ℝ] ℝ × ℝ} {z : Ambient n}
  {δ r ρ s : ℝ} {B : ℕ → ℝ} {c C : ℝ≥0} {L α β ε : ℝ}
  {F : MeasuredTubularChart S Q z δ r ρ s B c C L}
  {E : ChartNormalCoordinates F α β}
  {g : Lp ℂ 2 ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier)}

/-- A joint scalar representative of the normalized amplitudes. -/
noncomputable def normalizedAmplitude (A : StripChartAmplitude F E g ε)
    (p : (ℝ × ℝ) × Ambient (n - 3)) : ℂ :=
  (NNReal.sqrt (coordinateMeasureFactor E.equiv volume (volume.prod volume)) : ℝ) •
    A.fiberAmplitude p.1 p.2

/-- Integrating only scalar amplitudes defines the zero-fiber input before
any physical point or restriction exponent is selected. -/
noncomputable def referenceAmplitude (A : StripChartAmplitude F E g ε)
    (v : Ambient (n - 3)) : ℂ := ∫ u, A.normalizedAmplitude (u, v)

theorem measurable_normalizedAmplitude (A : StripChartAmplitude F E g ε) :
    Measurable A.normalizedAmplitude := by
  unfold normalizedAmplitude fiberAmplitude
  exact measurable_const.smul ((A.measurable_weight.comp E.equiv.symm.continuous.measurable).smul
    (A.measurable_input.comp E.equiv.symm.continuous.measurable))

theorem normalizedAmplitude_coe_ae (A : StripChartAmplitude F E g ε) :
    ∀ᵐ u ∂volume, (A.normalizedFiberInput u : Ambient (n - 3) → ℂ) =ᵐ[volume]
      fun v => A.normalizedAmplitude (u, v) := by
  filter_upwards [A.fiberInput_coe_ae] with u hu
  filter_upwards [hu, Lp.coeFn_smul
    (NNReal.sqrt (coordinateMeasureFactor E.equiv volume (volume.prod volume)) : ℝ) (A.fiberInput u)] with v hv hs
  exact hs.trans (congrArg (fun z : ℂ => (NNReal.sqrt (coordinateMeasureFactor E.equiv volume (volume.prod volume)) : ℝ) • z) hv)

/-- The joint representative has exactly the actual normalized fiber energy. -/
theorem normalizedAmplitude_energy (A : StripChartAmplitude F E g ε) :
    (∫⁻ u, ∫⁻ v, ‖A.normalizedAmplitude (u, v)‖ₑ ^ 2) ≤ (C : ℝ≥0∞) * ‖g‖ₑ ^ 2 := by
  refine le_trans (le_of_eq ?_) A.normalizedFiberInput_energy
  apply lintegral_congr_ae
  filter_upwards [A.normalizedAmplitude_coe_ae] with u hu
  rw [lp_enorm_sq_eq_energy]
  exact lintegral_congr_ae (hu.symm.fun_comp (fun z : ℂ => ‖z‖ₑ ^ 2))

theorem referenceAmplitude_energy (A : StripChartAmplitude F E g ε) :
    (∫⁻ v, ‖A.referenceAmplitude v‖ₑ ^ 2) ≤
      ENNReal.ofReal (2 * ε) ^ 2 * ((C : ℝ≥0∞) * ‖g‖ₑ ^ 2) := by
  have hs : ∀ u v, A.normalizedAmplitude (u, v) ≠ 0 →
      u ∈ closedBall (-Q (S.normal z)) ε := by
    intro u v hn
    have hi : A.input (E.equiv.symm (u, v)) ≠ 0 := by
      intro hz
      exact hn (by simp [normalizedAmplitude, fiberAmplitude, hz])
    have hh := (A.coordinate_support hi).1
    simpa only [mem_closedBall, dist_eq_norm, sub_neg_eq_add, add_comm] using hh
  exact (normal_marginal_energy A.normalizedAmplitude A.measurable_normalizedAmplitude
    (-Q (S.normal z)) ε hs).trans (mul_le_mul_left' A.normalizedAmplitude_energy _)

/-- The aggregate is an actual L2 input, not an assumed restriction datum. -/
theorem referenceAmplitude_memLp (A : StripChartAmplitude F E g ε) :
    MemLp A.referenceAmplitude 2 volume := by
  refine ⟨A.measurable_normalizedAmplitude.stronglyMeasurable.integral_prod_left'.aestronglyMeasurable, ?_⟩
  apply (eLpNorm_lt_top_iff_lintegral_rpow_enorm_lt_top
    (by norm_num : (2 : ℝ≥0∞) ≠ 0) (by norm_num : (2 : ℝ≥0∞) ≠ ∞)).mpr
  norm_num only [ENNReal.toReal_ofNat]
  simpa only [ENNReal.rpow_two] using A.referenceAmplitude_energy.trans_lt
    (ENNReal.mul_lt_top (ENNReal.pow_lt_top ENNReal.ofReal_lt_top)
      (ENNReal.mul_lt_top ENNReal.coe_lt_top (ENNReal.pow_lt_top (by rw [Lp.enorm_def]; exact (Lp.memLp g).2))))

noncomputable def referenceInput (A : StripChartAmplitude F E g ε) :
    Lp ℂ 2 (volume : Measure (Ambient (n - 3))) := A.referenceAmplitude_memLp.toLp A.referenceAmplitude

theorem referenceInput_energy (A : StripChartAmplitude F E g ε) :
    ‖A.referenceInput‖ₑ ^ 2 ≤ ENNReal.ofReal (2 * ε) ^ 2 * ((C : ℝ≥0∞) * ‖g‖ₑ ^ 2) := by
  rw [lp_enorm_sq_eq_energy]
  have hh := MemLp.coeFn_toLp A.referenceAmplitude_memLp
  exact (le_of_eq (lintegral_congr_ae (hh.fun_comp (fun z : ℂ => ‖z‖ₑ ^ 2)))).trans A.referenceAmplitude_energy

end StripChartAmplitude
end N2Restriction

#print axioms N2Restriction.StripChartAmplitude.measurable_normalizedAmplitude
#print axioms N2Restriction.StripChartAmplitude.normalizedAmplitude_coe_ae
#print axioms N2Restriction.StripChartAmplitude.normalizedAmplitude_energy
#print axioms N2Restriction.StripChartAmplitude.referenceAmplitude_energy
#print axioms N2Restriction.StripChartAmplitude.referenceAmplitude_memLp
#print axioms N2Restriction.StripChartAmplitude.referenceInput_energy
