import N2Restriction.SurfaceAssembly

namespace N2Restriction
open MeasureTheory

/-- Positive normal Gram bound on the actual extended patches. -/
def SurfaceTransverse {k : ℕ} (S : Fin k → SmoothPatch (k+2)) : Prop :=
  ∃ ν : ℝ, 0 < ν ∧ ∀ z : Fin k → Ambient (k+2),
    (∀ i, z i ∈ (S i).extendedSurface) →
    ν ^ 2 ≤ Matrix.det (fun i j => inner ℝ ((S i).normal (z i)) ((S j).normal (z j)))

/-- The decay hypothesis of External input 4. Smooth compactly supported
ambient test functions are integrated on the fixed extended surface. Their
compact support lies inside its open chart neighborhood. This avoids both
sharp truncation at the compact frequency support and a vacuous test class
when that support has empty relative interior.
This proposition is a remaining article-side obligation, not an axiom. -/
def SurfaceTestDecay {k : ℕ} (S : Fin k → SmoothPatch (k+2)) : Prop :=
  ∃ a : ℝ, 0 < a ∧ ∀ i (ψ : Ambient (k+2) → ℂ),
    ContDiff ℝ (⊤ : ℕ∞) ψ → HasCompactSupport ψ →
    tsupport ψ ⊆ (S i).neighborhood →
    ∃ C : ℝ, 0 ≤ C ∧ ∀ x : Ambient (k+2),
      ‖extension ((Measure.hausdorffMeasure (((k+2 : ℕ) : ℝ)-1)).restrict
        (S i).extendedSurface) id ψ x‖ ≤ C * (1 + ‖x‖) ^ (-a)

/-- External input 4 in precisely the local/global operator language of
this project. This is an explicit borrowed assumption. It does not supply
the local estimate or the decay hypothesis. -/
def SurfaceEpsilonRemovalInput : Prop :=
  ∀ k : ℕ, 3 ≤ k → ∀ S : Fin k → SmoothPatch (k+2),
    SurfaceTransverse S → SurfaceTestDecay S →
    ∀ u : ℝ, lower k ≤ u →
      LocalRestriction (fun i => (S i).surfaceMeasure) (fun _ => id) u →
      ∀ v : ℝ, u < v →
        GlobalRestriction (fun i => (S i).surfaceMeasure) (fun _ => id) v

/-- The article's geometry supplies the transversality premise, without
assuming any curvature-to-decay implication. -/
theorem geometric_surface_transverse {k : ℕ}
    (S : Fin k → SmoothPatch (k+2)) {ν κ : ℝ}
    (hgeo : GeometricHypotheses S ν κ) : SurfaceTransverse S :=
  ⟨ν, hgeo.1, fun z hz => (hgeo.2.2 z hz).1⟩

/-- Section 8's final application: at the proved local critical exponent,
the numerical threshold in the borrowed epsilon-removal input is satisfied. -/
theorem surface_global_of_local_and_external_removal
    (hexternal : SurfaceEpsilonRemovalInput) {k : ℕ} (hk : 3 ≤ k)
    (S : Fin k → SmoothPatch (k+2)) {ν κ : ℝ}
    (hgeo : GeometricHypotheses S ν κ) (hdecay : SurfaceTestDecay S)
    (hlocal : LocalRestriction (fun i => (S i).surfaceMeasure) (fun _ => id) (critical k)) :
    ∀ p : ℝ, critical k < p →
      GlobalRestriction (fun i => (S i).surfaceMeasure) (fun _ => id) p := by
  have hkR : (0 : ℝ) < k := by exact_mod_cast (show 0 < k by omega)
  exact hexternal k hk S (geometric_surface_transverse S hgeo) hdecay
    (critical k) (lower_lt_critical hkR).le hlocal

/-- The two article-side obligations are visible: local restriction and
surface test decay. Epsilon removal itself is now an external assumption. -/
theorem mainGlobalGoal_of_local_decay_and_external_removal
    (hexternal : SurfaceEpsilonRemovalInput) (hlocal : MainLocalGoal)
    (hdecay : ∀ k : ℕ, 3 ≤ k → ∀ S : Fin k → SmoothPatch (k+2),
      ∀ ν κ : ℝ, GeometricHypotheses S ν κ → SurfaceTestDecay S) : MainGlobalGoal := by
  intro k hk S ν κ hgeo
  exact surface_global_of_local_and_external_removal hexternal hk S hgeo
    (hdecay k hk S ν κ hgeo) (hlocal k hk S ν κ hgeo)

/-- Complete final assembly conditional on the actual article recurrence
and decay. Neither is mislabeled as a borrowed input. -/
theorem mainGoals_of_recurrences_decay_and_external_removal
    (hexternal : SurfaceEpsilonRemovalInput)
    (hrec : ∀ k : ℕ, 3 ≤ k → ∀ S : Fin k → SmoothPatch (k+2),
      ∀ ν κ : ℝ, GeometricHypotheses S ν κ →
      ∀ p : ℝ, critical k < p → p < baseline k →
        RestrictionRecurrences (fun i => (S i).surfaceMeasure) (fun _ => id) p)
    (hdecay : ∀ k : ℕ, 3 ≤ k → ∀ S : Fin k → SmoothPatch (k+2),
      ∀ ν κ : ℝ, GeometricHypotheses S ν κ → SurfaceTestDecay S) :
    MainLocalGoal ∧ MainGlobalGoal := by
  have hl := mainLocalGoal_of_surface_recurrences hrec
  exact ⟨hl, mainGlobalGoal_of_local_decay_and_external_removal hexternal hl hdecay⟩

end N2Restriction

#print axioms N2Restriction.geometric_surface_transverse
#print axioms N2Restriction.surface_global_of_local_and_external_removal
#print axioms N2Restriction.mainGlobalGoal_of_local_decay_and_external_removal
#print axioms N2Restriction.mainGoals_of_recurrences_decay_and_external_removal
