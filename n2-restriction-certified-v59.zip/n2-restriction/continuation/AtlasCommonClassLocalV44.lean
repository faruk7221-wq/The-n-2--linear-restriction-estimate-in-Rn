import continuation.SurfaceAdmissibleLocalV44
import continuation.AtlasFamilyChildMarginV44

namespace N2Restriction
open MeasureTheory Set
open scoped ENNReal

/-- Direct local estimate on a common surface class using only active support.
The fixed class must contain each extended surface over its frequency domain;
no containment of inactive packet buffers is required. -/
theorem eventually_atlas_common_class_local {d k : ℕ}
    (S W : Fin k → SmoothPatch (d + 1)) (T : (i : Fin k) → PacketGraphAtlas (S i))
    (V : Fin k → Set (Ambient (d + 1))) (m : ℝ)
    (hW : ∀ i, (S i).extendedSurface ∩ V i ⊆ (W i).support) :
    ∀ᶠ R : ℝ in Filter.atTop, ∀ L : ℝ, 1 ≤ L → L ≤ R / 2 → 0 < m - L ^ (-1 / 4 : ℝ) →
      ∀ (Q : (i : Fin k) → (j : Fin (T i).size) →
        CoordinateCapFamily ((T i).patch j).support (R ^ (-1 / 2 : ℝ)))
      (hr : 0 < R ^ (-1 / 2 : ℝ)), (∀ i, R ^ (-1 / 2 : ℝ) ≤ (T i).capRadius) →
      ∀ (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure),
      (∀ i j, HasFrequencySupport ((T i).graph j).surfaceMeasure ((T i).patch j).rotation
        (marginRegion (V i) (m - R ^ (-1 / 4 : ℝ))) (f i j)) →
      ∀ (U : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ))
      (p : ℝ), 0 < p → ∀ x₀ : Ambient (d + 1),
      (∫⁻ x in Metric.ball x₀ L,
        ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
          (fun i => (T i).cellInput (Q i) hr (f i) (U i)) x‖ₑ ^ p) ≤
        (marginLocalConstant (fun i => (W i).surfaceMeasure) (fun _ => id) V m p L *
          ∏ i, ENNReal.ofReal ‖(T i).cellInput (Q i) hr (f i) (U i)‖)^p := by
  filter_upwards [Filter.eventually_all.mpr
    (fun i => (T i).eventually_cellInput_child_margin (V i) m)] with R hR
  intro L hL hLR hm Q hr hsmall f hf U p hp x₀
  have hmargin i := hR i L hL hLR (Q i) hr (f i) (hf i) (U i)
  apply surface_supported_local_power_bound W V _ hp _ hmargin x₀
  intro i
  apply (T i).cellInput_support_of_margin (W i).support (V i) _ _ (Q i) hr (hsmall i) (f i) (U i) (hmargin i)
  rintro x ⟨hx, hmarg⟩
  exact hW i ⟨hx, marginRegion_subset (V i) hm hmarg⟩

end N2Restriction
#print axioms N2Restriction.eventually_atlas_common_class_local
