import continuation.DependentBlockLoomisWhitneyV34
import continuation.FiberInputNormsV29

namespace N2Restriction
open MeasureTheory
open scoped ENNReal BigOperators

section
variable (n : ℕ) (X : Fin (n+2) → Type*) [∀ i, MeasurableSpace (X i)]
    [∀ i, Inhabited (X i)] (μ : ∀ i, Measure (X i)) [∀ i, SigmaFinite (μ i)]
    (f : ∀ i : Fin (n+2), Lp ℂ 2 (Measure.pi (fun j => μ (i.succAbove j))))

noncomputable def dependentBlockProduct (x : ∀ i, X i) : ℂ := ∏ i, f i (i.removeNth x)

omit [∀ i, SigmaFinite (μ i)] [∀ i, Inhabited (X i)] in
theorem measurable_dependentBlockProduct : Measurable (dependentBlockProduct n X μ f) := by
  apply Finset.measurable_prod
  intro i _
  exact (Lp.stronglyMeasurable (f i)).measurable.comp
    (measurable_pi_iff.mpr (fun j => measurable_pi_apply _))

theorem dependent_block_L2_power_integral :
    (∫⁻ x, ‖dependentBlockProduct n X μ f x‖ₑ ^ (2 / ((n : ℝ)+1)) ∂Measure.pi μ) ≤
      (∏ i, ‖f i‖ₑ) ^ (2 / ((n : ℝ)+1)) := by
  have hp : 0 ≤ 1 / ((n : ℝ)+1) := by positivity
  have hp₂ : 0 ≤ 2 / ((n : ℝ)+1) := by positivity
  have hb := dependent_block_loomis_whitney n X μ (fun i y => ‖f i y‖ₑ ^ 2)
    (fun i => (Lp.stronglyMeasurable (f i)).measurable.enorm.pow_const 2)
  have hs (a : ℝ≥0∞) : (a ^ 2) ^ (1 / ((n : ℝ)+1)) = a ^ (2 / ((n : ℝ)+1)) := by
    rw [← ENNReal.rpow_natCast, ← ENNReal.rpow_mul]
    congr 1
    ring
  simp only [← ENNReal.prod_rpow_of_nonneg hp, hs, ← lp_enorm_sq_eq_energy] at hb
  have hprod (s : Finset (Fin (n+2))) (g : Fin (n+2) → ℂ) : ‖∏ i ∈ s, g i‖ₑ = ∏ i ∈ s, ‖g i‖ₑ := by
    induction s using Finset.induction_on with
    | empty => simp
    | @insert i s hi ih => simp [hi, ih, enorm_mul]
  simpa only [dependentBlockProduct, hprod, ← ENNReal.prod_rpow_of_nonneg hp₂] using hb

theorem dependent_block_L2_quasinorm :
    eLpNorm' (dependentBlockProduct n X μ f) (2 / ((n : ℝ)+1)) (Measure.pi μ) ≤ ∏ i, ‖f i‖ₑ := by
  have hpos : 0 < (n : ℝ)+1 := by positivity
  have hq : 0 ≤ ((n : ℝ)+1)/2 := by positivity
  have hmul : (2 / ((n : ℝ)+1)) * (((n : ℝ)+1)/2) = 1 := by field_simp
  have hinv : 1 / (2 / ((n : ℝ)+1)) = ((n : ℝ)+1)/2 := by field_simp
  have h := ENNReal.rpow_le_rpow (dependent_block_L2_power_integral n X μ f) hq
  rw [← ENNReal.rpow_mul, hmul, ENNReal.rpow_one] at h
  simpa only [eLpNorm'_eq_lintegral_enorm, hinv] using h

theorem dependent_block_L2_memLp :
    MemLp (dependentBlockProduct n X μ f) (ENNReal.ofReal (2 / ((n : ℝ)+1))) (Measure.pi μ) := by
  have hp : 0 < 2 / ((n : ℝ)+1) := by positivity
  refine ⟨(measurable_dependentBlockProduct n X μ f).aestronglyMeasurable, ?_⟩
  rw [eLpNorm_eq_eLpNorm' (ne_of_gt (ENNReal.ofReal_pos.mpr hp)) ENNReal.ofReal_ne_top,
    ENNReal.toReal_ofReal hp.le]
  exact (dependent_block_L2_quasinorm n X μ f).trans_lt (ENNReal.prod_lt_top (fun i _ => by finiteness))

end
end N2Restriction

#print axioms N2Restriction.dependent_block_L2_memLp
#print axioms N2Restriction.dependent_block_L2_power_integral
#print axioms N2Restriction.dependent_block_L2_quasinorm
#print axioms N2Restriction.measurable_dependentBlockProduct
