import continuation.GraphFiberBudgetV57
import continuation.CurvedOscillatoryHalfDecayV56
import Mathlib.MeasureTheory.Integral.Prod
namespace N2Restriction
open Set MeasureTheory
set_option maxHeartbeats 1000000

/-- Actual compact chart product integrals have a coefficient fixed before
both physical direction and frequency. All amplitude and integrability budgets
are derived internally from the actual smooth compact amplitude. -/
theorem exists_compact_chart_product_half_decay {d n : ℕ}
    (B : Ambient (d+1) → ℂ) (hB : ContDiff ℝ (⊤ : ℕ∞) B) (hs : HasCompactSupport B)
    (G : Ambient (d+1) → Ambient n) (hG : ContDiff ℝ (⊤ : ℕ∞) G)
    (K : Set (Ambient d)) (hK : IsCompact K) (Θ : Set (Ambient n))
    (a b : ℝ) (hab : a ≤ b) {c : ℝ} (hc : 0 < c)
    (hcurved : ∀ θ ∈ Θ, ∀ y ∈ K, ∀ t ∈ Icc a b,
      c ≤ |deriv (deriv (fun s => inner ℝ θ (G (graphPoint y s)))) t|) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ θ ∈ Θ, ∀ freq : ℝ, 0 < freq →
      ‖∫ p : Ambient d × ℝ, B (graphPoint p.1 p.2)*
          phaseExponential freq (fun s => inner ℝ θ (G (graphPoint p.1 s))) p.2
          ∂((volume.restrict K).prod (volume.restrict (Ioc a b)))‖ ≤ C*freq^(-(1/2 : ℝ)) := by
  let μ : Measure (Ambient d) := volume.restrict K
  let ν : Measure ℝ := volume.restrict (Ioc a b)
  letI : IsFiniteMeasure μ := ⟨by simpa [μ] using hK.measure_lt_top (μ := volume)⟩
  obtain ⟨M,N,hM,hN,hMb,hNb⟩ := exists_graph_fiber_budgets B hB hs
  let C₀ := ((2+2*Real.pi)*M+(b-a)*N)/Real.sqrt c
  have hC₀ : 0 ≤ C₀ := div_nonneg
    (add_nonneg (mul_nonneg (by positivity) hM) (mul_nonneg (sub_nonneg.mpr hab) hN))
    (Real.sqrt_nonneg _)
  refine ⟨μ.real univ*C₀,mul_nonneg (measureReal_nonneg) hC₀,?_⟩
  intro θ hθ freq hf
  let F : Ambient d × ℝ → ℂ := fun p => B (graphPoint p.1 p.2)*
    phaseExponential freq (fun s => inner ℝ θ (G (graphPoint p.1 s))) p.2
  have hgp : Continuous (fun p : Ambient d × ℝ => graphPoint p.1 p.2) := graphPointCLM.continuous
  have hBc := hB.continuous
  have hGc := hG.continuous
  have hF : Continuous F := by
    unfold F phaseExponential
    fun_prop
  have hi : Integrable F (μ.prod ν) :=
    (integrable_const M).mono' hF.aestronglyMeasurable (Filter.Eventually.of_forall (fun p => by
      simpa only [F,norm_mul,norm_phaseExponential,mul_one] using hMb p.1 p.2))
  rw [integral_prod _ hi]
  calc
    _ ≤ ∫ _y, C₀*freq^(-(1/2 : ℝ)) ∂μ := by
      apply norm_integral_le_of_norm_le (integrable_const _)
      filter_upwards [ae_restrict_mem hK.measurableSet] with y hy
      have hAy := contDiff_graph_fiber B hB y
      have hφ := contDiff_graph_fiber (fun z => inner ℝ θ (G z))
        (ContDiff.inner (𝕜 := ℝ) contDiff_const hG) y
      have hdi := hAy.continuous_deriv (by norm_cast)
      have hNint : (∫ t in a..b, ‖deriv (fun s => B (graphPoint y s)) t‖) ≤ (b-a)*N := by
        have h := intervalIntegral.integral_mono_on (μ := volume) hab
          (hdi.norm.intervalIntegrable a b) (continuous_const.intervalIntegrable a b)
          (fun t _ => hNb y t)
        simpa only [intervalIntegral.integral_const,smul_eq_mul] using h
      have h := curved_oscillatory_half_decay _ (hAy.of_le (by norm_cast)) _
        (hφ.of_le (by norm_cast)) a b freq hab hf hc hM (hcurved θ hθ y hy) (fun t _ => hMb y t)
      rw [intervalIntegral.integral_of_le hab] at h
      exact h.trans (mul_le_mul_of_nonneg_right
        (div_le_div_of_nonneg_right (add_le_add_left hNint _) (Real.sqrt_nonneg _))
        (Real.rpow_nonneg hf.le _))
    _ = _ := by simp only [integral_const,smul_eq_mul]; ring
end N2Restriction
#print axioms N2Restriction.exists_compact_chart_product_half_decay
