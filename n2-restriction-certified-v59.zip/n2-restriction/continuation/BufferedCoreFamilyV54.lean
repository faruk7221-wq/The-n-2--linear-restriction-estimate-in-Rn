import continuation.CompactCoreInputsV53
namespace N2Restriction
open Set Metric MeasureTheory
set_option maxHeartbeats 600000

/-- A fixed refined family of ACTUAL smooth core patches, not an assumption
about margins on the boundary of the original directional pieces. -/
structure BufferedDirectionalCoreFamily {n : ℕ} (S P : SmoothPatch n)
    {ε : ℝ} (D : DirectionalSubdivision P ε) where
  size : ℕ
  patch : Fin size → SmoothPatch n
  label : Fin size → Fin D.size
  domain : Fin size → Set (Ambient n)
  collar : Fin size → ℝ
  collar_pos : ∀ j, 0 < collar j
  cover : S.support ⊆ ⋃ j, (patch j).support
  original : ∀ j, (patch j).support ⊆ S.support
  directional : ∀ j, (patch j).support ⊆ (D.piece (label j)).support
  margin : ∀ j, (patch j).support ⊆ marginRegion (domain j) (collar j)
  active : ∀ j, (D.piece (label j)).extendedSurface ∩ domain j ⊆ (D.piece (label j)).support

/-- Construct the finite core patches and their exact support geometry before
R, from the SAME retained directional open cover and buffered parent class. -/
theorem exists_buffered_directional_core_family {n : ℕ} (S P : SmoothPatch n)
    {ε : ℝ} (D : DirectionalSubdivision P ε) (hSP : S.support ⊆ P.support)
    (U : Set (Ambient n)) (hU : IsOpen U) (hSU : S.support ⊆ U)
    (hclass : P.extendedSurface ∩ U ⊆ P.support)
    (O : Fin D.size → Set (Ambient n)) (hO : ∀ j, IsOpen (O j))
    (hcover : P.support ⊆ ⋃ j, O j)
    (hinside : ∀ j, P.support ∩ O j ⊆ (D.piece j).support) :
    Nonempty (BufferedDirectionalCoreFamily S P D) := by
  classical
  obtain ⟨N,c,r,label,hr,hcov,hcompact,hdirectional,hmargin,hactive⟩ :=
    buffered_directional_core_cover P D S.support U S.compact_support hSP hU hSU hclass O hO hcover hinside
  choose Q hQ hE hN hM using fun j => (D.piece (label j)).exists_compact_core_patch
    (S.support ∩ closedBall (c j) (r j)) (hcompact j) (hdirectional j)
  exact ⟨⟨N,Q,label,(fun j => ball (c j) (2*r j)),r,hr,
    by simpa only [hQ] using hcov,
    (fun j => by rw [hQ]; exact inter_subset_left),
    (fun j => by rw [hQ]; exact hdirectional j),
    (fun j => by rw [hQ]; exact hmargin j),hactive⟩⟩
end N2Restriction
#print axioms N2Restriction.exists_buffered_directional_core_family
