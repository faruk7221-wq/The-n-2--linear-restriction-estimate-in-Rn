import continuation.AtlasLabelBudgetV42
import continuation.AtlasPacketAxesV42

namespace N2Restriction
open MeasureTheory
open scoped BigOperators ENNReal

/-- Equation (6.8) for the actual fixed surface atlas, with the original
surface norm on the right and the actual normal axes on the left. -/
theorem PacketGraphAtlas.near_cell_energy_budget {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) :
    ∃ B : ℝ, 0 ≤ B ∧ ∀ {m : ℕ} {r : ℝ}
      (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r) (hr : 0 < r)
      (g : Lp ℂ 2 S.surfaceMeasure)
      (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure),
      (∑ j, ‖f j‖^2) ≤ ‖g‖^2 →
      ∀ (A : (j : Fin T.size) → (Q j).centers → Set (Fin d → ℤ))
        (P : Fin m → MvPolynomial (Fin (d+1)) ℝ) (Ω : Set (Ambient (d+1)))
        {b w : ℝ}, w < b →
      (∑' σ : Fin m → Bool, ENNReal.ofReal (‖T.cellInput Q hr f
        (fun j a => {ν | ν ∈ A j a ∧ σ ∈ trimmedCellLabels P
          (T.cellAxisPoint j r ν) (T.cellAxisDirection j a.val) Ω b w})‖^2)) ≤
        ENNReal.ofReal B * (((∏ l, P l).totalDegree+1 : ℕ) : ENNReal) *
          ENNReal.ofReal (‖g‖^2) := by
  obtain ⟨B, hB, hb⟩ := T.original_labelled_cell_budget
  refine ⟨B, hB, ?_⟩
  intro m r Q hr g f he A P Ω b w hw
  apply hb Q hr g f he A
    (fun j a ν => trimmedCellLabels P (T.cellAxisPoint j r ν) (T.cellAxisDirection j a.val) Ω b w)
  intro j a ν _
  exact_mod_cast trimmedCellLabels_card_le_degree P _ _ Ω hw

end N2Restriction
#print axioms N2Restriction.PacketGraphAtlas.near_cell_energy_budget
