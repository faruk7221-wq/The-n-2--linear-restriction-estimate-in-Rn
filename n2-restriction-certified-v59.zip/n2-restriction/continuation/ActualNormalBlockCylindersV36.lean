import continuation.ThinNormalBlockCoordinatesV36
import continuation.FixedApertureDependentBlockV35

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal BigOperators

/-- The fixed-aperture estimate is now instantiated on actual general-dimensional
thin-normal configurations, with aperture and coefficient chosen before
all geometric data. This concerns projection cylinders with close projections. -/
theorem uniform_actual_normal_block_fixed_aperture_cylinders {n : ℕ} (i : Fin (n+2))
    (M c : ℝ) (hM : 0 ≤ M) (hc : 0 < c) (η : ℝ) (hη : 0 < η) :
    ∃ K : ℝ≥0∞, 0 < K ∧ K ≠ ⊤ ∧ ∃ δ : ℝ, 0 < δ ∧
    ∀ (S : Fin (n+2) → SmoothPatch (n+4)) (z : Fin (n+2) → Ambient (n+4))
      (q : Ambient (n+4) × Ambient (n+4)) (N : Submodule ℝ (Ambient (n+4)))
      (_b : OrthonormalBasis (Fin 3) ℝ N),
      (∀ j, ‖(S j).normal (z j)‖ = 1) → ‖(S i).shape (z i)‖ ≤ M →
      ‖q.1‖ ≤ 1 → ‖q.2‖ ≤ 1 →
      (S i).normal (z i) ∈ N → (S i).shape (z i) q.1 ∈ N →
      (S i).shape (z i) q.2 ∈ N →
      c ≤ Matrix.det (Matrix.gram ℝ (nearbyWedgeVectors S z i q)) →
      ∃ C : Ambient (n+4) ≃L[ℝ] (∀ j, Ambient (normalBlockDimensions n j)),
        NormalBlockKernels S z i N C ∧
      ∀ (T : Fin (n+2) → Type) [∀ j, Countable (T j)]
      (A : ∀ j, T j → Ambient (n+4) →L[ℝ] (∀ t, Ambient (normalBlockDimensions n (j.succAbove t))))
      (a : ∀ j, T j → (∀ t, Ambient (normalBlockDimensions n (j.succAbove t)))),
      (∀ j t, ‖A j t - dependentBlockProjection (normalBlockDimensions n) C j‖ ≤ δ) →
      ∀ (u : ∀ j, T j → ℝ≥0∞) (x₀ : Ambient (n+4)) (R w : ℝ), 0 < w → w ≤ R →
      (∫⁻ x in closedBall x₀ R, (∏ j, tubeDensity
        (fun t => A j t ⁻¹' closedBall (a j t) w) (u j) x) ^ (1/((n:ℝ)+1))) ≤
        K * ENNReal.ofReal R^η * ENNReal.ofReal w^(((n+4:ℕ):ℝ)-η) * (∏ j, ∑' t, u j t)^(1/((n:ℝ)+1)) := by
  obtain ⟨B,hB,hcoord⟩ := uniform_thin_normal_block_coordinates i M c hM hc
  obtain ⟨K,hK,hKfin,δ,hδ,hbound⟩ := uniform_fixed_aperture_dependent_blocks (n+4) n (normalBlockDimensions n)
    (normalBlockDimensions_sum n) B hB.le η hη
  refine ⟨K,hK,hKfin,δ,hδ,?_⟩
  intro S z q N b hunit hshape hq₁ hq₂ hN hA₁ hA₂ hG
  obtain ⟨C,he,hei,hker⟩ := hcoord S z q N b hunit hshape hq₁ hq₂ hN hA₁ hA₂ hG
  exact ⟨C,hker,hbound C he hei⟩

end N2Restriction

#print axioms N2Restriction.uniform_actual_normal_block_fixed_aperture_cylinders
