import continuation.ConstructedSubpatchGrowthV53
import continuation.FixedGrowthEstimateV53
namespace N2Restriction
open MeasureTheory Set Metric Filter
open scoped ENNReal NNReal
set_option maxHeartbeats 800000

/-- Actual local extension estimate on the chosen subpatch margin classes.
Finite descent, input reconstruction and scalar closure are internal proofs;
only the explicitly listed borrowed inputs remain hypotheses. -/
theorem exists_constructed_subpatch_margin_estimate {k : ℕ} (hk : 3 ≤ k)
    (P : Fin k → SmoothPatch (k+2)) {ν κ : ℝ} (hgeo : GeometricHypotheses P ν κ)
    (hKexternal : WeightedKakeyaExternalGoal (k+2) k)
    (hcutsExternal : UniformTangentCutsInput (k+2))
    (hpartitionExternal : UniformProjectedPartitionInput (k+2))
    (hcoverExternal : UniformPolynomialTubeCoverInput (k+2))
    (hpointsExternal : ZeroDimensionalPointCountInput (k+2))
    {δ : ℝ} (hδ : 0 < δ) :
    ∃ ι : ℝ, 0 < ι ∧ ∃ Dsub : (i : Fin k) → DirectionalSubdivision (P i) ι,
    ∀ (a : (i : Fin k) → Fin (Dsub i).size)
      (B : ArticleLocalizationAtlas (fun i => (Dsub i).piece (a i)) κ)
      (V : Fin k → Set (Ambient (k+2))) (margin : ℝ),
    (∀ i, ((Dsub i).piece (a i)).extendedSurface ∩ V i ⊆ ((Dsub i).piece (a i)).support) →
    0 < margin → B.UniformLocalizedInput (baseline (k : ℝ)) →
    ∀ p : ℝ, critical k < p → p < baseline k →
    ∃ C : ℝ≥0, ∀ R : ℝ, 2 ≤ R →
    ∀ (x : Ambient (k+2)) (f : Fin k → Ambient (k+2) → ℂ),
      (∀ i, MemLp (f i) 2 ((Dsub i).piece (a i)).surfaceMeasure) →
      MarginAdmissible (fun i => ((Dsub i).piece (a i)).surfaceMeasure) (fun _ => id) V margin R f →
      eLpNorm' (extensionProduct (fun i => ((Dsub i).piece (a i)).surfaceMeasure) (fun _ => id) f) p
        (volume.restrict (ball x R)) ≤
        (C : ENNReal)*ENNReal.ofReal (R^δ)*inputNormProduct (fun i => ((Dsub i).piece (a i)).surfaceMeasure) f := by
  obtain ⟨ι,hι,Dsub,hbound⟩ := exists_constructed_subpatch_margin_growth hk P hgeo hKexternal
    hcutsExternal hpartitionExternal hcoverExternal hpointsExternal hδ
  refine ⟨ι,hι,Dsub,?_⟩
  intro a B V margin hS hm hexternal p hpc hpb
  letI : ∀ i, IsFiniteMeasure (((Dsub i).piece (a i)).surfaceMeasure) :=
    fun i => ((Dsub i).piece (a i)).isFiniteMeasure_surfaceMeasure (by omega)
  have hp : 0 < p := (critical_pos (by exact_mod_cast (show 0 < k by omega))).trans hpc
  exact margin_estimate_of_fixed_growth (fun i => ((Dsub i).piece (a i)).surfaceMeasure) (fun _ => id)
    V margin hp (hbound a B V margin hS hm hexternal p hpc hpb)
end N2Restriction
#print axioms N2Restriction.exists_constructed_subpatch_margin_estimate
