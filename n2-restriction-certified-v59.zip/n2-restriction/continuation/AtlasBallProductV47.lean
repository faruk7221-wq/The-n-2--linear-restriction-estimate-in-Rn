import continuation.AtlasCommonClassLocalV44

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal

/-- The positive function F_nt in (7.2), for a specified selection in
each covering ball. All factors use the original atlas decomposition. -/
noncomputable def atlasBallProductSum {d k L : ℕ}
    {S : Fin k → SmoothPatch (d+1)} (T : (i : Fin k) → PacketGraphAtlas (S i))
    {r : ℝ} (Q : (i : Fin k) → (j : Fin (T i).size) →
      CoordinateCapFamily ((T i).patch j).support r) (hr : 0 < r)
    (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure)
    (U : Fin L → (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ))
    (c : Fin L → Ambient (d+1)) (ρ : ℝ) (Ω : Set (Ambient (d+1))) : Ambient (d+1) → ENNReal :=
  fun x => ∑ l, (Ω ∩ ball (c l) ρ).indicator (fun y =>
    ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
      (fun i => (T i).cellInput (Q i) hr (f i) (U l i)) y‖ₑ) x

/-- Integrability of actual selected packet inputs gives measurability of
each product, even though the ambient Hausdorff measure is not finite. -/
theorem measurable_atlas_selected_product {d k : ℕ}
    {S : Fin k → SmoothPatch (d+1)} (T : (i : Fin k) → PacketGraphAtlas (S i))
    {r : ℝ} (Q : (i : Fin k) → (j : Fin (T i).size) →
      CoordinateCapFamily ((T i).patch j).support r) (hr : 0 < r)
    (hsmall : ∀ i, r ≤ (T i).capRadius)
    (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure)
    (U : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ)) :
    Measurable (fun x => ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ))
      (fun _ => id) (fun i => (T i).cellInput (Q i) hr (f i) (U i)) x‖ₑ) := by
  exact (continuous_finset_prod _ (fun i _ => continuous_extension measurable_id
    ((T i).cellInput_integrable (Q i) hr (hsmall i) (f i) (U i)))).enorm.measurable

end N2Restriction
#print axioms N2Restriction.measurable_atlas_selected_product
