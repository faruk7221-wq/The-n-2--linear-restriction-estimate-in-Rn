import N2Restriction.AtlasPackets

namespace N2Restriction
open MeasureTheory Set

/-- Restriction preserves arbitrary essential frequency support. -/
theorem restrictInputL2_frequency_support {Ω E : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) (s : Set Ω) (f : Lp ℂ 2 μ) (ζ : Ω → E) (F : Set E)
    (hf : HasFrequencySupport μ ζ F f) :
    HasFrequencySupport (μ.restrict s) ζ F (restrictInputL2 μ s f) :=
  HasFrequencySupport.congr (ae_restrict_of_ae hf) (restrictInputL2_coe μ s f).symm

/-- The disjoint chart assignment cannot enlarge the original input support. -/
theorem finiteCoverInput_frequency_support {Ω E : Type*} [MeasurableSpace Ω] {m : ℕ}
    (μ : Measure Ω) (K : Fin m → Set Ω) (hK : ∀ j, MeasurableSet (K j))
    (g : Lp ℂ 2 μ) (ζ : Ω → E) (F : Set E) (hg : HasFrequencySupport μ ζ F g)
    (j : Fin m) : HasFrequencySupport μ ζ F (finiteCoverInput μ K hK g j) := by
  filter_upwards [finiteCoverInput_coe μ K hK g j, hg] with x hx hs hn
  apply hs
  intro hz
  by_cases h : x ∈ disjointed K j
  · exact hn (by simpa only [hx, indicator_of_mem h] using hz)
  · exact hn (hx.trans (indicator_of_notMem h _))

/-- Chart-measure inputs preserve the actual original essential support. -/
theorem atlasPatchInput_frequency_support {n m : ℕ} (μ : Measure (Ambient n))
    (S : Set (Ambient n)) (hS : MeasurableSet S)
    (K : Fin m → Set (Ambient n)) (hK : ∀ j, MeasurableSet (K j))
    (g : Lp ℂ 2 (μ.restrict S)) (ζ : Ambient n → Ambient n) (F : Set (Ambient n))
    (hg : HasFrequencySupport (μ.restrict S) ζ F g) (j : Fin m) :
    HasFrequencySupport (μ.restrict (K j)) ζ F (atlasPatchInput μ S hS K hK g j) := by
  apply restrictInputL2_frequency_support
  apply zeroExtendL2_frequency_support
  exact finiteCoverInput_frequency_support _ K hK g ζ F hg j

/-- Essential support of a transported input pulls back through the rotation. -/
theorem rotatedInput_frequency_support_iff {n : ℕ} (A : Ambient n ≃ₗᵢ[ℝ] Ambient n)
    (μ : Measure (Ambient n)) (F : Set (Ambient n)) (f : Lp ℂ 2 μ) :
    HasFrequencySupport (μ.map A) id F (rotatedInput A μ f) ↔
      HasFrequencySupport μ A F f := by
  refine ⟨?_, rotatedInput_frequency_support A μ F f⟩
  intro hf
  have hh := ae_of_ae_map A.continuous.measurable.aemeasurable hf
  have he := ae_of_ae_map A.continuous.measurable.aemeasurable
    (imageInput_coe μ A A.symm A.continuous.measurable A.symm.continuous.measurable
      A.symm_apply_apply f)
  filter_upwards [hh, he] with x hs hx hn
  apply hs
  change (rotatedInput A μ f) (A x) = f (A.symm (A x)) at hx
  simpa only [hx, A.symm_apply_apply] using hn

end N2Restriction
#print axioms N2Restriction.restrictInputL2_frequency_support
#print axioms N2Restriction.finiteCoverInput_frequency_support
#print axioms N2Restriction.atlasPatchInput_frequency_support
#print axioms N2Restriction.rotatedInput_frequency_support_iff
