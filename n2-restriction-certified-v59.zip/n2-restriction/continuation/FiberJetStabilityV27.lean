import continuation.ReferenceLocalizationV27

namespace N2Restriction
open Metric

/-- A bound on the next derivative controls variation of the current jet on
a convex chart domain. This compares the full multilinear derivatives. -/
theorem iteratedFDeriv_distance_bound {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    {φ : E → F} {r M : ℝ} (m : ℕ)
    (hφ : ∀ x ∈ closedBall (0 : E) r, ContDiffAt ℝ (⊤ : ℕ∞) φ x)
    (hD : ∀ x ∈ closedBall (0 : E) r, ‖iteratedFDeriv ℝ (m + 1) φ x‖ ≤ M)
    {x y : E} (hx : x ∈ closedBall (0 : E) r) (hy : y ∈ closedBall (0 : E) r) :
    ‖iteratedFDeriv ℝ m φ x - iteratedFDeriv ℝ m φ y‖ ≤ M * ‖x - y‖ := by
  exact (convex_closedBall (0 : E) r).norm_image_sub_le_of_norm_fderiv_le
    (fun t ht => (hφ t ht).differentiableAt_iteratedFDeriv (m := m) (by
      exact WithTop.coe_lt_coe.mpr (ENat.coe_lt_top m)))
    (fun t ht => by simpa only [norm_fderiv_iteratedFDeriv] using hD t ht) hy hx

/-- Taking the same affine slice of two full jets costs at most L^m. -/
theorem affine_slice_jet_difference {E F G : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    [NormedAddCommGroup G] [NormedSpace ℝ G]
    (g : G →L[ℝ] E) {L : ℝ} (hg : ‖g‖ ≤ L) (a b : E) {φ : E → F}
    (v : G) (m : ℕ)
    (ha : ContDiffAt ℝ (⊤ : ℕ∞) φ (a + g v))
    (hb : ContDiffAt ℝ (⊤ : ℕ∞) φ (b + g v)) :
    ‖iteratedFDeriv ℝ m (fun w => φ (a + g w)) v -
      iteratedFDeriv ℝ m (fun w => φ (b + g w)) v‖ ≤
      ‖iteratedFDeriv ℝ m φ (a + g v) - iteratedFDeriv ℝ m φ (b + g v)‖ * L ^ m := by
  have hea := iteratedFDeriv_comp_linear_at g m
    (ha.comp (g v) (contDiffAt_const.add contDiffAt_id))
  have heb := iteratedFDeriv_comp_linear_at g m
    (hb.comp (g v) (contDiffAt_const.add contDiffAt_id))
  change iteratedFDeriv ℝ m (fun w => φ (a + g w)) v = _ at hea
  change iteratedFDeriv ℝ m (fun w => φ (b + g w)) v = _ at heb
  rw [hea, heb]
  simp only [Function.comp_def] 
  rw [iteratedFDeriv_comp_add_left, iteratedFDeriv_comp_add_left]
  have heq : (iteratedFDeriv ℝ m φ (a + g v)).compContinuousLinearMap (fun _ => g) -
      (iteratedFDeriv ℝ m φ (b + g v)).compContinuousLinearMap (fun _ => g) =
      (iteratedFDeriv ℝ m φ (a + g v) - iteratedFDeriv ℝ m φ (b + g v)).compContinuousLinearMap
        (fun _ => g) := by
    ext w
    rfl
  rw [heq]
  exact (ContinuousMultilinearMap.norm_compContinuousLinearMap_le _ _).trans
    (mul_le_mul_of_nonneg_left (by simpa using pow_le_pow_left₀ (norm_nonneg g) hg m) (norm_nonneg _))

/-- Nearby normal-coordinate fibers are close in every derivative order on
the common chart, with the explicit next-derivative constant. -/
theorem tubular_fiber_jet_distance_bound {d n k : ℕ}
    (e : Ambient d ≃L[ℝ] (ℝ × ℝ) × Ambient k)
    (φ : Ambient d → Ambient n) {r M L : ℝ} (hM : 0 ≤ M) (hL : 0 ≤ L)
    (hei : ‖e.symm.toContinuousLinearMap‖ ≤ L) (m : ℕ)
    (hφ : ∀ x ∈ closedBall (0 : Ambient d) r, ContDiffAt ℝ (⊤ : ℕ∞) φ x)
    (hD : ∀ x ∈ closedBall (0 : Ambient d) r, ‖iteratedFDeriv ℝ (m + 1) φ x‖ ≤ M)
    (u w : ℝ × ℝ) (v : Ambient k)
    (hu : e.symm (u, v) ∈ closedBall (0 : Ambient d) r)
    (hw : e.symm (w, v) ∈ closedBall (0 : Ambient d) r) :
    ‖iteratedFDeriv ℝ m (fun t => φ (e.symm (u, t))) v -
      iteratedFDeriv ℝ m (fun t => φ (e.symm (w, t))) v‖ ≤
      M * L ^ (m + 1) * dist u w := by
  let g := e.symm.toContinuousLinearMap.comp (ContinuousLinearMap.inr ℝ (ℝ × ℝ) (Ambient k))
  have hg : ‖g‖ ≤ L := by
    apply ContinuousLinearMap.opNorm_le_bound _ hL
    intro t
    simpa [g] using e.symm.toContinuousLinearMap.le_of_opNorm_le hei (0, t)
  have hpoint : ∀ a t, e.symm (a, 0) + g t = e.symm (a, t) := by
    intro a t
    change e.symm (a, 0) + e.symm (0, t) = _
    rw [← map_add]
    simp
  have hh := affine_slice_jet_difference g hg (e.symm (u, 0)) (e.symm (w, 0)) v m
    (by simpa only [hpoint] using hφ _ hu) (by simpa only [hpoint] using hφ _ hw)
  simp only [hpoint] at hh
  have hd := iteratedFDeriv_distance_bound m hφ hD hu hw
  have he : ‖e.symm (u, v) - e.symm (w, v)‖ ≤ L * ‖u - w‖ := by
    rw [← map_sub]
    have hh := e.symm.toContinuousLinearMap.le_of_opNorm_le hei ((u, v) - (w, v))
    have hn : ‖((u, v) - (w, v))‖ = ‖u - w‖ := by
      change max ‖u - w‖ ‖v - v‖ = ‖u - w‖
      rw [sub_self, norm_zero, max_eq_left (norm_nonneg _)]
    simpa only [hn] using hh
  calc
    _ ≤ (M * ‖e.symm (u, v) - e.symm (w, v)‖) * L ^ m :=
      hh.trans (mul_le_mul_of_nonneg_right hd (pow_nonneg hL m))
    _ ≤ (M * (L * ‖u - w‖)) * L ^ m :=
      mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left he hM) (pow_nonneg hL m)
    _ = M * L ^ (m + 1) * dist u w := by rw [dist_eq_norm, pow_succ]; ring

/-- The strip residual controls all thin-fiber jets relative to the interior
zero reference, using the same compact-to-smooth domain margin. -/
theorem tubular_zero_reference_jet_bound {d n k : ℕ}
    (e : Ambient d ≃L[ℝ] (ℝ × ℝ) × Ambient k)
    (φ : Ambient d → Ambient n) {r ρ M L δ : ℝ} (hM : 0 ≤ M) (hL : 0 ≤ L)
    (hei : ‖e.symm.toContinuousLinearMap‖ ≤ L) (m : ℕ)
    (hφ : ∀ x ∈ closedBall (0 : Ambient d) r, ContDiffAt ℝ (⊤ : ℕ∞) φ x)
    (hD : ∀ x ∈ closedBall (0 : Ambient d) r, ‖iteratedFDeriv ℝ (m + 1) φ x‖ ≤ M)
    (a : ℝ × ℝ) (t : Ambient d) (hρ : ρ ≤ r)
    (ht : t ∈ closedBall (0 : Ambient d) ρ)
    (hs : ‖a + (e t).1‖ ≤ δ) (hm : L * δ < r - ρ) :
    ‖iteratedFDeriv ℝ m (fun w => φ (e.symm ((e t).1, w))) (e t).2 -
      iteratedFDeriv ℝ m (fun w => φ (e.symm (-a, w))) (e t).2‖ ≤
      M * L ^ (m + 1) * δ := by
  have hz := normalReference_mem_ball e a hL hei ht hs hm
  have hu : e.symm ((e t).1, (e t).2) ∈ closedBall (0 : Ambient d) r := by
    simpa only [e.symm_apply_apply] using closedBall_subset_closedBall hρ ht
  have hh := tubular_fiber_jet_distance_bound e φ hM hL hei m hφ hD
    (e t).1 (-a) (e t).2 hu (ball_subset_closedBall hz)
  apply hh.trans
  apply mul_le_mul_of_nonneg_left _ (mul_nonneg hM (pow_nonneg hL _))
  simpa only [dist_eq_norm, sub_neg_eq_add, add_comm] using hs

end N2Restriction

#print axioms N2Restriction.affine_slice_jet_difference
#print axioms N2Restriction.iteratedFDeriv_distance_bound
#print axioms N2Restriction.tubular_fiber_jet_distance_bound
#print axioms N2Restriction.tubular_zero_reference_jet_bound
