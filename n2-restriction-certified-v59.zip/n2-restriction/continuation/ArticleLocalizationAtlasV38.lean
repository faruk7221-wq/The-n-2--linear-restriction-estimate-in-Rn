import continuation.UniformDistanceAtlasV30
import continuation.UniformCardinalityAssemblyV28
import N2Restriction.SurfaceMeasure

set_option maxHeartbeats 1600000
set_option synthInstance.maxHeartbeats 100000

namespace N2Restriction
open MeasureTheory Metric Set
open scoped NNReal ENNReal BigOperators

/-- The planes admitted by the quantitative implicit-function construction.
This is a geometric condition, not a restriction estimate. -/
def ArticleFrame {k : ℕ} (S : Fin k → SmoothPatch (k+2)) (κ : ℝ) :=
  {q : Ambient (k+2) × Ambient (k+2) // q ∈ orthonormalPairSet (k+2) ∧
    (∀ i x, x ∈ (S i).support →
      (pairFrameMap q, x) ∈ frameFrequencyAdmissibleImage (S i) κ) ∧
    ∀ z : Fin k → Ambient (k+2), (∀ i, z i ∈ (S i).support) → ∀ i,
      ‖(commonTangent (fun j => (S j).normal (z j))).starProjection - pairProjection q‖ *
        ‖(S i).shape (z i)‖ ≤ κ/2}

/-- A uniformly finite atlas and its genuine zero-level reference sets.
Only the geometric data used by Corollary 4.3 are retained. Analytic bounds
are deliberately not fields of this structure. -/
structure ArticleLocalizationAtlas {k : ℕ} (S : Fin k → SmoothPatch (k+2)) (κ : ℝ) where
  count : ℕ
  charts : Fin k → ℕ
  count_bound : ∀ i, charts i ≤ count
  threshold : ℝ
  threshold_pos : 0 < threshold
  distanceCost : ℝ≥0
  distanceCost_pos : 0 < distanceCost
  carrier : ArticleFrame S κ → ∀ i, Fin (charts i) → Set (Ambient (k+2))
  target : ArticleFrame S κ → ∀ i, Fin (charts i) → Set (Ambient (k+2))
  compact_carrier : ∀ q i j, IsCompact (carrier q i j)
  covers : ∀ q i, (S i).support ⊆ ⋃ j, carrier q i j
  zero_target : ∀ q i j y, y ∈ target q i j →
    y ∈ (S i).extendedSurface ∧ thinConstraint (S i) (pairPlane q.val) y = 0
  localizes : ∀ q i j x, x ∈ carrier q i j →
    ‖pairFrameMap q.val ((S i).normal x)‖ ≤ threshold →
    ∃ y ∈ target q i j,
      dist x y ≤ (distanceCost : ℝ) * ‖pairFrameMap q.val ((S i).normal x)‖

/-- Construction of a uniform geometric atlas on the actual surfaces.
The count, threshold and displacement constant precede the plane. -/
theorem exists_article_localization_atlas {k : ℕ} (hk : 0 < k)
    (S : Fin k → SmoothPatch (k+2)) {κ : ℝ} (hκ : 0 < κ) :
    Nonempty (ArticleLocalizationAtlas S κ) := by
  classical
  obtain ⟨η, hη, M, δ, r, ρ, hδ, hρ, hρr, B, hB, c, C, hc,
    L, α, β, τ, D, hL, hα, hβ, hτ, hD, N, m, z, hm, hz, hatlas⟩ :=
    uniform_distance_ready_atlases hk S hκ
  have ha : ∀ (q : ArticleFrame S κ) (i : Fin k),
      ∃ F : ∀ j, MeasuredTubularChart (S i) (pairFrameMap q.val) (z i j)
          δ r ρ (η / 2) B c C L,
      ∃ E : ∀ j, ChartNormalCoordinates (F j) α β,
        (S i).support ⊆ ⋃ j, (F j).carrier ∧
        ∀ j, LipschitzOnWith M (S i).normal (closedBall (z i j) η) ∧
          (∀ y ∈ (E j).zeroTarget τ, y ∈ (S i).extendedSurface ∧
            thinConstraint (S i) (pairPlane q.val) y = 0 ∧ dist y (z i j) ≤ η) ∧
          (∀ x ∈ (F j).carrier, ‖pairFrameMap q.val ((S i).normal x)‖ ≤ τ →
            ∃ y ∈ (E j).zeroTarget τ,
              dist x y ≤ D * ‖pairFrameMap q.val ((S i).normal x)‖) := by
    intro q i
    exact hatlas i q.val q.property.1 (fun j => q.property.2.1 i _ (hz i j))
  choose F E hcover hproperties using ha
  refine ⟨{
    count := N, charts := m, count_bound := hm,
    threshold := τ, threshold_pos := hτ,
    distanceCost := ⟨D, hD.le⟩, distanceCost_pos := hD,
    carrier := fun q i j => (F q i j).carrier,
    target := fun q i j => (E q i j).zeroTarget τ,
    compact_carrier := ?_, covers := hcover,
    zero_target := ?_, localizes := ?_ }⟩
  · intro q i j
    exact (F q i j).compact_carrier hρr.le
  · intro q i j y hy
    exact ⟨((hproperties q i j).2.1 y hy).1, ((hproperties q i j).2.1 y hy).2.1⟩
  · intro q i j x hx hs
    exact (hproperties q i j).2.2 x hx hs

end N2Restriction

#print axioms N2Restriction.exists_article_localization_atlas
