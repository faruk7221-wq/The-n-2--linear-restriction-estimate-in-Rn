import continuation.IndependentCoordinateNormalsV40
import Mathlib.Analysis.Calculus.Gradient.Basic

namespace N2Restriction
open InnerProductSpace

/-- The coordinate normal used by the lifting field is the actual gradient
of the corresponding scalar defining function. -/
theorem defining_coordinate_gradient {E : Type*} {m : ℕ}
    [NormedAddCommGroup E] [InnerProductSpace ℝ E] [FiniteDimensional ℝ E]
    (q : E → Ambient m) {x : E} (hq : DifferentiableAt ℝ q x) (i : Fin m) :
    gradient (fun y => q y i) x = (fderiv ℝ q x).adjoint (EuclideanSpace.basisFun (Fin m) ℝ i) := by
  have he : toDual ℝ E ((fderiv ℝ q x).adjoint (EuclideanSpace.basisFun (Fin m) ℝ i)) =
      (EuclideanSpace.proj i).comp (fderiv ℝ q x) := by
    ext v
    change inner ℝ ((fderiv ℝ q x).adjoint (EuclideanSpace.basisFun (Fin m) ℝ i)) v =
      (fderiv ℝ q x v) i
    rw [ContinuousLinearMap.adjoint_inner_left]
    exact EuclideanSpace.basisFun_inner (𝕜 := ℝ) (ι := Fin m) (fderiv ℝ q x v) i
  apply HasGradientAt.gradient
  rw [hasGradientAt_iff_hasFDerivAt, he]
  exact (EuclideanSpace.proj i).hasFDerivAt.comp x hq.hasFDerivAt

/-- The article's independent-gradient condition supplies the surjective
differential premise used by the geometric lifting theorem. -/
theorem defining_map_regular_of_gradients {E : Type*} {m : ℕ}
    [NormedAddCommGroup E] [InnerProductSpace ℝ E] [FiniteDimensional ℝ E]
    (q : E → Ambient m) {x : E} (hq : DifferentiableAt ℝ q x)
    (hgrad : LinearIndependent ℝ (fun i : Fin m => gradient (fun y => q y i) x)) :
    Function.Surjective (fderiv ℝ q x) := by
  apply surjective_of_independent_coordinate_normals
  simpa only [defining_coordinate_gradient q hq] using hgrad

end N2Restriction
#print axioms N2Restriction.defining_coordinate_gradient
#print axioms N2Restriction.defining_map_regular_of_gradients
