import continuation.SubspaceKakeyaNeighborhoodV36
import continuation.GeometricNormalizedBoundV24

namespace N2Restriction
open Metric
open scoped ENNReal BigOperators

/-- One radius, aperture and finite coefficient work for all supported tuples,
all admissible nearby frames, all selected indices and every moved tuple in
the surface buffer. The mixed normal subspace is the actual supplied plane. -/
theorem geometric_buffered_normal_subspace_kakeya {n : ℕ}
    (S : Fin (n+2) → SmoothPatch (n+4)) {ν κ : ℝ}
    (hgeo : GeometricHypotheses S ν κ) (η : ℝ) (hη : 0 < η) :
    ∃ ρ ε : ℝ, 0 < ρ ∧ 0 < ε ∧ ∃ K : ℝ≥0∞, 0 < K ∧ K ≠ ⊤ ∧
      ∀ z : Fin (n+2) → Ambient (n+4), (∀ j, z j ∈ (S j).support) →
      ∀ i q, q ∈ nearbyWedgeFrameSet S z i κ →
      ∀ y : Fin (n+2) → Ambient (n+4),
        (∀ j, y j ∈ (S j).extendedSurface ∧ dist (y j) (z j) ≤ ρ) →
      ∀ (N : Submodule ℝ (Ambient (n+4))) (_b : OrthonormalBasis (Fin 3) ℝ N),
        (S i).normal (y i) ∈ N → (S i).shape (y i) q.1 ∈ N → (S i).shape (y i) q.2 ∈ N →
        ∃ r : Fin (n+1) ≃ {j : Fin (n+2) // j ≠ i},
          SubspaceKakeyaNeighborhood (actualNormalSubspaces S y i N r) ε (1/((n:ℝ)+1)) η K := by
  classical
  obtain ⟨ρ,c,hρ,hc,hw⟩ := geometric_buffered_wedge_stability (by omega : 0 < n+2) S hgeo
  obtain ⟨σ,hσ,L,hL,_,hin,hbuf⟩ := uniform_compact_surface_buffers S
  choose M hM hMb using fun i => (S i).shape_bound_on_compact (hL i)
    (fun z hz => (hin i hz).1)
  choose K hK hKfin ε hε hb using fun i =>
    uniform_actual_normal_subspace_neighborhood i (M i) c (hM i) hc η hη
  have hne : (Finset.univ : Finset (Fin (n+2))).Nonempty := ⟨0, Finset.mem_univ _⟩
  let ε₀ := Finset.univ.inf' hne ε
  let K₀ := ∑ i, K i
  have hε₀ : 0 < ε₀ := (Finset.lt_inf'_iff _).mpr (fun i _ => hε i)
  have hKle (i : Fin (n+2)) : K i ≤ K₀ := Finset.single_le_sum (fun _ _ => zero_le _) (Finset.mem_univ i)
  have hK₀ : 0 < K₀ := (hK 0).trans_le (hKle 0)
  have hK₀fin : K₀ ≠ ⊤ := by
    exact ne_of_lt (ENNReal.sum_lt_top.mpr (fun i _ => lt_top_iff_ne_top.mpr (hKfin i)))
  refine ⟨min ρ σ, ε₀, lt_min hρ hσ, hε₀, K₀, hK₀, hK₀fin, ?_⟩
  intro z hz i q hq y hy N b hN hA₁ hA₂
  have hyL : y i ∈ L i := hbuf i (z i) (hz i) (y i) (hy i).1
    ((hy i).2.trans (min_le_right ρ σ))
  obtain ⟨r,hr⟩ := hb i S y q N b (fun j => (S j).normal_unit (y j) (hy j).1.1)
    (hMb i _ hyL) hq.1.1.le hq.1.2.1.le hN hA₁ hA₂
    (hw z hz i q hq y (fun j => ⟨(hy j).1, (hy j).2.trans (min_le_left ρ σ)⟩))
  exact ⟨r,hr.mono (Finset.inf'_le _ (Finset.mem_univ i)) (hKle i)⟩

/-- The buffered estimate applies to the normal space of an actual injective
thin level-set parametrization, with no normal-basis or membership hypotheses. -/
theorem geometric_moved_chart_subspace_kakeya {n : ℕ}
    (S : Fin (n+2) → SmoothPatch (n+4)) {ν κ : ℝ}
    (hgeo : GeometricHypotheses S ν κ) (η : ℝ) (hη : 0 < η) :
    ∃ ρ ε : ℝ, 0 < ρ ∧ 0 < ε ∧ ∃ K : ℝ≥0∞, 0 < K ∧ K ≠ ⊤ ∧
      ∀ z : Fin (n+2) → Ambient (n+4), (∀ j, z j ∈ (S j).support) →
      ∀ i q, q ∈ nearbyWedgeFrameSet S z i κ →
      ∀ y : Fin (n+2) → Ambient (n+4),
        (∀ j, y j ∈ (S j).extendedSurface ∧ dist (y j) (z j) ≤ ρ) →
      ∀ H : Submodule ℝ (Ambient (n+4)), pairPlane q = H →
        H.orthogonalProjection ((S i).normal (y i)) = 0 →
      ∀ (φ : Ambient (n+4-3) → Ambient (n+4)) (t : Ambient (n+4-3)),
        φ t = y i → DifferentiableAt ℝ φ t → Function.Injective (fderiv ℝ φ t) →
        (∀ᶠ s in nhds t, thinConstraint (S i) H (φ s) = thinConstraint (S i) H (φ t)) →
        ∃ r : Fin (n+1) ≃ {j : Fin (n+2) // j ≠ i},
          SubspaceKakeyaNeighborhood
            (actualNormalSubspaces S y i (LinearMap.range (fderiv ℝ φ t).toLinearMap)ᗮ r)
            ε (1/((n:ℝ)+1)) η K := by
  obtain ⟨ρ,ε,hρ,hε,K,hK,hKfin,hb⟩ := geometric_buffered_normal_subspace_kakeya S hgeo η hη
  refine ⟨ρ,ε,hρ,hε,K,hK,hKfin,?_⟩
  intro z hz i q hq y hy H hspan hzero φ t hφt hφ hi hlevel
  have hn := thin_parametrization_normal_dimension (by omega : 3 ≤ n+4) hi
  let b : OrthonormalBasis (Fin 3) ℝ (LinearMap.range (fderiv ℝ φ t).toLinearMap)ᗮ :=
    (stdOrthonormalBasis ℝ _).reindex (finCongr hn)
  obtain ⟨hN,hA₁,hA₂⟩ := thin_chart_normal_contains_shape_frame S y i H q hspan
    (hy i).1.1 hzero hφt hφ hlevel
  exact hb z hz i q hq y hy _ b hN hA₁ hA₂

end N2Restriction

#print axioms N2Restriction.geometric_buffered_normal_subspace_kakeya
#print axioms N2Restriction.geometric_moved_chart_subspace_kakeya
