import continuation.FiberInputReferenceV30
import continuation.ExtensionParametrizationStabilityV30

namespace N2Restriction
open MeasureTheory Metric
open scoped NNReal ENNReal

namespace StripChartAmplitude
variable {n : ℕ} {S : SmoothPatch n} {Q : Ambient n →L[ℝ] ℝ × ℝ} {z : Ambient n}
  {δ r ρ s : ℝ} {B : ℕ → ℝ} {c C : ℝ≥0} {L α β ε : ℝ}
  {F : MeasuredTubularChart S Q z δ r ρ s B c C L}
  {E : ChartNormalCoordinates F α β}
  {g : Lp ℂ 2 ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier)}

/-- Actual fiber frequencies are close to their zero-fiber reference on
essential input support, with the same thin coordinate. -/
theorem normalizedFiberInput_reference_distance (A : StripChartAmplitude F E g ε)
    (hρ : ρ ≤ r) (hL : 0 ≤ L + 1) (hB : ∀ m, 0 ≤ B m)
    (hm : (L + 1) * ε < r - ρ) (u : ℝ × ℝ) :
    ∀ᵐ v ∂volume, A.normalizedFiberInput u v ≠ 0 →
      dist (F.param (E.equiv.symm (u, v))) (F.param (E.equiv.symm (-Q (S.normal z), v))) ≤
        B 1 * (L + 1) * ε := by
  filter_upwards [A.normalizedFiberInput_reference_jets hρ hL hB hm u] with v hv hn
  have hh := hv hn 0
  simpa only [iteratedFDeriv_zero_eq_comp, Function.comp_apply, ← map_sub,
    LinearIsometryEquiv.norm_map, zero_add, pow_one, dist_eq_norm] using hh

/-- The actual input-supported phase is uniformly close to its zero-fiber
phase on every bounded physical ball. No quasi-Banach integration is used. -/
theorem normalizedFiberInput_phase_difference (A : StripChartAmplitude F E g ε)
    (hρ : ρ ≤ r) (hL : 0 ≤ L + 1) (hB : ∀ m, 0 ≤ B m)
    (hm : (L + 1) * ε < r - ρ) (u : ℝ × ℝ) (x : Ambient n) :
    ∀ᵐ v ∂volume, A.normalizedFiberInput u v ≠ 0 →
      ‖Complex.exp ((inner ℝ x (F.param (E.equiv.symm (u, v))) : ℂ) * Complex.I) -
        Complex.exp ((inner ℝ x (F.param (E.equiv.symm (-Q (S.normal z), v))) : ℂ) * Complex.I)‖ ≤
        2 * ‖x‖ * (B 1 * (L + 1) * ε) := by
  filter_upwards [A.normalizedFiberInput_reference_distance hρ hL hB hm u] with v hv hn
  exact (extension_phase_difference_bound x _ _).trans
    (mul_le_mul_of_nonneg_left (hv hn) (by positivity))

end StripChartAmplitude
end N2Restriction

#print axioms N2Restriction.StripChartAmplitude.normalizedFiberInput_phase_difference
#print axioms N2Restriction.StripChartAmplitude.normalizedFiberInput_reference_distance
