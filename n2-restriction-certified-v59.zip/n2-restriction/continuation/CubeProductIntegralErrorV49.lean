import continuation.RegionProductErrorV49
import continuation.GridCubeMonotoneV49
import continuation.QuasiBanachProductErrorV49

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal

/-- Cube localization of every original selected product, including its
integrated rapid error. All constants precede the cube and stage selection. -/
theorem cube_product_integral_error {d k : ℕ}
    (S : Fin k → SmoothPatch (d+1)) (A : (i : Fin k) → PacketGraphAtlas (S i))
    {τ : ℝ} (hτ : 0 < τ) :
    ∃ M : ℝ, 1 ≤ M ∧ ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ N : ℝ, ∃ C : ℝ, 0 ≤ C ∧
    ∀ R : ℝ, R₀ ≤ R →
    ∀ (Q : (i : Fin k) → (j : Fin (A i).size) →
      CoordinateCapFamily ((A i).patch j).support (R^(-1/2 : ℝ)))
      (hr : 0 < R^(-1/2 : ℝ)), (∀ i, R^(-1/2 : ℝ) ≤ (A i).capRadius) →
    ∀ B : ℝ, 0 ≤ B → (∀ i j, ((Q i j).centers.card : ℝ) ≤ B*R^((d : ℝ)/2)) →
    ∀ (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure)
      (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure),
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
    ∀ (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin d → ℤ))
      (E : Set (Ambient (d+1))) (q : Ambient (d+1)) (b D p : ℝ),
    0 ≤ b → 1 ≤ D → 0 < p → p ≤ 1 → MeasurableSet E → E ⊆ gridCube q b ∩ closedBall 0 R →
    (∫⁻ x in E, ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
      (fun i => (A i).cellInput (Q i) hr (f i) (U i)) x‖ₑ^p) ≤
    (∫⁻ x in E, ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
      (fun i => (A i).cellInput (Q i) hr (f i) (fun j a => U i j a ∩
        {ν | ((A i).originalPacketTube j a (R^(-1/2 : ℝ)) ν R (R^(1/2+τ)/10) ∩
          gridCube q (D*b)).Nonempty})) x‖ₑ^p) +
      (ENNReal.ofReal ((k : ℝ)*(C*Real.sqrt B*R^(-N))*M^k*∏ i, ‖g i‖))^p*volume E := by
  obtain ⟨M,hM,R₀,hR₀,htail⟩ := region_selected_product_error S A hτ
  refine ⟨M,hM,R₀,hR₀,fun N => ?_⟩
  obtain ⟨C,hC,hc⟩ := htail N
  refine ⟨C,hC,?_⟩
  intro R hR Q hr hsmall B hB hcount g f he U E q b D p hb hD hp hp1 hEmeas hE
  apply integral_power_le_of_difference volume E hEmeas _ _ hp hp1
  · exact (continuous_finset_prod _ (fun i _ => continuous_extension measurable_id
      ((A i).cellInput_integrable (Q i) hr (hsmall i) (f i) _))).measurable
  intro x hx
  exact hc R hR Q hr hsmall B hB hcount g f he U (gridCube q (D*b)) x
    (by simpa only [mem_closedBall,dist_zero_right] using (hE hx).2)
    (gridCube_subset_dilate q hb hD (hE hx).1)

end N2Restriction
#print axioms N2Restriction.cube_product_integral_error
