import continuation.AtlasOriginalChildMarginV44
import continuation.HalfBallCoverV42

namespace N2Restriction
open MeasureTheory Set
open scoped BigOperators ENNReal

/-- The actual local estimate with an explicit inherited margin, on any chosen
frequency domains. The finite buffer is only used for measure and norm transfer. -/
theorem atlas_cell_admissible_power_bound {d k : ℕ} (S : Fin k → SmoothPatch (d+1))
    (T : (i : Fin k) → PacketGraphAtlas (S i)) {r : ℝ} (hr : 0 < r)
    (Q : (i : Fin k) → (j : Fin (T i).size) → CoordinateCapFamily ((T i).patch j).support r)
    (hsmall : ∀ i, r ≤ (T i).capRadius)
    (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure)
    (U : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ))
    (V : Fin k → Set (Ambient (d+1)))
    {m L p : ℝ}
    (hadm : MarginAdmissible (fun i => (T i).bufferMeasure) (fun _ => id) V m L
      (fun i => (T i).bufferInput ((T i).cellInput (Q i) hr (f i) (U i))))
    (hp : 0 < p)
    (x₀ : Ambient (d+1)) :
    (∫⁻ x in Metric.ball x₀ L,
      ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
        (fun i => (T i).cellInput (Q i) hr (f i) (U i)) x‖ₑ ^ p) ≤
      (marginLocalConstant (fun i => (T i).bufferMeasure) (fun _ => id)
        V m p L *
          ∏ i, ENNReal.ofReal (‖(T i).cellInput (Q i) hr (f i) (U i)‖))^p := by
  let u := fun i => (T i).bufferInput ((T i).cellInput (Q i) hr (f i) (U i))
  have hn i : eLpNorm (u i) 2 (T i).bufferMeasure =
      ENNReal.ofReal (‖(T i).cellInput (Q i) hr (f i) (U i)‖) := by
    rw [← Lp.enorm_def, ← ofReal_norm]
    exact congrArg ENNReal.ofReal ((T i).bufferInput_cell_norm (Q i) hr (hsmall i) (f i) (U i))
  have he x : extensionProduct (fun i => (T i).bufferMeasure) (fun _ => id) (fun i => u i) x =
      extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
        (fun i => (T i).cellInput (Q i) hr (f i) (U i)) x := by
    unfold extensionProduct
    apply Finset.prod_congr rfl
    intro i _
    exact (T i).bufferInput_cell_extension (Q i) hr (hsmall i) (f i) (U i) x
  have h := ENNReal.rpow_le_rpow (marginLocalConstant_spec (fun i => (T i).bufferMeasure)
    (fun _ => id) V m hp x₀ (fun i => Lp.memLp (u i)) hadm) hp.le
  rw [← lintegral_rpow_enorm_eq_rpow_eLpNorm' hp] at h
  simpa only [he, inputNormProduct, hn] using h

end N2Restriction
#print axioms N2Restriction.atlas_cell_admissible_power_bound
