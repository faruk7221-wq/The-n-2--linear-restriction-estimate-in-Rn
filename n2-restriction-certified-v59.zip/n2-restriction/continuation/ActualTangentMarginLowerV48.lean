import continuation.ActualTangentLowerV48
import continuation.SelectedSamePatchSupportV48

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal

/-- Equation (7.9) with selected support discharged from the original parent
margin. Every ball and angular subset uses the same initial packet family. -/
theorem eventually_actualTangentSum_lower_bound {d k : ℕ} (hk : 0 < k)
    (S : Fin k → SmoothPatch (d+1)) (A : (i : Fin k) → PacketGraphAtlas (S i))
    (V : Fin k → Set (Ambient (d+1))) (m : ℝ)
    (hS : ∀ i, (S i).extendedSurface ∩ V i ⊆ (S i).support)
    {θ : ℝ} (hθ : 0 < θ) :
    ∃ D : ENNReal, D ≠ ∞ ∧ ∀ᶠ R : ℝ in Filter.atTop,
    ∀ ρ : ℝ, 1 ≤ ρ → ρ ≤ R/2 → 0 < m-ρ^(-1/4 : ℝ) →
    ∀ (Q : (i : Fin k) → (j : Fin (A i).size) → CoordinateCapFamily ((A i).patch j).support (R^(-1/2 : ℝ)))
    (hr : 0 < R^(-1/2 : ℝ)), (∀ i, R^(-1/2 : ℝ) ≤ (A i).capRadius) →
    ∀ (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure)
    (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure),
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
    (∀ i j, HasFrequencySupport ((A i).graph j).surfaceMeasure ((A i).patch j).rotation
      (marginRegion (V i) (m-R^(-1/4 : ℝ))) (f i j)) →
    ∀ {L : ℕ} (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin d → ℤ))
    (Z : Set (Ambient (d+1))) (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1)))
    (c : Fin L → Ambient (d+1)) (b C₀ w : ℝ) (Ω : Set (Ambient (d+1))),
    w ≤ ρ →
    (∀ l t, l ≠ t → 2*(θ*ρ) ≤ dist (c l) (c t)) →
    positiveNorm (actualTangentSum A Q hr f U Z T c ρ b C₀ R w Ω) (2/(k : ℝ)) volume ≤
      D*(ENNReal.ofReal R)^((k : ℝ)/2)*∏ i, ENNReal.ofReal ‖g i‖ := by
  obtain ⟨D,hD,hbound⟩ := actualTangentSum_lower_bound hk S A hθ
  refine ⟨D,hD,?_⟩
  filter_upwards [eventually_atlas_same_patch_support S A V m hS] with R hsupport
  intro ρ hρ hρR hm Q hr hsmall g f he hf L U Z T c b C₀ w Ω hw hsep
  have hρ0 : 0 < ρ := zero_lt_one.trans_le hρ
  have hR : 0 ≤ R := by linarith
  apply hbound Q hr hsmall g f he U Z T c ρ b C₀ R w Ω hR hρ0 (by linarith) hw hsep
  intro i ls
  exact hsupport ρ hρ hρR hm Q hr hsmall f hf
    (fun j => if ls.2 then (A j).actualTangentSelection (Q j) (U j) Z T (c ls.1) ρ b C₀ R w Ω
      else (A j).actualNontangentSelection (Q j) (U j) Z T (c ls.1) ρ b C₀ R w Ω) i

end N2Restriction
#print axioms N2Restriction.eventually_actualTangentSum_lower_bound
