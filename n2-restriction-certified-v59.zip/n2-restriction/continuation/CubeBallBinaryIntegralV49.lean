import continuation.PositiveLocalizedSumV47
import continuation.PositiveBallOverlapV48
import continuation.CubeBallOverlapV47

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal

/-- Sum localized quasi-Banach estimates over balls and nonzero binary
choices on one cube. Only the bounded number of balls meeting that cube is
charged; the total number of covering balls does not appear. -/
theorem cube_ball_binary_integral {n k L : ℕ} {ρ θ b p : ℝ}
    (hρ : 0 < ρ) (hθ : 0 < θ) (hb : 0 ≤ b) (hbρ : b ≤ ρ)
    (hp : 0 < p) (hp1 : p ≤ 1) (q : Ambient n) (c : Fin L → Ambient n)
    (hsep : ∀ l t, l ≠ t → 2*(θ*ρ) ≤ dist (c l) (c t))
    (Ω : Set (Ambient n)) (hΩ : MeasurableSet Ω)
    (G : Fin L → (Fin k → Bool) → Ambient n → ENNReal)
    (hG : ∀ l σ, Measurable (G l σ)) (K : ENNReal)
    (hlocal : ∀ l σ, σ ∈ (Finset.univ : Finset (Fin k → Bool)).erase (fun _ => false) →
      (gridCube q b ∩ ball (c l) ρ).Nonempty →
      (∫⁻ x in (Ω ∩ ball (c l) ρ) ∩ gridCube q b, (G l σ x)^p) ≤ K) :
    (∫⁻ x in gridCube q b,
      (∑ l, (Ω ∩ ball (c l) ρ).indicator (fun y =>
        ∑ σ ∈ (Finset.univ : Finset (Fin k → Bool)).erase (fun _ => false), G l σ y) x)^p) ≤
      ENNReal.ofReal (((1+Real.sqrt n/2)/θ+1)^n)*((2^k : ENNReal)*K) := by
  classical
  let J := (Finset.univ : Finset (Fin k → Bool)).erase (fun _ => false)
  have hU l : MeasurableSet (Ω ∩ ball (c l) ρ) := hΩ.inter isOpen_ball.measurableSet
  have hsum l : Measurable (fun x => ∑ σ ∈ J, G l σ x) :=
    Finset.measurable_sum _ (fun σ _ => hG l σ)
  have hh := localized_positive_sum_integral (volume.restrict (gridCube q b))
    (fun l => Ω ∩ ball (c l) ρ) hU (fun l x => ∑ σ ∈ J, G l σ x) hsum hp hp1
  have hl l : (∫⁻ x in Ω ∩ ball (c l) ρ, (∑ σ ∈ J, G l σ x)^p
      ∂(volume.restrict (gridCube q b))) ≤
      if (gridCube q b ∩ ball (c l) ρ).Nonempty then (2^k : ENNReal)*K else 0 := by
    rw [Measure.restrict_restrict (hU l)]
    by_cases hm : (gridCube q b ∩ ball (c l) ρ).Nonempty
    · rw [if_pos hm]
      calc
        _ ≤ ∫⁻ x in (Ω ∩ ball (c l) ρ) ∩ gridCube q b, ∑ σ ∈ J, (G l σ x)^p :=
          lintegral_mono (fun x => positive_sum_rpow_le J _ hp hp1)
        _ = ∑ σ ∈ J, ∫⁻ x in (Ω ∩ ball (c l) ρ) ∩ gridCube q b, (G l σ x)^p :=
          lintegral_finset_sum _ (fun σ _ => (hG l σ).pow_const p)
        _ ≤ ∑ _σ ∈ J, K := Finset.sum_le_sum (fun σ hσ => hlocal l σ hσ hm)
        _ ≤ _ := binary_nonzero_sum_bound (fun _ => K) K (fun _ => le_rfl)
    · have he : (Ω ∩ ball (c l) ρ) ∩ gridCube q b = ∅ := by
        apply eq_empty_iff_forall_notMem.mpr
        intro x hx
        exact hm ⟨x,hx.2,hx.1.2⟩
      simp [he,hm]
  have hc : (Fintype.card {l : Fin L // (gridCube q b ∩ ball (c l) ρ).Nonempty} : ENNReal) ≤
      ENNReal.ofReal (((1+Real.sqrt n/2)/θ+1)^n) := by
    simpa only [ENNReal.ofReal_natCast] using ENNReal.ofReal_le_ofReal
      (cube_meeting_balls_card hρ hθ hb hbρ c hsep q)
  have he : (∑ l, if (gridCube q b ∩ ball (c l) ρ).Nonempty then (2^k : ENNReal)*K else 0) =
      (Fintype.card {l : Fin L // (gridCube q b ∩ ball (c l) ρ).Nonempty} : ENNReal)*((2^k : ENNReal)*K) := by
    simp [Fintype.card_subtype,Finset.sum_ite]
  exact hh.trans ((Finset.sum_le_sum (fun l _ => hl l)).trans
    (he.trans_le (mul_le_mul_right' hc _)))

end N2Restriction
#print axioms N2Restriction.cube_ball_binary_integral
