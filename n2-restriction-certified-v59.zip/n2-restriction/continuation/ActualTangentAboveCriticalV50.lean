import continuation.ActualTangentCriticalV50
import continuation.PositiveNormRaiseV50
import continuation.ActualTangentInfinityV48
namespace N2Restriction
open MeasureTheory Set Metric Filter
open scoped ENNReal NNReal

/-- The above-critical part of (7.12), for the same actual Ftan. The bound
holds for every p>pc, including the article range pc<p<q0, with fixed sigma. -/
theorem actualTangentSum_above_critical_bound {k : ℕ} (hk : 3 ≤ k)
    (P : Fin k → SmoothPatch (k+2)) {ι : ℝ}
    (Dsub : ∀ i, DirectionalSubdivision (P i) ι) (a : ∀ i, Fin (Dsub i).size) (A : (i : Fin k) → PacketGraphAtlas ((fun i => (Dsub i).piece (a i)) i))
    {κ : ℝ} (B : ArticleLocalizationAtlas (fun i => (Dsub i).piece (a i)) κ)
    (V : Fin k → Set (Ambient (k+2))) (m : ℝ)
    (hS : ∀ i, ((fun i => (Dsub i).piece (a i)) i).extendedSurface ∩ V i ⊆ ((fun i => (Dsub i).piece (a i)) i).support) (hm : 0 < m)
    {ε τ lam : ℝ} (hε : 0 < ε)
    (hexternal : B.UniformLocalizedInput (baseline (k : ℝ))) (hτ : 0 < τ) (hτ' : τ < 1/4) (hlam : 1 ≤ lam)
    (C C₀ θ Cext Bcap : ℝ)
    (hC : 1 ≤ C) (hC₀ : 1+Real.sqrt (k+2 : ℕ)*(1+C)/2 ≤ C₀)
    (hθ : 0 < θ) (hBcap : 0 ≤ Bcap)
    (hKak : ∀ r w : ℝ, 1 ≤ w → w < r →
      FiniteDirectionalKakeya (volume.restrict (ball 0 r))
        (fun i => (P i).normal ((Dsub i).anchor (a i))) ι w (1/((k : ℝ)-1))
        (ENNReal.ofReal (Cext*r^(ε*(baseline (k : ℝ)))*w^((k+2 : ℕ)-ε*(baseline (k : ℝ)))))) :
    ∀ p : ℝ, critical (k : ℝ) < p →
    ∃ K : ENNReal, K ≠ ∞ ∧ ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ R : ℝ, R₀ ≤ R →
    ∀ (Q : (i : Fin k) → (j : Fin (A i).size) →
      CoordinateCapFamily ((A i).patch j).support (R^(-1/2 : ℝ)))
      (hr : 0 < R^(-1/2 : ℝ)), (∀ i, R^(-1/2 : ℝ) ≤ (A i).capRadius) →
    (∀ i j, ((Q i j).centers.card : ℝ) ≤ Bcap*R^(((k+1 : ℕ) : ℝ)/2)) →
    ∀ (g : (i : Fin k) → Lp ℂ 2 ((fun i => (Dsub i).piece (a i)) i).surfaceMeasure)
      (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure),
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
    (∀ i j, HasFrequencySupport ((A i).graph j).surfaceMeasure ((A i).patch j).rotation
      (marginRegion (V i) (m-R^(-1/4 : ℝ))) (f i j)) →
    ∀ (L : ℕ) (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin (k+1) → ℤ))
      (Z : Set (Ambient (k+2))) (T : Ambient (k+2) → Submodule ℝ (Ambient (k+2)))
      (c : Fin L → Ambient (k+2)) (Ω : Set (Ambient (k+2))),
    (∀ l t, l ≠ t → 2*(θ*(R^(1-τ))) ≤ dist (c l) (c t)) →
    MeasurableSet Ω → Ω ⊆ closedBall 0 R →
    (∀ (zgrid : meetingGrid (n := k+2) (lam*R^(1/2+τ)) R) (l : Fin L), ((Ω ∩ ball (c l) (R^(1-τ))) ∩ gridCube (gridCentre (lam*R^(1/2+τ)) zgrid.val) (lam*R^(1/2+τ))).Nonempty →
      HasTerminalCubeFrame (fun i => (Dsub i).piece (a i)) κ Z T (c l) (gridCentre (lam*R^(1/2+τ)) zgrid.val) (R^(1-τ)) (lam*R^(1/2+τ))) →
    positiveNorm
      (actualTangentSum A Q hr f U Z T c (R^(1-τ)) (lam*R^(1/2+τ)) C₀ R (R^(1/2+τ)/10) Ω) p volume ≤
      K*ENNReal.ofReal (R^(sigma (k : ℝ) τ ε))*∏ i, ENNReal.ofReal ‖g i‖ := by
  intro p hp
  have hkR : (3 : ℝ) ≤ k := by exact_mod_cast hk
  have hk0 : (0 : ℝ) < k := by linarith
  have hq : 0 < critical (k : ℝ) := critical_pos hk0
  have hp0 : 0 < p := hq.trans hp
  obtain ⟨K,hK,R₀,hR₀,hb⟩ := actualTangentSum_critical_bound hk P Dsub a A B V m hS hm
    hε hexternal hτ hτ' hlam C C₀ θ Cext Bcap hC hC₀ hθ hBcap hKak
  obtain ⟨D,hD,hpoint⟩ := actualTangentSum_uniform_bound (fun i => (Dsub i).piece (a i)) A hθ
  have ha : 0 ≤ (p-critical (k : ℝ))/p := div_nonneg (by linarith) hp0.le
  have hbpow : 0 ≤ critical (k : ℝ)/p := div_nonneg hq.le hp0.le
  have hs : 0 ≤ sigma (k : ℝ) τ ε := by
    unfold sigma
    exact mul_nonneg (theta_range hk0).1.le (by linarith)
  refine ⟨(ENNReal.ofReal D)^((p-critical (k : ℝ))/p)*K^(critical (k : ℝ)/p),
    ENNReal.mul_ne_top (ENNReal.rpow_ne_top_of_nonneg ha ENNReal.ofReal_ne_top)
      (ENNReal.rpow_ne_top_of_nonneg hbpow hK),R₀,hR₀,?_⟩
  intro R hR Q hr hsmall hcount g f he hf L U Z T c Ω hsep hΩ hΩR hframe
  have hRone := hR₀.trans hR
  have hρ : 0 < R^(1-τ) := Real.rpow_pos_of_pos (zero_lt_one.trans_le hRone) _
  exact positive_norm_raise_normalized volume _
    (measurable_actualTangentSum A Q hr hsmall f U Z T c (R^(1-τ)) (lam*R^(1/2+τ)) C₀ R
      (R^(1/2+τ)/10) Ω hΩ).aemeasurable hq hp hRone hs K (ENNReal.ofReal D) _
    (hpoint Q hr hsmall g f he U Z T c (R^(1-τ)) (lam*R^(1/2+τ)) C₀ R (R^(1/2+τ)/10) Ω hρ hsep)
    (hb R hR Q hr hsmall hcount g f he hf L U Z T c Ω hsep hΩ hΩR hframe)

end N2Restriction
#print axioms N2Restriction.actualTangentSum_above_critical_bound
