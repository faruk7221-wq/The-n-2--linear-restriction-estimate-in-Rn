import continuation.StripCoordinateSupportV29

namespace N2Restriction
open MeasureTheory Set Metric
open scoped NNReal ENNReal

namespace StripChartAmplitude
variable {n : ℕ} {S : SmoothPatch n} {Q : Ambient n →L[ℝ] ℝ × ℝ} {z : Ambient n}
  {δ r ρ s : ℝ} {B : ℕ → ℝ} {c C : ℝ≥0} {L α β ε : ℝ}
  {F : MeasuredTubularChart S Q z δ r ρ s B c C L}
  {E : ChartNormalCoordinates F α β}
  {g : Lp ℂ 2 ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier)}

noncomputable def fiberAmplitude (A : StripChartAmplitude F E g ε) (u : ℝ × ℝ)
    (v : Ambient (n - 3)) : ℂ := A.weight (E.equiv.symm (u, v)) • A.input (E.equiv.symm (u, v))

/-- The density-multiplied coordinate amplitudes are actual L2 functions on
almost every thin fiber. -/
theorem fiber_memLp_ae (A : StripChartAmplitude F E g ε) :
    ∀ᵐ u ∂volume, MemLp (A.fiberAmplitude u) 2 volume := by
  filter_upwards [A.fiber_energy_finite] with u hu
  have hf : Measurable (A.fiberAmplitude u) := by
    have hW := A.measurable_weight
    have hF := A.measurable_input
    change Measurable (fun v => A.weight (E.equiv.symm (u, v)) • A.input (E.equiv.symm (u, v)))
    fun_prop
  refine ⟨hf.aestronglyMeasurable, ?_⟩
  apply (eLpNorm_lt_top_iff_lintegral_rpow_enorm_lt_top
    (by norm_num : (2 : ℝ≥0∞) ≠ 0) (by norm_num : (2 : ℝ≥0∞) ≠ ∞)).mpr
  simpa [fiberAmplitude] using hu

/-- Exceptional fibers are assigned zero; almost every fiber is the actual
weighted coordinate input. No joint measurable selection is asserted. -/
noncomputable def fiberInput (A : StripChartAmplitude F E g ε) (u : ℝ × ℝ) :
    Lp ℂ 2 (volume : Measure (Ambient (n - 3))) := by
  classical
  exact if h : MemLp (A.fiberAmplitude u) 2 volume then h.toLp (A.fiberAmplitude u) else 0

theorem fiberInput_coe_ae (A : StripChartAmplitude F E g ε) :
    ∀ᵐ u ∂volume, (A.fiberInput u : Ambient (n - 3) → ℂ) =ᵐ[volume] A.fiberAmplitude u := by
  filter_upwards [A.fiber_memLp_ae] with u hu
  simp only [fiberInput, dif_pos hu]
  exact MemLp.coeFn_toLp hu

/-- Every fiber outside the translated normal strip is exactly zero. -/
theorem fiberInput_zero_outside (A : StripChartAmplitude F E g ε) (u : ℝ × ℝ)
    (hu : ε < ‖Q (S.normal z) + u‖) : A.fiberInput u = 0 := by
  have hz : A.fiberAmplitude u = 0 := by
    funext v
    have hi : A.input (E.equiv.symm (u, v)) = 0 := by
      by_contra h
      exact (not_le_of_gt hu) (A.coordinate_support h).1
    simp [fiberAmplitude, hi]
  have hm : MemLp (A.fiberAmplitude u) 2 volume := by rw [hz]; simp
  apply Lp.ext
  rw [fiberInput, dif_pos hm]
  filter_upwards [MemLp.coeFn_toLp hm, Lp.coeFn_zero (E := ℂ) (p := (2 : ℝ≥0∞))
    (μ := (volume : Measure (Ambient (n - 3))))] with v hv hzero
  rw [hv, hz, hzero]

/-- The original chart extension is the Haar-normalized integral of the
extensions of the actual L2 thin-fiber inputs. -/
theorem extension_fiberInput (A : StripChartAmplitude F E g ε) (x : Ambient n) :
    extension ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier) id g x =
      (coordinateMeasureFactor E.equiv volume (volume.prod volume) : ℝ) •
        ∫ u, extension volume (fun v => F.param (E.equiv.symm (u, v))) (A.fiberInput u) x := by
  refine (A.extension_identity x).2.trans ?_
  congr 1
  apply integral_congr_ae
  filter_upwards [A.fiberInput_coe_ae] with u hu
  symm
  apply integral_congr_ae
  filter_upwards [hu] with v hv
  rw [hv]
  exact mul_smul_comm _ _ _

end StripChartAmplitude
end N2Restriction

#print axioms N2Restriction.StripChartAmplitude.extension_fiberInput
#print axioms N2Restriction.StripChartAmplitude.fiberInput_coe_ae
#print axioms N2Restriction.StripChartAmplitude.fiberInput_zero_outside
#print axioms N2Restriction.StripChartAmplitude.fiber_memLp_ae
