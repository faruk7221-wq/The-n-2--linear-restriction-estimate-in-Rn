import continuation.AtlasRelativeMarginsV44
import continuation.AtlasSupportedDecompositionV44
import continuation.AtlasBufferedInputV42

namespace N2Restriction
open MeasureTheory Set

/-- The finite-buffer representative preserves every essential support constraint. -/
theorem PacketGraphAtlas.bufferInput_frequency_support {d : ℕ} {S : SmoothPatch (d + 1)}
    (T : PacketGraphAtlas S)
    (g : Lp ℂ 2 (Measure.hausdorffMeasure (d : ℝ) : Measure (Ambient (d + 1))))
    (F : Set (Ambient (d + 1)))
    (hg : HasFrequencySupport (Measure.hausdorffMeasure (d : ℝ)) id F g) :
    HasFrequencySupport T.bufferMeasure id F (T.bufferInput g) :=
  restrictInputL2_frequency_support _ _ g id F hg

/-- Original radius-admissible inputs admit an energy-controlled atlas
decomposition whose every original-packet selection is child-admissible.
The radius threshold is independent of the input and all cap/selection choices. -/
theorem PacketGraphAtlas.eventually_original_child_adapter {d : ℕ} {S : SmoothPatch (d + 1)}
    (T : PacketGraphAtlas S) (V : Set (Ambient (d + 1))) (m : ℝ) :
    ∀ᶠ R : ℝ in Filter.atTop, ∀ g : Lp ℂ 2 S.surfaceMeasure,
      HasFrequencySupport S.surfaceMeasure id (marginRegion V (m - R ^ (-1 / 4 : ℝ))) g →
      ∃ f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure,
        (∑ j, ‖f j‖ ^ 2) ≤ ‖g‖ ^ 2 ∧
        (∀ j, HasFrequencySupport (T.graph j).surfaceMeasure id
          ((T.graph j).parametrization '' (T.patch j).support) (f j)) ∧
        (∀ x, (∑ j, extension (T.graph j).surfaceMeasure (T.patch j).rotation (f j) x) =
          extension S.surfaceMeasure id g x) ∧
        ∀ (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support (R ^ (-1 / 2 : ℝ)))
          (hr : 0 < R ^ (-1 / 2 : ℝ))
          (U : (j : Fin T.size) → (Q j).centers → Set (Fin d → ℤ))
          (L : ℝ), 1 ≤ L → L ≤ R / 2 →
          HasFrequencySupport T.bufferMeasure id (marginRegion V (m - L ^ (-1 / 4 : ℝ)))
            (T.bufferInput (T.cellInput Q hr f U)) := by
  filter_upwards [T.eventually_cellInput_child_margin V m] with R hR
  intro g hg
  obtain ⟨f, he, hs, hm, hx⟩ := T.input_decomposition_supported g _ hg
  refine ⟨f, he, hs, hx, ?_⟩
  intro Q hr U L hL hLR
  exact T.bufferInput_frequency_support _ _ (hR L hL hLR Q hr f hm U)

end N2Restriction
#print axioms N2Restriction.PacketGraphAtlas.bufferInput_frequency_support
#print axioms N2Restriction.PacketGraphAtlas.eventually_original_child_adapter
