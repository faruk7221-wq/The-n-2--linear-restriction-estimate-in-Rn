import continuation.SupportedNormalFibersV25

namespace N2Restriction
open MeasureTheory
open scoped ENNReal NNReal

/-- Multiplying an input by a bounded nonnegative density costs at most its
upper bound in squared L2 energy. Zero densities are allowed. -/
theorem bounded_density_amplitude_energy {d : ℕ}
    (J : Ambient d → ℝ≥0) (hJ : Measurable J) (C : ℝ≥0)
    (hC : ∀ᵐ x ∂volume, J x ≤ C) (F : Ambient d → ℂ) (hF : Measurable F) :
    (∫⁻ x, (‖J x • F x‖ₑ)^2) ≤ (C : ℝ≥0∞) *
      ∫⁻ x, (‖F x‖ₑ)^2 ∂volume.withDensity (fun x => (J x : ℝ≥0∞)) := by
  rw [lintegral_withDensity_eq_lintegral_mul _ hJ.coe_nnreal_ennreal (by fun_prop),
    ← lintegral_const_mul _ (by fun_prop)]
  apply lintegral_mono_ae
  filter_upwards [hC] with x hx
  have he : ‖J x • F x‖ₑ = (J x : ℝ≥0∞) * ‖F x‖ₑ := by
    change (‖(J x : ℝ) • F x‖₊ : ℝ≥0∞) = _
    rw [nnnorm_smul, ENNReal.coe_mul]
    simp [enorm_eq_nnnorm]
  rw [he, mul_pow]
  have hj : (J x : ℝ≥0∞) ≤ C := by exact_mod_cast hx
  calc
    (J x : ℝ≥0∞)^2 * ‖F x‖ₑ^2 ≤ ((C : ℝ≥0∞) * J x) * ‖F x‖ₑ^2 := by
      rw [pow_two]
      exact mul_le_mul_right' (mul_le_mul_right' hj _) _
    _ = (C : ℝ≥0∞) * ((J x : ℝ≥0∞) * ‖F x‖ₑ^2) := mul_assoc _ _ _

/-- The fiber L2 energies of the density-multiplied input have total energy
bounded by the density upper bound times the surface-coordinate energy. -/
theorem density_amplitude_fiber_energy {d k : ℕ}
    (e : Ambient d ≃L[ℝ] (ℝ × ℝ) × Ambient k)
    (J : Ambient d → ℝ≥0) (hJ : Measurable J) (C : ℝ≥0)
    (hC : ∀ᵐ x ∂volume, J x ≤ C) (F : Ambient d → ℂ) (hF : Measurable F) :
    (coordinateMeasureFactor e volume (volume.prod volume) : ℝ≥0∞) *
      (∫⁻ u, ∫⁻ v, (‖J (e.symm (u, v)) • F (e.symm (u, v))‖ₑ)^2) ≤
      (C : ℝ≥0∞) *
        ∫⁻ x, (‖F x‖ₑ)^2 ∂volume.withDensity (fun x => (J x : ℝ≥0∞)) := by
  have he := normal_fiber_energy_identity e (fun _ => 1) measurable_const
    (fun x => J x • F x) (by fun_prop)
  simp only [withDensity_const, one_smul, one_mul] at he
  rw [← he]
  exact bounded_density_amplitude_energy J hJ C hC F hF

/-- The density-weighted extension amplitude retains the thickness gain, with
the explicit density upper bound. Haar normalization is kept inside the fiber
energy; a further constant square root accounts for moving it into amplitudes. -/
theorem density_amplitude_thickness_bound {d k : ℕ}
    (R : Ambient d →L[ℝ] ℝ × ℝ)
    (e : Ambient d ≃L[ℝ] (ℝ × ℝ) × Ambient k) (he : ∀ x, (e x).1 = R x)
    (J : Ambient d → ℝ≥0) (hJ : Measurable J) (C : ℝ≥0)
    (hC : ∀ᵐ x ∂volume, J x ≤ C)
    (F : Ambient d → ℂ) (hF : Measurable F) (a : ℝ × ℝ) (r : ℝ)
    (hs : ∀ x, F x ≠ 0 → ‖a + R x‖ ≤ r) :
    (∫⁻ u, ((coordinateMeasureFactor e volume (volume.prod volume) : ℝ≥0∞) *
      ∫⁻ v, (‖J (e.symm (u, v)) • F (e.symm (u, v))‖ₑ)^2) ^ (1 / 2 : ℝ)) ≤
      ENNReal.ofReal (2 * r) * ((C : ℝ≥0∞) *
        ∫⁻ x, (‖F x‖ₑ)^2 ∂volume.withDensity (fun x => (J x : ℝ≥0∞))) ^ (1 / 2 : ℝ) := by
  have hsupport : ∀ x, J x • F x ≠ 0 → ‖a + R x‖ ≤ r := by
    intro x hx
    apply hs x
    intro hzero
    exact hx (by rw [hzero, smul_zero])
  have hh := supported_normal_fiber_thickness_bound R e he (fun _ => 1) measurable_const
    (fun x => J x • F x) (by fun_prop) a r hsupport
  simp only [withDensity_const, one_smul, one_mul] at hh
  exact hh.trans (mul_le_mul_left' (ENNReal.rpow_le_rpow
    (bounded_density_amplitude_energy J hJ C hC F hF) (by norm_num)) _)

end N2Restriction

#print axioms N2Restriction.bounded_density_amplitude_energy
#print axioms N2Restriction.density_amplitude_fiber_energy
#print axioms N2Restriction.density_amplitude_thickness_bound
