import continuation.SmoothSurfaceAmplitudeV57
import Mathlib.Analysis.Calculus.Deriv.Support
namespace N2Restriction
open Set
set_option maxHeartbeats 800000

/-- A continuous compactly supported function has an actual global norm
budget, chosen once before any oscillation parameter. -/
theorem exists_nonneg_compact_norm_bound {E F : Type*} [TopologicalSpace E]
    [NormedAddCommGroup F] (f : E → F) (hf : Continuous f) (hs : HasCompactSupport f) :
    ∃ M : ℝ, 0 ≤ M ∧ ∀ x, ‖f x‖ ≤ M := by
  obtain ⟨M,hM⟩ := hs.bddAbove_image hf.norm.continuousOn
  refine ⟨max M 0,le_max_right _ _,?_⟩
  intro x
  by_cases hx : x ∈ tsupport f
  · exact (hM (mem_image_of_mem _ hx)).trans (le_max_left _ _)
  · rw [image_eq_zero_of_notMem_tsupport hx,norm_zero]
    exact le_max_right _ _

/-- Both the amplitude and the actual vertical coordinate derivative have
global budgets derived from compact support and smoothness. -/
theorem exists_compact_vertical_budgets {d : ℕ} (B : Ambient (d+1) → ℂ)
    (hB : ContDiff ℝ (⊤ : ℕ∞) B) (hs : HasCompactSupport B) :
    ∃ M N : ℝ, 0 ≤ M ∧ 0 ≤ N ∧ (∀ z, ‖B z‖ ≤ M) ∧
      ∀ z, ‖fderiv ℝ B z (graphPoint (0 : Ambient d) 1)‖ ≤ N := by
  obtain ⟨M,hM,hMb⟩ := exists_nonneg_compact_norm_bound B hB.continuous hs
  have hd : Continuous (fun z => fderiv ℝ B z (graphPoint (0 : Ambient d) 1)) :=
    (hB.continuous_fderiv (by norm_cast)).clm_apply continuous_const
  have hsd := hs.fderiv_apply ℝ (graphPoint (0 : Ambient d) 1)
  obtain ⟨N,hN,hNb⟩ := exists_nonneg_compact_norm_bound _ hd hsd
  exact ⟨M,N,hM,hN,hMb,hNb⟩
end N2Restriction
#print axioms N2Restriction.exists_nonneg_compact_norm_bound
#print axioms N2Restriction.exists_compact_vertical_budgets
