import continuation.DependentBlockLoomisWhitneyV34
import continuation.ComplementaryDensityV32

namespace N2Restriction
open MeasureTheory Set
open scoped ENNReal BigOperators

/-- Arbitrarily many countable weighted complementary cylinder families on
possibly different block spaces. Only cross-sectional mass budgets enter;
no disjointness or finite total mass is assumed. -/
theorem dependent_block_weighted_cylinders (n : ℕ) (X : Fin (n+2) → Type*)
    [∀ i, MeasurableSpace (X i)] [∀ i, Inhabited (X i)]
    (μ : ∀ i, Measure (X i)) [∀ i, SigmaFinite (μ i)]
    (T : Fin (n+2) → Type*) [∀ i, Countable (T i)]
    (U : ∀ i : Fin (n+2), T i → Set (∀ j, X (i.succAbove j)))
    (hU : ∀ i t, MeasurableSet (U i t)) (u : ∀ i, T i → ℝ≥0∞)
    (A : Fin (n+2) → ℝ≥0∞)
    (hA : ∀ i t, (Measure.pi (fun j => μ (i.succAbove j))) (U i t) ≤ A i) :
    (∫⁻ x, (∏ i, tubeDensity (U i) (u i) (i.removeNth x)) ^ (1 / ((n : ℝ)+1)) ∂Measure.pi μ) ≤
      (∏ i, (∑' t, u i t) * A i) ^ (1 / ((n : ℝ)+1)) := by
  have hp : 0 ≤ 1 / ((n : ℝ)+1) := by positivity
  refine (dependent_block_loomis_whitney n X μ (fun i => tubeDensity (U i) (u i))
    (fun i => measurable_tubeDensity (U i) (hU i) (u i))).trans ?_
  rw [ENNReal.prod_rpow_of_nonneg hp]
  apply ENNReal.rpow_le_rpow _ hp
  exact Finset.prod_le_prod' (fun i _ => tubeDensity_integral_le _ (U i) (hU i) (u i) (A i) (hA i))

end N2Restriction

#print axioms N2Restriction.dependent_block_weighted_cylinders
