import continuation.AffineSliceChartsV24

namespace N2Restriction
open Metric Filter

/-- An affine chart slice covers every nearby point whose chart-coordinate
difference belongs to its linear range. The lower norm bound keeps the
preimage inside the prescribed coordinate ball. -/
theorem SubmersionChartModel.Controls.affine_slice_local_coverage
    {P F : Type*} {n d : ℕ}
    [NormedAddCommGroup P] [NormedSpace ℝ P] [FiniteDimensional ℝ P]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    {c : SubmersionChartModel (P × Ambient n) (P × F)} {f : P × Ambient n → F}
    {U : Set (P × Ambient n)} {x : P × Ambient n} {r : ℝ} {B : ℕ → ℝ}
    (h : c.Controls (fun q => (q.1, f q)) U x r B) {s : ℝ} (hs : 0 < s)
    (g : Ambient d →L[ℝ] (P × F) × c.free)
    {L : ℝ} (hL : 0 < L) (hgl : ∀ v, ‖v‖ ≤ L * ‖g v‖)
    (φ : Ambient d → Ambient n) (hφ : ∀ t, φ t = (c.chart.symm (c.chart x + g t)).2) :
    ∀ᶠ y in nhds x.2,
      c.chart (x.1, y) - c.chart x ∈ LinearMap.range g.toLinearMap →
      ∃ t ∈ ball 0 s, φ t = y := by
  have hx : x ∈ c.chart.source := h.2.2.1
  have hpair : ContinuousAt (fun y : Ambient n => (x.1, y)) x.2 :=
    continuousAt_const.prodMk continuousAt_id
  have hnear : ∀ᶠ y in nhds x.2,
      (x.1, y) ∈ c.chart.source ∧ c.chart (x.1, y) ∈ ball (c.chart x) (s / L) :=
    inter_mem (hpair.preimage_mem_nhds (c.chart.open_source.mem_nhds hx))
      (((c.chart.continuousAt hx).comp hpair).preimage_mem_nhds
        (ball_mem_nhds _ (div_pos hs hL)))
  filter_upwards [hnear] with y hy hrange
  obtain ⟨t, ht⟩ := hrange
  change g t = c.chart (x.1, y) - c.chart x at ht
  have hsmall : ‖g t‖ < s / L := by
    rw [ht]
    simpa only [mem_ball, dist_eq_norm] using hy.2
  have htb : t ∈ ball 0 s := by
    have hh := mul_lt_mul_of_pos_left hsmall hL
    rw [mul_div_cancel₀ _ hL.ne'] at hh
    simpa using (hgl t).trans_lt hh
  refine ⟨t, htb, ?_⟩
  rw [hφ, ht, add_sub_cancel, c.chart.left_inv hy.1]

end N2Restriction

#print axioms N2Restriction.SubmersionChartModel.Controls.affine_slice_local_coverage
