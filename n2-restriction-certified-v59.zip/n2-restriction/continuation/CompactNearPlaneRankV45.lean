import N2Restriction.CompactTupleWedge

namespace N2Restriction
open Set Metric

/-- Uniform robust rank obstruction for a compact family of independent
vectors: a plane cannot be close to more vectors than its dimension. -/
theorem compact_near_plane_rank {k n : ℕ} (K : Set (Fin k → Ambient n))
    (hK : IsCompact K) (hind : ∀ v ∈ K, LinearIndependent ℝ v) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ v ∈ K, ∀ (V : Submodule ℝ (Ambient n)) (near : Finset (Fin k)),
      (∀ i ∈ near, ‖V.starProjection (v i) - v i‖ < ε) →
      near.card ≤ Module.finrank ℝ V := by
  classical
  obtain ⟨ε, hε, he⟩ := hK.exists_thickening_subset_open
    (isOpen_setOf_linearIndependent (𝕜 := ℝ)) hind
  refine ⟨ε, hε, ?_⟩
  intro v hv V near hnear
  let w : Fin k → Ambient n := fun i => if i ∈ near then V.starProjection (v i) else v i
  have hd : dist w v < ε := by
    apply (dist_pi_lt_iff hε).2
    intro i
    by_cases hi : i ∈ near
    · simpa [w, hi, dist_eq_norm] using hnear i hi
    · simpa [w, hi] using hε
  have hw : LinearIndependent ℝ w := he (mem_thickening_iff.mpr ⟨v, hv, hd⟩)
  have hsub : LinearIndependent ℝ (fun i : near => V.orthogonalProjection (v i)) := by
    apply LinearIndependent.of_comp V.subtype
    simpa [Function.comp_def, w] using hw.comp (fun i : near => (i : Fin k)) Subtype.val_injective
  simpa using hsub.fintype_card_le_finrank

end N2Restriction
#print axioms N2Restriction.compact_near_plane_rank
