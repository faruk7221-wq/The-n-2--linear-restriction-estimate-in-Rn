import continuation.AtlasNontangentChildV47
import continuation.SeparatedBallOverlapV47
import continuation.UniformAtlasCapsV45
import continuation.AtlasSupportedDecompositionV44

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal

/-- The nontangent estimate with its finite separated covering, cap families,
and original chart inputs constructed internally. The same surface class is
retained and all constants precede the scale, input and selected stage. -/
theorem admissible_nontangent_constructed_data {d k : ℕ} (hk : 0 < k)
    (S W : Fin k → SmoothPatch (d+1)) (A : (i : Fin k) → PacketGraphAtlas (S i))
    (V : Fin k → Set (Ambient (d+1))) (m : ℝ)
    (hW : ∀ i, (S i).extendedSurface ∩ V i ⊆ (W i).support)
    (hm : 0 < m) {τ lam : ℝ} (hτ : 0 < τ) (hτsmall : τ < 1/2) (hlam : 1 ≤ lam) :
    ∃ B : Fin k → ℝ, (∀ i, 0 ≤ B i) ∧
    ∃ Bcap : ℝ, 0 ≤ Bcap ∧ ∀ᶠ R : ℝ in Filter.atTop,
    ∃ (Q : (i : Fin k) → (j : Fin (A i).size) →
      CoordinateCapFamily ((A i).patch j).support (R^(-1/2 : ℝ)))
      (L : ℕ) (c : Fin L → Ambient (d+1)),
    (∀ i, R^(-1/2 : ℝ) ≤ (A i).capRadius) ∧
    (∀ i j, ((Q i j).centers.card : ℝ) ≤ Bcap*R^((d : ℝ)/2)) ∧
    (closedBall 0 R ⊆ ⋃ l, ball (c l) (R^(1-τ))) ∧
    (∀ l t, l ≠ t → 2*((1/(2*Real.sqrt ((d+1 : ℕ) : ℝ)))*(R^(1-τ))) ≤ dist (c l) (c t)) ∧
    (∀ x : Ambient (d+1), ∀ [DecidablePred (fun l => x ∈ ball (c l) (R^(1-τ)))],
      (Fintype.card {l : Fin L // x ∈ ball (c l) (R^(1-τ))} : ℝ) ≤
        (2*Real.sqrt ((d+1 : ℕ) : ℝ)+1)^(d+1)) ∧
    ∀ (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure),
    MarginAdmissible (fun i => (S i).surfaceMeasure) (fun _ => id) V m R (fun i => g i) →
    ∃ f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure,
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) ∧
    (∀ i j, HasFrequencySupport ((A i).graph j).surfaceMeasure id
      (((A i).graph j).parametrization '' ((A i).patch j).support) (f i j)) ∧
    (∀ i x, (∑ j, extension ((A i).graph j).surfaceMeasure ((A i).patch j).rotation (f i j) x) =
      extension (S i).surfaceMeasure id (g i) x) ∧
    ∀ (hr : 0 < R^(-1/2 : ℝ)),
    ∀ (M : ℕ) (Z : Set (Ambient (d+1)))
      (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1))) (K C₀ : ℝ),
    0 ≤ K → 0 ≤ C₀ →
    UniformAlgebraicTubeCoverInput Z T M K →
    ∀ (U : Fin L → (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin d → ℤ))
      (Ω : Set (Ambient (d+1))), MeasurableSet Ω →
    (∀ l i j a ν, ν ∈ U l i j a →
      ¬ PacketTangentInBall Z ((A i).originalPacketTube j a (R^(-1/2 : ℝ)) ν R (R^(1/2+τ)/10))
        T ((A i).cellAxisDirection j a) (c l) (R^(1-τ)) (lam*R^(1/2+τ)) C₀) →
    ∀ p : ℝ, 0 < p → p ≤ 1 → 2/(k : ℝ) ≤ p →
    (∫⁻ x, (atlasBallProductSum A Q hr f U c (R^(1-τ)) Ω x)^p) ^ (1/p) ≤
      marginLocalConstant (fun i => (W i).surfaceMeasure) (fun _ => id) V m p (R^(1-τ)) *
        (∏ i, (ENNReal.ofReal (B i) * ENNReal.ofReal (M*((K*(C₀+1)+2)/(1/(2*Real.sqrt ((d+1 : ℕ) : ℝ)))+1)^(d+1)))^(1/2 : ℝ)) *
        ∏ i, ENNReal.ofReal ‖g i‖ := by
  classical
  obtain ⟨B,hB,he⟩ := eventually_atlas_nontangent_child_mass hk S W A V m hW hm hτ hτsmall hlam
  obtain ⟨Bcap,hBcap,Rc,hRc,hcaps⟩ := exists_uniform_atlas_packet_caps S A
  refine ⟨B,hB,Bcap,hBcap,?_⟩
  filter_upwards [he, Filter.eventually_ge_atTop Rc] with R hR hRcR
  obtain ⟨hsmall,Q,hcount⟩ := hcaps R hRcR
  have hR0 : 0 < R := zero_lt_one.trans_le (hRc.trans hRcR)
  have hρ : 0 < R^(1-τ) := Real.rpow_pos_of_pos hR0 _
  obtain ⟨L,c,hcover,hsep,hoverlap⟩ := exists_bounded_overlap_ball_cover (by omega : 0 < d+1) hρ R
  refine ⟨Q,L,c,hsmall,hcount,hcover,hsep,hoverlap,?_⟩
  intro g hg
  choose f he hs hf hx using fun i => (A i).input_decomposition_supported (g i) _ (hg i)
  refine ⟨f,he,hs,hx,?_⟩
  intro hr M Z T K C₀ hK hC₀ hext U Ω hΩ hnt p hp hp1 hkp
  have hθ : 0 < 1/(2*Real.sqrt ((d+1 : ℕ) : ℝ)) := by positivity
  exact hR Q hr hsmall g f he hf M Z T K C₀ _ hK hC₀ hθ hext L c hsep U Ω hΩ hnt p hp hp1 hkp

end N2Restriction
#print axioms N2Restriction.admissible_nontangent_constructed_data
