import continuation.AtlasNearCellBudgetV42
import continuation.TangentNetAssignmentV41

namespace N2Restriction
open MeasureTheory
open scoped BigOperators ENNReal

/-- Equation (6.9) for actual surface-atlas packets. The constant precedes
the new partition degree, scale, input, selected plane and polynomial stage.
Only algebraic tube covering is borrowed in the incidence argument. -/
theorem PacketGraphAtlas.far_cell_energy_budget {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) :
    ∃ B : ℝ, 0 ≤ B ∧ ∀ {m q H : ℕ} {r : ℝ}
      (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r) (hr : 0 < r)
      (g : Lp ℂ 2 S.surfaceMeasure)
      (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure),
      (∑ j, ‖f j‖^2) ≤ ‖g‖^2 →
      ∀ (A : (j : Fin T.size) → (Q j).centers → Set (Fin d → ℤ))
        (P : Fin m → MvPolynomial (Fin (d+1)) ℝ)
        (Z : Fin q → MvPolynomial (Fin (d+1)) ℝ) (cuts : Set (Ambient (d+1)))
        (V : Submodule ℝ (Ambient (d+1))) {γ K : ℝ}, 0 ≤ K →
      AlgebraicTubeCoverInput {x | polynomialLevelMap Z x = 0}
        (fun z => LinearMap.ker (fderiv ℝ (polynomialLevelMap Z) z).toLinearMap) γ H K →
      ∀ (Ω : Set (Ambient (d+1))) {b w : ℝ}, 0 < b → w ≤ b →
      Ω ⊆ Metric.thickening b (planeWitnessSet Z cuts V (2*γ)) →
      (∀ j a ν, ν ∈ A j a → 4*γ < directionPlaneAngle (T.cellAxisDirection j a.val) V) →
      (∑' σ : Fin m → Bool, ENNReal.ofReal (‖T.cellInput Q hr f
        (fun j a => {ν | ν ∈ A j a ∧ σ ∈ trimmedCellLabels P
          (T.cellAxisPoint j r ν) (T.cellAxisDirection j a.val) Ω b w})‖^2)) ≤
        ENNReal.ofReal B * ENNReal.ofReal (H*(K+2)^(d+1)) * ENNReal.ofReal (‖g‖^2) := by
  obtain ⟨B, hB, hb⟩ := T.original_labelled_cell_budget
  refine ⟨B, hB, ?_⟩
  intro m q H r Q hr g f he A P Z cuts V γ K hK hexternal Ω b w hpos hw hregion hangle
  apply hb Q hr g f he A
    (fun j a ν => trimmedCellLabels P (T.cellAxisPoint j r ν) (T.cellAxisDirection j a.val) Ω b w)
  intro j a ν hν
  have hwitness : ∀ x ∈ Ω, ∃ z ∈ {x | polynomialLevelMap Z x = 0}, dist x z < b ∧
      ‖(LinearMap.ker (fderiv ℝ (polynomialLevelMap Z) z).toLinearMap).starProjection -
        V.starProjection‖ < 2*γ := by
    intro x hx
    obtain ⟨z, hz, _, hn, hg⟩ := plane_region_near_tangent Z cuts V (hregion hx)
    exact ⟨z, hz, hn, hg⟩
  have hh := trimmedCellLabels_card_le_nontangent P _ _ V hK hexternal
    (T.cellAxisPoint j r ν) (T.cellAxisDirection j a.val)
    (T.cellAxisDirection_unit j ((Q j).centers_mem a.property)) Ω hpos hw hwitness (hangle j a ν hν)
  exact_mod_cast ENNReal.ofReal_le_ofReal hh

end N2Restriction
#print axioms N2Restriction.PacketGraphAtlas.far_cell_energy_budget
