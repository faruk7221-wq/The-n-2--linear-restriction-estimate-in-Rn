import continuation.NormalResidualPerturbationV46

namespace N2Restriction
open Set Metric

/-- The orthogonal complement of a compact independent normal tuple varies
uniformly under small tuple perturbations. No global choice of frame is made. -/
theorem compact_commonTangent_stability {k : ℕ} (K : Set (Fin k → Ambient (k+2)))
    (hK : IsCompact K) (hind : ∀ v ∈ K, LinearIndependent ℝ v)
    {δ : ℝ} (hδ : 0 < δ) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ v ∈ K, ∀ w : Fin k → Ambient (k+2),
      dist w v < ε → LinearIndependent ℝ w ∧
      ‖(commonTangent w).starProjection - (commonTangent v).starProjection‖ < δ := by
  obtain ⟨ε₁, hε₁, hgap⟩ := compact_frame_residual_gap K hK hind hδ
  obtain ⟨ε₂, hε₂, hstable⟩ := hK.exists_thickening_subset_open
    (isOpen_setOf_linearIndependent (𝕜 := ℝ)) hind
  refine ⟨min ε₁ ε₂, lt_min hε₁ hε₂, ?_⟩
  intro v hv w hw
  have hwind : LinearIndependent ℝ w := hstable
    (mem_thickening_iff.mpr ⟨v,hv,hw.trans_le (min_le_right _ _)⟩)
  refine ⟨hwind, ?_⟩
  obtain ⟨p, hp, hep⟩ := exists_orthonormalPair_for_twoPlane (commonTangent v) (commonTangent_two v (hind v hv))
  obtain ⟨q, hq, heq⟩ := exists_orthonormalPair_for_twoPlane (commonTangent w) (commonTangent_two w hwind)
  have hpzero := frameNormalResidual_of_commonTangent v p hep
  have hqzero := frameNormalResidual_of_commonTangent w q heq
  have hqbound := frameNormalResidual_le_dist v w q hq ((frameNormalResidual_eq_zero_iff w q).mp hqzero)
  have hb : frameNormalResidual v p + frameNormalResidual v q < ε₁ := by
    rw [hpzero, zero_add]
    exact hqbound.trans_lt (by simpa only [dist_comm] using hw.trans_le (min_le_left _ _))
  have hg := hgap v hv p hp q hq hb
  rw [pairProjection_eq_planeProjection hp, pairProjection_eq_planeProjection hq, hep, heq, norm_sub_rev] at hg
  exact hg

end N2Restriction
#print axioms N2Restriction.compact_commonTangent_stability
