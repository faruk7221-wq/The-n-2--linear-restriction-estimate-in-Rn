import continuation.FiberInputReferenceV30
import continuation.FiniteJetThresholdV27

namespace N2Restriction
open MeasureTheory Metric
open scoped NNReal ENNReal

/-- A common positive strip threshold puts the actual normalized fiber-input
supports into any prescribed finite-jet perturbation neighborhood of their
zero fibers. The threshold precedes all frames, charts and L2 inputs. -/
theorem actual_normalized_fiber_finite_jet_stability {n : ℕ} {r ρ L : ℝ}
    (hρ : ρ < r) (hL : 0 < L + 1) (B : ℕ → ℝ) (hB : ∀ m, 0 ≤ B m)
    (N : ℕ) {tol : ℝ} (htol : 0 < tol) :
    ∃ τ : ℝ, 0 < τ ∧ (L + 1) * τ < r - ρ ∧
      ∀ (S : SmoothPatch n) (Q : Ambient n →L[ℝ] ℝ × ℝ) (z : Ambient n)
        (δ s : ℝ) (c C : ℝ≥0) (α β : ℝ)
        (F : MeasuredTubularChart S Q z δ r ρ s B c C L)
        (E : ChartNormalCoordinates F α β)
        (g : Lp ℂ 2 ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier))
        (ε : ℝ), ε ≤ τ → ∀ (A : StripChartAmplitude F E g ε) (u : ℝ × ℝ),
        ∀ᵐ v ∂volume, A.normalizedFiberInput u v ≠ 0 →
          E.equiv.symm (-Q (S.normal z), v) ∈ ball (0 : Ambient (n - 1)) r ∧
          ∀ m ≤ N, ‖iteratedFDeriv ℝ m (fun w => F.param (E.equiv.symm (u, w))) v -
            iteratedFDeriv ℝ m (fun w => F.param (E.equiv.symm (-Q (S.normal z), w))) v‖ ≤ tol := by
  obtain ⟨τ, hτ, hm, hjets⟩ := tubular_zero_reference_finite_jet_stability
    (d := n - 1) (n := n) (k := n - 3) hρ hL B hB N htol
  refine ⟨τ, hτ, hm, ?_⟩
  intro S Q z δ s c C α β F E g ε hε A u
  filter_upwards [A.normalizedFiberInput_parameter_support u,
    A.normalizedFiberInput_residual_ae u] with v hv hs hn
  have hh := hjets E.equiv F.param E.inverse_norm_le
    (fun t ht => (F.bounds t ht).2.2.1) F.iterated_bounds
    (Q (S.normal z)) (E.equiv.symm (u, v)) (hv hn)
    (by simpa only [E.equiv.apply_symm_apply] using (hs hn).trans hε)
  simpa only [normalReference, E.equiv.apply_symm_apply] using hh

end N2Restriction

#print axioms N2Restriction.actual_normalized_fiber_finite_jet_stability
