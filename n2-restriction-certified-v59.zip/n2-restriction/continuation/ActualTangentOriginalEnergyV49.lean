import continuation.ActualTangentDirectionalKakeyaV49
import continuation.OriginalKakeyaBudgetV49
namespace N2Restriction
open MeasureTheory Set Metric Filter
open scoped ENNReal NNReal

/-- The actual tangent integral after Kakeya is bounded by the original
input norms. The input decomposition and original packet family are preserved. -/
theorem actualTangentSum_original_energy_integral {k : ℕ}
    (P : Fin k → SmoothPatch (k+2)) {ι : ℝ}
    (Dsub : ∀ i, DirectionalSubdivision (P i) ι) (a : ∀ i, Fin (Dsub i).size) (A : (i : Fin k) → PacketGraphAtlas ((fun i => (Dsub i).piece (a i)) i))
    {κ : ℝ} (B : ArticleLocalizationAtlas (fun i => (Dsub i).piece (a i)) κ)
    (V : Fin k → Set (Ambient (k+2))) (m : ℝ)
    (hS : ∀ i, ((fun i => (Dsub i).piece (a i)) i).extendedSurface ∩ V i ⊆ ((fun i => (Dsub i).piece (a i)) i).support) (hm : 0 < m)
    {p ε τ lam : ℝ} (hp : 0 < p) (hp1 : p ≤ 1) (hε : 0 < ε)
    (hexternal : B.UniformLocalizedInput p) (hτ : 0 < τ) (hτ' : τ < 1/4) (hlam : 0 < lam) :
    ∃ Benergy : Fin k → ℝ, (∀ i, 0 ≤ Benergy i) ∧
    ∃ D : ℝ≥0, ∃ H M R₀ : ℝ, 0 ≤ H ∧ 1 ≤ M ∧ 1 ≤ R₀ ∧
    ∀ N : ℝ, ∃ Cerr : ℝ, 0 ≤ Cerr ∧ ∀ R : ℝ, R₀ ≤ R →
    ∀ (Q : (i : Fin k) → (j : Fin (A i).size) →
      CoordinateCapFamily ((A i).patch j).support (R^(-1/2 : ℝ)))
      (hr : 0 < R^(-1/2 : ℝ)), (∀ i, R^(-1/2 : ℝ) ≤ (A i).capRadius) →
    ∀ Bcap : ℝ, 0 ≤ Bcap →
    (∀ i j, ((Q i j).centers.card : ℝ) ≤ Bcap*R^(((k+1 : ℕ) : ℝ)/2)) →
    ∀ (g : (i : Fin k) → Lp ℂ 2 ((fun i => (Dsub i).piece (a i)) i).surfaceMeasure)
      (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure),
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
    (∀ i j, HasFrequencySupport ((A i).graph j).surfaceMeasure ((A i).patch j).rotation
      (marginRegion (V i) (m-R^(-1/4 : ℝ))) (f i j)) →
    ∀ (L : ℕ) (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin (k+1) → ℤ))
      (Z : Set (Ambient (k+2))) (T : Ambient (k+2) → Submodule ℝ (Ambient (k+2)))
      (c : Fin L → Ambient (k+2)) (C C₀ θ : ℝ) (Ω : Set (Ambient (k+2))),
    1 ≤ C → 1+Real.sqrt (k+2 : ℕ)*(1+C)/2 ≤ C₀ → 0 < θ →
    (∀ l t, l ≠ t → 2*(θ*(R^(1-τ))) ≤ dist (c l) (c t)) →
    MeasurableSet Ω → Ω ⊆ closedBall 0 R →
    (∀ (zgrid : meetingGrid (n := k+2) (lam*R^(1/2+τ)) R) (l : Fin L), ((Ω ∩ ball (c l) (R^(1-τ))) ∩ gridCube (gridCentre (lam*R^(1/2+τ)) zgrid.val) (lam*R^(1/2+τ))).Nonempty →
      HasTerminalCubeFrame (fun i => (Dsub i).piece (a i)) κ Z T (c l) (gridCentre (lam*R^(1/2+τ)) zgrid.val) (R^(1-τ)) (lam*R^(1/2+τ))) →
    ∀ (α β Dwidth Cext η : ℝ),
    0 ≤ α → 0 ≤ β → R^(1/2+τ)/10 ≤ Dwidth*(lam*R^(1/2+τ)) →
    β = Dwidth+Real.sqrt (k+2 : ℕ)*(1+C)/2 →
    R+Real.sqrt (k+2 : ℕ)*(lam*R^(1/2+τ)) < α*R →
    FiniteDirectionalKakeya (volume.restrict (ball 0 (α*R)))
      (fun i => (P i).normal ((Dsub i).anchor (a i))) ι (β*(lam*R^(1/2+τ))) (p/2)
      (ENNReal.ofReal (Cext*(α*R)^η*(β*(lam*R^(1/2+τ)))^((k+2 : ℕ)-η))) →
    (∫⁻ y,
      (actualTangentSum A Q hr f U Z T c (R^(1-τ)) (lam*R^(1/2+τ)) C₀ R (R^(1/2+τ)/10) Ω y)^p) ≤
      ENNReal.ofReal (((1+Real.sqrt (k+2 : ℕ)/2)/θ+1)^(k+2)) * ((2^k : ENNReal) *
        (((((D : ENNReal)*ENNReal.ofReal (((1+Real.sqrt (k+2 : ℕ))*(lam*R^(1/2+τ)))^ε))^p *
          (ENNReal.ofReal (lam*R^(-1/2+2*τ)))^p) *
          ((ENNReal.ofReal H)^(p/2) *
            (ENNReal.ofReal (Cext*α^η*β^((k+2 : ℕ)-η)*(R/(lam*R^(1/2+τ)))^η)*
              ((∏ i, ENNReal.ofReal (Benergy i))^(p/2)*∏ i, (ENNReal.ofReal ‖g i‖)^p)))) +
        (ENNReal.ofReal ((k : ℝ)*(Cerr*Real.sqrt Bcap*R^(-N))*M^k*∏ i, ‖g i‖))^p*
          volume (closedBall (0 : Ambient (k+2)) (R+Real.sqrt (k+2 : ℕ)*(lam*R^(1/2+τ)))))) := by
  choose Benergy hBenergy hbudget using fun i => (A i).kakeyaWeight_existing_input_budget
  refine ⟨Benergy,hBenergy,?_⟩
  obtain ⟨D,H,M,R₀,hH,hM,hR₀,ht⟩ := actualTangentSum_directional_kakeya_integral
    P Dsub a A B V m hS hm hp hp1 hε hexternal hτ hτ' hlam
  refine ⟨D,H,M,R₀,hH,hM,hR₀,fun N => ?_⟩
  obtain ⟨Cerr,hCerr,hc⟩ := ht N
  refine ⟨Cerr,hCerr,?_⟩
  intro R hR Q hr hsmall Bcap hBcap hcount g f he hf L U Z T c C C₀ θ Ω hC hC₀ hθ hsep hΩ hΩR hframe α β Dwidth Cext η hα hβ hw hwidth hball hK
  have hh := hc R hR Q hr hsmall Bcap hBcap hcount g f he hf L U Z T c C C₀ θ Ω hC hC₀ hθ hsep hΩ hΩR hframe
    α β Dwidth Cext η (fun i => ENNReal.ofReal (Benergy i*‖g i‖^2)) hα hβ hw hwidth hball
    (fun i => hbudget i (Q i) hr (g i) (f i) (he i)) hK
  rwa [original_kakeya_budget_product Benergy (fun i => ‖g i‖) hBenergy (fun i => norm_nonneg _) p hp.le] at hh

end N2Restriction
#print axioms N2Restriction.actualTangentSum_original_energy_integral
