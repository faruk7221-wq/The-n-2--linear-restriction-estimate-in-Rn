import continuation.AtlasFinitePointMassV45
import continuation.PositiveChildMarginsV44
namespace N2Restriction
open MeasureTheory Set Metric
open scoped BigOperators ENNReal
/-- Equation (6.15) at the actual child radius, on the fixed common class,
with child-range and margin positivity discharged. Finite-point coverage
is the geometric input; no selected-input analytic estimate is assumed. -/
theorem eventually_atlas_zero_dimensional_child_mass {d k : ℕ}
    (S W : Fin k → SmoothPatch (d+1)) (T : (i : Fin k) → PacketGraphAtlas (S i))
    (V : Fin k → Set (Ambient (d+1))) (m : ℝ)
    (hW : ∀ i, (S i).extendedSurface ∩ V i ⊆ (W i).support)
    (hm : 0 < m) {τ lam : ℝ} (hτ : 0 < τ) (hτsmall : τ < 1/2) (hlam : 0 < lam) :
    ∃ C : Fin k → ℝ, (∀ i, 1 ≤ C i) ∧
    ∀ᶠ R : ℝ in Filter.atTop,
    ∀ (Q : (i : Fin k) → (j : Fin (T i).size) →
      CoordinateCapFamily ((T i).patch j).support (R^(-1/2 : ℝ)))
      (hr : 0 < R^(-1/2 : ℝ)), (∀ i, R^(-1/2 : ℝ) ≤ (T i).capRadius) →
    ∀ (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure)
      (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure),
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
    (∀ i j, HasFrequencySupport ((T i).graph j).surfaceMeasure ((T i).patch j).rotation
      (marginRegion (V i) (m-R^(-1/4 : ℝ))) (f i j)) →
    ∀ (A : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ))
      (p : ℝ), 0 < p → ∀ (q : Finset (Ambient (d+1))) (Ω : Set (Ambient (d+1))),
    Ω ⊆ thickening (lam*R^(1/2+τ)) (q : Set (Ambient (d+1))) →
    (∫⁻ x in Ω, ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
      (fun i => (T i).cellInput (Q i) hr (f i) (A i)) x‖ₑ ^ p) ≤
    (q.card : ENNReal) *
      (marginLocalConstant (fun i => (W i).surfaceMeasure) (fun _ => id) V m p (lam*R^(1/2+τ)) *
        (∏ i, ENNReal.ofReal (C i)) * (∏ i, ENNReal.ofReal ‖g i‖))^p := by
  obtain ⟨C, hC, he⟩ := eventually_atlas_finite_point_mass S W T V m hW
  refine ⟨C, hC, ?_⟩
  filter_upwards [he, eventually_children hτ hτsmall hlam,
    eventually_positive_child_margins hm hτ hτsmall hlam] with R hR hc hmargin
  exact hR _ hc.2.2.2.1 hc.2.2.2.2 hmargin.2.2

end N2Restriction
#print axioms N2Restriction.eventually_atlas_zero_dimensional_child_mass
