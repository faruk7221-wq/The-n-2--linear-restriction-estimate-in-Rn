import continuation.ThreeBlockLoomisWhitneyV32
import continuation.GridEnergyV21

namespace N2Restriction
open MeasureTheory Set
open scoped ENNReal BigOperators

/-- A countable weighted family has exactly the sum of its weighted
cross-sectional measures. No disjointness assumption is needed. -/
theorem tubeDensity_integral {X P : Type*} [MeasurableSpace X] [Countable P]
    (μ : Measure X) (U : P → Set X) (hU : ∀ t, MeasurableSet (U t)) (e : P → ℝ≥0∞) :
    (∫⁻ x, tubeDensity U e x ∂μ) = ∑' t, e t * μ (U t) := by
  unfold tubeDensity
  rw [lintegral_tsum (fun t => (measurable_const.indicator (hU t)).aemeasurable)]
  congr 1
  funext t
  rw [lintegral_indicator (hU t), lintegral_const, Measure.restrict_apply_univ]

theorem tubeDensity_integral_le {X P : Type*} [MeasurableSpace X] [Countable P]
    (μ : Measure X) (U : P → Set X) (hU : ∀ t, MeasurableSet (U t)) (e : P → ℝ≥0∞)
    (V : ℝ≥0∞) (hV : ∀ t, μ (U t) ≤ V) :
    (∫⁻ x, tubeDensity U e x ∂μ) ≤ (∑' t, e t) * V := by
  rw [tubeDensity_integral μ U hU e, ← ENNReal.tsum_mul_right]
  exact ENNReal.tsum_le_tsum (fun t => mul_le_mul_left' (hV t) _)

/-- Countable weighted complementary cylinders satisfy the sharp flat
three-block Kakeya inequality. Each family is invariant along its own block. -/
theorem three_block_weighted_cylinders
    {X Y Z P Q T : Type*} [MeasurableSpace X] [MeasurableSpace Y] [MeasurableSpace Z]
    [Countable P] [Countable Q] [Countable T]
    (μ : Measure X) (ν : Measure Y) (ξ : Measure Z) [SFinite μ] [SFinite ν] [SFinite ξ]
    (U : P → Set (Y × Z)) (V : Q → Set (X × Z)) (W : T → Set (X × Y))
    (hU : ∀ t, MeasurableSet (U t)) (hV : ∀ t, MeasurableSet (V t)) (hW : ∀ t, MeasurableSet (W t))
    (e : P → ℝ≥0∞) (d : Q → ℝ≥0∞) (c : T → ℝ≥0∞)
    (A B C : ℝ≥0∞) (hA : ∀ t, (ν.prod ξ) (U t) ≤ A)
    (hB : ∀ t, (μ.prod ξ) (V t) ≤ B) (hC : ∀ t, (μ.prod ν) (W t) ≤ C) :
    (∫⁻ yz, ∫⁻ x, (tubeDensity U e yz * tubeDensity V d (x, yz.2) *
      tubeDensity W c (x, yz.1)) ^ (1 / 2 : ℝ) ∂μ ∂ν.prod ξ) ≤
      ((∑' t, e t) * A) ^ (1 / 2 : ℝ) *
      ((∑' t, d t) * B) ^ (1 / 2 : ℝ) * ((∑' t, c t) * C) ^ (1 / 2 : ℝ) := by
  refine (three_block_loomis_whitney μ ν ξ _ _ _ (measurable_tubeDensity U hU e)
    (measurable_tubeDensity V hV d) (measurable_tubeDensity W hW c)).trans ?_
  apply mul_le_mul'
  · apply mul_le_mul'
    · exact ENNReal.rpow_le_rpow (tubeDensity_integral_le _ U hU e A hA) (by norm_num)
    · exact ENNReal.rpow_le_rpow (tubeDensity_integral_le _ V hV d B hB) (by norm_num)
  · exact ENNReal.rpow_le_rpow (tubeDensity_integral_le _ W hW c C hC) (by norm_num)

end N2Restriction

#print axioms N2Restriction.three_block_weighted_cylinders
#print axioms N2Restriction.tubeDensity_integral
#print axioms N2Restriction.tubeDensity_integral_le
