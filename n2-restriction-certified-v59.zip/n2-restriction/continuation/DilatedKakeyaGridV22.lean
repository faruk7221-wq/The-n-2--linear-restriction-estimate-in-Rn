import continuation.DirectionalGridV22
import continuation.ExternalKakeyaInterfaceV22
import continuation.GridScalesV21

set_option maxHeartbeats 300000
namespace N2Restriction
open MeasureTheory Set
open scoped ENNReal BigOperators

/-- Fixed dilations of the physical ball and tube width contribute only a fixed factor. -/
theorem dilated_kakeya_scale_normalization (n : ℕ) {R b α β : ℝ}
    (hR : 0 ≤ R) (hb : 0 < b) (hα : 0 ≤ α) (hβ : 0 ≤ β) (η : ℝ) :
    (α * R) ^ η * (β * b) ^ ((n : ℝ) - η) =
      α ^ η * β ^ ((n : ℝ) - η) * b ^ n * (R / b) ^ η := by
  rw [Real.mul_rpow hα hR, Real.mul_rpow hβ hb.le]
  calc
    _ = (α ^ η * β ^ ((n : ℝ) - η)) * (R ^ η * b ^ ((n : ℝ) - η)) := by ring
    _ = _ := by rw [kakeya_scale_normalization n hR hb]; ring

/-- The normalized ENNReal constant used to cancel a grid cube's volume. -/
theorem dilated_kakeya_constant (n : ℕ) {R b α β C : ℝ}
    (hR : 0 ≤ R) (hb : 0 < b) (hα : 0 ≤ α) (hβ : 0 ≤ β) (η : ℝ) :
    ENNReal.ofReal (C * (α * R) ^ η * (β * b) ^ ((n : ℝ) - η)) =
      ENNReal.ofReal b ^ n *
        ENNReal.ofReal (C * α ^ η * β ^ ((n : ℝ) - η) * (R / b) ^ η) := by
  rw [← ENNReal.ofReal_pow hb.le, ← ENNReal.ofReal_mul (pow_nonneg hb.le n)]
  congr 1
  calc
    _ = C * ((α * R) ^ η * (β * b) ^ ((n : ℝ) - η)) := by ring
    _ = _ := by rw [dilated_kakeya_scale_normalization n hR hb hα hβ]; ring

/-- Actual packet-grid energies satisfy the exact (R/b)^η loss under the finite
straight-tube estimate on a larger open ball. All dilation factors are displayed. -/
theorem directional_packet_grid_dilated_kakeya {d : ℕ} {I : Type} [Fintype I]
    {S : I → SmoothPatch (d + 1)} {ε : ℝ} (Dsub : ∀ i, DirectionalSubdivision (S i) ε)
    (a : ∀ i, Fin (Dsub i).size) (T : ∀ i, PacketGraphAtlas ((Dsub i).piece (a i)))
    {r : ℝ} (Q : (i : I) → (j : Fin (T i).size) → CoordinateCapFamily ((T i).patch j).support r)
    (hr : 0 < r) (f : (i : I) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure)
    {R w C D b α β Cext η p : ℝ}
    (hR : 0 ≤ R) (hb : 0 < b) (hC : 0 ≤ C) (hw : w ≤ D * b) (hp : 0 ≤ p)
    (hα : 0 ≤ α) (hβ : 0 ≤ β)
    (hwidth : β = D + Real.sqrt ((d + 1 : ℕ) : ℝ) * (1 + C) / 2)
    (hball : R + Real.sqrt ((d + 1 : ℕ) : ℝ) * b < α * R)
    (E : I → ℝ≥0∞) (hE : ∀ i, (∑' t, (T i).kakeyaWeight (Q i) hr (f i) t) ≤ E i)
    (hK : FiniteDirectionalKakeya (volume.restrict (Metric.ball 0 (α * R)))
      (fun i => (S i).normal ((Dsub i).anchor (a i))) ε (β * b) p
      (ENNReal.ofReal (Cext * (α * R) ^ η * (β * b) ^ (((d + 1 : ℕ) : ℝ) - η)))) :
    (∑' z : meetingGrid (n := d + 1) b R,
      (∏ i, selectedEnergy
        (packetCubeSelection
          (fun t : (j : Fin (T i).size) × ((Q i j).centers × (Fin d → ℤ)) => ((T i).patch t.1).rotation)
          (fun t => graphGradient ((T i).graph t.1).phase t.2.1)
          (fun t => r⁻¹ • latticeVector t.2.2) R w C b (gridCentre b z))
        ((T i).kakeyaWeight (Q i) hr (f i))) ^ p) ≤
      ENNReal.ofReal (Cext * α ^ η * β ^ (((d + 1 : ℕ) : ℝ) - η) * (R / b) ^ η) *
        (∏ i, E i) ^ p := by
  have hclosed := hK.closedBall_of_larger_ball hball
  have hactual := DirectionalSubdivision.packet_kakeya Dsub a T Q hr f _ hp _ hclosed
  rw [dilated_kakeya_constant (d + 1) hR hb hα hβ η, mul_assoc] at hactual
  rw [hwidth] at hactual
  exact actual_packet_lattice_energy_of_kakeya
    (fun i (t : (j : Fin (T i).size) × ((Q i j).centers × (Fin d → ℤ))) => ((T i).patch t.1).rotation)
    (fun i (t : (j : Fin (T i).size) × ((Q i j).centers × (Fin d → ℤ))) =>
      graphGradient ((T i).graph t.1).phase t.2.1)
    (fun i (t : (j : Fin (T i).size) × ((Q i j).centers × (Fin d → ℤ))) => r⁻¹ • latticeVector t.2.2)
    (fun i => (T i).kakeyaWeight (Q i) hr (f i)) hR hb hC hw hp _ E hE
    (by simpa only [hwidth] using hactual)

/-- After a fixed threshold the enlarged tubes and a strictly larger open ball lie in
External input 2's admissible range, for the article's grid scale. -/
theorem eventually_open_kakeya_grid_scales (n : ℕ) {τ ℓ β : ℝ}
    (hτ : 0 < τ) (hτupper : τ < 1 / 2) (hℓ : 1 ≤ ℓ) (hβ : 1 ≤ β) :
    ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ R : ℝ, R₀ ≤ R →
      1 ≤ ℓ * R ^ (1 / 2 + τ) ∧
      1 ≤ β * (ℓ * R ^ (1 / 2 + τ)) ∧
      β * (ℓ * R ^ (1 / 2 + τ)) < (2 * (1 + Real.sqrt n)) * R ∧
      R + Real.sqrt n * (ℓ * R ^ (1 / 2 + τ)) < (2 * (1 + Real.sqrt n)) * R := by
  obtain ⟨R₀, hR₀, hb⟩ := eventually_kakeya_grid_scales n hτ hτupper hℓ hβ
  refine ⟨R₀, hR₀, fun R hR => ?_⟩
  obtain ⟨hgrid, hwide, hlt, _⟩ := hb R hR
  have hRone := hR₀.trans hR
  have hsqrt := Real.sqrt_nonneg (n : ℝ)
  have hgridR : ℓ * R ^ (1 / 2 + τ) ≤ R := by nlinarith
  have hprod := mul_le_mul_of_nonneg_left hgridR hsqrt
  have hpositive : 0 < (1 + Real.sqrt n) * R := by positivity
  refine ⟨hgrid, hwide, ?_, ?_⟩ <;> nlinarith

end N2Restriction

#print axioms N2Restriction.dilated_kakeya_constant
#print axioms N2Restriction.dilated_kakeya_scale_normalization
#print axioms N2Restriction.directional_packet_grid_dilated_kakeya
#print axioms N2Restriction.eventually_open_kakeya_grid_scales
