import continuation.BoundedCutStageConstructionV51
import continuation.StageRestrictionV41
namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal BigOperators

/-- The actual cut-near/cut-away step, including zero mass, preserves the
selected input and accumulated error and propagates fixed numerical ceilings. -/
theorem polynomial_cut_or_away_stage {n k m D : ℕ} {I : Type*} [Fintype I] [Nonempty I]
    {μ : Fin k → Measure (Ambient n)} {g : Fin k → Ambient n → ℂ}
    {p R r : ℝ} {M₀ err : ENNReal} (S : PolynomialStage μ g p R r M₀ err m)
    (B : PolynomialStageBudget) (hB : S.withinBudget B)
    (Q : I → Fin (m+1) → MvPolynomial (Fin n) ℝ)
    (hD : ∀ i j, (Q i j).totalDegree ≤ D)
    (hregular : ∀ i x, polynomialLevelMap (Q i) x = 0 →
      Function.Surjective (fderiv ℝ (polynomialLevelMap (Q i)) x)) :
    M₀ ≤ err ∨
    (m < n ∧ ∃ i, ∃ S' : PolynomialStage μ g p R r M₀ err (m+1),
      S'.equations = Q i ∧ S'.degreeBound = D ∧ S'.multiplier = 100*S.multiplier ∧
      S'.region ⊆ S.region ∧
      S'.withinBudget (B.advance D 100 (by norm_num)
        ((Fintype.card I : ENNReal)/(2 : ENNReal)⁻¹) (ENNReal.div_ne_top (by simp) (by norm_num)))) ∨
    (∃ S' : PolynomialStage μ g p R r M₀ err m,
      S'.equations = S.equations ∧ S'.degreeBound = S.degreeBound ∧ S'.multiplier = S.multiplier ∧
      S'.region = S.region \ thickening (100*(S.multiplier*r))
        (⋃ i, {x | polynomialLevelMap (Q i) x = 0}) ∧
      S'.withinBudget (B.advance 0 1 le_rfl 2 (by norm_num))) := by
  classical
  let cuts := ⋃ i, {x | polynomialLevelMap (Q i) x = 0}
  let ν := partitionDensity μ g S.region p
  let M := ∫⁻ x in S.region, ‖extensionProduct μ (fun _ => id) g x‖ₑ^p
  by_cases hz : M = 0
  · left
    simpa only [M,hz,mul_zero,zero_add] using S.mass_bound
  right
  have hM : 0 < M := pos_iff_ne_zero.mpr hz
  have hν : ν S.region = M := partitionDensity_retained_mass μ g S.region S.region p S.measurable (Subset.refl _)
  rcases cut_near_or_away_mass ν S.region cuts (100*(S.multiplier*r)) with hcut|haway
  · left
    have hc : (2 : ENNReal)⁻¹*M ≤ ∫⁻ x in S.region ∩ thickening (100*(S.multiplier*r)) cuts,
        ‖extensionProduct μ (fun _ => id) g x‖ₑ^p := by
      rw [hν,partitionDensity_retained_mass μ g S.region _ p
        (S.measurable.inter isOpen_thickening.measurableSet) inter_subset_left] at hcut
      have hh := mul_le_mul_left' hcut (2 : ENNReal)⁻¹
      simpa only [← mul_assoc,ENNReal.inv_mul_cancel (by norm_num : (2 : ENNReal) ≠ 0)
        (by norm_num : (2 : ENNReal) ≠ ∞),one_mul] using hh
    obtain ⟨hm,i,S',heq,hdeg,hmult,hconst,hsub,hbudget⟩ := polynomial_tangent_cut_stage_with_budget S B hB Q hD hregular
      (by norm_num : (2 : ENNReal)⁻¹ ≠ 0) (by norm_num : (2 : ENNReal)⁻¹ ≠ ∞)
      (by change 0 < (2 : ENNReal)⁻¹*M; exact ENNReal.mul_pos (by norm_num) (ne_of_gt hM)) hc
    exact ⟨hm,i,S',heq,hdeg,hmult,hsub,hbudget⟩
  · right
    let Ω := S.region \ thickening (100*(S.multiplier*r)) cuts
    have hΩ : MeasurableSet Ω := S.measurable.diff isOpen_thickening.measurableSet
    have hs : Ω ⊆ S.region := diff_subset
    rw [hν,partitionDensity_retained_mass μ g S.region Ω p hΩ hs] at haway
    obtain ⟨S',heq,hdeg,hregion,hmult,hconst⟩ := polynomial_stage_restrict S Ω hΩ hs 2 (by norm_num) haway
    refine ⟨S',heq,hdeg,hmult,hregion,?_⟩
    apply polynomial_stage_budget_update S S' B hB 0 1 le_rfl 2 (by norm_num)
    · simp only [hdeg,Nat.max_zero,le_refl]
    · simp only [hmult,one_mul,le_refl]
    · rw [hconst]

end N2Restriction
#print axioms N2Restriction.polynomial_cut_or_away_stage
