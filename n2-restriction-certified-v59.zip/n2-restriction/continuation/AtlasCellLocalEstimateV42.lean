import continuation.AtlasBufferedInputV42
import continuation.HalfBallCoverV42

namespace N2Restriction
open MeasureTheory Set
open scoped BigOperators ENNReal

/-- The actual selected packet inputs obey the margin best constant at
every center. Restriction to the finite buffer changes neither norm nor
extension, and the buffer construction supplies the admissibility proof. -/
theorem atlas_cell_local_power_bound {d k : ℕ} (S : Fin k → SmoothPatch (d+1))
    (T : (i : Fin k) → PacketGraphAtlas (S i)) {r : ℝ} (hr : 0 < r)
    (Q : (i : Fin k) → (j : Fin (T i).size) → CoordinateCapFamily ((T i).patch j).support r)
    (hsmall : ∀ i, r ≤ (T i).capRadius)
    (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure)
    (U : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ))
    {m L p : ℝ} (hm : ∀ i, m ≤ (T i).margin) (hL : 0 ≤ L) (hp : 0 < p)
    (x₀ : Ambient (d+1)) :
    (∫⁻ x in Metric.ball x₀ L,
      ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
        (fun i => (T i).cellInput (Q i) hr (f i) (U i)) x‖ₑ ^ p) ≤
      (marginLocalConstant (fun i => (T i).bufferMeasure) (fun _ => id)
        (fun i => (S i).neighborhood) m p L *
          ∏ i, ENNReal.ofReal (‖(T i).cellInput (Q i) hr (f i) (U i)‖))^p := by
  let u := fun i => (T i).bufferInput ((T i).cellInput (Q i) hr (f i) (U i))
  have hadm : MarginAdmissible (fun i => (T i).bufferMeasure) (fun _ => id)
      (fun i => (S i).neighborhood) m L (fun i => u i) := by
    intro i
    apply ((T i).bufferInput_margin _).mono
    exact inter_subset_right.trans (marginRegion_antitone _
      ((sub_le_self _ (Real.rpow_nonneg hL _)).trans (hm i)))
  have hn i : eLpNorm (u i) 2 (T i).bufferMeasure =
      ENNReal.ofReal (‖(T i).cellInput (Q i) hr (f i) (U i)‖) := by
    rw [← Lp.enorm_def, ← ofReal_norm]
    exact congrArg ENNReal.ofReal ((T i).bufferInput_cell_norm (Q i) hr (hsmall i) (f i) (U i))
  have he x : extensionProduct (fun i => (T i).bufferMeasure) (fun _ => id) (fun i => u i) x =
      extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
        (fun i => (T i).cellInput (Q i) hr (f i) (U i)) x := by
    unfold extensionProduct
    apply Finset.prod_congr rfl
    intro i _
    exact (T i).bufferInput_cell_extension (Q i) hr (hsmall i) (f i) (U i) x
  have h := ENNReal.rpow_le_rpow (marginLocalConstant_spec (fun i => (T i).bufferMeasure)
    (fun _ => id) (fun i => (S i).neighborhood) m hp x₀ (fun i => Lp.memLp (u i)) hadm) hp.le
  rw [← lintegral_rpow_enorm_eq_rpow_eLpNorm' hp] at h
  simpa only [he, inputNormProduct, hn] using h

/-- Applying the actual local estimate on a fixed half-radius cover yields
the selected-cell integral bound used in the non-wall branch. -/
theorem atlas_cell_half_ball_bound {d k : ℕ} (S : Fin k → SmoothPatch (d+1))
    (T : (i : Fin k) → PacketGraphAtlas (S i)) {r : ℝ} (hr : 0 < r)
    (Q : (i : Fin k) → (j : Fin (T i).size) → CoordinateCapFamily ((T i).patch j).support r)
    (hsmall : ∀ i, r ≤ (T i).capRadius)
    (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure)
    (U : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ))
    {m R p : ℝ} (hm : ∀ i, m ≤ (T i).margin) (hR : 0 ≤ R) (hp : 0 < p)
    (q : Finset (Ambient (d+1)))
    (hcover : Metric.closedBall 0 R ⊆ ⋃ a : q, Metric.ball (R • a.val) (R/2))
    (Ω : Set (Ambient (d+1))) (hΩ : Ω ⊆ Metric.closedBall 0 R) :
    (∫⁻ x in Ω,
      ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
        (fun i => (T i).cellInput (Q i) hr (f i) (U i)) x‖ₑ ^ p) ≤
      (q.card : ENNReal) *
      (marginLocalConstant (fun i => (T i).bufferMeasure) (fun _ => id)
        (fun i => (S i).neighborhood) m p (R/2) *
          ∏ i, ENNReal.ofReal (‖(T i).cellInput (Q i) hr (f i) (U i)‖))^p := by
  apply half_ball_integral_bound q hcover _ Ω hΩ
  intro a
  exact atlas_cell_local_power_bound S T hr Q hsmall f U hm (by positivity) hp (R • a.val)

end N2Restriction
#print axioms N2Restriction.atlas_cell_local_power_bound
#print axioms N2Restriction.atlas_cell_half_ball_bound
