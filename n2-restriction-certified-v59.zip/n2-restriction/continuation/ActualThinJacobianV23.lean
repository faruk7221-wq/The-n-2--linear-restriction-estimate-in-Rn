import continuation.ParameterSliceJacobianV23

set_option maxHeartbeats 800000
set_option synthInstance.maxHeartbeats 100000

namespace N2Restriction
open Metric Filter

/-- The free space in an augmented chart is vertical in the external parameter. -/
theorem SubmersionChartModel.Controls.free_vertical {P E F : Type*}
    [NormedAddCommGroup P] [NormedSpace ℝ P] [FiniteDimensional ℝ P]
    [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    {c : SubmersionChartModel (P × E) (P × F)} {f : P × E → F}
    {U : Set (P × E)} {x : P × E} {r : ℝ} {B : ℕ → ℝ}
    (h : c.Controls (fun q => (q.1, f q)) U x r B) (hU : IsOpen U) :
    ∀ v : c.free, (v : P × E).1 = 0 := by
  obtain ⟨_, ⟨z, hz, hK⟩, _, _, he, hf, _⟩ := h
  have hfwd : ContDiffOn ℝ (⊤ : ℕ∞) (fun q => (q.1, f q)) U :=
    hf.fst.congr (fun y _ => (he y).symm)
  have hdiff := (hfwd.contDiffAt (hU.mem_nhds hz)).differentiableAt (by simp)
  intro v
  have hv : fderiv ℝ (fun q => (q.1, f q)) z v = 0 :=
    (hK ▸ v.property : (v : P × E) ∈ LinearMap.ker
      (fderiv ℝ (fun q => (q.1, f q)) z).toLinearMap)
  have hfst := hdiff.hasFDerivAt.fst
  have hfstEq := hfst.unique (hasFDerivAt_fst (𝕜 := ℝ) (p := z))
  have hp := congrArg (fun w : P × F => w.1) hv
  change ((ContinuousLinearMap.fst ℝ P F).comp
    (fderiv ℝ (fun q => (q.1, f q)) z)) v = 0 at hp
  rw [hfstEq] at hp
  exact hp

/-- Free coordinates admit a Euclidean isometry, with dimension n-codim,
even though the augmented ambient product carries its maximum norm. -/
theorem SubmersionChartModel.Controls.free_euclidean_isometry {P F : Type*} {n : ℕ}
    [NormedAddCommGroup P] [NormedSpace ℝ P] [FiniteDimensional ℝ P]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    {c : SubmersionChartModel (P × Ambient n) (P × F)} {f : P × Ambient n → F}
    {U : Set (P × Ambient n)} {x : P × Ambient n} {r : ℝ} {B : ℕ → ℝ}
    (h : c.Controls (fun q => (q.1, f q)) U x r B) (hU : IsOpen U) :
    Nonempty (Ambient (n - Module.finrank ℝ F) ≃ₗᵢ[ℝ] c.free) := by
  let j := verticalSubmoduleIsometry c.free (h.free_vertical hU)
  let V := LinearMap.range j.toLinearMap
  let e : c.free ≃ₗᵢ[ℝ] V := j.equivRange
  have hd := h.1
  rw [Module.finrank_prod, Module.finrank_prod] at hd
  have hn : Module.finrank ℝ (Ambient n) = n := by simp [Ambient]
  rw [hn] at hd
  have hdim : Module.finrank ℝ V = n - Module.finrank ℝ F := by
    have he := e.toLinearEquiv.finrank_eq
    omega
  have A : Ambient (n - Module.finrank ℝ F) ≃ₗᵢ[ℝ] c.free := by
    rw [← hdim]
    exact (stdOrthonormalBasis ℝ V).repr.symm.trans e.symm
  exact ⟨A⟩

/-- A controlled augmented chart has an actual physical level parametrization
whose derivative obeys uniform upper and lower bounds everywhere on the
closed coordinate ball. All constants are inherited from the original atlas. -/
theorem SubmersionChartModel.Controls.physical_parametrization_bounds
    {P F : Type*} {n : ℕ}
    [NormedAddCommGroup P] [NormedSpace ℝ P] [FiniteDimensional ℝ P]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    {c : SubmersionChartModel (P × Ambient n) (P × F)} {f : P × Ambient n → F}
    {U : Set (P × Ambient n)} {x : P × Ambient n} {r : ℝ} {B : ℕ → ℝ}
    (h : c.Controls (fun q => (q.1, f q)) U x r B) (hU : IsOpen U)
    (hr : 0 < r) (hB : 0 ≤ B 1) :
    ∃ φ : Ambient (n - Module.finrank ℝ F) → Ambient n,
      φ 0 = x.2 ∧ Set.InjOn φ (closedBall 0 r) ∧
      (∀ t ∈ closedBall 0 r, (x.1, φ t) ∈ U ∧ f (x.1, φ t) = f x ∧
        ContDiffAt ℝ (⊤ : ℕ∞) φ t ∧
        ‖fderiv ℝ φ t‖ ≤ B 1 ∧ ∀ v, ‖v‖ ≤ B 1 * ‖fderiv ℝ φ t v‖) ∧
      (∀ m t, t ∈ closedBall 0 r → ‖iteratedFDeriv ℝ m φ t‖ ≤ B m) ∧
      ∀ᶠ y in nhds x.2, f (x.1, y) = f x → ∃ t ∈ ball 0 r, φ t = y := by
  obtain ⟨A⟩ := h.free_euclidean_isometry hU
  let g : Ambient (n - Module.finrank ℝ F) →ₗᵢ[ℝ] (P × F) × c.free :=
    { toLinearMap := (LinearMap.inr ℝ (P × F) c.free).comp A.toLinearMap
      norm_map' := fun v => by simp [Prod.norm_def] }
  let a := c.chart x
  let ψ := fun t => c.chart.symm (a + g t)
  let φ := fun t => (ψ t).2
  have hctrl := h
  obtain ⟨_, _, hx, _, he, _, ht, hinto, hs, hderiv, _⟩ := h
  have hball : ∀ t ∈ closedBall 0 r, a + g t ∈ closedBall a r := by
    intro t ht'
    simpa [mem_closedBall, dist_eq_norm] using ht'
  have hlev : ∀ t ∈ closedBall 0 r, (ψ t).1 = x.1 ∧ f (ψ t) = f x := by
    intro t ht'
    have hp := congrArg Prod.fst (c.chart.right_inv (ht (hball t ht')))
    rw [he] at hp
    have ha : (a + g t).1 = (x.1, f x) := by simpa [a, g] using he x
    rw [ha] at hp
    exact ⟨congrArg (fun w : P × F => w.1) hp, congrArg (fun w : P × F => w.2) hp⟩
  have hp : ∀ t ∈ closedBall 0 r, (x.1, φ t) = ψ t :=
    fun t ht' => Prod.ext (hlev t ht').1.symm rfl
  refine ⟨φ, by simp [φ, ψ, a, c.chart.left_inv hx], ?_, ?_, ?_, ?_⟩
  · intro s hs' t ht' heq
    have hψ : ψ s = ψ t := by rw [← hp s hs', ← hp t ht', heq]
    have hh := congrArg c.chart hψ
    change c.chart (c.chart.symm (a + g s)) = c.chart (c.chart.symm (a + g t)) at hh
    rw [c.chart.right_inv (ht (hball s hs')), c.chart.right_inv (ht (hball t ht'))] at hh
    exact g.injective (add_left_cancel hh)
  · intro t ht'
    have hc := hs _ (hball t ht')
    have hsm : ContDiffAt ℝ (⊤ : ℕ∞) ψ t :=
      hc.comp t (contDiffAt_const.add g.contDiff.contDiffAt)
    have hd : fderiv ℝ φ t = ((ContinuousLinearMap.snd ℝ P (Ambient n)).comp
        (fderiv ℝ (c.chart.symm : (P × F) × c.free → P × Ambient n) (a + g t))).comp
          g.toContinuousLinearMap := by
      have hder := hc.differentiableAt (by simp)
      have ha := (hasFDerivAt_const (𝕜 := ℝ) a t).add g.toContinuousLinearMap.hasFDerivAt
      simpa only [zero_add] using (hder.hasFDerivAt.comp t ha).snd.fderiv
    obtain ⟨hup, hlo⟩ := hctrl.physical_slice_derivative_bounds hU hB (hball t ht') g (by
      intro v
      rfl)
    refine ⟨?_, ?_, hsm.snd, ?_, ?_⟩
    · rw [hp t ht']; exact hinto (hball t ht')
    · rw [hp t ht']; exact (hlev t ht').2
    · rw [hd]; exact hup
    · rw [hd]; exact hlo
  · intro m t ht
    have hsm := (hs _ (hball t ht)).comp t (contDiffAt_const.add g.contDiff.contDiffAt)
    have hp := norm_iteratedFDeriv_contraction_comp (ContinuousLinearMap.snd ℝ P (Ambient n))
      (ContinuousLinearMap.norm_snd_le ..) m hsm
    have ha := norm_iteratedFDeriv_affine_slice g.toContinuousLinearMap
      (by apply ContinuousLinearMap.opNorm_le_bound _ zero_le_one; intro v; simp) a m (hs _ (hball t ht))
    exact hp.trans (ha.trans (hderiv m _ (hball t ht)))
  · have hnear : ∀ᶠ y in nhds x.2,
        (x.1, y) ∈ c.chart.source ∧ c.chart (x.1, y) ∈ ball a r := by
      have hpair : ContinuousAt (fun y : Ambient n => (x.1, y)) x.2 :=
        continuousAt_const.prodMk continuousAt_id
      exact inter_mem (hpair.preimage_mem_nhds (c.chart.open_source.mem_nhds hx))
        (((c.chart.continuousAt hx).comp hpair).preimage_mem_nhds (ball_mem_nhds a hr))
    filter_upwards [hnear] with y hy hfy
    let t := A.symm ((c.chart (x.1, y)).2 - a.2)
    have ht' : t ∈ ball 0 r := by
      have hdist : dist (c.chart (x.1, y)).2 a.2 ≤ dist (c.chart (x.1, y)) a := by
        rw [Prod.dist_eq]; exact le_max_right _ _
      change ‖A.symm ((c.chart (x.1, y)).2 - a.2) - 0‖ < r
      rw [sub_zero, A.symm.norm_map]
      simpa only [dist_eq_norm] using hdist.trans_lt hy.2
    have heq : a + g t = c.chart (x.1, y) := by
      apply Prod.ext
      · simp [a, g, he, hfy]
      · simp [g, t]
    exact ⟨t, ht', by dsimp [φ, ψ]; rw [heq, c.chart.left_inv hy.1]⟩

end N2Restriction

#print axioms N2Restriction.SubmersionChartModel.Controls.free_euclidean_isometry
#print axioms N2Restriction.SubmersionChartModel.Controls.free_vertical
#print axioms N2Restriction.SubmersionChartModel.Controls.physical_parametrization_bounds
