import continuation.AtlasCubeTangentStripV46
import continuation.NontangentSeparationScaleV46

namespace N2Restriction
open Set Metric

/-- Failure of the angular tangency condition produces an actual witness
on the variety and a nearby point of the finite packet tube. -/
theorem not_packetTangentInBall_iff {n : ℕ} (Z tube : Set (Ambient n))
    (T : Ambient n → Submodule ℝ (Ambient n)) (v center : Ambient n) (ρ b C₀ : ℝ) :
    ¬ PacketTangentInBall Z tube T v center ρ b C₀ ↔
      ∃ z ∈ Z, dist z center < 2*ρ ∧ (∃ y ∈ tube, dist z y ≤ C₀*b) ∧
        b/ρ < directionPlaneAngle v (T z) := by
  simp only [PacketTangentInBall, not_forall, not_le, exists_prop]

/-- For an actual finite original packet, the number of separated balls
where it is nontangent is uniformly bounded. Witnesses and enlargement to
the exact normal-axis line are proved, not supplied as extra premises. -/
theorem PacketGraphAtlas.actual_nontangent_ball_multiplicity {d M : ℕ}
    {S : SmoothPatch (d+1)} (A : PacketGraphAtlas S)
    {I : Type*} [Fintype I] (Z : Set (Ambient (d+1)))
    (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1)))
    {K C₀ b ρ θ R w : ℝ} (hK : 0 ≤ K) (hC₀ : 0 ≤ C₀)
    (hb : 0 < b) (hρ : 0 < ρ) (hθ : 0 < θ) (hR : 0 ≤ R) (hw : w ≤ b)
    (hexternal : UniformAlgebraicTubeCoverInput Z T M K)
    (j : Fin A.size) (a : Ambient d) (ha : a ∈ (A.patch j).support)
    (r : ℝ) (ν : Fin d → ℤ) (x : I → Ambient (d+1))
    (hsep : ∀ i l, i ≠ l → 2*(θ*ρ) ≤ dist (x i) (x l))
    (hnontan : ∀ i, ¬ PacketTangentInBall Z (A.originalPacketTube j a r ν R w)
      T (A.cellAxisDirection j a) (x i) ρ b C₀) :
    (Fintype.card I : ℝ) ≤ M * ((K*(C₀+1)+2)/θ+1)^(d+1) := by
  classical
  have he (i : I) := (not_packetTangentInBall_iff Z _ T _ (x i) ρ b C₀).mp (hnontan i)
  choose z hz hball hnear hangle using he
  apply nontangent_ball_multiplicity_with_separation Z T hK (by positivity : 0 < C₀+1) hb hρ hθ hexternal
    (A.cellAxisPoint j r ν) (A.cellAxisDirection j a) (A.cellAxisDirection_unit j ha)
    x z hsep hz
  · intro i
    simpa only [dist_comm] using (hball i).le
  · intro i
    obtain ⟨y,hy,hzy⟩ := hnear i
    obtain ⟨t,ht⟩ := A.packet_tube_near_cell_axis j ha r ν hR hy
    refine ⟨t,?_⟩
    have htri := dist_triangle (z i) y (A.cellAxisPoint j r ν + t • A.cellAxisDirection j a)
    nlinarith only [htri,ht,hzy,hw]
  · exact hangle

end N2Restriction
#print axioms N2Restriction.not_packetTangentInBall_iff
#print axioms N2Restriction.PacketGraphAtlas.actual_nontangent_ball_multiplicity
