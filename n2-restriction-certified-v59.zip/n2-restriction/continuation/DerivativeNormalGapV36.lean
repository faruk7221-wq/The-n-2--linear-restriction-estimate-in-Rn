import continuation.SubspaceGapV36

namespace N2Restriction

/-- A lower bound for an immersion turns derivative perturbation into relative
distance to the perturbed tangent range. -/
theorem range_starProjection_distance_le {d m : ℕ}
    (A B : Ambient d →L[ℝ] Ambient m) (c : ℝ) (hc : 0 < c)
    (hA : ∀ t, c*‖t‖ ≤ ‖A t‖) (x : Ambient m) (hx : x ∈ LinearMap.range A.toLinearMap) :
    ‖x-(LinearMap.range B.toLinearMap).starProjection x‖ ≤ (‖A-B‖/c)*‖x‖ := by
  obtain ⟨t,rfl⟩ := hx
  have ht : ‖t‖ ≤ ‖A t‖/c := (le_div_iff₀ hc).mpr (by simpa [mul_comm] using hA t)
  calc
    _ ≤ ‖A t-B t‖ := norm_sub_starProjection_le (LinearMap.range B.toLinearMap) _ _ (LinearMap.mem_range_self B.toLinearMap t)
    _ ≤ ‖A-B‖*‖t‖ := (A-B).le_opNorm t
    _ ≤ ‖A-B‖*(‖A t‖/c) := mul_le_mul_of_nonneg_left ht (norm_nonneg _)
    _ = _ := by change ‖A-B‖*(‖A t‖/c) = (‖A-B‖/c)*‖A t‖; ring

/-- Uniformly immersed tangent maps have Lipschitz-varying normal spaces,
with explicit conditioning cost 2/c. -/
theorem derivative_normal_gap_le {d m : ℕ}
    (A B : Ambient d →L[ℝ] Ambient m) (c : ℝ) (hc : 0 < c)
    (hA : ∀ t, c*‖t‖ ≤ ‖A t‖) (hB : ∀ t, c*‖t‖ ≤ ‖B t‖) :
    ‖(LinearMap.range A.toLinearMap)ᗮ.starProjection-
      (LinearMap.range B.toLinearMap)ᗮ.starProjection‖ ≤ 2*‖A-B‖/c := by
  rw [starProjection_orthogonal_gap]
  have hh := starProjection_gap_le (LinearMap.range A.toLinearMap) (LinearMap.range B.toLinearMap)
    (‖A-B‖/c) (‖A-B‖/c) (by positivity) (by positivity)
    (fun x hx => range_starProjection_distance_le A B c hc hA x hx)
    (fun x hx => by simpa only [norm_sub_rev] using range_starProjection_distance_le B A c hc hB x hx)
  convert hh using 1; ring

/-- A derivative Lipschitz bound and common immersion lower bound give the
normal-plane aperture required by the new geometric Kakeya estimate. -/
theorem chart_normal_gap_of_lipschitz {d m : ℕ} (φ : Ambient d → Ambient m)
    (s t : Ambient d) (c L : ℝ) (hc : 0 < c)
    (hs : ∀ v, c*‖v‖ ≤ ‖fderiv ℝ φ s v‖) (ht : ∀ v, c*‖v‖ ≤ ‖fderiv ℝ φ t v‖)
    (hL : ‖fderiv ℝ φ s-fderiv ℝ φ t‖ ≤ L*dist s t) :
    ‖(LinearMap.range (fderiv ℝ φ s).toLinearMap)ᗮ.starProjection-
      (LinearMap.range (fderiv ℝ φ t).toLinearMap)ᗮ.starProjection‖ ≤ (2*L/c)*dist s t := by
  refine (derivative_normal_gap_le _ _ c hc hs ht).trans ?_
  calc
    _ ≤ 2*(L*dist s t)/c := div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left hL (by norm_num)) hc.le
    _ = _ := by ring

end N2Restriction

#print axioms N2Restriction.chart_normal_gap_of_lipschitz
#print axioms N2Restriction.derivative_normal_gap_le
#print axioms N2Restriction.range_starProjection_distance_le
