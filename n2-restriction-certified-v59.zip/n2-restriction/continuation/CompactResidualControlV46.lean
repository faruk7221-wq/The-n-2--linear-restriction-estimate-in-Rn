import N2Restriction.CompactTupleWedge

namespace N2Restriction
open Set

/-- On a compact parameter set, a continuous nonnegative residual controls
any continuous quantity vanishing on its zero set, with a uniform threshold. -/
theorem compact_residual_control {X : Type*} [TopologicalSpace X] (K : Set X)
    (hK : IsCompact K) (f g : X → ℝ) (hf : Continuous f) (hg : Continuous g)
    (hfnonneg : ∀ x ∈ K, 0 ≤ f x) (hzero : ∀ x ∈ K, f x = 0 → g x = 0)
    {δ : ℝ} (hδ : 0 < δ) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ x ∈ K, f x < ε → g x < δ := by
  let B := K ∩ {x | δ ≤ g x}
  have hB : IsCompact B := hK.inter_right (isClosed_le continuous_const hg)
  by_cases hne : B.Nonempty
  · obtain ⟨x, hx, hmin⟩ := hB.exists_isMinOn hne hf.continuousOn
    have hpos : 0 < f x := by
      apply lt_of_le_of_ne (hfnonneg x hx.1)
      intro hz
      have h := hzero x hx.1 hz.symm
      have hd := hx.2
      change δ ≤ g x at hd
      linarith
    refine ⟨f x, hpos, ?_⟩
    intro y hy hsmall
    by_contra hbad
    have hyB : y ∈ B := ⟨hy, not_lt.mp hbad⟩
    exact (not_lt_of_ge (hmin hyB)) hsmall
  · refine ⟨1, by norm_num, ?_⟩
    intro x hx _
    by_contra hbad
    exact hne ⟨x, hx, not_lt.mp hbad⟩

/-- An orthonormal two-frame perpendicular to k independent normals in
k+2 dimensions spans their exact common tangent plane. -/
theorem pairPlane_eq_commonTangent_of_independent {k : ℕ}
    (v : Fin k → Ambient (k+2)) (hv : LinearIndependent ℝ v)
    (p : Ambient (k+2) × Ambient (k+2)) (hp : p ∈ orthonormalPairSet (k+2))
    (horth : ∀ i, inner ℝ (v i) p.1 = 0 ∧ inner ℝ (v i) p.2 = 0) :
    pairPlane p = commonTangent v := by
  apply Submodule.eq_of_le_of_finrank_eq
  · apply Submodule.span_le.mpr
    intro x hx
    rcases hx with rfl | hx
    · exact mem_commonTangent_of_normal_orthogonality v _ (fun i => (horth i).1)
    · have he : x = p.2 := Set.mem_singleton_iff.mp hx
      subst x
      exact mem_commonTangent_of_normal_orthogonality v _ (fun i => (horth i).2)
  · rw [pairPlane_finrank_two hp, commonTangent_two v hv]

end N2Restriction
#print axioms N2Restriction.compact_residual_control
#print axioms N2Restriction.pairPlane_eq_commonTangent_of_independent
