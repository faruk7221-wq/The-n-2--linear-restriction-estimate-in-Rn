import N2Restriction.Geometry
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
namespace N2Restriction
open Matrix
set_option maxHeartbeats 600000

/-- A pointwise four-dimensional shape-matrix model. -/
def compressionCounterexample : Matrix (Fin 4) (Fin 4) ℝ :=
  !![0,0,1,0; 0,0,0,1; 1,0,0,0; 0,1,0,0]

theorem compressionCounterexample_symmetric : compressionCounterexampleᵀ = compressionCounterexample := by
  ext i j
  fin_cases i <;> fin_cases j <;> norm_num [compressionCounterexample,Matrix.transpose_apply]

theorem compressionCounterexample_involution : compressionCounterexample * compressionCounterexample = 1 := by
  ext i j
  fin_cases i <;> fin_cases j <;> norm_num [compressionCounterexample,Matrix.mul_apply,Fin.sum_univ_succ]

theorem compressionCounterexample_invertible : compressionCounterexample.det ≠ 0 := by
  have h := congrArg Matrix.det compressionCounterexample_involution
  rw [Matrix.det_mul,Matrix.det_one] at h
  intro hn
  rw [hn,zero_mul] at h
  norm_num at h

/-- Its restriction followed by projection onto the first coordinate two-plane
is zero, despite invertibility of the full symmetric matrix. -/
theorem compressionCounterexample_zero_compression :
    compressionCounterexample.submatrix (Fin.castAdd 2 : Fin 2 → Fin 4)
      (Fin.castAdd 2 : Fin 2 → Fin 4) = 0 := by
  ext i j
  fin_cases i <;> fin_cases j <;> norm_num [compressionCounterexample,Matrix.submatrix,Fin.castAdd,Fin.castLE]

/-- Nonzero full determinant alone cannot ensure invertible two-plane compression.
This is the pointwise linear-algebra obstruction, not a construction of a family
of hypersurface patches. -/
theorem invertible_symmetric_matrix_with_singular_two_plane_compression :
    ∃ A : Matrix (Fin 4) (Fin 4) ℝ, Aᵀ = A ∧ A.det ≠ 0 ∧
      (A.submatrix (Fin.castAdd 2 : Fin 2 → Fin 4)
        (Fin.castAdd 2 : Fin 2 → Fin 4)).det = 0 := by
  refine ⟨compressionCounterexample,compressionCounterexample_symmetric,
    compressionCounterexample_invertible,?_⟩
  rw [compressionCounterexample_zero_compression]
  simp
end N2Restriction
#print axioms N2Restriction.compressionCounterexample_symmetric
#print axioms N2Restriction.compressionCounterexample_involution
#print axioms N2Restriction.compressionCounterexample_invertible
#print axioms N2Restriction.compressionCounterexample_zero_compression
#print axioms N2Restriction.invertible_symmetric_matrix_with_singular_two_plane_compression
