import N2Restriction.RegularGraphCover
namespace N2Restriction
open Set MeasureTheory
set_option maxHeartbeats 800000

/-- A compact ambient test density supported in the regular neighborhood
meets the FULL extended surface in a compact set. No global continuity of
the defining function outside its neighborhood is assumed. -/
theorem SmoothPatch.isCompact_extended_test_support {n : ℕ} (S : SmoothPatch n)
    (ψ : Ambient n → ℂ) (hψ : HasCompactSupport ψ)
    (hinside : tsupport ψ ⊆ S.neighborhood) :
    IsCompact (tsupport ψ ∩ S.extendedSurface) := by
  let K := tsupport ψ
  letI : CompactSpace K := isCompact_iff_compactSpace.mp hψ
  have hf : Continuous (fun x : K => S.defining x) :=
    (S.smooth_defining.continuousOn.mono hinside).restrict
  have hzero : IsClosed {x : K | S.defining x = 0} := isClosed_eq hf continuous_const
  have hc := hzero.isCompact.image continuous_subtype_val
  have heq : (Subtype.val : K → Ambient n) '' {x : K | S.defining x = 0} =
      tsupport ψ ∩ S.extendedSurface := by
    ext x
    constructor
    · rintro ⟨y,hy,rfl⟩
      exact ⟨y.property,⟨hinside y.property,hy⟩⟩
    · intro hx
      exact ⟨⟨x,hx.1⟩,hx.2.2,rfl⟩
  rwa [heq] at hc

/-- An actual auxiliary smooth patch covering the complete supported test
portion of the extended surface, even beyond the original compact support. -/
theorem SmoothPatch.exists_extended_test_patch {n : ℕ} (S : SmoothPatch n)
    (ψ : Ambient n → ℂ) (hψ : HasCompactSupport ψ)
    (hinside : tsupport ψ ⊆ S.neighborhood) :
    ∃ P : SmoothPatch n, P.support = tsupport ψ ∩ S.extendedSurface ∧
      P.extendedSurface = S.extendedSurface ∧ P.normal = S.normal ∧
      P.surfaceMeasure = (Measure.hausdorffMeasure ((n : ℝ)-1)).restrict (tsupport ψ ∩ S.extendedSurface) := by
  let P : SmoothPatch n := { S with
    support := tsupport ψ ∩ S.extendedSurface
    compact_support := S.isCompact_extended_test_support ψ hψ hinside
    support_inside := fun _ hx => hx.2.1
    support_on_surface := fun _ hx => hx.2.2 }
  exact ⟨P,rfl,rfl,rfl,rfl⟩
end N2Restriction
#print axioms N2Restriction.SmoothPatch.isCompact_extended_test_support
#print axioms N2Restriction.SmoothPatch.exists_extended_test_patch
