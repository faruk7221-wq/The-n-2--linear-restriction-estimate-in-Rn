import continuation.SharpQuantitativeOscillatoryV56
import continuation.SqrtRegularizationV56
namespace N2Restriction
open Set MeasureTheory
set_option maxHeartbeats 1000000

/-- Actual one-dimensional van der Corput power 1/2, with an explicit
amplitude coefficient and no curvature-upper-bound hypothesis. -/
theorem curved_oscillatory_half_decay
    (A : ℝ → ℂ) (hA : ContDiff ℝ 1 A) (φ : ℝ → ℝ) (hφ : ContDiff ℝ 2 φ)
    (a b freq : ℝ) (hab : a ≤ b) (hfreq : 0 < freq) {c M : ℝ}
    (hc : 0 < c) (hM : 0 ≤ M)
    (hcurved : ∀ t ∈ Icc a b, c ≤ |deriv (deriv φ) t|)
    (hAt : ∀ t ∈ Icc a b, ‖A t‖ ≤ M) :
    ‖∫ t in a..b, A t * phaseExponential freq φ t‖ ≤
      (((2+2*Real.pi)*M+(∫ t in a..b, ‖deriv A t‖))/Real.sqrt c)*freq^(-(1/2 : ℝ)) := by
  have hp : 0 < Real.sqrt c := Real.sqrt_pos.2 hc
  have hq : 0 < Real.sqrt freq := Real.sqrt_pos.2 hfreq
  calc
    _ ≤ ((2+Real.pi)*M+(∫ t in a..b, ‖deriv A t‖))/(freq*(Real.sqrt c/Real.sqrt freq))+
        Real.pi*M*(Real.sqrt c/Real.sqrt freq)/c :=
      sharp_quantitative_curved_oscillatory_bound A hA φ hφ a b freq hab hfreq
        (div_pos hp hq) hc hM hcurved hAt
    _ = (((2+Real.pi)*M+(∫ t in a..b, ‖deriv A t‖))+Real.pi*M)/(Real.sqrt c*Real.sqrt freq) :=
      sqrt_regularization_budget _ _ hc hfreq
    _ = _ := by
      rw [Real.rpow_neg hfreq.le,← Real.sqrt_eq_rpow]
      simp only [div_eq_mul_inv,mul_inv_rev]
      ring
end N2Restriction
#print axioms N2Restriction.curved_oscillatory_half_decay
