import continuation.CenteredBlockCylindersV32
import continuation.Block311ConstantV32

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal BigOperators
attribute [local instance] tripleProductHaar

/-- Width-to-radius aperture gives the fifth-power bound with fixed loss 32.
This theorem does not allow a fixed angular aperture at arbitrary radius. -/
theorem centered_small_aperture_311_cylinders {P Q T : Type*}
    [Countable P] [Countable Q] [Countable T]
    (e : Ambient 5 ≃L[ℝ] (Ambient 1 × Ambient 1) × Ambient 3)
    (A : P → Ambient 5 →L[ℝ] Ambient 1 × Ambient 1)
    (B : Q → Ambient 5 →L[ℝ] Ambient 3 × Ambient 1)
    (C : T → Ambient 5 →L[ℝ] Ambient 3 × Ambient 1)
    (za : P → Ambient 1 × Ambient 1) (zb : Q → Ambient 3 × Ambient 1)
    (zc : T → Ambient 3 × Ambient 1)
    (u : P → ℝ≥0∞) (v : Q → ℝ≥0∞) (s : T → ℝ≥0∞)
    (x₀ : Ambient 5) (R w δ : ℝ) (hδ : 0 ≤ δ) (hR : 0 ≤ R) (hw : 0 ≤ w) (hscale : δ * R ≤ w)
    (hA : ∀ t, ‖A t - blockProjectionOne e‖ ≤ δ)
    (hB : ∀ t, ‖B t - blockProjectionTwo e‖ ≤ δ)
    (hC : ∀ t, ‖C t - blockProjectionThree e‖ ≤ δ) :
    (∫⁻ x in closedBall x₀ R,
      (tubeDensity (fun t => A t ⁻¹' closedBall (za t) w) u x *
       tubeDensity (fun t => B t ⁻¹' closedBall (zb t) w) v x *
       tubeDensity (fun t => C t ⁻¹' closedBall (zc t) w) s x) ^ (1 / 2 : ℝ)) ≤
      (coordinateMeasureFactor e volume ((volume.prod volume).prod volume) : ℝ≥0∞) *
      (block311VolumeConstant * 32 * ENNReal.ofReal w ^ 5 *
       ((∑' t, u t) ^ (1 / 2 : ℝ) * (∑' t, v t) ^ (1 / 2 : ℝ) *
        (∑' t, s t) ^ (1 / 2 : ℝ))) := by
  have hr : 0 ≤ w + δ * R := add_nonneg hw (mul_nonneg hδ hR)
  have hb := centered_perturbed_block_cylinders e A B C za zb zc u v s x₀ R w δ hδ hA hB hC
  rw [block311_ball_mass _ hr] at hb
  refine hb.trans ?_
  apply mul_le_mul_left'
  apply mul_le_mul_right'
  have hwidth : ENNReal.ofReal (w + δ * R) ^ 5 ≤ 32 * ENNReal.ofReal w ^ 5 := by
    calc
      _ ≤ ENNReal.ofReal (2 * w) ^ 5 := pow_le_pow_left' (ENNReal.ofReal_le_ofReal (by linarith)) 5
      _ = _ := by rw [ENNReal.ofReal_mul (by norm_num : (0 : ℝ) ≤ 2), mul_pow]; norm_num
  simpa only [mul_assoc] using mul_le_mul_left' hwidth block311VolumeConstant

end N2Restriction

#print axioms N2Restriction.centered_small_aperture_311_cylinders
