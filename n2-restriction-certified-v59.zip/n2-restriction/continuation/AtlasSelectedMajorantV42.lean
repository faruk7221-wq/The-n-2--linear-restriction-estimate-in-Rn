import continuation.AtlasBufferedInputV42
import continuation.AtlasCellBudgetV42

namespace N2Restriction
open MeasureTheory Set
open scoped BigOperators ENNReal

/-- Every selected atlas input and its extension have one uniform
original-input majorant, independent of scale and packet selection. -/
theorem PacketGraphAtlas.selected_input_majorant {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) :
    ∃ C : ℝ, 1 ≤ C ∧ ∀ {r : ℝ}
      (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r) (hr : 0 < r)
      (g : Lp ℂ 2 S.surfaceMeasure)
      (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure),
      (∑ j, ‖f j‖^2) ≤ ‖g‖^2 →
      ∀ U : (j : Fin T.size) → (Q j).centers → Set (Fin d → ℤ),
      ‖T.cellInput Q hr f U‖ ≤ C*‖g‖ ∧
      (r ≤ T.capRadius → ∀ x, ‖extension (Measure.hausdorffMeasure (d : ℝ)) id
        (T.cellInput Q hr f U) x‖ ≤ C*‖g‖) := by
  obtain ⟨B, hB, hb⟩ := T.cell_energy_budget
  let D := (eLpNorm (fun _ : Ambient (d+1) => (1 : ℂ)) 2 T.bufferMeasure).toReal
  let C := max 1 (max (Real.sqrt B) (D*Real.sqrt B))
  refine ⟨C, le_max_left _ _, ?_⟩
  intro r Q hr g f he U
  have hinc : ∀ j a ν, (∑' _c : Unit, (U j a).indicator (fun _ => (1 : ENNReal)) ν) ≤ 1 := by
    intro j a ν
    simp only [tsum_fintype, Fintype.sum_unique]
    exact Set.indicator_le_self' (fun _ _ => zero_le _) ν
  have h := (hb Q hr f (fun _ : Unit => U) 1 hinc).trans
    (mul_le_mul_left' (ENNReal.ofReal_le_ofReal he) _)
  have hsq : ‖T.cellInput Q hr f U‖^2 ≤ B*‖g‖^2 := by
    apply (ENNReal.ofReal_le_ofReal_iff (mul_nonneg hB (sq_nonneg _))).mp
    simpa only [tsum_fintype, Fintype.sum_unique, mul_one, ENNReal.ofReal_mul hB, cellInput] using h
  have hn : ‖T.cellInput Q hr f U‖ ≤ Real.sqrt B*‖g‖ := by
    apply (sq_le_sq₀ (norm_nonneg _) (mul_nonneg (Real.sqrt_nonneg _) (norm_nonneg _))).mp
    simpa only [mul_pow, Real.sq_sqrt hB] using hsq
  refine ⟨hn.trans (mul_le_mul_of_nonneg_right
    ((le_max_left _ _).trans (le_max_right _ _)) (norm_nonneg _)), ?_⟩
  intro hsmall x
  have hx := (extensionEvaluation T.bufferMeasure id measurable_id x).le_opNorm
    (T.bufferInput (T.cellInput Q hr f U))
  rw [extensionEvaluation_eq, extensionEvaluation_norm, T.bufferInput_cell_norm Q hr hsmall f U,
    T.bufferInput_cell_extension Q hr hsmall f U] at hx
  calc
    _ ≤ D*‖T.cellInput Q hr f U‖ := hx
    _ ≤ D*(Real.sqrt B*‖g‖) := mul_le_mul_of_nonneg_left hn ENNReal.toReal_nonneg
    _ = (D*Real.sqrt B)*‖g‖ := by ring
    _ ≤ C*‖g‖ := mul_le_mul_of_nonneg_right
      ((le_max_right _ _).trans (le_max_right _ _)) (norm_nonneg _)

end N2Restriction
#print axioms N2Restriction.PacketGraphAtlas.selected_input_majorant
