import continuation.CertifiedOriginalSurfaceEstimateV55
import N2Restriction.HigherExponents
namespace N2Restriction
open MeasureTheory

/-- The article's local restriction theorem on the complete ORIGINAL surfaces,
including endpoint passage and all larger exponents, relative only to the
explicit borrowed inputs. The finite iteration and support assembly are proved. -/
theorem certified_original_surface_local_range {k : ℕ} (hk : 3 ≤ k)
    (S : Fin k → SmoothPatch (k+2)) {ν κ : ℝ} (hgeo : GeometricHypotheses S ν κ)
    (hKexternal : WeightedKakeyaExternalGoal (k+2) k)
    (hLocalized : CertifiedLocalizedRestrictionInput (k := k))
    (hcutsExternal : UniformTangentCutsInput (k+2))
    (hpartitionExternal : UniformProjectedPartitionInput (k+2))
    (hcoverExternal : UniformPolynomialTubeCoverInput (k+2))
    (hpointsExternal : ZeroDimensionalPointCountInput (k+2)) :
    ∀ p : ℝ, critical k ≤ p → LocalRestriction (fun i => (S i).surfaceMeasure) (fun _ => id) p := by
  letI : ∀ i, IsFiniteMeasure (S i).surfaceMeasure := fun i => (S i).isFiniteMeasure_surfaceMeasure (by omega)
  have hk0 : (0 : ℝ) < k := by exact_mod_cast (show 0 < k by omega)
  have hcrit : 0 < critical k := critical_pos hk0
  have hstrict : ∀ p : ℝ, critical k < p → p < baseline k →
      LocalRestriction (fun i => (S i).surfaceMeasure) (fun _ => id) p := by
    intro p hpc hpb δ hδ
    exact certified_original_surface_fixed_loss hk S hgeo hKexternal hLocalized hcutsExternal hpartitionExternal
      hcoverExternal hpointsExternal hδ hpc hpb
  have hend : LocalRestriction (fun i => (S i).surfaceMeasure) (fun _ => id) (critical k) :=
    localRestriction_endpoint (fun _ => measurable_id) (by omega : 0 < k+2) hcrit
      (critical_lt_baseline (by exact_mod_cast (show 1 < k by omega))) hstrict
  exact fun p hp => LocalRestriction.mono_exponent (fun _ => measurable_id) hcrit hp hend

/-- The named MainLocalGoal is now derived from explicit borrowed inputs,
without assuming a recurrence, finite descent, support transfer or local estimate. -/
theorem mainLocalGoal_of_certified_borrowed_inputs
    (hK : ∀ k : ℕ, 3 ≤ k → WeightedKakeyaExternalGoal (k+2) k)
    (hL : ∀ (k : ℕ) (_hk : 3 ≤ k), CertifiedLocalizedRestrictionInput (k := k))
    (hcuts : ∀ k : ℕ, 3 ≤ k → UniformTangentCutsInput (k+2))
    (hpartition : ∀ k : ℕ, 3 ≤ k → UniformProjectedPartitionInput (k+2))
    (hcover : ∀ k : ℕ, 3 ≤ k → UniformPolynomialTubeCoverInput (k+2))
    (hpoints : ∀ k : ℕ, 3 ≤ k → ZeroDimensionalPointCountInput (k+2)) : MainLocalGoal := by
  intro k hk S ν κ hgeo
  exact certified_original_surface_local_range hk S hgeo (hK k hk) (hL k hk) (hcuts k hk)
    (hpartition k hk) (hcover k hk) (hpoints k hk) (critical k) le_rfl
end N2Restriction
#print axioms N2Restriction.certified_original_surface_local_range
#print axioms N2Restriction.mainLocalGoal_of_certified_borrowed_inputs
