import continuation.GridGeometryV21

namespace N2Restriction
open Set Metric

/-- A half-open cube lies in a slightly larger open ball, as required by
the localized restriction theorem. The dilation depends only on dimension. -/
theorem gridCube_subset_open_ball {n : ℕ} (q : Ambient n) {b : ℝ} (hb : 0 < b) :
    gridCube q b ⊆ ball q ((1+Real.sqrt n)*b) := by
  intro x hx
  have hh := gridCube_subset_ball q hb.le hx
  change dist x q ≤ _ at hh
  change dist x q < _
  have hs := Real.sqrt_nonneg (n : ℝ)
  nlinarith

end N2Restriction
#print axioms N2Restriction.gridCube_subset_open_ball
