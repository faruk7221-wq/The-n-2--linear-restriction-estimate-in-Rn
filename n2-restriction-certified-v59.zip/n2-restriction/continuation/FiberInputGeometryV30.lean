import continuation.FiberDomainSupportV29
import continuation.TubularFiberDerivativesV25

namespace N2Restriction
open MeasureTheory Metric
open scoped NNReal ENNReal

namespace StripChartAmplitude
variable {n : ℕ} {S : SmoothPatch n} {Q : Ambient n →L[ℝ] ℝ × ℝ} {z : Ambient n}
  {δ r ρ s : ℝ} {B : ℕ → ℝ} {c C : ℝ≥0} {L α β ε : ℝ}
  {F : MeasuredTubularChart S Q z δ r ρ s B c C L}
  {E : ChartNormalCoordinates F α β}
  {g : Lp ℂ 2 ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier)}

/-- Actual normalized fiber inputs are supported where the parametrization
is smooth, has all common derivative bounds, and has a controlled inverse
differential. This transfers chart geometry to the input support. -/
theorem normalizedFiberInput_regularity (A : StripChartAmplitude F E g ε)
    (hρ : ρ ≤ r) (hL : 0 ≤ L + 1) (u : ℝ × ℝ) :
    ∀ᵐ v ∂volume, A.normalizedFiberInput u v ≠ 0 →
      ContDiffAt ℝ (⊤ : ℕ∞) (fun w => F.param (E.equiv.symm (u, w))) v ∧
      (∀ m, ‖iteratedFDeriv ℝ m (fun w => F.param (E.equiv.symm (u, w))) v‖ ≤ B m * (L + 1)^m) ∧
      ∀ w, ‖w‖ ≤ ((L + 1) * (B 1 * L)) *
        ‖fderiv ℝ (fun w => F.param (E.equiv.symm (u, w))) v w‖ := by
  filter_upwards [A.normalizedFiberInput_parameter_support u] with v hv hn
  have ht := closedBall_subset_closedBall hρ (hv hn)
  exact tubular_fiber_derivative_bounds E.equiv hL E.norm_le E.inverse_norm_le F.param B u v
    (F.bounds _ ht).2.2.1 (fun m => F.iterated_bounds m _ ht) (F.bounds _ ht).2.2.2.2.2

/-- Almost every nonzero fiber frequency lies on the original extended
surface, inside its actual chart carrier and the same physical buffer. -/
theorem normalizedFiberInput_surface_support (A : StripChartAmplitude F E g ε)
    (hρ : ρ ≤ r) (u : ℝ × ℝ) :
    ∀ᵐ v ∂volume, A.normalizedFiberInput u v ≠ 0 →
      F.param (E.equiv.symm (u, v)) ∈ F.carrier ∧
      F.param (E.equiv.symm (u, v)) ∈ S.extendedSurface ∧
      dist (F.param (E.equiv.symm (u, v))) z ≤ s ∧
      Q (S.normal (F.param (E.equiv.symm (u, v)))) = Q (S.normal z) + u := by
  filter_upwards [A.normalizedFiberInput_parameter_support u] with v hv hn
  have ht := hv hn
  have hb := F.bounds _ (closedBall_subset_closedBall hρ ht)
  refine ⟨⟨_, ht, rfl⟩, hb.1, F.image_buffer _ ht, ?_⟩
  simpa only [← E.normal_eq, E.equiv.apply_symm_apply] using hb.2.1

end StripChartAmplitude
end N2Restriction

#print axioms N2Restriction.StripChartAmplitude.normalizedFiberInput_regularity
#print axioms N2Restriction.StripChartAmplitude.normalizedFiberInput_surface_support
