import continuation.FiberInputGeometryV30
import continuation.FiberJetStabilityV27

namespace N2Restriction
open MeasureTheory Metric
open scoped NNReal ENNReal

namespace StripChartAmplitude
variable {n : ℕ} {S : SmoothPatch n} {Q : Ambient n →L[ℝ] ℝ × ℝ} {z : Ambient n}
  {δ r ρ s : ℝ} {B : ℕ → ℝ} {c C : ℝ≥0} {L α β ε : ℝ}
  {F : MeasuredTubularChart S Q z δ r ρ s B c C L}
  {E : ChartNormalCoordinates F α β}
  {g : Lp ℂ 2 ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier)}

/-- Every nonzero L2 fiber lies inside the translated normal strip. -/
theorem normalizedFiberInput_normal_support (A : StripChartAmplitude F E g ε)
    (u : ℝ × ℝ) (hu : A.normalizedFiberInput u ≠ 0) : ‖Q (S.normal z) + u‖ ≤ ε := by
  by_contra h
  exact hu (A.normalizedFiberInput_zero_outside u (lt_of_not_ge h))

/-- The strip condition also holds on the essential support of each chosen
fiber representative, including fibers whose L2 class is zero. -/
theorem normalizedFiberInput_residual_ae (A : StripChartAmplitude F E g ε) (u : ℝ × ℝ) :
    ∀ᵐ v ∂volume, A.normalizedFiberInput u v ≠ 0 → ‖Q (S.normal z) + u‖ ≤ ε := by
  by_cases hu : A.normalizedFiberInput u = 0
  · rw [hu]
    filter_upwards [Lp.coeFn_zero (E := ℂ) (p := (2 : ℝ≥0∞))
      (μ := (volume : Measure (Ambient (n - 3))))] with v hv hn
    exact (hn hv).elim
  · exact Filter.Eventually.of_forall (fun _ _ => A.normalizedFiberInput_normal_support u hu)

/-- On the actual input support the zero-reference parameter is strictly
inside the smooth chart, with no change of the thin coordinate. -/
theorem normalizedFiberInput_reference_inside (A : StripChartAmplitude F E g ε)
    (hL : 0 ≤ L + 1) (hm : (L + 1) * ε < r - ρ) (u : ℝ × ℝ) :
    ∀ᵐ v ∂volume, A.normalizedFiberInput u v ≠ 0 →
      E.equiv.symm (-Q (S.normal z), v) ∈ ball (0 : Ambient (n - 1)) r := by
  filter_upwards [A.normalizedFiberInput_parameter_support u,
    A.normalizedFiberInput_residual_ae u] with v hv hs hn
  have ht := normalReference_mem_ball E.equiv (Q (S.normal z)) hL E.inverse_norm_le (hv hn)
    (by simpa only [E.equiv.apply_symm_apply] using hs hn) hm
  simpa only [normalReference, E.equiv.apply_symm_apply] using ht

/-- Every finite-order jet on actual fiber input support is uniformly close
to the corresponding zero fiber, with error linear in the strip width. -/
theorem normalizedFiberInput_reference_jets (A : StripChartAmplitude F E g ε)
    (hρ : ρ ≤ r) (hL : 0 ≤ L + 1) (hB : ∀ m, 0 ≤ B m)
    (hm : (L + 1) * ε < r - ρ) (u : ℝ × ℝ) :
    ∀ᵐ v ∂volume, A.normalizedFiberInput u v ≠ 0 → ∀ m,
      ‖iteratedFDeriv ℝ m (fun w => F.param (E.equiv.symm (u, w))) v -
        iteratedFDeriv ℝ m (fun w => F.param (E.equiv.symm (-Q (S.normal z), w))) v‖ ≤
        B (m + 1) * (L + 1) ^ (m + 1) * ε := by
  filter_upwards [A.normalizedFiberInput_parameter_support u,
    A.normalizedFiberInput_residual_ae u] with v hv hs hn
  intro m
  have hh := tubular_zero_reference_jet_bound E.equiv F.param (hB (m + 1)) hL E.inverse_norm_le m
    (fun t ht => (F.bounds t ht).2.2.1) (fun t ht => F.iterated_bounds (m + 1) t ht)
    (Q (S.normal z)) (E.equiv.symm (u, v)) hρ (hv hn)
    (by simpa only [E.equiv.apply_symm_apply] using hs hn) hm
  simpa only [E.equiv.apply_symm_apply] using hh

end StripChartAmplitude
end N2Restriction

#print axioms N2Restriction.StripChartAmplitude.normalizedFiberInput_normal_support
#print axioms N2Restriction.StripChartAmplitude.normalizedFiberInput_reference_inside
#print axioms N2Restriction.StripChartAmplitude.normalizedFiberInput_reference_jets
#print axioms N2Restriction.StripChartAmplitude.normalizedFiberInput_residual_ae
