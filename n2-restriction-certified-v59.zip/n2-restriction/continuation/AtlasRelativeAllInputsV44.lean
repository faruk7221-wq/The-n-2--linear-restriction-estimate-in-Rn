import continuation.AtlasRelativeRapidV44

namespace N2Restriction
open MeasureTheory Set
open scoped BigOperators ENNReal

/-- Relative-margin version of the actual non-wall estimate. The input
support, not an upper bound on m by a fixed atlas margin, supplies child
admissibility. The fixed m is chosen before the uniform radius threshold.
External partition and tube-cover data remain explicit. -/
theorem atlas_partition_nonwall_relative_all_inputs {d k : ℕ} (S : Fin k → SmoothPatch (d+1))
    (T : (i : Fin k) → PacketGraphAtlas (S i)) (Vfreq : Fin k → Set (Ambient (d+1))) (m : ℝ) {τ : ℝ} (hτ : 0 < τ) :
    ∃ B₀ : Fin k → ℝ, (∀ i, 1 ≤ B₀ i) ∧
    ∃ M : ℝ, 1 ≤ M ∧ ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ p : ℝ, 0 < p → p ≤ 1 → ∀ J : ℝ, ∃ C : ℝ, 0 ≤ C ∧
    ∀ R : ℝ, R₀ ≤ R →
    ∀ (Q : (i : Fin k) → (j : Fin (T i).size) →
      CoordinateCapFamily ((T i).patch j).support (R^(-1/2 : ℝ)))
      (hr : 0 < R^(-1/2 : ℝ)), (∀ i, R^(-1/2 : ℝ) ≤ (T i).capRadius) →
    ∀ B : ℝ, 0 ≤ B → (∀ i j, ((Q i j).centers.card : ℝ) ≤ B*R^((d : ℝ)/2)) →
    ∀ (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure)
      (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure),
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
    ∀ (A : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ))
      (Ω : Set (Ambient (d+1))), Ω ⊆ Metric.closedBall 0 R →
    (∀ i j, HasFrequencySupport ((T i).graph j).surfaceMeasure ((T i).patch j).rotation
        (marginRegion (Vfreq i) (m - R ^ (-1 / 4 : ℝ))) (f i j)) →
    let ρ := partitionDensity (fun _ => Measure.hausdorffMeasure (d : ℝ))
      (fun i => (T i).cellInput (Q i) hr (f i) (A i)) Ω p
    ∀ {l u Hgeom : ℕ} (P : Fin l → MvPolynomial (Fin (d+1)) ℝ)
      (Z : Fin u → MvPolynomial (Fin (d+1)) ℝ) (cuts : Set (Ambient (d+1)))
      (V : Submodule ℝ (Ambient (d+1))) {γ Kgeom b : ℝ}, 0 ≤ Kgeom →
    AlgebraicTubeCoverInput {x | polynomialLevelMap Z x = 0}
      (fun z => LinearMap.ker (fderiv ℝ (polynomialLevelMap Z) z).toLinearMap) γ Hgeom Kgeom →
    0 < b → R^(1/2+τ)/10 < b →
    Ω ⊆ Metric.thickening b (planeWitnessSet Z cuts V (2*γ)) →
    ∀ (far : Finset (Fin k)),
    (∀ i ∈ far, ∀ j a ν, ν ∈ A i j a →
      4*γ < directionPlaneAngle ((T i).cellAxisDirection j a.val) V) →
    ∀ {Cells : Type*} [Fintype Cells] [Nonempty Cells]
      (label : Cells → (Fin l → Bool)), Function.Injective label →
    ∀ (Δ : Cells → Set (Ambient (d+1))), (∀ c, MeasurableSet (Δ c)) →
    (∀ c, Δ c ⊆ Ω) → (∀ c, Δ c ⊆ PolynomialSignRegion P (label c)) →
    (∀ c x, x ∈ Δ c → ∀ z, ambientPolynomial (∏ l, P l) z = 0 → b ≤ dist x z) →
    ∀ {θ E D c₀ c₁ s : ℝ}, 0 < θ → 0 < E → 1 ≤ D → 0 < c₀ →
    θ*(ρ univ).toReal ≤ ∑ c, (ρ (Δ c)).toReal →
    (∀ c, (ρ (Δ c)).toReal ≤ E*(ρ univ).toReal/Fintype.card Cells) →
    c₀*D^s ≤ Fintype.card Cells → (Fintype.card Cells : ℝ) ≤ c₁*D^s →
    ((∏ l, P l).totalDegree : ℝ) ≤ D →
    ∀ (q : Finset (Ambient (d+1))),
    (Metric.closedBall 0 R ⊆ ⋃ a : q, Metric.ball (R • a.val) (R/2)) →
    ∀ K M₀ err : ENNReal, M₀ ≤ K*ρ univ+err →
    let Ec := fun i => ((2*E*((k : ℝ)+1)/θ)/c₀ * B₀ i *
      max 2 (max 1 ((Hgeom : ℝ)*(Kgeom+2)^(d+1))))
    M₀ ≤ (K*ENNReal.ofReal (2*c₁/θ)*(q.card : ENNReal)) *
      ENNReal.ofReal ((∏ i, Ec i)^(p/2)*D^(cellular k s far.card p)) *
      (marginLocalConstant (fun i => (T i).bufferMeasure) (fun _ => id)
        (fun i => Vfreq i) m p (R/2))^p *
      (∏ i, ENNReal.ofReal ‖g i‖)^p +
      (K*ENNReal.ofReal (2*c₁/θ)*ENNReal.ofReal (D^s)*
        ((volume (Metric.ball (0 : Ambient (d+1)) 1) *
          (ENNReal.ofReal ((k : ℝ)*C*Real.sqrt B*M^k))^p) *
          ENNReal.ofReal (R^(-J)) * (∏ i, ENNReal.ofReal ‖g i‖)^p)+err) := by
  classical
  obtain ⟨B₀, hB₀, M, hM, R₀, hR₀, ht⟩ := atlas_partition_nonwall_relative_rapid S T Vfreq m hτ
  refine ⟨B₀, hB₀, M, hM, R₀, hR₀, ?_⟩
  intro p hp hp1 J
  obtain ⟨C, hC, hc⟩ := ht p hp hp1 J
  refine ⟨C, hC, ?_⟩
  intro R hR Q hr hsmall B hB hcount g f he A Ω hΩ hmargin
  dsimp only
  intro l u Hgeom P Z cuts V γ Kgeom b hKgeom hexternal hb hw hregion far hangle Cells _ _ label hinj Δ hmeas hsub hsign htrim θ E D c₀ c₁ s hθ hE hD hc₀ htotal hupper hcountlo hcounthi hdeg q hcover K M₀ err hstage
  let ρ := partitionDensity (fun _ => Measure.hausdorffMeasure (d : ℝ))
    (fun i => (T i).cellInput (Q i) hr (f i) (A i)) Ω p
  by_cases hzero : ρ univ = 0
  · have hh : M₀ ≤ err := by simpa only [show partitionDensity _ _ Ω p univ = 0 from hzero, mul_zero, zero_add] using hstage
    exact hh.trans (le_add_left (le_add_left le_rfl))
  · exact hc R hR Q hr hsmall B hB hcount g f he A Ω hΩ hmargin hzero
      P Z cuts V hKgeom hexternal hb hw hregion far hangle label hinj Δ hmeas hsub hsign htrim
      hθ hE hD hc₀ htotal hupper hcountlo hcounthi hdeg q hcover K M₀ err hstage

end N2Restriction
#print axioms N2Restriction.atlas_partition_nonwall_relative_all_inputs
