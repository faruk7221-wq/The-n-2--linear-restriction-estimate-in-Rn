import continuation.ActualTangentSplitV47

namespace N2Restriction
open MeasureTheory Set Metric Filter

/-- Equation (7.7) for the explicitly defined tangent selection, subsequently
restricted to packets meeting the dilated cube. The angular and packet-meeting
premises follow from the selection itself. The variety witness is stage data. -/
theorem PacketGraphAtlas.eventually_actual_cube_tangent_strip {d : ℕ} {S : SmoothPatch (d+1)}
    (A : PacketGraphAtlas S) {τ lam : ℝ} (hτ : 0 < τ) (hτ' : τ < 1/4) (hlam : 0 < lam) :
    ∀ᶠ R : ℝ in atTop,
      ∀ (Q : (j : Fin A.size) → CoordinateCapFamily (A.patch j).support (R ^ (-1/2 : ℝ)))
      (hr : 0 < R ^ (-1/2 : ℝ))
      (f : (j : Fin A.size) → Lp ℂ 2 (A.graph j).surfaceMeasure)
      (Z : Set (Ambient (d+1))) (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1)))
      (F : Submodule ℝ (Ambient (d+1))) (center q x z : Ambient (d+1)) (C C₀ : ℝ) (Ω : Set (Ambient (d+1)))
      (U : (j : Fin A.size) → (Q j).centers → Set (Fin d → ℤ)),
      0 ≤ C → 1 + Real.sqrt ((d+1 : ℕ) : ℝ) * (1+C)/2 ≤ C₀ →
      z ∈ Z → x ∈ ball center (R ^ (1-τ)) → x ∈ gridCube q (lam * R ^ (1/2+τ)) →
      dist z x ≤ lam * R ^ (1/2+τ) →
      HasFrequencySupport (Measure.hausdorffMeasure (d : ℝ)) id
        (normalStrip S (T z ⊔ F)ᗮ (2*(lam * R ^ (-1/2+2*τ)))) (A.cellInput Q hr f
          (fun j a => A.actualTangentSelection Q U Z T center (R^(1-τ))
            (lam*R^(1/2+τ)) C₀ R (R^(1/2+τ)/10) Ω j a ∩
            {ν | (A.originalPacketTube j a (R^(-1/2 : ℝ)) ν R (R^(1/2+τ)/10) ∩
              gridCube q (C*(lam*R^(1/2+τ)))).Nonempty})) := by
  filter_upwards [A.eventually_cube_tangent_strip hτ hτ' hlam] with R hR
  intro Q hr f Z T F center q x z C C₀ Ω U hC hC₀ hz hxb hxq hzx
  exact hR Q hr f Z T F center q x z (R^(1/2+τ)/10) C C₀ _ hC hC₀ hz hxb hxq hzx
    (fun _ _ _ hν => hν.1.2) (fun _ _ _ hν => hν.2)

end N2Restriction
#print axioms N2Restriction.PacketGraphAtlas.eventually_actual_cube_tangent_strip
