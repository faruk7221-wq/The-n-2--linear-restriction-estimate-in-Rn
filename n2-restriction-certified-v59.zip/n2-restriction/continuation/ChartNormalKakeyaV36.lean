import continuation.ChartNormalApertureV36
import continuation.SubspaceKakeyaNeighborhoodV36

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal BigOperators

/-- Countable normal-tube Kakeya sampled from a fixed family of charts. -/
def ChartNormalKakeyaFamily {m : ℕ} {I : Type} [Fintype I]
    (d : I → ℕ) (φ : ∀ i, Ambient (d i) → Ambient m) (ρ p η : ℝ) (K : ℝ≥0∞) : Prop :=
      ∀ (T : I → Type) [∀ i, Countable (T i)]
      (s : ∀ i, T i → Ambient (d i)), (∀ i t, s i t ∈ closedBall 0 ρ) →
      ∀ (a : ∀ i, T i → Ambient m) (u : ∀ i, T i → ℝ≥0∞)
        (x₀ : Ambient m) (R w : ℝ), 0 < w → w ≤ R →
      (∫⁻ x in closedBall x₀ R, (∏ i, tubeDensity
        (fun t => affineSubspaceTube
          (LinearMap.range (fderiv ℝ (φ i) (s i t)).toLinearMap)ᗮ (a i t) w) (u i) x)^p) ≤
        K * ENNReal.ofReal R^η * ENNReal.ofReal w^((m:ℝ)-η) * (∏ i, ∑' t, u i t)^p

/-- Convert a subspace-neighborhood estimate into a uniform local estimate
for actual normal spaces sampled from controlled parametrizations. Charts
may have different domain dimensions; the radius precedes every chart. -/
theorem uniform_chart_normal_kakeya_from_neighborhood {m : ℕ} {I : Type} [Fintype I]
    (ε : ℝ) (hε : 0 < ε)
    (r M D : ℝ) (hr : 0 < r) (hM : 0 ≤ M) (hD : 0 ≤ D) :
    ∃ ρ : ℝ, 0 < ρ ∧ ρ ≤ r ∧
      ∀ (N₀ : I → Submodule ℝ (Ambient m)) (p η : ℝ) (K : ℝ≥0∞),
      SubspaceKakeyaNeighborhood N₀ ε p η K →
      ∀ (d : I → ℕ) (φ : ∀ i, Ambient (d i) → Ambient m),
      (∀ i, (LinearMap.range (fderiv ℝ (φ i) 0).toLinearMap)ᗮ = N₀ i) →
      (∀ i t, t ∈ closedBall 0 r → ContDiffAt ℝ (⊤ : ℕ∞) (φ i) t) →
      (∀ i t, t ∈ closedBall 0 r → ‖iteratedFDeriv ℝ 2 (φ i) t‖ ≤ D) →
      (∀ i t, t ∈ closedBall 0 r → ∀ v, ‖v‖ ≤ M*‖fderiv ℝ (φ i) t v‖) →
      ChartNormalKakeyaFamily d φ ρ p η K := by
  obtain ⟨ρ,hρ,hρr,hb⟩ := uniform_controlled_chart_normal_aperture r M D ε hr hM hD hε
  refine ⟨ρ,hρ,hρr,?_⟩
  intro N₀ p η K hK d φ h0 hs hd hl T _ s hsr a u x₀ R w hw hwR
  apply hK T (fun i t => (LinearMap.range (fderiv ℝ (φ i) (s i t)).toLinearMap)ᗮ) a
    ?_ u x₀ R w hw hwR
  intro i t
  simpa only [h0 i] using hb (d i) m (φ i) (hs i) (hd i) (hl i) (s i t) (hsr i t)

end N2Restriction

#print axioms N2Restriction.uniform_chart_normal_kakeya_from_neighborhood
