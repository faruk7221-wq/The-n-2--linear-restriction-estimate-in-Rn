import continuation.AtlasCellExtensionV42
import continuation.AtlasPacketAxesV42

namespace N2Restriction
open MeasureTheory Set
open scoped BigOperators

/-- Omitted actual packets have a rapid tail on every trimmed sign cell.
The scale threshold and decay constant are independent of the new polynomial
partition, its labels, and the selected packet subfamily. -/
theorem PacketGraphAtlas.omitted_cell_rapid_tail {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) {τ : ℝ} (hτ : 0 < τ) :
    ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ N : ℝ, ∃ C : ℝ, 0 ≤ C ∧
      ∀ R : ℝ, R₀ ≤ R →
      ∀ (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support (R^(-1/2 : ℝ)))
        (hr : 0 < R^(-1/2 : ℝ)) (B : ℝ), 0 ≤ B →
      (∀ j, ((Q j).centers.card : ℝ) ≤ B*R^((d : ℝ)/2)) →
      ∀ (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
        (g : Lp ℂ 2 S.surfaceMeasure), (∑ j, ‖f j‖^2) ≤ ‖g‖^2 →
      ∀ {m : ℕ} (P : Fin m → MvPolynomial (Fin (d+1)) ℝ)
        (Ω : Set (Ambient (d+1))) (σ : Fin m → Bool) (b : ℝ)
        (A : (j : Fin T.size) → (Q j).centers → Set (Fin d → ℤ))
        (x : Ambient (d+1)), ‖x‖ ≤ R → x ∈ Ω →
      (∀ z, ambientPolynomial (∏ l, P l) z = 0 → b ≤ dist x z) →
      x ∈ PolynomialSignRegion P σ →
      ‖extension (Measure.hausdorffMeasure (d : ℝ)) id
        (T.cellInput Q hr f (fun j a => {ν | ν ∈ A j a ∧
          σ ∉ trimmedCellLabels P (T.cellAxisPoint j (R^(-1/2 : ℝ)) ν)
            (T.cellAxisDirection j a.val) Ω b (R^(1/2+τ)/10)})) x‖ ≤
        C*Real.sqrt B*R^(-N)*‖g‖ := by
  obtain ⟨R₀, hR₀, htail⟩ := T.arbitrary_packet_rapid_tail hτ
  refine ⟨R₀, hR₀, fun N => ?_⟩
  obtain ⟨C, hC, hc⟩ := htail N
  refine ⟨C, hC, ?_⟩
  intro R hR Q hr B hB hcount f g he m P Ω σ b A x hx hΩ htrim hsign
  let U : Set ((j : Fin T.size) × ((Q j).centers × (Fin d → ℤ))) :=
    {p | p.2.2 ∈ A p.1 p.2.1 ∧ σ ∉ trimmedCellLabels P
      (T.cellAxisPoint p.1 (R^(-1/2 : ℝ)) p.2.2) (T.cellAxisDirection p.1 p.2.1.val)
      Ω b (R^(1/2+τ)/10)}
  have hU : ∀ p ∈ U, x ∉ rotatedPacketTube (T.patch p.1).rotation
      (graphGradient (T.graph p.1).phase p.2.1)
      ((R^(-1/2 : ℝ))⁻¹ • latticeVector p.2.2) R (R^(1/2+τ)/10) := by
    intro p hp htube
    exact hp.2 (T.packet_meeting_cell_label p.1 ((Q p.1).centers_mem p.2.1.property)
      (R^(-1/2 : ℝ)) p.2.2 P Ω ((zero_le_one.trans hR₀).trans hR) σ
      ⟨x, hΩ, htube, htrim, hsign⟩)
  have hh := (hc R hR Q hr B hB hcount f g he x hx U hU).2
  rw [T.cellInput_eq_selected_tsum]
  exact hh

end N2Restriction
#print axioms N2Restriction.PacketGraphAtlas.omitted_cell_rapid_tail
