import continuation.QuantitativeOscillatoryIntervalV55
import continuation.FifthPowerRegularizationV55
namespace N2Restriction
open Set MeasureTheory
set_option maxHeartbeats 1000000

/-- Optimize the actual curved-phase integral at e=t^2, alpha=t, with
freq*t^5>=1. No oscillatory bound is supplied as a hypothesis. -/
theorem curved_oscillatory_fifth_power_bound
    (A : ℝ → ℂ) (hA : ContDiff ℝ 1 A) (φ : ℝ → ℝ) (hφ : ContDiff ℝ 2 φ)
    (a b freq : ℝ) (hab : a ≤ b) (hfreq : 0 < freq) {t c M N B : ℝ}
    (ht : 0 < t) (ht1 : t ≤ 1) (hscale : 1 ≤ freq*t^5)
    (hc : 0 < c) (hM : 0 ≤ M) (hN : 0 ≤ N) (hB : 0 ≤ B)
    (hcurved : ∀ s ∈ Icc a b, c ≤ |deriv (deriv φ) s|)
    (hAt : ∀ s ∈ Icc a b, ‖A s‖ ≤ M)
    (hdAt : ∀ s ∈ Icc a b, ‖deriv A s‖ ≤ N)
    (hddφ : ∀ s ∈ Icc a b, |deriv (deriv φ) s| ≤ B) :
    ‖∫ s in a..b, A s * phaseExponential freq φ s‖ ≤
      (2*M+(b-a)*(N+M*B)+2*M/c+M*(b-a))*t := by
  exact (quantitative_curved_oscillatory_interval_bound A hA φ hφ a b freq hab hfreq
    (sq_pos_of_pos ht) ht hc hM hN hB hcurved hAt hdAt hddφ).trans
    (fifth_power_regularization_budget hfreq ht ht1 hc hM hN hB (sub_nonneg.mpr hab) hscale)

/-- A proved positive frequency-decay power for actual one-dimensional
curved oscillatory integrals. The rate 1/5 is weaker than van der Corput's
1/2 but suffices as a possible input to positive-power epsilon removal. -/
theorem curved_oscillatory_one_fifth_decay
    (A : ℝ → ℂ) (hA : ContDiff ℝ 1 A) (φ : ℝ → ℝ) (hφ : ContDiff ℝ 2 φ)
    (a b freq : ℝ) (hab : a ≤ b) (hfreq : 1 ≤ freq) {c M N B : ℝ}
    (hc : 0 < c) (hM : 0 ≤ M) (hN : 0 ≤ N) (hB : 0 ≤ B)
    (hcurved : ∀ s ∈ Icc a b, c ≤ |deriv (deriv φ) s|)
    (hAt : ∀ s ∈ Icc a b, ‖A s‖ ≤ M)
    (hdAt : ∀ s ∈ Icc a b, ‖deriv A s‖ ≤ N)
    (hddφ : ∀ s ∈ Icc a b, |deriv (deriv φ) s| ≤ B) :
    ‖∫ s in a..b, A s * phaseExponential freq φ s‖ ≤
      (2*M+(b-a)*(N+M*B)+2*M/c+M*(b-a))*freq^(-(1/5 : ℝ)) := by
  have hf : 0 < freq := lt_of_lt_of_le zero_lt_one hfreq
  let t := freq^(-(1/5 : ℝ))
  have ht : 0 < t := Real.rpow_pos_of_pos hf _
  have ht1 : t ≤ 1 := Real.rpow_le_one_of_one_le_of_nonpos hfreq (by norm_num)
  have ht5 : t^5 = freq⁻¹ := by
    dsimp [t]
    rw [← Real.rpow_natCast,← Real.rpow_mul hf.le]
    norm_num [Real.rpow_neg_one]
  have hscale : 1 ≤ freq*t^5 := by rw [ht5,mul_inv_cancel₀ hf.ne']
  exact curved_oscillatory_fifth_power_bound A hA φ hφ a b freq hab hf ht ht1 hscale hc hM hN hB hcurved hAt hdAt hddφ
end N2Restriction
#print axioms N2Restriction.curved_oscillatory_fifth_power_bound
#print axioms N2Restriction.curved_oscillatory_one_fifth_decay
