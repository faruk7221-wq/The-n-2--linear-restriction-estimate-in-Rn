import continuation.DirectionalPacketsV22
import continuation.KakeyaCountableV21

namespace N2Restriction
open MeasureTheory Set
open scoped ENNReal BigOperators

/-- A straight tube expressed using its physical base point and unit direction. -/
def normalLineTube {n : ℕ} (b N : Ambient n) (w : ℝ) : Set (Ambient n) :=
  {x | Metric.infDist x (Set.range (fun t : ℝ => b + t • N)) ≤ w}

/-- The external finite-family weighted estimate, with its directional hypothesis explicit.
This is a proposition, not an asserted theorem or a new axiom. -/
def FiniteDirectionalKakeya {n : ℕ} {I : Type} [Fintype I]
    (μ : Measure (Ambient n)) (ref : I → Ambient n) (ε w p : ℝ) (K : ℝ≥0∞) : Prop :=
  ∀ (P : I → Type) [∀ i, Fintype (P i)]
    (b N : (i : I) → P i → Ambient n) (e : (i : I) → P i → ℝ≥0∞),
    (∀ i t, e i t ≠ ⊤) →
    (∀ i t, ‖N i t‖ = 1 ∧ dist (N i t) (ref i) < ε) →
    (∫⁻ x, (∏ i, ∑ t, (normalLineTube (b i t) (N i t) w).indicator (fun _ => e i t) x) ^ p ∂μ) ≤
      K * (∏ i, ∑ t, e i t) ^ p

/-- The finite directional theorem supplies its countable version without an additional assumption. -/
theorem FiniteDirectionalKakeya.countable {n : ℕ} {I : Type} [Fintype I]
    {μ : Measure (Ambient n)} {ref : I → Ambient n} {ε w p : ℝ} {K : ℝ≥0∞}
    (hK : FiniteDirectionalKakeya μ ref ε w p K) (hp : 0 ≤ p)
    {P : I → Type} [∀ i, Countable (P i)]
    (b N : (i : I) → P i → Ambient n) (e : (i : I) → P i → ℝ≥0∞)
    (hN : ∀ i t, ‖N i t‖ = 1 ∧ dist (N i t) (ref i) < ε)
    (he : ∀ i, (∑' t, e i t) ≠ ⊤) :
    (∫⁻ x, (∏ i, tubeDensity (fun t => normalLineTube (b i t) (N i t) w) (e i) x) ^ p ∂μ) ≤
      K * (∏ i, ∑' t, e i t) ^ p := by
  classical
  apply weighted_kakeya_of_countable_finite_families μ _
    (fun i t => (isClosed_le (Metric.continuous_infDist_pt _) continuous_const).measurableSet)
    e he hp K
  intro Q
  have h := hK (fun i => ↥(Q i)) (fun i t => b i t) (fun i t => N i t)
    (fun i t => e i t)
    (fun i t => ne_top_of_le_ne_top (he i) (ENNReal.le_tsum t.val)) (fun i t => hN i t)
  have hs (i : I) (x : Ambient n) :
      (∑ t : ↥(Q i), (normalLineTube (b i t) (N i t) w).indicator (fun _ => e i t) x) =
      ∑ t ∈ Q i, (normalLineTube (b i t) (N i t) w).indicator (fun _ => e i t) x :=
    (Q i).sum_coe_sort (fun t => (normalLineTube (b i t) (N i t) w).indicator (fun _ => e i t) x)
  simp_rw [hs] at h
  simpa only [Finset.sum_coe_sort] using h

/-- The full packet tube is precisely a straight tube with its actual geometric normal. -/
theorem PacketGraphAtlas.axisTube_eq_normalLineTube {d : ℕ} {S : SmoothPatch (d + 1)}
    (T : PacketGraphAtlas S) (j : Fin T.size) {u : Ambient d}
    (hu : u ∈ (T.patch j).support) (v : Ambient d) (w : ℝ) :
    rotatedAxisTube (T.patch j).rotation (graphGradient (T.graph j).phase u) v w =
      normalLineTube ((T.patch j).rotation (graphPoint (-v) 0))
        (S.normal ((T.patch j).rotation ((T.graph j).parametrization u))) w := by
  unfold rotatedAxisTube normalLineTube
  rw [T.axis_eq_normal_line j hu v]

/-- A finite directional Kakeya theorem applies to every actual packet of a directional tuple.
No finite packet truncation and no assumed packet-direction data remain. -/
theorem DirectionalSubdivision.packet_kakeya {d : ℕ} {I : Type} [Fintype I]
    {S : I → SmoothPatch (d + 1)} {ε : ℝ} (D : ∀ i, DirectionalSubdivision (S i) ε)
    (a : ∀ i, Fin (D i).size) (T : ∀ i, PacketGraphAtlas ((D i).piece (a i)))
    {r : ℝ} (Q : (i : I) → (j : Fin (T i).size) → CoordinateCapFamily ((T i).patch j).support r)
    (hr : 0 < r) (f : (i : I) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure)
    (μ : Measure (Ambient (d + 1))) {w p : ℝ} (hp : 0 ≤ p) (K : ℝ≥0∞)
    (hK : FiniteDirectionalKakeya μ (fun i => (S i).normal ((D i).anchor (a i))) ε w p K) :
    (∫⁻ x, (∏ i, tubeDensity
      (fun t : (j : Fin (T i).size) × ((Q i j).centers × (Fin d → ℤ)) =>
        rotatedAxisTube ((T i).patch t.1).rotation
          (graphGradient ((T i).graph t.1).phase t.2.1) (r⁻¹ • latticeVector t.2.2) w)
      ((T i).kakeyaWeight (Q i) hr (f i)) x) ^ p ∂μ) ≤
      K * (∏ i, ∑' t, (T i).kakeyaWeight (Q i) hr (f i) t) ^ p := by
  classical
  let P := fun i => (j : Fin (T i).size) × ((Q i j).centers × (Fin d → ℤ))
  let b := fun i (t : P i) => ((T i).patch t.1).rotation (graphPoint (-(r⁻¹ • latticeVector t.2.2)) 0)
  let N := fun i (t : P i) => (S i).normal (((T i).patch t.1).rotation
    (((T i).graph t.1).parametrization t.2.1))
  have he i : (∑' t, (T i).kakeyaWeight (Q i) hr (f i) t) ≠ ⊤ := by
    rw [(T i).kakeyaWeight_total]
    exact ENNReal.ofReal_ne_top
  have hN i (t : P i) : ‖N i t‖ = 1 ∧ dist (N i t) ((S i).normal ((D i).anchor (a i))) < ε := by
    have hz := (D i).buffer_normals (a i) (T i) t.1
      ((T i).support_point_mem_buffer t.1 ((Q i t.1).centers_mem t.2.1.property))
    exact ⟨(S i).normal_unit _ hz.1.1, hz.2⟩
  have h := hK.countable hp b N (fun i => (T i).kakeyaWeight (Q i) hr (f i)) hN he
  have ht i (t : P i) : rotatedAxisTube ((T i).patch t.1).rotation
      (graphGradient ((T i).graph t.1).phase t.2.1) (r⁻¹ • latticeVector t.2.2) w =
      normalLineTube (b i t) (N i t) w := by
    simpa only [b, N, (D i).normal_eq] using (T i).axisTube_eq_normalLineTube t.1
      ((Q i t.1).centers_mem t.2.1.property) (r⁻¹ • latticeVector t.2.2) w
  simpa only [ht] using h

end N2Restriction

#print axioms N2Restriction.DirectionalSubdivision.packet_kakeya
#print axioms N2Restriction.FiniteDirectionalKakeya.countable
#print axioms N2Restriction.PacketGraphAtlas.axisTube_eq_normalLineTube
