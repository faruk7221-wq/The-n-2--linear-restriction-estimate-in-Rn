import continuation.SmoothGraphFourierTransferV57
import continuation.CompactChartProductDecayV57
import continuation.PhysicalPhaseCoordinatesV57
namespace N2Restriction
open Set MeasureTheory
set_option maxHeartbeats 1000000

/-- Half-decay of an actual Hausdorff surface-chart Fourier integral. The
only borrowed premise is the standard graph area formula. Smoothness, compact
support, amplitude budgets, integrability, exact coordinates and the oscillatory
estimate are proved internally. The coefficient precedes direction/frequency. -/
theorem exists_actual_surface_chart_half_decay (harea : SmoothGraphAreaFormulaInput) {d : ℕ}
    (A : Ambient (d+2) ≃ₗᵢ[ℝ] Ambient (d+2)) (Φ : Ambient (d+1) → ℝ)
    (hΦ : ContDiff ℝ (⊤ : ℕ∞) Φ) (ψ : Ambient (d+2) → ℂ)
    (hψ : ContDiff ℝ (⊤ : ℕ∞) ψ) (hs : HasCompactSupport ψ)
    (β : Ambient (d+2) → ℝ) (hβ : ContDiff ℝ (⊤ : ℕ∞) β)
    (K : Set (Ambient d)) (hK : IsCompact K) (Θ : Set (Ambient (d+2)))
    (a b : ℝ) (hab : a ≤ b) {c : ℝ} (hc : 0 < c)
    (hcurved : ∀ θ ∈ Θ, ∀ y ∈ K, ∀ t ∈ Icc a b,
      c ≤ |deriv (deriv (fun s => inner ℝ θ
        (A (graphPoint (graphPoint y s) (Φ (graphPoint y s)))))) t|) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ θ ∈ Θ, ∀ freq : ℝ, 0 < freq →
      ‖extension ((Measure.hausdorffMeasure ((d+1 : ℕ) : ℝ)).restrict
          ((fun u => A (graphPoint u (Φ u))) ''
            ((graphFiberEquiv d) '' (K ×ˢ Icc a b)))) id
          (fun z => ψ z*(β z : ℂ)) (freq • θ)‖ ≤ C*freq^(-(1/2 : ℝ)) := by
  let B := smoothSurfaceAmplitude A Φ ψ β
  let G : Ambient (d+1) → Ambient (d+2) := fun u => A (graphPoint u (Φ u))
  have hB := contDiff_smoothSurfaceAmplitude A Φ hΦ ψ hψ β hβ
  have hBs := hasCompactSupport_smoothSurfaceAmplitude A Φ ψ hs β
  have hG : ContDiff ℝ (⊤ : ℕ∞) G :=
    A.contDiff.comp (graphPointCLM.contDiff.comp (contDiff_id.prodMk hΦ))
  obtain ⟨C,hC,hdecay⟩ := exists_compact_chart_product_half_decay B hB hBs G hG K hK Θ a b hab hc hcurved
  have hL : IsCompact ((graphFiberEquiv d) '' (K ×ˢ Icc a b)) :=
    (hK.prod isCompact_Icc).image graphPointCLM.continuous
  refine ⟨C,hC,?_⟩
  intro θ hθ freq hf
  rw [smooth_graph_fourier_transfer harea A Φ hΦ _ hL ψ hψ.continuous β hβ.continuous,
    extension_graph_rectangle_product]
  exact hdecay θ hθ freq hf
end N2Restriction
#print axioms N2Restriction.exists_actual_surface_chart_half_decay
