import continuation.CellDegreeLocalBoundV43

namespace N2Restriction
open scoped BigOperators ENNReal

/-- Combine substantial-cell retention, the local cell estimate, and all
near/far energy bounds. This is the mass-level algebra behind (6.10), with
the old-stage constant and both error contributions retained explicitly. -/
theorem cellular_mass_recurrence {k : ℕ} (far : Finset (Fin k))
    (C : Fin k → ℝ) (hC : ∀ i, 0 ≤ C i) {D : ℝ} (hD : 0 < D) (s : ℝ)
    (a b : Fin k → ENNReal) (L Q K H M₀ M cell err tail : ENNReal)
    {p : ℝ} (hp : 0 ≤ p)
    (hstage : M₀ ≤ K*M+err)
    (hmass : M ≤ H*ENNReal.ofReal (D^s)*cell)
    (hcell : cell ≤ Q*(L*∏ i, a i)^p+tail)
    (he : ∀ i, a i ^ (2 : ℕ) ≤
      ENNReal.ofReal (C i * D^(1-s-(if i ∈ far then (1 : ℝ) else 0))) * b i ^ (2 : ℕ)) :
    M₀ ≤ (K*H*Q) * ENNReal.ofReal ((∏ i, C i)^(p/2) * D^(cellular k s far.card p)) *
      L^p * (∏ i, b i)^p + (K*H*ENNReal.ofReal (D^s)*tail+err) := by
  have hh := cell_degree_local_bound far C hC hD s a b L Q hp he
  calc
    M₀ ≤ K*M+err := hstage
    _ ≤ K*(H*ENNReal.ofReal (D^s)*(Q*(L*∏ i, a i)^p+tail))+err := by
      exact add_le_add_right (mul_le_mul_left' (hmass.trans
        (mul_le_mul_left' hcell _)) K) err
    _ = K*H*(ENNReal.ofReal (D^s)*Q*(L*∏ i, a i)^p) +
        (K*H*ENNReal.ofReal (D^s)*tail+err) := by ring
    _ ≤ K*H*(Q*ENNReal.ofReal ((∏ i, C i)^(p/2)*D^(cellular k s far.card p))*
        L^p*(∏ i, b i)^p) + (K*H*ENNReal.ofReal (D^s)*tail+err) :=
      add_le_add_right (mul_le_mul_left' hh _) _
    _ = _ := by ac_rfl

end N2Restriction
#print axioms N2Restriction.cellular_mass_recurrence
