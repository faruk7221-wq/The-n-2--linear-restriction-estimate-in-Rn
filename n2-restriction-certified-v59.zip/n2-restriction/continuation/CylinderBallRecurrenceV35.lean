import continuation.CylinderCellBudgetV35
import continuation.CellLocalEstimateV35
import continuation.BallCellPartitionV35

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal BigOperators

/-- One genuine radius-reduction step. The local estimate is required only
on balls of radius c*b, for the same projections and arbitrary reweighted
families. The flat estimate supplies a scale-independent recurrence cost. -/
theorem cylinder_ball_recurrence {n : ℕ} {I : Type*} [Fintype I]
    {T : I → Type*} {F : I → Type*}
    [∀ i, NormedAddCommGroup (F i)] [∀ i, NormedSpace ℝ (F i)]
    (A : ∀ i, T i → Ambient n →L[ℝ] F i) (Q : ∀ i, Ambient n →L[ℝ] F i)
    (z : ∀ i, T i → F i) (u : ∀ i, T i → ℝ≥0∞)
    (x₀ : Ambient n) (R w δ M b c p : ℝ)
    (hp : 0 ≤ p) (hb : 0 < b) (hM : 0 ≤ M)
    (hc : Real.sqrt n / 2 ≤ c) (hw : w ≤ b) (ha : δ*R ≤ b)
    (hδ : 0 ≤ δ) (hA : ∀ i t, ‖A i t - Q i‖ ≤ δ)
    (hQ : ∀ i, ‖Q i‖ ≤ M) (Klocal Kflat : ℝ≥0∞)
    (hlocal : ∀ (v : ∀ i, T i → ℝ≥0∞) (q : Ambient n),
      (∫⁻ x in closedBall q (c*b), (∏ i, tubeDensity
        (fun t => A i t ⁻¹' closedBall (z i t) w) (v i) x) ^ p) ≤
      Klocal * (∏ i, ∑' t, v i t) ^ p)
    (hflat : (∫⁻ x, (∏ i, tubeDensity
      (fun t => Q i ⁻¹' closedBall (z i t + (Q i - A i t) x₀)
        ((2 + M*Real.sqrt n)*b)) (u i) x) ^ p) ≤
      Kflat * ENNReal.ofReal ((2 + M*Real.sqrt n)*b) ^ n * (∏ i, ∑' t, u i t) ^ p) :
    (∫⁻ x in closedBall x₀ R, (∏ i, tubeDensity
      (fun t => A i t ⁻¹' closedBall (z i t) w) (u i) x) ^ p) ≤
      Klocal * (Kflat * ENNReal.ofReal (2 + M*Real.sqrt n) ^ n * (∏ i, ∑' t, u i t) ^ p) := by
  obtain ⟨J, instJ, q, hcov, hdis, hmeas, hvol, hball, hdiam⟩ :=
    finite_ball_cell_partition n x₀ R b hb
  letI := instJ
  let U := fun i t => A i t ⁻¹' closedBall (z i t) w
  apply cell_local_estimate_of_budget volume (fun j => gridCube (q j) b)
    (closedBall x₀ R) hcov measurableSet_closedBall hmeas U u p Klocal
  · intro j
    refine le_trans ?_ (hlocal (fun i => cellMeetingWeight (U i) (u i)
      (gridCube (q j) b ∩ closedBall x₀ R)) (q j))
    apply lintegral_mono_set
    exact inter_subset_left.trans ((hball j).trans (closedBall_subset_closedBall (by nlinarith)))
  · apply perturbed_cylinder_cell_budget (fun j => gridCube (q j) b) hmeas hdis
      A Q z u x₀ R w δ (Real.sqrt n*b) M ((2+M*Real.sqrt n)*b) p hp hδ hA
      (by positivity) hQ (cylinder_cell_width_bound w δ R M (Real.sqrt n) b hw ha)
      hdiam (ENNReal.ofReal b ^ n)
      (Kflat * ENNReal.ofReal (2 + M*Real.sqrt n) ^ n * (∏ i, ∑' t, u i t) ^ p)
      (by positivity) (by finiteness) hvol
    convert hflat using 1
    rw [ENNReal.ofReal_mul (by positivity), mul_pow]
    ring

end N2Restriction

#print axioms N2Restriction.cylinder_ball_recurrence
