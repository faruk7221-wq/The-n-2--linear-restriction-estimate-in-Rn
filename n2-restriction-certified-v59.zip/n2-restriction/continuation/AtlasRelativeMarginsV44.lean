import continuation.GraphRelativeMarginsV44
import continuation.AtlasCellSupportV42

namespace N2Restriction
open MeasureTheory Set
open scoped NNReal

/-- A fixed atlas-wide support enlargement constant, independent of scale and selection. -/
noncomputable def PacketGraphAtlas.supportLoss {d : ℕ} {S : SmoothPatch (d + 1)}
    (T : PacketGraphAtlas S) : ℝ := 3 * (1 + ∑ j, ((T.graph j).lipConstant : ℝ))

theorem PacketGraphAtlas.supportLoss_bound {d : ℕ} {S : SmoothPatch (d + 1)}
    (T : PacketGraphAtlas S) (j : Fin T.size) :
    3 * (1 + ((T.graph j).lipConstant : ℝ)) ≤ T.supportLoss := by
  have h := Finset.single_le_sum (f := fun j : Fin T.size => ((T.graph j).lipConstant : ℝ))
    (fun j _ => NNReal.coe_nonneg _) (Finset.mem_univ j)
  dsimp [supportLoss]
  linarith

/-- Actual ambient atlas packets spend a single uniform margin loss relative
 to the input support; fixed buffer margins are not used here. -/
theorem PacketGraphAtlas.packet_relative_margin {d : ℕ} {S : SmoothPatch (d + 1)}
    (T : PacketGraphAtlas S) {r : ℝ}
    (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r) (hr : 0 < r)
    (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
    (V : Set (Ambient (d + 1))) (a : ℝ)
    (hf : ∀ j, HasFrequencySupport (T.graph j).surfaceMeasure (T.patch j).rotation
      (marginRegion V a) (f j)) (j : Fin T.size) (c : (Q j).centers) (ν : Fin d → ℤ) :
    HasFrequencySupport (Measure.hausdorffMeasure (d : ℝ)) id
      (marginRegion V (a - T.supportLoss * r))
      ((T.graph j).rotatedAmbientInput (T.patch j).rotation ((T.graph j).packet (Q j) hr (f j) c ν)) := by
  apply (T.graph j).rotatedAmbientInput_support
  apply ((T.graph j).packet_relative_margin (Q j) hr (f j) (T.patch j).rotation V a (hf j) c ν).mono
  apply marginRegion_antitone
  have h := mul_le_mul_of_nonneg_right (T.supportLoss_bound j) hr.le
  linarith

/-- Every cell, near/far, or repeatedly refined selection of the original
atlas packets retains the same margin. No fresh decomposition is performed. -/
theorem PacketGraphAtlas.cellInput_relative_margin {d : ℕ} {S : SmoothPatch (d + 1)}
    (T : PacketGraphAtlas S) {r : ℝ}
    (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r) (hr : 0 < r)
    (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
    (V : Set (Ambient (d + 1))) (a : ℝ)
    (hf : ∀ j, HasFrequencySupport (T.graph j).surfaceMeasure (T.patch j).rotation
      (marginRegion V a) (f j))
    (U : (j : Fin T.size) → (Q j).centers → Set (Fin d → ℤ)) :
    HasFrequencySupport (Measure.hausdorffMeasure (d : ℝ)) id
      (marginRegion V (a - T.supportLoss * r)) (T.cellInput Q hr f U) := by
  have hm := (isClosed_marginRegion V (a - T.supportLoss * r)).measurableSet
  apply HasFrequencySupport.sum_L2 _ _ hm
  intro j
  apply HasFrequencySupport.sum_L2 _ _ hm
  intro c
  apply HasFrequencySupport.tsum_L2 _ _ hm _ ((T.cap_packet_summable Q hr f j c).subtype (U j c))
  intro ν
  exact T.packet_relative_margin Q hr f V a hf j c ν.val

/-- Every selection from one original atlas decomposition is admissible at
all child radii, uniformly over inputs, cap families, and selections. -/
theorem PacketGraphAtlas.eventually_cellInput_child_margin {d : ℕ} {S : SmoothPatch (d + 1)}
    (T : PacketGraphAtlas S) (V : Set (Ambient (d + 1))) (m : ℝ) :
    ∀ᶠ R : ℝ in Filter.atTop, ∀ L : ℝ, 1 ≤ L → L ≤ R / 2 →
      ∀ (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support (R ^ (-1 / 2 : ℝ)))
      (hr : 0 < R ^ (-1 / 2 : ℝ))
      (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure),
      (∀ j, HasFrequencySupport (T.graph j).surfaceMeasure (T.patch j).rotation
        (marginRegion V (m - R ^ (-1 / 4 : ℝ))) (f j)) →
      ∀ (U : (j : Fin T.size) → (Q j).centers → Set (Fin d → ℤ)),
      HasFrequencySupport (Measure.hausdorffMeasure (d : ℝ)) id
        (marginRegion V (m - L ^ (-1 / 4 : ℝ))) (T.cellInput Q hr f U) := by
  filter_upwards [eventually_support_margin T.supportLoss] with R hR
  intro L hL hLR Q hr f hf U
  exact (T.cellInput_relative_margin Q hr f V _ hf U).mono
    (marginRegion_antitone V (by linarith [hR L hL hLR]))

end N2Restriction
#print axioms N2Restriction.PacketGraphAtlas.supportLoss_bound
#print axioms N2Restriction.PacketGraphAtlas.packet_relative_margin
#print axioms N2Restriction.PacketGraphAtlas.cellInput_relative_margin
#print axioms N2Restriction.PacketGraphAtlas.eventually_cellInput_child_margin
