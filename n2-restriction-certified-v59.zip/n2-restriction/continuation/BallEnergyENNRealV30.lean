import N2Restriction.SurfacePlancherel

namespace N2Restriction
open MeasureTheory Metric
open scoped NNReal ENNReal

/-- The proved local Plancherel estimate in the lower-integral form used by
Holder; representative and original L2 normalization are unchanged. -/
theorem HasBallEnergyBound.lintegral {n : ℕ} {μ : Measure (Ambient n)} [IsFiniteMeasure μ]
    {C : ℝ} (hC : 0 ≤ C) (h : HasBallEnergyBound μ C)
    (g : Lp ℂ 2 μ) (x₀ : Ambient n) {R : ℝ} (hR : 0 ≤ R) :
    (∫⁻ x in ball x₀ R, ‖extension μ id g x‖ₑ ^ (2 : ℝ)) ≤
      ENNReal.ofReal C * ENNReal.ofReal R * ‖g‖ₑ ^ 2 := by
  have hc := continuous_extension measurable_id ((Lp.memLp g).integrable (by norm_num))
  have hi : IntegrableOn (fun x => ‖extension μ id g x‖ ^ 2) (ball x₀ R) volume :=
    ((hc.norm.pow 2).continuousOn.integrableOn_compact (isCompact_closedBall x₀ R)).mono_set
      ball_subset_closedBall
  have hh := ENNReal.ofReal_le_ofReal (h g x₀ R hR)
  rw [ofReal_integral_eq_lintegral_ofReal hi (Filter.Eventually.of_forall (fun x => sq_nonneg _))] at hh
  simpa only [ENNReal.ofReal_mul (mul_nonneg hC hR), ENNReal.ofReal_mul hC,
    ENNReal.ofReal_pow (norm_nonneg _), ofReal_norm_eq_enorm, ENNReal.rpow_two] using hh

/-- Every original fixed patch has one nonnegative coefficient for its
lower-integral L2 ball bound, uniform in radius, center and input. -/
theorem SmoothPatch.local_Plancherel_lintegral {d : ℕ} (S : SmoothPatch (d + 1)) :
    ∃ C : ℝ≥0, ∀ (g : Lp ℂ 2 S.surfaceMeasure) (x₀ : Ambient (d + 1)) (R : ℝ), 0 ≤ R →
      (∫⁻ x in ball x₀ R, ‖extension S.surfaceMeasure id g x‖ₑ ^ (2 : ℝ)) ≤
        (C : ℝ≥0∞) * ENNReal.ofReal R * ‖g‖ₑ ^ 2 := by
  haveI : IsFiniteMeasure S.surfaceMeasure := S.isFiniteMeasure_surfaceMeasure (by omega)
  obtain ⟨C, hC, hb⟩ := S.local_Plancherel_ball
  refine ⟨⟨C, hC⟩, ?_⟩
  intro g x₀ R hR
  simpa only [← ENNReal.ofReal_coe_nnreal] using hb.lintegral hC g x₀ hR

end N2Restriction

#print axioms N2Restriction.HasBallEnergyBound.lintegral
#print axioms N2Restriction.SmoothPatch.local_Plancherel_lintegral
