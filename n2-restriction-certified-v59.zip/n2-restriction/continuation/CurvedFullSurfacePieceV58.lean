import continuation.LocalizedRectangleV58
import continuation.SurfaceChartLocalizationV58
import continuation.ActualAffineSurfaceChartV57
import continuation.SlicingProductBoxV57
namespace N2Restriction
open Set Filter Metric MeasureTheory
set_option maxHeartbeats 1200000

/-- A covered curved graph germ supplies an actual weighted full-surface
estimate on a spatial and angular neighborhood. No chart replacement is assumed. -/
theorem SmoothPatch.curved_full_surface_piece {d : ℕ} (harea : SmoothGraphAreaFormulaInput)
    (S : SmoothPatch (d+2)) (x θ₀ : Ambient (d+2))
    (A : Ambient (d+2) ≃ₗᵢ[ℝ] Ambient (d+2)) (Φ : Ambient (d+1) → ℝ)
    (hΦ : ContDiff ℝ (⊤ : ℕ∞) Φ) (u v : Ambient (d+1))
    (hgerm : ∀ᶠ y in nhds u, A (graphPoint y (Φ y)) ∈ S.extendedSurface)
    (hcover : ∀ W : Set (Ambient (d+1)), W ∈ nhds u → ∀ᶠ z in nhds x,
      z ∈ S.extendedSurface → z ∈ (fun y => A (graphPoint y (Φ y))) '' W)
    {r c : ℝ} (hr : 0 < r) (hc : 0 < c)
    (hphase : ∀ y θ t, ‖y-u‖ < r → ‖θ-θ₀‖ < r → |t| < r →
      c ≤ |deriv (deriv (rotatedGraphLinePhase A Φ v y θ)) t|) :
    ∃ (V : Set (Ambient (d+2))) (δ : ℝ), IsOpen V ∧ x ∈ V ∧ 0 < δ ∧
      ∀ (ψ : Ambient (d+2) → ℂ), ContDiff ℝ (⊤ : ℕ∞) ψ → HasCompactSupport ψ →
      ∀ (β : Ambient (d+2) → ℝ), ContDiff ℝ (⊤ : ℕ∞) β → tsupport β ⊆ V →
      ∃ C : ℝ, 0 ≤ C ∧ ∀ θ ∈ closedBall θ₀ δ, ∀ freq : ℝ, 0 < freq →
        ‖extension ((Measure.hausdorffMeasure ((d+1 : ℕ) : ℝ)).restrict S.extendedSurface)
          id (fun z => ψ z*(β z : ℂ)) (freq • θ)‖ ≤ C*freq^(-(1/2 : ℝ)) := by
  obtain ⟨R,ρ,hρ,hR,hbox⟩ := exists_curved_slicing_product_box A Φ u v θ₀ hr hc hphase
  have hv : v ≠ 0 := by
    intro he
    have hn := slicing_direction_ne_zero_of_second A Φ v u θ₀ 0
      (abs_pos.mp (hc.trans_le (hphase u θ₀ 0 (by simpa using hr) (by simpa using hr) (by simpa using hr))))
    exact hn he
  have hvp := norm_pos_iff.mpr hv
  let G : Ambient (d+1) → Ambient (d+2) := fun y => A (graphPoint y (Φ y))
  have hG : Continuous G := A.continuous.comp
    (graphPointCLM.continuous.comp (continuous_id.prodMk hΦ.continuous))
  obtain ⟨δ,V,hd,hdρ,hVo,hx,hcompact,hsub,hVC⟩ :=
    exists_localized_affine_rectangle S G hG u x hgerm hcover R hvp hρ
  refine ⟨V,δ,hVo,hx,hd,?_⟩
  intro ψ hψ hs β hβ hβV
  have hbound : ∀ θ ∈ closedBall θ₀ δ, ∀ y ∈ closedBall (0 : Ambient d) δ,
      ∀ t ∈ Icc (-δ) δ,
      c ≤ |deriv (deriv (fun s => inner ℝ θ
        (A (graphPoint (horizontalAffine u R ‖v‖ hvp.ne' (graphPoint y s))
          (Φ (horizontalAffine u R ‖v‖ hvp.ne' (graphPoint y s))))))) t| := by
    intro θ hθ y hy t ht
    exact hbox θ (closedBall_subset_closedBall hdρ hθ) y
      (closedBall_subset_closedBall hdρ hy) t ⟨by linarith [ht.1],by linarith [ht.2]⟩
  obtain ⟨C,hC,hdecay⟩ := exists_actual_affine_surface_chart_half_decay harea A Φ hΦ
    ψ hψ hs β hβ u R hvp _ (isCompact_closedBall _ _) _ (-δ) δ (by linarith) hc hbound
  refine ⟨C,hC,?_⟩
  intro θ hθ freq hf
  have he := S.extension_localize_to_chart _ V hsub hVC ψ β hβV (freq • θ)
  have hm : ((d+2 : ℕ) : ℝ)-1 = ((d+1 : ℕ) : ℝ) := by push_cast; ring
  rw [hm] at he
  rw [he]
  exact hdecay θ hθ freq hf
end N2Restriction
#print axioms N2Restriction.SmoothPatch.curved_full_surface_piece
