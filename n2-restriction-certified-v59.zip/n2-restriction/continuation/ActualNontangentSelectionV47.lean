import continuation.AtlasBallProductV47
import continuation.AtlasCubeTangentStripV46

namespace N2Restriction
open Set Metric

/-- Section 7's nontangent selection: among the same original stage packets,
retain those meeting Omega in this ball and failing angular tangency (7.1). -/
def PacketGraphAtlas.actualNontangentSelection {d : ℕ} {S : SmoothPatch (d+1)}
    (A : PacketGraphAtlas S) {r : ℝ}
    (Q : (j : Fin A.size) → CoordinateCapFamily (A.patch j).support r)
    (U : (j : Fin A.size) → (Q j).centers → Set (Fin d → ℤ))
    (Z : Set (Ambient (d+1))) (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1)))
    (c : Ambient (d+1)) (ρ b C₀ R w : ℝ) (Ω : Set (Ambient (d+1))) :
    (j : Fin A.size) → (Q j).centers → Set (Fin d → ℤ) :=
  fun j a => {ν | ν ∈ U j a ∧
    (A.originalPacketTube j a r ν R w ∩ (Ω ∩ ball c ρ)).Nonempty ∧
    ¬ PacketTangentInBall Z (A.originalPacketTube j a r ν R w) T
      (A.cellAxisDirection j a) c ρ b C₀}

end N2Restriction
