import continuation.DescentMassPowerAdapterV53
import continuation.SeparateScaleRecurrenceV53
namespace N2Restriction
open MeasureTheory Filter
open scoped ENNReal BigOperators
section
variable {n k : ℕ} {Ω : Fin k → Type*} [∀ i, MeasurableSpace (Ω i)]
variable (μ : ∀ i, Measure (Ω i)) [∀ i, IsFiniteMeasure (μ i)]
variable (ζ : ∀ i, Ω i → Ambient n) (hζ : ∀ i, Measurable (ζ i))
variable (U : Fin k → Set (Ambient n)) (margin : ℝ)

include hζ

/-- Close the mass inequality actually obtained by the descent. The fixed
child scale and analytic coefficient stay separate, so no radius monotonicity
of the changing frequency-margin class is used. -/
theorem margin_growth_of_descent_mass {p τ σ lam δ : ℝ}
    (hp : 0 < p) (hτ : 0 < τ) (hτsmall : τ < 1/2) (hlam : 0 < lam)
    (hσ : 0 ≤ σ) (hδ : 0 < δ) (hσδ : σ < δ)
    (K : ENNReal) (hK : K ≠ ∞)
    (hmass : ∀ᶠ R : ℝ in atTop,
      ∀ g : (i : Fin k) → Lp ℂ 2 (μ i),
      MarginAdmissible μ ζ U margin R (fun i => g i) →
      (∫⁻ x in Metric.ball 0 R, ‖extensionProduct μ ζ (fun i => g i) x‖ₑ^p) ≤
        descentMassCoefficient μ ζ U margin p τ σ lam R K*(∏ i, ENNReal.ofReal ‖g i‖)^p) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ R : ℝ, 1 ≤ R →
      (marginLocalConstant μ ζ U margin p R).toReal ≤ C*R^δ := by
  let C : ℝ := max 1 K.toReal
  have hC : 0 < C := lt_of_lt_of_le zero_lt_one (le_max_left _ _)
  have hrec : ∀ᶠ R : ℝ in atTop,
      marginPowerConstant μ ζ U margin p R ≤
        1/4*marginPowerConstant μ ζ U margin p (R/2)+
        C*marginPowerConstant μ ζ U margin p (R^(1-τ))+
        C*marginPowerConstant μ ζ U margin p (lam*R^(1/2+τ))+(2*K.toReal)*R^(σ*p) := by
    filter_upwards [hmass,eventually_ge_atTop (1 : ℝ)] with R hm hR
    have hh := margin_power_of_descent_Lp_mass μ ζ U margin hζ hp (by linarith : 0 ≤ R) K hK hm
    have hpow : 1 ≤ R^(σ*p) := Real.one_le_rpow hR (mul_nonneg hσ hp.le)
    have hA (r : ℝ) : 0 ≤ marginPowerConstant μ ζ U margin p r := Real.rpow_nonneg ENNReal.toReal_nonneg _
    have hc : K.toReal ≤ C := le_max_right _ _
    nlinarith [mul_le_mul_of_nonneg_right hc (hA (R^(1-τ))),
      mul_le_mul_of_nonneg_right hc (hA (lam*R^(1/2+τ))),ENNReal.toReal_nonneg (a := K)]
  obtain ⟨H,hH,hbound⟩ := power_recurrence_growth_separate_scale
    (marginPowerConstant μ ζ U margin p) C lam (2*K.toReal) (δ*p) (σ*p) τ
    hC hlam (by positivity) (mul_pos hδ hp) (mul_lt_mul_of_pos_right hσδ hp) hτ hτsmall
    (marginPowerConstant_locally_bounded μ ζ U margin hp) hrec
  exact ⟨H^(1/p),Real.rpow_nonneg hH _,
    growth_from_power_bound (fun R => (marginLocalConstant μ ζ U margin p R).toReal) hp hH
      (fun _ _ => ENNReal.toReal_nonneg) hbound⟩
end
end N2Restriction
#print axioms N2Restriction.margin_growth_of_descent_mass
