import continuation.NormalizedFiberInputsV29

namespace N2Restriction
open MeasureTheory
open scoped NNReal ENNReal

namespace StripChartAmplitude
variable {n : ℕ} {S : SmoothPatch n} {Q : Ambient n →L[ℝ] ℝ × ℝ} {z : Ambient n}
  {δ r ρ s : ℝ} {B : ℕ → ℝ} {c C : ℝ≥0} {L α β ε : ℝ}
  {F : MeasuredTubularChart S Q z δ r ρ s B c C L}
  {E : ChartNormalCoordinates F α β}
  {g : Lp ℂ 2 ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier)}

/-- Fiber energy is a measurable function of the normal coordinate. -/
theorem measurable_fiber_energy (A : StripChartAmplitude F E g ε) :
    Measurable (fun u => ∫⁻ v, (‖A.fiberAmplitude u v‖ₑ)^2) := by
  apply Measurable.lintegral_prod_right
  have hW := A.measurable_weight
  have hf := A.measurable_input
  change Measurable (fun p => ‖A.weight (E.equiv.symm p) • A.input (E.equiv.symm p)‖ₑ ^ 2)
  exact ((hW.comp E.equiv.symm.continuous.measurable).smul
    (hf.comp E.equiv.symm.continuous.measurable)).enorm.pow_const 2

/-- The norms of the actual L2 equivalence classes form an a.e. measurable
scalar family; no measurable representative of the L2-valued map is assumed. -/
theorem aemeasurable_fiberInput_enorm (A : StripChartAmplitude F E g ε) :
    AEMeasurable (fun u => ‖A.fiberInput u‖ₑ) volume := by
  have hm : AEMeasurable (fun u => ‖A.fiberInput u‖ₑ ^ 2) volume :=
    A.measurable_fiber_energy.aemeasurable.congr (by
      filter_upwards [A.fiberInput_enorm_sq_ae] with u hu
      exact hu.symm)
  have hr := hm.pow_const (1 / 2 : ℝ)
  convert hr using 1
  funext u
  rw [← ENNReal.rpow_natCast, ← ENNReal.rpow_mul]
  norm_num

/-- Haar normalization retains measurability of the actual norm budget. -/
theorem aemeasurable_normalizedFiberInput_enorm (A : StripChartAmplitude F E g ε) :
    AEMeasurable (fun u => ‖A.normalizedFiberInput u‖ₑ) volume := by
  simp_rw [A.normalizedFiberInput_enorm]
  exact aemeasurable_const.mul A.aemeasurable_fiberInput_enorm

/-- The scalar normal-parameter norm budget is a genuine Bochner-integrable
real function, not just a possibly nonmeasurable lower integral. -/
theorem integrable_normalizedFiberInput_norm (A : StripChartAmplitude F E g ε) :
    Integrable (fun u => ‖A.normalizedFiberInput u‖) volume := by
  have hm : AEMeasurable (fun u => ‖A.normalizedFiberInput u‖) volume := by
    simpa only [toReal_enorm] using A.aemeasurable_normalizedFiberInput_enorm.ennreal_toReal
  refine ⟨hm.aestronglyMeasurable, ?_⟩
  change (∫⁻ u, ‖‖A.normalizedFiberInput u‖‖ₑ) < ∞
  simp only [enorm_norm]
  exact A.normalizedFiberInput_thickness.trans_lt (lt_top_iff_ne_top.mpr
    (ENNReal.mul_ne_top (ENNReal.mul_ne_top ENNReal.ofReal_ne_top
      (ENNReal.rpow_ne_top_of_nonneg (by norm_num) ENNReal.coe_ne_top)) (by rw [Lp.enorm_def]; exact (Lp.memLp g).2.ne)))

/-- The squared actual input norms are integrable as well, with the energy
budget already proved for these same inputs. -/
theorem integrable_normalizedFiberInput_norm_sq (A : StripChartAmplitude F E g ε) :
    Integrable (fun u => ‖A.normalizedFiberInput u‖ ^ 2) volume := by
  have hm := A.integrable_normalizedFiberInput_norm.aestronglyMeasurable.pow 2
  refine ⟨hm, ?_⟩
  change (∫⁻ u, ‖‖A.normalizedFiberInput u‖ ^ 2‖ₑ) < ∞
  simp only [enorm_pow, enorm_norm]
  exact A.normalizedFiberInput_energy.trans_lt (lt_top_iff_ne_top.mpr
    (ENNReal.mul_ne_top ENNReal.coe_ne_top (ENNReal.pow_ne_top (by rw [Lp.enorm_def]; exact (Lp.memLp g).2.ne))))

end StripChartAmplitude
end N2Restriction

#print axioms N2Restriction.StripChartAmplitude.aemeasurable_fiberInput_enorm
#print axioms N2Restriction.StripChartAmplitude.aemeasurable_normalizedFiberInput_enorm
#print axioms N2Restriction.StripChartAmplitude.integrable_normalizedFiberInput_norm
#print axioms N2Restriction.StripChartAmplitude.integrable_normalizedFiberInput_norm_sq
#print axioms N2Restriction.StripChartAmplitude.measurable_fiber_energy
