import continuation.GeneralExternalKakeyaV36

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal BigOperators

/-- Compact families of independent unit tuples have a common proved Kakeya
aperture and coefficient, uniform over all admissible scales. This applies
both to the full tuple and to compact unlocalized subensembles. -/
theorem compact_independent_weighted_kakeya {m k : ℕ} (hk : 2 ≤ k)
    (K : Set (Fin k → Ambient m)) (hK : IsCompact K)
    (hunit : ∀ v ∈ K, ∀ i, ‖v i‖ = 1) (hindep : ∀ v ∈ K, LinearIndependent ℝ v)
    (η : ℝ) (hη : 0 < η) :
    ∃ ε C : ℝ, 0 < ε ∧ 0 ≤ C ∧ ∀ v ∈ K, ∀ R w : ℝ, 1 ≤ w → w < R →
      FiniteDirectionalKakeya (volume.restrict (ball 0 R)) v ε w (1/((k:ℝ)-1))
        (ENNReal.ofReal (C*R^η*w^((m:ℝ)-η))) := by
  let A := {s : ℝ × ℝ // 1 ≤ s.2 ∧ s.2 < s.1}
  let μ := fun s : A => volume.restrict (ball (0 : Ambient m) s.val.1)
  let w := fun s : A => s.val.2
  let p := fun _ : A => 1/((k:ℝ)-1)
  let L := fun s : A => ENNReal.ofReal (s.val.1^η*s.val.2^((m:ℝ)-η))
  have hlocal : ∀ v ∈ K, ∃ ε C : ℝ, 0 < ε ∧ 0 ≤ C ∧ ∀ s : A,
      FiniteDirectionalKakeya (μ s) v ε (w s) (p s) (ENNReal.ofReal C*L s) := by
    intro v hv
    obtain ⟨ε,C,hε,hC,hb⟩ := weighted_kakeya_external_all_dimensions m k hk v (hunit v hv) (hindep v hv) η hη
    refine ⟨ε,C,hε,hC,fun s => ?_⟩
    simpa only [μ,w,p,L,← ENNReal.ofReal_mul hC,mul_assoc] using hb s.val.1 s.val.2 s.property.1 s.property.2
  obtain ⟨ε,C,hε,hC,hb⟩ := compact_uniform_directional_kakeya μ w p L hK hlocal
  refine ⟨ε,C,hε,hC,?_⟩
  intro v hv R b hb1 hbR
  simpa only [μ,w,p,L,← ENNReal.ofReal_mul hC,mul_assoc] using hb v hv (⟨(R,b),hb1,hbR⟩ : A)

end N2Restriction

#print axioms N2Restriction.compact_independent_weighted_kakeya
