import continuation.UnitDirectionLineKakeyaV35
import continuation.FlatDependentBlockV35

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal BigOperators

/-- A proved fixed-directional-neighborhood line Kakeya estimate for every
unit tuple lying in complementary reference blocks. The flat hypothesis is
discharged, and the neighborhood precedes both the coordinate map and the
choice of unit reference vectors. -/
theorem uniform_directional_line_dependent_blocks (m n : ℕ) (d : Fin (n+2) → ℕ)
    (hd : (∑ i, d i) = m) (M : ℝ) (hM : 1 ≤ M) (η : ℝ) (hη : 0 < η) :
    ∃ C : ℝ≥0∞, 0 < C ∧ C ≠ ⊤ ∧ ∃ ε : ℝ, 0 < ε ∧
      ∀ e : Ambient m ≃L[ℝ] (∀ i, Ambient (d i)),
      ‖e.toContinuousLinearMap‖ ≤ M → ‖e.symm.toContinuousLinearMap‖ ≤ M →
      ∀ (v₀ : Fin (n+2) → Ambient m), (∀ i, ‖v₀ i‖ = 1) →
      (∀ i, dependentBlockProjection d e i (v₀ i) = 0) →
      ∀ (T : Fin (n+2) → Type) [∀ i, Countable (T i)]
      (v a : ∀ i, T i → Ambient m), (∀ i t, ‖v i t-v₀ i‖ ≤ ε) →
      ∀ (u : ∀ i, T i → ℝ≥0∞) (x₀ : Ambient m) (R w : ℝ), 0 < w → w ≤ R →
      (∫⁻ x in closedBall x₀ R, (∏ i, tubeDensity
        (fun t => affineLineTube (a i t) (v i t) w) (u i) x) ^ (1/((n:ℝ)+1))) ≤
        C * ENNReal.ofReal R^η * ENNReal.ofReal w^((m:ℝ)-η) *
          (∏ i, ∑' t, u i t) ^ (1/((n:ℝ)+1)) := by
  obtain ⟨K,hK,hKfin,hflat⟩ := uniform_flat_dependent_block_input m n d hd M (by linarith)
  obtain ⟨C,hC,hCfin,ε,hε,hb⟩ := uniform_unit_directional_line_kakeya_from_flat m (Fin (n+2))
    (fun i => ∀ j, Ambient (d (i.succAbove j))) (1/((n:ℝ)+1)) M
    (by positivity) hM K hK hKfin η hη
  refine ⟨C,hC,hCfin,ε,hε,?_⟩
  intro e he hei
  exact hb (dependentBlockProjection d e)
    (fun i => (dependentBlockProjection_norm_le d e i).trans he) (hflat e he hei)

end N2Restriction

#print axioms N2Restriction.uniform_directional_line_dependent_blocks
