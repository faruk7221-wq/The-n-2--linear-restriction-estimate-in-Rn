import continuation.AtlasLabelBudgetV42
import continuation.CheckedCellSelectionV41

namespace N2Restriction
open MeasureTheory
open scoped BigOperators ENNReal

/-- Simultaneous substantial-cell selection for the actual atlas inputs.
The only mass/count premises belong to the external reset partition; all
packet synthesis and original-input energy estimates are discharged here.
Positive original norms isolate the nonzero-mass branch. -/
theorem atlas_substantial_cell_selection {d k : ℕ} (S : Fin k → SmoothPatch (d+1))
    (T : (i : Fin k) → PacketGraphAtlas (S i)) :
    ∃ B : Fin k → ℝ, (∀ i, 1 ≤ B i) ∧
      ∀ {m : ℕ} {C : Type*} [Fintype C] [Nonempty C] {r : ℝ}
        (Q : (i : Fin k) → (j : Fin (T i).size) → CoordinateCapFamily ((T i).patch j).support r)
        (hr : 0 < r) (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure)
        (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure),
      (∀ i, 0 < ‖g i‖) → (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
      ∀ (A : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ))
        (L : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers →
          (Fin d → ℤ) → Finset (Fin m → Bool))
        (N : Fin k → ℝ), (∀ i, 0 < N i) →
      (∀ i j a ν, ν ∈ A i j a → ((L i j a ν).card : ENNReal) ≤ ENNReal.ofReal (N i)) →
      ∀ (label : C → (Fin m → Bool)), Function.Injective label →
      ∀ (mass : C → ℝ) {M θ H : ℝ}, 0 < M → 0 < θ → 0 < H →
      θ*M ≤ ∑ c, mass c → (∀ c, mass c ≤ H*M/Fintype.card C) →
      ∃ c, θ*M/(2*Fintype.card C) ≤ mass c ∧
        ∀ i, ‖(T i).cellInput (Q i) hr (f i)
          (fun j a => {ν | ν ∈ A i j a ∧ label c ∈ L i j a ν})‖^2 <
          (2*H*((k : ℝ)+1)/(θ*Fintype.card C))*(B i*N i*‖g i‖^2) := by
  classical
  choose B₀ hB₀ hb using fun i => (T i).original_labelled_cell_budget
  let B := fun i => max 1 (B₀ i)
  refine ⟨B, fun _ => le_max_left _ _, ?_⟩
  intro m C _ _ r Q hr g f hg he A L N hN hl label hinj mass M θ H hM hθ hH htotal hupper
  have hB i : 0 < B i := lt_of_lt_of_le zero_lt_one (le_max_left _ _)
  have hbudget i : (∑' σ : Fin m → Bool, ENNReal.ofReal (‖(T i).cellInput (Q i) hr (f i)
      (fun j a => {ν | ν ∈ A i j a ∧ σ ∈ L i j a ν})‖^2)) ≤
      ENNReal.ofReal (B i*N i*‖g i‖^2) := by
    have hh := hb i (Q i) hr (g i) (f i) (he i) (A i) (L i) (ENNReal.ofReal (N i)) (hl i)
    rw [ENNReal.ofReal_mul (mul_pos (hB i) (hN i)).le, ENNReal.ofReal_mul (hB i).le]
    exact hh.trans (mul_le_mul_right' (mul_le_mul_right'
      (ENNReal.ofReal_le_ofReal (le_max_right 1 (B₀ i))) _) _)
  simpa only [Fintype.card_fin] using substantial_cell_from_checked_budgets
    (fun _ : Fin k => Lp ℂ 2 (Measure.hausdorffMeasure (d : ℝ) : Measure (Ambient (d+1))))
    label hinj (fun i σ => (T i).cellInput (Q i) hr (f i)
      (fun j a => {ν | ν ∈ A i j a ∧ σ ∈ L i j a ν})) mass hM hθ hH htotal hupper
    (fun i => B i*N i*‖g i‖^2)
    (fun i => mul_pos (mul_pos (hB i) (hN i)) (sq_pos_of_pos (hg i))) hbudget

end N2Restriction
#print axioms N2Restriction.atlas_substantial_cell_selection
