import continuation.ActualTangentSplitV47

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal

/-- Exact expansion over the tangent/nontangent choices of the retained
original inputs in one covering ball. False denotes nontangent. -/
theorem actual_retained_binary_expansion {d k : ℕ} {S : Fin k → SmoothPatch (d+1)}
    (A : (i : Fin k) → PacketGraphAtlas (S i)) {r : ℝ}
    (Q : (i : Fin k) → (j : Fin (A i).size) → CoordinateCapFamily ((A i).patch j).support r)
    (hr : 0 < r) (hsmall : ∀ i, r ≤ (A i).capRadius)
    (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure)
    (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin d → ℤ))
    (Z : Set (Ambient (d+1))) (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1)))
    (c : Ambient (d+1)) (ρ b C₀ R w : ℝ) (Ω : Set (Ambient (d+1))) (x : Ambient (d+1)) :
    extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
      (fun i => (A i).cellInput (Q i) hr (f i) ((A i).actualRetainedSelection (Q i) (U i) c ρ R w Ω)) x =
    ∑ σ : Fin k → Bool, extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
      (fun i => (A i).cellInput (Q i) hr (f i)
        (if σ i then (A i).actualTangentSelection (Q i) (U i) Z T c ρ b C₀ R w Ω
         else (A i).actualNontangentSelection (Q i) (U i) Z T c ρ b C₀ R w Ω)) x := by
  unfold extensionProduct
  simp_rw [(fun i => (A i).actual_retained_extension_split (Q i) hr (hsmall i)
    (f i) (U i) Z T c ρ b C₀ R w Ω x)]
  have he (i : Fin k) :
      extension (Measure.hausdorffMeasure (d : ℝ)) id ((A i).cellInput (Q i) hr (f i)
        ((A i).actualTangentSelection (Q i) (U i) Z T c ρ b C₀ R w Ω)) x +
      extension (Measure.hausdorffMeasure (d : ℝ)) id ((A i).cellInput (Q i) hr (f i)
        ((A i).actualNontangentSelection (Q i) (U i) Z T c ρ b C₀ R w Ω)) x =
      ∑ s : Bool, extension (Measure.hausdorffMeasure (d : ℝ)) id ((A i).cellInput (Q i) hr (f i)
        (if s then (A i).actualTangentSelection (Q i) (U i) Z T c ρ b C₀ R w Ω
         else (A i).actualNontangentSelection (Q i) (U i) Z T c ρ b C₀ R w Ω)) x := by simp
  simp_rw [he]
  exact Fintype.prod_sum _

/-- The all-nontangent term is singled out; every remaining binary term
has a tangent family, exactly as in (7.2)--(7.3). -/
theorem actual_retained_product_majorant {d k : ℕ} {S : Fin k → SmoothPatch (d+1)}
    (A : (i : Fin k) → PacketGraphAtlas (S i)) {r : ℝ}
    (Q : (i : Fin k) → (j : Fin (A i).size) → CoordinateCapFamily ((A i).patch j).support r)
    (hr : 0 < r) (hsmall : ∀ i, r ≤ (A i).capRadius)
    (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure)
    (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin d → ℤ))
    (Z : Set (Ambient (d+1))) (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1)))
    (c : Ambient (d+1)) (ρ b C₀ R w : ℝ) (Ω : Set (Ambient (d+1))) (x : Ambient (d+1)) :
    ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
      (fun i => (A i).cellInput (Q i) hr (f i) ((A i).actualRetainedSelection (Q i) (U i) c ρ R w Ω)) x‖ₑ ≤
    ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
      (fun i => (A i).cellInput (Q i) hr (f i) ((A i).actualNontangentSelection (Q i) (U i) Z T c ρ b C₀ R w Ω)) x‖ₑ +
    ∑ σ ∈ (Finset.univ : Finset (Fin k → Bool)).erase (fun _ => false),
      ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
        (fun i => (A i).cellInput (Q i) hr (f i)
          (if σ i then (A i).actualTangentSelection (Q i) (U i) Z T c ρ b C₀ R w Ω
           else (A i).actualNontangentSelection (Q i) (U i) Z T c ρ b C₀ R w Ω)) x‖ₑ := by
  rw [actual_retained_binary_expansion A Q hr hsmall f U Z T c ρ b C₀ R w Ω x]
  apply (enorm_sum_le _ _).trans_eq
  rw [← Finset.add_sum_erase _ _ (Finset.mem_univ (fun _ : Fin k => false))]
  simp only [Bool.false_eq_true, ↓reduceIte]

end N2Restriction
#print axioms N2Restriction.actual_retained_binary_expansion
#print axioms N2Restriction.actual_retained_product_majorant
