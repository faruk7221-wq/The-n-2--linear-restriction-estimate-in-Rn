import continuation.ActualTerminalIntegralV50
import continuation.ActualTerminalProductErrorV47
namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal

/-- Full original selected-product decomposition into the actual positive
nontangent and tangent sums, including the internally proved rapid error.
There is no cardinality loss from the physical covering balls. -/
theorem actual_terminal_full_integral {d k : ℕ}
    (S : Fin k → SmoothPatch (d+1)) (A : (i : Fin k) → PacketGraphAtlas (S i))
    {τ : ℝ} (hτ : 0 < τ) :
    ∃ M : ℝ, 1 ≤ M ∧ ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ N : ℝ, ∃ C : ℝ, 0 ≤ C ∧
    ∀ R : ℝ, R₀ ≤ R →
    ∀ (Q : (i : Fin k) → (j : Fin (A i).size) →
      CoordinateCapFamily ((A i).patch j).support (R^(-1/2 : ℝ)))
      (hr : 0 < R^(-1/2 : ℝ)), (∀ i, R^(-1/2 : ℝ) ≤ (A i).capRadius) →
    ∀ B : ℝ, 0 ≤ B → (∀ i j, ((Q i j).centers.card : ℝ) ≤ B*R^((d : ℝ)/2)) →
    ∀ (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure)
      (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure),
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
    ∀ (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin d → ℤ))
      (L : ℕ) (Z : Set (Ambient (d+1))) (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1)))
      (Ω : Set (Ambient (d+1))) (c : Fin L → Ambient (d+1)) (ρ b C₀ : ℝ)
      (p : ℝ), 0 < p → p ≤ 1 → MeasurableSet Ω → Ω ⊆ closedBall 0 R →
    Ω ⊆ ⋃ l, ball (c l) ρ →
    (∫⁻ x in Ω, ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
      (fun i => (A i).cellInput (Q i) hr (f i) (U i)) x‖ₑ^p) ≤
      (∫⁻ x, (atlasBallProductSum A Q hr f
        (fun l i => (A i).actualNontangentSelection (Q i) (U i) Z T (c l) ρ b C₀ R (R^(1/2+τ)/10) Ω) c ρ Ω x)^p) +
      (∫⁻ x, (actualTangentSum A Q hr f U Z T c ρ b C₀ R (R^(1/2+τ)/10) Ω x)^p) +
      (ENNReal.ofReal ((k : ℝ)*(C*Real.sqrt B*R^(-N))*M^k*∏ i, ‖g i‖))^p*volume Ω := by
  obtain ⟨M,hM,R₀,hR₀,ht⟩ := actual_terminal_product_error S A hτ
  refine ⟨M,hM,R₀,hR₀,fun N => ?_⟩
  obtain ⟨C,hC,hc⟩ := ht N
  refine ⟨C,hC,?_⟩
  intro R hR Q hr hsmall B hB hcount g f he U L Z T Ω c ρ b C₀ p hp hp1 hΩ hΩR hcover
  apply actual_terminal_integral_majorant A Q hr hsmall f U Z T c ρ b C₀ R (R^(1/2+τ)/10) Ω hp hp1 hcover _ hΩ
  intro l x hx
  have hxR : ‖x‖ ≤ R := by
    have hh := hΩR hx.1
    simpa only [mem_closedBall,dist_zero_right] using hh
  exact hc R hR Q hr hsmall B hB hcount g f he U Ω (c l) ρ x hxR hx

end N2Restriction
#print axioms N2Restriction.actual_terminal_full_integral
