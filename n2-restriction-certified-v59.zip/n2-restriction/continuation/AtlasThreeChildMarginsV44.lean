import continuation.AtlasFamilyChildMarginV44
namespace N2Restriction
open MeasureTheory Set
/-- All three child scales from Section 8 retain the original input margin
under arbitrary selections of its single R-scale packet decomposition. -/
theorem eventually_atlas_three_children_admissible {d k : ℕ} (S : Fin k → SmoothPatch (d+1))
    (T : (i : Fin k) → PacketGraphAtlas (S i))
    (V : Fin k → Set (Ambient (d+1))) (m : ℝ)
    {τ C : ℝ} (hτ : 0 < τ) (hτsmall : τ < 1 / 2) (hC : 0 < C) :
    ∀ᶠ R : ℝ in Filter.atTop,
      ∀ (Q : (i : Fin k) → (j : Fin (T i).size) →
        CoordinateCapFamily ((T i).patch j).support (R ^ (-1 / 2 : ℝ)))
      (hr : 0 < R ^ (-1 / 2 : ℝ))
      (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure),
      (∀ i j, HasFrequencySupport ((T i).graph j).surfaceMeasure ((T i).patch j).rotation
        (marginRegion (V i) (m - R ^ (-1 / 4 : ℝ))) (f i j)) →
      ∀ (U : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ)),
      MarginAdmissible (fun i => (T i).bufferMeasure) (fun _ => id) V m (R/2)
        (fun i => (T i).bufferInput ((T i).cellInput (Q i) hr (f i) (U i))) ∧
      MarginAdmissible (fun i => (T i).bufferMeasure) (fun _ => id) V m (R^(1-τ))
        (fun i => (T i).bufferInput ((T i).cellInput (Q i) hr (f i) (U i))) ∧
      MarginAdmissible (fun i => (T i).bufferMeasure) (fun _ => id) V m (C*R^(1/2+τ))
        (fun i => (T i).bufferInput ((T i).cellInput (Q i) hr (f i) (U i))) := by
  filter_upwards [eventually_atlas_cell_admissible S T V m,
    eventually_children hτ hτsmall hC] with R hR hc
  intro Q hr f hf U
  exact ⟨hR _ hc.1 le_rfl Q hr f hf U,
    hR _ hc.2.1 hc.2.2.1 Q hr f hf U,
    hR _ hc.2.2.2.1 hc.2.2.2.2 Q hr f hf U⟩

end N2Restriction
#print axioms N2Restriction.eventually_atlas_three_children_admissible
