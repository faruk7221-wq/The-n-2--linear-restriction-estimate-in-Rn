import continuation.AtlasFeasibleCountsV45
import continuation.AtlasNonemptySelectionV45
import continuation.NonwallDegreeChoiceV43

namespace N2Restriction
open Set MeasureTheory
open scoped ENNReal

/-- The feasible-count inequality (6.5) follows from actual nonzero selected
extension mass and the near/far classification, with a scale-independent angle. -/
theorem atlas_nonzero_mass_feasible_counts {k : ℕ} (S : Fin k → SmoothPatch (k+2))
    (T : (i : Fin k) → PacketGraphAtlas (S i))
    {ν κ : ℝ} (hgeo : GeometricHypotheses S ν κ) :
    ∃ γ₀ : ℝ, 0 < γ₀ ∧ ∀ {r γ : ℝ}, γ ≤ γ₀ → (hr : 0 < r) →
      ∀ (Q : (i : Fin k) → (j : Fin (T i).size) →
        CoordinateCapFamily ((T i).patch j).support r)
      (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure)
      (A : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin (k+1) → ℤ))
      (Ω : Set (Ambient (k+2))) {p : ℝ}, 0 < p →
      (∫⁻ x in Ω, ‖extensionProduct (fun _ => Measure.hausdorffMeasure ((k+1 : ℕ) : ℝ)) (fun _ => id)
        (fun i => (T i).cellInput (Q i) hr (f i) (A i)) x‖ₑ ^ p) ≠ 0 →
      ∀ (V : Submodule ℝ (Ambient (k+2))) (far : Finset (Fin k)),
      (∀ i, i ∉ far → ∀ j a ν, ν ∈ A i j a →
        directionPlaneAngle ((T i).cellAxisDirection j a.val) V ≤ 4*γ) →
      k ≤ Module.finrank ℝ V + far.card := by
  obtain ⟨γ₀, hγ₀, he⟩ := atlas_feasible_near_far_counts S T hgeo
  refine ⟨γ₀, hγ₀, ?_⟩
  intro r γ hγ hr Q f A Ω p hp hmass V far hnear
  exact he hγ Q A (atlas_nonzero_mass_nonempty_selection S T hr Q f A Ω hp hmass) V far hnear

/-- Under the proved feasible-count constraint, the article's list of cases
is exhaustive: dimension zero, a Section 7 configuration, or a negative cellular exponent. -/
theorem feasible_stage_cases {k s t : ℕ} {p : ℝ}
    (hk : 3 ≤ k) (hsmax : s ≤ k+2) (hfeas : k ≤ s+t) (hp : critical k < p) :
    s = 0 ∨ (1 ≤ s ∧ s ≤ k ∧ t = k-s) ∨ cellular k s t p < 0 := by
  by_cases hs : s = 0
  · exact Or.inl hs
  right
  by_cases hst : s+t = k
  · left
    omega
  · right
    exact nonterminal_cellular_negative hk (by omega) hsmax (by omega) hp

end N2Restriction
#print axioms N2Restriction.atlas_nonzero_mass_feasible_counts
#print axioms N2Restriction.feasible_stage_cases
