import continuation.TubularFiberLevelV26

namespace N2Restriction
open Metric

/-- A single positive normalized Gram bound holds for the actual fixed-normal
fibers of full tubular charts at every interior point in the surface buffer.
The constants precede all coordinate choices and all normal levels. -/
theorem geometric_actual_fiber_normalized_bound {k : ℕ} (hk : 0 < k)
    (S : Fin k → SmoothPatch (k + 2)) {ν κ : ℝ}
    (hgeo : GeometricHypotheses S ν κ) :
    ∃ η a : ℝ, 0 < η ∧ 0 < a ∧
      ∀ (z : Fin k → Ambient (k + 2)), (∀ j, z j ∈ (S j).support) →
      ∀ i q, q ∈ orthonormalPairSet (k + 2) →
        ‖(commonTangent (fun j => (S j).normal (z j))).starProjection - pairProjection q‖ *
          ‖(S i).shape (z i)‖ ≤ κ / 2 →
      ∀ (y : Fin k → Ambient (k + 2)),
        (∀ j, y j ∈ (S j).extendedSurface ∧ dist (y j) (z j) ≤ η) →
      ∀ (e : Ambient (k + 2 - 1) ≃L[ℝ] (ℝ × ℝ) × Ambient (k + 2 - 3))
        (R : Ambient (k + 2 - 1) →L[ℝ] ℝ × ℝ),
        (∀ x, (e x).1 = R x) →
      ∀ (φ : Ambient (k + 2 - 1) → Ambient (k + 2))
        (U : Set (Ambient (k + 2 - 1))), IsOpen U →
      ∀ (c : ℝ × ℝ),
        (∀ x ∈ U, φ x ∈ (S i).extendedSurface ∧
          pairFrameMap q ((S i).normal (φ x)) = c + R x) →
      ∀ (u : ℝ × ℝ) (v : Ambient (k + 2 - 3)), e.symm (u, v) ∈ U →
        φ (e.symm (u, v)) = y i →
        DifferentiableAt ℝ φ (e.symm (u, v)) →
        Function.Injective (fderiv ℝ φ (e.symm (u, v))) →
        ∃ b : OrthonormalBasis (Fin 3) ℝ
          (LinearMap.range (fderiv ℝ (fun w => φ (e.symm (u, w))) v).toLinearMap)ᗮ,
          a ≤ Matrix.det (Matrix.gram ℝ (Sum.elim
            (fun j : {j : Fin k // j ≠ i} => (S j).normal (y j))
            (fun j => (b j : Ambient (k + 2))))) := by
  obtain ⟨η, a, hη, ha, hb⟩ := geometric_nonzero_chart_normalized_bound hk S hgeo
  refine ⟨η, a, hη, ha, ?_⟩
  intro z hz i q hq hgap y hy e R he φ U hU c hcoord u v hv hyi hφ hi
  obtain ⟨hd, hdi⟩ := tubular_fiber_differentiable_injective e φ u v hφ hi
  exact hb z hz i q hq hgap y hy (pairPlane q) rfl
    (fun w => φ (e.symm (u, w))) v hyi hd hdi
    (tubular_fiber_eventually_level (S i) (pairPlane q) q hq rfl e R he φ U hU c
      hcoord u v hv)

end N2Restriction

#print axioms N2Restriction.geometric_actual_fiber_normalized_bound
