import continuation.AtlasNontangentMassV47
import continuation.PositiveChildMarginsV44

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal

/-- The nontangent estimate at the article child radius and tube width,
with child-range and positive-margin side conditions discharged. -/
theorem eventually_atlas_nontangent_child_mass {d k : ℕ} (hk : 0 < k)
    (S W : Fin k → SmoothPatch (d+1)) (A : (i : Fin k) → PacketGraphAtlas (S i))
    (V : Fin k → Set (Ambient (d+1))) (m : ℝ)
    (hW : ∀ i, (S i).extendedSurface ∩ V i ⊆ (W i).support)
    (hm : 0 < m) {τ lam : ℝ} (hτ : 0 < τ) (hτsmall : τ < 1/2) (hlam : 1 ≤ lam) :
    ∃ B : Fin k → ℝ, (∀ i, 0 ≤ B i) ∧
    ∀ᶠ R : ℝ in Filter.atTop,
    ∀ (Q : (i : Fin k) → (j : Fin (A i).size) →
      CoordinateCapFamily ((A i).patch j).support (R^(-1/2 : ℝ)))
      (hr : 0 < R^(-1/2 : ℝ)), (∀ i, R^(-1/2 : ℝ) ≤ (A i).capRadius) →
    ∀ (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure)
      (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure),
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
    (∀ i j, HasFrequencySupport ((A i).graph j).surfaceMeasure ((A i).patch j).rotation
      (marginRegion (V i) (m-R^(-1/4 : ℝ))) (f i j)) →
    ∀ (M : ℕ) (Z : Set (Ambient (d+1)))
      (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1))) (K C₀ θ : ℝ),
    0 ≤ K → 0 ≤ C₀ → 0 < θ →
    UniformAlgebraicTubeCoverInput Z T M K →
    ∀ (L : ℕ) (c : Fin L → Ambient (d+1)),
    (∀ l t, l ≠ t → 2*(θ*(R^(1-τ))) ≤ dist (c l) (c t)) →
    ∀ (U : Fin L → (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin d → ℤ))
      (Ω : Set (Ambient (d+1))), MeasurableSet Ω →
    (∀ l i j a ν, ν ∈ U l i j a →
      ¬ PacketTangentInBall Z ((A i).originalPacketTube j a (R^(-1/2 : ℝ)) ν R (R^(1/2+τ)/10))
        T ((A i).cellAxisDirection j a) (c l) (R^(1-τ)) (lam*R^(1/2+τ)) C₀) →
    ∀ p : ℝ, 0 < p → p ≤ 1 → 2/(k : ℝ) ≤ p →
    (∫⁻ x, (atlasBallProductSum A Q hr f U c (R^(1-τ)) Ω x)^p) ^ (1/p) ≤
      marginLocalConstant (fun i => (W i).surfaceMeasure) (fun _ => id) V m p (R^(1-τ)) *
        (∏ i, (ENNReal.ofReal (B i) * ENNReal.ofReal (M*((K*(C₀+1)+2)/θ+1)^(d+1)))^(1/2 : ℝ)) *
        ∏ i, ENNReal.ofReal ‖g i‖ := by
  obtain ⟨B,hB,he⟩ := eventually_atlas_nontangent_mass hk S W A V m hW
  refine ⟨B,hB,?_⟩
  have hlam0 : 0 < lam := zero_lt_one.trans_le hlam
  filter_upwards [he, eventually_children hτ hτsmall hlam0,
    eventually_positive_child_margins hm hτ hτsmall hlam0,
    Filter.eventually_gt_atTop (0 : ℝ)] with R hR hc hmargin hR0
  intro Q hr hsmall g f he hf M Z T K C₀ θ hK hC₀ hθ hext L c hsep U Ω hΩ hnt p hp hp1 hkp
  have hw : 0 < R^(1/2+τ) := Real.rpow_pos_of_pos hR0 _
  exact hR _ hc.2.1 hc.2.2.1 hmargin.2.1 Q hr hsmall g f he hf M Z T
    K C₀ (lam*R^(1/2+τ)) θ (R^(1/2+τ)/10) hK hC₀ (mul_pos hlam0 hw) hθ
    ((by linarith : R^(1/2+τ)/10 ≤ R^(1/2+τ)).trans (le_mul_of_one_le_left hw.le hlam)) hext L c hsep U Ω hΩ hnt p hp hp1 hkp

end N2Restriction
#print axioms N2Restriction.eventually_atlas_nontangent_child_mass
