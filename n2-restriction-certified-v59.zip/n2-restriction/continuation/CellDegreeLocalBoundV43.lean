import continuation.CellDegreePowerV43

namespace N2Restriction
open scoped BigOperators ENNReal

/-- The actual local-constant term gains exactly D^e after the
substantial-cell factor is inserted. No finiteness of the local constant
or nonvanishing of the inputs is needed. -/
theorem cell_degree_local_bound {k : ℕ} (far : Finset (Fin k))
    (C : Fin k → ℝ) (hC : ∀ i, 0 ≤ C i) {D : ℝ} (hD : 0 < D) (s : ℝ)
    (a b : Fin k → ENNReal) (L Q : ENNReal) {p : ℝ} (hp : 0 ≤ p)
    (he : ∀ i, a i ^ (2 : ℕ) ≤
      ENNReal.ofReal (C i * D^(1-s-(if i ∈ far then (1 : ℝ) else 0))) * b i ^ (2 : ℕ)) :
    ENNReal.ofReal (D^s) * Q * (L * ∏ i, a i)^p ≤
      Q * ENNReal.ofReal ((∏ i, C i)^(p/2) * D^(cellular k s far.card p)) *
        L^p * (∏ i, b i)^p := by
  have hc i : 0 ≤ C i * D^(1-s-(if i ∈ far then (1 : ℝ) else 0)) :=
    mul_nonneg (hC i) (Real.rpow_nonneg hD.le _)
  have hid : ENNReal.ofReal (D^s) *
      (∏ i, ENNReal.ofReal (C i * D^(1-s-(if i ∈ far then (1 : ℝ) else 0))))^(p/2) =
      ENNReal.ofReal ((∏ i, C i)^(p/2) * D^(cellular k s far.card p)) := by
    rw [← ENNReal.ofReal_prod_of_nonneg (fun i _ => hc i),
      ENNReal.ofReal_rpow_of_nonneg (Finset.prod_nonneg (fun i _ => hc i)) (by positivity),
      ← ENNReal.ofReal_mul (Real.rpow_nonneg hD.le _), cell_degree_power_identity far C hC hD]
  have hh := mul_le_mul_left' (cell_local_energy_product a b _ L hp he)
    (ENNReal.ofReal (D^s)*Q)
  calc
    _ ≤ _ := hh
    _ = Q * (ENNReal.ofReal (D^s) *
        (∏ i, ENNReal.ofReal (C i * D^(1-s-(if i ∈ far then (1 : ℝ) else 0))))^(p/2)) *
        L^p * (∏ i, b i)^p := by ac_rfl
    _ = _ := by rw [hid]

end N2Restriction
#print axioms N2Restriction.cell_degree_local_bound
