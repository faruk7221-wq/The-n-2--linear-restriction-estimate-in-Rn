import continuation.OriginalInputV20
set_option maxHeartbeats 10000
namespace N2Restriction
open MeasureTheory Set Filter
attribute [local irreducible] equalMeasureInput
noncomputable def castZeroExtend {n : ℕ} (μ ν : Measure (Ambient n))
    (K : Set (Ambient n)) (hK : MeasurableSet K) (h : μ = ν.restrict K)
    (g : Lp ℂ 2 μ) : Lp ℂ 2 ν :=
  zeroExtendL2 ν K hK (equalMeasureInput h g)

theorem castZeroExtend_apply {n : ℕ} (μ ν : Measure (Ambient n))
    (K : Set (Ambient n)) (hK : MeasurableSet K) (h : μ = ν.restrict K)
    (g : Lp ℂ 2 μ) : castZeroExtend μ ν K hK h g =
      zeroExtendL2 ν K hK (equalMeasureInput h g) := rfl

theorem castZeroExtend_extension {n : ℕ} (μ ν : Measure (Ambient n))
    (K : Set (Ambient n)) (hK : MeasurableSet K) (h : μ = ν.restrict K)
    (g : Lp ℂ 2 μ) (x : Ambient n) :
    extension ν id (castZeroExtend μ ν K hK h g) x = extension μ id g x :=
  (zeroExtendL2_extension ν K hK (equalMeasureInput h g) id x).trans
    (equalMeasureInput_extension h id g x)

theorem castZeroExtend_isometry {n : ℕ} (μ ν : Measure (Ambient n))
    (K : Set (Ambient n)) (hK : MeasurableSet K) (h : μ = ν.restrict K) :
    Isometry (castZeroExtend μ ν K hK h) :=
  ((zeroExtendIsometry ν K hK).comp (equalMeasureInput h)).isometry

theorem castZeroExtend_norm {n : ℕ} (μ ν : Measure (Ambient n))
    (K : Set (Ambient n)) (hK : MeasurableSet K) (h : μ = ν.restrict K)
    (g : Lp ℂ 2 μ) : ‖castZeroExtend μ ν K hK h g‖ = ‖g‖ :=
  (zeroExtendL2_norm ν K hK (equalMeasureInput h g)).trans ((equalMeasureInput h).norm_map g)

/-- A finite cover with exact norm-preserving local lifts reconstructs the original L2 input. -/
theorem finite_cover_lift_L2 {n m : ℕ}
    (μ ν : Measure (Ambient n)) (B : Set (Ambient n)) (hB : MeasurableSet B)
    (hm : μ = ν.restrict B) (K : Fin m → Set (Ambient n))
    (hK : ∀ j, MeasurableSet (K j)) (hcover : B ⊆ ⋃ j, K j)
    (F : Fin m → Type*) [∀ j, Norm (F j)] (I : ∀ j, F j → Lp ℂ 2 ν)
    (p : ∀ j, F j → Prop)
    (hlift : ∀ j (u : Lp ℂ 2 (ν.restrict (K j))),
      ∃ f : F j, ‖f‖ = ‖u‖ ∧ p j f ∧ I j f = zeroExtendL2 ν (K j) (hK j) u)
    (g : Lp ℂ 2 μ) :
    ∃ f : ∀ j, F j, (∑ j, ‖f j‖ ^ 2) ≤ ‖g‖ ^ 2 ∧ (∀ j, p j (f j)) ∧
      (∑ j, I j (f j)) = castZeroExtend μ ν B hB hm g := by
  classical
  let v := equalMeasureInput hm g
  let u := atlasPatchInput ν B hB K hK v
  choose f hn hs he using fun j => hlift j (u j)
  refine ⟨f, ?_, hs, ?_⟩
  · calc
      _ = ∑ j, ‖u j‖ ^ 2 := Finset.sum_congr rfl (fun j _ => congrArg (fun t : ℝ => t ^ 2) (hn j))
      _ ≤ ‖v‖ ^ 2 := atlasPatchInput_energy ν B hB K hK v
      _ = ‖g‖ ^ 2 := congrArg (fun t : ℝ => t ^ 2) ((equalMeasureInput hm).norm_map g)
  · exact (Finset.sum_congr rfl (fun j _ => he j)).trans
      (atlasPatchInput_L2_reconstruction ν B hB K hK hcover v)

noncomputable def ambientHausdorff (d : ℕ) : Measure (Ambient (d + 1)) :=
  Measure.hausdorffMeasure (d : ℝ)

/-- The dimension convention in the original surface measure agrees with graph dimension. -/
theorem SmoothPatch.surfaceMeasure_succ {d : ℕ} (S : SmoothPatch (d + 1)) :
    S.surfaceMeasure = (ambientHausdorff d).restrict S.support := by
  have hdim : ((d + 1 : ℕ) : ℝ) - 1 = (d : ℝ) := by push_cast; ring
  rw [SmoothPatch.surfaceMeasure, hdim]
  rfl

/-- Canonical isometric realization of an original surface input in ambient Hausdorff L2. -/
noncomputable def SmoothPatch.hausdorffInput {d : ℕ} (S : SmoothPatch (d + 1))
    (g : Lp ℂ 2 S.surfaceMeasure) :
      Lp ℂ 2 (ambientHausdorff d) :=
  castZeroExtend S.surfaceMeasure (ambientHausdorff d) S.support
    S.compact_support.measurableSet S.surfaceMeasure_succ g

/-- The original-input embedding preserves the extension integral. -/
theorem SmoothPatch.hausdorffInput_extension {d : ℕ} (S : SmoothPatch (d + 1))
    (g : Lp ℂ 2 S.surfaceMeasure) (x : Ambient (d + 1)) :
    extension (ambientHausdorff d) id (@SmoothPatch.hausdorffInput d S g) x =
      extension S.surfaceMeasure id g x :=
  castZeroExtend_extension S.surfaceMeasure (ambientHausdorff d) S.support
    S.compact_support.measurableSet S.surfaceMeasure_succ g x

theorem SmoothPatch.hausdorffInput_apply {d : ℕ} (S : SmoothPatch (d + 1))
    (g : Lp ℂ 2 S.surfaceMeasure) : @SmoothPatch.hausdorffInput d S g =
      zeroExtendL2 (ambientHausdorff d) S.support S.compact_support.measurableSet
        (equalMeasureInput (μ := S.surfaceMeasure) (ν := (ambientHausdorff d).restrict S.support) S.surfaceMeasure_succ g) :=
  castZeroExtend_apply S.surfaceMeasure (ambientHausdorff d) S.support
    S.compact_support.measurableSet S.surfaceMeasure_succ g

theorem SmoothPatch.hausdorffInput_isometry {d : ℕ} (S : SmoothPatch (d + 1)) :
    Isometry (@SmoothPatch.hausdorffInput d S) :=
  castZeroExtend_isometry S.surfaceMeasure (ambientHausdorff d) S.support
    S.compact_support.measurableSet S.surfaceMeasure_succ

theorem SmoothPatch.hausdorffInput_norm {d : ℕ} (S : SmoothPatch (d + 1))
    (g : Lp ℂ 2 S.surfaceMeasure) : ‖S.hausdorffInput g‖ = ‖g‖ :=
  castZeroExtend_norm S.surfaceMeasure (ambientHausdorff d) S.support
    S.compact_support.measurableSet S.surfaceMeasure_succ g

end N2Restriction

namespace N2Restriction
open MeasureTheory Set Filter

/-- The chart inputs recover the original surface input itself, not only its extension. -/
theorem PacketGraphAtlas.input_decomposition_L2 {d : ℕ} {S : SmoothPatch (d + 1)}
    (T : PacketGraphAtlas S) (g : Lp ℂ 2 S.surfaceMeasure) :
    ∃ f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure,
      (∑ j, ‖f j‖ ^ 2) ≤ ‖g‖ ^ 2 ∧
      (∀ j, HasFrequencySupport (T.graph j).surfaceMeasure id
        ((T.graph j).parametrization '' (T.patch j).support) (f j)) ∧
      (∑ j, (T.graph j).rotatedAmbientInput (T.patch j).rotation (f j)) = @SmoothPatch.hausdorffInput d S g := by
  classical
  let H : Measure (Ambient (d + 1)) := ambientHausdorff d
  let K := fun j : Fin T.size => (T.patch j).rotation ''
    ((T.graph j).parametrization '' (T.patch j).support)
  have hK j : MeasurableSet (K j) :=
    (((T.patch j).compact_support.image
      (graphMap_lipschitz (T.graph j).lipschitz).continuous).image
      (T.patch j).rotation.continuous).measurableSet
  have hcover : S.support ⊆ ⋃ j, K j := by
    intro x hx
    obtain ⟨j, hj⟩ := Set.mem_iUnion.mp (T.cover hx)
    refine Set.mem_iUnion.mpr ⟨j, ?_⟩
    change x ∈ (T.patch j).rotation '' ((T.graph j).parametrization '' (T.patch j).support)
    rw [← T.carrier_eq j]
    exact hj
  exact finite_cover_lift_L2 S.surfaceMeasure H S.support S.compact_support.measurableSet
    S.surfaceMeasure_succ K hK hcover
    (fun j => Lp ℂ 2 (T.graph j).surfaceMeasure)
    (fun j => (T.graph j).rotatedAmbientInput (T.patch j).rotation)
    (fun j f => HasFrequencySupport (T.graph j).surfaceMeasure id
      ((T.graph j).parametrization '' (T.patch j).support) f)
    (fun j u => (T.graph j).rotated_patch_input_L2 (T.patch j).rotation
      (T.patch j).compact_support u) g

/-- The actual sigma-indexed packet series sums unconditionally to the original input in L2. -/
theorem PacketGraphAtlas.original_input_packet_hasSum {d : ℕ} {S : SmoothPatch (d + 1)}
    (T : PacketGraphAtlas S) (g : Lp ℂ 2 S.surfaceMeasure) :
    ∃ f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure,
      (∑ j, ‖f j‖ ^ 2) ≤ ‖g‖ ^ 2 ∧
      ∀ (r : ℝ) (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r)
        (hr : 0 < r),
      HasSum (fun p : (j : Fin T.size) × ((Q j).centers × (Fin d → ℤ)) =>
        (T.graph p.1).rotatedAmbientInput (T.patch p.1).rotation
          ((T.graph p.1).packet (Q p.1) hr (f p.1) p.2.1 p.2.2)) (@SmoothPatch.hausdorffInput d S g) := by
  obtain ⟨f, hf, hs, he⟩ := T.input_decomposition_L2 g
  refine ⟨f, hf, fun r Q hr => ?_⟩
  exact he ▸ T.packet_hasSum Q hr f hs

end N2Restriction

namespace N2Restriction
open MeasureTheory Set Filter

/-- One original-input choice and the same cap families satisfy L2 reconstruction,
energy, cap count and uniform extension reconstruction at every admissible scale. -/
theorem PacketGraphAtlas.original_input_packet_decomposition {d : ℕ}
    {S : SmoothPatch (d + 1)} (T : PacketGraphAtlas S) :
    ∃ C A : ℝ, 0 ≤ C ∧ 0 ≤ A ∧ ∀ g : Lp ℂ 2 S.surfaceMeasure,
      ∃ f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure,
        (∑ j, ‖f j‖ ^ 2) ≤ ‖g‖ ^ 2 ∧
        (∀ j, HasFrequencySupport (T.graph j).surfaceMeasure id
          ((T.graph j).parametrization '' (T.patch j).support) (f j)) ∧
        ∀ r : ℝ, 0 < r → r ≤ min 1 T.capRadius →
        ∃ Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r,
          (∑ j, ((Q j).centers.card : ℝ)) ≤ A * r ^ (-(d : ℝ)) ∧
          ∀ hr : 0 < r,
          HasSum (fun p : (j : Fin T.size) × ((Q j).centers × (Fin d → ℤ)) =>
            (T.graph p.1).rotatedAmbientInput (T.patch p.1).rotation
              ((T.graph p.1).packet (Q p.1) hr (f p.1) p.2.1 p.2.2)) (@SmoothPatch.hausdorffInput d S g) ∧
          (∑ j, ∑ c, ∑' ν, ‖(T.graph j).rotatedAmbientInput (T.patch j).rotation
            ((T.graph j).packet (Q j) hr (f j) c ν)‖ ^ 2) ≤ C * ‖g‖ ^ 2 ∧
          ∀ ε : ℝ, 0 < ε → ∀ᶠ F : Finset ((j : Fin T.size) × ((Q j).centers × (Fin d → ℤ))) in atTop,
            ∀ x : Ambient (d + 1), dist
              (∑ p ∈ F, extension (ambientHausdorff d) id
                ((T.graph p.1).rotatedAmbientInput (T.patch p.1).rotation
                  ((T.graph p.1).packet (Q p.1) hr (f p.1) p.2.1 p.2.2)) x)
              (extension S.surfaceMeasure id g x) < ε := by
  obtain ⟨C, hC, henergy⟩ := T.packet_total_energy
  obtain ⟨A, hA, hcaps⟩ := T.exists_cap_families
  refine ⟨C, A, hC, hA, ?_⟩
  intro g
  obtain ⟨f, hf, hs, he⟩ := T.input_decomposition_L2 g
  refine ⟨f, hf, hs, ?_⟩
  intro r hr hsmall
  obtain ⟨Q, hQ⟩ := hcaps r hr (hsmall.trans (min_le_left _ _))
  refine ⟨Q, hQ, fun hr => ⟨he ▸ T.packet_hasSum Q hr f hs, ?_, ?_⟩⟩
  · exact (henergy Q hr f).trans (mul_le_mul_of_nonneg_left hf hC)
  · have hE x := (congrArg (fun u : Lp ℂ 2 (ambientHausdorff d) => extension (ambientHausdorff d) id u x) he).trans
      (S.hausdorffInput_extension g x)
    intro ε hε
    filter_upwards [T.packet_uniform_extension Q hr (hsmall.trans (min_le_right _ _)) f hs ε hε] with F hF
    intro x
    exact (hE x) ▸ hF x

end N2Restriction











#print axioms N2Restriction.PacketGraphAtlas.input_decomposition_L2
#print axioms N2Restriction.PacketGraphAtlas.original_input_packet_decomposition
#print axioms N2Restriction.PacketGraphAtlas.original_input_packet_hasSum
#print axioms N2Restriction.SmoothPatch.hausdorffInput_apply
#print axioms N2Restriction.SmoothPatch.hausdorffInput_extension
#print axioms N2Restriction.SmoothPatch.hausdorffInput_isometry
#print axioms N2Restriction.SmoothPatch.hausdorffInput_norm
#print axioms N2Restriction.SmoothPatch.surfaceMeasure_succ
#print axioms N2Restriction.castZeroExtend_apply
#print axioms N2Restriction.castZeroExtend_extension
#print axioms N2Restriction.castZeroExtend_isometry
#print axioms N2Restriction.castZeroExtend_norm
#print axioms N2Restriction.finite_cover_lift_L2
