import continuation.AtlasSupportTransportV44

namespace N2Restriction
open MeasureTheory Set

/-- Rotation and graph extension preserve an input's specified essential support,
in addition to chart support, norm and extension identity. -/
theorem SurfaceGraphChart.rotated_patch_input_supported {d : ℕ} (G : SurfaceGraphChart d)
    (A : Ambient (d + 1) ≃ₗᵢ[ℝ] Ambient (d + 1)) {K : Set (Ambient d)}
    (hK : IsCompact K) (F : Set (Ambient (d + 1)))
    (g : Lp ℂ 2 ((Measure.hausdorffMeasure (d : ℝ)).restrict (A '' (G.parametrization '' K))))
    (hg : HasFrequencySupport ((Measure.hausdorffMeasure (d : ℝ)).restrict (A '' (G.parametrization '' K))) id F g) :
    ∃ f : Lp ℂ 2 G.surfaceMeasure, ‖f‖ = ‖g‖ ∧
      HasFrequencySupport G.surfaceMeasure id (G.parametrization '' K) f ∧
      HasFrequencySupport G.surfaceMeasure A F f ∧
      ∀ x, extension G.surfaceMeasure A f x =
        extension ((Measure.hausdorffMeasure (d : ℝ)).restrict (A '' (G.parametrization '' K))) id g x := by
  have hmeas : MeasurableSet (G.parametrization '' K) :=
    (hK.image (graphMap_lipschitz G.lipschitz).continuous).measurableSet
  revert g
  rw [← orthogonal_surface_measure A (d : ℝ), ← G.surfaceMeasure_restrict_image]
  intro g hg
  obtain ⟨u, rfl⟩ := rotatedInput_surjective A (G.surfaceMeasure.restrict (G.parametrization '' K)) g
  refine ⟨G.patchInput hmeas u, ?_, G.patchInput_support hmeas u, ?_, ?_⟩
  · rw [rotatedInput_norm]
    exact zeroExtendL2_norm _ _ _ _
  · exact zeroExtendL2_frequency_support _ _ hmeas A F u
      ((rotatedInput_frequency_support_iff A _ F u).mp hg)
  · intro x
    rw [show extension ((G.surfaceMeasure.restrict (G.parametrization '' K)).map A) id
        (rotatedInput A _ u) x = extension (G.surfaceMeasure.restrict (G.parametrization '' K)) A u x from
      imageInput_extension _ A A.symm A.toHomeomorph.measurableEmbedding
        A.symm.continuous.measurable A.symm_apply_apply u x]
    exact zeroExtendL2_extension _ _ _ _ A _

/-- The actual atlas decomposition preserves arbitrary essential support of the
original surface input, including its radius-dependent margin. -/
theorem PacketGraphAtlas.input_decomposition_supported {d : ℕ} {S : SmoothPatch (d + 1)}
    (T : PacketGraphAtlas S) (g : Lp ℂ 2 S.surfaceMeasure) (F : Set (Ambient (d + 1)))
    (hg : HasFrequencySupport S.surfaceMeasure id F g) :
    ∃ f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure,
      (∑ j, ‖f j‖ ^ 2) ≤ ‖g‖ ^ 2 ∧
      (∀ j, HasFrequencySupport (T.graph j).surfaceMeasure id
        ((T.graph j).parametrization '' (T.patch j).support) (f j)) ∧
      (∀ j, HasFrequencySupport (T.graph j).surfaceMeasure (T.patch j).rotation F (f j)) ∧
      ∀ x, (∑ j, extension (T.graph j).surfaceMeasure (T.patch j).rotation (f j) x) =
        extension S.surfaceMeasure id g x := by
  have hdim : ((d + 1 : ℕ) : ℝ) - 1 = (d : ℝ) := by push_cast; ring
  have hμ : S.surfaceMeasure = (Measure.hausdorffMeasure (d : ℝ)).restrict S.support := by
    rw [SmoothPatch.surfaceMeasure, hdim]
  haveI : IsFiniteMeasure S.surfaceMeasure := S.isFiniteMeasure_surfaceMeasure (by omega)
  revert g
  rw [hμ] at *
  intro g hg
  let K := fun j => (T.patch j).carrier
  have hK j : MeasurableSet (K j) := (T.patch j).compact_carrier.measurableSet
  let u := atlasPatchInput _ S.support S.compact_support.measurableSet K hK g
  have hus j : HasFrequencySupport ((Measure.hausdorffMeasure (d : ℝ)).restrict (K j)) id F (u j) :=
    atlasPatchInput_frequency_support _ S.support S.compact_support.measurableSet K hK g id F hg j
  have hu j : ∃ f : Lp ℂ 2 (T.graph j).surfaceMeasure, ‖f‖ = ‖u j‖ ∧
      HasFrequencySupport (T.graph j).surfaceMeasure id ((T.graph j).parametrization '' (T.patch j).support) f ∧
      HasFrequencySupport (T.graph j).surfaceMeasure (T.patch j).rotation F f ∧
      ∀ x, extension (T.graph j).surfaceMeasure (T.patch j).rotation f x =
        extension ((Measure.hausdorffMeasure (d : ℝ)).restrict (K j)) id (u j) x := by
    have h := hus j
    generalize u j = v at h ⊢
    revert v
    dsimp only [K]
    rw [T.carrier_eq j]
    intro v hs
    exact (T.graph j).rotated_patch_input_supported (T.patch j).rotation (T.patch j).compact_support F v hs
  choose f hn hs hF he using hu
  refine ⟨f, ?_, hs, hF, ?_⟩
  · simp_rw [hn]
    exact atlasPatchInput_energy _ S.support S.compact_support.measurableSet K hK g
  · intro x
    simp_rw [he]
    exact atlasPatchInput_reconstruction _ S.support S.compact_support.measurableSet K hK T.cover g x

end N2Restriction
#print axioms N2Restriction.SurfaceGraphChart.rotated_patch_input_supported
#print axioms N2Restriction.PacketGraphAtlas.input_decomposition_supported
