import N2Restriction.BallEstimates

namespace N2Restriction
open MeasureTheory Set
open scoped ENNReal

/-- Integration costs only the ambient volume power. Choosing the packet
omission exponent (J+n)/p leaves any prescribed rapid decay R^(-J). -/
theorem cell_rapid_error_normalization {n : ℕ} {R p : ℝ}
    (hR : 0 < R) (hp : 0 < p) (J : ℝ) (C P : ENNReal)
    (Δ : Set (Ambient n)) (hΔ : Δ ⊆ Metric.closedBall 0 R) :
    (C * ENNReal.ofReal (R^(-((J+n)/p))) * P)^p * volume Δ ≤
      (volume (Metric.ball (0 : Ambient n) 1) * C^p) *
        ENNReal.ofReal (R^(-J)) * P^p := by
  have hvol : volume Δ ≤ volume (Metric.closedBall (0 : Ambient n) R) := measure_mono hΔ
  rw [Measure.addHaar_closedBall volume 0 hR.le] at hvol
  simp only [Ambient, finrank_euclideanSpace, Fintype.card_fin] at hvol
  have hid : (ENNReal.ofReal (R^(-((J+n)/p))))^p * ENNReal.ofReal (R^n) =
      ENNReal.ofReal (R^(-J)) := by
    rw [ENNReal.ofReal_rpow_of_pos (Real.rpow_pos_of_pos hR _),
      ← ENNReal.ofReal_mul (Real.rpow_nonneg (Real.rpow_nonneg hR.le _) _),
      ← Real.rpow_mul hR.le, ← Real.rpow_natCast R n, ← Real.rpow_add hR]
    congr 2
    field_simp [hp.ne']
    ring
  calc
    _ ≤ (C * ENNReal.ofReal (R^(-((J+n)/p))) * P)^p *
        (ENNReal.ofReal (R^n) * volume (Metric.ball (0 : Ambient n) 1)) :=
      mul_le_mul_left' hvol _
    _ = (volume (Metric.ball (0 : Ambient n) 1) * C^p) *
        ((ENNReal.ofReal (R^(-((J+n)/p))))^p * ENNReal.ofReal (R^n)) * P^p := by
      simp only [ENNReal.mul_rpow_of_nonneg _ _ hp.le]
      ac_rfl
    _ = _ := by rw [hid]

end N2Restriction
#print axioms N2Restriction.cell_rapid_error_normalization
