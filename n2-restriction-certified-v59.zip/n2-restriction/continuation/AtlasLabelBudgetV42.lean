import continuation.OriginalAtlasCellBudgetV42

namespace N2Restriction
open MeasureTheory
open scoped BigOperators ENNReal

/-- A uniform label budget charged to the original surface input, for
any chart decomposition satisfying the proved energy inequality. -/
theorem PacketGraphAtlas.original_labelled_cell_budget {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) :
    ∃ B : ℝ, 0 ≤ B ∧ ∀ {m : ℕ} {r : ℝ}
      (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r) (hr : 0 < r)
      (g : Lp ℂ 2 S.surfaceMeasure)
      (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure),
      (∑ j, ‖f j‖^2) ≤ ‖g‖^2 →
      ∀ (A : (j : Fin T.size) → (Q j).centers → Set (Fin d → ℤ))
        (L : (j : Fin T.size) → (Q j).centers → (Fin d → ℤ) → Finset (Fin m → Bool))
        (N : ENNReal),
      (∀ j a ν, ν ∈ A j a → ((L j a ν).card : ENNReal) ≤ N) →
      (∑' σ : Fin m → Bool, ENNReal.ofReal (‖T.cellInput Q hr f
        (fun j a => {ν | ν ∈ A j a ∧ σ ∈ L j a ν})‖^2)) ≤
        ENNReal.ofReal B*N*ENNReal.ofReal (‖g‖^2) := by
  obtain ⟨B, hB, hb⟩ := T.cell_energy_budget
  refine ⟨B, hB, ?_⟩
  intro m r Q hr g f he A L N hl
  apply T.labelled_cell_budget Q hr f A L N (ENNReal.ofReal (‖g‖^2)) _ hl
  intro U hi
  exact (hb Q hr f U N hi).trans (mul_le_mul_left' (ENNReal.ofReal_le_ofReal he) _)

end N2Restriction
#print axioms N2Restriction.PacketGraphAtlas.original_labelled_cell_budget
