import continuation.SurfaceCellBudgetV42
import N2Restriction.AtlasPackets

namespace N2Restriction
open MeasureTheory
open scoped BigOperators ENNReal

/-- Combining a fixed finite atlas costs its cardinality, never the number of caps. -/
theorem finite_atlas_cell_energy {C E : Type*} [NormedAddCommGroup E]
    {m : ℕ} (v : C → Fin m → E) (B : Fin m → ENNReal)
    (hv : ∀ j, (∑' c, ENNReal.ofReal (‖v c j‖^2)) ≤ B j) :
    (∑' c, ENNReal.ofReal (‖∑ j, v c j‖^2)) ≤ (m : ENNReal) * ∑ j, B j := by
  have hp c : ‖∑ j, v c j‖^2 ≤ (m : ℝ) * ∑ j, ‖v c j‖^2 := by
    have hn := pow_le_pow_left₀ (norm_nonneg (∑ j, v c j)) (norm_sum_le _ _) 2
    have hc := Finset.sum_mul_sq_le_sq_mul_sq Finset.univ (fun _ : Fin m => (1 : ℝ))
      (fun j => ‖v c j‖)
    simp only [one_mul, one_pow, Finset.sum_const, Finset.card_univ, Fintype.card_fin,
      nsmul_eq_mul, mul_one] at hc
    exact hn.trans hc
  calc
    _ ≤ ∑' c, (m : ENNReal) * ∑ j, ENNReal.ofReal (‖v c j‖^2) := by
      apply ENNReal.tsum_le_tsum
      intro c
      simpa only [ENNReal.ofReal_mul (Nat.cast_nonneg m), ENNReal.ofReal_natCast,
        ENNReal.ofReal_sum_of_nonneg (fun j _ => sq_nonneg ‖v c j‖)] using
        ENNReal.ofReal_le_ofReal (hp c)
    _ = (m : ENNReal) * ∑ j, ∑' c, ENNReal.ofReal (‖v c j‖^2) := by
      rw [ENNReal.tsum_mul_left, Summable.tsum_finsetSum (fun _ _ => ENNReal.summable)]
    _ ≤ _ := mul_le_mul_left' (Finset.sum_le_sum (fun j _ => hv j)) _

end N2Restriction
#print axioms N2Restriction.finite_atlas_cell_energy
