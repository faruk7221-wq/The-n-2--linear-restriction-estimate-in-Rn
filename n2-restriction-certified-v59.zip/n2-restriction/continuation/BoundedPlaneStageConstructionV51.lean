import continuation.PlaneStageConstructionV41
import continuation.PolynomialStageBudgetV51
namespace N2Restriction
open Set Metric MeasureTheory
open scoped BigOperators ENNReal

/-- The actual selection propagates the same fixed numerical stage ceilings. -/
theorem polynomial_plane_stage_with_budget {n k m : ℕ} {I : Type*} [Fintype I] [Nonempty I]
    {μ : Fin k → Measure (Ambient n)} {g : Fin k → Ambient n → ℂ}
    {a R r : ℝ} {M₀ err : ENNReal} (S : PolynomialStage μ g a R r M₀ err m)
    (B : PolynomialStageBudget) (hB : S.withinBudget B)
    (cuts : Set (Ambient n)) (V : I → Submodule ℝ (Ambient n))
    (hd : ∀ i, Module.finrank ℝ (V i) = n-m)
    {γ : ℝ} (hγsmall : 2*γ ≤ (1 : ℝ)/2)
    (haway : ∀ x ∈ S.region, x ∉ thickening (100*(S.multiplier*r)) cuts)
    (hosc : ∀ z ∈ {x | polynomialLevelMap S.equations x = 0} \ cuts,
      ∀ w ∈ connectedComponentIn ({x | polynomialLevelMap S.equations x = 0} \ cuts) z,
        ‖(LinearMap.ker (fderiv ℝ (polynomialLevelMap S.equations) w).toLinearMap).starProjection -
          (LinearMap.ker (fderiv ℝ (polynomialLevelMap S.equations) z).toLinearMap).starProjection‖ < γ)
    (hnet : ∀ z ∈ {x | polynomialLevelMap S.equations x = 0} \ cuts, ∃ i,
      ‖(LinearMap.ker (fderiv ℝ (polynomialLevelMap S.equations) z).toLinearMap).starProjection -
        (V i).starProjection‖ < γ) :
    ∃ i, ∃ S' : PolynomialStage μ g a R r M₀ err m,
      S'.equations = S.equations ∧ S'.degreeBound = S.degreeBound ∧
      S'.multiplier = S.multiplier ∧
      S'.constant = max 1 (S.constant*(Fintype.card I : ENNReal)) ∧
      S'.region ⊆ S.region ∧
      S'.region ⊆ thickening (S.multiplier*r) (planeWitnessSet S.equations cuts (V i) (2*γ)) ∧
      (∀ x ∈ S'.region, Nonempty (ShortLiftWitness (V i) (polynomialLevelMap S.equations)
        {x | polynomialLevelMap S.equations x = 0} cuts (S.multiplier*r) x)) ∧ S'.withinBudget (B.advance 0 1 le_rfl (Fintype.card I : ENNReal) (by simp)) := by
  obtain ⟨i,S',heq,hdeg,hmult,hconst,hsub,hplane,hw⟩ := polynomial_plane_stage S cuts V hd hγsmall haway hosc hnet
  refine ⟨i,S',heq,hdeg,hmult,hconst,hsub,hplane,hw,?_⟩
  apply polynomial_stage_budget_update S S' B hB 0 1 le_rfl (Fintype.card I : ENNReal) (by simp)
  · simp only [hdeg,Nat.max_zero,le_refl]
  · simp only [hmult,one_mul,le_refl]
  · rw [hconst]

end N2Restriction
#print axioms N2Restriction.polynomial_plane_stage_with_budget
