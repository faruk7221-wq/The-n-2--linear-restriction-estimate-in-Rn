import continuation.AtlasTangentStripScaleV46
import continuation.TangentCubeWitnessV46
import continuation.TerminalAngularScalesV46

namespace N2Restriction
open Set Metric MeasureTheory Filter

/-- The actual finite tube attached to an original atlas packet. -/
noncomputable def PacketGraphAtlas.originalPacketTube {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) (j : Fin T.size) (a : Ambient d) (r : ℝ)
    (ν : Fin d → ℤ) (R w : ℝ) : Set (Ambient (d+1)) :=
  rotatedPacketTube (T.patch j).rotation (graphGradient (T.graph j).phase a)
    (r⁻¹ • latticeVector ν) R w

/-- Equation (7.7) for the actual selected original packets meeting a
dilated cube. The angular hypothesis is precisely tangency at all nearby
variety points in the doubled ball; the chosen cube witness is derived
to qualify. No extra normal-strip assumption is supplied. -/
theorem PacketGraphAtlas.eventually_cube_tangent_strip {d : ℕ} {S : SmoothPatch (d+1)}
    (A : PacketGraphAtlas S) {τ lam : ℝ} (hτ : 0 < τ) (hτ' : τ < 1/4) (hlam : 0 < lam) :
    ∀ᶠ R : ℝ in atTop,
      ∀ (Q : (j : Fin A.size) → CoordinateCapFamily (A.patch j).support (R ^ (-1/2 : ℝ)))
      (hr : 0 < R ^ (-1/2 : ℝ))
      (f : (j : Fin A.size) → Lp ℂ 2 (A.graph j).surfaceMeasure)
      (Z : Set (Ambient (d+1))) (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1)))
      (F : Submodule ℝ (Ambient (d+1))) (center q x z : Ambient (d+1)) (w C C₀ : ℝ)
      (U : (j : Fin A.size) → (Q j).centers → Set (Fin d → ℤ)),
      0 ≤ C → 1 + Real.sqrt ((d+1 : ℕ) : ℝ) * (1+C)/2 ≤ C₀ →
      z ∈ Z → x ∈ ball center (R ^ (1-τ)) → x ∈ gridCube q (lam * R ^ (1/2+τ)) →
      dist z x ≤ lam * R ^ (1/2+τ) →
      (∀ j c ν, ν ∈ U j c → PacketTangentInBall Z
        (A.originalPacketTube j c (R ^ (-1/2 : ℝ)) ν R w) T (A.cellAxisDirection j c)
        center (R ^ (1-τ)) (lam * R ^ (1/2+τ)) C₀) →
      (∀ j c ν, ν ∈ U j c →
        (A.originalPacketTube j c (R ^ (-1/2 : ℝ)) ν R w ∩
          gridCube q (C*(lam * R ^ (1/2+τ)))).Nonempty) →
      HasFrequencySupport (Measure.hausdorffMeasure (d : ℝ)) id
        (normalStrip S (T z ⊔ F)ᗮ (2*(lam * R ^ (-1/2+2*τ)))) (A.cellInput Q hr f U) := by
  filter_upwards [A.eventually_selected_witness_strip hτ hlam,
    eventually_terminal_width_le_radius hτ' lam, eventually_gt_atTop (0 : ℝ)] with R hs hbρ hR
  intro Q hr f Z T F center q x z w C C₀ U hC hC₀ hz hxb hxq hzx htan hmeet
  apply hs Q hr f (T z) F U
  intro j c hc
  obtain ⟨ν,hν⟩ := hc
  have ha := tangent_cube_witness_angle Z _ T (A.cellAxisDirection j c) center q x z
    (mul_nonneg hlam.le (Real.rpow_nonneg hR.le _)) hbρ hC hC₀
    (htan j c ν hν) hz hxb hxq hzx (hmeet j c ν hν)
  rw [terminal_angular_scale hR] at ha
  simpa only [directionPlaneAngle, norm_sub_rev] using ha

end N2Restriction
#print axioms N2Restriction.PacketGraphAtlas.eventually_cube_tangent_strip
