import continuation.AtlasBinarySelectionV42
import continuation.PartitionDensityV38

namespace N2Restriction
open MeasureTheory Set
open scoped BigOperators ENNReal

/-- The actual extension integral has a finite uniform L1 bound in the
extended-norm convention, including infinite ambient surface measures. -/
theorem enorm_extension_L1_bound {n : ℕ} (μ : Measure (Ambient n))
    (g : Ambient n → ℂ) (x : Ambient n) :
    ‖extension μ id g x‖ₑ ≤ ENNReal.ofReal (∫ y, ‖g y‖ ∂μ) := by
  simpa only [ofReal_norm] using ENNReal.ofReal_le_ofReal (extension_le_L1 μ id g x)

/-- Finite physical volume is enough for the reset density; the ambient
Hausdorff measure need not be finite. Integrability of selected atlas inputs
is established separately, so their Fourier integrals have their usual meaning. -/
theorem partitionDensity_finite_volume {n k : ℕ}
    (μ : Fin k → Measure (Ambient n)) (g : Fin k → Ambient n → ℂ)
    (Ω : Set (Ambient n)) (hΩ : volume Ω ≠ ⊤) {p : ℝ} (hp : 0 ≤ p) :
    IsFiniteMeasure (partitionDensity μ g Ω p) := by
  let B := ∏ i, ENNReal.ofReal (∫ y, ‖g i y‖ ∂μ i)
  have hB : B ≠ ⊤ := ENNReal.prod_ne_top (fun _ _ => ENNReal.ofReal_ne_top)
  have hbound x : ‖extensionProduct μ (fun _ => id) g x‖ₑ ≤ B := by
    simp only [extensionProduct, enorm_eq_nnnorm, nnnorm_prod, ENNReal.coe_finset_prod]
    exact Finset.prod_le_prod' (fun i _ => enorm_extension_L1_bound (μ i) (g i) x)
  apply isFiniteMeasure_withDensity
  have hi : (∫⁻ x in Ω, ‖extensionProduct μ (fun _ => id) g x‖ₑ ^ p) ≤ B^p * volume Ω := by
    calc
      _ ≤ ∫⁻ _ in Ω, B^p := lintegral_mono (fun x => ENNReal.rpow_le_rpow (hbound x) hp)
      _ = _ := by simp
  exact ne_top_of_le_ne_top (ENNReal.mul_ne_top (ENNReal.rpow_ne_top_of_nonneg hp hB) hΩ) hi

/-- After the actual binary packet choice, the projected reset measure is
finite, absolutely continuous, and nonzero whenever the selected mass is nonzero. -/
theorem atlas_selected_partition_measure_ready {d k s t : ℕ}
    (S : Fin k → SmoothPatch (d+1)) (T : (i : Fin k) → PacketGraphAtlas (S i))
    {r : ℝ} (hr : 0 < r)
    (Q : (i : Fin k) → (j : Fin (T i).size) → CoordinateCapFamily ((T i).patch j).support r)
    (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure)
    (U : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ))
    (e : Ambient (d+1) ≃L[ℝ] Ambient s × Ambient t)
    (Ω : Set (Ambient (d+1))) {R p : ℝ} (hΩ : Ω ⊆ Metric.ball 0 R) (hp : 0 ≤ p)
    (hmass : (∫⁻ x in Ω,
      ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
        (fun i => (T i).cellInput (Q i) hr (f i) (U i)) x‖ₑ ^ p) ≠ 0) :
    let μ := partitionDensity (fun _ => Measure.hausdorffMeasure (d : ℝ))
      (fun i => (T i).cellInput (Q i) hr (f i) (U i)) Ω p
    IsFiniteMeasure (μ.map (fun x => (e x).1)) ∧
      μ.map (fun x => (e x).1) ≪ volume ∧ μ.map (fun x => (e x).1) ≠ 0 := by
  let μ := partitionDensity (fun _ => Measure.hausdorffMeasure (d : ℝ))
    (fun i => (T i).cellInput (Q i) hr (f i) (U i)) Ω p
  letI : IsFiniteMeasure μ := partitionDensity_finite_volume _ _ Ω
    (ne_top_of_le_ne_top measure_ball_lt_top.ne (measure_mono hΩ)) hp
  refine ⟨inferInstance, projected_partitionDensity_absolutelyContinuous e _ _ Ω p, ?_⟩
  intro hzero
  have hh := projected_partitionDensity_mass e (fun _ => Measure.hausdorffMeasure (d : ℝ))
    (fun i => (T i).cellInput (Q i) hr (f i) (U i)) Ω p
  change μ.map (fun x => (e x).1) univ = _ at hh
  rw [hzero] at hh
  exact hmass (by simpa using hh.symm)

end N2Restriction
#print axioms N2Restriction.enorm_extension_L1_bound
#print axioms N2Restriction.partitionDensity_finite_volume
#print axioms N2Restriction.atlas_selected_partition_measure_ready
