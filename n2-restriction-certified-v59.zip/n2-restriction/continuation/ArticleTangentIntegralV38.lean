import continuation.ArticleCorollary43V38
import N2Restriction.PowerRecurrence

namespace N2Restriction
open MeasureTheory Metric Set Filter
open scoped ENNReal NNReal BigOperators

/-- The packet angular width is eventually inside the fixed localization
threshold. The radius threshold is independent of plane and input. -/
theorem packet_width_localization_threshold {τ lam μ₀ : ℝ}
    (hτ : τ < 1/4) (hlam : 0 < lam) (hμ₀ : 0 < μ₀) :
    ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ R : ℝ, R₀ ≤ R →
      0 < lam * R ^ (-1/2+2*τ) ∧ lam * R ^ (-1/2+2*τ) < μ₀ := by
  have hh := eventually_power_small (a := 1/2-2*τ) (by linarith) hμ₀ lam
  obtain ⟨T,hT⟩ := eventually_atTop.1 hh
  refine ⟨max 1 T, le_max_left _ _, ?_⟩
  intro R hR
  have hRpos : 0 < R := lt_of_lt_of_le zero_lt_one ((le_max_left _ _).trans hR)
  refine ⟨mul_pos hlam (Real.rpow_pos_of_pos hRpos _), ?_⟩
  have hs := hT R ((le_max_right _ _).trans hR)
  convert hs using 1
  congr 2
  ring

namespace ArticleLocalizationAtlas
variable {k : ℕ} {S : Fin k → SmoothPatch (k+2)} {κ : ℝ}

/-- The integral bound used in (7.13), on any set contained in the ball.
The exact L2 inputs, codimension-two gain and quasi-Banach exponent are
retained. The chart restriction estimate is the borrowed premise. -/
theorem corollary43_integral_on_subset (A : ArticleLocalizationAtlas S κ)
    {p ε : ℝ} (hp : 0 < p) (hε : 0 < ε) (hexternal : A.UniformLocalizedInput p)
    (c : ℝ≥0) (hc : 0 < c) :
    ∃ μ₀ : ℝ, 0 < μ₀ ∧ ∃ C : ℝ≥0,
      ∀ (q : ArticleFrame S κ) (i₀ : Fin k) (μ : ℝ≥0) (b : ℝ) (x₀ : Ambient (k+2))
        (Q : Set (Ambient (k+2))),
      0 < μ → (μ : ℝ) < μ₀ → 1 ≤ b → Q ⊆ ball x₀ b →
      ∀ g : ∀ i, Lp ℂ 2 (S i).surfaceMeasure,
      HasFrequencySupport (S i₀).surfaceMeasure id
        {x | ‖(pairPlane q.val).orthogonalProjection ((S i₀).normal x)‖ ≤ (c : ℝ)*μ} (g i₀) →
      (∫⁻ x in Q, ‖∏ i, extension (S i).surfaceMeasure id (g i) x‖ₑ ^ p) ≤
        (((C : ℝ≥0∞)*ENNReal.ofReal (b^ε))^p * (μ : ℝ≥0∞)^p) * ∏ i, ‖g i‖ₑ ^ p := by
  obtain ⟨μ₀,hμ₀,C,hC⟩ := A.corollary43_small_width hp hε hexternal c hc
  refine ⟨μ₀,hμ₀,C,?_⟩
  intro q i₀ μ b x₀ Q hμ hs hb hQ g hg
  have hh := localized_integral_gain (fun i => (S i).surfaceMeasure) g
    (volume.restrict (ball x₀ b)) hp ((C : ℝ≥0∞)*ENNReal.ofReal (b^ε)) μ
    (hC q i₀ μ b x₀ hμ hs hb g hg)
  exact (lintegral_mono_set hQ).trans hh

/-- The article exponent q0 is positive in every intended dimension; the
integral application requires no Banach-space triangle inequality. -/
theorem baseline_integral_localization (A : ArticleLocalizationAtlas S κ) (hk : 3 ≤ k)
    {ε : ℝ} (hε : 0 < ε) (hexternal : A.UniformLocalizedInput (baseline k))
    (c : ℝ≥0) (hc : 0 < c) :
    ∃ μ₀ : ℝ, 0 < μ₀ ∧ ∃ C : ℝ≥0,
      ∀ (q : ArticleFrame S κ) (i₀ : Fin k) (μ : ℝ≥0) (b : ℝ) (x₀ : Ambient (k+2))
        (Q : Set (Ambient (k+2))),
      0 < μ → (μ : ℝ) < μ₀ → 1 ≤ b → Q ⊆ ball x₀ b →
      ∀ g : ∀ i, Lp ℂ 2 (S i).surfaceMeasure,
      HasFrequencySupport (S i₀).surfaceMeasure id
        {x | ‖(pairPlane q.val).orthogonalProjection ((S i₀).normal x)‖ ≤ (c : ℝ)*μ} (g i₀) →
      (∫⁻ x in Q, ‖∏ i, extension (S i).surfaceMeasure id (g i) x‖ₑ ^ baseline k) ≤
        (((C : ℝ≥0∞)*ENNReal.ofReal (b^ε))^baseline k * (μ : ℝ≥0∞)^baseline k) *
          ∏ i, ‖g i‖ₑ ^ baseline k := by
  apply A.corollary43_integral_on_subset _ hε hexternal c hc
  have hkR : (3 : ℝ) ≤ k := by exact_mod_cast hk
  unfold baseline
  exact div_pos (by norm_num) (by linarith)

end ArticleLocalizationAtlas
end N2Restriction

#print axioms N2Restriction.packet_width_localization_threshold
#print axioms N2Restriction.ArticleLocalizationAtlas.corollary43_integral_on_subset
#print axioms N2Restriction.ArticleLocalizationAtlas.baseline_integral_localization
