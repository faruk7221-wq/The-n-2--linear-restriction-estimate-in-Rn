import continuation.MeasurableNormalStripV46
import continuation.AtlasCellSupportV42

namespace N2Restriction
open Set Metric MeasureTheory
open scoped NNReal

/-- The actual rotated surface packet is supported in a thin normal strip,
with the normal variation across its original frequency cap included. -/
theorem PacketGraphAtlas.packet_normal_strip {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) {r : ℝ}
    (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r) (hr : 0 < r)
    (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
    (j : Fin T.size) (c : (Q j).centers) (ν : Fin d → ℤ)
    (H : Submodule ℝ (Ambient (d+1))) {η α β : ℝ} {M : ℝ≥0}
    (hη : 0 ≤ η)
    (hinside : closedBall ((T.patch j).rotation ((T.graph j).parametrization c)) η ⊆ S.neighborhood)
    (hN : LipschitzOnWith M S.normal
      (closedBall ((T.patch j).rotation ((T.graph j).parametrization c)) η))
    (hcap : (1 + ((T.graph j).lipConstant : ℝ)) * (2*r) ≤ η)
    (herr : α + (M : ℝ) * ((1 + ((T.graph j).lipConstant : ℝ)) * (2*r)) ≤ β)
    (haxis : ‖H.starProjection (T.cellAxisDirection j c)‖ ≤ α) :
    HasFrequencySupport (Measure.hausdorffMeasure (d : ℝ)) id (normalStrip S H β)
      ((T.graph j).rotatedAmbientInput (T.patch j).rotation ((T.graph j).packet (Q j) hr (f j) c ν)) := by
  apply (T.graph j).rotatedAmbientInput_support
  have hs := (T.graph j).packet_ambient_support (Q j) hr (f j) c ν
  filter_upwards [hs] with x hx hn
  have hd : dist ((T.patch j).rotation x)
      ((T.patch j).rotation ((T.graph j).parametrization c)) ≤
      (1 + ((T.graph j).lipConstant : ℝ)) * (2*r) := by
    rw [(T.patch j).rotation.dist_map]
    exact (hx hn).le
  exact ⟨hinside (hd.trans hcap),
    (normal_strip_of_lipschitz S.normal H _ hη hcap hN haxis hd).trans herr⟩

/-- A common normal-strip bound survives every summable selection of the
original atlas packets. Constants are fixed before scale and selection. -/
theorem PacketGraphAtlas.selected_normal_strip {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) :
    ∃ η : ℝ, 0 < η ∧ ∃ M : ℝ≥0, ∀ (r : ℝ)
      (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r) (hr : 0 < r)
      (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
      (H : Submodule ℝ (Ambient (d+1))) (α β : ℝ)
      (U : (j : Fin T.size) → (Q j).centers → Set (Fin d → ℤ)),
      (∀ j, (1 + ((T.graph j).lipConstant : ℝ)) * (2*r) ≤ η) →
      (∀ j, α + (M : ℝ) * ((1 + ((T.graph j).lipConstant : ℝ)) * (2*r)) ≤ β) →
      (∀ j c, (U j c).Nonempty → ‖H.starProjection (T.cellAxisDirection j c)‖ ≤ α) →
      HasFrequencySupport (Measure.hausdorffMeasure (d : ℝ)) id
        (normalStrip S H β) (T.cellInput Q hr f U) := by
  obtain ⟨η,hη,M,hM⟩ := T.normal_lipschitz_at_cap_centers
  refine ⟨η,hη,M,?_⟩
  intro r Q hr f H α β U hcap herr haxis
  have hm := measurableSet_normalStrip S H β
  apply HasFrequencySupport.sum_L2 _ _ hm
  intro j
  apply HasFrequencySupport.sum_L2 _ _ hm
  intro c
  apply HasFrequencySupport.tsum_L2 _ _ hm _ ((T.cap_packet_summable Q hr f j c).subtype (U j c))
  intro ν
  have hc := hM j c ((Q j).centers_mem c.property)
  exact T.packet_normal_strip Q hr f j c ν.val H hη.le hc.1 hc.2 (hcap j) (herr j)
    (haxis j c ⟨ν.val,ν.property⟩)

end N2Restriction
#print axioms N2Restriction.PacketGraphAtlas.packet_normal_strip
#print axioms N2Restriction.PacketGraphAtlas.selected_normal_strip
