import continuation.CenteredCylinderPerturbationV32
import continuation.ProjectionDensityV32

namespace N2Restriction
open Set Metric
open scoped ENNReal

/-- Countable weighted perturbed cylinders are dominated on any physical
ball by corrected-center reference cylinders. -/
theorem centered_perturbed_cylinder_density_bound {E F P : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    (A : P → E →L[ℝ] F) (Q : E →L[ℝ] F) (z : P → F) (u : P → ℝ≥0∞)
    (x₀ : E) (R w δ : ℝ) (hδ : 0 ≤ δ) (hA : ∀ t, ‖A t - Q‖ ≤ δ)
    {x : E} (hx : x ∈ closedBall x₀ R) :
    tubeDensity (fun t => A t ⁻¹' closedBall (z t) w) u x ≤
      tubeDensity (fun t => closedBall (z t + (Q - A t) x₀) (w + δ * R)) u (Q x) := by
  exact tubeDensity_le_pullback_on _ _ u Q (closedBall x₀ R)
    (fun t => centered_perturbed_projection_cylinder_subset (A t) Q x₀ (z t) R w δ hδ (hA t)) hx

end N2Restriction

#print axioms N2Restriction.centered_perturbed_cylinder_density_bound
