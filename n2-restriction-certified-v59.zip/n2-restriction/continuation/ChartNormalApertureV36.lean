import continuation.DerivativeNormalGapV36
import continuation.UniformChartSeparationV24

namespace N2Restriction
open Metric

/-- Second derivative control implies a Lipschitz bound for tangent maps on
the common convex chart ball. -/
theorem chart_derivative_lipschitz {d m : ℕ} (φ : Ambient d → Ambient m) (r D : ℝ)
    (hs : ∀ t ∈ closedBall 0 r, ContDiffAt ℝ (⊤ : ℕ∞) φ t)
    (hD : ∀ t ∈ closedBall 0 r, ‖iteratedFDeriv ℝ 2 φ t‖ ≤ D)
    (s t : Ambient d) (hsr : s ∈ closedBall 0 r) (htr : t ∈ closedBall 0 r) :
    ‖fderiv ℝ φ s-fderiv ℝ φ t‖ ≤ D*dist s t := by
  have hdiff : ∀ t ∈ closedBall 0 r, DifferentiableAt ℝ (fderiv ℝ φ) t := by
    intro t ht
    exact ((hs t ht).fderiv_right (m := 1) (by norm_cast)).differentiableAt (by simp)
  have hd : ∀ t ∈ closedBall 0 r, ‖fderiv ℝ (fderiv ℝ φ) t‖ ≤ D := by
    intro t ht
    rw [norm_second_fderiv_eq_iterated]
    exact hD t ht
  simpa only [dist_eq_norm] using
    (convex_closedBall (0 : Ambient d) r).norm_image_sub_le_of_norm_fderiv_le hdiff hd htr hsr

/-- One parameter radius gives any prescribed normal-plane aperture for all
charts with common inverse-derivative and second-derivative bounds. The
radius is independent of both the chart and its domain and target dimensions. -/
theorem uniform_controlled_chart_normal_aperture (r M D ε : ℝ)
    (hr : 0 < r) (hM : 0 ≤ M) (hD : 0 ≤ D) (hε : 0 < ε) :
    ∃ ρ : ℝ, 0 < ρ ∧ ρ ≤ r ∧ ∀ (d m : ℕ) (φ : Ambient d → Ambient m),
      (∀ t ∈ closedBall 0 r, ContDiffAt ℝ (⊤ : ℕ∞) φ t) →
      (∀ t ∈ closedBall 0 r, ‖iteratedFDeriv ℝ 2 φ t‖ ≤ D) →
      (∀ t ∈ closedBall 0 r, ∀ v, ‖v‖ ≤ M*‖fderiv ℝ φ t v‖) →
      ∀ t ∈ closedBall 0 ρ,
        ‖(LinearMap.range (fderiv ℝ φ t).toLinearMap)ᗮ.starProjection-
          (LinearMap.range (fderiv ℝ φ 0).toLinearMap)ᗮ.starProjection‖ ≤ ε := by
  let L := 2*(M+1)*D
  have hL : 0 ≤ L := by dsimp [L]; positivity
  let ρ := min r (ε/(L+1))
  have hρ : 0 < ρ := lt_min hr (div_pos hε (by linarith))
  have hρr : ρ ≤ r := min_le_left _ _
  have hLρ : L*ρ ≤ ε := by
    have hh := (le_div_iff₀ (by linarith : 0 < L+1)).mp (min_le_right r (ε/(L+1)))
    change ρ*(L+1) ≤ ε at hh
    nlinarith
  refine ⟨ρ,hρ,hρr,?_⟩
  intro d m φ hs hd hl t ht
  have ht' := closedBall_subset_closedBall hρr ht
  have h0 : (0 : Ambient d) ∈ closedBall 0 r := mem_closedBall_self hr.le
  have hlo (s : Ambient d) (hsr : s ∈ closedBall 0 r) (v : Ambient d) :
      (1/(M+1))*‖v‖ ≤ ‖fderiv ℝ φ s v‖ := by
    rw [one_div_mul_eq_div]
    apply (div_le_iff₀ (by linarith : 0 < M+1)).mpr
    have hh := hl s hsr v
    nlinarith [norm_nonneg (fderiv ℝ φ s v)]
  have hh := chart_normal_gap_of_lipschitz φ t 0 (1/(M+1)) D
    (by positivity) (hlo t ht') (hlo 0 h0) (chart_derivative_lipschitz φ r D hs hd t 0 ht' h0)
  have heq : 2*D/(1/(M+1)) = L := by dsimp [L]; field_simp
  rw [heq] at hh
  exact hh.trans ((mul_le_mul_of_nonneg_left (mem_closedBall.mp ht) hL).trans hLρ)

end N2Restriction

#print axioms N2Restriction.chart_derivative_lipschitz
#print axioms N2Restriction.uniform_controlled_chart_normal_aperture
