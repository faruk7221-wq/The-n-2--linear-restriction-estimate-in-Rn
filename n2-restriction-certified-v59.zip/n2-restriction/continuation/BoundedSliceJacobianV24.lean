import continuation.ParameterSliceJacobianV23
namespace N2Restriction
open Metric Filter
/-- Physical differentials of fixed-parameter uniformly distorted slices inherit both
inverse-chart bounds. The physical norm equals the full norm because the
parameter differential vanishes. -/
theorem SubmersionChartModel.Controls.bounded_physical_slice_derivative
    {P F : Type*} {d n : ℕ}
    [NormedAddCommGroup P] [NormedSpace ℝ P] [FiniteDimensional ℝ P]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    {c : SubmersionChartModel (P × Ambient n) (P × F)} {f : P × Ambient n → F}
    {U : Set (P × Ambient n)} {x : P × Ambient n} {r : ℝ} {B : ℕ → ℝ}
    (h : c.Controls (fun q => (q.1, f q)) U x r B) (hU : IsOpen U) (hB : 0 ≤ B 1)
    {y : (P × F) × c.free} (hy : y ∈ closedBall (c.chart x) r)
    (g : Ambient d →L[ℝ] (P × F) × c.free) (hg : ∀ v, (g v).1.1 = 0)
    {L : ℝ} (hL : 0 ≤ L) (hup : ‖g‖ ≤ L) (hlo : ∀ v, ‖v‖ ≤ L * ‖g v‖) :
    let A := ((ContinuousLinearMap.snd ℝ P (Ambient n)).comp
      (fderiv ℝ (c.chart.symm : (P × F) × c.free → P × Ambient n) y)).comp
        g
    ‖A‖ ≤ B 1 * L ∧ ∀ v, ‖v‖ ≤ (B 1 * L) * ‖A v‖ := by
  let D := fderiv ℝ (c.chart.symm : (P × F) × c.free → P × Ambient n) y
  have he : ∀ v, ‖D (g v)‖ = ‖(D (g v)).2‖ := by
    intro v
    rw [Prod.norm_def, h.inverse_parameter_derivative hy (g v), hg v,
      norm_zero, max_eq_right (norm_nonneg _)]
  dsimp only
  constructor
  · apply ContinuousLinearMap.opNorm_le_bound _ (mul_nonneg hB hL)
    intro v
    have hb := (h.inverse_derivative_bounds hU hy (g v)).1
    change ‖D (g v)‖ ≤ B 1 * ‖g v‖ at hb
    rw [he] at hb
    exact hb.trans (by simpa [mul_assoc] using
      mul_le_mul_of_nonneg_left (g.le_of_opNorm_le hup v) hB)
  · intro v
    have hb := (h.inverse_derivative_bounds hU hy (g v)).2
    change ‖g v‖ ≤ B 1 * ‖D (g v)‖ at hb
    rw [he] at hb
    exact (hlo v).trans (by simpa [mul_assoc, mul_comm, mul_left_comm] using
      mul_le_mul_of_nonneg_left hb hL)

/-- Uniform positive Jacobian bounds for the physical slices of every
augmented chart with common control. External parameters may vary freely, and L controls both linear distortions. -/
theorem bounded_parameter_sliceJacobian_bounds (d n : ℕ) (B : ℕ → ℝ) (hB : 0 ≤ B 1) (L : ℝ) (hL : 0 ≤ L) :
    ∃ a b : ℝ, 0 < a ∧ 0 < b ∧
      ∀ (P F : Type) [NormedAddCommGroup P] [NormedSpace ℝ P] [FiniteDimensional ℝ P]
        [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
        (c : SubmersionChartModel (P × Ambient n) (P × F))
        (f : P × Ambient n → F) (U : Set (P × Ambient n)) (x : P × Ambient n) (r : ℝ),
        c.Controls (fun q => (q.1, f q)) U x r B → IsOpen U →
        ∀ y ∈ closedBall (c.chart x) r,
        ∀ g : Ambient d →L[ℝ] (P × F) × c.free, (∀ v, (g v).1.1 = 0) →
        ‖g‖ ≤ L → (∀ v, ‖v‖ ≤ L * ‖g v‖) →
          let A := ((ContinuousLinearMap.snd ℝ P (Ambient n)).comp
            (fderiv ℝ (c.chart.symm : (P × F) × c.free → P × Ambient n) y)).comp
              g
          a ≤ sliceJacobian A ∧ sliceJacobian A ≤ b := by
  obtain ⟨a, b, ha, hb, hJ⟩ := uniform_sliceJacobian_bounds d n (B 1 * L)
  refine ⟨a, b, ha, hb, ?_⟩
  intro P F _ _ _ _ _ _ c f U x r hc hU y hy g hg hup hlo
  obtain ⟨hA, hl⟩ := hc.bounded_physical_slice_derivative hU hB hy g hg hL hup hlo
  exact hJ _ hA hl

end N2Restriction

#print axioms N2Restriction.SubmersionChartModel.Controls.bounded_physical_slice_derivative
#print axioms N2Restriction.bounded_parameter_sliceJacobian_bounds
