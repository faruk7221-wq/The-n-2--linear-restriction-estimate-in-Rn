import continuation.ActualCubeFullIntegralV49
import continuation.CubeBallBinaryIntegralV49
import continuation.TerminalCubeFrameDataV49
import continuation.ActualTangentSumV48

namespace N2Restriction
open MeasureTheory Set Metric Filter
open scoped ENNReal NNReal

/-- The actual Ftan on one cube is bounded by its common original Kakeya
energy and a rapid error. Binary choices and covering-ball multiplicity are
summed internally, using only explicit terminal geometric frame data. -/
theorem actualTangentSum_cube_integral {k : ℕ}
    (S : Fin k → SmoothPatch (k+2)) (A : (i : Fin k) → PacketGraphAtlas (S i))
    {κ : ℝ} (B : ArticleLocalizationAtlas S κ)
    (V : Fin k → Set (Ambient (k+2))) (m : ℝ)
    (hS : ∀ i, (S i).extendedSurface ∩ V i ⊆ (S i).support) (hm : 0 < m)
    {p ε τ lam : ℝ} (hp : 0 < p) (hp1 : p ≤ 1) (hε : 0 < ε)
    (hexternal : B.UniformLocalizedInput p) (hτ : 0 < τ) (hτ' : τ < 1/4) (hlam : 0 < lam) :
    ∃ D : ℝ≥0, ∃ H M R₀ : ℝ, 0 ≤ H ∧ 1 ≤ M ∧ 1 ≤ R₀ ∧
    ∀ N : ℝ, ∃ Cerr : ℝ, 0 ≤ Cerr ∧ ∀ R : ℝ, R₀ ≤ R →
    ∀ (Q : (i : Fin k) → (j : Fin (A i).size) →
      CoordinateCapFamily ((A i).patch j).support (R^(-1/2 : ℝ)))
      (hr : 0 < R^(-1/2 : ℝ)), (∀ i, R^(-1/2 : ℝ) ≤ (A i).capRadius) →
    ∀ Bcap : ℝ, 0 ≤ Bcap →
    (∀ i j, ((Q i j).centers.card : ℝ) ≤ Bcap*R^(((k+1 : ℕ) : ℝ)/2)) →
    ∀ (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure)
      (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure),
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
    (∀ i j, HasFrequencySupport ((A i).graph j).surfaceMeasure ((A i).patch j).rotation
      (marginRegion (V i) (m-R^(-1/4 : ℝ))) (f i j)) →
    ∀ (L : ℕ) (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin (k+1) → ℤ))
      (Z : Set (Ambient (k+2))) (T : Ambient (k+2) → Submodule ℝ (Ambient (k+2)))
      (c : Fin L → Ambient (k+2)) (C C₀ θ : ℝ) (Ω : Set (Ambient (k+2))) (q : Ambient (k+2)),
    1 ≤ C → 1+Real.sqrt (k+2 : ℕ)*(1+C)/2 ≤ C₀ → 0 < θ →
    (∀ l t, l ≠ t → 2*(θ*(R^(1-τ))) ≤ dist (c l) (c t)) →
    MeasurableSet Ω → Ω ⊆ closedBall 0 R →
    (∀ l, ((Ω ∩ ball (c l) (R^(1-τ))) ∩ gridCube q (lam*R^(1/2+τ))).Nonempty →
      HasTerminalCubeFrame S κ Z T (c l) q (R^(1-τ)) (lam*R^(1/2+τ))) →
    (∫⁻ y in gridCube q (lam*R^(1/2+τ)),
      (actualTangentSum A Q hr f U Z T c (R^(1-τ)) (lam*R^(1/2+τ)) C₀ R (R^(1/2+τ)/10) Ω y)^p) ≤
      ENNReal.ofReal (((1+Real.sqrt (k+2 : ℕ)/2)/θ+1)^(k+2)) * ((2^k : ENNReal) *
        (((((D : ENNReal)*ENNReal.ofReal (((1+Real.sqrt (k+2 : ℕ))*(lam*R^(1/2+τ)))^ε))^p *
          (ENNReal.ofReal (lam*R^(-1/2+2*τ)))^p) *
          ((ENNReal.ofReal H)^(p/2) *
            (∏ i, (A i).cubeEnergy (Q i) hr (f i) R (R^(1/2+τ)/10) C (lam*R^(1/2+τ)) q)^(p/2))) +
        (ENNReal.ofReal ((k : ℝ)*(Cerr*Real.sqrt Bcap*R^(-N))*M^k*∏ i, ‖g i‖))^p*
          volume (gridCube q (lam*R^(1/2+τ))))) := by
  obtain ⟨D,H,M,R₀,hH,hM,hR₀,ht⟩ := actual_tangent_cube_full_integral S A B V m hS hm hp hp1 hε hexternal hτ hτ' hlam
  obtain ⟨Rw,hw⟩ := eventually_atTop.1 (eventually_terminal_width_le_radius hτ' lam)
  refine ⟨D,H,M,max R₀ Rw,hH,hM,hR₀.trans (le_max_left _ _),fun N => ?_⟩
  obtain ⟨Cerr,hCerr,hc⟩ := ht N
  refine ⟨Cerr,hCerr,?_⟩
  intro R hR Q hr hsmall Bcap hBcap hcount g f he hf L U Z T c C C₀ θ Ω q hC hC₀ hθ hsep hΩ hΩR hframe
  have hRold := (le_max_left R₀ Rw).trans hR
  have hRpos : 0 < R := zero_lt_one.trans_le (hR₀.trans hRold)
  have hb : 0 ≤ lam*R^(1/2+τ) := mul_nonneg hlam.le (Real.rpow_nonneg hRpos.le _)
  apply cube_ball_binary_integral (Real.rpow_pos_of_pos hRpos _) hθ hb
    (hw R ((le_max_right R₀ Rw).trans hR)) hp hp1 q c hsep Ω hΩ
    (fun l σ y => ‖extensionProduct (fun _ => Measure.hausdorffMeasure ((k+1 : ℕ) : ℝ)) (fun _ => id)
      (fun i => (A i).cellInput (Q i) hr (f i)
        (if σ i then (A i).actualTangentSelection (Q i) (U i) Z T (c l) (R^(1-τ)) (lam*R^(1/2+τ)) C₀ R (R^(1/2+τ)/10) Ω
         else (A i).actualNontangentSelection (Q i) (U i) Z T (c l) (R^(1-τ)) (lam*R^(1/2+τ)) C₀ R (R^(1/2+τ)/10) Ω)) y‖ₑ)
    (fun l σ => measurable_atlas_selected_product A Q hr hsmall f _)
  intro l σ hσ _hmeet
  let E := (Ω ∩ ball (c l) (R^(1-τ))) ∩ gridCube q (lam*R^(1/2+τ))
  by_cases hne : E.Nonempty
  · obtain ⟨x,z,F,frame,hz,hxb,hxq,hzx,hplane⟩ := hframe l hne
    obtain ⟨i₀,hi₀⟩ := exists_true_of_ne_all_false σ (Finset.mem_erase.mp hσ).1
    have hh := hc R hRold Q hr hsmall Bcap hBcap hcount g f he hf i₀ Z T F (c l) q x z C C₀ Ω E
      (U i₀) (fun i => if σ i then (A i).actualTangentSelection (Q i) (U i) Z T (c l) (R^(1-τ)) (lam*R^(1/2+τ)) C₀ R (R^(1/2+τ)/10) Ω
         else (A i).actualNontangentSelection (Q i) (U i) Z T (c l) (R^(1-τ)) (lam*R^(1/2+τ)) C₀ R (R^(1/2+τ)/10) Ω)
      frame hplane hC hC₀ hz hxb hxq hzx inter_subset_right
      ((hΩ.inter isOpen_ball.measurableSet).inter (measurableSet_gridCube _ _))
      (fun y hy => hΩR hy.1.1) (by simp [hi₀])
    exact hh.trans (add_le_add_left (mul_le_mul_left' (measure_mono (show E ⊆ gridCube q (lam*R^(1/2+τ)) from inter_subset_right)) _) _)
  · have hEmpty : E = ∅ := Set.not_nonempty_iff_eq_empty.mp hne
    change (∫⁻ y in E, _) ≤ _
    rw [hEmpty]
    simp

end N2Restriction
#print axioms N2Restriction.actualTangentSum_cube_integral
