import continuation.SpatialDecayAssemblyV58
namespace N2Restriction
open Set MeasureTheory Metric
set_option maxHeartbeats 1200000

/-- A finite open cover of the unit sphere gives one coefficient before all
directions and frequencies. No angular partition or angular amplitude is needed. -/
theorem uniform_half_decay_of_direction_neighborhoods {n : ℕ} (S : SmoothPatch n)
    (ψ : Ambient n → ℂ)
    (hnear : ∀ θ₀ : Ambient n, ‖θ₀‖ = 1 →
      ∃ W : Set (Ambient n), IsOpen W ∧ θ₀ ∈ W ∧ ∃ C : ℝ, 0 ≤ C ∧
        ∀ θ ∈ W, ∀ freq : ℝ, 1 ≤ freq →
          ‖extension ((Measure.hausdorffMeasure ((n : ℝ)-1)).restrict S.extendedSurface)
            id ψ (freq • θ)‖ ≤ C*freq^(-(1/2 : ℝ))) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ θ : Ambient n, ‖θ‖ = 1 → ∀ freq : ℝ, 1 ≤ freq →
      ‖extension ((Measure.hausdorffMeasure ((n : ℝ)-1)).restrict S.extendedSurface)
        id ψ (freq • θ)‖ ≤ C*freq^(-(1/2 : ℝ)) := by
  classical
  let K := sphere (0 : Ambient n) 1
  have hnorm : ∀ θ : K, ‖(θ : Ambient n)‖ = 1 := fun θ => by
    simpa only [K,Metric.mem_sphere,dist_zero_right] using θ.property
  choose W hWo hθW C hC hbound using fun θ : K => hnear θ (hnorm θ)
  have hcov : K ⊆ ⋃ θ : K, W θ := by
    intro θ hθ
    exact mem_iUnion.mpr ⟨⟨θ,hθ⟩,hθW ⟨θ,hθ⟩⟩
  obtain ⟨m,f,hf⟩ := exists_fin_open_subcover K (isCompact_sphere _ _) W hWo hcov
  refine ⟨∑ j : Fin m, C (f j),Finset.sum_nonneg (fun j _ => hC (f j)),?_⟩
  intro θ hθ freq hfq
  have hθK : θ ∈ K := by simpa only [K,Metric.mem_sphere,dist_zero_right] using hθ
  obtain ⟨j,hj⟩ := mem_iUnion.mp (hf hθK)
  exact (hbound (f j) θ hj freq hfq).trans
    (mul_le_mul_of_nonneg_right
      (Finset.single_le_sum (fun l _ => hC (f l)) (Finset.mem_univ j))
      (Real.rpow_nonneg (by linarith) _))
end N2Restriction
#print axioms N2Restriction.uniform_half_decay_of_direction_neighborhoods
