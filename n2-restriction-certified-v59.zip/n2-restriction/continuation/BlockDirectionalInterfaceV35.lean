import continuation.DirectionalBlockLinesV35
import continuation.ExternalKakeyaInterfaceV22

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal BigOperators

/-- Exact agreement with the tube definition used by the existing packet
and finite-directional Kakeya interfaces. -/
theorem affineLineTube_eq_normalLineTube {n : ℕ} (a v : Ambient n) (w : ℝ) :
    affineLineTube a v w = normalLineTube a v w := affineLineTube_eq_infDist a v w

/-- The proved block-line estimate plugs directly into the project's finite
directional interface on open balls. General independent-line coordinate
construction is the remaining input for the literal external proposition. -/
theorem uniform_block_finite_directional_kakeya (m n : ℕ) (d : Fin (n+2) → ℕ)
    (hd : (∑ i, d i) = m) (M : ℝ) (hM : 1 ≤ M) (η : ℝ) (hη : 0 < η) :
    ∃ C : ℝ≥0∞, 0 < C ∧ C ≠ ⊤ ∧ ∃ ε : ℝ, 0 < ε ∧
      ∀ e : Ambient m ≃L[ℝ] (∀ i, Ambient (d i)),
      ‖e.toContinuousLinearMap‖ ≤ M → ‖e.symm.toContinuousLinearMap‖ ≤ M →
      ∀ (v₀ : Fin (n+2) → Ambient m), (∀ i, ‖v₀ i‖ = 1) →
      (∀ i, dependentBlockProjection d e i (v₀ i) = 0) →
      ∀ (R w : ℝ), 0 < w → w ≤ R →
        FiniteDirectionalKakeya (volume.restrict (ball 0 R)) v₀ ε w (1/((n:ℝ)+1))
          (C * ENNReal.ofReal R^η * ENNReal.ofReal w^((m:ℝ)-η)) := by
  obtain ⟨C,hC,hCfin,ε,hε,hb⟩ := uniform_directional_line_dependent_blocks m n d hd M hM η hη
  refine ⟨C,hC,hCfin,ε,hε,?_⟩
  intro e he hei v₀ hunit hker R w hw hwR T _ a v u _hu hv
  have hh := hb e he hei v₀ hunit hker T v a
    (fun i t => by simpa only [dist_eq_norm] using (hv i t).2.le) u 0 R w hw hwR
  calc
    _ ≤ ∫⁻ x in closedBall 0 R,
        (∏ i, ∑ t, (normalLineTube (a i t) (v i t) w).indicator (fun _ => u i t) x) ^ (1/((n:ℝ)+1)) :=
      lintegral_mono_set ball_subset_closedBall
    _ ≤ _ := by
      simpa only [tubeDensity, affineLineTube_eq_normalLineTube, tsum_fintype] using hh

end N2Restriction

#print axioms N2Restriction.affineLineTube_eq_normalLineTube
#print axioms N2Restriction.uniform_block_finite_directional_kakeya
