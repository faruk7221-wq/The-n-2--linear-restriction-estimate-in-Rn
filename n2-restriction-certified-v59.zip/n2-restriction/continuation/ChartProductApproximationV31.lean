import continuation.TranslatedReferenceApproximationV31
import continuation.ReplacementProductErrorV31

namespace N2Restriction
open MeasureTheory Set Metric
open scoped NNReal ENNReal BigOperators

/-- Actual chart products admit replacement of the selected factor by one
zero-fiber input. The error is controlled by the genuine ball L2 energies
of the other factors, at the localized exponent including values below one. -/
theorem translated_chart_product_approximation {k n : ℕ} (hk : 1 < k) (hn : 1 ≤ n)
    (S : Fin k → SmoothPatch n) (Q : Ambient n →L[ℝ] ℝ × ℝ) (z : Fin k → Ambient n)
    {δ r ρ s L α β ε : ℝ} {B : ℕ → ℝ} {c C : ℝ≥0}
    (F : ∀ i, MeasuredTubularChart (S i) Q (z i) δ r ρ s B c C L)
    (i₀ : Fin k) (E : ChartNormalCoordinates (F i₀) α β)
    (hρ : ρ ≤ r) (hL : 0 ≤ L + 1) (hB : ∀ m, 0 ≤ B m)
    (hm : (L + 1) * ε < r - ρ)
    (g : ∀ i, Lp ℂ 2 ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict (F i).carrier))
    (hg : HasFrequencySupport ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict (F i₀).carrier)
      id {y | ‖Q ((S i₀).normal y)‖ ≤ ε} (g i₀)) (x₀ : Ambient n) :
    ∃ f : Lp ℂ 2 (volume : Measure (Ambient (n - 3))),
      HasFrequencySupport volume id
        {v | v ∈ closedBall (0 : Ambient (n - 3)) ((L + 1) * ρ) ∧
          E.equiv.symm (-Q ((S i₀).normal (z i₀)), v) ∈ ball (0 : Ambient (n - 1)) r} f ∧
      ‖f‖ₑ ≤ ENNReal.ofReal β ^ (1 / 2 : ℝ) *
        (ENNReal.ofReal (2 * ε) * (C : ℝ≥0∞) ^ (1 / 2 : ℝ) * ‖g i₀‖ₑ) ∧
      ∀ R : ℝ,
      eLpNorm' (fun x =>
        (∏ i, extension ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict (F i).carrier) id (g i) x) -
        extension volume (fun v => (F i₀).param (E.equiv.symm (-Q ((S i₀).normal (z i₀)), v))) f (x - x₀) *
          ∏ i ∈ Finset.univ.erase i₀,
            extension ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict (F i).carrier) id (g i) x)
        (2 / ((k - 1 : ℕ) : ℝ)) (volume.restrict (ball x₀ R)) ≤
        (referenceErrorCoefficient n C β L ρ (B 1) * ENNReal.ofReal R * ENNReal.ofReal ε ^ 2 * ‖g i₀‖ₑ) *
          ∏ i ∈ Finset.univ.erase i₀,
            (∫⁻ x in ball x₀ R,
              ‖extension ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict (F i).carrier) id (g i) x‖ₑ ^ (2 : ℝ)) ^ (1 / 2 : ℝ) := by
  obtain ⟨f, hs, hf, he⟩ := (F i₀).translated_zero_reference_approximation E hn hρ hL hB hm (g i₀) hg x₀
  refine ⟨f, hs, hf, ?_⟩
  intro R
  apply replacement_product_error (volume.restrict (ball x₀ R)) hk _ i₀ _
  · intro i
    letI := (F i).finite_surface_carrier hn
    exact (continuous_extension_of_memLp measurable_id (Lp.memLp (g i))).enorm.measurable.aemeasurable
  · exact ENNReal.mul_ne_top (ENNReal.mul_ne_top
      (ENNReal.mul_ne_top (referenceErrorCoefficient_ne_top _ _ _ _ _ _) ENNReal.ofReal_ne_top)
      (ENNReal.pow_ne_top ENNReal.ofReal_ne_top)) enorm_ne_top
  · filter_upwards [ae_restrict_mem isOpen_ball.measurableSet] with x hx
    refine (he x).trans ?_
    apply mul_le_mul_right'
    apply mul_le_mul_right'
    apply mul_le_mul_left'
    exact ENNReal.ofReal_le_ofReal (mem_ball.mp hx).le

end N2Restriction

#print axioms N2Restriction.translated_chart_product_approximation
