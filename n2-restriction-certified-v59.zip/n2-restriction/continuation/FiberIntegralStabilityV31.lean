import continuation.FiberPhaseStabilityV30
import continuation.SupportedParametrizationStabilityV31

namespace N2Restriction
open MeasureTheory Set Metric
open scoped NNReal ENNReal

namespace MeasuredTubularChart
/-- A globally measurable representative of a chart on its smooth domain.
No regularity outside that domain is required. -/
theorem measurable_param_representative {n : ℕ} {S : SmoothPatch n}
    {Q : Ambient n →L[ℝ] ℝ × ℝ} {z : Ambient n} {δ r ρ s : ℝ}
    {B : ℕ → ℝ} {c C : ℝ≥0} {L : ℝ}
    (F : MeasuredTubularChart S Q z δ r ρ s B c C L) :
    ∃ φ : Ambient (n - 1) → Ambient n, Measurable φ ∧
      ∀ t ∈ closedBall (0 : Ambient (n - 1)) r, φ t = F.param t := by
  have hc : ContinuousOn F.param (closedBall (0 : Ambient (n - 1)) r) :=
    fun t ht => (F.bounds t ht).2.2.1.continuousAt.continuousWithinAt
  obtain ⟨φ, hφ, he, _⟩ := exists_measurable_zero_extension
    (closedBall (0 : Ambient (n - 1)) r) isClosed_closedBall.measurableSet
    (fun t => F.param t) (continuousOn_iff_continuous_restrict.mp hc).measurable
  exact ⟨φ, hφ, fun t ht => he ⟨t, ht⟩⟩
end MeasuredTubularChart

namespace StripChartAmplitude
variable {n : ℕ} {S : SmoothPatch n} {Q : Ambient n →L[ℝ] ℝ × ℝ} {z : Ambient n}
  {δ r ρ s : ℝ} {B : ℕ → ℝ} {c C : ℝ≥0} {L α β ε : ℝ}
  {F : MeasuredTubularChart S Q z δ r ρ s B c C L}
  {E : ChartNormalCoordinates F α β}
  {g : Lp ℂ 2 ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier)}

/-- Integrating the actual supported phase comparison costs only the common
thin-domain square-root volume and the same normalized L2 input norm. -/
theorem normalizedFiberInput_extension_difference (A : StripChartAmplitude F E g ε)
    (hρ : ρ ≤ r) (hL : 0 ≤ L + 1) (hB : ∀ m, 0 ≤ B m)
    (hm : (L + 1) * ε < r - ρ) (u : ℝ × ℝ) (x : Ambient n) :
    ‖extension volume (fun v => F.param (E.equiv.symm (u, v))) (A.normalizedFiberInput u) x -
      extension volume (fun v => F.param (E.equiv.symm (-Q (S.normal z), v)))
        (A.normalizedFiberInput u) x‖ₑ ≤
      ENNReal.ofReal (2 * ‖x‖ * (B 1 * (L + 1) * ε)) *
        (‖A.normalizedFiberInput u‖ₑ *
          volume (closedBall (0 : Ambient (n - 3)) ((L + 1) * ρ)) ^ (1 / 2 : ℝ)) := by
  obtain ⟨φ, hφ, he⟩ := F.measurable_param_representative
  have hz : ∀ᵐ v ∂volume, A.normalizedFiberInput u v ≠ 0 →
      F.param (E.equiv.symm (u, v)) = φ (E.equiv.symm (u, v)) := by
    filter_upwards [A.normalizedFiberInput_parameter_support u] with v hv hn
    exact (he _ (closedBall_subset_closedBall hρ (hv hn))).symm
  have hr : ∀ᵐ v ∂volume, A.normalizedFiberInput u v ≠ 0 →
      F.param (E.equiv.symm (-Q (S.normal z), v)) = φ (E.equiv.symm (-Q (S.normal z), v)) := by
    filter_upwards [A.normalizedFiberInput_reference_inside hL hm u] with v hv hn
    exact (he _ (ball_subset_closedBall (hv hn))).symm
  have hc : ∀ᵐ v ∂volume, A.normalizedFiberInput u v ≠ 0 →
      dist (φ (E.equiv.symm (u, v))) (φ (E.equiv.symm (-Q (S.normal z), v))) ≤
        B 1 * (L + 1) * ε := by
    filter_upwards [hz, hr, A.normalizedFiberInput_reference_distance hρ hL hB hm u] with v hz hr hv hn
    rw [← hz hn, ← hr hn]
    exact hv hn
  rw [extension_congr_frequency_support volume _ _ _ hz x,
    extension_congr_frequency_support volume _ _ _ hr x]
  apply supported_extension_parametrization_difference volume
    (closedBall (0 : Ambient (n - 3)) ((L + 1) * ρ)) isClosed_closedBall.measurableSet
    ((isCompact_closedBall (0 : Ambient (n - 3)) ((L + 1) * ρ)).measure_lt_top) _ _ _ _ (A.normalizedFiberInput u)
    (A.normalizedFiberInput_thin_support u) hc x
  · exact hφ.comp (E.equiv.symm.continuous.measurable.comp (measurable_const.prodMk measurable_id))
  · exact hφ.comp (E.equiv.symm.continuous.measurable.comp (measurable_const.prodMk measurable_id))

end StripChartAmplitude
end N2Restriction

#print axioms N2Restriction.MeasuredTubularChart.measurable_param_representative
#print axioms N2Restriction.StripChartAmplitude.normalizedFiberInput_extension_difference
