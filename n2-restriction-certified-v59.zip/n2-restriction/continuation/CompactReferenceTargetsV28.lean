import continuation.ReferenceTargetsV28

namespace N2Restriction
open Metric Set
open scoped NNReal

/-- The fixed reference target is compact when the references stay inside the
smooth chart. Its defining strip is closed by the affine normal identity,
without any global smoothness assumption on the extended normal field. -/
theorem ChartNormalCoordinates.compact_zeroTarget {n : ℕ} {S : SmoothPatch n}
    {Q : Ambient n →L[ℝ] ℝ × ℝ} {z : Ambient n} {δ r ρ s : ℝ}
    {B : ℕ → ℝ} {c C : ℝ≥0} {L α β τ : ℝ}
    {F : MeasuredTubularChart S Q z δ r ρ s B c C L}
    (E : ChartNormalCoordinates F α β) (hρ : ρ ≤ r)
    (hinside : ∀ t ∈ closedBall (0 : Ambient (n - 1)) ρ,
      ‖Q (S.normal (F.param t))‖ ≤ τ →
      normalReference E.equiv (Q (S.normal z)) t ∈ closedBall (0 : Ambient (n - 1)) r) :
    IsCompact (E.zeroTarget τ) := by
  let A := {t ∈ closedBall (0 : Ambient (n - 1)) ρ | ‖Q (S.normal (F.param t))‖ ≤ τ}
  have hA : A = closedBall (0 : Ambient (n - 1)) ρ ∩
      {t | ‖Q (S.normal z) + F.normalCoord t‖ ≤ τ} := by
    ext t
    constructor
    · rintro ⟨ht, hs⟩
      exact ⟨ht, by simpa only [(F.bounds t (closedBall_subset_closedBall hρ ht)).2.1] using hs⟩
    · rintro ⟨ht, hs⟩
      exact ⟨ht, by simpa only [(F.bounds t (closedBall_subset_closedBall hρ ht)).2.1] using hs⟩
  have hc : IsCompact A := by
    rw [hA]
    exact (isCompact_closedBall _ _).inter_right
      (isClosed_le (continuous_const.add F.normalCoord.continuous).norm continuous_const)
  apply hc.image_of_continuousOn
  intro t ht
  exact ((F.bounds _ (hinside t ht.1 ht.2)).2.2.1.continuousAt.comp
    (continuous_normalReference E.equiv (Q (S.normal z))).continuousAt).continuousWithinAt

end N2Restriction

#print axioms N2Restriction.ChartNormalCoordinates.compact_zeroTarget
