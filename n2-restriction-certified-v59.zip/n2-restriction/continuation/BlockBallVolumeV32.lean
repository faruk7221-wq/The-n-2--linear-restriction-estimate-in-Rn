import continuation.LinearWeightedCylindersV32
import Mathlib.MeasureTheory.Measure.Lebesgue.EqHaar

namespace N2Restriction
open MeasureTheory Metric
open scoped ENNReal

/-- Exact cross-sectional scaling for the product (max-norm) block balls. -/
theorem block_ball_volume (a b : ℕ) (z : Ambient a × Ambient b) (r : ℝ) (hr : 0 ≤ r) :
    (volume.prod volume) (closedBall z r) = ENNReal.ofReal r ^ (a + b) *
      (volume.prod volume) (closedBall (0 : Ambient a × Ambient b) 1) := by
  rw [Measure.addHaar_closedBall' (volume.prod volume) z hr]
  simp only [Module.finrank_prod, finrank_euclideanSpace, Fintype.card_fin,
    ENNReal.ofReal_pow hr]

/-- The normalization constants for product block balls are finite. -/
theorem block_unit_ball_volume_ne_top (a b : ℕ) :
    (volume.prod volume) (closedBall (0 : Ambient a × Ambient b) 1) ≠ ⊤ :=
  measure_closedBall_lt_top.ne

/-- In dimensions 3+1+1, the three complementary cross-sections have
sizes 2, 4, 4; the half-power product scales exactly as the fifth power. -/
theorem block_311_width_scaling (r A B C u v w : ℝ≥0∞) :
    ((u * (r ^ 2 * A)) ^ (1 / 2 : ℝ) *
     (v * (r ^ 4 * B)) ^ (1 / 2 : ℝ) *
     (w * (r ^ 4 * C)) ^ (1 / 2 : ℝ)) =
    r ^ 5 * ((u * A) ^ (1 / 2 : ℝ) * (v * B) ^ (1 / 2 : ℝ) *
      (w * C) ^ (1 / 2 : ℝ)) := by
  have h2 : (r ^ 2) ^ (1 / 2 : ℝ) = r := by
    rw [← ENNReal.rpow_natCast, ← ENNReal.rpow_mul]
    norm_num
  have h4 : (r ^ 4) ^ (1 / 2 : ℝ) = r ^ 2 := by
    rw [← ENNReal.rpow_natCast, ← ENNReal.rpow_mul]
    norm_num
  simp only [ENNReal.mul_rpow_of_nonneg _ _ (by norm_num : (0 : ℝ) ≤ 1 / 2), h2, h4]
  ring

end N2Restriction

#print axioms N2Restriction.block_311_width_scaling
#print axioms N2Restriction.block_ball_volume
#print axioms N2Restriction.block_unit_ball_volume_ne_top
