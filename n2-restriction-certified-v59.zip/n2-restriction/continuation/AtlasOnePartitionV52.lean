import continuation.AtlasSameClassAllInputsV45
import continuation.ProjectedPartitionCertificateV52
import continuation.NonwallCellMassV43
import continuation.BoundedWallStageConstructionV51
import continuation.BudgetMonotonicityV52
import continuation.HalfBallCoverV42
namespace N2Restriction
open Set Metric MeasureTheory
open scoped BigOperators ENNReal
set_option maxHeartbeats 1200000

/-- One actual polynomial partition gives either the proved same-class
cellular estimate or a genuine bounded factor-wall dimension drop. Canonical
trimmed cells and their retained mass are constructed from borrowed geometric
partition data; no wall/nonwall analytic estimate is assumed. -/
theorem atlas_one_partition_stage_alternative {d k : ℕ}
    (S : Fin k → SmoothPatch (d+1)) (T : (i : Fin k) → PacketGraphAtlas (S i))
    (Vfreq : Fin k → Set (Ambient (d+1))) (margin : ℝ) (hm : 0 < margin)
    (hW : ∀ i, (S i).extendedSurface ∩ Vfreq i ⊆ (S i).support) {τ : ℝ} (hτ : 0 < τ) :
    ∃ B₀ : Fin k → ℝ, (∀ i, 1 ≤ B₀ i) ∧ ∃ M : ℝ, 1 ≤ M ∧
    ∃ q : Finset (Ambient (d+1)), ∃ R₀ : ℝ, 1 ≤ R₀ ∧
    ∀ p : ℝ, 0 < p → p ≤ 1 → ∀ J : ℝ, ∃ C : ℝ, 0 ≤ C ∧
    ∀ (Bstage : PolynomialStageBudget) (Hgeom : ℕ) (Kgeom γ E c₀ c₁ s : ℝ),
    0 ≤ Kgeom → 0 < E → 0 < c₀ →
    ∀ D Nfac : ℕ, 1 ≤ D →
    ∀ R : ℝ, R₀ ≤ R →
    ∀ (Q : (i : Fin k) → (j : Fin (T i).size) → CoordinateCapFamily ((T i).patch j).support (R^(-1/2 : ℝ)))
      (hr : 0 < R^(-1/2 : ℝ)), (∀ i, R^(-1/2 : ℝ) ≤ (T i).capRadius) →
    ∀ Bcap : ℝ, 0 ≤ Bcap → (∀ i j, ((Q i j).centers.card : ℝ) ≤ Bcap*R^((d : ℝ)/2)) →
    ∀ (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure)
      (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure),
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
    (∀ i j, HasFrequencySupport ((T i).graph j).surfaceMeasure ((T i).patch j).rotation
      (marginRegion (Vfreq i) (margin-R^(-1/4 : ℝ))) (f i j)) →
    ∀ (U : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ))
      {M₀ err : ENNReal} (mvar : ℕ)
      (Zs : PolynomialStage (fun _ => Measure.hausdorffMeasure (d : ℝ))
        (fun i => (T i).cellInput (Q i) hr (f i) (U i)) p R (R^(1/2+τ)) M₀ err mvar),
    Zs.withinBudget Bstage →
    ∀ (cuts : Set (Ambient (d+1))) (V : Submodule ℝ (Ambient (d+1))), IsClosed cuts →
    (∀ x ∈ Zs.region, Nonempty (ShortLiftWitness V (polynomialLevelMap Zs.equations)
      {x | polynomialLevelMap Zs.equations x = 0} cuts (Zs.multiplier*R^(1/2+τ)) x)) →
    Zs.region ⊆ thickening (Zs.multiplier*R^(1/2+τ)) (planeWitnessSet Zs.equations cuts V (2*γ)) →
    ∀ far : Finset (Fin k),
    (∀ i ∈ far, ∀ j a ν, ν ∈ U i j a → 4*γ < directionPlaneAngle ((T i).cellAxisDirection j a.val) V) →
    AlgebraicTubeCoverInput {x | polynomialLevelMap Zs.equations x = 0}
      (fun z => LinearMap.ker (fderiv ℝ (polynomialLevelMap Zs.equations) z).toLinearMap) γ Hgeom Kgeom →
    ∀ PC : ProjectedPartitionCertificate Zs.equations V
      (partitionDensity (fun _ => Measure.hausdorffMeasure (d : ℝ))
        (fun i => (T i).cellInput (Q i) hr (f i) (U i)) Zs.region p) Zs.region D Nfac s c₀ c₁ E,
    let Ec := fun i => ((2*E*((k : ℝ)+1)/(1/2))/c₀ * B₀ i * max 2 (max 1 ((Hgeom : ℝ)*(Kgeom+2)^(d+1))))
    (M₀ ≤ (Bstage.mass*ENNReal.ofReal (2*c₁/(1/2))*(q.card : ENNReal)) *
      ENNReal.ofReal ((∏ i, Ec i)^(p/2)*(D : ℝ)^(cellular k s far.card p)) *
      (marginLocalConstant (fun i => (S i).surfaceMeasure) (fun _ => id) Vfreq margin p (R/2))^p *
      (∏ i, ENNReal.ofReal ‖g i‖)^p +
      (Bstage.mass*ENNReal.ofReal (2*c₁/(1/2))*ENNReal.ofReal ((D : ℝ)^s)*
        ((volume (ball (0 : Ambient (d+1)) 1)*(ENNReal.ofReal ((k : ℝ)*C*Real.sqrt Bcap*M^k))^p)*
        ENNReal.ofReal (R^(-J))*(∏ i, ENNReal.ofReal ‖g i‖)^p)+err)) ∨
    (mvar < d+1 ∧ ∃ i : Fin PC.factorCount,
      ∃ Z' : PolynomialStage (fun _ => Measure.hausdorffMeasure (d : ℝ))
        (fun i => (T i).cellInput (Q i) hr (f i) (U i)) p R (R^(1/2+τ)) M₀ err (mvar+1),
      Z'.equations = Fin.cons (PC.factors i) Zs.equations ∧
      Z'.degreeBound = max Zs.degreeBound D ∧ Z'.multiplier = 5*Zs.multiplier ∧
      Z'.region ⊆ Zs.region ∧ Z'.withinBudget (Bstage.advance D 5 (by norm_num)
        ((Nfac : ENNReal)/(2 : ENNReal)⁻¹) (ENNReal.div_ne_top (by simp) (by norm_num)))) := by
  classical
  obtain ⟨B₀,hB₀,M,hM,R₀,hR₀,hb⟩ := atlas_partition_nonwall_same_class_all_inputs S T S Vfreq margin hm hW hτ
  obtain ⟨q,hq⟩ := uniform_half_ball_cover (d+1)
  refine ⟨B₀,hB₀,M,hM,q,R₀,hR₀,?_⟩
  intro p hp hp1 J
  obtain ⟨C,hC,hbound⟩ := hb p hp hp1 J
  refine ⟨C,hC,?_⟩
  intro Bstage Hgeom Kgeom γ E c₀ c₁ s hKgeom hE hc₀ D Nfac hD R hR Q hr hsmall Bcap hBcap hcount g f he hf U M₀ err mvar Zs hB cuts V hcuts hw hregion far hfar hAlg PC
  dsimp only
  let ρ := partitionDensity (fun _ => Measure.hausdorffMeasure (d : ℝ))
    (fun i => (T i).cellInput (Q i) hr (f i) (U i)) Zs.region p
  have hvol : volume Zs.region ≠ ∞ := ne_top_of_le_ne_top measure_closedBall_lt_top.ne
    (measure_mono (Zs.in_ball.trans ball_subset_closedBall))
  letI : IsFiniteMeasure ρ := partitionDensity_finite_volume _ _ Zs.region hvol hp.le
  have hRpos : 0 < R := zero_lt_one.trans_le (hR₀.trans hR)
  have hbpos : 0 < Zs.multiplier*R^(1/2+τ) := mul_pos (by linarith [Zs.multiplier_ge_one]) (Real.rpow_pos_of_pos hRpos _)
  have hwsmall : R^(1/2+τ)/10 < Zs.multiplier*R^(1/2+τ) := by nlinarith [Zs.multiplier_ge_one,Real.rpow_pos_of_pos hRpos (1/2+τ)]
  let wall := thickening (Zs.multiplier*R^(1/2+τ)) {z | ambientPolynomial (∏ i, PC.factors i) z = 0}
  let Δ := fun c => (Zs.region ∩ PolynomialSignRegion PC.factors (PC.label c)) \ wall
  obtain ⟨hmeas,hsub,hsign,htrim,hcover,hupper⟩ := PC.trimmed_cells Zs.measurable hbpos
  have hstage : M₀ ≤ Bstage.mass*ρ univ+err := by
    rw [partitionDensity_mass]
    exact Zs.mass_bound.trans (add_le_add_right (mul_le_mul_right' hB.2.2 _) err)
  by_cases hz : ρ univ = 0
  · left
    have hh : M₀ ≤ err := by simpa only [hz,mul_zero,zero_add] using hstage
    exact hh.trans (le_add_left (le_add_left le_rfl))
  rcases reset_partition_wall_or_cells _ _ Zs.region _ Zs.measurable hvol _ Δ hcover hp.le with hwall|hcells
  · right
    letI : Nonempty (Fin PC.factorCount) := Fin.pos_iff_nonempty.mp PC.factor_pos
    have heval (x : Ambient (d+1)) : ambientPolynomial (∏ i, PC.factors i) x = ∏ i, PC.projected i (V.orthogonalProjection x) := by
      change MvPolynomial.eval (fun j => x j) (∏ i, PC.factors i) = _
      rw [map_prod]
      exact Finset.prod_congr rfl (fun i _ => PC.eval_eq i x)
    have hwall' : (2 : ENNReal)⁻¹ * (∫⁻ x in Zs.region, ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ))
        (fun _ => id) (fun i => (T i).cellInput (Q i) hr (f i) (U i)) x‖ₑ^p) ≤
      ∫⁻ x in Zs.region ∩ thickening (Zs.multiplier*R^(1/2+τ)) {x | (∏ i, PC.projected i (V.orthogonalProjection x)) = 0},
        ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
          (fun i => (T i).cellInput (Q i) hr (f i) (U i)) x‖ₑ^p := by
      rw [partitionDensity_mass,partitionDensity_retained_mass _ _ Zs.region _ p
        (Zs.measurable.inter isOpen_thickening.measurableSet) inter_subset_left] at hwall
      have hh := mul_le_mul_left' hwall (2 : ENNReal)⁻¹
      simpa only [← mul_assoc,ENNReal.inv_mul_cancel (by norm_num : (2 : ENNReal) ≠ 0)
        (by norm_num : (2 : ENNReal) ≠ ∞),one_mul,heval] using hh
    have hpos : 0 < (2 : ENNReal)⁻¹ * (∫⁻ x in Zs.region, ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ))
        (fun _ => id) (fun i => (T i).cellInput (Q i) hr (f i) (U i)) x‖ₑ^p) := by
      rw [← partitionDensity_mass]
      exact ENNReal.mul_pos (by norm_num) hz
    obtain ⟨hdim,i,Z',heq,hdeg,hmult,hconst,hsub,hbudget⟩ := polynomial_wall_stage_with_budget Zs Bstage hB
      PC.factors V PC.projected cuts hcuts hw PC.eval_eq PC.degree_le PC.transverse
      (by norm_num : (2 : ENNReal)⁻¹ ≠ 0) (by norm_num : (2 : ENNReal)⁻¹ ≠ ∞) hpos hwall'
    refine ⟨hdim,i,Z',heq,hdeg,hmult,hsub,?_⟩
    apply Z'.withinBudget_advance_cost_mono Bstage D 5 (by norm_num) _ _ _ hbudget
    simp only [Fintype.card_fin]
    gcongr
    exact_mod_cast PC.factor_count_le
  · left
    letI : Nonempty (Fin PC.cellCount) := Fin.pos_iff_nonempty.mp PC.cell_pos
    have hh := hbound R hR Q hr hsmall Bcap hBcap hcount g f he U Zs.region
      (Zs.in_ball.trans ball_subset_closedBall) hf PC.factors Zs.equations cuts V hKgeom hAlg
      hbpos hwsmall hregion far hfar PC.label PC.label_injective Δ hmeas hsub hsign htrim
      (by norm_num : (0 : ℝ) < 1/2) hE (show (1 : ℝ) ≤ (D : ℝ) by exact_mod_cast hD) hc₀ hcells hupper (by simpa only [Fintype.card_fin] using PC.count_lower) (by simpa only [Fintype.card_fin] using PC.count_upper)
      (by exact_mod_cast PC.product_degree_le) q (hq R hRpos) Bstage.mass M₀ err hstage
    simpa only [mul_assoc] using hh

end N2Restriction
#print axioms N2Restriction.atlas_one_partition_stage_alternative
