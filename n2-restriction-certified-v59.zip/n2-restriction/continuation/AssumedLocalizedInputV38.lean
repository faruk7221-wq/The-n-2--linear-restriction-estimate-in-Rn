import continuation.ArticleLocalizationAtlasV38

set_option maxHeartbeats 1400000

namespace N2Restriction
open MeasureTheory Metric Set
open scoped NNReal ENNReal BigOperators

namespace ArticleLocalizationAtlas
variable {k : ℕ} {S : Fin k → SmoothPatch (k+2)} {κ : ℝ}

/-- External input 1, specialized to a fixed uniform atlas. The constant is
chosen before the plane, selected factor, chart tuple, width, radius, center
and inputs. This is an assumption interface, NOT an asserted theorem. Its
justification from chart regularity/transversality is the borrowed uniform
localized restriction theorem (article External input 1 and Remark 4.2).
No strip estimate, recurrence or main theorem is assumed here. -/
def UniformLocalizedInput (A : ArticleLocalizationAtlas S κ) (p : ℝ) : Prop :=
  ∀ ε : ℝ, 0 < ε → ∃ C : ℝ≥0,
    ∀ (q : ArticleFrame S κ) (i₀ : Fin k) (a : ∀ i, Fin (A.charts i))
      (w R : ℝ) (x₀ : Ambient (k+2)), 0 < w → w < 1 → 1 ≤ R →
      ∀ f : ∀ i, Lp ℂ 2
        ((Measure.hausdorffMeasure (((k+2 : ℕ) : ℝ)-1)).restrict (A.carrier q i (a i))),
      HasFrequencySupport
        ((Measure.hausdorffMeasure (((k+2 : ℕ) : ℝ)-1)).restrict (A.carrier q i₀ (a i₀)))
        id {x | ∃ y ∈ A.target q i₀ (a i₀), dist x y ≤ w} (f i₀) →
      eLpNorm' (fun x => ∏ i, extension
        ((Measure.hausdorffMeasure (((k+2 : ℕ) : ℝ)-1)).restrict (A.carrier q i (a i)))
        id (f i) x) p (volume.restrict (ball x₀ R)) ≤
          ((C : ℝ≥0∞) * ENNReal.ofReal (R ^ ε) * ENNReal.ofReal w) * ∏ i, ‖f i‖ₑ

/-- Explicit finite atlas cost as an ordinary nonnegative constant. -/
noncomputable def assemblyCost (A : ArticleLocalizationAtlas S κ) (p : ℝ) : ℝ≥0 :=
  ((finitePowerLoss (A.count ^ k) p * (A.count ^ k : ℝ≥0∞)) ^ (1 / p)).toNNReal

theorem assemblyCost_coe (A : ArticleLocalizationAtlas S κ) {p : ℝ} (hp : 0 < p) :
    (A.assemblyCost p : ℝ≥0∞) =
      (finitePowerLoss (A.count ^ k) p * (A.count ^ k : ℝ≥0∞)) ^ (1 / p) := by
  exact ENNReal.coe_toNNReal (by simpa only [Nat.cast_pow] using finite_atlas_cost_ne_top (A.count ^ k) hp)

/-- Apply the distance-localized external input after the proved geometric
strip-to-distance reduction, and assemble all original Hausdorff inputs.
The coefficient is independent of the frame, width, radius and input. -/
theorem strip_bound_of_external_input (A : ArticleLocalizationAtlas S κ)
    {p ε : ℝ} (hp : 0 < p) (hε : 0 < ε) (hexternal : A.UniformLocalizedInput p) :
    ∃ C : ℝ≥0, ∀ (q : ArticleFrame S κ) (i₀ : Fin k) (δ : ℝ≥0)
      (R : ℝ) (x₀ : Ambient (k+2)),
      0 < δ → (δ : ℝ) ≤ A.threshold → (A.distanceCost : ℝ) * δ < 1 → 1 ≤ R →
      ∀ g : ∀ i, Lp ℂ 2 (S i).surfaceMeasure,
      HasFrequencySupport (S i₀).surfaceMeasure id
        {x | ‖(pairPlane q.val).orthogonalProjection ((S i₀).normal x)‖ ≤ (δ : ℝ)} (g i₀) →
      eLpNorm' (fun x => ∏ i, extension (S i).surfaceMeasure id (g i) x) p
        (volume.restrict (ball x₀ R)) ≤
          ((C : ℝ≥0∞) * ENNReal.ofReal (R ^ ε) * (δ : ℝ≥0∞)) * ∏ i, ‖g i‖ₑ := by
  obtain ⟨C, hC⟩ := hexternal ε hε
  refine ⟨A.assemblyCost p * C * A.distanceCost, ?_⟩
  intro q i₀ δ R x₀ hδ hδτ hw hR g hg
  let μ : Fin k → Measure (Ambient (k+2)) :=
    fun _ => Measure.hausdorffMeasure (((k+2 : ℕ) : ℝ)-1)
  letI (i : Fin k) : IsFiniteMeasure ((μ i).restrict (S i).support) :=
    (S i).isFiniteMeasure_surfaceMeasure (by omega)
  let B : ℝ≥0 := ⟨R ^ ε, Real.rpow_nonneg (by linarith) _⟩
  let C' : ℝ≥0 := C * B * A.distanceCost
  have hpow : (B : ℝ≥0∞) = ENNReal.ofReal (R ^ ε) := ENNReal.coe_nnreal_eq B
  have hlocal : ∀ (a : ∀ i, Fin (A.charts i))
      (f : ∀ i, Lp ℂ 2 ((μ i).restrict (A.carrier q i (a i)))),
      HasFrequencySupport ((μ i₀).restrict (A.carrier q i₀ (a i₀))) id
        {x | ∃ y ∈ A.target q i₀ (a i₀), dist x y ≤ (A.distanceCost : ℝ) * δ} (f i₀) →
      eLpNorm' (fun x => ∏ i, extension ((μ i).restrict (A.carrier q i (a i))) id (f i) x)
        p (volume.restrict (ball x₀ R)) ≤
          ((C' : ℝ≥0∞) * (δ : ℝ≥0∞)) * ∏ i, ‖f i‖ₑ := by
    intro a f hf
    have hh := hC q i₀ a ((A.distanceCost : ℝ) * δ) R x₀
      (mul_pos A.distanceCost_pos hδ) hw hR f hf
    simpa only [C', ENNReal.coe_mul, ENNReal.ofReal_mul A.distanceCost.coe_nonneg,
      ENNReal.ofReal_coe_nnreal, hpow, mul_assoc] using hh
  have hh := uniform_cardinality_thickness_assembly μ (fun i => (S i).support)
    (fun i => (S i).compact_support.measurableSet) A.charts A.count A.count_bound
    (A.carrier q) (fun i j => (A.compact_carrier q i j).measurableSet) (A.covers q)
    i₀ (S i₀) q.property.1 (A.target q i₀) A.distanceCost.coe_nonneg δ hδτ
    (A.localizes q i₀) g hg (volume.restrict (ball x₀ R)) hp C' hlocal
  simpa only [← A.assemblyCost_coe hp, C', ENNReal.coe_mul, hpow,
    mul_assoc, mul_left_comm, mul_comm] using hh

end ArticleLocalizationAtlas
end N2Restriction

#print axioms N2Restriction.ArticleLocalizationAtlas.assemblyCost_coe
#print axioms N2Restriction.ArticleLocalizationAtlas.strip_bound_of_external_input
