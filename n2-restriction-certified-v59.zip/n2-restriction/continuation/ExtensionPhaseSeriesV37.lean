import continuation.IntegratedPhaseSeriesV37

namespace N2Restriction
open MeasureTheory Filter
open scoped BigOperators ENNReal

/-- All phase-series input multipliers preserve the L2 budget, uniformly in
the multi-index. The support-localized uncertainty condition suffices. -/
theorem phase_series_input_L2_contraction {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} {n : ℕ} (h : Ω → Fin n → ℝ) (hh : Measurable h)
    (g : Ω → ℂ) (hg : MemLp g 2 μ) (R : ℝ)
    (hfreq : ∀ᵐ ω ∂μ, g ω ≠ 0 → ∀ i, |R*h ω i| ≤ 1) (a : Fin n → ℕ) :
    MemLp (fun ω => phaseSeriesAmplitude R (h ω) a*g ω) 2 μ ∧
      eLpNorm (fun ω => phaseSeriesAmplitude R (h ω) a*g ω) 2 μ ≤ eLpNorm g 2 μ := by
  have hm : Measurable (fun ω => phaseSeriesAmplitude R (h ω) a) := by
    unfold phaseSeriesAmplitude
    fun_prop
  have hb : ∀ᵐ ω ∂μ, ‖phaseSeriesAmplitude R (h ω) a*g ω‖ ≤ ‖g ω‖ := by
    filter_upwards [hfreq] with ω hω
    by_cases hz : g ω = 0
    · simp [hz]
    · rw [norm_mul]
      have ha := phase_series_amplitude_norm_le (h ω) R (hω hz) a
      exact (mul_le_mul_of_nonneg_right ha (norm_nonneg _)).trans_eq (one_mul _)
  exact ⟨hg.of_le (hm.aestronglyMeasurable.mul hg.aestronglyMeasurable) hb,eLpNorm_mono_ae hb⟩

/-- Exact frozen-frequency expansion for the actual extension operator.
It is valid at the uncertainty scale and uses the same input-independent
factorial coefficients as the abstract phase series. No scalar-to-vector
restriction estimate is assumed or concluded here. -/
theorem extension_frozen_phase_series {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} {n : ℕ} (ζ h : Ω → Ambient n)
    (hζ : Measurable ζ) (hh : Measurable h) (g : Ω → ℂ) (hg : Integrable g μ)
    (x : Ambient n) (R : ℝ) (hR : 0 < R) (hx : ∀ i, |x i| ≤ R)
    (hfreq : ∀ᵐ ω ∂μ, g ω ≠ 0 → ∀ i, |R*h ω i| ≤ 1) :
    HasSum (fun a : Fin n → ℕ => phaseSeriesCoefficient R x a *
      extension μ ζ (fun ω => phaseSeriesAmplitude R (h ω) a*g ω) x)
      (extension μ (fun ω => ζ ω+h ω) g x) := by
  let G := fun ω => Complex.exp ((inner ℝ x (ζ ω):ℂ)*Complex.I)*g ω
  have hG : Integrable G μ := integrable_extension_kernel hζ hg x
  have hh' : Measurable (fun ω i => h ω i) := by fun_prop
  have hf : ∀ᵐ ω ∂μ, G ω ≠ 0 → ∀ i, |R*h ω i| ≤ 1 := by
    filter_upwards [hfreq] with ω hω hn
    apply hω
    intro hz
    exact hn (by simp [G,hz])
  have H := integrated_phase_series (fun ω i => h ω i) hh' G hG x R hR hx hf
  have he (ω : Ω) : (∑ i, (x i:ℂ)*(h ω i:ℂ)) = (inner ℝ x (h ω):ℂ) := by
    simp only [PiLp.inner_apply,RCLike.inner_apply,RCLike.conj_to_real,Complex.ofReal_sum,
      Complex.ofReal_mul]
    apply Finset.sum_congr rfl
    intro i _
    ring
  simp_rw [he] at H
  convert H using 1
  · ext a
    congr 1
    apply integral_congr_ae
    apply Eventually.of_forall
    intro ω
    dsimp [G]
    ring
  · unfold extension
    apply integral_congr_ae
    apply Eventually.of_forall
    intro ω
    dsimp [G]
    rw [inner_add_right,Complex.ofReal_add,add_mul,Complex.exp_add]
    ring

end N2Restriction

#print axioms N2Restriction.extension_frozen_phase_series
#print axioms N2Restriction.phase_series_input_L2_contraction
