import continuation.OriginalAtlasCellBudgetV42

namespace N2Restriction
open MeasureTheory Set
open scoped BigOperators

/-- Every cap's transported actual packet series is unconditionally summable. -/
theorem PacketGraphAtlas.cap_packet_summable {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) {r : ℝ}
    (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r) (hr : 0 < r)
    (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
    (j : Fin T.size) (a : (Q j).centers) :
    Summable (fun ν : Fin d → ℤ => (T.graph j).rotatedAmbientInput (T.patch j).rotation
      ((T.graph j).packet (Q j) hr (f j) a ν)) := by
  apply ((T.graph j).rotatedAmbientInput (T.patch j).rotation).toContinuousLinearMap.summable
  apply (T.graph j).liftInput.toContinuousLinearMap.summable
  apply (T.graph j).density.fromCoordinate.summable
  exact ((Q j).packet_hasSum hr ((T.graph j).density.toCoordinate ((T.graph j).pullInput (f j))) a).summable

/-- Splitting selected packets into disjoint subfamilies is an exact L2 identity. -/
theorem PacketGraphAtlas.cellInput_union {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) {r : ℝ}
    (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r) (hr : 0 < r)
    (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
    (U V : (j : Fin T.size) → (Q j).centers → Set (Fin d → ℤ))
    (hd : ∀ j a, Disjoint (U j a) (V j a)) :
    T.cellInput Q hr f (fun j a => U j a ∪ V j a) =
      T.cellInput Q hr f U + T.cellInput Q hr f V := by
  unfold cellInput
  rw [← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro j _
  rw [← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro a _
  exact (T.cap_packet_summable Q hr f j a).subtype (U j a) |>.tsum_union_disjoint
    (hd j a) ((T.cap_packet_summable Q hr f j a).subtype (V j a))

/-- The near/far split of any already-selected packet input is exact,
including boundary angles in the near part. -/
theorem PacketGraphAtlas.cellInput_split {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) {r : ℝ}
    (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r) (hr : 0 < r)
    (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
    (U V : (j : Fin T.size) → (Q j).centers → Set (Fin d → ℤ)) :
    T.cellInput Q hr f U = T.cellInput Q hr f (fun j a => U j a ∩ V j a) +
      T.cellInput Q hr f (fun j a => U j a \ V j a) := by
  have h := T.cellInput_union Q hr f (fun j a => U j a ∩ V j a)
    (fun j a => U j a \ V j a) (fun j a => Set.disjoint_left.mpr (by
      intro ν h₁ h₂
      exact h₂.2 h₁.2))
  simpa only [Set.inter_union_diff] using h

end N2Restriction
#print axioms N2Restriction.PacketGraphAtlas.cap_packet_summable
#print axioms N2Restriction.PacketGraphAtlas.cellInput_union
#print axioms N2Restriction.PacketGraphAtlas.cellInput_split
