import continuation.AggregatedFiberInputV31
import continuation.IntegratedFiberErrorV31

namespace N2Restriction
open MeasureTheory Set Metric
open scoped NNReal ENNReal

namespace StripChartAmplitude
variable {n : ℕ} {S : SmoothPatch n} {Q : Ambient n →L[ℝ] ℝ × ℝ} {z : Ambient n}
  {δ r ρ s : ℝ} {B : ℕ → ℝ} {c C : ℝ≥0} {L α β ε : ℝ}
  {F : MeasuredTubularChart S Q z δ r ρ s B c C L}
  {E : ChartNormalCoordinates F α β}
  {g : Lp ℂ 2 ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier)}

/-- The joint normalized amplitude is integrable on the coordinate product. -/
theorem normalizedAmplitude_integrable (A : StripChartAmplitude F E g ε) :
    Integrable A.normalizedAmplitude (volume.prod volume) := by
  have hi : Integrable (fun t => A.weight t • A.input t) := by
    simpa using (A.extension_identity 0).1
  exact ((integrable_linear_coordinates_iff E.equiv volume (volume.prod volume) _).mpr hi).smul _

/-- The actual aggregate has the same linear thickness norm budget. -/
theorem referenceInput_enorm (A : StripChartAmplitude F E g ε) :
    ‖A.referenceInput‖ₑ ≤ ENNReal.ofReal (2 * ε) * (C : ℝ≥0∞) ^ (1 / 2 : ℝ) * ‖g‖ₑ := by
  have h := ENNReal.rpow_le_rpow A.referenceInput_energy (by norm_num : (0 : ℝ) ≤ 1 / 2)
  simpa only [ENNReal.mul_rpow_of_nonneg _ _ (by norm_num : (0 : ℝ) ≤ 1 / 2),
    ← ENNReal.rpow_natCast, ← ENNReal.rpow_mul, Nat.cast_ofNat,
    mul_one_div_cancel (by norm_num : (2 : ℝ) ≠ 0), ENNReal.rpow_one, mul_assoc] using h

/-- Fubini combines all normal parameters into a single actual L2 input when
the frequency map is independent of that parameter. -/
theorem extension_referenceInput_measurable (A : StripChartAmplitude F E g ε)
    (ζ : Ambient (n - 3) → Ambient n) (hζ : Measurable ζ) (x : Ambient n) :
    extension volume ζ A.referenceInput x =
      ∫ u, extension volume ζ (A.normalizedFiberInput u) x := by
  have hk := integrable_extension_kernel (hζ.comp measurable_snd) A.normalizedAmplitude_integrable x
  change Integrable (fun p : (ℝ × ℝ) × Ambient (n - 3) =>
    Complex.exp ((inner ℝ x (ζ p.2) : ℂ) * Complex.I) * A.normalizedAmplitude p) (volume.prod volume) at hk
  have he : extension volume ζ A.referenceInput x =
      ∫ v, ∫ u, Complex.exp ((inner ℝ x (ζ v) : ℂ) * Complex.I) * A.normalizedAmplitude (u, v) := by
    unfold extension
    apply integral_congr_ae
    filter_upwards [MemLp.coeFn_toLp A.referenceAmplitude_memLp] with v hv
    change A.referenceInput v = A.referenceAmplitude v at hv
    rw [hv]
    exact (integral_const_mul _ _).symm
  rw [he, ← integral_prod_symm _ hk, integral_prod _ hk]
  apply integral_congr_ae
  filter_upwards [A.normalizedAmplitude_coe_ae] with u hu
  symm
  apply integral_congr_ae
  filter_upwards [hu] with v hv
  rw [hv]

/-- The aggregate remains in the fixed compact thin-coordinate ball. -/
theorem referenceInput_thin_support (A : StripChartAmplitude F E g ε) :
    HasFrequencySupport volume id (closedBall (0 : Ambient (n - 3)) ((L + 1) * ρ)) A.referenceInput := by
  filter_upwards [MemLp.coeFn_toLp A.referenceAmplitude_memLp] with v hv hn
  by_contra h
  have hz : A.referenceAmplitude v = 0 := by
    apply integral_eq_zero_of_ae
    apply Filter.Eventually.of_forall
    intro u
    have hi : A.input (E.equiv.symm (u, v)) = 0 := by
      by_contra hh
      exact h (mem_closedBall_zero_iff.mpr (A.coordinate_support hh).2)
    simp [normalizedAmplitude, fiberAmplitude, hi]
  exact hn (hv.trans hz)

/-- The aggregate is supported on the smooth zero-fiber domain. -/
theorem referenceInput_parameter_support (A : StripChartAmplitude F E g ε)
    (hL : 0 ≤ L + 1) (hm : (L + 1) * ε < r - ρ) :
    HasFrequencySupport volume id
      {v | E.equiv.symm (-Q (S.normal z), v) ∈ ball (0 : Ambient (n - 1)) r} A.referenceInput := by
  filter_upwards [MemLp.coeFn_toLp A.referenceAmplitude_memLp] with v hv hn
  by_contra h
  have hz : A.referenceAmplitude v = 0 := by
    apply integral_eq_zero_of_ae
    apply Filter.Eventually.of_forall
    intro u
    have hi : A.input (E.equiv.symm (u, v)) = 0 := by
      by_contra hh
      have ht := normalReference_mem_ball E.equiv (Q (S.normal z)) hL E.inverse_norm_le (A.input_mem_ball hh)
        (by simpa only [E.equiv.apply_symm_apply] using (A.coordinate_support hh).1) hm
      exact h (by simpa only [normalReference, E.equiv.apply_symm_apply] using ht)
    simp [normalizedAmplitude, fiberAmplitude, hi]
  exact hn (hv.trans hz)

/-- The zero-fiber superposition is exactly the extension of one actual L2
input, despite the original chart being arbitrary outside its smooth domain. -/
theorem extension_referenceInput (A : StripChartAmplitude F E g ε)
    (hL : 0 ≤ L + 1) (hm : (L + 1) * ε < r - ρ) (x : Ambient n) :
    extension volume (fun v => F.param (E.equiv.symm (-Q (S.normal z), v))) A.referenceInput x =
      ∫ u, extension volume (fun v => F.param (E.equiv.symm (-Q (S.normal z), v)))
        (A.normalizedFiberInput u) x := by
  obtain ⟨φ, hφ, he⟩ := F.measurable_param_representative
  have hr : ∀ᵐ v ∂volume, A.referenceInput v ≠ 0 →
      F.param (E.equiv.symm (-Q (S.normal z), v)) = φ (E.equiv.symm (-Q (S.normal z), v)) := by
    filter_upwards [A.referenceInput_parameter_support hL hm] with v hv hn
    exact (he _ (ball_subset_closedBall (hv hn))).symm
  rw [extension_congr_frequency_support volume _ _ _ hr x,
    A.extension_referenceInput_measurable (fun v => φ (E.equiv.symm (-Q (S.normal z), v)))
      (hφ.comp (E.equiv.symm.continuous.measurable.comp (measurable_const.prodMk measurable_id))) x]
  apply integral_congr_ae
  apply Filter.Eventually.of_forall
  intro u
  symm
  apply extension_congr_frequency_support
  filter_upwards [A.normalizedFiberInput_reference_inside hL hm u] with v hv hn
  exact (he _ (ball_subset_closedBall (hv hn))).symm

end StripChartAmplitude
end N2Restriction

#print axioms N2Restriction.StripChartAmplitude.extension_referenceInput
#print axioms N2Restriction.StripChartAmplitude.extension_referenceInput_measurable
#print axioms N2Restriction.StripChartAmplitude.normalizedAmplitude_integrable
#print axioms N2Restriction.StripChartAmplitude.referenceInput_enorm
#print axioms N2Restriction.StripChartAmplitude.referenceInput_parameter_support
#print axioms N2Restriction.StripChartAmplitude.referenceInput_thin_support
