import continuation.UniformMeasuredAtlasV28

namespace N2Restriction
open Metric MeasureTheory
open scoped NNReal ENNReal

/-- Normal/thin coordinates attached to the actual chart, including the
uniform Haar measure factor and both operator-norm bounds. -/
structure ChartNormalCoordinates {n : ℕ} {S : SmoothPatch n}
    {Q : Ambient n →L[ℝ] ℝ × ℝ} {z : Ambient n} {δ r ρ s : ℝ}
    {B : ℕ → ℝ} {c C : ℝ≥0} {L : ℝ}
    (F : MeasuredTubularChart S Q z δ r ρ s B c C L) (α β : ℝ) where
  equiv : Ambient (n - 1) ≃L[ℝ] (ℝ × ℝ) × Ambient (n - 3)
  normal_eq : ∀ t, (equiv t).1 = F.normalCoord t
  norm_le : ‖equiv.toContinuousLinearMap‖ ≤ L + 1
  inverse_norm_le : ‖equiv.symm.toContinuousLinearMap‖ ≤ L + 1
  haar_lower : α ≤ (coordinateMeasureFactor equiv volume (volume.prod volume) : ℝ)
  haar_upper : (coordinateMeasureFactor equiv volume (volume.prod volume) : ℝ) ≤ β

/-- The coordinate-factor bounds precede every chart in the family. -/
theorem uniform_chart_normal_coordinates (n : ℕ) (hn : 3 ≤ n) {L : ℝ} (hL : 0 ≤ L) :
    ∃ α β : ℝ, 0 < α ∧ 0 < β ∧
      ∀ (S : SmoothPatch n) (Q : Ambient n →L[ℝ] ℝ × ℝ) (z : Ambient n)
        (δ r ρ s : ℝ) (B : ℕ → ℝ) (c C : ℝ≥0)
        (F : MeasuredTubularChart S Q z δ r ρ s B c C L),
        Nonempty (ChartNormalCoordinates F α β) := by
  obtain ⟨α, β, hα, hβ, he⟩ := uniform_tubular_product_measure_coordinates n hn hL
  refine ⟨α, β, hα, hβ, ?_⟩
  intro S Q z δ r ρ s B c C F
  obtain ⟨e, hcoord, hen, hein, hlo, hup⟩ := he F.normalCoord F.normal_norm F.normal_preimages
  exact ⟨⟨e, hcoord, hen, hein, hlo, hup⟩⟩

namespace ChartNormalCoordinates
variable {n : ℕ} {S : SmoothPatch n} {q : Ambient n × Ambient n} {z : Ambient n}
  {δ r ρ η : ℝ} {B : ℕ → ℝ} {c C : ℝ≥0} {L α β : ℝ}
  {F : MeasuredTubularChart S (pairFrameMap q) z δ r ρ (η / 2) B c C L}

/-- The reference belongs to the actual zero level on the same chart. -/
theorem zero_reference (E : ChartNormalCoordinates F α β)
    (hq : q ∈ orthonormalPairSet n) (hB : 0 ≤ B 1) (hL : 1 ≤ L) (hρ : ρ ≤ r)
    {τ : ℝ} (hmargin : (L + 1) * τ < r - ρ)
    (hsmall : (B 1 * L) * (L + 1) * τ ≤ η / 2)
    {t : Ambient (n - 1)} (ht : t ∈ closedBall 0 ρ)
    (hstrip : ‖pairFrameMap q (S.normal (F.param t))‖ ≤ τ) :
    normalReference E.equiv (pairFrameMap q (S.normal z)) t ∈ ball (0 : Ambient (n - 1)) r ∧
      F.param (normalReference E.equiv (pairFrameMap q (S.normal z)) t) ∈ S.extendedSurface ∧
      thinConstraint S (pairPlane q)
        (F.param (normalReference E.equiv (pairFrameMap q (S.normal z)) t)) = 0 ∧
      dist (F.param t) (F.param (normalReference E.equiv (pairFrameMap q (S.normal z)) t)) ≤
        (B 1 * L) * (L + 1) * τ ∧
      dist (F.param (normalReference E.equiv (pairFrameMap q (S.normal z)) t)) z ≤ η := by
  exact normalReference_zero_localization S (pairPlane q) q hq rfl E.equiv F.normalCoord
    E.normal_eq F.param (pairFrameMap q (S.normal z)) (mul_nonneg hB (by linarith))
    (by linarith) E.inverse_norm_le hρ
    (fun x hx => ⟨(F.bounds x hx).1, (F.bounds x hx).2.1,
      (F.bounds x hx).2.2.1.differentiableAt (by simp), (F.bounds x hx).2.2.2.2.1⟩)
    t ht hstrip hmargin hsmall z (F.image_buffer t ht)

end ChartNormalCoordinates
end N2Restriction

#print axioms N2Restriction.ChartNormalCoordinates.zero_reference
#print axioms N2Restriction.uniform_chart_normal_coordinates
