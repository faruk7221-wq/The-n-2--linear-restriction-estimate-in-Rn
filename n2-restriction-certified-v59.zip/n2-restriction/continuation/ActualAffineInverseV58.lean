import continuation.SmoothGraphFourierTransferV57
import continuation.AffineInverseDecayV58
import continuation.PhysicalPhaseCoordinatesV57
namespace N2Restriction
open Set MeasureTheory
set_option maxHeartbeats 1000000

/-- Inverse-frequency decay of an actual affine-sliced Hausdorff surface-chart Fourier integral. The
only borrowed premise is the standard graph area formula. Smoothness, compact
support, amplitude budgets, integrability, exact coordinates and the oscillatory
estimate are proved internally. The coefficient precedes direction/frequency. -/
theorem exists_actual_affine_surface_chart_inverse_decay (harea : SmoothGraphAreaFormulaInput) {d : ℕ}
    (A : Ambient (d+2) ≃ₗᵢ[ℝ] Ambient (d+2)) (Φ : Ambient (d+1) → ℝ)
    (hΦ : ContDiff ℝ (⊤ : ℕ∞) Φ) (ψ : Ambient (d+2) → ℂ)
    (hψ : ContDiff ℝ (⊤ : ℕ∞) ψ) (hs : HasCompactSupport ψ)
    (β : Ambient (d+2) → ℝ) (hβ : ContDiff ℝ (⊤ : ℕ∞) β)
    (u : Ambient (d+1)) (R : Ambient (d+1) ≃ₗᵢ[ℝ] Ambient (d+1))
    {r : ℝ} (hr : 0 < r) (K : Set (Ambient d)) (hK : IsCompact K) (Θ : Set (Ambient (d+2))) (hΘ : IsCompact Θ)
    (a b : ℝ) (hab : a ≤ b) {c : ℝ} (hc : 0 < c)
    (hcurved : ∀ θ ∈ Θ, ∀ y ∈ K, ∀ t ∈ Icc a b,
      c ≤ |deriv (fun s => inner ℝ θ
        (A (graphPoint (horizontalAffine u R r hr.ne' (graphPoint y s)) (Φ (horizontalAffine u R r hr.ne' (graphPoint y s)))))) t|) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ θ ∈ Θ, ∀ freq : ℝ, 0 < freq →
      ‖extension ((Measure.hausdorffMeasure ((d+1 : ℕ) : ℝ)).restrict
          ((fun u => A (graphPoint u (Φ u))) ''
            ((horizontalAffine u R r hr.ne') '' ((graphFiberEquiv d) '' (K ×ˢ Icc a b))))) id
          (fun z => ψ z*(β z : ℂ)) (freq • θ)‖ ≤ C/freq := by
  let B := smoothSurfaceAmplitude A Φ ψ β
  let G : Ambient (d+1) → Ambient (d+2) := fun u => A (graphPoint u (Φ u))
  have hB := contDiff_smoothSurfaceAmplitude A Φ hΦ ψ hψ β hβ
  have hBs := hasCompactSupport_smoothSurfaceAmplitude A Φ ψ hs β
  have hG : ContDiff ℝ (⊤ : ℕ∞) G :=
    A.contDiff.comp (graphPointCLM.contDiff.comp (contDiff_id.prodMk hΦ))
  obtain ⟨C,hC,hdecay⟩ := exists_affine_chart_inverse_decay B hB hBs G hG u R hr K hK Θ hΘ a b hab hc hcurved
  have hL : IsCompact ((graphFiberEquiv d) '' (K ×ˢ Icc a b)) :=
    (hK.prod isCompact_Icc).image graphPointCLM.continuous
  have hFL := hL.image (horizontalAffine u R r hr.ne').continuous
  refine ⟨C,hC,?_⟩
  intro θ hθ freq hf
  rw [smooth_graph_fourier_transfer harea A Φ hΦ _ hFL ψ hψ.continuous β hβ.continuous]
  exact hdecay θ hθ freq hf
end N2Restriction
#print axioms N2Restriction.exists_actual_affine_surface_chart_inverse_decay
