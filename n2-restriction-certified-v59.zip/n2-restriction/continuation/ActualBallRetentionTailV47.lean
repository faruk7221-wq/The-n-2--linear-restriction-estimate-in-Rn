import continuation.ActualTangentSplitV47

namespace N2Restriction
open MeasureTheory Set

/-- Packets omitted by the actual ball-retention rule have a uniform rapid
tail on Omega in that ball. This applies to every original stage selection. -/
theorem PacketGraphAtlas.omitted_ball_rapid_tail {d : ℕ} {S : SmoothPatch (d+1)}
    (A : PacketGraphAtlas S) {τ : ℝ} (hτ : 0 < τ) :
    ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ N : ℝ, ∃ C : ℝ, 0 ≤ C ∧
      ∀ R : ℝ, R₀ ≤ R →
      ∀ (Q : (j : Fin A.size) → CoordinateCapFamily (A.patch j).support (R^(-1/2 : ℝ)))
        (hr : 0 < R^(-1/2 : ℝ)) (B : ℝ), 0 ≤ B →
      (∀ j, ((Q j).centers.card : ℝ) ≤ B*R^((d : ℝ)/2)) →
      ∀ (f : (j : Fin A.size) → Lp ℂ 2 (A.graph j).surfaceMeasure)
        (g : Lp ℂ 2 S.surfaceMeasure), (∑ j, ‖f j‖^2) ≤ ‖g‖^2 →
      ∀ (Ω : Set (Ambient (d+1))) (c : Ambient (d+1)) (ρ : ℝ)
        (U : (j : Fin A.size) → (Q j).centers → Set (Fin d → ℤ))
        (x : Ambient (d+1)), ‖x‖ ≤ R → x ∈ Ω ∩ Metric.ball c ρ →
      ‖extension (Measure.hausdorffMeasure (d : ℝ)) id
        (A.cellInput Q hr f (fun j a => {ν | ν ∈ U j a ∧
          ¬ (A.originalPacketTube j a (R^(-1/2 : ℝ)) ν R (R^(1/2+τ)/10) ∩
            (Ω ∩ Metric.ball c ρ)).Nonempty})) x‖ ≤
        C*Real.sqrt B*R^(-N)*‖g‖ := by
  obtain ⟨R₀,hR₀,htail⟩ := A.arbitrary_packet_rapid_tail hτ
  refine ⟨R₀,hR₀,fun N => ?_⟩
  obtain ⟨C,hC,hc⟩ := htail N
  refine ⟨C,hC,?_⟩
  intro R hR Q hr B hB hcount f g he Ω c ρ U x hx hxΩ
  let J : Set ((j : Fin A.size) × ((Q j).centers × (Fin d → ℤ))) :=
    {p | p.2.2 ∈ U p.1 p.2.1 ∧
      ¬ (A.originalPacketTube p.1 p.2.1 (R^(-1/2 : ℝ)) p.2.2 R (R^(1/2+τ)/10) ∩
        (Ω ∩ Metric.ball c ρ)).Nonempty}
  have hJ : ∀ p ∈ J, x ∉ rotatedPacketTube (A.patch p.1).rotation
      (graphGradient (A.graph p.1).phase p.2.1)
      ((R^(-1/2 : ℝ))⁻¹ • latticeVector p.2.2) R (R^(1/2+τ)/10) := by
    intro p hp htube
    exact hp.2 ⟨x,htube,hxΩ⟩
  have hh := (hc R hR Q hr B hB hcount f g he x hx J hJ).2
  rw [A.cellInput_eq_selected_tsum]
  exact hh

end N2Restriction
#print axioms N2Restriction.PacketGraphAtlas.omitted_ball_rapid_tail
