import continuation.AtlasFamilyApproximationV43
import continuation.AtlasCellMassEstimateV42

namespace N2Restriction
open MeasureTheory Set
open scoped BigOperators ENNReal

/-- The actual trimmed-cell mass bound with the omission estimate discharged.
The error is uniform over all partition polynomials, cells and selected packet
families. Only geometric membership in the trimmed cell is assumed. -/
theorem atlas_trimmed_cell_mass {d k : ℕ} (S : Fin k → SmoothPatch (d+1))
    (T : (i : Fin k) → PacketGraphAtlas (S i)) {τ : ℝ} (hτ : 0 < τ) :
    ∃ M : ℝ, 1 ≤ M ∧ ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ N : ℝ, ∃ C : ℝ, 0 ≤ C ∧
      ∀ R : ℝ, R₀ ≤ R →
      ∀ (Q : (i : Fin k) → (j : Fin (T i).size) →
        CoordinateCapFamily ((T i).patch j).support (R^(-1/2 : ℝ)))
        (hr : 0 < R^(-1/2 : ℝ)), (∀ i, R^(-1/2 : ℝ) ≤ (T i).capRadius) →
      ∀ B : ℝ, 0 ≤ B → (∀ i j, ((Q i j).centers.card : ℝ) ≤ B*R^((d : ℝ)/2)) →
      ∀ (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure)
        (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure),
      (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
      ∀ {l : ℕ} (P : Fin l → MvPolynomial (Fin (d+1)) ℝ)
        (Ω : Set (Ambient (d+1))) (σ : Fin l → Bool) (b : ℝ)
        (A : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ))
        {m p : ℝ}, (∀ i, m ≤ (T i).margin) → 0 < p → p ≤ 1 →
      ∀ (q : Finset (Ambient (d+1))),
      (Metric.closedBall 0 R ⊆ ⋃ a : q, Metric.ball (R • a.val) (R/2)) →
      ∀ Δ : Set (Ambient (d+1)), MeasurableSet Δ → Δ ⊆ Metric.closedBall 0 R →
      Δ ⊆ Ω → Δ ⊆ PolynomialSignRegion P σ →
      (∀ x ∈ Δ, ∀ z, ambientPolynomial (∏ l, P l) z = 0 → b ≤ dist x z) →
      (∫⁻ x in Δ, ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
        (fun i => (T i).cellInput (Q i) hr (f i) (A i)) x‖ₑ ^ p) ≤
      (q.card : ENNReal) *
        (marginLocalConstant (fun i => (T i).bufferMeasure) (fun _ => id)
          (fun i => (S i).neighborhood) m p (R/2) *
            ∏ i, ENNReal.ofReal (‖(T i).cellInput (Q i) hr (f i)
              (fun j a => {ν | ν ∈ A i j a ∧ σ ∈ trimmedCellLabels P
                ((T i).cellAxisPoint j (R^(-1/2 : ℝ)) ν)
                ((T i).cellAxisDirection j a.val) Ω b (R^(1/2+τ)/10)})‖))^p +
        (ENNReal.ofReal ((k : ℝ)*(C*Real.sqrt B*R^(-N))*M^k*∏ i, ‖g i‖))^p * volume Δ := by
  obtain ⟨M, hM, hm⟩ := atlas_cell_mass_estimate S T
  obtain ⟨R₀, hR₀, ht⟩ := atlas_family_cell_approximation S T hτ
  refine ⟨M, hM, R₀, hR₀, fun N => ?_⟩
  obtain ⟨C, hC, hc⟩ := ht N
  refine ⟨C, hC, ?_⟩
  intro R hR Q hr hsmall B hB hcount g f he l P Ω σ b A m p hmargin hp hp1 q hcover Δ hΔ hin hΩ hsign htrim
  have hRpos : 0 ≤ R := (zero_le_one.trans hR₀).trans hR
  apply hm hr Q hsmall g f he A _ hmargin hRpos hp hp1
    (mul_nonneg (mul_nonneg hC (Real.sqrt_nonneg B)) (Real.rpow_nonneg hRpos _)) q hcover Δ hΔ hin
  intro x hx i
  exact hc R hR i (Q i) hr (hsmall i) B hB (hcount i) (f i) (g i) (he i)
    P Ω σ b (A i) x (by simpa only [Metric.mem_closedBall, dist_zero_right] using hin hx)
    (hΩ hx) (htrim x hx) (hsign hx)

end N2Restriction
#print axioms N2Restriction.atlas_trimmed_cell_mass
