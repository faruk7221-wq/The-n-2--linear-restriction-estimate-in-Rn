import continuation.DensityAmplitudeEnergyV25

namespace N2Restriction
open MeasureTheory
open scoped ENNReal NNReal

/-- With the Haar factor placed in the complex extension amplitude itself,
the fiber L2 integral has the same thickness gain, at a cost of the square root
of an upper bound for that factor. -/
theorem actual_amplitude_thickness_bound {d k : ℕ}
    (R : Ambient d →L[ℝ] ℝ × ℝ)
    (e : Ambient d ≃L[ℝ] (ℝ × ℝ) × Ambient k) (he : ∀ x, (e x).1 = R x)
    (J : Ambient d → ℝ≥0) (hJ : Measurable J) (C : ℝ≥0)
    (hC : ∀ᵐ x ∂volume, J x ≤ C)
    (F : Ambient d → ℂ) (hF : Measurable F) (a : ℝ × ℝ) (r : ℝ)
    (hs : ∀ x, F x ≠ 0 → ‖a + R x‖ ≤ r)
    (b : ℝ≥0) (hb : coordinateMeasureFactor e volume (volume.prod volume) ≤ b) :
    (∫⁻ u, (∫⁻ v, (‖coordinateMeasureFactor e volume (volume.prod volume) •
      (J (e.symm (u, v)) • F (e.symm (u, v)))‖ₑ)^2) ^ (1 / 2 : ℝ)) ≤
      (b : ℝ≥0∞) ^ (1 / 2 : ℝ) * (ENNReal.ofReal (2 * r) * ((C : ℝ≥0∞) *
        ∫⁻ x, (‖F x‖ₑ)^2 ∂volume.withDensity (fun x => (J x : ℝ≥0∞))) ^ (1 / 2 : ℝ)) := by
  let c := coordinateMeasureFactor e volume (volume.prod volume)
  let H := fun u => ∫⁻ v, (‖J (e.symm (u, v)) • F (e.symm (u, v))‖ₑ)^2
  have hscalar : ∀ z : ℂ, ‖c • z‖ₑ = (c : ℝ≥0∞) * ‖z‖ₑ := by
    intro z
    change (‖(c : ℝ) • z‖₊ : ℝ≥0∞) = _
    simp [enorm_eq_nnnorm]
  have hinner : ∀ u, (∫⁻ v, (‖c • (J (e.symm (u, v)) • F (e.symm (u, v)))‖ₑ)^2) =
      (c : ℝ≥0∞) * ((c : ℝ≥0∞) * H u) := by
    intro u
    simp_rw [hscalar, mul_pow]
    rw [lintegral_const_mul _ (by fun_prop), pow_two, mul_assoc]
  have heq : (∫⁻ u, (∫⁻ v, (‖c • (J (e.symm (u, v)) • F (e.symm (u, v)))‖ₑ)^2) ^ (1 / 2 : ℝ)) =
      (c : ℝ≥0∞) ^ (1 / 2 : ℝ) * ∫⁻ u, ((c : ℝ≥0∞) * H u) ^ (1 / 2 : ℝ) := by
    simp_rw [hinner, ENNReal.mul_rpow_of_nonneg _ _ (by norm_num : (0 : ℝ) ≤ 1 / 2)]
    rw [lintegral_const_mul _ (by dsimp [H]; fun_prop)]
  change (∫⁻ u, (∫⁻ v, (‖c • (J (e.symm (u, v)) • F (e.symm (u, v)))‖ₑ)^2) ^ (1 / 2 : ℝ)) ≤ _
  rw [heq]
  apply mul_le_mul'
  · exact ENNReal.rpow_le_rpow (by exact_mod_cast hb) (by norm_num)
  · exact density_amplitude_thickness_bound R e he J hJ C hC F hF a r hs

end N2Restriction

#print axioms N2Restriction.actual_amplitude_thickness_bound
