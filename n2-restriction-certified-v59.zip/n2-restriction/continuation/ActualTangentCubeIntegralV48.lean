import continuation.SupportedCubeIntegralV48
import continuation.SelectedSamePatchSupportV48
import continuation.ActualCubeSelectionStripV47
import continuation.PositiveChildMarginsV44

namespace N2Restriction
open MeasureTheory Set Metric Filter
open scoped ENNReal NNReal

/-- The localized integral estimate (7.13) for actual cube-selected tangent
packets at the article scales. The strip and common-patch support are proved
from selection and parent margin. The frame identifies the terminal plane;
only the borrowed localized restriction bound is an analytic premise. -/
theorem eventually_actual_tangent_cube_integral {k : ℕ}
    (S : Fin k → SmoothPatch (k+2)) (A : (i : Fin k) → PacketGraphAtlas (S i))
    {κ : ℝ} (B : ArticleLocalizationAtlas S κ)
    (V : Fin k → Set (Ambient (k+2))) (m : ℝ)
    (hS : ∀ i, (S i).extendedSurface ∩ V i ⊆ (S i).support) (hm : 0 < m)
    {p ε τ lam : ℝ} (hp : 0 < p) (hε : 0 < ε)
    (hexternal : B.UniformLocalizedInput p) (hτ : 0 < τ) (hτ' : τ < 1/4) (hlam : 0 < lam) :
    ∃ D : ℝ≥0, ∀ᶠ R : ℝ in atTop,
    ∀ (Q : (i : Fin k) → (j : Fin (A i).size) →
      CoordinateCapFamily ((A i).patch j).support (R^(-1/2 : ℝ)))
      (hr : 0 < R^(-1/2 : ℝ)), (∀ i, R^(-1/2 : ℝ) ≤ (A i).capRadius) →
    ∀ (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure),
    (∀ i j, HasFrequencySupport ((A i).graph j).surfaceMeasure ((A i).patch j).rotation
      (marginRegion (V i) (m-R^(-1/4 : ℝ))) (f i j)) →
    ∀ (i₀ : Fin k) (Z : Set (Ambient (k+2)))
      (T : Ambient (k+2) → Submodule ℝ (Ambient (k+2))) (F : Submodule ℝ (Ambient (k+2)))
      (center q x z : Ambient (k+2)) (C C₀ : ℝ) (Ω E : Set (Ambient (k+2)))
      (Ubase : (j : Fin (A i₀).size) → (Q i₀ j).centers → Set (Fin (k+1) → ℤ))
      (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin (k+1) → ℤ))
      (frame : ArticleFrame S κ),
    pairPlane frame.val = (T z ⊔ F)ᗮ →
    0 ≤ C → 1+Real.sqrt (k+2 : ℕ)*(1+C)/2 ≤ C₀ →
    z ∈ Z → x ∈ ball center (R^(1-τ)) → x ∈ gridCube q (lam*R^(1/2+τ)) →
    dist z x ≤ lam*R^(1/2+τ) → E ⊆ gridCube q (lam*R^(1/2+τ)) →
    U i₀ = (fun j a => (A i₀).actualTangentSelection (Q i₀) Ubase Z T center (R^(1-τ))
      (lam*R^(1/2+τ)) C₀ R (R^(1/2+τ)/10) Ω j a ∩
      {ν | ((A i₀).originalPacketTube j a (R^(-1/2 : ℝ)) ν R (R^(1/2+τ)/10) ∩
        gridCube q (C*(lam*R^(1/2+τ)))).Nonempty}) →
    (∫⁻ y in E, ‖extensionProduct (fun _ => Measure.hausdorffMeasure ((k+1 : ℕ) : ℝ))
      (fun _ => id) (fun i => (A i).cellInput (Q i) hr (f i) (U i)) y‖ₑ ^ p) ≤
      (((D : ENNReal)*ENNReal.ofReal (((1+Real.sqrt (k+2 : ℕ))*(lam*R^(1/2+τ)))^ε))^p *
        (ENNReal.ofReal (lam*R^(-1/2+2*τ)))^p) *
      ∏ i, (ENNReal.ofReal ‖(A i).cellInput (Q i) hr (f i) (U i)‖)^p := by
  obtain ⟨μ₀,hμ₀,D,hD⟩ := B.supported_cube_integral hp hε hexternal 2 (by norm_num)
  obtain ⟨R₀,_,hwidth⟩ := packet_width_localization_threshold hτ' hlam hμ₀
  refine ⟨D,?_⟩
  have hτhalf : τ < 1/2 := by linarith
  filter_upwards [eventually_atlas_same_patch_support S A V m hS,
    Filter.eventually_all.mpr (fun i => (A i).eventually_actual_cube_tangent_strip hτ hτ' hlam),
    eventually_children hτ hτhalf hlam,
    eventually_positive_child_margins hm hτ hτhalf hlam,
    eventually_ge_atTop R₀] with R hs ht hc hmarg hR
  intro Q hr hsmall f hf i₀ Z T F center q x z C C₀ Ω E Ubase U frame hplane
    hC hC₀ hz hxb hxq hzx hE hU
  have hw := hwidth R hR
  let μ : ℝ≥0 := ⟨lam*R^(-1/2+2*τ),hw.1.le⟩
  have hstrip := ht i₀ (Q i₀) hr (f i₀) Z T F center q x z C C₀ Ω Ubase
    hC hC₀ hz hxb hxq hzx
  have hsupport := hs _ hc.2.2.2.1 hc.2.2.2.2 hmarg.2.2 Q hr hsmall f hf U
  have hstrip' : HasFrequencySupport (Measure.hausdorffMeasure ((k+1 : ℕ) : ℝ)) id
      (normalStrip (S i₀) (pairPlane frame.val) ((2 : ℝ)*μ))
      ((A i₀).cellInput (Q i₀) hr (f i₀) (U i₀)) := by
    simpa only [hplane,hU,μ,NNReal.coe_mk] using hstrip
  have hh := hD frame i₀ μ _ q E hw.1 hw.2 hc.2.2.2.1 hE
    (fun i => (A i).cellInput (Q i) hr (f i) (U i)) hsupport hstrip'
  have hμcoe : (μ : ENNReal) = ENNReal.ofReal (lam*R^(-1/2+2*τ)) := by
    exact (ENNReal.ofReal_coe_nnreal (p := μ)).symm
  simpa only [hμcoe] using hh

end N2Restriction
#print axioms N2Restriction.eventually_actual_tangent_cube_integral
