import continuation.DirectionProjectionV35

namespace N2Restriction
open Set Metric

/-- An affine line, including the degenerate point case, is closed. -/
theorem isClosed_affineLine_range {n : ℕ} (a v : Ambient n) :
    IsClosed (Set.range (fun s : ℝ => a+s•v)) := by
  have heq : Set.range (fun s : ℝ => a+s•v) =
      (fun x => x-a) ⁻¹' (Submodule.span ℝ {v} : Set (Ambient n)) := by
    ext x
    change (∃ s : ℝ, a+s•v = x) ↔ x-a ∈ Submodule.span ℝ {v}
    rw [Submodule.mem_span_singleton]
    constructor
    · rintro ⟨s, rfl⟩
      exact ⟨s, by abel⟩
    · rintro ⟨s, hs⟩
      exact ⟨s, by rw [hs]; abel⟩
  rw [heq]
  exact (Submodule.span ℝ {v}).closed_of_finiteDimensional.preimage (continuous_id.sub continuous_const)

/-- The witness-based tube is exactly the closed metric neighborhood of the
affine line: the distance is attained in finite-dimensional physical space. -/
theorem affineLineTube_eq_infDist {n : ℕ} (a v : Ambient n) (w : ℝ) :
    affineLineTube a v w = {x | infDist x (Set.range (fun s : ℝ => a+s•v)) ≤ w} := by
  ext x
  constructor
  · rintro ⟨s, hs⟩
    exact (infDist_le_dist_of_mem (Set.mem_range_self s)).trans hs
  · intro hx
    obtain ⟨y, hy, heq⟩ := (isClosed_affineLine_range a v).exists_infDist_eq_dist
      (Set.range_nonempty _) x
    obtain ⟨s, rfl⟩ := hy
    exact ⟨s, heq ▸ hx⟩

/-- The directional line tubes used in the Kakeya conclusion are measurable. -/
theorem measurableSet_affineLineTube {n : ℕ} (a v : Ambient n) (w : ℝ) :
    MeasurableSet (affineLineTube a v w) := by
  rw [affineLineTube_eq_infDist]
  exact (isClosed_le (continuous_infDist_pt _) continuous_const).measurableSet

end N2Restriction

#print axioms N2Restriction.affineLineTube_eq_infDist
#print axioms N2Restriction.isClosed_affineLine_range
#print axioms N2Restriction.measurableSet_affineLineTube
