import continuation.WeightedCoordinateSlicingV25

namespace N2Restriction
open MeasureTheory
open scoped ENNReal

/-- A measurable function on a measurable chart domain has a measurable zero
extension. Agreement is pointwise, including boundary points. -/
theorem exists_measurable_zero_extension {X Y : Type*}
    [MeasurableSpace X] [MeasurableSpace Y] [Zero Y]
    (K : Set X) (hK : MeasurableSet K) (f : K → Y) (hf : Measurable f) :
    ∃ F : X → Y, Measurable F ∧ (∀ x : K, F x = f x) ∧ ∀ x ∉ K, F x = 0 := by
  classical
  let F := Function.extend (Subtype.val : K → X) f (fun _ => 0)
  refine ⟨F, (MeasurableEmbedding.subtype_coe hK).measurable_extend hf measurable_const, ?_, ?_⟩
  · exact fun x => Subtype.val_injective.extend_apply f (fun _ => 0) x
  · intro x hx
    exact Function.extend_apply' f (fun _ => 0) x (by rintro ⟨y, rfl⟩; exact hx y.property)

/-- Zero extension turns the weighted measure on a compact chart's subtype
into an ordinary ambient-coordinate energy integral. -/
theorem chart_density_zero_extension_integral {d : ℕ}
    (K : Set (Ambient d)) (hK : MeasurableSet K)
    (J : K → ℝ≥0∞) (hJ : Measurable J)
    (W : Ambient d → ℝ≥0∞) (hW : Measurable W)
    (hWK : ∀ x : K, W x = J x) (hWzero : ∀ x ∉ K, W x = 0)
    (f : Ambient d → ℝ≥0∞) (hf : Measurable f) :
    ∫⁻ x : K, f x ∂((volume : Measure (Ambient d)).comap Subtype.val).withDensity J =
      ∫⁻ x, f x ∂volume.withDensity W := by
  rw [lintegral_withDensity_eq_lintegral_mul _ hJ (show Measurable (fun x : K => f x) from hf.comp measurable_subtype_coe),
    lintegral_withDensity_eq_lintegral_mul _ hW hf]
  have he : (fun x : K => (J * (fun x : K => f x)) x) = fun x : K => W x * f x := by
    funext x
    simp only [Pi.mul_apply, hWK]
  rw [he, lintegral_subtype_comap hK (fun x => W x * f x)]
  apply setLIntegral_eq_of_support_subset
  intro x hx
  by_contra hn
  exact hx (by simp [hWzero x hn])

end N2Restriction

#print axioms N2Restriction.chart_density_zero_extension_integral
#print axioms N2Restriction.exists_measurable_zero_extension
