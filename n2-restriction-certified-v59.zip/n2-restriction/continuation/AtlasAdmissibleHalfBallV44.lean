import continuation.AtlasAdmissibleLocalV44
namespace N2Restriction
open MeasureTheory Set
open scoped BigOperators ENNReal
/-- Half-radius covering bound for selected inputs with an inherited margin. -/
theorem atlas_cell_admissible_half_ball_bound {d k : ℕ} (S : Fin k → SmoothPatch (d+1))
    (T : (i : Fin k) → PacketGraphAtlas (S i)) {r : ℝ} (hr : 0 < r)
    (Q : (i : Fin k) → (j : Fin (T i).size) → CoordinateCapFamily ((T i).patch j).support r)
    (hsmall : ∀ i, r ≤ (T i).capRadius)
    (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure)
    (U : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ))
    (V : Fin k → Set (Ambient (d+1)))
    {m R p : ℝ}
    (hadm : MarginAdmissible (fun i => (T i).bufferMeasure) (fun _ => id) V m (R/2)
      (fun i => (T i).bufferInput ((T i).cellInput (Q i) hr (f i) (U i))))
    (hp : 0 < p)
    (q : Finset (Ambient (d+1)))
    (hcover : Metric.closedBall 0 R ⊆ ⋃ a : q, Metric.ball (R • a.val) (R/2))
    (Ω : Set (Ambient (d+1))) (hΩ : Ω ⊆ Metric.closedBall 0 R) :
    (∫⁻ x in Ω,
      ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
        (fun i => (T i).cellInput (Q i) hr (f i) (U i)) x‖ₑ ^ p) ≤
      (q.card : ENNReal) *
      (marginLocalConstant (fun i => (T i).bufferMeasure) (fun _ => id)
        V m p (R/2) *
          ∏ i, ENNReal.ofReal (‖(T i).cellInput (Q i) hr (f i) (U i)‖))^p := by
  apply half_ball_integral_bound q hcover _ Ω hΩ
  intro a
  exact atlas_cell_admissible_power_bound S T hr Q hsmall f U V hadm hp (R • a.val)


end N2Restriction
#print axioms N2Restriction.atlas_cell_admissible_half_ball_bound
