import continuation.PerturbedFourBlockV33

namespace N2Restriction
open MeasureTheory Metric
open scoped ENNReal
attribute [local instance] tripleProductHaar fourProductHaar

/-- Exact volume scaling of a triple product block ball. -/
theorem triple_block_ball_volume (a b c : ℕ) (z : (Ambient b × Ambient c) × Ambient a)
    (r : ℝ) (hr : 0 ≤ r) :
    ((volume.prod volume).prod volume) (closedBall z r) = ENNReal.ofReal r ^ (b + c + a) *
      ((volume.prod volume).prod volume) (closedBall (0 : (Ambient b × Ambient c) × Ambient a) 1) := by
  rw [Measure.addHaar_closedBall' ((volume.prod volume).prod volume) z hr]
  simp only [Module.finrank_prod, finrank_euclideanSpace, Fintype.card_fin, ENNReal.ofReal_pow hr]

/-- The three-fold product unit ball has positive finite Haar measure. -/
theorem triple_block_unit_ball_volume_bounds (a b c : ℕ) :
    0 < ((volume.prod volume).prod volume) (closedBall (0 : (Ambient b × Ambient c) × Ambient a) 1) ∧
    ((volume.prod volume).prod volume) (closedBall (0 : (Ambient b × Ambient c) × Ambient a) 1) ≠ ⊤ :=
  ⟨measure_closedBall_pos _ _ (by norm_num), measure_closedBall_lt_top.ne⟩

/-- The fixed volume normalization for normal dimensions 3,1,1,1. -/
noncomputable def block3111VolumeConstant : ℝ≥0∞ :=
  (((volume.prod volume).prod volume) (closedBall (0 : (Ambient 1 × Ambient 1) × Ambient 3) 1) *
   ((volume.prod volume).prod volume) (closedBall (0 : (Ambient 1 × Ambient 1) × Ambient 1) 1) *
   ((volume.prod volume).prod volume) (closedBall (0 : (Ambient 3 × Ambient 1) × Ambient 1) 1) *
   ((volume.prod volume).prod volume) (closedBall (0 : (Ambient 3 × Ambient 1) × Ambient 1) 1)) ^ (1 / 3 : ℝ)

theorem block3111VolumeConstant_pos : 0 < block3111VolumeConstant := by
  have h₀ := (triple_block_unit_ball_volume_bounds 3 1 1).1
  have h₁ := (triple_block_unit_ball_volume_bounds 1 1 1).1
  have h₂ := (triple_block_unit_ball_volume_bounds 1 3 1).1
  unfold block3111VolumeConstant
  positivity

theorem block3111VolumeConstant_ne_top : block3111VolumeConstant ≠ ⊤ := by
  have h₀ := (triple_block_unit_ball_volume_bounds 3 1 1).2
  have h₁ := (triple_block_unit_ball_volume_bounds 1 1 1).2
  have h₂ := (triple_block_unit_ball_volume_bounds 1 3 1).2
  unfold block3111VolumeConstant
  finiteness

/-- Complementary dimensions 5,3,5,5 give width exponent 18/3=6. -/
theorem block3111_ball_mass (r : ℝ) (hr : 0 ≤ r) (u₀ u₁ u₂ u₃ : ℝ≥0∞) :
    ((u₀ * ((volume.prod volume).prod volume) (closedBall (0 : (Ambient 1 × Ambient 1) × Ambient 3) r)) *
     (u₁ * ((volume.prod volume).prod volume) (closedBall (0 : (Ambient 1 × Ambient 1) × Ambient 1) r)) *
     (u₂ * ((volume.prod volume).prod volume) (closedBall (0 : (Ambient 3 × Ambient 1) × Ambient 1) r)) *
     (u₃ * ((volume.prod volume).prod volume) (closedBall (0 : (Ambient 3 × Ambient 1) × Ambient 1) r))) ^ (1 / 3 : ℝ) =
    block3111VolumeConstant * ENNReal.ofReal r ^ 6 * (u₀ * u₁ * u₂ * u₃) ^ (1 / 3 : ℝ) := by
  rw [triple_block_ball_volume 3 1 1 _ r hr, triple_block_ball_volume 1 1 1 _ r hr,
    triple_block_ball_volume 1 3 1 _ r hr]
  norm_num only [Nat.reduceAdd]
  have he (v A B C u v₁ v₂ v₃ : ℝ≥0∞) :
      u * (v ^ 5 * A) * (v₁ * (v ^ 3 * B)) * (v₂ * (v ^ 5 * C)) * (v₃ * (v ^ 5 * C)) =
      (A * B * C * C) * v ^ 18 * (u * v₁ * v₂ * v₃) := by ring
  rw [he]
  simp only [ENNReal.mul_rpow_of_nonneg _ _ (by norm_num : (0 : ℝ) ≤ 1 / 3)]
  have hp (v : ℝ≥0∞) : (v ^ 18) ^ (1 / 3 : ℝ) = v ^ 6 := by
    rw [← ENNReal.rpow_natCast, ← ENNReal.rpow_mul]
    norm_num
  rw [hp]
  simp only [block3111VolumeConstant, ENNReal.mul_rpow_of_nonneg _ _ (by norm_num : (0 : ℝ) ≤ 1 / 3)]

end N2Restriction

#print axioms N2Restriction.block3111VolumeConstant_ne_top
#print axioms N2Restriction.block3111VolumeConstant_pos
#print axioms N2Restriction.block3111_ball_mass
#print axioms N2Restriction.triple_block_ball_volume
#print axioms N2Restriction.triple_block_unit_ball_volume_bounds
