import continuation.CertifiedLocalizationAtlasV55
import continuation.MeasuredFiberChartsV37

namespace N2Restriction
open Set Metric Filter MeasureTheory
set_option maxHeartbeats 1600000

/-- Every zero reference has a uniform positive parameter margin. -/
theorem CertifiedArticleLocalizationAtlas.reference_norm_bound {k : ℕ}
    {S : Fin k → SmoothPatch (k+2)} {κ : ℝ} (A : CertifiedArticleLocalizationAtlas S κ)
    (q : ArticleFrame S κ) (i : Fin k) (j : Fin (A.charts i))
    (t : Ambient (k+2-1)) (ht : t ∈ closedBall 0 A.ρ)
    (hs : ‖pairFrameMap q.val ((S i).normal ((A.measuredChart q i j).param t))‖ ≤ A.τ) :
    ‖normalReference (A.normalCoordinates q i j).equiv
      (pairFrameMap q.val ((S i).normal (A.centers i j))) t‖ ≤ A.ρ+(A.L+1)*A.τ := by
  let F := A.measuredChart q i j
  let E := A.normalCoordinates q i j
  have hd := normalReference_displacement E.equiv
    (pairFrameMap q.val ((S i).normal (A.centers i j))) E.inverse_norm_le t
  have he : (E.equiv t).1 = F.normalCoord t := E.normal_eq t
  rw [he, ← (F.bounds t (closedBall_subset_closedBall A.ρ_lt_r.le ht)).2.1] at hd
  have hL : 0 ≤ A.L+1 := by linarith [A.L_one]
  have hd' := hd.trans (mul_le_mul_of_nonneg_left hs hL)
  have hh := norm_add_le
    (normalReference E.equiv (pairFrameMap q.val ((S i).normal (A.centers i j))) t - t) t
  rw [sub_add_cancel] at hh
  have ht' : ‖t‖ ≤ A.ρ := by simpa only [mem_closedBall, dist_zero_right] using ht
  rw [dist_eq_norm] at hd'
  change ‖normalReference E.equiv (pairFrameMap q.val ((S i).normal (A.centers i j))) t‖ ≤ _
  linarith

/-- Actual target points have regular zero-level charts of one common radius,
with the retained derivative and inverse-derivative bounds. -/
theorem CertifiedArticleLocalizationAtlas.uniform_zero_target_charts {k : ℕ} (hk : 0 < k)
    {S : Fin k → SmoothPatch (k+2)} {κ : ℝ} (A : CertifiedArticleLocalizationAtlas S κ) :
    ∃ σ : ℝ, 0 < σ ∧ ∀ (q : ArticleFrame S κ) (i : Fin k) (j : Fin (A.charts i))
      (y : Ambient (k+2)), y ∈ (A.normalCoordinates q i j).zeroTarget A.τ →
      ∃ φ : Ambient (k+2-3) → Ambient (k+2), φ 0 = y ∧
        (∀ t ∈ closedBall 0 σ, ContDiffAt ℝ (⊤ : ℕ∞) φ t) ∧
        (∀ m t, t ∈ closedBall 0 σ → ‖iteratedFDeriv ℝ m φ t‖ ≤ A.B m) ∧
        (∀ t ∈ closedBall 0 σ, ∀ v, ‖v‖ ≤ (A.B 1*A.L)*‖fderiv ℝ φ t v‖) ∧
        (∀ t ∈ closedBall 0 σ, φ t ∈ (S i).extendedSurface ∧
          thinConstraint (S i) (pairPlane q.val) (φ t) = 0) := by
  let σ := (A.r-A.ρ-(A.L+1)*A.τ)/2
  have hσ : 0 < σ := by dsimp [σ]; linarith [A.reference_margin]
  refine ⟨σ,hσ,?_⟩
  intro q i j y hy
  obtain ⟨t,⟨ht,hs⟩,rfl⟩ := hy
  let F := A.measuredChart q i j
  let E := A.normalCoordinates q i j
  let a := normalReference E.equiv (pairFrameMap q.val ((S i).normal (A.centers i j))) t
  have ha : ‖a‖ ≤ A.ρ+(A.L+1)*A.τ := A.reference_norm_bound q i j t ht hs
  have hfit : ‖a‖+σ ≤ A.r := by dsimp [σ]; linarith [A.reference_margin]
  obtain ⟨φ,hφ0,hφ,hder,hinv,hlevel⟩ := F.controlled_fiber_chart
    (by omega : 3 ≤ k+2) q.property.1 a σ hσ hfit
  have hz : thinConstraint (S i) (pairPlane q.val) (F.param a) = 0 :=
    (A.zero_target q i j _ ⟨t,⟨ht,hs⟩,rfl⟩).2.1
  refine ⟨φ,hφ0,hφ,hder,hinv,?_⟩
  intro u hu
  exact ⟨(hlevel u hu).1,(hlevel u hu).2.trans (by rw [hφ0]; exact hz)⟩

/-- The exact localized target and unlocalized carriers satisfy the borrowed
normal-space condition, on genuine regular charts, with a common normalized
Gram lower bound fixed before the frame, chart tuple and frequency points. -/
theorem CertifiedArticleLocalizationAtlas.localized_normal_certificate {k : ℕ} (hk : 0 < k)
    {S : Fin k → SmoothPatch (k+2)} {κ : ℝ} (A : CertifiedArticleLocalizationAtlas S κ) :
    ∃ σ : ℝ, 0 < σ ∧ ∀ (q : ArticleFrame S κ) (i : Fin k)
      (a : ∀ j, Fin (A.charts j)) (y : Fin k → Ambient (k+2)),
      y i ∈ (A.normalCoordinates q i (a i)).zeroTarget A.τ →
      (∀ j, j ≠ i → y j ∈ (A.measuredChart q j (a j)).carrier) →
      ∃ φ : Ambient (k+2-3) → Ambient (k+2), φ 0 = y i ∧
        (∀ t ∈ closedBall 0 σ, ContDiffAt ℝ (⊤ : ℕ∞) φ t) ∧
        (∀ m t, t ∈ closedBall 0 σ → ‖iteratedFDeriv ℝ m φ t‖ ≤ A.B m) ∧
        Function.Injective (fderiv ℝ φ 0) ∧
        (∀ t ∈ closedBall 0 σ, thinConstraint (S i) (pairPlane q.val) (φ t) = 0) ∧
        ∃ b : OrthonormalBasis (Fin 3) ℝ (LinearMap.range (fderiv ℝ φ 0).toLinearMap)ᗮ,
          A.wedgeLower ≤ Matrix.det (Matrix.gram ℝ (Sum.elim
            (fun j : {j : Fin k // j ≠ i} => (S j).normal (y j))
            (fun j => (b j : Ambient (k+2))))) := by
  obtain ⟨σ,hσ,hcharts⟩ := A.uniform_zero_target_charts hk
  refine ⟨σ,hσ,?_⟩
  intro q i a y hyi hyrest
  obtain ⟨φ,hφ0,hφ,hder,hinv,hlevel⟩ := hcharts q i (a i) (y i) hyi
  have h0 : (0 : Ambient (k+2-3)) ∈ closedBall 0 σ := mem_closedBall_self hσ.le
  have hi : Function.Injective (fderiv ℝ φ 0) := by
    intro u v huv
    apply sub_eq_zero.mp
    apply norm_eq_zero.mp
    have hh := hinv 0 h0 (u-v)
    rw [map_sub,huv,sub_self,norm_zero,mul_zero] at hh
    exact le_antisymm hh (norm_nonneg _)
  have hy : ∀ j, y j ∈ (S j).extendedSurface ∧ dist (y j) (A.centers j (a j)) ≤ A.η := by
    intro j
    by_cases hj : j = i
    · subst j
      exact ⟨(A.zero_target q i (a i) _ hyi).1,(A.zero_target q i (a i) _ hyi).2.2⟩
    · have hc := hyrest j hj
      refine ⟨(A.measuredChart q j (a j)).carrier_subset_surface A.ρ_lt_r.le hc,?_⟩
      have hd := (A.measuredChart q j (a j)).carrier_subset_closedBall hc
      exact hd.trans (by linarith [A.η_pos])
  have hevent : ∀ᶠ t in nhds (0 : Ambient (k+2-3)),
      thinConstraint (S i) (pairPlane q.val) (φ t) = thinConstraint (S i) (pairPlane q.val) (φ 0) := by
    filter_upwards [Metric.ball_mem_nhds (0 : Ambient (k+2-3)) hσ] with t ht
    exact (hlevel t (ball_subset_closedBall ht)).2.trans (hlevel 0 h0).2.symm
  obtain ⟨b,hb⟩ := A.joint_normalized q i a y hy φ 0 hφ0
    ((hφ 0 h0).differentiableAt (by simp)) hi hevent
  exact ⟨φ,hφ0,hφ,hder,hi,fun t ht => (hlevel t ht).2,b,hb⟩
end N2Restriction
#print axioms N2Restriction.CertifiedArticleLocalizationAtlas.reference_norm_bound
#print axioms N2Restriction.CertifiedArticleLocalizationAtlas.uniform_zero_target_charts
#print axioms N2Restriction.CertifiedArticleLocalizationAtlas.localized_normal_certificate
