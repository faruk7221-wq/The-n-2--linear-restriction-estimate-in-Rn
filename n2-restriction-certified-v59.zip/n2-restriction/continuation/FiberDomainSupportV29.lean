import continuation.NormalizedFiberInputsV29

namespace N2Restriction
open MeasureTheory Set Metric
open scoped NNReal ENNReal

namespace StripChartAmplitude
variable {n : ℕ} {S : SmoothPatch n} {Q : Ambient n →L[ℝ] ℝ × ℝ} {z : Ambient n}
  {δ r ρ s : ℝ} {B : ℕ → ℝ} {c C : ℝ≥0} {L α β ε : ℝ}
  {F : MeasuredTubularChart S Q z δ r ρ s B c C L}
  {E : ChartNormalCoordinates F α β}
  {g : Lp ℂ 2 ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier)}

/-- Actual fiber inputs are supported in the actual slice of the compact
parameter domain, not merely in an enclosing thin-coordinate ball. -/
theorem fiberInput_parameter_support (A : StripChartAmplitude F E g ε) (u : ℝ × ℝ) :
    HasFrequencySupport volume id
      {v | E.equiv.symm (u, v) ∈ closedBall (0 : Ambient (n - 1)) ρ} (A.fiberInput u) := by
  classical
  by_cases hm : MemLp (A.fiberAmplitude u) 2 volume
  · rw [fiberInput, dif_pos hm]
    filter_upwards [MemLp.coeFn_toLp hm] with v hv hn
    apply A.input_mem_ball
    intro hz
    change A.input (E.equiv.symm (u, v)) = 0 at hz
    exact hn (hv.trans (by simp [fiberAmplitude, hz]))
  · rw [fiberInput, dif_neg hm]
    filter_upwards [Lp.coeFn_zero (E := ℂ) (p := (2 : ℝ≥0∞))
      (μ := (volume : Measure (Ambient (n - 3))))] with v hv hn
    exact (hn hv).elim

/-- Haar normalization preserves the actual sliced parameter support, so
chart derivative and transversality hypotheses apply on essential support. -/
theorem normalizedFiberInput_parameter_support (A : StripChartAmplitude F E g ε) (u : ℝ × ℝ) :
    HasFrequencySupport volume id
      {v | E.equiv.symm (u, v) ∈ closedBall (0 : Ambient (n - 1)) ρ} (A.normalizedFiberInput u) := by
  filter_upwards [A.fiberInput_parameter_support u,
    Lp.coeFn_smul (NNReal.sqrt (coordinateMeasureFactor E.equiv volume (volume.prod volume)) : ℝ)
      (A.fiberInput u)] with v hv he hn
  apply hv
  intro hz
  exact hn (he.trans (by simp [hz]))

end StripChartAmplitude
end N2Restriction

#print axioms N2Restriction.StripChartAmplitude.fiberInput_parameter_support
#print axioms N2Restriction.StripChartAmplitude.normalizedFiberInput_parameter_support
