import continuation.ActualTangentBaselineV50
import continuation.ActualTangentArticleLowerV50
import continuation.TangentCriticalNormalizationV50
namespace N2Restriction
open MeasureTheory Set Metric Filter
open scoped ENNReal NNReal

/-- The critical-exponent part of (7.12) for the actual Ftan, with the exact
loss sigma=k/(k+1)*(2*tau+epsilon). Terminal cube geometry remains explicit. -/
theorem actualTangentSum_critical_bound {k : ℕ} (hk : 3 ≤ k)
    (P : Fin k → SmoothPatch (k+2)) {ι : ℝ}
    (Dsub : ∀ i, DirectionalSubdivision (P i) ι) (a : ∀ i, Fin (Dsub i).size) (A : (i : Fin k) → PacketGraphAtlas ((fun i => (Dsub i).piece (a i)) i))
    {κ : ℝ} (B : ArticleLocalizationAtlas (fun i => (Dsub i).piece (a i)) κ)
    (V : Fin k → Set (Ambient (k+2))) (m : ℝ)
    (hS : ∀ i, ((fun i => (Dsub i).piece (a i)) i).extendedSurface ∩ V i ⊆ ((fun i => (Dsub i).piece (a i)) i).support) (hm : 0 < m)
    {ε τ lam : ℝ} (hε : 0 < ε)
    (hexternal : B.UniformLocalizedInput (baseline (k : ℝ))) (hτ : 0 < τ) (hτ' : τ < 1/4) (hlam : 1 ≤ lam)
    (C C₀ θ Cext Bcap : ℝ)
    (hC : 1 ≤ C) (hC₀ : 1+Real.sqrt (k+2 : ℕ)*(1+C)/2 ≤ C₀)
    (hθ : 0 < θ) (hBcap : 0 ≤ Bcap)
    (hKak : ∀ r w : ℝ, 1 ≤ w → w < r →
      FiniteDirectionalKakeya (volume.restrict (ball 0 r))
        (fun i => (P i).normal ((Dsub i).anchor (a i))) ι w (1/((k : ℝ)-1))
        (ENNReal.ofReal (Cext*r^(ε*(baseline (k : ℝ)))*w^((k+2 : ℕ)-ε*(baseline (k : ℝ)))))) :
    ∃ K : ENNReal, K ≠ ∞ ∧ ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ R : ℝ, R₀ ≤ R →
    ∀ (Q : (i : Fin k) → (j : Fin (A i).size) →
      CoordinateCapFamily ((A i).patch j).support (R^(-1/2 : ℝ)))
      (hr : 0 < R^(-1/2 : ℝ)), (∀ i, R^(-1/2 : ℝ) ≤ (A i).capRadius) →
    (∀ i j, ((Q i j).centers.card : ℝ) ≤ Bcap*R^(((k+1 : ℕ) : ℝ)/2)) →
    ∀ (g : (i : Fin k) → Lp ℂ 2 ((fun i => (Dsub i).piece (a i)) i).surfaceMeasure)
      (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure),
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
    (∀ i j, HasFrequencySupport ((A i).graph j).surfaceMeasure ((A i).patch j).rotation
      (marginRegion (V i) (m-R^(-1/4 : ℝ))) (f i j)) →
    ∀ (L : ℕ) (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin (k+1) → ℤ))
      (Z : Set (Ambient (k+2))) (T : Ambient (k+2) → Submodule ℝ (Ambient (k+2)))
      (c : Fin L → Ambient (k+2)) (Ω : Set (Ambient (k+2))),
    (∀ l t, l ≠ t → 2*(θ*(R^(1-τ))) ≤ dist (c l) (c t)) →
    MeasurableSet Ω → Ω ⊆ closedBall 0 R →
    (∀ (zgrid : meetingGrid (n := k+2) (lam*R^(1/2+τ)) R) (l : Fin L), ((Ω ∩ ball (c l) (R^(1-τ))) ∩ gridCube (gridCentre (lam*R^(1/2+τ)) zgrid.val) (lam*R^(1/2+τ))).Nonempty →
      HasTerminalCubeFrame (fun i => (Dsub i).piece (a i)) κ Z T (c l) (gridCentre (lam*R^(1/2+τ)) zgrid.val) (R^(1-τ)) (lam*R^(1/2+τ))) →
    positiveNorm
      (actualTangentSum A Q hr f U Z T c (R^(1-τ)) (lam*R^(1/2+τ)) C₀ R (R^(1/2+τ)/10) Ω) (critical (k : ℝ)) volume ≤
      K*ENNReal.ofReal (R^(sigma (k : ℝ) τ ε))*∏ i, ENNReal.ofReal ‖g i‖ := by
  have hkR : (3 : ℝ) ≤ k := by exact_mod_cast hk
  have hk0 : (0 : ℝ) < k := by linarith
  have hk1 : (1 : ℝ) < k := by linarith
  obtain ⟨K₀,hK₀,R₀,hR₀,hb⟩ := actualTangentSum_baseline_bound hk P Dsub a A B V m hS hm
    hε hexternal hτ hτ' hlam C C₀ θ Cext Bcap hC hC₀ hθ hBcap hKak
  obtain ⟨K₁,hK₁,R₁,hR₁,hl⟩ := actualTangentSum_article_lower_bound (by omega : 0 < k)
    (fun i => (Dsub i).piece (a i)) A V m hS hθ hm hτ hτ'
  obtain ⟨hθ₀,hθ₁⟩ := theta_range hk0
  have hθc : 0 ≤ 1-theta (k : ℝ) := by linarith
  refine ⟨K₀^theta (k : ℝ)*K₁^(1-theta (k : ℝ)),
    ENNReal.mul_ne_top (ENNReal.rpow_ne_top_of_nonneg hθ₀.le hK₀)
      (ENNReal.rpow_ne_top_of_nonneg hθc hK₁),
    max R₀ R₁,hR₀.trans (le_max_left _ _),?_⟩
  intro R hR Q hr hsmall hcount g f he hf L U Z T c Ω hsep hΩ hΩR hframe
  have hR0 := (le_max_left R₀ R₁).trans hR
  have hR1 := (le_max_right R₀ R₁).trans hR
  have hRpos : 0 < R := zero_lt_one.trans_le (hR₀.trans hR0)
  have hlow := hl R hR1 Q hr hsmall g f he hf U Z T c (lam*R^(1/2+τ)) C₀ Ω hsep
  apply tangent_critical_normalized volume _
    (measurable_actualTangentSum A Q hr hsmall f U Z T c (R^(1-τ)) (lam*R^(1/2+τ)) C₀ R
      (R^(1/2+τ)/10) Ω hΩ).aemeasurable hk1 hRpos K₀ K₁ _
  · exact hb R hR0 Q hr hsmall hcount g f he hf L U Z T c Ω hsep hΩ hΩR hframe
  · exact hlow

end N2Restriction
#print axioms N2Restriction.actualTangentSum_critical_bound
