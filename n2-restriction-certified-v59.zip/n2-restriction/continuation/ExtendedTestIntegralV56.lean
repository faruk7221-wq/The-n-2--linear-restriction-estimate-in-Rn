import continuation.ExtendedTestSupportV56
import N2Restriction.Extension
namespace N2Restriction
open Set MeasureTheory

/-- The full surface integral of a test density equals its compactly
restricted integral. This is exact even before integrability is proved. -/
theorem extended_test_integral_restrict {n : ℕ} (S : SmoothPatch n)
    (ψ : Ambient n → ℂ) (μ : Measure (Ambient n)) (x : Ambient n) :
    extension (μ.restrict (tsupport ψ ∩ S.extendedSurface)) id ψ x =
      extension (μ.restrict S.extendedSurface) id ψ x := by
  unfold extension
  rw [← Measure.restrict_restrict (isClosed_tsupport ψ).measurableSet]
  apply setIntegral_eq_integral_of_forall_compl_eq_zero
  intro y hy
  rw [image_eq_zero_of_notMem_tsupport hy,mul_zero]

/-- The original full extended-surface Fourier integral is realized by a
genuine compact SmoothPatch with precisely the original Hausdorff measure. -/
theorem SmoothPatch.exists_extended_test_extension {n : ℕ} (S : SmoothPatch n)
    (ψ : Ambient n → ℂ) (hψ : HasCompactSupport ψ)
    (hinside : tsupport ψ ⊆ S.neighborhood) :
    ∃ P : SmoothPatch n, P.support = tsupport ψ ∩ S.extendedSurface ∧
      P.extendedSurface = S.extendedSurface ∧ P.normal = S.normal ∧
      ∀ x, extension P.surfaceMeasure id ψ x =
        extension ((Measure.hausdorffMeasure ((n : ℝ)-1)).restrict S.extendedSurface) id ψ x := by
  obtain ⟨P,hP,hE,hN,hμ⟩ := S.exists_extended_test_patch ψ hψ hinside
  refine ⟨P,hP,hE,hN,?_⟩
  intro x
  rw [hμ]
  exact extended_test_integral_restrict S ψ _ x
end N2Restriction
#print axioms N2Restriction.extended_test_integral_restrict
#print axioms N2Restriction.SmoothPatch.exists_extended_test_extension
