import continuation.AdjointWedgeV26

set_option maxHeartbeats 800000

namespace N2Restriction

def tupleAdjointAdmissible {k : ℕ} (S : Fin k → SmoothPatch (k + 2))
    (i : Fin k) (κ : ℝ)
    (r : (Fin k → Ambient (k + 2)) ×
      ((Ambient (k + 2) × Ambient (k + 2)) ×
        (Ambient (k + 2) × Ambient (k + 2)))) : Prop :=
  (∀ j, inner ℝ ((S j).normal (r.1 j)) r.2.1.1 = 0) ∧
  (∀ j, inner ℝ ((S j).normal (r.1 j)) r.2.1.2 = 0) ∧
  ‖pairProjection r.2.1 - pairProjection r.2.2‖ *
    ‖(S i).shape (r.1 i)‖ ≤ κ / 2

def tupleAdjointFrameSet {k : ℕ} (S : Fin k → SmoothPatch (k + 2))
    (i : Fin k) (κ : ℝ) : Set (TupleWedgeBase S) :=
  {r | tupleAdjointAdmissible S i κ r.1}

theorem isClosed_tupleAdjointFrameSet {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) (i : Fin k) (κ : ℝ) :
    IsClosed (tupleAdjointFrameSet S i κ) := by
  let B := TupleWedgeBase S
  let z : B → Fin k → Ambient (k + 2) := fun r => r.1.1
  let p : B → Ambient (k + 2) × Ambient (k + 2) := fun r => r.1.2.1
  let q : B → Ambient (k + 2) × Ambient (k + 2) := fun r => r.1.2.2
  have hz : Continuous z := continuous_fst.comp continuous_subtype_val
  have hp : Continuous p := continuous_fst.comp (continuous_snd.comp continuous_subtype_val)
  have hq : Continuous q := continuous_snd.comp (continuous_snd.comp continuous_subtype_val)
  have hzj : ∀ j, Continuous (fun r : B => z r j) := fun j =>
    (continuous_apply j).comp hz
  have hNj : ∀ j, Continuous (fun r : B => (S j).normal (z r j)) := by
    intro j
    have hNOn : ContinuousOn (S j).normal (S j).support :=
      (S j).smooth_normal.continuousOn.mono
        (fun x hx => (S j).support_inside hx)
    exact hNOn.comp_continuous (hzj j) (fun r => r.2.1 j)
  have hp₁ : Continuous (fun r : B => (p r).1) := continuous_fst.comp hp
  have hp₂ : Continuous (fun r : B => (p r).2) := continuous_snd.comp hp
  have hTan₁ : IsClosed {r : B | ∀ j,
      inner ℝ ((S j).normal (z r j)) (p r).1 = 0} := by
    rw [show {r : B | ∀ j, inner ℝ ((S j).normal (z r j)) (p r).1 = 0} =
      ⋂ j, {r : B | inner ℝ ((S j).normal (z r j)) (p r).1 = 0} by
        ext r
        simp]
    apply isClosed_iInter
    intro j
    exact isClosed_eq ((hNj j).inner hp₁) continuous_const
  have hTan₂ : IsClosed {r : B | ∀ j,
      inner ℝ ((S j).normal (z r j)) (p r).2 = 0} := by
    rw [show {r : B | ∀ j, inner ℝ ((S j).normal (z r j)) (p r).2 = 0} =
      ⋂ j, {r : B | inner ℝ ((S j).normal (z r j)) (p r).2 = 0} by
        ext r
        simp]
    apply isClosed_iInter
    intro j
    exact isClosed_eq ((hNj j).inner hp₂) continuous_const
  have hShapeOn : ContinuousOn (S i).shape (S i).support := by
    unfold SmoothPatch.shape
    exact (S i).smooth_normal.continuousOn_fderiv_of_isOpen
      (S i).open_neighborhood (by simp) |>.neg |>.mono
        (fun x hx => (S i).support_inside hx)
  have hShape : Continuous (fun r : B => (S i).shape (z r i)) :=
    hShapeOn.comp_continuous (hzj i) (fun r => r.2.1 i)
  have hPW : Continuous (fun r : B => pairProjection (p r)) :=
    (continuous_pairProjection (k + 2)).comp hp
  have hPQ : Continuous (fun r : B => pairProjection (q r)) :=
    (continuous_pairProjection (k + 2)).comp hq
  have hGap : Continuous (fun r : B =>
      ‖pairProjection (p r) - pairProjection (q r)‖ *
        ‖(S i).shape (z r i)‖) := (hPW.sub hPQ).norm.mul hShape.norm
  change IsClosed ({r : B | ∀ j, inner ℝ ((S j).normal (z r j)) (p r).1 = 0} ∩
    ({r : B | ∀ j, inner ℝ ((S j).normal (z r j)) (p r).2 = 0} ∩
      {r : B | ‖pairProjection (p r) - pairProjection (q r)‖ * ‖(S i).shape (z r i)‖ ≤ κ / 2}))
  exact hTan₁.inter (hTan₂.inter (isClosed_le hGap continuous_const))

theorem isCompact_tupleAdjointFrameSet {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) (i : Fin k) (κ : ℝ) :
    IsCompact (tupleAdjointFrameSet S i κ) := by
  letI : CompactSpace (TupleWedgeBase S) :=
    isCompact_iff_compactSpace.mp (isCompact_tupleWedgeBaseSet S)
  exact (isClosed_tupleAdjointFrameSet S i κ).isCompact

noncomputable def tupleAdjointVectors {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) (i : Fin k)
    (r : TupleWedgeBase S) : Sum (Fin k) (Fin 2) → Ambient (k + 2) :=
  adjointWedgeVectors S r.1.1 i r.1.2.2

theorem continuous_tupleAdjointVectors {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) (i : Fin k) :
    Continuous (fun r : TupleWedgeBase S => tupleAdjointVectors S i r) := by
  let B := TupleWedgeBase S
  let z : B → Fin k → Ambient (k + 2) := fun r => r.1.1
  let q : B → Ambient (k + 2) × Ambient (k + 2) := fun r => r.1.2.2
  have hz : Continuous z := continuous_fst.comp continuous_subtype_val
  have hzj : ∀ j, Continuous (fun r : B => z r j) := fun j =>
    (continuous_apply j).comp hz
  have hNj : ∀ j, Continuous (fun r : B => (S j).normal (z r j)) := by
    intro j
    have hNOn : ContinuousOn (S j).normal (S j).support :=
      (S j).smooth_normal.continuousOn.mono
        (fun x hx => (S j).support_inside hx)
    exact hNOn.comp_continuous (hzj j) (fun r => r.2.1 j)
  have hShapeOn : ContinuousOn (S i).shape (S i).support := by
    unfold SmoothPatch.shape
    exact (S i).smooth_normal.continuousOn_fderiv_of_isOpen
      (S i).open_neighborhood (by simp) |>.neg |>.mono
        (fun x hx => (S i).support_inside hx)
  have hShape : Continuous (fun r : B => (S i).shape (z r i)) :=
    hShapeOn.comp_continuous (hzj i) (fun r => r.2.1 i)
  have hq : Continuous q := continuous_snd.comp (continuous_snd.comp continuous_subtype_val)
  have hq₁ : Continuous (fun r : B => (q r).1) := continuous_fst.comp hq
  have hq₂ : Continuous (fun r : B => (q r).2) := continuous_snd.comp hq
  have hSq₁ : Continuous (fun r : B => ((S i).shape (z r i)).adjoint ((q r).1)) :=
    (ContinuousLinearMap.adjoint.continuous.comp hShape).clm_apply hq₁
  have hSq₂ : Continuous (fun r : B => ((S i).shape (z r i)).adjoint ((q r).2)) :=
    (ContinuousLinearMap.adjoint.continuous.comp hShape).clm_apply hq₂
  change Continuous (fun r : B =>
    adjointWedgeVectors S (z r) i (q r))
  refine continuous_pi fun a => ?_
  cases a with
  | inl j => simpa [adjointWedgeVectors] using hNj j
  | inr j =>
    fin_cases j
    · simpa [adjointWedgeVectors] using hSq₁
    · simpa [adjointWedgeVectors] using hSq₂


end N2Restriction

#print axioms N2Restriction.continuous_tupleAdjointVectors
#print axioms N2Restriction.isClosed_tupleAdjointFrameSet
#print axioms N2Restriction.isCompact_tupleAdjointFrameSet
