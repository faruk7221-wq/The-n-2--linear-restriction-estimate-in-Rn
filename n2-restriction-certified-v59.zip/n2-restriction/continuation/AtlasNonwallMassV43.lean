import continuation.AtlasTrimmedCellMassV43
import continuation.CellularMassRecurrenceV43

namespace N2Restriction
open MeasureTheory Set
open scoped BigOperators ENNReal

/-- The actual atlas non-wall mass estimate with the exact cellular degree
power and the proved packet omission error. The energy and mass retention
premises are supplied by a single substantial-cell selection. This theorem
retains the fixed-buffer local constant; changing-stage margin compatibility
is a separate obligation. -/
theorem atlas_nonwall_mass_bound {d k : ℕ} (S : Fin k → SmoothPatch (d+1))
    (T : (i : Fin k) → PacketGraphAtlas (S i)) {τ : ℝ} (hτ : 0 < τ) :
    ∃ M : ℝ, 1 ≤ M ∧ ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ N : ℝ, ∃ C : ℝ, 0 ≤ C ∧
      ∀ R : ℝ, R₀ ≤ R →
      ∀ (Q : (i : Fin k) → (j : Fin (T i).size) →
        CoordinateCapFamily ((T i).patch j).support (R^(-1/2 : ℝ)))
        (hr : 0 < R^(-1/2 : ℝ)), (∀ i, R^(-1/2 : ℝ) ≤ (T i).capRadius) →
      ∀ B : ℝ, 0 ≤ B → (∀ i j, ((Q i j).centers.card : ℝ) ≤ B*R^((d : ℝ)/2)) →
      ∀ (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure)
        (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure),
      (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
      ∀ {l : ℕ} (P : Fin l → MvPolynomial (Fin (d+1)) ℝ)
        (Ω : Set (Ambient (d+1))) (σ : Fin l → Bool) (b : ℝ)
        (A : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ))
        {m p : ℝ}, (∀ i, m ≤ (T i).margin) → 0 < p → p ≤ 1 →
      ∀ (q : Finset (Ambient (d+1))),
      (Metric.closedBall 0 R ⊆ ⋃ a : q, Metric.ball (R • a.val) (R/2)) →
      ∀ Δ : Set (Ambient (d+1)), MeasurableSet Δ → Δ ⊆ Metric.closedBall 0 R →
      Δ ⊆ Ω → Δ ⊆ PolynomialSignRegion P σ →
      (∀ x ∈ Δ, ∀ z, ambientPolynomial (∏ l, P l) z = 0 → b ≤ dist x z) →
      ∀ (far : Finset (Fin k)) (E : Fin k → ℝ), (∀ i, 0 ≤ E i) →
      ∀ {D s : ℝ}, 0 < D →
      (∀ i, ‖(T i).cellInput (Q i) hr (f i)
        (fun j a => {ν | ν ∈ A i j a ∧ σ ∈ trimmedCellLabels P
          ((T i).cellAxisPoint j (R^(-1/2 : ℝ)) ν)
          ((T i).cellAxisDirection j a.val) Ω b (R^(1/2+τ)/10)})‖^2 ≤
        (E i * D^(1-s-(if i ∈ far then (1 : ℝ) else 0))) * ‖g i‖^2) →
      ∀ K H M₀ err : ENNReal,
      M₀ ≤ K*(∫⁻ x in Ω, ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
        (fun i => (T i).cellInput (Q i) hr (f i) (A i)) x‖ₑ ^ p)+err →
      (∫⁻ x in Ω, ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
        (fun i => (T i).cellInput (Q i) hr (f i) (A i)) x‖ₑ ^ p) ≤
        H*ENNReal.ofReal (D^s)*(∫⁻ x in Δ,
          ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
            (fun i => (T i).cellInput (Q i) hr (f i) (A i)) x‖ₑ ^ p) →
      M₀ ≤ (K*H*(q.card : ENNReal)) *
        ENNReal.ofReal ((∏ i, E i)^(p/2)*D^(cellular k s far.card p)) *
        (marginLocalConstant (fun i => (T i).bufferMeasure) (fun _ => id)
          (fun i => (S i).neighborhood) m p (R/2))^p *
        (∏ i, ENNReal.ofReal ‖g i‖)^p +
        (K*H*ENNReal.ofReal (D^s)*
          ((ENNReal.ofReal ((k : ℝ)*(C*Real.sqrt B*R^(-N))*M^k*∏ i, ‖g i‖))^p * volume Δ)+err) := by
  obtain ⟨M, hM, R₀, hR₀, ht⟩ := atlas_trimmed_cell_mass S T hτ
  refine ⟨M, hM, R₀, hR₀, fun N => ?_⟩
  obtain ⟨C, hC, hc⟩ := ht N
  refine ⟨C, hC, ?_⟩
  intro R hR Q hr hsmall B hB hcount g f he l P Ω σ b A m p hmargin hp hp1 q hcover Δ hΔ hin hΩ hsign htrim far E hE D s hD henergy K H M₀ err hstage hret
  have hcell := hc R hR Q hr hsmall B hB hcount g f he P Ω σ b A hmargin hp hp1 q hcover Δ hΔ hin hΩ hsign htrim
  apply cellular_mass_recurrence far E hE hD s _ (fun i => ENNReal.ofReal ‖g i‖)
    _ (q.card : ENNReal) K H M₀ _ _ err _ hp.le hstage hret hcell
  intro i
  rw [← ENNReal.ofReal_pow (norm_nonneg _) 2, ← ENNReal.ofReal_pow (norm_nonneg _) 2,
    ← ENNReal.ofReal_mul (mul_nonneg (hE i) (Real.rpow_nonneg hD.le _))]
  exact ENNReal.ofReal_le_ofReal (henergy i)

end N2Restriction
#print axioms N2Restriction.atlas_nonwall_mass_bound
