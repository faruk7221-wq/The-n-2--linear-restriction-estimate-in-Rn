import continuation.UniformLocalizedSupportV27

namespace N2Restriction
open Set Filter Metric MeasureTheory

/-- Finite extraction preserves any chart/target property. Relative local
coverage is sufficient; the compact chart sets themselves need not be open. -/
theorem compact_localization_atlas {E : Type*} [TopologicalSpace E]
    {T : Set E} (hT : IsCompact T) (P : Set E → Set E → Prop)
    (hlocal : ∀ x ∈ T, ∃ K Z : Set E, P K Z ∧
      ∀ᶠ y in nhds x, y ∈ T → y ∈ K) :
    ∃ m : ℕ, ∃ K Z : Fin m → Set E,
      (∀ j, P (K j) (Z j)) ∧ T ⊆ ⋃ j, K j := by
  classical
  choose K Z hP hcov using fun x : T => hlocal x x.2
  obtain ⟨s, hs⟩ := hT.elim_nhds_subcover'
    (fun x hx => {y | y ∈ T → y ∈ K ⟨x, hx⟩}) (fun x hx => hcov ⟨x, hx⟩)
  let e := Fintype.equivFin s
  refine ⟨Fintype.card s, (fun j => K (e.symm j).val),
    (fun j => Z (e.symm j).val), (fun j => hP _), ?_⟩
  intro x hx
  obtain ⟨y, hy, hxy⟩ := mem_iUnion₂.mp (hs hx)
  refine mem_iUnion.mpr ⟨e ⟨y, hy⟩, ?_⟩
  simpa only [Equiv.symm_apply_apply] using hxy hx

/-- For a fixed frame admissible over a selected support, the uniform local
geometry yields a finite atlas of genuine zero-level localization targets.
The chart count is finite here, not asserted uniform over frames. -/
theorem geometric_finite_localization_atlas {k : ℕ} (hk : 0 < k)
    (S : Fin k → SmoothPatch (k + 2)) {ν κ : ℝ}
    (hgeo : GeometricHypotheses S ν κ) :
    ∃ τ D : ℝ, 0 < τ ∧ 0 < D ∧
      ∀ z : Fin k → Ambient (k + 2), (∀ j, z j ∈ (S j).support) →
      ∀ i q, q ∈ orthonormalPairSet (k + 2) →
        (∀ x ∈ (S i).support,
          ‖(commonTangent (fun j => (S j).normal (Function.update z i x j))).starProjection -
            pairProjection q‖ * ‖(S i).shape x‖ ≤ κ / 2) →
      ∃ m : ℕ, ∃ K Z : Fin m → Set (Ambient (k + 2)),
        (∀ j, IsCompact (K j)) ∧ (S i).support ⊆ ⋃ j, K j ∧
        (∀ j y, y ∈ Z j → y ∈ (S i).extendedSurface ∧
          thinConstraint (S i) (pairPlane q) y = 0) ∧
        (∀ j x, x ∈ K j → ‖pairFrameMap q ((S i).normal x)‖ ≤ τ →
          ∃ y ∈ Z j, dist x y ≤ D * ‖pairFrameMap q ((S i).normal x)‖) := by
  classical
  obtain ⟨η, τ, D, _, hτ, hD, hlocal⟩ := geometric_uniform_localized_support hk S hgeo
  refine ⟨τ, D, hτ, hD, ?_⟩
  intro z hz i q hq hgap
  let P : Set (Ambient (k + 2)) → Set (Ambient (k + 2)) → Prop := fun K Z =>
    IsCompact K ∧ (∀ y ∈ Z, y ∈ (S i).extendedSurface ∧ thinConstraint (S i) (pairPlane q) y = 0) ∧
    (∀ x ∈ K, ‖pairFrameMap q ((S i).normal x)‖ ≤ τ →
      ∃ y ∈ Z, dist x y ≤ D * ‖pairFrameMap q ((S i).normal x)‖)
  have hl : ∀ x ∈ (S i).support, ∃ K Z, P K Z ∧
      ∀ᶠ y in nhds x, y ∈ (S i).support → y ∈ K := by
    intro x hx
    have hz' : ∀ j, Function.update z i x j ∈ (S j).support := by
      intro j
      by_cases hji : j = i
      · subst j; simpa using hx
      · simpa [Function.update_of_ne hji] using hz j
    obtain ⟨K, Z, hc, _, hcov, hzero, hloc, _⟩ := hlocal (Function.update z i x) hz' i q hq
      (by simpa using hgap x hx)
    refine ⟨K, Z, ⟨hc, fun y hy => ⟨(hzero y hy).1, (hzero y hy).2.1⟩, hloc⟩, ?_⟩
    simp only [Function.update_self] at hcov
    filter_upwards [hcov] with y hy hys
    exact hy ((S i).support_in_extendedSurface hys)
  obtain ⟨m, K, Z, hp, hcover⟩ := compact_localization_atlas (S i).compact_support P hl
  exact ⟨m, K, Z, fun j => (hp j).1, hcover, fun j => (hp j).2.1, fun j => (hp j).2.2⟩

end N2Restriction

#print axioms N2Restriction.compact_localization_atlas
#print axioms N2Restriction.geometric_finite_localization_atlas
