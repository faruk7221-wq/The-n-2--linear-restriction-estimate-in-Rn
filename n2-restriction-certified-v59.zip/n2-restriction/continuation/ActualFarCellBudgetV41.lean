import continuation.ActualLabelledCellBudgetV41
import continuation.TangentNetAssignmentV41

namespace N2Restriction
open MeasureTheory UnitAddTorus Set
open scoped BigOperators ENNReal
noncomputable local instance farCellCircleMeasure : MeasureSpace UnitAddCircle := ⟨AddCircle.haarAddCircle⟩

/-- Section 6's degree-independent far-cell budget for actual graph packets
across all caps on the selected plane region. Algebraic tube covering is
an explicit borrowed premise; energy and incidence are proved. -/
theorem actual_far_cell_budget {d n m q H : ℕ} {J : Type*} [Fintype J]
    (c : J → Ambient d) (r : ℝ) (hr : 0 < r)
    (f : (j : J) → Lp ℂ 2 (volume.restrict (packetFrequencyCube (c j) r hr)))
    (A : J → Set (Fin d → ℤ)) (P : Fin m → MvPolynomial (Fin n) ℝ)
    (Q : Fin q → MvPolynomial (Fin n) ℝ) (cuts : Set (Ambient n))
    (V : Submodule ℝ (Ambient n)) {γ K : ℝ} (hK : 0 ≤ K)
    (hexternal : AlgebraicTubeCoverInput {x | polynomialLevelMap Q x = 0}
      (fun z => LinearMap.ker (fderiv ℝ (polynomialLevelMap Q) z).toLinearMap) γ H K)
    (a v : J → (Fin d → ℤ) → Ambient n) (Ω : Set (Ambient n))
    {b w : ℝ} (hb : 0 < b) (hw : w ≤ b)
    (hregion : Ω ⊆ Metric.thickening b (planeWitnessSet Q cuts V (2*γ)))
    (hv : ∀ j ν, ν ∈ A j → ‖v j ν‖ = 1)
    (hangle : ∀ j ν, ν ∈ A j → 4*γ < directionPlaneAngle (v j ν) V)
    {M : ℝ} (hM : 0 ≤ M)
    (hoverlap : ∀ᵐ y ∂(volume : Measure (Ambient d)),
      (∑ j, (Metric.ball (c j) (2*r)).indicator (fun _ => (1 : ℝ)) y) ≤ M)
    (E₀ : ENNReal) (henergy : (∑ j, ENNReal.ofReal (‖f j‖^2)) ≤ E₀) :
    (∑' σ : Fin m → Bool, ENNReal.ofReal (‖∑ j,
      ∑' ν : {ν // ν ∈ A j ∧ σ ∈ trimmedCellLabels P (a j ν) (v j ν) Ω b w},
        actualPacketInput (c j) r hr (f j) ν.val‖^2)) ≤
      ENNReal.ofReal M * ENNReal.ofReal (H*(K+2)^n) * E₀ := by
  apply actual_labelled_cell_budget c r hr f A
    (fun j ν => trimmedCellLabels P (a j ν) (v j ν) Ω b w) hM hoverlap _ E₀ _ henergy
  intro j ν hν
  have hwitness : ∀ x ∈ Ω, ∃ z ∈ {x | polynomialLevelMap Q x = 0}, dist x z < b ∧
      ‖(LinearMap.ker (fderiv ℝ (polynomialLevelMap Q) z).toLinearMap).starProjection -
        V.starProjection‖ < 2*γ := by
    intro x hx
    obtain ⟨z, hz, _, hn, hg⟩ := plane_region_near_tangent Q cuts V (hregion hx)
    exact ⟨z, hz, hn, hg⟩
  have hh := trimmedCellLabels_card_le_nontangent P _ _ V hK hexternal
    (a j ν) (v j ν) (hv j ν hν) Ω hb hw hwitness (hangle j ν hν)
  exact_mod_cast ENNReal.ofReal_le_ofReal hh

end N2Restriction
#print axioms N2Restriction.actual_far_cell_budget
