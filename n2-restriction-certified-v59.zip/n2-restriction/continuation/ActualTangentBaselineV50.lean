import continuation.ActualTangentEventualNormV50
namespace N2Restriction
open MeasureTheory Set Metric Filter
open scoped ENNReal NNReal

/-- Equation (7.8) at q0=2/(k-1), with the exact borrowed Kakeya exponent
1/(k-1), the same actual Ftan, and a finite scale-independent coefficient. -/
theorem actualTangentSum_baseline_bound {k : ℕ} (hk : 3 ≤ k)
    (P : Fin k → SmoothPatch (k+2)) {ι : ℝ}
    (Dsub : ∀ i, DirectionalSubdivision (P i) ι) (a : ∀ i, Fin (Dsub i).size) (A : (i : Fin k) → PacketGraphAtlas ((fun i => (Dsub i).piece (a i)) i))
    {κ : ℝ} (B : ArticleLocalizationAtlas (fun i => (Dsub i).piece (a i)) κ)
    (V : Fin k → Set (Ambient (k+2))) (m : ℝ)
    (hS : ∀ i, ((fun i => (Dsub i).piece (a i)) i).extendedSurface ∩ V i ⊆ ((fun i => (Dsub i).piece (a i)) i).support) (hm : 0 < m)
    {ε τ lam : ℝ} (hε : 0 < ε)
    (hexternal : B.UniformLocalizedInput (baseline (k : ℝ))) (hτ : 0 < τ) (hτ' : τ < 1/4) (hlam : 1 ≤ lam)
    (C C₀ θ Cext Bcap : ℝ)
    (hC : 1 ≤ C) (hC₀ : 1+Real.sqrt (k+2 : ℕ)*(1+C)/2 ≤ C₀)
    (hθ : 0 < θ) (hBcap : 0 ≤ Bcap)
    (hKak : ∀ r w : ℝ, 1 ≤ w → w < r →
      FiniteDirectionalKakeya (volume.restrict (ball 0 r))
        (fun i => (P i).normal ((Dsub i).anchor (a i))) ι w (1/((k : ℝ)-1))
        (ENNReal.ofReal (Cext*r^(ε*(baseline (k : ℝ)))*w^((k+2 : ℕ)-ε*(baseline (k : ℝ)))))) :
    ∃ K : ENNReal, K ≠ ∞ ∧ ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ R : ℝ, R₀ ≤ R →
    ∀ (Q : (i : Fin k) → (j : Fin (A i).size) →
      CoordinateCapFamily ((A i).patch j).support (R^(-1/2 : ℝ)))
      (hr : 0 < R^(-1/2 : ℝ)), (∀ i, R^(-1/2 : ℝ) ≤ (A i).capRadius) →
    (∀ i j, ((Q i j).centers.card : ℝ) ≤ Bcap*R^(((k+1 : ℕ) : ℝ)/2)) →
    ∀ (g : (i : Fin k) → Lp ℂ 2 ((fun i => (Dsub i).piece (a i)) i).surfaceMeasure)
      (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure),
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
    (∀ i j, HasFrequencySupport ((A i).graph j).surfaceMeasure ((A i).patch j).rotation
      (marginRegion (V i) (m-R^(-1/4 : ℝ))) (f i j)) →
    ∀ (L : ℕ) (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin (k+1) → ℤ))
      (Z : Set (Ambient (k+2))) (T : Ambient (k+2) → Submodule ℝ (Ambient (k+2)))
      (c : Fin L → Ambient (k+2)) (Ω : Set (Ambient (k+2))),
    (∀ l t, l ≠ t → 2*(θ*(R^(1-τ))) ≤ dist (c l) (c t)) →
    MeasurableSet Ω → Ω ⊆ closedBall 0 R →
    (∀ (zgrid : meetingGrid (n := k+2) (lam*R^(1/2+τ)) R) (l : Fin L), ((Ω ∩ ball (c l) (R^(1-τ))) ∩ gridCube (gridCentre (lam*R^(1/2+τ)) zgrid.val) (lam*R^(1/2+τ))).Nonempty →
      HasTerminalCubeFrame (fun i => (Dsub i).piece (a i)) κ Z T (c l) (gridCentre (lam*R^(1/2+τ)) zgrid.val) (R^(1-τ)) (lam*R^(1/2+τ))) →
    positiveNorm
      (actualTangentSum A Q hr f U Z T c (R^(1-τ)) (lam*R^(1/2+τ)) C₀ R (R^(1/2+τ)/10) Ω) (baseline (k : ℝ)) volume ≤
      K*ENNReal.ofReal (R^(-1/2+2*τ+ε))*∏ i, ENNReal.ofReal ‖g i‖ := by
  have hkR : (3 : ℝ) ≤ k := by exact_mod_cast hk
  have hp : 0 < baseline (k : ℝ) := by unfold baseline; apply div_pos <;> linarith
  have hp1 := baseline_le_one hkR
  have he : baseline (k : ℝ)/2 = 1/((k : ℝ)-1) := by unfold baseline; ring
  apply eventually_actualTangentSum_q0_bound P Dsub a A B V m hS hm hp hp1 hε hexternal
    hτ hτ' hlam C C₀ θ Cext Bcap hC hC₀ hθ hBcap
  simpa only [he] using hKak

end N2Restriction
#print axioms N2Restriction.actualTangentSum_baseline_bound
