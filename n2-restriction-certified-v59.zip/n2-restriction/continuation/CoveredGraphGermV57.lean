import N2Restriction.RegularGraphCover
namespace N2Restriction
open Set Filter
set_option maxHeartbeats 1000000

/-- Construct a locally covering full regular graph germ at any point of the extended surface,
retaining both its vertical differential and local coverage of the actual extended surface. -/
theorem SmoothPatch.exists_covered_regular_graph_germ {d : ℕ} (S : SmoothPatch (d+1))
    {x : Ambient (d+1)} (hx : x ∈ S.extendedSurface) :
    ∃ (A : Ambient (d+1) ≃ₗᵢ[ℝ] Ambient (d+1))
      (U : Set (Ambient d)) (φ : Ambient d → ℝ) (u : Ambient d),
      IsOpen U ∧ u ∈ U ∧ ContDiffOn ℝ (⊤ : ℕ∞) φ U ∧
      A (graphPoint u (φ u)) = x ∧
      (∀ y ∈ U, A (graphPoint y (φ y)) ∈ S.extendedSurface) ∧
      fderiv ℝ S.defining x (A (graphPoint (0 : Ambient d) 1)) ≠ 0 ∧
      ∀ᶠ z in nhds x, z ∈ S.extendedSurface →
        z ∈ (fun y => A (graphPoint y (φ y))) '' U := by
  obtain ⟨A,hA⟩ := S.exists_vertical_rotation hx.1
  let f : Ambient (d+1) → ℝ := fun y => S.defining (A y)
  let V := A ⁻¹' S.neighborhood
  have hV : IsOpen V := S.open_neighborhood.preimage A.continuous
  have hf : ContDiffOn ℝ (⊤ : ℕ∞) f V :=
    S.smooth_defining.comp A.contDiff.contDiffOn (fun _ hy => hy)
  have hz : A.symm x ∈ V := by simpa only [V,mem_preimage,A.apply_symm_apply] using hx.1
  obtain ⟨U,φ,hU,hu,hφ,hlevel,hinside,hlocal⟩ := exists_vertical_level_graph hV hf hz hA
  have he : A (graphPoint (graphProjection (A.symm x)) (φ (graphProjection (A.symm x)))) = x := by
    have h := congrArg A (hlocal.self_of_nhds rfl)
    simpa only [A.apply_symm_apply] using h.symm
  refine ⟨A,U,φ,graphProjection (A.symm x),hU,hu,hφ,he,?_,?_,?_⟩
  · intro y hy
    refine ⟨hinside y hy,?_⟩
    simpa only [f,A.apply_symm_apply,hx.2] using hlevel y hy
  · have hd := ((S.smooth_defining.contDiffAt (S.open_neighborhood.mem_nhds hx.1)).differentiableAt
      (by simp)).hasFDerivAt
    have hd' : HasFDerivAt S.defining (fderiv ℝ S.defining x) (A (A.symm x)) := by
      simpa only [A.apply_symm_apply] using hd
    have hcomp := hd'.comp (A.symm x) A.toContinuousLinearMap.hasFDerivAt
    have hder : fderiv ℝ f (A.symm x) = (fderiv ℝ S.defining x).comp A.toContinuousLinearMap :=
      hcomp.fderiv
    change fderiv ℝ f (A.symm x) _ ≠ 0 at hA
    rw [hder] at hA
    exact hA
  · have hp : ∀ᶠ z in nhds x, graphProjection (A.symm z) ∈ U :=
      (graphProjection_lipschitz.continuous.comp A.symm.continuous).continuousAt.preimage_mem_nhds
        (hU.mem_nhds hu)
    have hl := A.symm.continuous.continuousAt.tendsto.eventually hlocal
    filter_upwards [hp,hl] with z hzU hz hsurf
    have hfz : f (A.symm z) = f (A.symm x) := by
      simp only [f,A.apply_symm_apply,hsurf.2,hx.2]
    have hez := congrArg A (hz hfz)
    refine ⟨graphProjection (A.symm z),hzU,?_⟩
    simpa only [A.apply_symm_apply] using hez.symm
end N2Restriction
#print axioms N2Restriction.SmoothPatch.exists_covered_regular_graph_germ
