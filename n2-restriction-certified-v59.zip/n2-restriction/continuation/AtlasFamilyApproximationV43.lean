import continuation.AtlasCellApproximationV42

namespace N2Restriction
open MeasureTheory Set
open scoped BigOperators

/-- Uniformize the actual omission estimate over the finitely many surface
atlases. Both scale and error constants precede the new partition. -/
theorem atlas_family_cell_approximation {d k : ℕ}
    (S : Fin k → SmoothPatch (d+1)) (T : (i : Fin k) → PacketGraphAtlas (S i))
    {τ : ℝ} (hτ : 0 < τ) :
    ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ N : ℝ, ∃ C : ℝ, 0 ≤ C ∧
      ∀ R : ℝ, R₀ ≤ R → ∀ i : Fin k,
      ∀ (Q : (j : Fin (T i).size) → CoordinateCapFamily ((T i).patch j).support (R^(-1/2 : ℝ)))
        (hr : 0 < R^(-1/2 : ℝ)) (_hsmall : R^(-1/2 : ℝ) ≤ (T i).capRadius) (B : ℝ), 0 ≤ B →
      (∀ j, ((Q j).centers.card : ℝ) ≤ B*R^((d : ℝ)/2)) →
      ∀ (f : (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure)
        (g : Lp ℂ 2 (S i).surfaceMeasure), (∑ j, ‖f j‖^2) ≤ ‖g‖^2 →
      ∀ {m : ℕ} (P : Fin m → MvPolynomial (Fin (d+1)) ℝ)
        (Ω : Set (Ambient (d+1))) (σ : Fin m → Bool) (b : ℝ)
        (A : (j : Fin (T i).size) → (Q j).centers → Set (Fin d → ℤ))
        (x : Ambient (d+1)), ‖x‖ ≤ R → x ∈ Ω →
      (∀ z, ambientPolynomial (∏ l, P l) z = 0 → b ≤ dist x z) →
      x ∈ PolynomialSignRegion P σ →
      ‖extension (Measure.hausdorffMeasure (d : ℝ)) id ((T i).cellInput Q hr f A) x -
        extension (Measure.hausdorffMeasure (d : ℝ)) id
          ((T i).cellInput Q hr f (fun j a => {ν | ν ∈ A j a ∧
            σ ∈ trimmedCellLabels P ((T i).cellAxisPoint j (R^(-1/2 : ℝ)) ν)
              ((T i).cellAxisDirection j a.val) Ω b (R^(1/2+τ)/10)})) x‖ ≤
        C*Real.sqrt B*R^(-N)*‖g‖ := by
  classical
  choose R₀ hR₀ ht using fun i => (T i).cell_restriction_rapid_approximation hτ
  let Rstar := 1 + ∑ i, R₀ i
  have hR0 i : 0 ≤ R₀ i := zero_le_one.trans (hR₀ i)
  have hiR i : R₀ i ≤ Rstar :=
    (Finset.single_le_sum (fun j _ => hR0 j) (Finset.mem_univ i)).trans
      (le_add_of_nonneg_left zero_le_one)
  refine ⟨Rstar, le_add_of_nonneg_right (Finset.sum_nonneg (fun i _ => hR0 i)), fun N => ?_⟩
  choose C hC hc using fun i => ht i N
  let Cstar := ∑ i, C i
  have hiC i : C i ≤ Cstar := Finset.single_le_sum (fun j _ => hC j) (Finset.mem_univ i)
  refine ⟨Cstar, Finset.sum_nonneg (fun i _ => hC i), ?_⟩
  intro R hR i Q hr hsmall B hB hcount f g he m P Ω σ b A x hx hΩ htrim hsign
  exact (hc i R ((hiR i).trans hR) Q hr hsmall B hB hcount f g he P Ω σ b A x hx hΩ htrim hsign).trans
    (mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_right (hiC i) (Real.sqrt_nonneg B)) (Real.rpow_nonneg (by linarith [hR0 i, hiR i]) _))
      (norm_nonneg g))

end N2Restriction
#print axioms N2Restriction.atlas_family_cell_approximation
