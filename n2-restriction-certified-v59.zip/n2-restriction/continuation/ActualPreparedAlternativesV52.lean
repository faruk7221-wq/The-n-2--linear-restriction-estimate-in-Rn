import continuation.SelectedReferenceFeasibilityV51
import continuation.AtlasMassFeasibleCountsV45
import continuation.PolynomialStageBudgetV51
namespace N2Restriction
open Set Metric MeasureTheory
open scoped ENNReal

/-- Classify the actual polynomial stage using its true dimension and the
same initial reference-rank subdivision. A zero selected integral is discharged
as M0<=err, rather than an additional geometric or nonemptiness assumption. -/
theorem actual_prepared_stage_alternatives {k m : ℕ} (hk : 3 ≤ k)
    (P : Fin k → SmoothPatch (k+2)) {ι γ r : ℝ} (hι : 0 < ι) (hγ : γ ≤ ι/2)
    (D : (i : Fin k) → DirectionalSubdivision (P i) ι) (b : (i : Fin k) → Fin (D i).size)
    (T : (i : Fin k) → PacketGraphAtlas ((D i).piece (b i)))
    (hrank : ∀ (V : Submodule ℝ (Ambient (k+2))) (near : Finset (Fin k)),
      (∀ i ∈ near, directionPlaneAngle ((P i).normal ((D i).anchor (b i))) V ≤ 4*ι) →
      k ≤ Module.finrank ℝ V+nearᶜ.card)
    (hr : 0 < r)
    (Q : (i : Fin k) → (j : Fin (T i).size) → CoordinateCapFamily ((T i).patch j).support r)
    (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure)
    (U : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin (k+1) → ℤ))
    {p R width : ℝ} {M₀ err : ENNReal} (hp : 0 < p) (hpc : critical k < p)
    (W : PolynomialStage (fun _ => Measure.hausdorffMeasure ((k+1 : ℕ) : ℝ))
      (fun i => (T i).cellInput (Q i) hr (f i) (U i)) p R width M₀ err m)
    (V : Submodule ℝ (Ambient (k+2))) (hd : Module.finrank ℝ V = (k+2)-m)
    (near : Finset (Fin k))
    (hnear : ∀ i ∈ near, ∀ j a ν, ν ∈ U i j a →
      directionPlaneAngle ((T i).cellAxisDirection j a.val) V ≤ 4*γ) :
    M₀ ≤ err ∨
    ((∀ i ∈ near, directionPlaneAngle ((P i).normal ((D i).anchor (b i))) V ≤ 4*ι) ∧
      ((k+2)-m = 0 ∨
       (1 ≤ (k+2)-m ∧ (k+2)-m ≤ k ∧ (k+2)-m+nearᶜ.card = k) ∨
       (k+1 ≤ (k+2)-m+nearᶜ.card ∧ cellular k (((k+2)-m : ℕ) : ℝ) nearᶜ.card p < 0))) := by
  classical
  by_cases hz : (∫⁻ x in W.region, ‖extensionProduct (fun _ => Measure.hausdorffMeasure ((k+1 : ℕ) : ℝ))
      (fun _ => id) (fun i => (T i).cellInput (Q i) hr (f i) (U i)) x‖ₑ^p) = 0
  · left
    simpa only [hz,mul_zero,zero_add] using W.mass_bound
  right
  have hn := atlas_nonzero_mass_nonempty_selection (fun i => (D i).piece (b i)) T hr Q f U W.region hp hz
  have href := selected_packet_reference_near P hι hγ D b T Q U V near (fun i _ => hn i) hnear
  refine ⟨href,?_⟩
  have hf := hrank V near href
  rw [hd] at hf
  by_cases h0 : (k+2)-m = 0
  · exact Or.inl h0
  by_cases ht : (k+2)-m+nearᶜ.card = k
  · exact Or.inr (Or.inl ⟨by omega,by omega,ht⟩)
  · have hgap : k+1 ≤ (k+2)-m+nearᶜ.card := by omega
    exact Or.inr (Or.inr ⟨hgap,nonterminal_cellular_negative hk (by omega) (by omega) hgap hpc⟩)

end N2Restriction
#print axioms N2Restriction.actual_prepared_stage_alternatives
