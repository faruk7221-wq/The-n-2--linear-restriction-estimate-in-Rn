import continuation.CurvedOscillatoryHalfDecayV56
import Mathlib.MeasureTheory.Integral.Prod
namespace N2Restriction
open Set MeasureTheory
set_option maxHeartbeats 1000000

/-- Apply the proved curved estimate to every fiber and then integrate the
remaining chart parameters. The hypothesis is integrability of the actual
amplitude, not an assumed oscillatory-decay estimate. -/
theorem curved_fubini_half_decay {Y : Type*} [MeasurableSpace Y]
    (μ : Measure Y) [SFinite μ] (A : Y → ℝ → ℂ) (φ : Y → ℝ → ℝ)
    (hA : ∀ y, ContDiff ℝ 1 (A y)) (hφ : ∀ y, ContDiff ℝ 2 (φ y))
    (a b freq : ℝ) (hab : a ≤ b) (hf : 0 < freq) {c : ℝ} (hc : 0 < c)
    (M N : Y → ℝ) (hM : ∀ y, 0 ≤ M y)
    (hcurved : ∀ y t, t ∈ Icc a b → c ≤ |deriv (deriv (φ y)) t|)
    (hAt : ∀ y t, t ∈ Icc a b → ‖A y t‖ ≤ M y)
    (hN : ∀ y, (∫ t in a..b, ‖deriv (A y) t‖) ≤ N y)
    (hbudget : Integrable (fun y => ((2+2*Real.pi)*M y+N y)/Real.sqrt c) μ)
    (hactual : Integrable (fun p : Y × ℝ => A p.1 p.2 * phaseExponential freq (φ p.1) p.2)
      (μ.prod (volume.restrict (Ioc a b)))) :
    ‖∫ p : Y × ℝ, A p.1 p.2 * phaseExponential freq (φ p.1) p.2
        ∂(μ.prod (volume.restrict (Ioc a b)))‖ ≤
      (∫ y, ((2+2*Real.pi)*M y+N y)/Real.sqrt c ∂μ)*freq^(-(1/2 : ℝ)) := by
  rw [integral_prod _ hactual]
  calc
    _ ≤ ∫ y, (((2+2*Real.pi)*M y+N y)/Real.sqrt c)*freq^(-(1/2 : ℝ)) ∂μ := by
      apply norm_integral_le_of_norm_le (hbudget.mul_const _)
      apply Filter.Eventually.of_forall
      intro y
      have h := curved_oscillatory_half_decay (A y) (hA y) (φ y) (hφ y)
        a b freq hab hf hc (hM y) (hcurved y) (hAt y)
      rw [intervalIntegral.integral_of_le hab] at h
      exact h.trans (mul_le_mul_of_nonneg_right
        (div_le_div_of_nonneg_right (add_le_add_left (hN y) _) (Real.sqrt_nonneg _))
        (Real.rpow_nonneg hf.le _))
    _ = _ := integral_mul_const _ _
end N2Restriction
#print axioms N2Restriction.curved_fubini_half_decay
