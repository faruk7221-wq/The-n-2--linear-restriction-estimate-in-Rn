import continuation.ActualTangentCubeSumV49
import continuation.GridIntegralAssemblyV49

namespace N2Restriction
open MeasureTheory Set Metric Filter
open scoped ENNReal NNReal

/-- Sum the actual Ftan estimate over the finite lattice meeting the physical
ball. The same positive Ftan is retained, and the rapid error is charged to
one enlarged physical-ball volume. -/
theorem actualTangentSum_grid_integral {k : ℕ}
    (S : Fin k → SmoothPatch (k+2)) (A : (i : Fin k) → PacketGraphAtlas (S i))
    {κ : ℝ} (B : ArticleLocalizationAtlas S κ)
    (V : Fin k → Set (Ambient (k+2))) (m : ℝ)
    (hS : ∀ i, (S i).extendedSurface ∩ V i ⊆ (S i).support) (hm : 0 < m)
    {p ε τ lam : ℝ} (hp : 0 < p) (hp1 : p ≤ 1) (hε : 0 < ε)
    (hexternal : B.UniformLocalizedInput p) (hτ : 0 < τ) (hτ' : τ < 1/4) (hlam : 0 < lam) :
    ∃ D : ℝ≥0, ∃ H M R₀ : ℝ, 0 ≤ H ∧ 1 ≤ M ∧ 1 ≤ R₀ ∧
    ∀ N : ℝ, ∃ Cerr : ℝ, 0 ≤ Cerr ∧ ∀ R : ℝ, R₀ ≤ R →
    ∀ (Q : (i : Fin k) → (j : Fin (A i).size) →
      CoordinateCapFamily ((A i).patch j).support (R^(-1/2 : ℝ)))
      (hr : 0 < R^(-1/2 : ℝ)), (∀ i, R^(-1/2 : ℝ) ≤ (A i).capRadius) →
    ∀ Bcap : ℝ, 0 ≤ Bcap →
    (∀ i j, ((Q i j).centers.card : ℝ) ≤ Bcap*R^(((k+1 : ℕ) : ℝ)/2)) →
    ∀ (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure)
      (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure),
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
    (∀ i j, HasFrequencySupport ((A i).graph j).surfaceMeasure ((A i).patch j).rotation
      (marginRegion (V i) (m-R^(-1/4 : ℝ))) (f i j)) →
    ∀ (L : ℕ) (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin (k+1) → ℤ))
      (Z : Set (Ambient (k+2))) (T : Ambient (k+2) → Submodule ℝ (Ambient (k+2)))
      (c : Fin L → Ambient (k+2)) (C C₀ θ : ℝ) (Ω : Set (Ambient (k+2))),
    1 ≤ C → 1+Real.sqrt (k+2 : ℕ)*(1+C)/2 ≤ C₀ → 0 < θ →
    (∀ l t, l ≠ t → 2*(θ*(R^(1-τ))) ≤ dist (c l) (c t)) →
    MeasurableSet Ω → Ω ⊆ closedBall 0 R →
    (∀ (zgrid : meetingGrid (n := k+2) (lam*R^(1/2+τ)) R) (l : Fin L), ((Ω ∩ ball (c l) (R^(1-τ))) ∩ gridCube (gridCentre (lam*R^(1/2+τ)) zgrid.val) (lam*R^(1/2+τ))).Nonempty →
      HasTerminalCubeFrame S κ Z T (c l) (gridCentre (lam*R^(1/2+τ)) zgrid.val) (R^(1-τ)) (lam*R^(1/2+τ))) →
    (∫⁻ y,
      (actualTangentSum A Q hr f U Z T c (R^(1-τ)) (lam*R^(1/2+τ)) C₀ R (R^(1/2+τ)/10) Ω y)^p) ≤
      ENNReal.ofReal (((1+Real.sqrt (k+2 : ℕ)/2)/θ+1)^(k+2)) * ((2^k : ENNReal) *
        (((((D : ENNReal)*ENNReal.ofReal (((1+Real.sqrt (k+2 : ℕ))*(lam*R^(1/2+τ)))^ε))^p *
          (ENNReal.ofReal (lam*R^(-1/2+2*τ)))^p) *
          ((ENNReal.ofReal H)^(p/2) *
            (∑' zgrid : meetingGrid (n := k+2) (lam*R^(1/2+τ)) R,
              (∏ i, (A i).cubeEnergy (Q i) hr (f i) R (R^(1/2+τ)/10) C (lam*R^(1/2+τ))
                (gridCentre (lam*R^(1/2+τ)) zgrid.val))^(p/2)))) +
        (ENNReal.ofReal ((k : ℝ)*(Cerr*Real.sqrt Bcap*R^(-N))*M^k*∏ i, ‖g i‖))^p*
          volume (closedBall (0 : Ambient (k+2)) (R+Real.sqrt (k+2 : ℕ)*(lam*R^(1/2+τ)))))) := by
  obtain ⟨D,H,M,R₀,hH,hM,hR₀,ht⟩ := actualTangentSum_cube_integral S A B V m hS hm hp hp1 hε hexternal hτ hτ' hlam
  refine ⟨D,H,M,R₀,hH,hM,hR₀,fun N => ?_⟩
  obtain ⟨Cerr,hCerr,hc⟩ := ht N
  refine ⟨Cerr,hCerr,?_⟩
  intro R hR Q hr hsmall Bcap hBcap hcount g f he hf L U Z T c C C₀ θ Ω hC hC₀ hθ hsep hΩ hΩR hframe
  have hRpos : 0 < R := zero_lt_one.trans_le (hR₀.trans hR)
  have hb : 0 < lam*R^(1/2+τ) := mul_pos hlam (Real.rpow_pos_of_pos hRpos _)
  let O : ENNReal := ENNReal.ofReal (((1+Real.sqrt (k+2 : ℕ)/2)/θ+1)^(k+2))*(2^k : ENNReal)
  let J : ENNReal := (((D : ENNReal)*ENNReal.ofReal (((1+Real.sqrt (k+2 : ℕ))*(lam*R^(1/2+τ)))^ε))^p *
    (ENNReal.ofReal (lam*R^(-1/2+2*τ)))^p)*(ENNReal.ofReal H)^(p/2)
  let err : ENNReal := (ENNReal.ofReal ((k : ℝ)*(Cerr*Real.sqrt Bcap*R^(-N))*M^k*∏ i, ‖g i‖))^p
  have hh := grid_integral_of_cube_bounds hb hp
    (actualTangentSum A Q hr f U Z T c (R^(1-τ)) (lam*R^(1/2+τ)) C₀ R (R^(1/2+τ)/10) Ω)
    (fun x hx => by
      unfold actualTangentSum
      apply Finset.sum_eq_zero
      intro l _
      exact indicator_of_notMem (fun h => hx (hΩR h.1)) _)
    (fun zgrid => (∏ i, (A i).cubeEnergy (Q i) hr (f i) R (R^(1/2+τ)/10) C (lam*R^(1/2+τ))
      (gridCentre (lam*R^(1/2+τ)) zgrid.val))^(p/2)) (O*J) (O*err)
    (fun zgrid => (hc R hR Q hr hsmall Bcap hBcap hcount g f he hf L U Z T c C C₀ θ Ω
      (gridCentre (lam*R^(1/2+τ)) zgrid.val) hC hC₀ hθ hsep hΩ hΩR (hframe zgrid)).trans_eq (by dsimp [O,J,err]; ring))
  apply hh.trans_eq
  dsimp [O,J,err]
  ring

end N2Restriction
#print axioms N2Restriction.actualTangentSum_grid_integral
