import continuation.AtlasProductAssemblyV26

set_option maxHeartbeats 800000

namespace N2Restriction
open MeasureTheory Set
open scoped ENNReal BigOperators

section
variable {k n : ℕ} (μ : Fin k → Measure (Ambient n))
  (S : Fin k → Set (Ambient n)) (hS : ∀ i, MeasurableSet (S i))
  (m : Fin k → ℕ) (K : ∀ i, Fin (m i) → Set (Ambient n))
  (hK : ∀ i j, MeasurableSet (K i j)) (hcover : ∀ i, S i ⊆ ⋃ j, K i j)
  [∀ i, IsFiniteMeasure ((μ i).restrict (S i))]
  (g : ∀ i, Lp ℂ 2 ((μ i).restrict (S i)))

include hcover

/-- Chartwise quasi-norm estimates assemble with the original input norms.
This is the quasi-norm form of the finite atlas step, for every p>0. -/
theorem atlas_assemble_quasinorm_estimates (σ : Measure (Ambient n)) {p : ℝ} (hp : 0 < p)
    (C : (∀ i, Fin (m i)) → ℝ≥0∞)
    (hC : ∀ a : (∀ i, Fin (m i)), eLpNorm' (fun x => ∏ i, extension ((μ i).restrict (K i (a i))) id
        (atlasPatchInput (μ i) (S i) (hS i) (K i) (hK i) (g i) (a i)) x) p σ ≤
        C a * ∏ i, ‖atlasPatchInput (μ i) (S i) (hS i) (K i) (hK i) (g i) (a i)‖ₑ) :
    eLpNorm' (fun x => ∏ i, extension ((μ i).restrict (S i)) id (g i) x) p σ ≤
      (finitePowerLoss (Fintype.card (∀ i, Fin (m i))) p * ∑ a, C a ^ p) ^ (1 / p) *
        ∏ i, ‖g i‖ₑ := by
  have hpow : ∀ a, (∫⁻ x, ‖∏ i, extension ((μ i).restrict (K i (a i))) id
        (atlasPatchInput (μ i) (S i) (hS i) (K i) (hK i) (g i) (a i)) x‖ₑ ^ p ∂σ) ≤
        C a ^ p * ∏ i, ‖atlasPatchInput (μ i) (S i) (hS i) (K i) (hK i) (g i) (a i)‖ₑ ^ p := by
    intro a
    have hh := ENNReal.rpow_le_rpow (hC a) hp.le
    simpa only [eLpNorm'_eq_lintegral_enorm, ← ENNReal.rpow_mul,
      one_div_mul_cancel hp.ne', ENNReal.rpow_one,
      ENNReal.mul_rpow_of_nonneg _ _ hp.le, ENNReal.prod_rpow_of_nonneg hp.le] using hh
  have hh := ENNReal.rpow_le_rpow
    (atlas_assemble_local_estimates μ S hS m K hK hcover g σ hp (fun a => C a ^ p) hpow)
    (by positivity : 0 ≤ 1 / p)
  simpa only [eLpNorm'_eq_lintegral_enorm,
    ENNReal.mul_rpow_of_nonneg _ _ (by positivity : 0 ≤ 1 / p),
    ← ENNReal.prod_rpow_of_nonneg (by positivity : 0 ≤ 1 / p),
    ← ENNReal.rpow_mul, mul_one_div_cancel hp.ne', ENNReal.rpow_one] using hh

/-- A common local constant costs only the explicit finite chart-count factor
in the original surface quasi-norm estimate. -/
theorem atlas_assemble_uniform_quasinorm_bound (σ : Measure (Ambient n)) {p : ℝ} (hp : 0 < p)
    (C : ℝ≥0∞)
    (hC : ∀ a : (∀ i, Fin (m i)), eLpNorm' (fun x => ∏ i, extension ((μ i).restrict (K i (a i))) id
        (atlasPatchInput (μ i) (S i) (hS i) (K i) (hK i) (g i) (a i)) x) p σ ≤
        C * ∏ i, ‖atlasPatchInput (μ i) (S i) (hS i) (K i) (hK i) (g i) (a i)‖ₑ) :
    eLpNorm' (fun x => ∏ i, extension ((μ i).restrict (S i)) id (g i) x) p σ ≤
      ((finitePowerLoss (Fintype.card (∀ i, Fin (m i))) p *
        (Fintype.card (∀ i, Fin (m i)) : ℝ≥0∞)) ^ (1 / p) * C) * ∏ i, ‖g i‖ₑ := by
  have hh := atlas_assemble_quasinorm_estimates μ S hS m K hK hcover g σ hp (fun _ => C) hC
  simpa only [Finset.sum_const, Finset.card_univ, nsmul_eq_mul, ← mul_assoc,
    ENNReal.mul_rpow_of_nonneg _ _ (by positivity : 0 ≤ 1 / p),
    ← ENNReal.rpow_mul, mul_one_div_cancel hp.ne', ENNReal.rpow_one] using hh

end
end N2Restriction

#print axioms N2Restriction.atlas_assemble_quasinorm_estimates
#print axioms N2Restriction.atlas_assemble_uniform_quasinorm_bound
