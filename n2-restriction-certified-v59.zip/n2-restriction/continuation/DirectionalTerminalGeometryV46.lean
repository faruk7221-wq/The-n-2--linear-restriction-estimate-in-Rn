import continuation.ReferencePlaneGeometryV46
import continuation.DirectionalSubdivisionV22

namespace N2Restriction
open Set

/-- Choose the small frequency patches after a uniform reference-plane
tolerance is fixed. All tuples in each full open patch neighborhood then
satisfy the plane-closeness assertion in Lemma 7.2. -/
theorem exists_terminal_directional_subdivision {k : ℕ}
    (S : Fin k → SmoothPatch (k+2)) {ν κ δ : ℝ}
    (hgeo : GeometricHypotheses S ν κ) (hδ : 0 < δ) :
    ∃ γ : ℝ, 0 < γ ∧ ∃ D : (i : Fin k) → DirectionalSubdivision (S i) γ,
      ∀ (j : (i : Fin k) → Fin (D i).size)
        (V₀ V : Submodule ℝ (Ambient (k+2))) (near : Finset (Fin k)),
      ‖V₀.starProjection - V.starProjection‖ < 2*γ →
      (∀ i ∈ near, directionPlaneAngle ((S i).normal ((D i).anchor (j i))) V₀ ≤ 4*γ) →
      Module.finrank ℝ V + nearᶜ.card = k →
      let v := fun i => (S i).normal ((D i).anchor (j i))
      let H := (V ⊔ Submodule.span ℝ (v '' (↑nearᶜ : Set (Fin k))))ᗮ
      Module.finrank ℝ H = 2 ∧
      ∀ z : Fin k → Ambient (k+2), (∀ i, z i ∈ ((D i).piece (j i)).neighborhood) →
        ‖H.starProjection - (commonTangent (fun i => ((D i).piece (j i)).normal (z i))).starProjection‖ < δ := by
  classical
  let K := Set.univ.pi (fun i => (S i).support)
  let N := fun (z : Fin k → Ambient (k+2)) i => (S i).normal (z i)
  have hK : IsCompact K := by
    simpa only [K, Set.pi, Set.mem_univ, forall_const] using
      isCompact_pi_infinite (fun i => (S i).compact_support)
  have hN : ContinuousOn N K := by
    apply continuousOn_pi.mpr
    intro i
    exact ((S i).smooth_normal.continuousOn.mono (S i).support_inside).comp
      (continuous_apply i).continuousOn (fun z hz => hz i (mem_univ i))
  have hi : ∀ v ∈ N '' K, LinearIndependent ℝ v := by
    rintro v ⟨z,hz,rfl⟩
    apply normals_independent_of_gram
    apply ne_of_gt
    apply (sq_pos_of_pos hgeo.1).trans_le
    exact (hgeo.2.2 z (fun i => ⟨(S i).support_inside (hz i (mem_univ i)),
      (S i).support_on_surface _ (hz i (mem_univ i))⟩)).1
  obtain ⟨γ,hγ,hplane⟩ := compact_terminal_plane_geometry (N '' K)
    (hK.image_of_continuousOn hN) hi hδ
  let D := fun i => Classical.choice ((S i).exists_directionalSubdivision hγ)
  refine ⟨γ,hγ,D,?_⟩
  intro j V₀ V near hgap hangle hterminal
  let a := fun i => (D i).anchor (j i)
  have ha : a ∈ K := fun i _ => (D i).anchor_mem (j i)
  obtain ⟨hd,hclose⟩ := hplane (N a) ⟨a,ha,rfl⟩
    (fun i => (D i).reference_unit (j i)) V₀ V near hgap hangle hterminal
  refine ⟨hd,?_⟩
  intro z hz
  apply hclose
  apply (dist_pi_lt_iff hγ).mpr
  intro i
  exact (D i).normal_close (j i) (z i) (hz i)

end N2Restriction
#print axioms N2Restriction.exists_terminal_directional_subdivision
