import continuation.AtlasOriginalChildMarginV44

namespace N2Restriction
open MeasureTheory Set

/-- A single threshold works for all surfaces, inputs, child radii and original
packet selections in the multilinear family. -/
theorem eventually_atlas_cell_admissible {d k : ℕ} (S : Fin k → SmoothPatch (d+1))
    (T : (i : Fin k) → PacketGraphAtlas (S i))
    (V : Fin k → Set (Ambient (d+1))) (m : ℝ) :
    ∀ᶠ R : ℝ in Filter.atTop, ∀ L : ℝ, 1 ≤ L → L ≤ R / 2 →
      ∀ (Q : (i : Fin k) → (j : Fin (T i).size) →
        CoordinateCapFamily ((T i).patch j).support (R ^ (-1 / 2 : ℝ)))
      (hr : 0 < R ^ (-1 / 2 : ℝ))
      (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure),
      (∀ i j, HasFrequencySupport ((T i).graph j).surfaceMeasure ((T i).patch j).rotation
        (marginRegion (V i) (m - R ^ (-1 / 4 : ℝ))) (f i j)) →
      ∀ (U : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ)),
      MarginAdmissible (fun i => (T i).bufferMeasure) (fun _ => id) V m L
        (fun i => (T i).bufferInput ((T i).cellInput (Q i) hr (f i) (U i))) := by
  filter_upwards [Filter.eventually_all.mpr
    (fun i => (T i).eventually_cellInput_child_margin (V i) m)] with R hR
  intro L hL hLR Q hr f hf U i
  exact (T i).bufferInput_frequency_support _ _ (hR i L hL hLR (Q i) hr (f i) (hf i) (U i))

end N2Restriction
#print axioms N2Restriction.eventually_atlas_cell_admissible
