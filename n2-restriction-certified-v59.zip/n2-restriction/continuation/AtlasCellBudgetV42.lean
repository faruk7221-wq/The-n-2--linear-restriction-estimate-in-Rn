import continuation.FiniteAtlasCellEnergyV42

namespace N2Restriction
open MeasureTheory
open scoped BigOperators ENNReal

/-- The fixed density/overlap loss for one graph chart. -/
noncomputable def SurfaceGraphChart.cellEnergyConstant {d : ℕ} (G : SurfaceGraphChart d) : ℝ :=
  (1 / G.density.lower) * (9^d : ℝ) * G.density.upper

theorem SurfaceGraphChart.cellEnergyConstant_nonneg {d : ℕ} (G : SurfaceGraphChart d) :
    0 ≤ G.cellEnergyConstant := by
  unfold cellEnergyConstant
  have := G.density.lower_pos
  have := G.density.upper_nonneg
  positivity

/-- Isometric rotation and zero extension preserve the actual chart cell budget. -/
theorem SurfaceGraphChart.rotated_cell_energy_budget {d : ℕ} {C : Type*}
    (G : SurfaceGraphChart d) (A : Ambient (d+1) ≃ₗᵢ[ℝ] Ambient (d+1))
    {K : Set (Ambient d)} {r : ℝ} (P : CoordinateCapFamily K r) (hr : 0 < r)
    (g : Lp ℂ 2 G.surfaceMeasure) (U : C → P.centers → Set (Fin d → ℤ)) (N : ENNReal)
    (hincidence : ∀ j ν, (∑' c, (U c j).indicator (fun _ => (1 : ENNReal)) ν) ≤ N) :
    (∑' c, ENNReal.ofReal (‖∑ j, ∑' ν : U c j,
      G.rotatedAmbientInput A (G.packet P hr g j ν.val)‖^2)) ≤
      ENNReal.ofReal G.cellEnergyConstant * N * ENNReal.ofReal (‖g‖^2) := by
  simp_rw [← G.rotated_selected_sum, LinearIsometry.norm_map]
  have h := G.cell_energy_budget P hr g U N hincidence
  apply h.trans_eq
  unfold cellEnergyConstant
  rw [ENNReal.ofReal_mul (mul_nonneg (one_div_pos.mpr G.density.lower_pos).le (by positivity)),
    ENNReal.ofReal_mul (one_div_pos.mpr G.density.lower_pos).le]
  ac_rfl

/-- A single scale-independent atlas constant bounds all selected cell inputs.
The only combinatorial hypothesis is incidence of each actual packet in the cells. -/
theorem PacketGraphAtlas.cell_energy_budget {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) :
    ∃ B : ℝ, 0 ≤ B ∧ ∀ {C : Type*} {r : ℝ}
      (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r) (hr : 0 < r)
      (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
      (U : C → (j : Fin T.size) → (Q j).centers → Set (Fin d → ℤ)) (N : ENNReal),
      (∀ j a ν, (∑' c, (U c j a).indicator (fun _ => (1 : ENNReal)) ν) ≤ N) →
      (∑' c, ENNReal.ofReal (‖∑ j, ∑ a, ∑' ν : U c j a,
        (T.graph j).rotatedAmbientInput (T.patch j).rotation
          ((T.graph j).packet (Q j) hr (f j) a ν.val)‖^2)) ≤
        ENNReal.ofReal B * N * ENNReal.ofReal (∑ j, ‖f j‖^2) := by
  classical
  let D := ∑ j, (T.graph j).cellEnergyConstant
  have hD : 0 ≤ D := Finset.sum_nonneg (fun j _ => (T.graph j).cellEnergyConstant_nonneg)
  refine ⟨T.size * D, mul_nonneg (Nat.cast_nonneg _) hD, ?_⟩
  intro C r Q hr f U N hincidence
  have hbound j := (T.graph j).rotated_cell_energy_budget (T.patch j).rotation
    (Q j) hr (f j) (fun c => U c j) N (hincidence j)
  have hle j : (T.graph j).cellEnergyConstant ≤ D :=
    Finset.single_le_sum (fun k _ => (T.graph k).cellEnergyConstant_nonneg) (Finset.mem_univ j)
  have h := finite_atlas_cell_energy
    (fun c j => ∑ a, ∑' ν : U c j a,
      (T.graph j).rotatedAmbientInput (T.patch j).rotation ((T.graph j).packet (Q j) hr (f j) a ν.val))
    (fun j => ENNReal.ofReal D * N * ENNReal.ofReal (‖f j‖^2))
    (fun j => (hbound j).trans (mul_le_mul_right' (mul_le_mul_right'
      (ENNReal.ofReal_le_ofReal (hle j)) N) _))
  convert h using 1
  rw [← Finset.mul_sum, ← ENNReal.ofReal_sum_of_nonneg (fun j _ => sq_nonneg ‖f j‖),
    ENNReal.ofReal_mul (Nat.cast_nonneg T.size), ENNReal.ofReal_natCast]
  ring

end N2Restriction
#print axioms N2Restriction.SurfaceGraphChart.cellEnergyConstant_nonneg
#print axioms N2Restriction.SurfaceGraphChart.rotated_cell_energy_budget
#print axioms N2Restriction.PacketGraphAtlas.cell_energy_budget
