import continuation.ActualTangentSumV48
import continuation.AtlasProductMajorantV48
import continuation.PositiveBallOverlapV48

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal

/-- Equation (7.10) for the actual positive tangent sum, uniformly in the
physical scale, variety, ball family and retained original-packet selection. -/
theorem actualTangentSum_uniform_bound {d k : ℕ}
    (S : Fin k → SmoothPatch (d+1)) (A : (i : Fin k) → PacketGraphAtlas (S i))
    {θ : ℝ} (hθ : 0 < θ) :
    ∃ D : ℝ, 0 ≤ D ∧ ∀ {r : ℝ}
    (Q : (i : Fin k) → (j : Fin (A i).size) → CoordinateCapFamily ((A i).patch j).support r)
    (hr : 0 < r), (∀ i, r ≤ (A i).capRadius) →
    ∀ (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure)
    (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure),
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
    ∀ {L : ℕ} (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin d → ℤ))
    (Z : Set (Ambient (d+1))) (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1)))
    (c : Fin L → Ambient (d+1)) (ρ b C₀ R w : ℝ) (Ω : Set (Ambient (d+1)))
    , 0 < ρ → (∀ l t, l ≠ t → 2*(θ*ρ) ≤ dist (c l) (c t)) →
    ∀ x, actualTangentSum A Q hr f U Z T c ρ b C₀ R w Ω x ≤
      ENNReal.ofReal D * ∏ i, ENNReal.ofReal ‖g i‖ := by
  obtain ⟨C,hC,hprod⟩ := atlas_selected_product_majorant S A
  let O := (1/θ+1)^(d+1)
  have hO : 0 ≤ O := by dsimp [O]; positivity
  have htwo : 0 ≤ (2 : ℝ)^k := by positivity
  refine ⟨O*(2 : ℝ)^k*C,mul_nonneg (mul_nonneg hO htwo) (zero_le_one.trans hC),?_⟩
  intro r Q hr hsmall g f he L U Z T c ρ b C₀ R w Ω hρ hsep x
  have hh := positive_ball_sum_bound hρ hθ c hsep Ω
    (fun l y => ∑ σ ∈ (Finset.univ : Finset (Fin k → Bool)).erase (fun _ => false),
      ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
        (fun i => (A i).cellInput (Q i) hr (f i)
          (if σ i then (A i).actualTangentSelection (Q i) (U i) Z T (c l) ρ b C₀ R w Ω
           else (A i).actualNontangentSelection (Q i) (U i) Z T (c l) ρ b C₀ R w Ω)) y‖ₑ)
    ((2^k : ENNReal)*(ENNReal.ofReal C*∏ i, ENNReal.ofReal ‖g i‖))
    (fun l y => binary_nonzero_sum_bound _ _ (fun σ => hprod Q hr hsmall g f he _ y)) x
  rw [ENNReal.ofReal_mul (mul_nonneg hO htwo),ENNReal.ofReal_mul hO,
    ENNReal.ofReal_pow (by norm_num : (0 : ℝ) ≤ 2)]
  simpa only [actualTangentSum,ENNReal.ofReal_ofNat,mul_assoc] using hh

end N2Restriction
#print axioms N2Restriction.actualTangentSum_uniform_bound
