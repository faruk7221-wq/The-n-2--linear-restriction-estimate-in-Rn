import continuation.UniformNonwallDegreeV45
import continuation.PolynomialStageBudgetV51
namespace N2Restriction
open scoped BigOperators ENNReal

/-- Instantiate the finite-case degree choice with the actual coefficient
of the new one-partition theorem. All quantities here are old bounds fixed
before D and before the radius or selected polynomial coefficients. -/
theorem concrete_partition_contracting_degree {k n : ℕ} {p c : ℝ}
    (hk : 3 ≤ k) (hp : critical k < p) (hc : 0 < c)
    (Bstage : PolynomialStageBudget) (B₀ : Fin k → ℝ)
    (Hgeom : ℕ) (Kgeom E c₀ c₁ : ℝ) (q : Finset (Ambient n)) :
    let Ec := fun i => ((2*E*((k : ℝ)+1)/(1/2))/c₀ * B₀ i * max 2 (max 1 ((Hgeom : ℝ)*(Kgeom+2)^n)))
    ∃ D : ℕ, 1 ≤ D ∧ ∀ (s : Fin (k+3)) (t : Fin (k+1)),
      1 ≤ s.val → k+1 ≤ s.val+t.val →
      (Bstage.mass*ENNReal.ofReal (2*c₁/(1/2))*(q.card : ENNReal)) *
        ENNReal.ofReal ((∏ i, Ec i)^(p/2)*(D : ℝ)^(cellular k s.val t.val p)) < ENNReal.ofReal c := by
  dsimp only
  exact uniform_nonwall_contracting_degree hk hp hc
    (fun _ _ => Bstage.mass) (fun _ _ => ENNReal.ofReal (2*c₁/(1/2))) (fun _ _ => (q.card : ENNReal))
    (fun _ _ => Bstage.mass_finite) (fun _ _ => ENNReal.ofReal_ne_top) (fun _ _ => by simp)
    (fun _ _ i => ((2*E*((k : ℝ)+1)/(1/2))/c₀ * B₀ i * max 2 (max 1 ((Hgeom : ℝ)*(Kgeom+2)^n))))

end N2Restriction
#print axioms N2Restriction.concrete_partition_contracting_degree
