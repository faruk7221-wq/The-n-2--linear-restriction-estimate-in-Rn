import continuation.AtlasBallMassV47
import continuation.ActualNontangentEnergyV47
import continuation.EnergyRootNormalizationV47

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal

/-- Lemma 7.1 for the actual nontangent original-packet selections on the
same fixed surface class. Incidence, energy, local estimates, and positive
quasi-Banach summation are all discharged; only stage geometry and the
explicit borrowed tube-cover input remain as hypotheses. -/
theorem eventually_atlas_nontangent_mass {d k : ℕ} (hk : 0 < k)
    (S W : Fin k → SmoothPatch (d+1)) (A : (i : Fin k) → PacketGraphAtlas (S i))
    (V : Fin k → Set (Ambient (d+1))) (m : ℝ)
    (hW : ∀ i, (S i).extendedSurface ∩ V i ⊆ (W i).support) :
    ∃ B : Fin k → ℝ, (∀ i, 0 ≤ B i) ∧
    ∀ᶠ R : ℝ in Filter.atTop, ∀ ρ : ℝ, 1 ≤ ρ → ρ ≤ R/2 → 0 < m-ρ^(-1/4 : ℝ) →
    ∀ (Q : (i : Fin k) → (j : Fin (A i).size) →
      CoordinateCapFamily ((A i).patch j).support (R^(-1/2 : ℝ)))
      (hr : 0 < R^(-1/2 : ℝ)), (∀ i, R^(-1/2 : ℝ) ≤ (A i).capRadius) →
    ∀ (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure)
      (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure),
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
    (∀ i j, HasFrequencySupport ((A i).graph j).surfaceMeasure ((A i).patch j).rotation
      (marginRegion (V i) (m-R^(-1/4 : ℝ))) (f i j)) →
    ∀ (M : ℕ) (Z : Set (Ambient (d+1)))
      (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1))) (K C₀ b θ w : ℝ),
    0 ≤ K → 0 ≤ C₀ → 0 < b → 0 < θ → w ≤ b →
    UniformAlgebraicTubeCoverInput Z T M K →
    ∀ (L : ℕ) (c : Fin L → Ambient (d+1)),
    (∀ l t, l ≠ t → 2*(θ*ρ) ≤ dist (c l) (c t)) →
    ∀ (U : Fin L → (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin d → ℤ))
      (Ω : Set (Ambient (d+1))), MeasurableSet Ω →
    (∀ l i j a ν, ν ∈ U l i j a →
      ¬ PacketTangentInBall Z ((A i).originalPacketTube j a (R^(-1/2 : ℝ)) ν R w)
        T ((A i).cellAxisDirection j a) (c l) ρ b C₀) →
    ∀ p : ℝ, 0 < p → p ≤ 1 → 2/(k : ℝ) ≤ p →
    (∫⁻ x, (atlasBallProductSum A Q hr f U c ρ Ω x)^p) ^ (1/p) ≤
      marginLocalConstant (fun i => (W i).surfaceMeasure) (fun _ => id) V m p ρ *
        (∏ i, (ENNReal.ofReal (B i) * ENNReal.ofReal (M*((K*(C₀+1)+2)/θ+1)^(d+1)))^(1/2 : ℝ)) *
        ∏ i, ENNReal.ofReal ‖g i‖ := by
  choose B hB hbudget using fun i => (A i).actual_nontangent_energy
  refine ⟨B,hB,?_⟩
  filter_upwards [eventually_atlas_ball_mass hk S W A V m hW,
    Filter.eventually_ge_atTop (0 : ℝ)] with R hR hR0
  intro ρ hρ hρR hm Q hr hsmall g f he hf M Z T K C₀ b θ w hK hC₀ hb hθ hw hext L c hsep U Ω hΩ hnt p hp hp1 hkp
  let N := ENNReal.ofReal (M*((K*(C₀+1)+2)/θ+1)^(d+1))
  have henergy (i : Fin k) :
      (∑' l, ENNReal.ofReal (‖(A i).cellInput (Q i) hr (f i) (U l i)‖^2)) ≤
        (ENNReal.ofReal (B i)*N)*ENNReal.ofReal (‖g i‖^2) := by
    have hh := hbudget i Z T K C₀ b ρ θ R w (R^(-1/2 : ℝ)) hK hC₀ hb
      (zero_lt_one.trans_le hρ) hθ hR0 hw hext (Q i) hr (f i) c hsep (fun l => U l i)
      (fun l j a ν hν => hnt l i j a ν hν)
    exact hh.trans (mul_le_mul_left' (ENNReal.ofReal_le_ofReal (he i)) _)
  have h := hR ρ hρ hρR hm Q hr hsmall f hf L U c Ω hΩ
    (fun i => (ENNReal.ofReal (B i)*N)*ENNReal.ofReal (‖g i‖^2)) p hp hp1 hkp henergy
  rw [energy_product_normalization _ _ (fun i => norm_nonneg (g i))] at h
  simpa only [mul_assoc] using h

end N2Restriction
#print axioms N2Restriction.eventually_atlas_nontangent_mass
