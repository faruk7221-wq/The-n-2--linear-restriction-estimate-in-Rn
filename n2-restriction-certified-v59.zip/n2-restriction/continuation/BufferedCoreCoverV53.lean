import continuation.DirectionalInteriorCoverV53
namespace N2Restriction
open Set Metric MeasureTheory
set_option maxHeartbeats 600000

/-- Compact cores admit a fixed positive collar inside the doubled ball. -/
theorem closedBall_subset_margin_doubledBall {n : ℕ} (c : Ambient n) (r : ℝ) :
    closedBall c r ⊆ marginRegion (ball c (2*r)) r := by
  intro x hx y hy
  have hx' := Metric.mem_closedBall.mp hx
  have hy' : 2*r ≤ dist y c := le_of_not_gt hy
  have ht := dist_triangle y x c
  rw [dist_comm y x] at ht
  linarith

/-- A compact set in an open domain and an open cover has finitely many
compact ball cores with doubled frequency balls inside that same cover.
The construction is independent of any analytic radius or input. -/
theorem compact_open_cover_buffered_cores {n : ℕ} {I : Type*}
    (K U : Set (Ambient n)) (hK : IsCompact K) (hU : IsOpen U) (hKU : K ⊆ U)
    (O : I → Set (Ambient n)) (hO : ∀ j, IsOpen (O j)) (hcover : K ⊆ ⋃ j, O j) :
    ∃ N : ℕ, ∃ c : Fin N → Ambient n, ∃ r : Fin N → ℝ, ∃ label : Fin N → I,
      (∀ i, 0 < r i) ∧
      (K ⊆ ⋃ i, K ∩ closedBall (c i) (r i)) ∧
      (∀ i, closedBall (c i) (2*r i) ⊆ U ∩ O (label i)) ∧
      (∀ i, IsCompact (K ∩ closedBall (c i) (r i))) ∧
      (∀ i, K ∩ closedBall (c i) (r i) ⊆ marginRegion (ball (c i) (2*r i)) (r i)) := by
  classical
  choose label hlabel using fun x : K => Set.mem_iUnion.mp (hcover x.property)
  have hlocal (x : K) : ∃ δ : ℝ, 0 < δ ∧ ball (x : Ambient n) δ ⊆ U ∩ O (label x) :=
    Metric.isOpen_iff.mp (hU.inter (hO (label x))) x ⟨hKU x.property,hlabel x⟩
  choose δ hδ hball using hlocal
  let ρ : K → ℝ := fun x => δ x/4
  have hρ (x : K) : 0 < ρ x := div_pos (hδ x) (by norm_num)
  let B := fun x : K => ball (x : Ambient n) (ρ x)
  have hB : K ⊆ ⋃ x : K, B x := by
    intro x hx
    exact mem_iUnion.mpr ⟨⟨x,hx⟩,Metric.mem_ball_self (hρ ⟨x,hx⟩)⟩
  obtain ⟨F,hF⟩ := hK.elim_finite_subcover B (fun _ => isOpen_ball) hB
  let e := Fintype.equivFin ↥F
  let a : Fin (Fintype.card ↥F) → K := fun i => (e.symm i).val
  refine ⟨Fintype.card ↥F,(fun i => (a i).val),(fun i => ρ (a i)),(fun i => label (a i)),
    (fun i => hρ (a i)),?_,?_,?_,?_⟩
  · intro x hx
    obtain ⟨b,hbF,hxb⟩ := Set.mem_iUnion₂.mp (hF hx)
    refine Set.mem_iUnion.mpr ⟨e ⟨b,hbF⟩,hx,?_⟩
    simpa only [a,Equiv.symm_apply_apply] using Metric.ball_subset_closedBall hxb
  · intro i x hx
    apply hball (a i)
    have hh := Metric.mem_closedBall.mp hx
    apply Metric.mem_ball.mpr
    dsimp only [ρ] at hh
    linarith [hδ (a i)]
  · intro i
    exact hK.inter_right isClosed_closedBall
  · intro i
    exact Set.inter_subset_right.trans (closedBall_subset_margin_doubledBall _ _)
end N2Restriction
#print axioms N2Restriction.closedBall_subset_margin_doubledBall
#print axioms N2Restriction.compact_open_cover_buffered_cores
