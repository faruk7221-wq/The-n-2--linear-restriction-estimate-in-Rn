import continuation.AtlasOmittedTailV42

namespace N2Restriction
open MeasureTheory Set
open scoped BigOperators

/-- The actual selected-family extension and its cell-restricted packet sum
agree up to rapid decay throughout the trimmed cell. The error is charged to
the original surface norm and is uniform in the new partition. -/
theorem PacketGraphAtlas.cell_restriction_rapid_approximation {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) {τ : ℝ} (hτ : 0 < τ) :
    ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ N : ℝ, ∃ C : ℝ, 0 ≤ C ∧
      ∀ R : ℝ, R₀ ≤ R →
      ∀ (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support (R^(-1/2 : ℝ)))
        (hr : 0 < R^(-1/2 : ℝ)) (_hsmall : R^(-1/2 : ℝ) ≤ T.capRadius) (B : ℝ), 0 ≤ B →
      (∀ j, ((Q j).centers.card : ℝ) ≤ B*R^((d : ℝ)/2)) →
      ∀ (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
        (g : Lp ℂ 2 S.surfaceMeasure), (∑ j, ‖f j‖^2) ≤ ‖g‖^2 →
      ∀ {m : ℕ} (P : Fin m → MvPolynomial (Fin (d+1)) ℝ)
        (Ω : Set (Ambient (d+1))) (σ : Fin m → Bool) (b : ℝ)
        (A : (j : Fin T.size) → (Q j).centers → Set (Fin d → ℤ))
        (x : Ambient (d+1)), ‖x‖ ≤ R → x ∈ Ω →
      (∀ z, ambientPolynomial (∏ l, P l) z = 0 → b ≤ dist x z) →
      x ∈ PolynomialSignRegion P σ →
      ‖extension (Measure.hausdorffMeasure (d : ℝ)) id (T.cellInput Q hr f A) x -
        extension (Measure.hausdorffMeasure (d : ℝ)) id
          (T.cellInput Q hr f (fun j a => {ν | ν ∈ A j a ∧
            σ ∈ trimmedCellLabels P (T.cellAxisPoint j (R^(-1/2 : ℝ)) ν)
              (T.cellAxisDirection j a.val) Ω b (R^(1/2+τ)/10)})) x‖ ≤
        C*Real.sqrt B*R^(-N)*‖g‖ := by
  obtain ⟨R₀, hR₀, htail⟩ := T.omitted_cell_rapid_tail hτ
  refine ⟨R₀, hR₀, fun N => ?_⟩
  obtain ⟨C, hC, hc⟩ := htail N
  refine ⟨C, hC, ?_⟩
  intro R hR Q hr hsmall B hB hcount f g he m P Ω σ b A x hx hΩ htrim hsign
  have hid := T.cellInput_extension_split Q hr hsmall f A
    (fun j a => {ν | σ ∈ trimmedCellLabels P (T.cellAxisPoint j (R^(-1/2 : ℝ)) ν)
      (T.cellAxisDirection j a.val) Ω b (R^(1/2+τ)/10)}) x
  exact (congrArg norm hid).le.trans
    (hc R hR Q hr B hB hcount f g he P Ω σ b A x hx hΩ htrim hsign)

end N2Restriction
#print axioms N2Restriction.PacketGraphAtlas.cell_restriction_rapid_approximation
