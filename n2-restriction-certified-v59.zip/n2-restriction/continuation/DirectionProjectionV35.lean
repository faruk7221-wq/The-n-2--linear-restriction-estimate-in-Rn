import continuation.MetricTubeDensityV35

namespace N2Restriction
open Set Metric

/-- Rank-one correction forcing a perturbed direction into the kernel. -/
noncomputable def directionAlignedProjection {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    (Q : E →L[ℝ] F) (ℓ : E →L[ℝ] ℝ) (v : E) : E →L[ℝ] F :=
  Q - ℓ.smulRight ((ℓ v)⁻¹ • Q v)

theorem directionAlignedProjection_annihilates {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    (Q : E →L[ℝ] F) (ℓ : E →L[ℝ] ℝ) (v : E) (hv : ℓ v ≠ 0) :
    directionAlignedProjection Q ℓ v v = 0 := by
  simp [directionAlignedProjection, ContinuousLinearMap.smulRight_apply, smul_smul, hv]

/-- A normalized dual functional stays bounded away from zero on a small
fixed directional neighborhood. -/
theorem direction_dual_lower {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    (ℓ : E →L[ℝ] ℝ) (v₀ v : E) (N ε : ℝ) (hN : 0 ≤ N)
    (hℓ : ‖ℓ‖ ≤ N) (hbase : ℓ v₀ = 1) (hv : ‖v-v₀‖ ≤ ε) (hε : N*ε ≤ 1/2) :
    1/2 ≤ ℓ v := by
  have h := (ℓ.le_of_opNorm_le hℓ (v-v₀)).trans (mul_le_mul_of_nonneg_left hv hN)
  rw [map_sub, hbase, Real.norm_eq_abs] at h
  have := (abs_le.mp h).1
  linarith

/-- Directional perturbations give operator perturbations with explicit
cost 2*N*M. This bridges directional tube neighborhoods to the proved
projection-neighborhood Kakeya theorem. -/
theorem directionAlignedProjection_norm_bound {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    (Q : E →L[ℝ] F) (ℓ : E →L[ℝ] ℝ) (v₀ v : E) (M N ε : ℝ)
    (hM : 0 ≤ M) (hN : 0 ≤ N) (hQ : ‖Q‖ ≤ M) (hℓ : ‖ℓ‖ ≤ N)
    (hQv : Q v₀ = 0) (hbase : ℓ v₀ = 1) (hv : ‖v-v₀‖ ≤ ε) (hε : N*ε ≤ 1/2) :
    ‖directionAlignedProjection Q ℓ v - Q‖ ≤ 2*N*M*ε := by
  have hlower := direction_dual_lower ℓ v₀ v N ε hN hℓ hbase hv hε
  have hpos : 0 < ℓ v := by linarith
  have hinv : ‖(ℓ v)⁻¹‖ ≤ 2 := by
    rw [Real.norm_eq_abs, abs_of_pos (inv_pos.mpr hpos)]
    rw [inv_eq_one_div]
    exact (div_le_iff₀ hpos).mpr (by linarith)
  have hqv : ‖Q v‖ ≤ M*ε := by
    have hh := (Q.le_of_opNorm_le hQ (v-v₀)).trans (mul_le_mul_of_nonneg_left hv hM)
    simpa only [map_sub, hQv, sub_zero] using hh
  have heps : 0 ≤ ε := (norm_nonneg _).trans hv
  have hid : directionAlignedProjection Q ℓ v - Q = -ℓ.smulRight ((ℓ v)⁻¹ • Q v) := by
    unfold directionAlignedProjection
    abel
  rw [hid, norm_neg, ContinuousLinearMap.norm_smulRight_apply, norm_smul]
  calc
    _ ≤ N * (2 * (M*ε)) := mul_le_mul hℓ (mul_le_mul hinv hqv (norm_nonneg _) (by norm_num))
      (by positivity) hN
    _ = _ := by ring

/-- Witness-based metric neighborhood of an affine line. -/
def affineLineTube {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    (a v : E) (w : ℝ) : Set E := {x | ∃ s : ℝ, dist x (a+s•v) ≤ w}

/-- An annihilated line lies in the affine fiber through its base point,
so its genuine metric tube is contained in that fiber's metric tube. -/
theorem affineLineTube_subset_affineFiberTube {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    (A : E →L[ℝ] F) (a v : E) (w : ℝ) (hv : A v = 0) :
    affineLineTube a v w ⊆ affineFiberTube A (A a) w := by
  rintro x ⟨s, hs⟩
  exact ⟨a+s•v, by simp [map_add, map_smul, hv], hs⟩

end N2Restriction

#print axioms N2Restriction.affineLineTube_subset_affineFiberTube
#print axioms N2Restriction.directionAlignedProjection_annihilates
#print axioms N2Restriction.directionAlignedProjection_norm_bound
#print axioms N2Restriction.direction_dual_lower
