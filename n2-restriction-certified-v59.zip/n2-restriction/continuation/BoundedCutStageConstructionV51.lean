import continuation.CutStageConstructionV41
import continuation.PolynomialStageBudgetV51
namespace N2Restriction
open Set Metric MeasureTheory
open scoped BigOperators ENNReal

/-- The actual dimension-drop constructor propagates fixed degree, width
and mass ceilings, with no dependence on the physical radius. -/
theorem polynomial_tangent_cut_stage_with_budget {n k m D : ℕ} {I : Type*} [Fintype I] [Nonempty I]
    {μ : Fin k → Measure (Ambient n)} {g : Fin k → Ambient n → ℂ}
    {a R r : ℝ} {M₀ err : ENNReal} (S : PolynomialStage μ g a R r M₀ err m)
    (B : PolynomialStageBudget) (hB : S.withinBudget B)
    (Q : I → Fin (m+1) → MvPolynomial (Fin n) ℝ)
    (hD : ∀ i j, (Q i j).totalDegree ≤ D)
    (hr : ∀ i x, polynomialLevelMap (Q i) x = 0 →
      Function.Surjective (fderiv ℝ (polynomialLevelMap (Q i)) x))
    {θ : ENNReal} (hθ : θ ≠ 0) (hθfin : θ ≠ ⊤)
    (hpos : 0 < θ * (∫⁻ x in S.region, ‖extensionProduct μ (fun _ => id) g x‖ₑ ^ a))
    (hcut : θ * (∫⁻ x in S.region, ‖extensionProduct μ (fun _ => id) g x‖ₑ ^ a) ≤
      ∫⁻ x in S.region ∩ thickening (100*(S.multiplier*r))
        (⋃ i, {x | polynomialLevelMap (Q i) x = 0}),
        ‖extensionProduct μ (fun _ => id) g x‖ₑ ^ a) :
    m < n ∧ ∃ i, ∃ S' : PolynomialStage μ g a R r M₀ err (m+1),
      S'.equations = Q i ∧ S'.degreeBound = D ∧
      S'.multiplier = 100*S.multiplier ∧
      S'.constant = max 1 (S.constant*(Fintype.card I : ENNReal)/θ) ∧
      S'.region ⊆ S.region ∧
      S'.withinBudget (B.advance D 100 (by norm_num)
        ((Fintype.card I : ENNReal)/θ) (ENNReal.div_ne_top (by simp) hθ)) := by
  obtain ⟨hm,i,S',heq,hdeg,hmult,hconst,hsub⟩ := polynomial_tangent_cut_stage S Q hD hr hθ hθfin hpos hcut
  refine ⟨hm,i,S',heq,hdeg,hmult,hconst,hsub,?_⟩
  apply polynomial_stage_budget_update S S' B hB D 100 (by norm_num)
    ((Fintype.card I : ENNReal)/θ) (ENNReal.div_ne_top (by simp) hθ)
  · rw [hdeg]
    exact le_max_right _ _
  · rw [hmult]
  · rw [hconst]
    simp only [div_eq_mul_inv,mul_assoc,le_refl]

end N2Restriction
#print axioms N2Restriction.polynomial_tangent_cut_stage_with_budget
