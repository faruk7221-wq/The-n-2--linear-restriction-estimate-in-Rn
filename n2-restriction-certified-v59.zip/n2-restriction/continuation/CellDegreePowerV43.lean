import continuation.CellEnergyProductV43

namespace N2Restriction
open scoped BigOperators ENNReal

/-- The far families each remove one power of the partition degree from the
product of squared energies. -/
theorem cell_degree_exponent_sum {k : ℕ} (far : Finset (Fin k)) (s : ℝ) :
    (∑ i : Fin k, (1-s-(if i ∈ far then (1 : ℝ) else 0))) =
      (k : ℝ)*(1-s)-far.card := by
  classical
  simp [Finset.sum_sub_distrib, Finset.sum_ite_mem, nsmul_eq_mul]
  ring

/-- Product of the simultaneous near/far squared-energy coefficients. -/
theorem cell_degree_energy_product {k : ℕ} (far : Finset (Fin k))
    (C : Fin k → ℝ) {D : ℝ} (hD : 0 < D) (s : ℝ) :
    (∏ i, C i * D^(1-s-(if i ∈ far then (1 : ℝ) else 0))) =
      (∏ i, C i) * D^((k : ℝ)*(1-s)-far.card) := by
  rw [Finset.prod_mul_distrib, ← Real.rpow_sum_of_pos hD,
    cell_degree_exponent_sum]

/-- The substantial-cell loss D^s and the p/2 power of the near/far
energy product give exactly the article's cellular exponent. -/
theorem cell_degree_power_identity {k : ℕ} (far : Finset (Fin k))
    (C : Fin k → ℝ) (hC : ∀ i, 0 ≤ C i) {D : ℝ} (hD : 0 < D) (s p : ℝ) :
    D^s * (∏ i, C i * D^(1-s-(if i ∈ far then (1 : ℝ) else 0)))^(p/2) =
      (∏ i, C i)^(p/2) * D^(cellular k s far.card p) := by
  rw [cell_degree_energy_product far C hD s,
    Real.mul_rpow (Finset.prod_nonneg (fun i _ => hC i)) (Real.rpow_nonneg hD.le _),
    ← Real.rpow_mul hD.le, mul_left_comm, ← Real.rpow_add hD]
  congr 2
  unfold cellular
  ring

end N2Restriction
#print axioms N2Restriction.cell_degree_exponent_sum
#print axioms N2Restriction.cell_degree_energy_product
#print axioms N2Restriction.cell_degree_power_identity
