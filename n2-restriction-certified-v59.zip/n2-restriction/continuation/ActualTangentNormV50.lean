import continuation.ActualTangentOriginalEnergyV49
import continuation.TangentNormAssemblyV50
set_option maxHeartbeats 600000
namespace N2Restriction
open MeasureTheory Set Metric Filter
open scoped ENNReal NNReal

/-- Normalized equation (7.8) for the actual tangent sum, relative to the
borrowed inputs and explicit terminal cube geometry. The finite constant is
fixed before the radius, inputs, varieties, cover and packet selections. -/
theorem actualTangentSum_normalized_bound {k : ℕ}
    (P : Fin k → SmoothPatch (k+2)) {ι : ℝ}
    (Dsub : ∀ i, DirectionalSubdivision (P i) ι) (a : ∀ i, Fin (Dsub i).size) (A : (i : Fin k) → PacketGraphAtlas ((fun i => (Dsub i).piece (a i)) i))
    {κ : ℝ} (B : ArticleLocalizationAtlas (fun i => (Dsub i).piece (a i)) κ)
    (V : Fin k → Set (Ambient (k+2))) (m : ℝ)
    (hS : ∀ i, ((fun i => (Dsub i).piece (a i)) i).extendedSurface ∩ V i ⊆ ((fun i => (Dsub i).piece (a i)) i).support) (hm : 0 < m)
    {p ε τ lam : ℝ} (hp : 0 < p) (hp1 : p ≤ 1) (hε : 0 < ε)
    (hexternal : B.UniformLocalizedInput p) (hτ : 0 < τ) (hτ' : τ < 1/4) (hlam : 0 < lam)
    (C C₀ θ α β Dwidth Cext Bcap : ℝ)
    (hC : 1 ≤ C) (hC₀ : 1+Real.sqrt (k+2 : ℕ)*(1+C)/2 ≤ C₀)
    (hθ : 0 < θ) (hα : 0 ≤ α) (hβ : 0 ≤ β) (hBcap : 0 ≤ Bcap)
    (hwidth : β = Dwidth+Real.sqrt (k+2 : ℕ)*(1+C)/2) :
    ∃ K : ENNReal, K ≠ ∞ ∧ ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ R : ℝ, R₀ ≤ R →
    ∀ (Q : (i : Fin k) → (j : Fin (A i).size) →
      CoordinateCapFamily ((A i).patch j).support (R^(-1/2 : ℝ)))
      (hr : 0 < R^(-1/2 : ℝ)), (∀ i, R^(-1/2 : ℝ) ≤ (A i).capRadius) →
    (∀ i j, ((Q i j).centers.card : ℝ) ≤ Bcap*R^(((k+1 : ℕ) : ℝ)/2)) →
    ∀ (g : (i : Fin k) → Lp ℂ 2 ((fun i => (Dsub i).piece (a i)) i).surfaceMeasure)
      (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure),
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
    (∀ i j, HasFrequencySupport ((A i).graph j).surfaceMeasure ((A i).patch j).rotation
      (marginRegion (V i) (m-R^(-1/4 : ℝ))) (f i j)) →
    ∀ (L : ℕ) (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin (k+1) → ℤ))
      (Z : Set (Ambient (k+2))) (T : Ambient (k+2) → Submodule ℝ (Ambient (k+2)))
      (c : Fin L → Ambient (k+2)) (Ω : Set (Ambient (k+2))),
    (∀ l t, l ≠ t → 2*(θ*(R^(1-τ))) ≤ dist (c l) (c t)) →
    MeasurableSet Ω → Ω ⊆ closedBall 0 R →
    (∀ (zgrid : meetingGrid (n := k+2) (lam*R^(1/2+τ)) R) (l : Fin L), ((Ω ∩ ball (c l) (R^(1-τ))) ∩ gridCube (gridCentre (lam*R^(1/2+τ)) zgrid.val) (lam*R^(1/2+τ))).Nonempty →
      HasTerminalCubeFrame (fun i => (Dsub i).piece (a i)) κ Z T (c l) (gridCentre (lam*R^(1/2+τ)) zgrid.val) (R^(1-τ)) (lam*R^(1/2+τ))) →
    R^(1/2+τ)/10 ≤ Dwidth*(lam*R^(1/2+τ)) →
    R+Real.sqrt (k+2 : ℕ)*(lam*R^(1/2+τ)) < α*R →
    FiniteDirectionalKakeya (volume.restrict (ball 0 (α*R)))
      (fun i => (P i).normal ((Dsub i).anchor (a i))) ι (β*(lam*R^(1/2+τ))) (p/2)
      (ENNReal.ofReal (Cext*(α*R)^(ε*p)*(β*(lam*R^(1/2+τ)))^((k+2 : ℕ)-ε*p))) →
    positiveNorm
      (actualTangentSum A Q hr f U Z T c (R^(1-τ)) (lam*R^(1/2+τ)) C₀ R (R^(1/2+τ)/10) Ω) p volume ≤
      K*ENNReal.ofReal (R^(-1/2+2*τ+ε))*∏ i, ENNReal.ofReal ‖g i‖ := by
  obtain ⟨Benergy,hBenergy,D,H,M,R₀,hH,hM,hR₀,ht⟩ := actualTangentSum_original_energy_integral
    P Dsub a A B V m hS hm hp hp1 hε hexternal hτ hτ' hlam
  let J : ℝ := -((-1/2+2*τ+ε)*p)
  obtain ⟨Cerr,hCerr,hc⟩ := ht ((J+(k+2 : ℕ))/p)
  let O : ENNReal := ENNReal.ofReal (((1+Real.sqrt (k+2 : ℕ)/2)/θ+1)^(k+2))*(2^k : ENNReal)
  let E : ENNReal := ∏ i, ENNReal.ofReal (Benergy i)
  let ae : ℝ := (k : ℝ)*Cerr*Real.sqrt Bcap*M^k
  let K := tangentNormCoefficient (k+2) O D (ENNReal.ofReal H) E
    (1+Real.sqrt (k+2 : ℕ)) lam α β Cext ε p ae
  have hO : O ≠ ∞ := ENNReal.mul_ne_top ENNReal.ofReal_ne_top (by simp)
  have hE : E ≠ ∞ := ENNReal.prod_ne_top (fun _ _ => ENNReal.ofReal_ne_top)
  have hK : K ≠ ∞ := tangentNormCoefficient_ne_top _ _ _ _ _ hO ENNReal.coe_ne_top
    ENNReal.ofReal_ne_top hE _ _ _ _ _ _ _ _ hp
  refine ⟨K,hK,R₀,hR₀,?_⟩
  intro R hR Q hr hsmall hcount g f he hf L U Z T c Ω hsep hΩ hΩR hframe hw hball hKak
  have hRone : 1 ≤ R := hR₀.trans hR
  have hRpos : 0 < R := zero_lt_one.trans_le hRone
  have hb : 0 < lam*R^(1/2+τ) := mul_pos hlam (Real.rpow_pos_of_pos hRpos _)
  have hd : 0 < 1+Real.sqrt (k+2 : ℕ) := by positivity
  have hae : 0 ≤ ae := by dsimp [ae]; positivity
  have hraw := hc R hR Q hr hsmall Bcap hBcap hcount g f he hf L U Z T c C C₀ θ Ω
    hC hC₀ hθ hsep hΩ hΩR hframe α β Dwidth Cext (ε*p) hα hβ hw hwidth hball hKak
  apply tangent_norm_from_integral _ O D (ENNReal.ofReal H) E hRone hb hlam hd hα hae hp
    β Cext τ ε J (by dsimp [J]; linarith) (fun i => ‖g i‖) (fun i => norm_nonneg _)
    (closedBall 0 (R+Real.sqrt (k+2 : ℕ)*(lam*R^(1/2+τ))))
    (closedBall_subset_closedBall hball.le)
  have herr : ae*R^(-((J+(k+2 : ℕ))/p))*(∏ i, ‖g i‖) =
      (k : ℝ)*(Cerr*Real.sqrt Bcap*R^(-((J+(k+2 : ℕ))/p)))*M^k*(∏ i, ‖g i‖) := by
    dsimp [ae]
    ring
  rw [herr]
  dsimp only [O,E]
  convert hraw using 1
  ring

end N2Restriction
#print axioms N2Restriction.actualTangentSum_normalized_bound
