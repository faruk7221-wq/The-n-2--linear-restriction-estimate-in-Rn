import continuation.CellMeetingWeightsV35

namespace N2Restriction
open MeasureTheory Set
open scoped ENNReal BigOperators

/-- A finite disjoint cell family transfers a flat density integral bound
to a budget for products of local meeting weights. No tube disjointness,
finite family assumption, or subadditivity of the power is needed. -/
theorem cellMeetingWeight_integral_budget {X I J : Type*}
    [MeasurableSpace X] [Fintype I] [Fintype J] {T : I → Type*}
    (μ : Measure X) (C : J → Set X) (hC : ∀ j, MeasurableSet (C j))
    (hd : Pairwise (fun j k => Disjoint (C j) (C k))) (S : Set X)
    (U V : ∀ i, T i → Set X) (u : ∀ i, T i → ℝ≥0∞)
    (hcover : ∀ i j t, ((C j ∩ S) ∩ U i t).Nonempty → C j ⊆ V i t)
    (p : ℝ) (hp : 0 ≤ p) :
    (∑ j, (∏ i, ∑' t, cellMeetingWeight (U i) (u i) (C j ∩ S) t) ^ p * μ (C j)) ≤
      ∫⁻ x, (∏ i, tubeDensity (V i) (u i) x) ^ p ∂μ := by
  apply disjoint_cells_integral_lower μ C hC hd
  intro j x hx
  apply ENNReal.rpow_le_rpow _ hp
  apply Finset.prod_le_prod'
  intro i _
  exact cellMeetingWeight_le_density (U i) (V i) (u i) (C j ∩ S)
    (fun t ht => hcover i j t ht hx)

/-- Equal positive finite cell volumes cancel exactly, including infinite
weights or an infinite integral on the right. -/
theorem cellMeetingWeight_sum_budget {X I J : Type*}
    [MeasurableSpace X] [Fintype I] [Fintype J] {T : I → Type*}
    (μ : Measure X) (C : J → Set X) (hC : ∀ j, MeasurableSet (C j))
    (hd : Pairwise (fun j k => Disjoint (C j) (C k))) (S : Set X)
    (U V : ∀ i, T i → Set X) (u : ∀ i, T i → ℝ≥0∞)
    (hcover : ∀ i j t, ((C j ∩ S) ∩ U i t).Nonempty → C j ⊆ V i t)
    (p : ℝ) (hp : 0 ≤ p) (v B : ℝ≥0∞) (hv : v ≠ 0) (hvfin : v ≠ ⊤)
    (hvol : ∀ j, μ (C j) = v)
    (hflat : (∫⁻ x, (∏ i, tubeDensity (V i) (u i) x) ^ p ∂μ) ≤ B * v) :
    (∑ j, (∏ i, ∑' t, cellMeetingWeight (U i) (u i) (C j ∩ S) t) ^ p) ≤ B := by
  have h := (cellMeetingWeight_integral_budget μ C hC hd S U V u hcover p hp).trans hflat
  simp only [hvol, ← Finset.sum_mul] at h
  exact (ENNReal.mul_le_mul_right hv hvfin).mp h

end N2Restriction

#print axioms N2Restriction.cellMeetingWeight_integral_budget
#print axioms N2Restriction.cellMeetingWeight_sum_budget
