import continuation.ParametricPhaseDerivativeV56
import continuation.GraphFiberBudgetV57
namespace N2Restriction
open Set
set_option maxHeartbeats 800000

theorem contDiff_product_graph_phase {d n : ℕ}
    (G : Ambient (d+1) → Ambient n) (hG : ContDiff ℝ (⊤ : ℕ∞) G) :
    ContDiff ℝ (⊤ : ℕ∞) (fun p : (Ambient d × Ambient n) × ℝ =>
      inner ℝ p.1.2 (G (graphPoint p.1.1 p.2))) := by
  have hl : ContDiff ℝ (⊤ : ℕ∞) (fun p : (Ambient d × Ambient n) × ℝ => graphPoint p.1.1 p.2) :=
    graphPointCLM.contDiff.comp (contDiff_fst.fst.prodMk contDiff_snd)
  exact ContDiff.inner (𝕜 := ℝ) contDiff_fst.snd (hG.comp hl)

/-- Actual second phase derivatives have one finite budget on a compact
parameter/direction box, chosen before physical frequency. -/
theorem exists_compact_phase_second_bound {d n : ℕ}
    (G : Ambient (d+1) → Ambient n) (hG : ContDiff ℝ (⊤ : ℕ∞) G)
    (K : Set (Ambient d)) (hK : IsCompact K) (Θ : Set (Ambient n)) (hΘ : IsCompact Θ)
    (a b : ℝ) :
    ∃ H : ℝ, 0 ≤ H ∧ ∀ θ ∈ Θ, ∀ y ∈ K, ∀ t ∈ Icc a b,
      |deriv (deriv (fun s => inner ℝ θ (G (graphPoint y s)))) t| ≤ H := by
  let Q : (Ambient d × Ambient n) × ℝ → ℝ := fun p =>
    deriv (deriv (fun s => inner ℝ p.1.2 (G (graphPoint p.1.1 s)))) p.2
  have hQ : Continuous Q := continuous_parametric_phase_second_derivative _ (contDiff_product_graph_phase G hG)
  have hc : IsCompact ((K ×ˢ Θ) ×ˢ Icc a b) := (hK.prod hΘ).prod isCompact_Icc
  obtain ⟨H,hH⟩ := hc.bddAbove_image hQ.abs.continuousOn
  refine ⟨max H 0,le_max_right _ _,?_⟩
  intro θ hθ y hy t ht
  have hp : ((y,θ),t) ∈ (K ×ˢ Θ) ×ˢ Icc a b := ⟨⟨hy,hθ⟩,ht⟩
  exact (hH (mem_image_of_mem (fun p => |Q p|) hp)).trans (le_max_left _ _)
end N2Restriction
#print axioms N2Restriction.contDiff_product_graph_phase
#print axioms N2Restriction.exists_compact_phase_second_bound
