import continuation.CompactSliceCoverageV27

namespace N2Restriction
open Set Filter Metric

/-- A finite controlled atlas admits compact center sets with the same chart
identities. Halving the radius makes the controls valid on neighborhoods,
then a compact refinement preserves the finite cover. -/
theorem compact_controlled_center_cover {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    {T : Set E} (hT : IsCompact T) (A : Finset (SubmersionChartModel E F))
    (f : E → F) (U : Set E) {r : ℝ} (hr : 0 < r) (B : ℕ → ℝ)
    (hcover : ∀ x ∈ T, ∃ c ∈ A, c.Controls f U x r B) :
    ∃ K : SubmersionChartModel E F → Set E,
      (∀ c, IsCompact (K c)) ∧ T = ⋃ c ∈ A, K c ∧
      ∀ c x, x ∈ K c → c.Controls f U x (r / 2) B := by
  let V := fun c : SubmersionChartModel E F => interior {x | c.Controls f U x (r / 2) B}
  have hV : T ⊆ ⋃ c ∈ A, V c := by
    intro x hx
    obtain ⟨c, hc, hctrl⟩ := hcover x hx
    exact mem_iUnion₂.mpr ⟨c, hc, mem_interior_iff_mem_nhds.mpr (hctrl.nearby hr)⟩
  obtain ⟨K, hc, hsub, heq⟩ := hT.finite_compact_cover A V (fun _ _ => isOpen_interior) hV
  exact ⟨K, hc, heq, fun c x hx => (interior_subset (s := {y : E | c.Controls f U y (r / 2) B})) (hsub c hx)⟩

end N2Restriction

#print axioms N2Restriction.compact_controlled_center_cover
