import continuation.ConstructedZeroDimensionalMassV51
import continuation.StageMassPositiveRootV51
namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal BigOperators

/-- Equation (6.15) with original cap/chart construction, a uniform degree
ceiling and one fixed child width. The accumulated error is rooted explicitly. -/
theorem exists_constructed_zero_dimensional_stage_norm {d k : ℕ}
    (S W : Fin k → SmoothPatch (d+1)) (T : (i : Fin k) → PacketGraphAtlas (S i))
    (V : Fin k → Set (Ambient (d+1))) (m : ℝ)
    (hW : ∀ i, (S i).extendedSurface ∩ V i ⊆ (W i).support)
    (hm : 0 < m) {τ lam : ℝ} (hτ : 0 < τ) (hτsmall : τ < 1/2) (hlam : 0 < lam)
    (hexternal : ZeroDimensionalPointCountInput (d+1)) (D : ℕ) (p : ℝ) (hp : 0 < p) (Cstage : ENNReal) (hCstage : Cstage ≠ ∞) :
    ∃ K : ENNReal, K ≠ ∞ ∧ ∃ Bcap : ℝ, 0 ≤ Bcap ∧
    ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ R : ℝ, R₀ ≤ R →
    ∃ Q : (i : Fin k) → (j : Fin (T i).size) →
      CoordinateCapFamily ((T i).patch j).support (R^(-1/2 : ℝ)),
    (∀ i, R^(-1/2 : ℝ) ≤ (T i).capRadius) ∧
    (∀ i j, ((Q i j).centers.card : ℝ) ≤ Bcap*R^((d : ℝ)/2)) ∧
    ∀ (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure),
    MarginAdmissible (fun i => (S i).surfaceMeasure) (fun _ => id) V m R (fun i => g i) →
    ∃ f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure,
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) ∧
    (∀ i j, HasFrequencySupport ((T i).graph j).surfaceMeasure id
      (((T i).graph j).parametrization '' ((T i).patch j).support) (f i j)) ∧
    (∀ i j, HasFrequencySupport ((T i).graph j).surfaceMeasure ((T i).patch j).rotation
      (marginRegion (V i) (m-R^(-1/4 : ℝ))) (f i j)) ∧
    (∀ i x, (∑ j, extension ((T i).graph j).surfaceMeasure ((T i).patch j).rotation (f i j) x) =
      extension (S i).surfaceMeasure id (g i) x) ∧
    ∀ (hr : 0 < R^(-1/2 : ℝ)),
    ∀ (A : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ))
      , ∀ {M₀ err : ENNReal} (mvar : ℕ)
      (Zs : PolynomialStage (fun _ => Measure.hausdorffMeasure (d : ℝ))
        (fun i => (T i).cellInput (Q i) hr (f i) (A i)) p R (R^(1/2+τ)) M₀ err mvar),
    (d+1)-mvar = 0 → Zs.degreeBound ≤ D → Zs.multiplier ≤ lam → Zs.constant ≤ Cstage →
    M₀^(1/p) ≤ K * (marginLocalConstant (fun i => (W i).surfaceMeasure) (fun _ => id) V m p
      (lam*R^(1/2+τ)) * (∏ i, ENNReal.ofReal ‖g i‖) + err^(1/p)) := by
  obtain ⟨K,hK,Bcap,hBcap,R₀,hR₀,hb⟩ := exists_constructed_zero_dimensional_stage_mass
    S W T V m hW hm hτ hτsmall hlam hexternal D p hp Cstage hCstage
  obtain ⟨C,hC,hroot⟩ := exists_stage_mass_norm_coefficient hp K hK
  refine ⟨C,hC,Bcap,hBcap,R₀,hR₀,?_⟩
  intro R hR
  obtain ⟨Q,hsmall,hcount,hinputs⟩ := hb R hR
  refine ⟨Q,hsmall,hcount,?_⟩
  intro g hg
  obtain ⟨f,he,hs,hf,hx,hselected⟩ := hinputs g hg
  refine ⟨f,he,hs,hf,hx,?_⟩
  intro hr A M₀ err mvar Zs hzero hdegree hmult hconst
  exact hroot M₀ _ _ err (hselected hr A mvar Zs hzero hdegree hmult hconst)

end N2Restriction
#print axioms N2Restriction.exists_constructed_zero_dimensional_stage_norm
