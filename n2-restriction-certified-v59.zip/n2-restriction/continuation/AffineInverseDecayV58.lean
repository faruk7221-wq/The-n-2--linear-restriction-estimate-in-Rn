import continuation.HorizontalAffineExtensionV57
import continuation.NonstationaryChartProductV57
import continuation.PhysicalPhaseCoordinatesV57
namespace N2Restriction
open Set MeasureTheory
set_option maxHeartbeats 1000000

/-- Actual coordinate inverse-frequency decay after aligning a nonstationary direction with the
slicing axis. The coefficient retains the exact horizontal scale factor. -/
theorem exists_affine_chart_inverse_decay {d n : ℕ}
    (B : Ambient (d+1) → ℂ) (hB : ContDiff ℝ (⊤ : ℕ∞) B) (hs : HasCompactSupport B)
    (G : Ambient (d+1) → Ambient n) (hG : ContDiff ℝ (⊤ : ℕ∞) G)
    (u : Ambient (d+1)) (R : Ambient (d+1) ≃ₗᵢ[ℝ] Ambient (d+1))
    {r : ℝ} (hr : 0 < r) (K : Set (Ambient d)) (hK : IsCompact K) (Θ : Set (Ambient n)) (hΘ : IsCompact Θ)
    (a b : ℝ) (hab : a ≤ b) {c : ℝ} (hc : 0 < c)
    (hcurved : ∀ θ ∈ Θ, ∀ y ∈ K, ∀ t ∈ Icc a b,
      c ≤ |deriv (fun s => inner ℝ θ
        (G (horizontalAffine u R r hr.ne' (graphPoint y s)))) t|) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ θ ∈ Θ, ∀ freq : ℝ, 0 < freq →
      ‖extension (volume.restrict ((horizontalAffine u R r hr.ne') ''
          ((graphFiberEquiv d) '' (K ×ˢ Icc a b)))) G B (freq • θ)‖ ≤ C/freq := by
  let F := horizontalAffine u R r hr.ne'
  have hF := contDiff_horizontalAffine u R r hr.ne'
  obtain ⟨C,hC,hdecay⟩ := exists_compact_chart_product_inverse_decay
    (fun z => B (F z)) (hB.comp hF) (hs.comp_homeomorph F)
    (fun z => G (F z)) (hG.comp hF) K hK Θ hΘ a b hab hc hcurved
  refine ⟨r^(d+1)*C,mul_nonneg (pow_nonneg hr.le _) hC,?_⟩
  intro θ hθ freq hf
  rw [horizontalAffine_extension_transfer u R hr _ G B,norm_mul,norm_pow,
    Complex.norm_real,Real.norm_eq_abs,abs_of_pos hr,extension_graph_rectangle_product]
  calc
    _ ≤ r^(d+1)*(C/freq) :=
      mul_le_mul_of_nonneg_left (hdecay θ hθ freq hf) (pow_nonneg hr.le _)
    _ = _ := by ring
end N2Restriction
#print axioms N2Restriction.exists_affine_chart_inverse_decay
