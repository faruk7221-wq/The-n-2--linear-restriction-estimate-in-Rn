import continuation.FiniteJetThresholdV27
import Mathlib.Topology.UniformSpace.HeineCantor

namespace N2Restriction
open Metric Filter Set

/-- A fixed chart model has one physical coverage radius over compact centers
inside its source. The radius precedes the affine slice choices, whose common
lower norm bound controls their preimages. This is an ingredient for a uniform
atlas count, not a construction of the required compact center cover. -/
theorem compact_affine_slice_uniform_coverage {P F : Type*} {n d : ℕ}
    [NormedAddCommGroup P] [NormedSpace ℝ P] [FiniteDimensional ℝ P]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    (c : SubmersionChartModel (P × Ambient n) (P × F))
    {K : Set (P × Ambient n)} (hK : IsCompact K) (hsource : K ⊆ c.chart.source)
    {s L : ℝ} (hs : 0 < s) (hL : 0 < L) :
    ∃ δ : ℝ, 0 < δ ∧ ∀ x ∈ K,
      ∀ (g : Ambient d →L[ℝ] (P × F) × c.free),
        (∀ v, ‖v‖ ≤ L * ‖g v‖) →
      ∀ (φ : Ambient d → Ambient n),
        (∀ t, φ t = (c.chart.symm (c.chart x + g t)).2) →
      ∀ y : Ambient n, dist y x.2 < δ →
        c.chart (x.1, y) - c.chart x ∈ LinearMap.range g.toLinearMap →
        ∃ t ∈ ball 0 s, φ t = y := by
  obtain ⟨δ₀, hδ₀, hinside⟩ := hK.exists_thickening_subset_open c.chart.open_source hsource
  have hu := hK.uniformContinuousAt_of_continuousAt c.chart
    (fun x hx => c.chart.continuousAt (hsource hx))
    (dist_mem_uniformity (div_pos hs hL))
  obtain ⟨δ₁, hδ₁, hclose⟩ := mem_uniformity_dist.mp hu
  refine ⟨min δ₀ δ₁, lt_min hδ₀ hδ₁, ?_⟩
  intro x hx g hgl φ hφ y hy hrange
  have hxy : dist x (x.1, y) < min δ₀ δ₁ := by
    simpa only [Prod.dist_eq, dist_self, max_eq_right (dist_nonneg), dist_comm] using hy
  have hyinside : (x.1, y) ∈ c.chart.source := by
    apply hinside
    exact mem_thickening_iff.mpr ⟨x, hx, by simpa only [dist_comm] using hxy.trans_le (min_le_left _ _)⟩
  have hc : dist (c.chart x) (c.chart (x.1, y)) < s / L :=
    hclose (hxy.trans_le (min_le_right _ _)) hx
  obtain ⟨t, ht⟩ := hrange
  change g t = c.chart (x.1, y) - c.chart x at ht
  have hg : ‖g t‖ < s / L := by simpa only [ht, ← dist_eq_norm, dist_comm] using hc
  have hsmall : ‖t‖ < s := by
    have hh := mul_lt_mul_of_pos_left hg hL
    rw [mul_div_cancel₀ _ hL.ne'] at hh
    exact (hgl t).trans_lt hh
  refine ⟨t, by simpa using hsmall, ?_⟩
  rw [hφ, ht, add_sub_cancel, c.chart.left_inv hyinside]

end N2Restriction

#print axioms N2Restriction.compact_affine_slice_uniform_coverage
