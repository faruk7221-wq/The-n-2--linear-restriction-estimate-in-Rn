import continuation.DirectionalCoreCoverV53
namespace N2Restriction
open Set MeasureTheory

/-- A finite input tuple has one positive frequency margin below all its
individual core collars, chosen independently of R and the input functions. -/
theorem fin_common_positive_core_margin {k : ℕ} (r : Fin k → ℝ) (hr : ∀ i, 0 < r i) :
    ∃ margin : ℝ, 0 < margin ∧ ∀ i, margin ≤ r i := by
  induction k with
  | zero => exact ⟨1,zero_lt_one,fun i => Fin.elim0 i⟩
  | succ k ih =>
    obtain ⟨m,hm,hbound⟩ := ih (fun i => r i.succ) (fun i => hr i.succ)
    refine ⟨min (r 0) m,lt_min (hr 0) hm,?_⟩
    intro i
    exact Fin.cases (min_le_left _ _) (fun j => (min_le_right _ _).trans (hbound j)) i

/-- Realize a compact core as an actual smooth patch on the SAME extended
surface, with its exact restricted Hausdorff measure. -/
theorem SmoothPatch.exists_compact_core_patch {n : ℕ} (P : SmoothPatch n)
    (K : Set (Ambient n)) (hK : IsCompact K) (hKP : K ⊆ P.support) :
    ∃ S : SmoothPatch n, S.support = K ∧ S.extendedSurface = P.extendedSurface ∧
      S.normal = P.normal ∧
      S.surfaceMeasure = (Measure.hausdorffMeasure ((n : ℝ)-1)).restrict K := by
  let S := P.subpatch K hK hKP P.neighborhood P.open_neighborhood
    (hKP.trans P.support_inside) Set.Subset.rfl
  exact ⟨S,rfl,rfl,rfl,rfl⟩
end N2Restriction
#print axioms N2Restriction.fin_common_positive_core_margin
#print axioms N2Restriction.SmoothPatch.exists_compact_core_patch
