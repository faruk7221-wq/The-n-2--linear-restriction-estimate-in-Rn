import continuation.RegionApproximationV49

namespace N2Restriction
open MeasureTheory Set

/-- Uniform rapid approximation over all surface families, chosen before
the physical region, retained stage and input. -/
theorem atlas_family_region_approximation {d k : ℕ}
    (S : Fin k → SmoothPatch (d+1)) (A : (i : Fin k) → PacketGraphAtlas (S i)) {τ : ℝ} (hτ : 0 < τ) :
    ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ N : ℝ, ∃ C : ℝ, 0 ≤ C ∧
      ∀ R : ℝ, R₀ ≤ R → ∀ i : Fin k,
      ∀ (Q : (j : Fin (A i).size) → CoordinateCapFamily ((A i).patch j).support (R^(-1/2 : ℝ)))
        (hr : 0 < R^(-1/2 : ℝ)) (_hsmall : R^(-1/2 : ℝ) ≤ (A i).capRadius) (B : ℝ), 0 ≤ B →
      (∀ j, ((Q j).centers.card : ℝ) ≤ B*R^((d : ℝ)/2)) →
      ∀ (f : (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure)
        (g : Lp ℂ 2 (S i).surfaceMeasure), (∑ j, ‖f j‖^2) ≤ ‖g‖^2 →
      ∀ (E : Set (Ambient (d+1)))
        (U : (j : Fin (A i).size) → (Q j).centers → Set (Fin d → ℤ))
        (x : Ambient (d+1)), ‖x‖ ≤ R → x ∈ E →
      ‖extension (Measure.hausdorffMeasure (d : ℝ)) id ((A i).cellInput Q hr f U) x -
        extension (Measure.hausdorffMeasure (d : ℝ)) id ((A i).cellInput Q hr f
          (fun j a => U j a ∩ {ν | ((A i).originalPacketTube j a (R^(-1/2 : ℝ)) ν R (R^(1/2+τ)/10) ∩ E).Nonempty})) x‖ ≤
        C*Real.sqrt B*R^(-N)*‖g‖ := by
  classical
  choose R₀ hR₀ ht using fun i => (A i).region_retention_approximation hτ
  let Rstar := 1 + ∑ i, R₀ i
  have hR0 i : 0 ≤ R₀ i := zero_le_one.trans (hR₀ i)
  have hiR i : R₀ i ≤ Rstar :=
    (Finset.single_le_sum (fun j _ => hR0 j) (Finset.mem_univ i)).trans
      (le_add_of_nonneg_left zero_le_one)
  refine ⟨Rstar, le_add_of_nonneg_right (Finset.sum_nonneg (fun i _ => hR0 i)), fun N => ?_⟩
  choose C hC hc using fun i => ht i N
  let Cstar := ∑ i, C i
  have hiC i : C i ≤ Cstar := Finset.single_le_sum (fun j _ => hC j) (Finset.mem_univ i)
  refine ⟨Cstar, Finset.sum_nonneg (fun i _ => hC i), ?_⟩
  intro R hR i Q hr hsmall B hB hcount f g he E U x hx hxΩ
  exact (hc i R ((hiR i).trans hR) Q hr hsmall B hB hcount f g he E U x hx hxΩ).trans
    (mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_right (hiC i) (Real.sqrt_nonneg B)) (Real.rpow_nonneg (by linarith [hR0 i, hiR i]) _))
      (norm_nonneg g))

end N2Restriction
#print axioms N2Restriction.atlas_family_region_approximation
