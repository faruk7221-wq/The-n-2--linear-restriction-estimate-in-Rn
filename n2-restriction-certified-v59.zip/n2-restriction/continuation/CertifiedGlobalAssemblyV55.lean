import continuation.CertifiedMainLocalV55
import continuation.EmptyGlobalSurfaceV54
import continuation.AssumedEpsilonRemovalV38
namespace N2Restriction
open MeasureTheory Set
set_option maxHeartbeats 600000

/-- Apply borrowed epsilon removal to the NOW PROVED local theorem.
The only additional article-side premise is smooth test decay in the
nonempty-support branch. It is not mislabeled as a borrowed input. -/
theorem certified_original_surface_global_of_nonempty_decay {k : ℕ} (hk : 3 ≤ k)
    (S : Fin k → SmoothPatch (k+2)) {ν κ : ℝ} (hgeo : GeometricHypotheses S ν κ)
    (hKexternal : WeightedKakeyaExternalGoal (k+2) k)
    (hLocalized : CertifiedLocalizedRestrictionInput (k := k))
    (hcutsExternal : UniformTangentCutsInput (k+2))
    (hpartitionExternal : UniformProjectedPartitionInput (k+2))
    (hcoverExternal : UniformPolynomialTubeCoverInput (k+2))
    (hpointsExternal : ZeroDimensionalPointCountInput (k+2))
    (hRemoval : SurfaceEpsilonRemovalInput)
    (hdecay : (∀ i, (S i).support.Nonempty) → SurfaceTestDecay S) :
    ∀ p : ℝ, critical k < p → GlobalRestriction (fun i => (S i).surfaceMeasure) (fun _ => id) p := by
  classical
  by_cases hn : ∀ i, (S i).support.Nonempty
  · have hl := certified_original_surface_local_range hk S hgeo hKexternal hLocalized hcutsExternal
      hpartitionExternal hcoverExternal hpointsExternal (critical k) le_rfl
    exact surface_global_of_local_and_external_removal hRemoval hk S hgeo (hdecay hn) hl
  · have he : ∃ i, (S i).support = ∅ := by
      push_neg at hn
      obtain ⟨i,hi⟩ := hn
      exact ⟨i,hi⟩
    intro p hp
    exact globalRestriction_of_empty_surface S he ((critical_pos
      (by exact_mod_cast (show 0 < k by omega))).trans hp)

/-- Precise remaining global obligation: local restriction is no longer a
hypothesis, while the unproved article-side decay estimate remains explicit. -/
theorem mainGlobalGoal_of_certified_inputs_and_nonempty_decay
    (hK : ∀ k : ℕ, 3 ≤ k → WeightedKakeyaExternalGoal (k+2) k)
    (hL : ∀ (k : ℕ) (_hk : 3 ≤ k), CertifiedLocalizedRestrictionInput (k := k))
    (hcuts : ∀ k : ℕ, 3 ≤ k → UniformTangentCutsInput (k+2))
    (hpartition : ∀ k : ℕ, 3 ≤ k → UniformProjectedPartitionInput (k+2))
    (hcover : ∀ k : ℕ, 3 ≤ k → UniformPolynomialTubeCoverInput (k+2))
    (hpoints : ∀ k : ℕ, 3 ≤ k → ZeroDimensionalPointCountInput (k+2))
    (hRemoval : SurfaceEpsilonRemovalInput)
    (hdecay : ∀ k : ℕ, 3 ≤ k → ∀ S : Fin k → SmoothPatch (k+2), ∀ ν κ : ℝ,
      GeometricHypotheses S ν κ → (∀ i, (S i).support.Nonempty) → SurfaceTestDecay S) : MainGlobalGoal := by
  intro k hk S ν κ hgeo
  exact certified_original_surface_global_of_nonempty_decay hk S hgeo (hK k hk) (hL k hk) (hcuts k hk)
    (hpartition k hk) (hcover k hk) (hpoints k hk) hRemoval (hdecay k hk S ν κ hgeo)
end N2Restriction
#print axioms N2Restriction.certified_original_surface_global_of_nonempty_decay
#print axioms N2Restriction.mainGlobalGoal_of_certified_inputs_and_nonempty_decay
