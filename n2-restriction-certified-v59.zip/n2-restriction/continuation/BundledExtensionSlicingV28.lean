import continuation.BundledSurfaceEnergyV28

namespace N2Restriction
open MeasureTheory Set Metric
open scoped NNReal ENNReal

/-- Exact complex-valued slicing of the actual extension of a chart L2 input.
Integrability follows from the retained bounded density on the compact chart.
This is a Fubini identity, not an estimate for a quasi-Banach product norm. -/
theorem MeasuredTubularChart.extension_slicing_L2 {n : ℕ} {S : SmoothPatch n}
    {Q : Ambient n →L[ℝ] ℝ × ℝ} {z : Ambient n} {δ r ρ s : ℝ}
    {B : ℕ → ℝ} {c C : ℝ≥0} {L α β : ℝ}
    (F : MeasuredTubularChart S Q z δ r ρ s B c C L)
    (hn : 1 ≤ n) (hρ : ρ ≤ r) (E : ChartNormalCoordinates F α β)
    (g : Lp ℂ 2 ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier))
    :
    ∃ W : Ambient (n - 1) → ℝ≥0, ∃ f : Ambient (n - 1) → ℂ,
      Measurable W ∧ Measurable f ∧
      (∀ t ∈ closedBall (0 : Ambient (n - 1)) ρ, f t = g (F.param t)) ∧
      (∀ t ∉ closedBall (0 : Ambient (n - 1)) ρ, W t = 0 ∧ f t = 0) ∧
      ∀ x : Ambient n,
        Integrable (fun t => W t •
          (Complex.exp ((inner ℝ x (F.param t) : ℂ) * Complex.I) * f t)) ∧
        extension ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier) id g x =
          (coordinateMeasureFactor E.equiv volume (volume.prod volume) : ℝ) •
            ∫ u, ∫ v, W (E.equiv.symm (u, v)) •
              (Complex.exp ((inner ℝ x (F.param (E.equiv.symm (u, v))) : ℂ) * Complex.I) *
                f (E.equiv.symm (u, v))) := by
  let K := closedBall (0 : Ambient (n - 1)) ρ
  let φ : K → Ambient n := fun t => F.param t
  have hφ : Measurable φ := by
    apply Continuous.measurable
    exact continuousOn_iff_continuous_restrict.mp (fun t ht =>
      (F.bounds t (closedBall_subset_closedBall hρ ht)).2.2.1.continuousAt.continuousWithinAt)
  have hrange : Set.range φ = F.carrier := by
    ext y
    simp only [φ, K, MeasuredTubularChart.carrier, Set.mem_range, Set.mem_image, Subtype.exists]
    constructor <;> rintro ⟨t, ht, he⟩ <;> exact ⟨t, ht, he⟩
  obtain ⟨J, hJ, _, hpush⟩ := F.density
  have hd : ((n - 1 : ℕ) : ℝ) = (n : ℝ) - 1 := by simp [Nat.cast_sub hn]
  have hp : (((volume : Measure (Ambient (n - 1))).comap (Subtype.val : K → Ambient (n - 1))).withDensity
      (fun t => (J t : ℝ≥0∞))).map φ =
      (Measure.hausdorffMeasure ((n - 1 : ℕ) : ℝ)).restrict (Set.range φ) := by
    simpa only [hrange] using hpush
  have hg : Measurable (g : Ambient n → ℂ) := (Lp.stronglyMeasurable g).measurable
  obtain ⟨W, hW, hWK, hWzero⟩ := exists_measurable_zero_extension K isClosed_closedBall.measurableSet J hJ
  obtain ⟨f, hf, hfK, hfzero⟩ := exists_measurable_zero_extension K isClosed_closedBall.measurableSet
    (fun t => g (φ t)) (hg.comp hφ)
  refine ⟨W, f, hW, hf, fun t ht => hfK ⟨t, ht⟩, fun t ht => ⟨hWzero t ht, hfzero t ht⟩, ?_⟩
  intro x
  let a : Ambient n → ℂ := fun y => Complex.exp ((inner ℝ x y : ℂ) * Complex.I) * g y
  have ha : Measurable a := by dsimp [a]; fun_prop
  letI := F.finite_surface_carrier hn
  have hi : Integrable a ((Measure.hausdorffMeasure ((n - 1 : ℕ) : ℝ)).restrict (Set.range φ)) := by
    rw [hd, hrange]
    apply ((Lp.memLp g).integrable (by norm_num)).norm.mono' ha.aestronglyMeasurable
    exact Filter.Eventually.of_forall (fun y => by simp [a])
  obtain ⟨Wx, fx, _, _, hKx, hzerox, hint, he⟩ := measured_chart_integral_slicing
    K isClosed_closedBall.measurableSet φ hφ J hJ hp a ha hi E.equiv
  have hWeq : Wx = W := by
    funext t
    by_cases ht : t ∈ K
    · exact (hKx ⟨t, ht⟩).1.trans (hWK ⟨t, ht⟩).symm
    · exact (hzerox t ht).1.trans (hWzero t ht).symm
  have hfeq : fx = fun t => Complex.exp ((inner ℝ x (F.param t) : ℂ) * Complex.I) * f t := by
    funext t
    by_cases ht : t ∈ K
    · rw [(hKx ⟨t, ht⟩).2, hfK ⟨t, ht⟩]
    · rw [(hzerox t ht).2, hfzero t ht, mul_zero]
  rw [hWeq, hfeq] at hint he
  rw [hd, hrange] at he
  exact ⟨hint, he⟩

end N2Restriction

#print axioms N2Restriction.MeasuredTubularChart.extension_slicing_L2
