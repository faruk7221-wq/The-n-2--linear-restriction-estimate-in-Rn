import continuation.PolynomialAxisV38
import continuation.TrimmedNontangentCellsV38
import Mathlib.Topology.Algebra.MvPolynomial

namespace N2Restriction
open Set Metric
open scoped BigOperators

/-- Ambient evaluation on Euclidean coordinates. -/
noncomputable def ambientPolynomial {n : ℕ} (P : MvPolynomial (Fin n) ℝ)
    (x : Ambient n) : ℝ := MvPolynomial.eval (fun j => x j) P

theorem continuous_ambientPolynomial {n : ℕ} (P : MvPolynomial (Fin n) ℝ) :
    Continuous (ambientPolynomial P) := by
  exact P.continuous_eval.comp (continuous_pi (fun j => EuclideanSpace.proj j |>.continuous))

/-- A zero of any factor lies in the zero set of the product. -/
theorem factor_zero_in_product_wall {n m : ℕ}
    (P : Fin m → MvPolynomial (Fin n) ℝ) (j : Fin m) :
    {x | ambientPolynomial (P j) x = 0} ⊆ {x | ambientPolynomial (∏ l, P l) x = 0} := by
  intro x hx
  change MvPolynomial.eval (fun l => x l) (∏ l, P l) = 0
  rw [map_prod]
  exact Finset.prod_eq_zero (Finset.mem_univ j) hx

/-- The first assertion of Lemma 5.2 for actual multivariate polynomial
sign regions and actual Euclidean tubes. The bound uses the ambient degree
and includes the identically-zero axis case. -/
theorem actual_polynomial_trimmed_cell_count {n m : ℕ} {I : Type*} [Fintype I]
    (P : Fin m → MvPolynomial (Fin n) ℝ) (a v : Ambient n)
    (x : I → Ambient n) {b w : ℝ} (hw : w < b)
    (htube : ∀ i, ∃ t : ℝ, dist (x i) (a+t • v) ≤ w)
    (htrim : ∀ i z, ambientPolynomial (∏ l, P l) z = 0 → b ≤ dist (x i) z)
    (hsign : ∀ i l, i ≠ l → ∃ j,
      (ambientPolynomial (P j) (x i) < 0 ∧ 0 < ambientPolynomial (P j) (x l)) ∨
      (ambientPolynomial (P j) (x l) < 0 ∧ 0 < ambientPolynomial (P j) (x i))) :
    Fintype.card I ≤ (∏ l, P l).totalDegree+1 := by
  have hh := trimmed_polynomial_tube_count (axisPolynomial (∏ l, P l) a v)
    (fun j => ambientPolynomial (P j)) (fun j => continuous_ambientPolynomial (P j))
    {z | ambientPolynomial (∏ l, P l) z = 0} (factor_zero_in_product_wall P) a v
    (fun t => by rw [axisPolynomial_eval]; rfl) x hw htube htrim hsign
  exact hh.trans (Nat.add_le_add_right (axisPolynomial_degree_le _ a v) 1)

/-- The second assertion of Lemma 5.2 for the same actual polynomial sign
regions, conditional only on the algebraic transverse-tube cover. The new
partition polynomial's degree is absent from the result. -/
theorem actual_polynomial_nontangent_cell_count {n m M : ℕ} {I : Type*} [Fintype I]
    (P : Fin m → MvPolynomial (Fin n) ℝ)
    (Z : Set (Ambient n)) (T : Ambient n → Submodule ℝ (Ambient n))
    (V : Submodule ℝ (Ambient n)) {γ K : ℝ} (hK : 0 ≤ K)
    (hexternal : AlgebraicTubeCoverInput Z T γ M K)
    (x z : I → Ambient n) (a v : Ambient n) (hv : ‖v‖ = 1)
    {b w : ℝ} (hb : 0 < b) (hw : w ≤ b)
    (htrim : ∀ i y, ambientPolynomial (∏ l, P l) y = 0 → b ≤ dist (x i) y)
    (hsign : ∀ i l, i ≠ l → ∃ j,
      (ambientPolynomial (P j) (x i) < 0 ∧ 0 < ambientPolynomial (P j) (x l)) ∨
      (ambientPolynomial (P j) (x l) < 0 ∧ 0 < ambientPolynomial (P j) (x i)))
    (hwitness : ∀ i, dist (x i) (z i) < b) (hz : ∀ i, z i ∈ Z)
    (htube : ∀ i, ∃ t : ℝ, dist (x i) (a+t • v) ≤ w)
    (hgap : ∀ i, ‖(T (z i)).starProjection - V.starProjection‖ < 2*γ)
    (hangle : 4*γ < directionPlaneAngle v V) :
    (Fintype.card I : ℝ) ≤ M * (K+2)^n :=
  trimmed_nontangent_cell_bound Z T V hK hexternal
    (fun j => ambientPolynomial (P j)) (fun j => continuous_ambientPolynomial (P j))
    {z | ambientPolynomial (∏ l, P l) z = 0} (factor_zero_in_product_wall P)
    x z a v hv hb hw htrim hsign hwitness hz htube hgap hangle

end N2Restriction

#print axioms N2Restriction.continuous_ambientPolynomial
#print axioms N2Restriction.factor_zero_in_product_wall
#print axioms N2Restriction.actual_polynomial_trimmed_cell_count
#print axioms N2Restriction.actual_polynomial_nontangent_cell_count
