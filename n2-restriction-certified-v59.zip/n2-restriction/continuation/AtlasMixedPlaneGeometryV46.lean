import continuation.MixedPlaneGeometryV46
import continuation.AtlasPacketAxesV42

namespace N2Restriction
open Set Metric

/-- Compact normal tuples from all atlas buffers, including cap centers. -/
def atlasNormalTuples {k : ℕ} (S : Fin k → SmoothPatch (k+2))
    (T : (i : Fin k) → PacketGraphAtlas (S i)) : Set (Fin k → Ambient (k+2)) :=
  (fun z i => (S i).normal (z i)) '' (Set.univ.pi (fun i => ⋃ j, (T i).buffer j))

/-- The geometric hypotheses provide compactness and independence on the
entire atlas frequency region, before a packet radius is chosen. -/
theorem atlasNormalTuples_compact_independent {k : ℕ} (S : Fin k → SmoothPatch (k+2))
    (T : (i : Fin k) → PacketGraphAtlas (S i))
    {ν κ : ℝ} (hgeo : GeometricHypotheses S ν κ) :
    IsCompact (atlasNormalTuples S T) ∧
      ∀ v ∈ atlasNormalTuples S T, LinearIndependent ℝ v := by
  classical
  let K : Fin k → Set (Ambient (k+2)) := fun i => ⋃ j, (T i).buffer j
  have hK (i : Fin k) : IsCompact (K i) := isCompact_iUnion (fun j => (T i).compact_buffer j)
  have hinside (i : Fin k) : K i ⊆ (S i).extendedSurface := by
    intro x hx
    obtain ⟨j, hj⟩ := mem_iUnion.mp hx
    exact ((T i).buffer_inside j hj).1
  let N : (Fin k → Ambient (k+2)) → (Fin k → Ambient (k+2)) :=
    fun z i => (S i).normal (z i)
  have hcont : ContinuousOn N (Set.univ.pi K) := by
    apply continuousOn_pi.mpr
    intro i
    exact ((S i).smooth_normal.continuousOn.mono (fun x hx => (hinside i hx).1)).comp
      (continuous_apply i).continuousOn (fun z hz => hz i (mem_univ i))
  have hbase : IsCompact (Set.univ.pi K) := by
    simpa only [Set.pi, Set.mem_univ, forall_const] using isCompact_pi_infinite hK
  have hcompact := hbase.image_of_continuousOn hcont
  have hind : ∀ v ∈ N '' (Set.univ.pi K), LinearIndependent ℝ v := by
    rintro v ⟨z, hz, rfl⟩
    apply normals_independent_of_gram
    exact ne_of_gt ((sq_pos_of_pos hgeo.1).trans_le
      (hgeo.2.2 z (fun i => hinside i (hz i (mem_univ i)))).1)
  exact ⟨hcompact, hind⟩

/-- Every tuple of actual cap-axis directions belongs to the fixed compact
normal family. -/
theorem cap_axes_mem_atlasNormalTuples {k : ℕ} (S : Fin k → SmoothPatch (k+2))
    (T : (i : Fin k) → PacketGraphAtlas (S i))
    (j : (i : Fin k) → Fin (T i).size) (a : Fin k → Ambient (k+1))
    (ha : ∀ i, a i ∈ ((T i).patch (j i)).support) :
    (fun i => (T i).cellAxisDirection (j i) (a i)) ∈ atlasNormalTuples S T := by
  refine ⟨fun i => ((T i).patch (j i)).rotation (((T i).graph (j i)).parametrization (a i)), ?_, rfl⟩
  intro i _
  apply mem_iUnion.mpr
  refine ⟨j i, ?_⟩
  exact ⟨_, ⟨a i, (closedBall_subset_closedBall ((T i).inner_lt (j i)).le)
    (((T i).patch (j i)).support_inside (ha i)), rfl⟩, rfl⟩

/-- Lemma 7.2's plane has dimension two and stays close to every nearby
common tangent from the fixed atlas frequency region. -/
theorem atlas_mixed_plane_geometry {k : ℕ} (S : Fin k → SmoothPatch (k+2))
    (T : (i : Fin k) → PacketGraphAtlas (S i))
    {ν κ : ℝ} (hgeo : GeometricHypotheses S ν κ) {δ : ℝ} (hδ : 0 < δ) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ v ∈ atlasNormalTuples S T,
      ∀ (V : Submodule ℝ (Ambient (k+2))) (near : Finset (Fin k)),
      (∀ i ∈ near, ‖V.starProjection (v i) - v i‖ < ε) →
      near.card = Module.finrank ℝ V →
      Module.finrank ℝ (V ⊔ Submodule.span ℝ (v '' (↑nearᶜ : Set (Fin k))))ᗮ = 2 ∧
      ∀ u ∈ atlasNormalTuples S T, dist u v < ε →
        ‖(V ⊔ Submodule.span ℝ (v '' (↑nearᶜ : Set (Fin k))))ᗮ.starProjection -
          (commonTangent u).starProjection‖ < δ := by
  obtain ⟨hK,hi⟩ := atlasNormalTuples_compact_independent S T hgeo
  exact compact_mixed_plane_geometry _ hK hi hδ

end N2Restriction
#print axioms N2Restriction.atlasNormalTuples_compact_independent
#print axioms N2Restriction.cap_axes_mem_atlasNormalTuples
#print axioms N2Restriction.atlas_mixed_plane_geometry
