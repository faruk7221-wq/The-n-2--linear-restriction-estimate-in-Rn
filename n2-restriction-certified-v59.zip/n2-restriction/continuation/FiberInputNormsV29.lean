import continuation.ActualFiberInputsV29

namespace N2Restriction
open MeasureTheory
open scoped NNReal ENNReal

/-- Exact squared norm in the L2 convention used for actual input spaces. -/
theorem lp_enorm_sq_eq_energy {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω) (f : Lp ℂ 2 μ) :
    ‖f‖ₑ ^ 2 = ∫⁻ x, (‖f x‖ₑ)^2 ∂μ := by
  rw [Lp.enorm_def, eLpNorm_eq_lintegral_rpow_enorm (by norm_num : (2 : ℝ≥0∞) ≠ 0)
    (by norm_num : (2 : ℝ≥0∞) ≠ ∞)]
  norm_num only [ENNReal.toReal_ofNat]
  rw [← ENNReal.rpow_natCast, ← ENNReal.rpow_mul]
  norm_num

namespace StripChartAmplitude
variable {n : ℕ} {S : SmoothPatch n} {Q : Ambient n →L[ℝ] ℝ × ℝ} {z : Ambient n}
  {δ r ρ s : ℝ} {B : ℕ → ℝ} {c C : ℝ≥0} {L α β ε : ℝ}
  {F : MeasuredTubularChart S Q z δ r ρ s B c C L}
  {E : ChartNormalCoordinates F α β}
  {g : Lp ℂ 2 ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier)}

theorem fiberInput_enorm_sq_ae (A : StripChartAmplitude F E g ε) :
    ∀ᵐ u ∂volume, ‖A.fiberInput u‖ₑ ^ 2 = ∫⁻ v, (‖A.fiberAmplitude u v‖ₑ)^2 := by
  filter_upwards [A.fiberInput_coe_ae] with u hu
  rw [lp_enorm_sq_eq_energy]
  exact lintegral_congr_ae (hu.fun_comp (fun v : ℂ => (‖v‖ₑ)^2))

/-- A normalized energy budget for the actual L2 fiber inputs, with the
original surface input norm on the right. -/
theorem fiberInput_energy_bound (A : StripChartAmplitude F E g ε) :
    (coordinateMeasureFactor E.equiv volume (volume.prod volume) : ℝ≥0∞) *
      (∫⁻ u, ‖A.fiberInput u‖ₑ ^ 2) ≤ (C : ℝ≥0∞) * ‖g‖ₑ ^ 2 := by
  rw [lintegral_congr_ae A.fiberInput_enorm_sq_ae, lp_enorm_sq_eq_energy]
  exact A.fiber_energy

/-- The actual fiber L2 norms have a linear normal-thickness budget. The
square-root Haar factor stays explicit. -/
theorem fiberInput_thickness_bound (A : StripChartAmplitude F E g ε) :
    (coordinateMeasureFactor E.equiv volume (volume.prod volume) : ℝ≥0∞) ^ (1 / 2 : ℝ) *
      (∫⁻ u, ‖A.fiberInput u‖ₑ) ≤
      ENNReal.ofReal (2 * ε) * (C : ℝ≥0∞) ^ (1 / 2 : ℝ) * ‖g‖ₑ := by
  have hsqrt (t : ℝ≥0∞) : (t^2) ^ (1 / 2 : ℝ) = t := by
    rw [← ENNReal.rpow_natCast, ← ENNReal.rpow_mul]
    norm_num
  have he : (∫⁻ u, ((coordinateMeasureFactor E.equiv volume (volume.prod volume) : ℝ≥0∞) *
      ‖A.fiberInput u‖ₑ ^ 2) ^ (1 / 2 : ℝ)) =
      ∫⁻ u, ((coordinateMeasureFactor E.equiv volume (volume.prod volume) : ℝ≥0∞) *
        ∫⁻ v, (‖A.fiberAmplitude u v‖ₑ)^2) ^ (1 / 2 : ℝ) := by
    apply lintegral_congr_ae
    filter_upwards [A.fiberInput_enorm_sq_ae] with u hu
    rw [hu]
  have hh := A.thickness
  change (∫⁻ u, ((coordinateMeasureFactor E.equiv volume (volume.prod volume) : ℝ≥0∞) *
      ∫⁻ v, (‖A.fiberAmplitude u v‖ₑ)^2) ^ (1 / 2 : ℝ)) ≤ _ at hh
  rw [← he, ← lp_enorm_sq_eq_energy] at hh
  simp_rw [ENNReal.mul_rpow_of_nonneg _ _ (by norm_num : (0 : ℝ) ≤ 1 / 2), hsqrt] at hh
  rw [lintegral_const_mul' _ _ (ENNReal.rpow_ne_top_of_nonneg (by norm_num) ENNReal.coe_ne_top)] at hh
  simpa only [mul_assoc] using hh

end StripChartAmplitude
end N2Restriction

#print axioms N2Restriction.StripChartAmplitude.fiberInput_energy_bound
#print axioms N2Restriction.StripChartAmplitude.fiberInput_enorm_sq_ae
#print axioms N2Restriction.StripChartAmplitude.fiberInput_thickness_bound
#print axioms N2Restriction.lp_enorm_sq_eq_energy
