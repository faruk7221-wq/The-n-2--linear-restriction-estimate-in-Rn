import continuation.ActualTangentMarginLowerV48
import continuation.PositiveChildMarginsV44
import N2Restriction.PowerRecurrence
namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal

/-- The actual (7.9) at the article radii; all child-radius and positive-margin
conditions are derived from fixed positive parent margin and small tau. -/
theorem actualTangentSum_article_lower_bound {d k : ℕ} (hk : 0 < k)
    (S : Fin k → SmoothPatch (d+1)) (A : (i : Fin k) → PacketGraphAtlas (S i))
    (V : Fin k → Set (Ambient (d+1))) (m : ℝ)
    (hS : ∀ i, (S i).extendedSurface ∩ V i ⊆ (S i).support)
    {θ τ : ℝ} (hθ : 0 < θ) (hm : 0 < m) (hτ : 0 < τ) (hτsmall : τ < 1/4) :
    ∃ D : ENNReal, D ≠ ∞ ∧ ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ R : ℝ, R₀ ≤ R →
    ∀ (Q : (i : Fin k) → (j : Fin (A i).size) → CoordinateCapFamily ((A i).patch j).support (R^(-1/2 : ℝ)))
    (hr : 0 < R^(-1/2 : ℝ)), (∀ i, R^(-1/2 : ℝ) ≤ (A i).capRadius) →
    ∀ (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure)
    (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure),
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
    (∀ i j, HasFrequencySupport ((A i).graph j).surfaceMeasure ((A i).patch j).rotation
      (marginRegion (V i) (m-R^(-1/4 : ℝ))) (f i j)) →
    ∀ {L : ℕ} (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin d → ℤ))
    (Z : Set (Ambient (d+1))) (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1)))
    (c : Fin L → Ambient (d+1)) (b C₀ : ℝ) (Ω : Set (Ambient (d+1))),
    (∀ l t, l ≠ t → 2*(θ*(R^(1-τ))) ≤ dist (c l) (c t)) →
    positiveNorm (actualTangentSum A Q hr f U Z T c (R^(1-τ)) b C₀ R (R^(1/2+τ)/10) Ω) (2/(k : ℝ)) volume ≤
      D*(ENNReal.ofReal R)^((k : ℝ)/2)*∏ i, ENNReal.ofReal ‖g i‖ := by
  obtain ⟨D,hD,hb⟩ := eventually_actualTangentSum_lower_bound hk S A V m hS hθ
  have hchildren := eventually_children hτ (by linarith : τ < 1/2) (by norm_num : (0:ℝ)<1)
  have hmargins := eventually_positive_child_margins hm hτ (by linarith : τ < 1/2) (by norm_num : (0:ℝ)<1)
  obtain ⟨R₀,hR₀⟩ := Filter.eventually_atTop.mp (hb.and (hchildren.and hmargins))
  refine ⟨D,hD,max 1 R₀,le_max_left _ _,?_⟩
  intro R hR Q hr hsmall g f he hf L U Z T c b C₀ Ω hsep
  have hRone : 1 ≤ R := (le_max_left 1 R₀).trans hR
  obtain ⟨hbound,hchild,hmargin⟩ := hR₀ R ((le_max_right 1 R₀).trans hR)
  have hp : R^(1/2+τ) ≤ R^(1-τ) := Real.rpow_le_rpow_of_exponent_le hRone (by linarith)
  have hw : R^(1/2+τ)/10 ≤ R^(1-τ) := by
    have hpos := Real.rpow_nonneg (zero_le_one.trans hRone) (1/2+τ)
    linarith
  exact hbound (R^(1-τ)) hchild.2.1 hchild.2.2.1 hmargin.2.1
    Q hr hsmall g f he hf U Z T c b C₀ (R^(1/2+τ)/10) Ω hw hsep

end N2Restriction
#print axioms N2Restriction.actualTangentSum_article_lower_bound
