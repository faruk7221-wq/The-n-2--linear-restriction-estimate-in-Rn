import continuation.LineSubspaceKakeyaV37
import continuation.UniformDirectionalKakeyaV22

namespace N2Restriction
open Metric MeasureTheory Set Filter
open scoped ENNReal BigOperators Topology

/-- Compact independent unit-line families have one genuine subspace
aperture and one finite countable Kakeya coefficient at all scales. -/
theorem compact_independent_line_subspace_kakeya {n c : ℕ}
    (F : Set (Fin (n+2) → Ambient (n+2+c))) (hF : IsCompact F)
    (hunit : ∀ v ∈ F, ∀ i, ‖v i‖ = 1) (hindep : ∀ v ∈ F, LinearIndependent ℝ v)
    (η : ℝ) (hη : 0 < η) :
    ∃ ε : ℝ, 0 < ε ∧ ∃ K : ℝ≥0∞, 0 < K ∧ K ≠ ⊤ ∧
      ∀ v ∈ F, SubspaceKakeyaNeighborhood (fun i => Submodule.span ℝ {v i})
        ε (1/((n:ℝ)+1)) η K := by
  let P : Set (Fin (n+2) → Ambient (n+2+c)) → Prop := fun V =>
    ∃ ε : ℝ, 0 < ε ∧ ∃ K : ℝ≥0∞, 0 < K ∧ K ≠ ⊤ ∧
      ∀ v ∈ V, (∀ i, ‖v i‖ = 1) →
        SubspaceKakeyaNeighborhood (fun i => Submodule.span ℝ {v i}) ε (1/((n:ℝ)+1)) η K
  have hp : P F := by
    refine IsCompact.induction_on hF (p := P) ?_ ?_ ?_ ?_
    · exact ⟨1,by norm_num,1,by norm_num,by simp,by simp⟩
    · intro s t hst ht
      obtain ⟨ε,hε,K,hK,hKfin,hb⟩ := ht
      exact ⟨ε,hε,K,hK,hKfin,fun v hv => hb v (hst hv)⟩
    · intro s t hs ht
      obtain ⟨εs,hεs,Ks,hKs,hKsfin,hbs⟩ := hs
      obtain ⟨εt,hεt,Kt,hKt,hKtfin,hbt⟩ := ht
      refine ⟨min εs εt,lt_min hεs hεt,max Ks Kt,hKs.trans_le (le_max_left _ _),
        ne_of_lt (max_lt (lt_top_iff_ne_top.mpr hKsfin) (lt_top_iff_ne_top.mpr hKtfin)),?_⟩
      intro v hv hu
      rcases hv with hv | hv
      · exact (hbs v hv hu).mono (min_le_left _ _) (le_max_left _ _)
      · exact (hbt v hv hu).mono (min_le_right _ _) (le_max_right _ _)
    · intro v hv
      obtain ⟨ε,hε,K,hK,hKfin,hb⟩ := independent_line_subspace_kakeya v (hindep v hv) η hη
      refine ⟨ball v (ε/4),mem_nhdsWithin_of_mem_nhds (ball_mem_nhds _ (by linarith)),
        ε/2,by linarith,K,hK,hKfin,?_⟩
      intro w hw hu
      apply hb.transfer _ le_rfl
      intro i
      have hi : ‖w i-v i‖ < ε/4 := by
        simpa only [dist_eq_norm] using (dist_le_pi_dist w v i).trans_lt hw
      have hh := unit_line_projection_distance (w i) (v i) (hu i) (hunit v hv i)
      linarith
  obtain ⟨ε,hε,K,hK,hKfin,hb⟩ := hp
  exact ⟨ε,hε,K,hK,hKfin,fun v hv => hb v hv (hunit v hv)⟩

/-- The full supported hypersurface normal ensemble, with every factor
retained, has uniform subspace-neighborhood Kakeya bounds. -/
theorem geometric_full_line_subspace_kakeya {n : ℕ}
    (S : Fin (n+2) → SmoothPatch (n+4)) {ν κ : ℝ}
    (hgeo : GeometricHypotheses S ν κ) (η : ℝ) (hη : 0 < η) :
    ∃ ε : ℝ, 0 < ε ∧ ∃ K : ℝ≥0∞, 0 < K ∧ K ≠ ⊤ ∧
      ∀ z : Fin (n+2) → Ambient (n+4), (∀ j, z j ∈ (S j).support) →
        SubspaceKakeyaNeighborhood (fun i => Submodule.span ℝ {(S i).normal (z i)})
          ε (1/((n:ℝ)+1)) η K := by
  let F := (fun z : Fin (n+2) → Ambient (n+4) => fun i => (S i).normal (z i)) '' supportedTupleSet S
  have hc : IsCompact F := isCompact_supported_normal_tuples S
  have hu : ∀ v ∈ F, ∀ i, ‖v i‖ = 1 := by
    rintro v ⟨z,hz,rfl⟩ i
    exact (S i).normal_unit _ ((S i).support_inside (hz i))
  have hi : ∀ v ∈ F, LinearIndependent ℝ v := by
    rintro v ⟨z,hz,rfl⟩
    apply normals_independent_of_gram
    exact ne_of_gt ((sq_pos_of_pos hgeo.1).trans_le
      (hgeo.2.2 z (fun j => (S j).support_in_extendedSurface (hz j))).1)
  obtain ⟨ε,hε,K,hK,hKfin,hb⟩ := compact_independent_line_subspace_kakeya (c := 2) F hc hu hi η hη
  exact ⟨ε,hε,K,hK,hKfin,fun z hz => hb _ ⟨z,hz,rfl⟩⟩

end N2Restriction

#print axioms N2Restriction.compact_independent_line_subspace_kakeya
#print axioms N2Restriction.geometric_full_line_subspace_kakeya
