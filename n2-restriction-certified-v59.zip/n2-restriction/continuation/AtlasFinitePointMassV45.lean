import continuation.AtlasCommonClassLocalV44
import continuation.AtlasSelectedMajorantV42

namespace N2Restriction
open MeasureTheory Set Metric
open scoped BigOperators ENNReal

/-- The analytic finite-point termination bound on the same margin class.
The point set (and its algebraic cardinality bound) is supplied separately;
all selected-input norm estimates are proved from the original chart budget. -/
theorem eventually_atlas_finite_point_mass {d k : ℕ}
    (S W : Fin k → SmoothPatch (d+1)) (T : (i : Fin k) → PacketGraphAtlas (S i))
    (V : Fin k → Set (Ambient (d+1))) (m : ℝ)
    (hW : ∀ i, (S i).extendedSurface ∩ V i ⊆ (W i).support) :
    ∃ C : Fin k → ℝ, (∀ i, 1 ≤ C i) ∧
    ∀ᶠ R : ℝ in Filter.atTop, ∀ L : ℝ, 1 ≤ L → L ≤ R/2 → 0 < m-L^(-1/4 : ℝ) →
    ∀ (Q : (i : Fin k) → (j : Fin (T i).size) →
      CoordinateCapFamily ((T i).patch j).support (R^(-1/2 : ℝ)))
      (hr : 0 < R^(-1/2 : ℝ)), (∀ i, R^(-1/2 : ℝ) ≤ (T i).capRadius) →
    ∀ (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure)
      (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure),
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
    (∀ i j, HasFrequencySupport ((T i).graph j).surfaceMeasure ((T i).patch j).rotation
      (marginRegion (V i) (m-R^(-1/4 : ℝ))) (f i j)) →
    ∀ (A : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ))
      (p : ℝ), 0 < p → ∀ (q : Finset (Ambient (d+1))) (Ω : Set (Ambient (d+1))),
    Ω ⊆ thickening L (q : Set (Ambient (d+1))) →
    (∫⁻ x in Ω, ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
      (fun i => (T i).cellInput (Q i) hr (f i) (A i)) x‖ₑ ^ p) ≤
    (q.card : ENNReal) *
      (marginLocalConstant (fun i => (W i).surfaceMeasure) (fun _ => id) V m p L *
        (∏ i, ENNReal.ofReal (C i)) * (∏ i, ENNReal.ofReal ‖g i‖))^p := by
  classical
  choose C hC hbound using fun i => (T i).selected_input_majorant
  refine ⟨C, hC, ?_⟩
  filter_upwards [eventually_atlas_common_class_local S W T V m hW] with R hR
  intro L hL hLR hm Q hr hsmall g f he hf A p hp q Ω hΩ
  have hcover : Ω ⊆ ⋃ a : q, ball a.val L := by
    intro x hx
    obtain ⟨a, ha, hdist⟩ := mem_thickening_iff.mp (hΩ hx)
    exact mem_iUnion.mpr ⟨⟨a, ha⟩, hdist⟩
  have hnorm : (∏ i, ENNReal.ofReal ‖(T i).cellInput (Q i) hr (f i) (A i)‖) ≤
      (∏ i, ENNReal.ofReal (C i)) * (∏ i, ENNReal.ofReal ‖g i‖) := by
    rw [← Finset.prod_mul_distrib]
    apply Finset.prod_le_prod'
    intro i _
    rw [← ENNReal.ofReal_mul (zero_le_one.trans (hC i))]
    exact ENNReal.ofReal_le_ofReal (hbound i (Q i) hr (g i) (f i) (he i) (A i)).1
  have hlocal (a : q) := (hR L hL hLR hm Q hr hsmall f hf A p hp a.val).trans
    (ENNReal.rpow_le_rpow (by simpa only [mul_assoc] using (mul_le_mul_left' hnorm
      (marginLocalConstant (fun i => (W i).surfaceMeasure) (fun _ => id) V m p L))) hp.le)
  calc
    _ ≤ ∫⁻ x in ⋃ a : q, ball a.val L,
        ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
          (fun i => (T i).cellInput (Q i) hr (f i) (A i)) x‖ₑ ^ p := lintegral_mono_set hcover
    _ ≤ ∑' a : q, ∫⁻ x in ball a.val L,
        ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
          (fun i => (T i).cellInput (Q i) hr (f i) (A i)) x‖ₑ ^ p := lintegral_iUnion_le _ _
    _ ≤ ∑' _a : q, _ := ENNReal.tsum_le_tsum hlocal
    _ = _ := by simp [tsum_fintype, mul_assoc]

end N2Restriction
#print axioms N2Restriction.eventually_atlas_finite_point_mass
