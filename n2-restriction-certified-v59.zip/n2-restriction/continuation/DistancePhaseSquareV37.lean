import continuation.ExtensionPhaseSquareV37

namespace N2Restriction
open MeasureTheory Metric Filter
open scoped BigOperators

/-- Geometric frequency-distance control supplies the uncertainty-scale
hypothesis for the exact extension square-function expansion. This is the
interface for the previously constructed fiber/reference distance bound. -/
theorem extension_phase_square_of_distance {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} {n : ℕ} (ζ φ : Ω → Ambient n)
    (hζ : Measurable ζ) (hφ : Measurable φ) (g : Ω → ℂ) (hg : Integrable g μ)
    (x : Ambient n) (R d : ℝ) (hR : 0 < R) (hx : x ∈ closedBall 0 R)
    (hd : ∀ᵐ ω ∂μ, g ω ≠ 0 → dist (φ ω) (ζ ω) ≤ d) (hscale : R*d ≤ 1) :
    ‖extension μ φ g x‖^2 ≤
      Real.exp n * ∑' a : Fin n → ℕ, phaseSeriesWeight a *
        ‖extension μ ζ (fun ω => phaseSeriesAmplitude R (φ ω-ζ ω) a*g ω) x‖^2 := by
  have hxc : ∀ i, |x i| ≤ R := by
    intro i
    have hh : |x i| ≤ ‖x‖ := by simpa only [Real.norm_eq_abs] using PiLp.norm_apply_le x i
    exact hh.trans (by simpa using hx)
  have hc : ∀ᵐ ω ∂μ, g ω ≠ 0 → ∀ i, |R*(φ ω-ζ ω) i| ≤ 1 := by
    filter_upwards [hd] with ω hω hn i
    rw [abs_mul,abs_of_pos hR]
    have hh : |(φ ω-ζ ω) i| ≤ ‖φ ω-ζ ω‖ := by
      simpa only [Real.norm_eq_abs] using PiLp.norm_apply_le (φ ω-ζ ω) i
    have hdist : ‖φ ω-ζ ω‖ ≤ d := by simpa only [dist_eq_norm] using hω hn
    exact (mul_le_mul_of_nonneg_left (hh.trans hdist) hR.le).trans hscale
  have H := extension_frozen_phase_square_bound ζ (fun ω => φ ω-ζ ω) hζ (hφ.sub hζ)
    g hg x R hR hxc hc
  simpa only [add_sub_cancel] using H

end N2Restriction

#print axioms N2Restriction.extension_phase_square_of_distance
