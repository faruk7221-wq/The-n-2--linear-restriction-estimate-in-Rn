import continuation.PacketKakeyaV21
import continuation.OriginalAtlasCellBudgetV42

namespace N2Restriction
open MeasureTheory Set
open scoped ENNReal

/-- Reindexing the nested cell synthesis preserves the exact original Kakeya
weights. No new decomposition or new packet energy is introduced. -/
theorem PacketGraphAtlas.cellInput_kakeya_norm_sq {d : ℕ} {S : SmoothPatch (d+1)}
    (A : PacketGraphAtlas S) :
    ∃ B : ℝ, 0 ≤ B ∧ ∀ {r : ℝ}
      (Q : (j : Fin A.size) → CoordinateCapFamily (A.patch j).support r) (hr : 0 < r)
      (f : (j : Fin A.size) → Lp ℂ 2 (A.graph j).surfaceMeasure)
      (U : (j : Fin A.size) → (Q j).centers → Set (Fin d → ℤ)),
    ENNReal.ofReal (‖A.cellInput Q hr f U‖^2) ≤ ENNReal.ofReal B *
      selectedEnergy {t : (j : Fin A.size) × ((Q j).centers × (Fin d → ℤ)) |
        t.2.2 ∈ U t.1 t.2.1} (A.kakeyaWeight Q hr f) := by
  obtain ⟨B,hB,hbound⟩ := A.kakeyaWeight_selected_norm
  refine ⟨B,hB,?_⟩
  intro r Q hr f U
  have hh := hbound Q hr f {t | t.2.2 ∈ U t.1 t.2.1}
  rw [(A.selected_packet_hasSum Q hr f _).tsum_eq] at hh
  exact hh

/-- The common cube energy, independent of the ball and angular class. -/
noncomputable def PacketGraphAtlas.cubeEnergy {d : ℕ} {S : SmoothPatch (d+1)}
    (A : PacketGraphAtlas S) {r : ℝ}
    (Q : (j : Fin A.size) → CoordinateCapFamily (A.patch j).support r) (hr : 0 < r)
    (f : (j : Fin A.size) → Lp ℂ 2 (A.graph j).surfaceMeasure)
    (R w C b : ℝ) (q : Ambient (d+1)) : ENNReal :=
  selectedEnergy (packetCubeSelection
    (fun t : (j : Fin A.size) × ((Q j).centers × (Fin d → ℤ)) => (A.patch t.1).rotation)
    (fun t => graphGradient (A.graph t.1).phase t.2.1)
    (fun t => r⁻¹ • latticeVector t.2.2) R w C b q) (A.kakeyaWeight Q hr f)

/-- Any selection of original packets meeting the same dilated cube is
controlled by its common cube energy, including either angular selection. -/
theorem PacketGraphAtlas.cellInput_cube_norm_sq {d : ℕ} {S : SmoothPatch (d+1)}
    (A : PacketGraphAtlas S) :
    ∃ B : ℝ, 0 ≤ B ∧ ∀ {r : ℝ}
      (Q : (j : Fin A.size) → CoordinateCapFamily (A.patch j).support r) (hr : 0 < r)
      (f : (j : Fin A.size) → Lp ℂ 2 (A.graph j).surfaceMeasure)
      (U : (j : Fin A.size) → (Q j).centers → Set (Fin d → ℤ))
      (R w C b : ℝ) (q : Ambient (d+1)),
    (∀ j a ν, ν ∈ U j a →
      (rotatedPacketTube (A.patch j).rotation (graphGradient (A.graph j).phase a)
        (r⁻¹ • latticeVector ν) R w ∩ gridCube q (C*b)).Nonempty) →
    ENNReal.ofReal (‖A.cellInput Q hr f U‖^2) ≤ ENNReal.ofReal B*A.cubeEnergy Q hr f R w C b q := by
  obtain ⟨B,hB,hbound⟩ := A.cellInput_kakeya_norm_sq
  refine ⟨B,hB,?_⟩
  intro r Q hr f U R w C b q hmeet
  apply (hbound Q hr f U).trans
  apply mul_le_mul_left'
  apply selectedEnergy_mono
  intro t ht
  exact hmeet t.1 t.2.1 t.2.2 ht

end N2Restriction
#print axioms N2Restriction.PacketGraphAtlas.cellInput_kakeya_norm_sq
#print axioms N2Restriction.PacketGraphAtlas.cellInput_cube_norm_sq
