import continuation.ActualRetainedSquareV48

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal

/-- Each selected component in a ball is bounded by the same square function. -/
theorem PacketGraphAtlas.actual_retained_extension_le_square {d L : ℕ} {S : SmoothPatch (d+1)}
    (A : PacketGraphAtlas S) {r : ℝ}
    (Q : (j : Fin A.size) → CoordinateCapFamily (A.patch j).support r) (hr : 0 < r)
    (f : (j : Fin A.size) → Lp ℂ 2 (A.graph j).surfaceMeasure)
    (U : (j : Fin A.size) → (Q j).centers → Set (Fin d → ℤ))
    (Z : Set (Ambient (d+1))) (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1)))
    (c : Fin L → Ambient (d+1)) (ρ b C₀ R w : ℝ) (Ω : Set (Ambient (d+1)))
    (l : Fin L) (s : Bool) (x : Ambient (d+1)) (hx : x ∈ ball (c l) ρ) :
    ‖extension (Measure.hausdorffMeasure (d : ℝ)) id (A.cellInput Q hr f
      (if s then A.actualTangentSelection Q U Z T (c l) ρ b C₀ R w Ω else
        A.actualNontangentSelection Q U Z T (c l) ρ b C₀ R w Ω)) x‖ₑ ≤
      (A.actualRetainedSquare Q hr f U Z T c ρ b C₀ R w Ω x)^(1/2 : ℝ) := by
  classical
  have hh := Finset.single_le_sum (fun (ls : Fin L × Bool) (_ : ls ∈ Finset.univ) =>
    show 0 ≤ (ball (c ls.1) ρ).indicator (fun y =>
      ‖extension (Measure.hausdorffMeasure (d : ℝ)) id (A.cellInput Q hr f
        (if ls.2 then A.actualTangentSelection Q U Z T (c ls.1) ρ b C₀ R w Ω else
          A.actualNontangentSelection Q U Z T (c ls.1) ρ b C₀ R w Ω)) y‖ₑ^(2 : ℝ)) x from zero_le _)
    (Finset.mem_univ (l,s))
  rw [indicator_of_mem hx] at hh
  have he := ENNReal.rpow_le_rpow hh (by norm_num : (0 : ℝ) ≤ 1/2)
  simpa only [← ENNReal.rpow_mul,show (2 : ℝ)*(1/2) = 1 by norm_num,ENNReal.rpow_one] using he

end N2Restriction
#print axioms N2Restriction.PacketGraphAtlas.actual_retained_extension_le_square
