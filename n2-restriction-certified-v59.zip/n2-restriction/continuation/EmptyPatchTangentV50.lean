import continuation.ActualTangentInfinityV48

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal

/-- A surface input on an empty compact patch has zero L2 norm. -/
theorem SmoothPatch.norm_eq_zero_of_support_empty {n : ℕ} (S : SmoothPatch n)
    (h : S.support = ∅) (g : Lp ℂ 2 S.surfaceMeasure) : ‖g‖ = 0 := by
  rw [Lp.norm_def]
  simp [SmoothPatch.surfaceMeasure,h]

/-- One empty selected patch annihilates the original norm product. -/
theorem norm_product_zero_of_empty_patch {n k : ℕ} (S : Fin k → SmoothPatch n)
    (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure)
    (h : ∃ i, (S i).support = ∅) : (∏ i, ENNReal.ofReal ‖g i‖) = 0 := by
  obtain ⟨i,hi⟩ := h
  apply Finset.prod_eq_zero (Finset.mem_univ i)
  rw [(S i).norm_eq_zero_of_support_empty hi,ENNReal.ofReal_zero]

/-- Empty directional subpatches contribute the zero actual tangent sum;
no global nonemptiness assumption is needed in the final assembly. -/
theorem actualTangentSum_eq_zero_of_empty_patch {d k : ℕ}
    (S : Fin k → SmoothPatch (d+1)) (A : (i : Fin k) → PacketGraphAtlas (S i))
    {θ : ℝ} (hθ : 0 < θ) {r : ℝ}
    (Q : (i : Fin k) → (j : Fin (A i).size) → CoordinateCapFamily ((A i).patch j).support r)
    (hr : 0 < r) (hsmall : ∀ i, r ≤ (A i).capRadius)
    (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure)
    (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure)
    (he : ∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2)
    (hempty : ∃ i, (S i).support = ∅)
    {L : ℕ} (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin d → ℤ))
    (Z : Set (Ambient (d+1))) (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1)))
    (c : Fin L → Ambient (d+1)) (ρ b C₀ R w : ℝ) (Ω : Set (Ambient (d+1)))
    (hρ : 0 < ρ) (hsep : ∀ l t, l ≠ t → 2*(θ*ρ) ≤ dist (c l) (c t)) :
    actualTangentSum A Q hr f U Z T c ρ b C₀ R w Ω = 0 := by
  obtain ⟨D,_,hD⟩ := actualTangentSum_uniform_bound S A hθ
  have hp := norm_product_zero_of_empty_patch S g hempty
  funext x
  apply le_antisymm _ (zero_le _)
  simpa only [hp,mul_zero,Pi.zero_apply] using
    hD Q hr hsmall g f he U Z T c ρ b C₀ R w Ω hρ hsep x

end N2Restriction
#print axioms N2Restriction.SmoothPatch.norm_eq_zero_of_support_empty
#print axioms N2Restriction.norm_product_zero_of_empty_patch
#print axioms N2Restriction.actualTangentSum_eq_zero_of_empty_patch
