import continuation.AtlasBallProductV47
import continuation.NontangentMassSummationV47

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal

/-- Same-class local estimates and actual selected-input energy imply the
bound for the positive ball sum. This is the analytic assembly in (7.4). -/
theorem eventually_atlas_ball_mass {d k : ℕ} (hk : 0 < k)
    (S W : Fin k → SmoothPatch (d+1)) (T : (i : Fin k) → PacketGraphAtlas (S i))
    (V : Fin k → Set (Ambient (d+1))) (m : ℝ)
    (hW : ∀ i, (S i).extendedSurface ∩ V i ⊆ (W i).support) :
    ∀ᶠ R : ℝ in Filter.atTop, ∀ ρ : ℝ, 1 ≤ ρ → ρ ≤ R/2 → 0 < m-ρ^(-1/4 : ℝ) →
    ∀ (Q : (i : Fin k) → (j : Fin (T i).size) →
      CoordinateCapFamily ((T i).patch j).support (R^(-1/2 : ℝ)))
      (hr : 0 < R^(-1/2 : ℝ)), (∀ i, R^(-1/2 : ℝ) ≤ (T i).capRadius) →
    ∀ (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure),
    (∀ i j, HasFrequencySupport ((T i).graph j).surfaceMeasure ((T i).patch j).rotation
      (marginRegion (V i) (m-R^(-1/4 : ℝ))) (f i j)) →
    ∀ (L : ℕ)
      (U : Fin L → (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ))
      (c : Fin L → Ambient (d+1)) (Ω : Set (Ambient (d+1))), MeasurableSet Ω →
    ∀ (E : Fin k → ENNReal) (p : ℝ), 0 < p → p ≤ 1 → 2/(k : ℝ) ≤ p →
    (∀ i, (∑' l, ENNReal.ofReal (‖(T i).cellInput (Q i) hr (f i) (U l i)‖^2)) ≤ E i) →
    (∫⁻ x, (atlasBallProductSum T Q hr f U c ρ Ω x)^p) ^ (1/p) ≤
      marginLocalConstant (fun i => (W i).surfaceMeasure) (fun _ => id) V m p ρ *
        ∏ i, (E i)^(1/2 : ℝ) := by
  filter_upwards [eventually_atlas_common_class_local S W T V m hW] with R hR
  intro ρ hρ hρR hm Q hr hsmall f hf L U c Ω hΩ E p hp hp1 hkp henergy
  apply nontangent_localized_mass_bound volume hk
    (fun l => Ω ∩ ball (c l) ρ) (fun _ => hΩ.inter isOpen_ball.measurableSet)
    _ (fun l => measurable_atlas_selected_product T Q hr hsmall f (U l))
    (fun i l => ENNReal.ofReal ‖(T i).cellInput (Q i) hr (f i) (U l i)‖) E _ hp hp1 hkp
  · intro l
    exact (lintegral_mono_set Set.inter_subset_right).trans
      (hR ρ hρ hρR hm Q hr hsmall f hf (U l) p hp (c l))
  · intro i
    simpa only [tsum_fintype, ENNReal.rpow_two, ENNReal.ofReal_pow (norm_nonneg _)] using henergy i

end N2Restriction
#print axioms N2Restriction.eventually_atlas_ball_mass
