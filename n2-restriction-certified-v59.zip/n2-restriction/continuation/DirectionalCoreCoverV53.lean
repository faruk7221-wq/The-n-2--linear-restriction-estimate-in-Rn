import continuation.BufferedCoreCoverV53
namespace N2Restriction
open Set Metric MeasureTheory
set_option maxHeartbeats 600000

/-- The retained relative open cover and a buffered parent frequency domain
supply actual compact original cores inside directional pieces, with explicit
positive collars and the active-surface inclusion required by the recurrence.
The same D must be the one retained by the terminal construction. -/
theorem buffered_directional_core_cover {n : ℕ} (P : SmoothPatch n) {ε : ℝ}
    (D : DirectionalSubdivision P ε) (K U : Set (Ambient n))
    (hK : IsCompact K) (hKP : K ⊆ P.support) (hU : IsOpen U) (hKU : K ⊆ U)
    (hclass : P.extendedSurface ∩ U ⊆ P.support)
    (O : Fin D.size → Set (Ambient n)) (hO : ∀ j, IsOpen (O j))
    (hcover : P.support ⊆ ⋃ j, O j)
    (hinside : ∀ j, P.support ∩ O j ⊆ (D.piece j).support) :
    ∃ N : ℕ, ∃ c : Fin N → Ambient n, ∃ r : Fin N → ℝ, ∃ label : Fin N → Fin D.size,
      (∀ i, 0 < r i) ∧
      (K ⊆ ⋃ i, K ∩ closedBall (c i) (r i)) ∧
      (∀ i, IsCompact (K ∩ closedBall (c i) (r i))) ∧
      (∀ i, K ∩ closedBall (c i) (r i) ⊆ (D.piece (label i)).support) ∧
      (∀ i, K ∩ closedBall (c i) (r i) ⊆ marginRegion (ball (c i) (2*r i)) (r i)) ∧
      (∀ i, (D.piece (label i)).extendedSurface ∩ ball (c i) (2*r i) ⊆ (D.piece (label i)).support) := by
  obtain ⟨N,c,r,label,hr,hcov,hball,hcompact,hmargin⟩ := compact_open_cover_buffered_cores K U hK hU hKU
    O hO (hKP.trans hcover)
  refine ⟨N,c,r,label,hr,hcov,hcompact,?_,hmargin,?_⟩
  · intro i x hx
    apply hinside (label i)
    exact ⟨hKP hx.1,(hball i (Metric.closedBall_subset_closedBall (by linarith [hr i]) hx.2)).2⟩
  · intro i x hx
    have hf := hball i (Metric.ball_subset_closedBall hx.2)
    apply hinside (label i)
    exact ⟨hclass ⟨D.extended_subset (label i) hx.1,hf.1⟩,hf.2⟩
end N2Restriction
#print axioms N2Restriction.buffered_directional_core_cover
