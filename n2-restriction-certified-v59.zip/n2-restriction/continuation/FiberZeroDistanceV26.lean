import continuation.MeasuredTransverseFibersV26

namespace N2Restriction
open Metric

/-- Two normal-coordinate fibers at the same thin coordinate have physical
distance controlled by the full chart derivative and the inverse coordinate norm. -/
theorem tubular_fiber_distance_bound {d n k : ℕ}
    (e : Ambient d ≃L[ℝ] (ℝ × ℝ) × Ambient k)
    (φ : Ambient d → Ambient n) {r M L : ℝ} (hM : 0 ≤ M)
    (hei : ‖e.symm.toContinuousLinearMap‖ ≤ L)
    (hφ : ∀ x ∈ closedBall (0 : Ambient d) r, DifferentiableAt ℝ φ x)
    (hD : ∀ x ∈ closedBall (0 : Ambient d) r, ‖fderiv ℝ φ x‖ ≤ M)
    (u w : ℝ × ℝ) (v : Ambient k)
    (hu : e.symm (u, v) ∈ closedBall (0 : Ambient d) r)
    (hw : e.symm (w, v) ∈ closedBall (0 : Ambient d) r) :
    dist (φ (e.symm (u, v))) (φ (e.symm (w, v))) ≤ M * L * dist u w := by
  have hd := (convex_closedBall (0 : Ambient d) r).norm_image_sub_le_of_norm_fderiv_le hφ hD hw hu
  have he : ‖e.symm (u, v) - e.symm (w, v)‖ ≤ L * ‖u - w‖ := by
    rw [← map_sub]
    have hh := e.symm.toContinuousLinearMap.le_of_opNorm_le hei ((u, v) - (w, v))
    have hn : ‖((u, v) - (w, v))‖ = ‖u - w‖ := by
      change max ‖u - w‖ ‖v - v‖ = ‖u - w‖
      rw [sub_self, norm_zero, max_eq_left (norm_nonneg _)]
    simpa only [hn] using hh
  rw [dist_eq_norm, dist_eq_norm]
  exact hd.trans (by simpa only [mul_assoc] using mul_le_mul_of_nonneg_left he hM)

/-- A positive margin between the compact and smooth chart radii keeps the
zero-level reference in the smooth chart whenever L*delta fits that margin. -/
theorem tubular_zero_reference_mem_chart {d k : ℕ}
    (e : Ambient d ≃L[ℝ] (ℝ × ℝ) × Ambient k) {L r ρ δ : ℝ}
    (hL : 0 ≤ L) (hei : ‖e.symm.toContinuousLinearMap‖ ≤ L)
    (a u : ℝ × ℝ) (v : Ambient k)
    (hu : e.symm (u, v) ∈ closedBall (0 : Ambient d) ρ)
    (hstrip : ‖a + u‖ ≤ δ) (hmargin : L * δ ≤ r - ρ) :
    e.symm (-a, v) ∈ closedBall (0 : Ambient d) r := by
  have hd : ‖e.symm (-a, v) - e.symm (u, v)‖ ≤ L * ‖a + u‖ := by
    rw [← map_sub]
    have hh := e.symm.toContinuousLinearMap.le_of_opNorm_le hei ((-a, v) - (u, v))
    have heq : ((-a, v) - (u, v)) = (-(a + u), (0 : Ambient k)) := by
      simp [sub_eq_add_neg, add_comm]
    have hn : ‖((-a, v) - (u, v))‖ = ‖a + u‖ := by
      rw [heq]
      change max ‖-(a + u)‖ ‖(0 : Ambient k)‖ = ‖a + u‖
      rw [norm_neg, norm_zero, max_eq_left (norm_nonneg _)]
    simpa only [hn] using hh
  have hu' : ‖e.symm (u, v)‖ ≤ ρ := by simpa using hu
  have hnorm := norm_le_norm_sub_add (e.symm (-a, v)) (e.symm (u, v))
  have hm := mul_le_mul_of_nonneg_left hstrip hL
  have hh : ‖e.symm (-a, v)‖ ≤ r := by linarith
  simpa using hh

/-- The zero-level reference is at normal coordinate -a, not necessarily 0.
If that reference remains in the full chart, a strip-supported point is within
M*L*delta of the actual zero projected-normal set. -/
theorem tubular_fiber_zero_reference {d n k : ℕ}
    (S : SmoothPatch n) (H : Submodule ℝ (Ambient n))
    (q : Ambient n × Ambient n) (hq : q ∈ orthonormalPairSet n) (hspan : pairPlane q = H)
    (e : Ambient d ≃L[ℝ] (ℝ × ℝ) × Ambient k)
    (R : Ambient d →L[ℝ] ℝ × ℝ) (he : ∀ x, (e x).1 = R x)
    (φ : Ambient d → Ambient n) (a : ℝ × ℝ) {r M L δ : ℝ}
    (hM : 0 ≤ M) (hL : 0 ≤ L) (hei : ‖e.symm.toContinuousLinearMap‖ ≤ L)
    (hφ : ∀ x ∈ closedBall (0 : Ambient d) r, φ x ∈ S.extendedSurface ∧
      pairFrameMap q (S.normal (φ x)) = a + R x ∧
      DifferentiableAt ℝ φ x ∧ ‖fderiv ℝ φ x‖ ≤ M)
    (u : ℝ × ℝ) (v : Ambient k)
    (hu : e.symm (u, v) ∈ closedBall (0 : Ambient d) r)
    (hzero : e.symm (-a, v) ∈ closedBall (0 : Ambient d) r)
    (hstrip : ‖a + u‖ ≤ δ) :
    thinConstraint S H (φ (e.symm (-a, v))) = 0 ∧
      dist (φ (e.symm (u, v))) (φ (e.symm (-a, v))) ≤ M * L * δ := by
  have hcoord : pairFrameMap q (S.normal (φ (e.symm (-a, v)))) = 0 := by
    rw [(hφ _ hzero).2.1, ← he, e.apply_symm_apply]
    exact add_neg_cancel a
  constructor
  · apply Prod.ext
    · exact (hφ _ hzero).1.2
    · change H.orthogonalProjection (S.normal (φ (e.symm (-a, v)))) = 0
      apply (pairFrameEquiv H q hq hspan).injective
      have hh := congrArg (fun f : Ambient n →L[ℝ] ℝ × ℝ =>
        f (S.normal (φ (e.symm (-a, v))))) (pairFrameEquiv_comp_projection H q hq hspan)
      change pairFrameEquiv H q hq hspan (H.orthogonalProjection
        (S.normal (φ (e.symm (-a, v))))) = pairFrameMap q (S.normal (φ (e.symm (-a, v)))) at hh
      rw [hh, hcoord, map_zero]
  · have hd := tubular_fiber_distance_bound e φ hM hei
      (fun x hx => (hφ x hx).2.2.1) (fun x hx => (hφ x hx).2.2.2) u (-a) v hu hzero
    apply hd.trans
    apply mul_le_mul_of_nonneg_left _ (mul_nonneg hM hL)
    simpa only [dist_eq_norm, sub_neg_eq_add, add_comm] using hstrip

/-- The strip constraint implies the distance-to-zero-set condition used by
localized restriction, with the compact-to-smooth chart margin explicit. -/
theorem tubular_strip_infDist_zero_set {d n k : ℕ}
    (S : SmoothPatch n) (H : Submodule ℝ (Ambient n))
    (q : Ambient n × Ambient n) (hq : q ∈ orthonormalPairSet n) (hspan : pairPlane q = H)
    (e : Ambient d ≃L[ℝ] (ℝ × ℝ) × Ambient k)
    (R : Ambient d →L[ℝ] ℝ × ℝ) (he : ∀ x, (e x).1 = R x)
    (φ : Ambient d → Ambient n) (a : ℝ × ℝ) {r ρ M L δ : ℝ}
    (hM : 0 ≤ M) (hL : 0 ≤ L) (hei : ‖e.symm.toContinuousLinearMap‖ ≤ L)
    (hφ : ∀ x ∈ closedBall (0 : Ambient d) r, φ x ∈ S.extendedSurface ∧
      pairFrameMap q (S.normal (φ x)) = a + R x ∧
      DifferentiableAt ℝ φ x ∧ ‖fderiv ℝ φ x‖ ≤ M)
    (u : ℝ × ℝ) (v : Ambient k) (hρ : ρ ≤ r)
    (hu : e.symm (u, v) ∈ closedBall (0 : Ambient d) ρ)
    (hstrip : ‖a + u‖ ≤ δ) (hmargin : L * δ ≤ r - ρ) :
    infDist (φ (e.symm (u, v)))
      {y | y ∈ S.extendedSurface ∧ H.orthogonalProjection (S.normal y) = 0} ≤ M * L * δ := by
  have hzero := tubular_zero_reference_mem_chart e hL hei a u v hu hstrip hmargin
  obtain ⟨hz, hd⟩ := tubular_fiber_zero_reference S H q hq hspan e R he φ a hM hL hei hφ u v
    (closedBall_subset_closedBall hρ hu) hzero hstrip
  have hmem : φ (e.symm (-a, v)) ∈
      {y | y ∈ S.extendedSurface ∧ H.orthogonalProjection (S.normal y) = 0} :=
    ⟨(hφ _ hzero).1, congrArg Prod.snd hz⟩
  exact (infDist_le_dist_of_mem hmem).trans hd

end N2Restriction

#print axioms N2Restriction.tubular_fiber_distance_bound
#print axioms N2Restriction.tubular_fiber_zero_reference
#print axioms N2Restriction.tubular_strip_infDist_zero_set
#print axioms N2Restriction.tubular_zero_reference_mem_chart
