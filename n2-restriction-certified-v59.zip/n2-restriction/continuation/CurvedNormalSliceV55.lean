import continuation.ImplicitNormalSliceV55
namespace N2Restriction
open Set Metric MeasureTheory Filter
set_option maxHeartbeats 800000

/-- The geometric hypotheses construct an actual curved normal slice of
the surface, with one positive phase-curvature bound uniform in time and
near-normal physical direction. No graph curve or curvature bound is assumed. -/
theorem exists_curved_surface_normal_slice {k : ℕ}
    (S : Fin k → SmoothPatch (k+2)) {ν κ : ℝ} (hgeo : GeometricHypotheses S ν κ)
    (hnonempty : ∀ j, (S j).support.Nonempty) (i : Fin k)
    (x : Ambient (k+2)) (hx : x ∈ (S i).extendedSurface) :
    ∃ (w : Ambient (k+2)) (φ : ℝ → ℝ) (r c : ℝ),
      ‖w‖ = 1 ∧ inner ℝ ((S i).normal x) w = 0 ∧
      ContDiff ℝ (⊤ : ℕ∞) φ ∧ φ 0 = 0 ∧ deriv φ 0 = 0 ∧
      deriv (deriv φ) 0 ≠ 0 ∧ 0 < r ∧ 0 < c ∧
      (∀ t ∈ ball (0 : ℝ) r, x + t • w + φ t • (S i).normal x ∈ (S i).extendedSurface) ∧
      (∀ t ∈ ball (0 : ℝ) r, ∀ θ : Ambient (k+2), ‖θ-(S i).normal x‖ ≤ 1/2 →
        c ≤ |deriv (deriv (fun s => inner ℝ θ (x + s • w + φ s • (S i).normal x))) t|) := by
  obtain ⟨w,hw,ht,hH⟩ := geometric_unit_tangent_hessian_direction S hgeo hnonempty i x hx
  obtain ⟨φ,hφ,hφ0,hdφ0,hgraph⟩ := (S i).exists_implicit_normal_slice hx ht
  have hcurved : deriv (deriv φ) 0 ≠ 0 := by
    rw [(S i).normal_graph_curve_curvature hx.1 φ hφ hφ0 hdφ0 hgraph]
    exact div_ne_zero (neg_ne_zero.mpr hH) ((S i).positive_normalScale x hx.1).ne'
  obtain ⟨r,c,hr,hc,hphase⟩ := normal_graph_phase_curvature_persistence x w ((S i).normal x)
    ((S i).normal_unit x hx.1) φ hφ hcurved
  obtain ⟨ρ,hρ,hρball⟩ := Metric.mem_nhds_iff.mp hgraph
  refine ⟨w,φ,min r ρ,c,hw,ht,hφ,hφ0,hdφ0,hcurved,lt_min hr hρ,hc,?_,?_⟩
  · intro t ht'
    exact hρball (ball_subset_ball (min_le_right _ _) ht')
  · intro t ht'
    exact hphase t (ball_subset_ball (min_le_left _ _) ht')
end N2Restriction
#print axioms N2Restriction.exists_curved_surface_normal_slice
