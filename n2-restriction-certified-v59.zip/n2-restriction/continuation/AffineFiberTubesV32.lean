import continuation.ProjectionDensityV32
import Mathlib.Topology.MetricSpace.HausdorffDistance

namespace N2Restriction
open Set Metric
open scoped ENNReal

/-- Points within distance w of a point of the actual affine fiber P(y)=z. -/
def affineFiberTube {E F : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    (P : E →L[ℝ] F) (z : F) (w : ℝ) : Set E :=
  {x | ∃ y, P y = z ∧ dist x y ≤ w}

/-- For a nonempty affine fiber in a proper space, this is exactly its
closed metric neighborhood, using attainment of the distance. -/
theorem affineFiberTube_eq_infDist {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [ProperSpace E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    (P : E →L[ℝ] F) (z : F) (w : ℝ) (hne : (P ⁻¹' {z}).Nonempty) :
    affineFiberTube P z w = {x | infDist x (P ⁻¹' {z}) ≤ w} := by
  ext x
  constructor
  · rintro ⟨y, hy, hxy⟩
    exact (infDist_le_dist_of_mem (show y ∈ P ⁻¹' {z} from hy)).trans hxy
  · intro hx
    obtain ⟨y, hy, hdist⟩ := (isClosed_singleton.preimage P.continuous).exists_infDist_eq_dist hne x
    exact ⟨y, hy, hdist ▸ hx⟩

/-- Metric fiber tubes are measurable, including empty fibers. -/
theorem measurableSet_affineFiberTube {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [ProperSpace E]
    [MeasurableSpace E] [BorelSpace E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    (P : E →L[ℝ] F) (z : F) (w : ℝ) : MeasurableSet (affineFiberTube P z w) := by
  by_cases hne : (P ⁻¹' {z}).Nonempty
  · rw [affineFiberTube_eq_infDist P z w hne]
    exact (isClosed_le (continuous_infDist_pt _) continuous_const).measurableSet
  · have he : affineFiberTube P z w = ∅ := by
      apply Set.eq_empty_iff_forall_notMem.mpr
      rintro x ⟨y, hy, _⟩
      exact hne ⟨y, hy⟩
    rw [he]
    exact MeasurableSet.empty

/-- A metric tube around an affine fiber lies in its projection cylinder,
with the explicit operator-norm width cost. -/
theorem affineFiberTube_subset_cylinder {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    (P : E →L[ℝ] F) (z : F) (w L : ℝ) (hL : 0 ≤ L) (hP : ‖P‖ ≤ L) :
    affineFiberTube P z w ⊆ P ⁻¹' closedBall z (L * w) := by
  rintro x ⟨y, hy, hxy⟩
  have hh := P.le_of_opNorm_le hP (x - y)
  rw [map_sub, hy] at hh
  change dist (P x) z ≤ L * w
  rw [dist_eq_norm]
  exact hh.trans (mul_le_mul_of_nonneg_left (by simpa [dist_eq_norm] using hxy) hL)

/-- Countable weighted metric tubes inherit the cylinder comparison. -/
theorem affineFiberTube_density_le {E F T : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    (P : T → E →L[ℝ] F) (z : T → F) (u : T → ℝ≥0∞)
    (w L : ℝ) (hL : 0 ≤ L) (hP : ∀ t, ‖P t‖ ≤ L) (x : E) :
    tubeDensity (fun t => affineFiberTube (P t) (z t) w) u x ≤
      tubeDensity (fun t => P t ⁻¹' closedBall (z t) (L * w)) u x :=
  tubeDensity_mono_sets _ _ u (fun t => affineFiberTube_subset_cylinder (P t) (z t) w L hL (hP t)) x

end N2Restriction

#print axioms N2Restriction.affineFiberTube_density_le
#print axioms N2Restriction.affineFiberTube_eq_infDist
#print axioms N2Restriction.affineFiberTube_subset_cylinder
#print axioms N2Restriction.measurableSet_affineFiberTube
