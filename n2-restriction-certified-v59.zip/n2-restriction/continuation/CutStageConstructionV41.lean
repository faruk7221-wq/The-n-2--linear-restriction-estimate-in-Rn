import continuation.CutNeighborhoodSelectionV41
import continuation.PolynomialStageV41
import continuation.RegularCodimensionV41

namespace N2Restriction
open Set Metric MeasureTheory
open scoped BigOperators ENNReal

/-- The tangent-cut-neighborhood alternative constructs a genuine next
stage. The finite regular polynomial cut family and its degree bound are
supplied by the borrowed cutting theorem; mass selection is proved here. -/
theorem polynomial_tangent_cut_stage {n k m D : ℕ} {I : Type*} [Fintype I] [Nonempty I]
    {μ : Fin k → Measure (Ambient n)} {g : Fin k → Ambient n → ℂ}
    {a R r : ℝ} {M₀ err : ENNReal} (S : PolynomialStage μ g a R r M₀ err m)
    (Q : I → Fin (m+1) → MvPolynomial (Fin n) ℝ)
    (hD : ∀ i j, (Q i j).totalDegree ≤ D)
    (hr : ∀ i x, polynomialLevelMap (Q i) x = 0 →
      Function.Surjective (fderiv ℝ (polynomialLevelMap (Q i)) x))
    {θ : ENNReal} (hθ : θ ≠ 0) (hθfin : θ ≠ ⊤)
    (hpos : 0 < θ * (∫⁻ x in S.region, ‖extensionProduct μ (fun _ => id) g x‖ₑ ^ a))
    (hcut : θ * (∫⁻ x in S.region, ‖extensionProduct μ (fun _ => id) g x‖ₑ ^ a) ≤
      ∫⁻ x in S.region ∩ thickening (100*(S.multiplier*r))
        (⋃ i, {x | polynomialLevelMap (Q i) x = 0}),
        ‖extensionProduct μ (fun _ => id) g x‖ₑ ^ a) :
    m < n ∧ ∃ i, ∃ S' : PolynomialStage μ g a R r M₀ err (m+1),
      S'.equations = Q i ∧ S'.degreeBound = D ∧
      S'.multiplier = 100*S.multiplier ∧
      S'.constant = max 1 (S.constant*(Fintype.card I : ENNReal)/θ) ∧
      S'.region ⊆ S.region := by
  let ν := partitionDensity μ g S.region a
  have hνΩ : ν S.region = ∫⁻ x in S.region, ‖extensionProduct μ (fun _ => id) g x‖ₑ ^ a :=
    partitionDensity_retained_mass μ g S.region S.region a S.measurable (Subset.refl _)
  have hcut' : θ*ν S.region ≤ ν (S.region ∩ thickening (100*(S.multiplier*r))
      (⋃ i, {x | polynomialLevelMap (Q i) x = 0})) := by
    rw [hνΩ, partitionDensity_retained_mass μ g S.region _ a
      (S.measurable.inter isOpen_thickening.measurableSet) inter_subset_left]
    exact hcut
  obtain ⟨i, Ω', hm, hs, hn, hd, hreg, hmass⟩ := polynomial_cut_neighborhood_selection
    Q hD hr S.region S.measurable (100*(S.multiplier*r)) ν θ hcut'
  have hne : {x | polynomialLevelMap (Q i) x = 0}.Nonempty := by
    by_contra h
    have hz := not_nonempty_iff_eq_empty.mp h
    have he : Ω' = ∅ := subset_empty_iff.mp (by simpa only [hz, thickening_empty] using hn)
    rw [he, measure_empty, mul_zero, hνΩ] at hmass
    exact (not_lt_of_ge hmass) hpos
  obtain ⟨z, hz⟩ := hne
  have hmn := polynomial_regular_codimension_bound (Q i) (hr i z hz)
  rw [hνΩ, partitionDensity_retained_mass μ g S.region Ω' a hm hs] at hmass
  have hstage := retained_mass_stage_constant hθ hθfin S.mass_bound hmass
  have hfinite : S.constant*(Fintype.card I : ENNReal)/θ ≠ ⊤ :=
    ENNReal.div_ne_top (ENNReal.mul_ne_top S.constant_finite (by simp)) hθ
  let S' : PolynomialStage μ g a R r M₀ err (m+1) := {
    equations := Q i
    degreeBound := D
    degree_le := hd
    regular := hr i
    nonempty := ⟨z, hz⟩
    region := Ω'
    measurable := hm
    in_ball := hs.trans S.in_ball
    multiplier := 100*S.multiplier
    multiplier_ge_one := by nlinarith [S.multiplier_ge_one]
    near := by simpa only [mul_assoc] using hn
    constant := max 1 (S.constant*(Fintype.card I : ENNReal)/θ)
    constant_ge_one := le_max_left _ _
    constant_finite := ne_of_lt (max_lt (by simp) (lt_top_iff_ne_top.mpr hfinite))
    mass_bound := stage_mass_constant_normalization hstage }
  exact ⟨by omega, i, S', rfl, rfl, rfl, rfl, hs⟩

end N2Restriction
#print axioms N2Restriction.polynomial_tangent_cut_stage
