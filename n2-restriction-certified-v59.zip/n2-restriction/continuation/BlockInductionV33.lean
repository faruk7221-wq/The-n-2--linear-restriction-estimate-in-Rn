import continuation.BlockHolderLiftV33

namespace N2Restriction
open MeasureTheory
open scoped ENNReal BigOperators

/-- The general induction implication: a reduced block inequality supplies
the next inequality without any finite-volume assumption. -/
theorem block_loomis_whitney_step {X Y : Type*} [MeasurableSpace X] [MeasurableSpace Y]
    (μ : Measure X) (ν : Measure Y) [SFinite ν]
    {m : ℕ} (hm : 2 ≤ m) (f₀ : X → ℝ≥0∞) (f : Fin m → X × Y → ℝ≥0∞)
    (hf₀ : Measurable f₀) (hf : ∀ i, Measurable (f i)) (A : Fin m → ℝ≥0∞)
    (hred : (∫⁻ x, ∏ i, (∫⁻ y, f i (x,y) ∂ν) ^ (1 / ((m : ℝ) - 1)) ∂μ) ≤
      ∏ i, A i ^ (1 / ((m : ℝ) - 1))) :
    (∫⁻ x, ∫⁻ y, (f₀ x * ∏ i, f i (x,y)) ^ (1 / (m : ℝ)) ∂ν ∂μ) ≤
      (∫⁻ x, f₀ x ∂μ) ^ (1 / (m : ℝ)) * ∏ i, A i ^ (1 / (m : ℝ)) := by
  have hmR : (2 : ℝ) ≤ m := by exact_mod_cast hm
  have hm0 : (0 : ℝ) < m := by linarith
  have hm1 : (0 : ℝ) < (m : ℝ) - 1 := by linarith
  have hq : 0 ≤ ((m : ℝ) - 1) / m := by positivity
  have he : (1 / ((m : ℝ) - 1)) * (((m : ℝ) - 1) / m) = 1 / (m : ℝ) := by field_simp
  refine (block_holder_lift μ ν hm f₀ f hf₀ hf).trans ?_
  have h := ENNReal.rpow_le_rpow hred hq
  simp only [← ENNReal.prod_rpow_of_nonneg hq, ← ENNReal.rpow_mul, he] at h
  exact mul_le_mul_left' h _

end N2Restriction

#print axioms N2Restriction.block_loomis_whitney_step
