import continuation.AtlasBinaryStageV42
import continuation.PolynomialStageBudgetV51
namespace N2Restriction
open MeasureTheory Set
open scoped BigOperators ENNReal

/-- Actual binary selection stays inside the original R-packet family and
returns a stage literally expressed by a new subset of those original indices. -/
theorem atlas_binary_selected_stage_with_budget {d k m : ℕ}
    (S : Fin k → SmoothPatch (d+1)) (T : (i : Fin k) → PacketGraphAtlas (S i))
    {r : ℝ} (hr : 0 < r)
    (Q : (i : Fin k) → (j : Fin (T i).size) → CoordinateCapFamily ((T i).patch j).support r)
    (hsmall : ∀ i, r ≤ (T i).capRadius)
    (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure)
    (U V : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ))
    {p R width : ℝ} {M₀ err : ENNReal} (hp : 0 < p) (hp1 : p ≤ 1)
    (W : PolynomialStage (fun _ => Measure.hausdorffMeasure (d : ℝ))
      (fun i => (T i).cellInput (Q i) hr (f i) (U i)) p R width M₀ err m)
    (B : PolynomialStageBudget) (hB : W.withinBudget B) :
    ∃ σ : Fin k → Bool,
    ∃ U' : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ),
      (∀ i j a, U' i j a ⊆ U i j a) ∧
      (∀ i j a, U' i j a = if σ i then U i j a ∩ V i j a else U i j a \ V i j a) ∧
      ∃ W' : PolynomialStage (fun _ => Measure.hausdorffMeasure (d : ℝ))
        (fun i => (T i).cellInput (Q i) hr (f i) (U' i)) p R width M₀ err m,
        W'.equations = W.equations ∧ W'.degreeBound = W.degreeBound ∧
        W'.region = W.region ∧ W'.multiplier = W.multiplier ∧
        W'.constant = max 1 (W.constant*(2^k : ENNReal)) ∧
        W'.withinBudget (B.advance 0 1 le_rfl (2^k : ENNReal) (by simp)) := by
  classical
  obtain ⟨σ,W',heq,hdeg,hregion,hmult,hconst⟩ := atlas_binary_input_stage S T hr Q hsmall f U V hp hp1 W
  let U' := fun i j a => if σ i then U i j a ∩ V i j a else U i j a \ V i j a
  have hg : (fun i => ((T i).binaryCellInput (Q i) hr (f i) (U i) (V i) (σ i) : Ambient (d+1) → ℂ)) =
      (fun i => ((T i).cellInput (Q i) hr (f i) (U' i) : Ambient (d+1) → ℂ)) := by
    funext i
    cases hh : σ i <;> simp only [PacketGraphAtlas.binaryCellInput,hh,U',Bool.false_eq_true,↓reduceIte]
  refine ⟨σ,U',?_,(fun _ _ _ => rfl),?_⟩
  · intro i j a
    dsimp [U']
    split <;> exact fun _ h => h.1
  · have hb : W'.withinBudget (B.advance 0 1 le_rfl (2^k : ENNReal) (by simp)) := by
      apply polynomial_stage_budget_update W W' B hB 0 1 le_rfl (2^k : ENNReal) (by simp)
      · simp only [hdeg,Nat.max_zero,le_refl]
      · simp only [hmult,one_mul,le_refl]
      · rw [hconst]
    rw [← hg]
    exact ⟨W',heq,hdeg,hregion,hmult,hconst,hb⟩

end N2Restriction
#print axioms N2Restriction.atlas_binary_selected_stage_with_budget
