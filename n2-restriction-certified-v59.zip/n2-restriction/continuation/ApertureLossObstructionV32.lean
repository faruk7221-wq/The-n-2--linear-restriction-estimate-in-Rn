import N2Restriction.PowerRecurrence

namespace N2Restriction
open Filter

/-- The one-step width inflation cannot be absorbed into an arbitrary small
radius loss at fixed positive aperture. This concerns the coarse comparison
factor, not the truth of the desired Kakeya inequality. -/
theorem fixed_aperture_inflation_not_small_loss (δ η C : ℝ)
    (hδ : 0 < δ) (hη : η < 5) :
    ∃ R : ℝ, 1 ≤ R ∧ C * R ^ η < (1 + δ * R) ^ 5 := by
  have hh := eventually_power_small (a := 5 - η) (by linarith)
    (pow_pos hδ 5) C
  obtain ⟨R, hsmall, hR⟩ := (hh.and (eventually_ge_atTop (1 : ℝ))).exists
  have hRp : 0 < R := by linarith
  have he : -(5 - η) = η - 5 := by ring
  rw [he, Real.rpow_sub hRp] at hsmall
  norm_num only [Real.rpow_ofNat] at hsmall
  have hm := mul_lt_mul_of_pos_right hsmall (pow_pos hRp 5)
  have hc : C * (R ^ η / R ^ 5) * R ^ 5 = C * R ^ η := by
    field_simp
  rw [hc] at hm
  refine ⟨R, hR, hm.trans_le ?_⟩
  rw [← mul_pow]
  gcongr
  linarith

end N2Restriction

#print axioms N2Restriction.fixed_aperture_inflation_not_small_loss
