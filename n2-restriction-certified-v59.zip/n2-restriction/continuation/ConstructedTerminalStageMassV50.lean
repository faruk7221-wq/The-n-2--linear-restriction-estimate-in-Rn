import continuation.ConstructedTerminalRecurrenceV50
import continuation.PolynomialStageV41
namespace N2Restriction
open MeasureTheory Set Metric Filter
open scoped ENNReal NNReal
set_option maxHeartbeats 600000

/-- Terminal mass outcome for an actual selected PolynomialStage, including
its pre-existing accumulated mass error. A fixed stage coefficient ceiling
is quantified before the radius; no internal analytic estimate is assumed. -/
theorem exists_constructed_terminal_stage_mass_bound {k : ℕ} (hk : 3 ≤ k)
    (P : Fin k → SmoothPatch (k+2)) {ν κ : ℝ} (hgeo : GeometricHypotheses P ν κ)
    (hKexternal : WeightedKakeyaExternalGoal (k+2) k)
    {ε τ lam : ℝ} (hε : 0 < ε) (hτ : 0 < τ) (hτ' : τ < 1/4) (hlam : 1 ≤ lam) :
    ∃ ι Cext : ℝ, 0 < ι ∧ 0 ≤ Cext ∧ ∃ Dsub : ∀ i, DirectionalSubdivision (P i) ι,
    ∀ (a : ∀ i, Fin (Dsub i).size) (A : (i : Fin k) → PacketGraphAtlas ((fun i => (Dsub i).piece (a i)) i))
    (B : ArticleLocalizationAtlas (fun i => (Dsub i).piece (a i)) κ)
    (V : Fin k → Set (Ambient (k+2))) (m : ℝ)
    (_hS : ∀ i, ((fun i => (Dsub i).piece (a i)) i).extendedSurface ∩ V i ⊆ ((fun i => (Dsub i).piece (a i)) i).support) (_hm : 0 < m)
    (_hexternal : B.UniformLocalizedInput (baseline (k : ℝ)))
    (C C₀ : ℝ)
    (_hC : 1 ≤ C) (_hC₀ : 1+Real.sqrt (k+2 : ℕ)*(1+C)/2 ≤ C₀),

    ∀ Mcover : ℕ, ∀ Kcover : ℝ, 0 ≤ Kcover →
    ∀ p : ℝ, critical (k : ℝ) < p → p < baseline (k : ℝ) →
    ∀ Cstage : ENNReal, Cstage ≠ ∞ →
    ∃ Bcap : ℝ, 0 ≤ Bcap ∧ ∃ K : ENNReal, K ≠ ∞ ∧ ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ R : ℝ, R₀ ≤ R →
    ∃ (Q : (i : Fin k) → (j : Fin (A i).size) →
      CoordinateCapFamily ((A i).patch j).support (R^(-1/2 : ℝ)))
      (L : ℕ) (c : Fin L → Ambient (k+2)),
    (∀ i, R^(-1/2 : ℝ) ≤ (A i).capRadius) ∧
    (∀ i j, ((Q i j).centers.card : ℝ) ≤ Bcap*R^(((k+1 : ℕ) : ℝ)/2)) ∧
    (closedBall 0 R ⊆ ⋃ l, ball (c l) (R^(1-τ))) ∧
    (∀ l t, l ≠ t → 2*((1/(2*Real.sqrt (k+2 : ℕ)))*(R^(1-τ))) ≤ dist (c l) (c t)) ∧
    ∀ (g : (i : Fin k) → Lp ℂ 2 ((Dsub i).piece (a i)).surfaceMeasure),
    MarginAdmissible (fun i => ((Dsub i).piece (a i)).surfaceMeasure) (fun _ => id) V m R (fun i => g i) →
    ∃ f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure,
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) ∧
    (∀ i j, HasFrequencySupport ((A i).graph j).surfaceMeasure id
      (((A i).graph j).parametrization '' ((A i).patch j).support) (f i j)) ∧
    (∀ i j, HasFrequencySupport ((A i).graph j).surfaceMeasure ((A i).patch j).rotation
      (marginRegion (V i) (m-R^(-1/4 : ℝ))) (f i j)) ∧
    (∀ i x, (∑ j, extension ((A i).graph j).surfaceMeasure ((A i).patch j).rotation (f i j) x) =
      extension ((Dsub i).piece (a i)).surfaceMeasure id (g i) x) ∧
    ∀ (hr : 0 < R^(-1/2 : ℝ))
      (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin (k+1) → ℤ))
      {M₀ err : ENNReal} (mvar : ℕ)
      (S : PolynomialStage (fun _ => Measure.hausdorffMeasure ((k+1 : ℕ) : ℝ))
        (fun i => (A i).cellInput (Q i) hr (f i) (U i)) p R (R^(1/2+τ)) M₀ err mvar)
      (cuts : Set (Ambient (k+2))) (V₀ : Submodule ℝ (Ambient (k+2))) (near : Finset (Fin k)),
    S.multiplier = lam → S.constant ≤ Cstage →
    (k+2)-mvar+nearᶜ.card = k →
    (∀ i ∈ near, directionPlaneAngle ((P i).normal ((Dsub i).anchor (a i))) V₀ ≤ 4*ι) →
    S.region ⊆ thickening (S.multiplier*R^(1/2+τ)) (planeWitnessSet S.equations cuts V₀ (2*ι)) →
    UniformAlgebraicTubeCoverInput {z | polynomialLevelMap S.equations z = 0}
      (fun z => LinearMap.ker (fderiv ℝ (polynomialLevelMap S.equations) z).toLinearMap) Mcover Kcover →
    M₀ ≤ K*(marginLocalConstant (fun i => ((Dsub i).piece (a i)).surfaceMeasure) (fun _ => id) V m p (R^(1-τ)) +
      ENNReal.ofReal (R^(sigma (k : ℝ) τ ε)))^p*(∏ i, ENNReal.ofReal ‖g i‖)^p+err := by
  obtain ⟨ι,Cext,hι,hCext,Dsub,hb⟩ := exists_constructed_terminal_selected_recurrence hk P hgeo hKexternal
    hε hτ hτ' hlam
  refine ⟨ι,Cext,hι,hCext,Dsub,?_⟩
  intro a A B V m hS hm hexternal C C₀ hC hC₀ Mcover Kcover hKcover p hpc hpb Cstage hCstage
  have hk0 : (0 : ℝ) < k := by exact_mod_cast (show 0 < k by omega)
  have hp : 0 < p := (critical_pos hk0).trans hpc
  obtain ⟨Bcap,hBcap,K,hK,R₀,hR₀,hbound⟩ := hb a A B V m hS hm hexternal C C₀ hC hC₀
    Mcover Kcover hKcover p hpc hpb
  refine ⟨Bcap,hBcap,Cstage*K^p,ENNReal.mul_ne_top hCstage (ENNReal.rpow_ne_top_of_nonneg hp.le hK),R₀,hR₀,?_⟩
  intro R hR
  obtain ⟨Q,L,c,hsmall,hcount,hcover,hsep,hinputs⟩ := hbound R hR
  refine ⟨Q,L,c,hsmall,hcount,hcover,hsep,?_⟩
  intro g hg
  obtain ⟨f,he,hs,hf,hx,hselected⟩ := hinputs g hg
  refine ⟨f,he,hs,hf,hx,?_⟩
  intro hr U M₀ err mvar S cuts V₀ near hmult hconst hterminal hnear hplane hAlg
  rw [hmult] at hplane
  have hn := hselected hr U mvar S.equations cuts V₀ near S.region S.regular hterminal hnear hplane
    S.measurable (S.in_ball.trans ball_subset_closedBall) hAlg
  have hi := ENNReal.rpow_le_rpow hn hp.le
  simp only [positiveNorm,← ENNReal.rpow_mul,one_div_mul_cancel hp.ne',ENNReal.rpow_one] at hi
  have hh := S.mass_bound.trans (add_le_add_right (mul_le_mul' hconst hi) err)
  simpa only [ENNReal.mul_rpow_of_nonneg _ _ hp.le,mul_assoc] using hh

end N2Restriction
#print axioms N2Restriction.exists_constructed_terminal_stage_mass_bound
