import continuation.PacketGeometryV18
import continuation.OriginalAtlasCellBudgetV42

namespace N2Restriction
open MeasureTheory Set
open scoped BigOperators

noncomputable def PacketGraphAtlas.cellAxisPoint {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) (j : Fin T.size) (r : ℝ) (ν : Fin d → ℤ) : Ambient (d+1) :=
  (T.patch j).rotation (graphPoint (-(r⁻¹ • latticeVector ν)) 0)

noncomputable def PacketGraphAtlas.cellAxisDirection {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) (j : Fin T.size) (a : Ambient d) : Ambient (d+1) :=
  S.normal ((T.patch j).rotation ((T.graph j).parametrization a))

/-- The cell-counting direction is the actual unit surface normal at the cap center. -/
theorem PacketGraphAtlas.cellAxisDirection_unit {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) (j : Fin T.size) {a : Ambient d}
    (ha : a ∈ (T.patch j).support) : ‖T.cellAxisDirection j a‖ = 1 := by
  apply S.normal_unit
  exact (T.buffer_inside j ⟨_, ⟨a, (Metric.closedBall_subset_closedBall (T.inner_lt j).le)
    ((T.patch j).support_inside ha), rfl⟩, rfl⟩).1.1

/-- Every point in an actual finite packet tube is close to the exact line
used by trimmed-cell counting. Compactness supplies a nearest segment point. -/
theorem PacketGraphAtlas.packet_tube_near_cell_axis {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) (j : Fin T.size) {a : Ambient d}
    (ha : a ∈ (T.patch j).support) (r : ℝ) (ν : Fin d → ℤ) {R w : ℝ}
    (hR : 0 ≤ R) {x : Ambient (d+1)}
    (hx : x ∈ rotatedPacketTube (T.patch j).rotation (graphGradient (T.graph j).phase a)
      (r⁻¹ • latticeVector ν) R w) :
    ∃ t : ℝ, dist x (T.cellAxisPoint j r ν + t • T.cellAxisDirection j a) ≤ w := by
  obtain ⟨y, hy, he⟩ := (compact_rotated_packetSegment (T.patch j).rotation
    (graphGradient (T.graph j).phase a) (r⁻¹ • latticeVector ν) R).exists_infDist_eq_dist
      ((packetSegment_nonempty _ _ hR).image (T.patch j).rotation) x
  obtain ⟨t, ht⟩ := T.segment_on_normal_line j ha (r⁻¹ • latticeVector ν) R hy
  refine ⟨t, ?_⟩
  change Metric.infDist x _ ≤ w at hx
  rw [he, ht] at hx
  exact hx

/-- A packet meeting a trimmed sign cell is included in that cell's actual label set. -/
theorem PacketGraphAtlas.packet_meeting_cell_label {d m : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) (j : Fin T.size) {a : Ambient d}
    (ha : a ∈ (T.patch j).support) (r : ℝ) (ν : Fin d → ℤ)
    (P : Fin m → MvPolynomial (Fin (d+1)) ℝ) (Ω : Set (Ambient (d+1)))
    {R b w : ℝ} (hR : 0 ≤ R) (σ : Fin m → Bool)
    (hmeet : ∃ x ∈ Ω, x ∈ rotatedPacketTube (T.patch j).rotation
      (graphGradient (T.graph j).phase a) (r⁻¹ • latticeVector ν) R w ∧
      (∀ z, ambientPolynomial (∏ l, P l) z = 0 → b ≤ dist x z) ∧
      x ∈ PolynomialSignRegion P σ) :
    σ ∈ trimmedCellLabels P (T.cellAxisPoint j r ν) (T.cellAxisDirection j a) Ω b w := by
  classical
  obtain ⟨x, hx, ht, hw, hs⟩ := hmeet
  exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, x, hx,
    T.packet_tube_near_cell_axis j ha r ν hR ht, hw, hs⟩

end N2Restriction
#print axioms N2Restriction.PacketGraphAtlas.cellAxisDirection_unit
#print axioms N2Restriction.PacketGraphAtlas.packet_tube_near_cell_axis
#print axioms N2Restriction.PacketGraphAtlas.packet_meeting_cell_label
