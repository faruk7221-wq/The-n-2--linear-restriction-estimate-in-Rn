import continuation.CellWeightBudgetV35
import continuation.CellCylinderEnlargementV35

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal BigOperators

/-- Uniform reference norm bounds allow all complementary cylinders to
use one enlargement width. -/
theorem meeting_cylinder_cell_subset_uniform {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    (A Q : E →L[ℝ] F) (z : F) (x₀ : E) (C : Set E)
    (R w δ D M r : ℝ) (hδ : 0 ≤ δ) (hA : ‖A - Q‖ ≤ δ)
    (hD : 0 ≤ D) (hQ : ‖Q‖ ≤ M) (hr : w + δ*R + M*D ≤ r)
    (hdiam : ∀ x ∈ C, ∀ y ∈ C, dist x y ≤ D)
    (hmeet : ((C ∩ closedBall x₀ R) ∩ A ⁻¹' closedBall z w).Nonempty) :
    C ⊆ Q ⁻¹' closedBall (z + (Q - A) x₀) r := by
  apply (meeting_cylinder_cell_subset A Q z x₀ C R w δ D hδ hA hdiam hmeet).trans
  apply preimage_mono
  apply closedBall_subset_closedBall
  exact (add_le_add_left (mul_le_mul_of_nonneg_right hQ hD) _).trans hr

/-- A flat reference-cylinder bound yields the complete finite-cell
meeting-weight budget for an arbitrary number of perturbed families. -/
theorem perturbed_cylinder_cell_budget {n : ℕ} {I J : Type*}
    [Fintype I] [Fintype J] {T : I → Type*} {F : I → Type*}
    [∀ i, NormedAddCommGroup (F i)] [∀ i, NormedSpace ℝ (F i)]
    (C : J → Set (Ambient n)) (hC : ∀ j, MeasurableSet (C j))
    (hd : Pairwise (fun j k => Disjoint (C j) (C k)))
    (A : ∀ i, T i → Ambient n →L[ℝ] F i) (Q : ∀ i, Ambient n →L[ℝ] F i)
    (z : ∀ i, T i → F i) (u : ∀ i, T i → ℝ≥0∞)
    (x₀ : Ambient n) (R w δ D M r p : ℝ) (hp : 0 ≤ p)
    (hδ : 0 ≤ δ) (hA : ∀ i t, ‖A i t - Q i‖ ≤ δ)
    (hD : 0 ≤ D) (hQ : ∀ i, ‖Q i‖ ≤ M) (hr : w + δ*R + M*D ≤ r)
    (hdiam : ∀ j, ∀ x ∈ C j, ∀ y ∈ C j, dist x y ≤ D)
    (v B : ℝ≥0∞) (hv : v ≠ 0) (hvfin : v ≠ ⊤)
    (hvol : ∀ j, volume (C j) = v)
    (hflat : (∫⁻ x, (∏ i, tubeDensity
      (fun t => Q i ⁻¹' closedBall (z i t + (Q i - A i t) x₀) r) (u i) x) ^ p) ≤ B * v) :
    (∑ j, (∏ i, ∑' t, cellMeetingWeight
      (fun t => A i t ⁻¹' closedBall (z i t) w) (u i) (C j ∩ closedBall x₀ R) t) ^ p) ≤ B := by
  apply cellMeetingWeight_sum_budget volume C hC hd (closedBall x₀ R)
    (fun i t => A i t ⁻¹' closedBall (z i t) w)
    (fun i t => Q i ⁻¹' closedBall (z i t + (Q i - A i t) x₀) r)
    u _ p hp v B hv hvfin hvol hflat
  intro i j t ht
  exact meeting_cylinder_cell_subset_uniform (A i t) (Q i) (z i t) x₀ (C j)
    R w δ D M r hδ (hA i t) hD (hQ i) hr (hdiam j) ht

/-- The enlarged radius is a fixed multiple of the cell side whenever
w <= b and delta*R <= b. Its multiplier is independent of R/b. -/
theorem cylinder_cell_width_bound (w δ R M c b : ℝ)
    (hw : w ≤ b) (ha : δ * R ≤ b) :
    w + δ*R + M*(c*b) ≤ (2 + M*c)*b := by nlinarith

end N2Restriction

#print axioms N2Restriction.cylinder_cell_width_bound
#print axioms N2Restriction.meeting_cylinder_cell_subset_uniform
#print axioms N2Restriction.perturbed_cylinder_cell_budget
