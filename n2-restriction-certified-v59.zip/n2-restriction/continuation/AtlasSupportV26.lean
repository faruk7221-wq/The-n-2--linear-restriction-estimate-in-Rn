import continuation.MeasuredTransverseFibersV26
import N2Restriction.AtlasInputs

namespace N2Restriction
open MeasureTheory Set

/-- Disjoint chart assignment preserves any original frequency constraint,
including a projected-normal strip. -/
theorem finiteCoverInput_inherits_support {Ω : Type*} [MeasurableSpace Ω] {n m : ℕ}
    (μ : Measure Ω) (K : Fin m → Set Ω) (hK : ∀ j, MeasurableSet (K j))
    (ζ : Ω → Ambient n) (A : Set (Ambient n)) (g : Lp ℂ 2 μ)
    (hg : HasFrequencySupport μ ζ A g) (j : Fin m) :
    HasFrequencySupport μ ζ A (finiteCoverInput μ K hK g j) := by
  filter_upwards [finiteCoverInput_coe μ K hK g j, hg] with x hx hs hn
  apply hs
  intro hz
  apply hn
  rw [hx]
  by_cases hm : x ∈ disjointed K j
  · rw [indicator_of_mem hm, hz]
  · exact indicator_of_notMem hm _

/-- Transferring a chart input to its chart measure preserves the original
strip support, not only membership in the original surface. -/
theorem atlasPatchInput_inherits_support {n m : ℕ} (μ : Measure (Ambient n))
    (S : Set (Ambient n)) (hS : MeasurableSet S)
    (K : Fin m → Set (Ambient n)) (hK : ∀ j, MeasurableSet (K j))
    (A : Set (Ambient n)) (g : Lp ℂ 2 (μ.restrict S))
    (hg : HasFrequencySupport (μ.restrict S) id A g) (j : Fin m) :
    HasFrequencySupport (μ.restrict (K j)) id A (atlasPatchInput μ S hS K hK g j) := by
  have hs := zeroExtendL2_frequency_support μ S hS id A _
    (finiteCoverInput_inherits_support (μ.restrict S) K hK id A g hg j)
  have hr := hs.filter_mono (ae_mono (Measure.restrict_le_self (μ := μ) (s := K j)))
  filter_upwards [restrictInputL2_coe μ (K j)
    (zeroExtendL2 μ S hS (finiteCoverInput (μ.restrict S) K hK g j)), hr] with x hx hfreq hn
  exact hfreq (fun hz => hn (hx.trans hz))

/-- Every actual chart-measure input costs at most the original L2 norm. -/
theorem atlasPatchInput_norm_le {n m : ℕ} (μ : Measure (Ambient n))
    (S : Set (Ambient n)) (hS : MeasurableSet S)
    (K : Fin m → Set (Ambient n)) (hK : ∀ j, MeasurableSet (K j))
    (g : Lp ℂ 2 (μ.restrict S)) (j : Fin m) :
    ‖atlasPatchInput μ S hS K hK g j‖ ≤ ‖g‖ := by
  have hs := (Finset.single_le_sum (fun i _ => sq_nonneg ‖atlasPatchInput μ S hS K hK g i‖)
    (Finset.mem_univ j)).trans (atlasPatchInput_energy μ S hS K hK g)
  nlinarith [norm_nonneg (atlasPatchInput μ S hS K hK g j), norm_nonneg g]

end N2Restriction

#print axioms N2Restriction.atlasPatchInput_inherits_support
#print axioms N2Restriction.atlasPatchInput_norm_le
#print axioms N2Restriction.finiteCoverInput_inherits_support
