import continuation.ActualTangentSumV48
import continuation.ActualSquareComponentV48
import continuation.PointwiseBallOverlapV48
import continuation.PositiveBallOverlapV48

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal

/-- The actual positive tangent sum is bounded by the product of the exact
square functions in (7.14), with only the fixed overlap and binary-choice cost. -/
theorem actualTangentSum_square_majorant {d k L : ℕ} {S : Fin k → SmoothPatch (d+1)}
    (A : (i : Fin k) → PacketGraphAtlas (S i)) {r : ℝ}
    (Q : (i : Fin k) → (j : Fin (A i).size) → CoordinateCapFamily ((A i).patch j).support r)
    (hr : 0 < r)
    (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure)
    (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin d → ℤ))
    (Z : Set (Ambient (d+1))) (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1)))
    (c : Fin L → Ambient (d+1)) (ρ b C₀ R w : ℝ) (Ω : Set (Ambient (d+1)))
    {θ : ℝ} (hρ : 0 < ρ) (hθ : 0 < θ)
    (hsep : ∀ l t, l ≠ t → 2*(θ*ρ) ≤ dist (c l) (c t)) (x : Ambient (d+1)) :
    actualTangentSum A Q hr f U Z T c ρ b C₀ R w Ω x ≤
      ENNReal.ofReal ((1/θ+1)^(d+1)) * ((2^k : ENNReal) *
        ∏ i, ((A i).actualRetainedSquare (Q i) hr (f i) (U i) Z T c ρ b C₀ R w Ω x)^(1/2 : ℝ)) := by
  apply positive_ball_sum_bound_at hρ hθ c hsep Ω _ _ x
  intro l hx
  apply binary_nonzero_sum_bound
  intro σ
  have hh := Finset.prod_le_prod' (fun i (_ : i ∈ Finset.univ) =>
    (A i).actual_retained_extension_le_square (Q i) hr (f i) (U i) Z T c ρ b C₀ R w Ω l (σ i) x hx.2)
  simpa [extensionProduct,enorm_eq_nnnorm] using hh

end N2Restriction
#print axioms N2Restriction.actualTangentSum_square_majorant
