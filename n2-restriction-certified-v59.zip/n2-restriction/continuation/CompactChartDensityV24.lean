import continuation.UniformChartSeparationV24
import N2Restriction.HausdorffDensity

namespace N2Restriction
open MeasureTheory Metric Set
open scoped ENNReal NNReal

/-- Hausdorff measure pulled back by a bi-Lipschitz compact chart is bounded
above and below by fixed multiples of restricted Euclidean coordinate measure. -/
theorem compact_chart_hausdorff_comparison {d n : ℕ}
    (K : Set (Ambient d)) (hK : IsCompact K) (φ : K → Ambient n)
    {L A : ℝ≥0} (hA : 0 < A) (hLip : LipschitzWith L φ) (hAnti : AntilipschitzWith A φ) :
    (((A ^ d)⁻¹ * coordinateHausdorffFactor d : ℝ≥0) : ℝ≥0∞) •
        ((volume : Measure (Ambient d)).comap (Subtype.val : K → Ambient d)) ≤
      (Measure.hausdorffMeasure (d : ℝ)).comap φ ∧
    (Measure.hausdorffMeasure (d : ℝ)).comap φ ≤
      ((L ^ d * coordinateHausdorffFactor d : ℝ≥0) : ℝ≥0∞) •
        ((volume : Measure (Ambient d)).comap (Subtype.val : K → Ambient d)) := by
  letI : CompactSpace K := isCompact_iff_compactSpace.mp hK
  have he := (hAnti.isClosedEmbedding hLip.uniformContinuous).measurableEmbedding
  have hv := hK.isClosed.isClosedEmbedding_subtypeVal.measurableEmbedding
  have hcoord : ∀ s : Set K, (Measure.hausdorffMeasure (d : ℝ)) s =
      (coordinateHausdorffFactor d : ℝ≥0∞) *
        ((volume : Measure (Ambient d)).comap (Subtype.val : K → Ambient d)) s := by
    intro s
    rw [hv.comap_apply]
    rw [← isometry_subtype_coe.hausdorffMeasure_image (Or.inl (Nat.cast_nonneg d)) s,
      coordinate_hausdorff_eq_volume]
    rfl
  constructor
  · intro s
    rw [Measure.smul_apply, smul_eq_mul, ENNReal.coe_mul, ENNReal.coe_inv (pow_ne_zero _ hA.ne'), ENNReal.coe_pow,
      mul_assoc, ← hcoord, he.comap_apply]
    apply (ENNReal.inv_mul_le_iff (pow_ne_zero _ (by exact_mod_cast hA.ne'))
      (ENNReal.pow_ne_top ENNReal.coe_ne_top)).mpr
    simpa only [ENNReal.rpow_natCast] using hAnti.le_hausdorffMeasure_image (Nat.cast_nonneg d) s
  · intro s
    rw [Measure.smul_apply, smul_eq_mul, ENNReal.coe_mul, ENNReal.coe_pow,
      mul_assoc, ← hcoord, he.comap_apply]
    simpa only [ENNReal.rpow_natCast] using hLip.hausdorffMeasure_image_le (Nat.cast_nonneg d) s

/-- The compact chart has an actual measurable positive bounded density,
and this density pushes forward to Hausdorff measure on its image. The
density is obtained by measure comparison, not identified with a Gram formula. -/
theorem exists_compact_chart_surface_density {d n : ℕ}
    (K : Set (Ambient d)) (hK : IsCompact K) (φ : K → Ambient n)
    {L A : ℝ≥0} (hA : 0 < A) (hLip : LipschitzWith L φ) (hAnti : AntilipschitzWith A φ) :
    let μ := (volume : Measure (Ambient d)).comap (Subtype.val : K → Ambient d)
    ∃ J : K → ℝ≥0, Measurable J ∧
      (∀ᵐ x ∂μ, (A ^ d)⁻¹ * coordinateHausdorffFactor d ≤ J x ∧
        J x ≤ L ^ d * coordinateHausdorffFactor d) ∧
      μ.withDensity (fun x => (J x : ℝ≥0∞)) = (Measure.hausdorffMeasure (d : ℝ)).comap φ ∧
      (μ.withDensity (fun x => (J x : ℝ≥0∞))).map φ =
        (Measure.hausdorffMeasure (d : ℝ)).restrict (range φ) := by
  letI : CompactSpace K := isCompact_iff_compactSpace.mp hK
  let μ := (volume : Measure (Ambient d)).comap (Subtype.val : K → Ambient d)
  let ν := (Measure.hausdorffMeasure (d : ℝ)).comap φ
  have hv := hK.isClosed.isClosedEmbedding_subtypeVal.measurableEmbedding
  have hμfin : μ Set.univ < ⊤ := by
    dsimp [μ]
    rw [hv.comap_apply]
    simpa using hK.measure_lt_top (μ := (volume : Measure (Ambient d)))
  letI : IsFiniteMeasure μ := ⟨hμfin⟩
  have hcomp := compact_chart_hausdorff_comparison K hK φ hA hLip hAnti
  letI : SigmaFinite (((L ^ d * coordinateHausdorffFactor d : ℝ≥0) : ℝ≥0∞) • μ) :=
    inferInstanceAs (SigmaFinite ((L ^ d * coordinateHausdorffFactor d) • μ))
  letI : SigmaFinite ν := Measure.sigmaFinite_of_le _ hcomp.2
  obtain ⟨J, hJ, hb, heq⟩ := exists_bounded_density μ ν _ _ hcomp.1 hcomp.2
  refine ⟨J, hJ, hb, heq, ?_⟩
  rw [heq]
  exact (hAnti.isClosedEmbedding hLip.uniformContinuous).measurableEmbedding.map_comap _

end N2Restriction

#print axioms N2Restriction.compact_chart_hausdorff_comparison
#print axioms N2Restriction.exists_compact_chart_surface_density
