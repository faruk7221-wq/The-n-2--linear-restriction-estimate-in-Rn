import continuation.CauchyKernelV56
import continuation.UnsignedStationarySublevelV55
namespace N2Restriction
open Set MeasureTheory
set_option maxHeartbeats 1000000

/-- Fundamental theorem of calculus for the actual Cauchy kernel composed
with a real C1 function. No substitution or oscillatory estimate is assumed. -/
theorem cauchyKernel_derivative_integral {e : ℝ} (he : 0 < e)
    (g : ℝ → ℝ) (hg : ContDiff ℝ 1 g) (a b : ℝ) :
    (∫ t in a..b, cauchyKernel e (g t)*deriv g t) =
      cauchyPrimitive e (g b)-cauchyPrimitive e (g a) := by
  have hd := hg.differentiable (by norm_num)
  have hi : IntervalIntegrable (fun t => cauchyKernel e (g t)*deriv g t) volume a b :=
    (((continuous_cauchyKernel he).comp hg.continuous).mul
      (hg.continuous_deriv (by norm_num))).intervalIntegrable a b
  exact intervalIntegral.integral_eq_sub_of_hasDerivAt
    (fun t _ => (hasDerivAt_cauchyPrimitive he (g t)).comp t (hd t).hasDerivAt) hi

/-- Kernel times the absolute derivative has a uniform pi/e integral bound
on every interval where the derivative is separated from zero. Its sign
is established internally from continuity and connectedness. -/
theorem cauchyKernel_abs_derivative_integral_le {e c : ℝ} (he : 0 < e) (hc : 0 < c)
    (g : ℝ → ℝ) (hg : ContDiff ℝ 1 g) (a b : ℝ) (hab : a ≤ b)
    (hcurved : ∀ t ∈ Icc a b, c ≤ |deriv g t|) :
    (∫ t in a..b, cauchyKernel e (g t)*|deriv g t|) ≤ Real.pi/e := by
  rcases continuous_separated_sign (convex_Icc a b).isPreconnected
    (hg.continuous_deriv (by norm_num)).continuousOn hc hcurved with hp | hn
  · have hEq : (∫ t in a..b, cauchyKernel e (g t)*|deriv g t|) =
        ∫ t in a..b, cauchyKernel e (g t)*deriv g t := by
      apply intervalIntegral.integral_congr
      intro t ht
      rw [uIcc_of_le hab] at ht
      dsimp only
      rw [abs_of_nonneg ((le_of_lt hc).trans (hp t ht))]
    rw [hEq,cauchyKernel_derivative_integral he g hg a b]
    exact cauchyPrimitive_increment_le he _ _
  · have hEq : (∫ t in a..b, cauchyKernel e (g t)*|deriv g t|) =
        ∫ t in a..b, cauchyKernel e (-g t)*deriv (fun s => -g s) t := by
      apply intervalIntegral.integral_congr
      intro t ht
      rw [uIcc_of_le hab] at ht
      dsimp only
      rw [abs_of_nonpos (le_trans (hn t ht) (by linarith)),deriv.fun_neg]
      simp only [cauchyKernel,neg_sq]
    rw [hEq,cauchyKernel_derivative_integral he (fun s => -g s) hg.neg a b]
    exact cauchyPrimitive_increment_le he _ _

/-- Curvature converts the kernel-variation bound into an actual small
stationary remainder integral, with size pi/(c*e). -/
theorem cauchyKernel_integral_le {e c : ℝ} (he : 0 < e) (hc : 0 < c)
    (g : ℝ → ℝ) (hg : ContDiff ℝ 1 g) (a b : ℝ) (hab : a ≤ b)
    (hcurved : ∀ t ∈ Icc a b, c ≤ |deriv g t|) :
    (∫ t in a..b, cauchyKernel e (g t)) ≤ (Real.pi/e)/c := by
  have hK := (continuous_cauchyKernel he).comp hg.continuous
  have hKg := hK.mul (hg.continuous_deriv (by norm_num)).abs
  have hmono := intervalIntegral.integral_mono_on (μ := volume) hab
    ((continuous_const.mul hK).intervalIntegrable a b) (hKg.intervalIntegrable a b)
    (fun t ht => by
      have h := mul_le_mul_of_nonneg_left (hcurved t ht) (cauchyKernel_nonneg he (g t))
      simpa only [mul_comm] using h)
  rw [intervalIntegral.integral_const_mul] at hmono
  apply (le_div_iff₀ hc).mpr
  have hmono' : (∫ t in a..b, cauchyKernel e (g t))*c ≤
      ∫ t in a..b, cauchyKernel e (g t)*|deriv g t| := by simpa only [mul_comm] using hmono
  exact hmono'.trans (cauchyKernel_abs_derivative_integral_le he hc g hg a b hab hcurved)
end N2Restriction
#print axioms N2Restriction.cauchyKernel_derivative_integral
#print axioms N2Restriction.cauchyKernel_abs_derivative_integral_le
#print axioms N2Restriction.cauchyKernel_integral_le
