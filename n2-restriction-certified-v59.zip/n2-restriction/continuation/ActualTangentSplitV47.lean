import continuation.ActualNontangentSelectionV47
import continuation.AtlasCellExtensionV42

namespace N2Restriction
open MeasureTheory Set Metric

/-- Original stage packets retained in a covering ball. -/
def PacketGraphAtlas.actualRetainedSelection {d : ℕ} {S : SmoothPatch (d+1)}
    (A : PacketGraphAtlas S) {r : ℝ}
    (Q : (j : Fin A.size) → CoordinateCapFamily (A.patch j).support r)
    (U : (j : Fin A.size) → (Q j).centers → Set (Fin d → ℤ))
    (c : Ambient (d+1)) (ρ R w : ℝ) (Ω : Set (Ambient (d+1))) :
    (j : Fin A.size) → (Q j).centers → Set (Fin d → ℤ) :=
  fun j a => {ν | ν ∈ U j a ∧
    (A.originalPacketTube j a r ν R w ∩ (Ω ∩ ball c ρ)).Nonempty}

/-- The tangent half of the retained original packets, using (7.1). -/
def PacketGraphAtlas.actualTangentSelection {d : ℕ} {S : SmoothPatch (d+1)}
    (A : PacketGraphAtlas S) {r : ℝ}
    (Q : (j : Fin A.size) → CoordinateCapFamily (A.patch j).support r)
    (U : (j : Fin A.size) → (Q j).centers → Set (Fin d → ℤ))
    (Z : Set (Ambient (d+1))) (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1)))
    (c : Ambient (d+1)) (ρ b C₀ R w : ℝ) (Ω : Set (Ambient (d+1))) :
    (j : Fin A.size) → (Q j).centers → Set (Fin d → ℤ) :=
  fun j a => A.actualRetainedSelection Q U c ρ R w Ω j a ∩
    {ν | PacketTangentInBall Z (A.originalPacketTube j a r ν R w) T
      (A.cellAxisDirection j a) c ρ b C₀}

/-- The actual retained L2 input is exactly its tangent plus nontangent
input. Infinite packet sums introduce no additional error in this split. -/
theorem PacketGraphAtlas.actual_retained_input_split {d : ℕ} {S : SmoothPatch (d+1)}
    (A : PacketGraphAtlas S) {r : ℝ}
    (Q : (j : Fin A.size) → CoordinateCapFamily (A.patch j).support r) (hr : 0 < r)
    (f : (j : Fin A.size) → Lp ℂ 2 (A.graph j).surfaceMeasure)
    (U : (j : Fin A.size) → (Q j).centers → Set (Fin d → ℤ))
    (Z : Set (Ambient (d+1))) (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1)))
    (c : Ambient (d+1)) (ρ b C₀ R w : ℝ) (Ω : Set (Ambient (d+1))) :
    A.cellInput Q hr f (A.actualRetainedSelection Q U c ρ R w Ω) =
      A.cellInput Q hr f (A.actualTangentSelection Q U Z T c ρ b C₀ R w Ω) +
      A.cellInput Q hr f (A.actualNontangentSelection Q U Z T c ρ b C₀ R w Ω) := by
  have h := A.cellInput_split Q hr f (A.actualRetainedSelection Q U c ρ R w Ω)
    (fun j a => {ν | PacketTangentInBall Z (A.originalPacketTube j a r ν R w) T
      (A.cellAxisDirection j a) c ρ b C₀})
  convert h using 1
  congr 1
  congr 1
  funext j a
  ext ν
  simp only [actualNontangentSelection,actualRetainedSelection,mem_setOf_eq,mem_diff,and_assoc]

/-- The exact tangent split also holds pointwise after applying extension. -/
theorem PacketGraphAtlas.actual_retained_extension_split {d : ℕ} {S : SmoothPatch (d+1)}
    (A : PacketGraphAtlas S) {r : ℝ}
    (Q : (j : Fin A.size) → CoordinateCapFamily (A.patch j).support r) (hr : 0 < r)
    (hsmall : r ≤ A.capRadius)
    (f : (j : Fin A.size) → Lp ℂ 2 (A.graph j).surfaceMeasure)
    (U : (j : Fin A.size) → (Q j).centers → Set (Fin d → ℤ))
    (Z : Set (Ambient (d+1))) (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1)))
    (c : Ambient (d+1)) (ρ b C₀ R w : ℝ) (Ω : Set (Ambient (d+1))) (x : Ambient (d+1)) :
    extension (Measure.hausdorffMeasure (d : ℝ)) id
      (A.cellInput Q hr f (A.actualRetainedSelection Q U c ρ R w Ω)) x =
    extension (Measure.hausdorffMeasure (d : ℝ)) id
      (A.cellInput Q hr f (A.actualTangentSelection Q U Z T c ρ b C₀ R w Ω)) x +
    extension (Measure.hausdorffMeasure (d : ℝ)) id
      (A.cellInput Q hr f (A.actualNontangentSelection Q U Z T c ρ b C₀ R w Ω)) x := by
  rw [A.actual_retained_input_split Q hr f U Z T c ρ b C₀ R w Ω]
  exact extension_L2_add _ _ _ (A.cellInput_integrable Q hr hsmall f _)
    (A.cellInput_integrable Q hr hsmall f _) x

end N2Restriction
#print axioms N2Restriction.PacketGraphAtlas.actual_retained_input_split
#print axioms N2Restriction.PacketGraphAtlas.actual_retained_extension_split
