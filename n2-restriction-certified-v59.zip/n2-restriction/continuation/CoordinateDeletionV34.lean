import continuation.FrameProjectionStabilityV33

namespace N2Restriction
open scoped BigOperators

noncomputable def coordinateDeletion {ι : Type*} [Fintype ι] {n : ℕ}
    (e : (ι → ℝ) ≃L[ℝ] Ambient n) (i : ι) :
    Ambient n →L[ℝ] ({j : ι // j ≠ i} → ℝ) :=
  ContinuousLinearMap.pi (fun j => (ContinuousLinearMap.proj j.val).comp e.symm.toContinuousLinearMap)

theorem coordinateDeletion_norm_le {ι : Type*} [Fintype ι] [DecidableEq ι] {n : ℕ}
    (e : (ι → ℝ) ≃L[ℝ] Ambient n) (i : ι) :
    ‖coordinateDeletion e i‖ ≤ ‖e.symm.toContinuousLinearMap‖ := by
  apply ContinuousLinearMap.opNorm_le_bound _ (norm_nonneg _)
  intro x
  apply (pi_norm_le_iff_of_nonneg (mul_nonneg (norm_nonneg _) (norm_nonneg _))).mpr
  intro j
  exact (norm_le_pi_norm (e.symm x) j.val).trans (e.symm.toContinuousLinearMap.le_opNorm x)

theorem coordinateDeletion_ker {ι : Type*} [Fintype ι] [DecidableEq ι] {n : ℕ}
    (v : ι → Ambient n) (e : (ι → ℝ) ≃L[ℝ] Ambient n)
    (he : ∀ x, e x = ∑ j, x j • v j) (i : ι) :
    LinearMap.ker (coordinateDeletion e i).toLinearMap = Submodule.span ℝ {v i} := by
  ext x
  change (coordinateDeletion e i x = 0) ↔ x ∈ Submodule.span ℝ {v i}
  rw [Submodule.mem_span_singleton]
  constructor
  · intro hx
    refine ⟨e.symm x i, ?_⟩
    have hz (j : ι) (hji : j ≠ i) : e.symm x j = 0 := congrFun hx ⟨j,hji⟩
    have hs := he (e.symm x)
    rw [e.apply_symm_apply, Finset.sum_eq_single i] at hs
    · exact hs.symm
    · intro j _ hji
      rw [hz j hji, zero_smul]
    · simp
  · rintro ⟨a,rfl⟩
    have hs : e (Pi.single i a) = a • v i := by simp [he]
    rw [← hs]
    ext j
    change e.symm (e (Pi.single i a)) j.val = 0
    rw [e.symm_apply_apply]
    simp [j.property]

theorem coordinateDeletion_bounded_preimages {ι : Type*} [Fintype ι] [DecidableEq ι] {n : ℕ}
    (e : (ι → ℝ) ≃L[ℝ] Ambient n) (i : ι) (y : {j : ι // j ≠ i} → ℝ) :
    ∃ x, coordinateDeletion e i x = y ∧ ‖x‖ ≤ ‖e.toContinuousLinearMap‖ * ‖y‖ := by
  let c : ι → ℝ := fun j => if h : j ≠ i then y ⟨j,h⟩ else 0
  refine ⟨e c, ?_, ?_⟩
  · ext j
    change e.symm (e c) j.val = y j
    simp [c, j.property]
  · refine (e.toContinuousLinearMap.le_opNorm c).trans ?_
    apply mul_le_mul_of_nonneg_left _ (norm_nonneg _)
    apply (pi_norm_le_iff_of_nonneg (norm_nonneg y)).mpr
    intro j
    change ‖(if h : j ≠ i then y ⟨j,h⟩ else 0)‖ ≤ ‖y‖
    split_ifs with h
    · exact norm_le_pi_norm y ⟨j,h⟩
    · simp

end N2Restriction

#print axioms N2Restriction.coordinateDeletion_bounded_preimages
#print axioms N2Restriction.coordinateDeletion_ker
#print axioms N2Restriction.coordinateDeletion_norm_le
