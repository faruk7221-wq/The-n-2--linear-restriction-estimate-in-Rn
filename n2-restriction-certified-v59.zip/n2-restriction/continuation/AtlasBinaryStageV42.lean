import continuation.AtlasBinarySelectionV42
import continuation.StageInputReplacementV42

namespace N2Restriction
open MeasureTheory
open scoped BigOperators ENNReal

/-- The actual near/far packet selection gives a genuine stage with reset
inputs and mass constant at most the prescribed 2^k update. -/
theorem atlas_binary_input_stage {d k m : ℕ} (S : Fin k → SmoothPatch (d+1))
    (T : (i : Fin k) → PacketGraphAtlas (S i)) {r : ℝ} (hr : 0 < r)
    (Q : (i : Fin k) → (j : Fin (T i).size) → CoordinateCapFamily ((T i).patch j).support r)
    (hsmall : ∀ i, r ≤ (T i).capRadius)
    (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure)
    (U V : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ))
    {p R width : ℝ} {M₀ err : ENNReal} (hp : 0 < p) (hp1 : p ≤ 1)
    (W : PolynomialStage (fun _ => Measure.hausdorffMeasure (d : ℝ))
      (fun i => (T i).cellInput (Q i) hr (f i) (U i)) p R width M₀ err m) :
    ∃ σ : Fin k → Bool,
    ∃ W' : PolynomialStage (fun _ => Measure.hausdorffMeasure (d : ℝ))
      (fun i => (T i).binaryCellInput (Q i) hr (f i) (U i) (V i) (σ i)) p R width M₀ err m,
      W'.equations = W.equations ∧ W'.degreeBound = W.degreeBound ∧
      W'.region = W.region ∧ W'.multiplier = W.multiplier ∧
      W'.constant = max 1 (W.constant*(2^k : ENNReal)) := by
  obtain ⟨σ, hσ⟩ := atlas_binary_mass_selection S T hr Q hsmall f U V W.region hp hp1
  exact ⟨σ, polynomial_stage_replace_inputs W (2^k : ENNReal) (by simp) hσ⟩

end N2Restriction
#print axioms N2Restriction.atlas_binary_input_stage
