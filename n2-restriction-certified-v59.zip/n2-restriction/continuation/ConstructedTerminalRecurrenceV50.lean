import continuation.TerminalSelectedRecurrenceV50
import continuation.UniformAtlasCapsV45
import continuation.AtlasSupportedDecompositionV44
import continuation.SeparatedBallOverlapV47
namespace N2Restriction
open MeasureTheory Set Metric Filter
open scoped ENNReal NNReal
set_option maxHeartbeats 600000

/-- Terminal selected-product recurrence starting from arbitrary admissible
original inputs: cap families, separated covering balls and original chart
inputs with their parent margins are constructed internally. -/
theorem exists_constructed_terminal_selected_recurrence {k : ℕ} (hk : 3 ≤ k)
    (P : Fin k → SmoothPatch (k+2)) {ν κ : ℝ} (hgeo : GeometricHypotheses P ν κ)
    (hKexternal : WeightedKakeyaExternalGoal (k+2) k)
    {ε τ lam : ℝ} (hε : 0 < ε) (hτ : 0 < τ) (hτ' : τ < 1/4) (hlam : 1 ≤ lam) :
    ∃ ι Cext : ℝ, 0 < ι ∧ 0 ≤ Cext ∧ ∃ Dsub : ∀ i, DirectionalSubdivision (P i) ι,
    ∀ (a : ∀ i, Fin (Dsub i).size) (A : (i : Fin k) → PacketGraphAtlas ((fun i => (Dsub i).piece (a i)) i))
    (B : ArticleLocalizationAtlas (fun i => (Dsub i).piece (a i)) κ)
    (V : Fin k → Set (Ambient (k+2))) (m : ℝ)
    (_hS : ∀ i, ((fun i => (Dsub i).piece (a i)) i).extendedSurface ∩ V i ⊆ ((fun i => (Dsub i).piece (a i)) i).support) (_hm : 0 < m)
    (_hexternal : B.UniformLocalizedInput (baseline (k : ℝ)))
    (C C₀ : ℝ)
    (_hC : 1 ≤ C) (_hC₀ : 1+Real.sqrt (k+2 : ℕ)*(1+C)/2 ≤ C₀),

    ∀ Mcover : ℕ, ∀ Kcover : ℝ, 0 ≤ Kcover →
    ∀ p : ℝ, critical (k : ℝ) < p → p < baseline (k : ℝ) →
    ∃ Bcap : ℝ, 0 ≤ Bcap ∧ ∃ K : ENNReal, K ≠ ∞ ∧ ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ R : ℝ, R₀ ≤ R →
    ∃ (Q : (i : Fin k) → (j : Fin (A i).size) →
      CoordinateCapFamily ((A i).patch j).support (R^(-1/2 : ℝ)))
      (L : ℕ) (c : Fin L → Ambient (k+2)),
    (∀ i, R^(-1/2 : ℝ) ≤ (A i).capRadius) ∧
    (∀ i j, ((Q i j).centers.card : ℝ) ≤ Bcap*R^(((k+1 : ℕ) : ℝ)/2)) ∧
    (closedBall 0 R ⊆ ⋃ l, ball (c l) (R^(1-τ))) ∧
    (∀ l t, l ≠ t → 2*((1/(2*Real.sqrt (k+2 : ℕ)))*(R^(1-τ))) ≤ dist (c l) (c t)) ∧
    ∀ (g : (i : Fin k) → Lp ℂ 2 ((Dsub i).piece (a i)).surfaceMeasure),
    MarginAdmissible (fun i => ((Dsub i).piece (a i)).surfaceMeasure) (fun _ => id) V m R (fun i => g i) →
    ∃ f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure,
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) ∧
    (∀ i j, HasFrequencySupport ((A i).graph j).surfaceMeasure id
      (((A i).graph j).parametrization '' ((A i).patch j).support) (f i j)) ∧
    (∀ i j, HasFrequencySupport ((A i).graph j).surfaceMeasure ((A i).patch j).rotation
      (marginRegion (V i) (m-R^(-1/4 : ℝ))) (f i j)) ∧
    (∀ i x, (∑ j, extension ((A i).graph j).surfaceMeasure ((A i).patch j).rotation (f i j) x) =
      extension ((Dsub i).piece (a i)).surfaceMeasure id (g i) x) ∧
    ∀ (hr : 0 < R^(-1/2 : ℝ))
      (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin (k+1) → ℤ))
      (mvar : ℕ) (equations : Fin mvar → MvPolynomial (Fin (k+2)) ℝ)
      (cuts : Set (Ambient (k+2))) (V₀ : Submodule ℝ (Ambient (k+2))) (near : Finset (Fin k))
      (Ω : Set (Ambient (k+2))),
    (∀ z, polynomialLevelMap equations z = 0 →
      Function.Surjective (fderiv ℝ (polynomialLevelMap equations) z)) →
    (k+2)-mvar+nearᶜ.card = k →
    (∀ i ∈ near, directionPlaneAngle ((P i).normal ((Dsub i).anchor (a i))) V₀ ≤ 4*ι) →
    Ω ⊆ thickening (lam*R^(1/2+τ)) (planeWitnessSet equations cuts V₀ (2*ι)) →
    MeasurableSet Ω → Ω ⊆ closedBall 0 R →
    UniformAlgebraicTubeCoverInput {z | polynomialLevelMap equations z = 0}
      (fun z => LinearMap.ker (fderiv ℝ (polynomialLevelMap equations) z).toLinearMap) Mcover Kcover →
    positiveNorm
      (fun x => ‖extensionProduct (fun _ => Measure.hausdorffMeasure ((k+1 : ℕ) : ℝ)) (fun _ => id)
        (fun i => (A i).cellInput (Q i) hr (f i) (U i)) x‖ₑ) p (volume.restrict Ω) ≤
      K*(marginLocalConstant (fun i => ((Dsub i).piece (a i)).surfaceMeasure) (fun _ => id) V m p (R^(1-τ)) +
        ENNReal.ofReal (R^(sigma (k : ℝ) τ ε)))*∏ i, ENNReal.ofReal ‖g i‖ := by
  classical
  obtain ⟨ι,Cext,hι,hCext,Dsub,hb⟩ := exists_subdivision_terminal_selected_recurrence hk P hgeo hKexternal
    hε hτ hτ' hlam
  refine ⟨ι,Cext,hι,hCext,Dsub,?_⟩
  intro a A B V m hS hm hexternal C C₀ hC hC₀ Mcover Kcover hKcover p hpc hpb
  obtain ⟨Bcap,hBcap,Rc,hRc,hcaps⟩ := exists_uniform_atlas_packet_caps (fun i => (Dsub i).piece (a i)) A
  let θ : ℝ := 1/(2*Real.sqrt (k+2 : ℕ))
  have hθ : 0 < θ := by dsimp [θ]; positivity
  obtain ⟨K,hK,R₀,hR₀,hbound⟩ := hb a A B V m hS hm hexternal C C₀ θ Bcap hC hC₀ hθ hBcap
    Mcover Kcover hKcover p hpc hpb
  refine ⟨Bcap,hBcap,K,hK,max R₀ Rc,hR₀.trans (le_max_left _ _),?_⟩
  intro R hR
  have hR0 := (le_max_left R₀ Rc).trans hR
  have hRcR := (le_max_right R₀ Rc).trans hR
  obtain ⟨hsmall,Q,hcount⟩ := hcaps R hRcR
  have hRpos : 0 < R := zero_lt_one.trans_le (hR₀.trans hR0)
  have hρ : 0 < R^(1-τ) := Real.rpow_pos_of_pos hRpos _
  obtain ⟨L,c,hcover,hsep,_hoverlap⟩ := exists_bounded_overlap_ball_cover (by omega : 0 < k+2) hρ R
  refine ⟨Q,L,c,hsmall,hcount,hcover,hsep,?_⟩
  intro g hg
  choose f he hs hf hx using fun i => (A i).input_decomposition_supported (g i) _ (hg i)
  refine ⟨f,he,hs,hf,hx,?_⟩
  intro hr U mvar equations cuts V₀ near Ω hregular hterminal hnear hplane hΩ hΩR hAlg
  exact hbound R hR0 Q hr hsmall hcount g f he hf L U mvar equations cuts V₀ near c Ω
    hregular hterminal hnear hplane hsep hΩ hΩR (hΩR.trans hcover) hAlg

end N2Restriction
#print axioms N2Restriction.exists_constructed_terminal_selected_recurrence
