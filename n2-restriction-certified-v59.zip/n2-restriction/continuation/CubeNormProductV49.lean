import continuation.CellKakeyaEnergyV49

namespace N2Restriction
open MeasureTheory Set
open scoped ENNReal

/-- Convert the squared L2 cube budget to every nonnegative power,
including the quasi-Banach exponents used in Section 7. -/
theorem norm_power_le_energy_power {E : Type*} [NormedAddCommGroup E]
    (g : E) {B W : ENNReal} (h : ENNReal.ofReal (‖g‖^2) ≤ B*W)
    {p : ℝ} (hp : 0 ≤ p) :
    (ENNReal.ofReal ‖g‖)^p ≤ B^(p/2)*W^(p/2) := by
  have hh := ENNReal.rpow_le_rpow h (by positivity : 0 ≤ p/2)
  rw [ENNReal.ofReal_pow (norm_nonneg g),← ENNReal.rpow_natCast,← ENNReal.rpow_mul,
    show ((2 : ℕ) : ℝ)*(p/2) = p by push_cast; ring,ENNReal.mul_rpow_of_nonneg _ _ (by positivity : 0 ≤ p/2)] at hh
  exact hh

/-- All ball-dependent and binary cube cuts obey one product of cube energies.
The atlas coefficient precedes scales, inputs, cubes and further selections. -/
theorem atlas_cube_norm_product {d k : ℕ} (S : Fin k → SmoothPatch (d+1))
    (A : (i : Fin k) → PacketGraphAtlas (S i)) :
    ∃ B : ℝ, 0 ≤ B ∧ ∀ {r : ℝ}
      (Q : (i : Fin k) → (j : Fin (A i).size) → CoordinateCapFamily ((A i).patch j).support r)
      (hr : 0 < r)
      (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure)
      (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin d → ℤ))
      (R w C b : ℝ) (q : Ambient (d+1)),
    (∀ i j a ν, ν ∈ U i j a →
      (rotatedPacketTube ((A i).patch j).rotation (graphGradient ((A i).graph j).phase a)
        (r⁻¹ • latticeVector ν) R w ∩ gridCube q (C*b)).Nonempty) →
    ∀ p : ℝ, 0 ≤ p →
    (∏ i, (ENNReal.ofReal ‖(A i).cellInput (Q i) hr (f i) (U i)‖)^p) ≤
      (ENNReal.ofReal B)^(p/2) * (∏ i, (A i).cubeEnergy (Q i) hr (f i) R w C b q)^(p/2) := by
  choose B hB hb using fun i => (A i).cellInput_cube_norm_sq
  refine ⟨∏ i, B i,Finset.prod_nonneg (fun i _ => hB i),?_⟩
  intro r Q hr f U R w C b q hmeet p hp
  have hh := Finset.prod_le_prod' (fun i (_ : i ∈ Finset.univ) =>
    norm_power_le_energy_power _ (hb i (Q i) hr (f i) (U i) R w C b q (hmeet i)) hp)
  rw [Finset.prod_mul_distrib,ENNReal.prod_rpow_of_nonneg (by positivity : 0 ≤ p/2),
    ENNReal.prod_rpow_of_nonneg (by positivity : 0 ≤ p/2),
    ← ENNReal.ofReal_prod_of_nonneg (fun i _ => hB i)] at hh
  exact hh

end N2Restriction
#print axioms N2Restriction.norm_power_le_energy_power
#print axioms N2Restriction.atlas_cube_norm_product
