import continuation.ActualMulticapCellBudgetV41
import continuation.CellPacketBudgetsV38

namespace N2Restriction
open MeasureTheory UnitAddTorus Set
open scoped BigOperators ENNReal
noncomputable local instance labelledCellCircleMeasure : MeasureSpace UnitAddCircle := ⟨AddCircle.haarAddCircle⟩

/-- Label incidence for actual graph-packet sums, simultaneously across caps. -/
theorem actual_labelled_cell_budget {d m : ℕ} {J : Type*} [Fintype J]
    (c : J → Ambient d) (r : ℝ) (hr : 0 < r)
    (f : (j : J) → Lp ℂ 2 (volume.restrict (packetFrequencyCube (c j) r hr)))
    (A : J → Set (Fin d → ℤ)) (L : J → (Fin d → ℤ) → Finset (Fin m → Bool))
    {M : ℝ} (hM : 0 ≤ M)
    (hoverlap : ∀ᵐ y ∂(volume : Measure (Ambient d)),
      (∑ j, (Metric.ball (c j) (2*r)).indicator (fun _ => (1 : ℝ)) y) ≤ M)
    (N E₀ : ENNReal) (hlabels : ∀ j ν, ν ∈ A j → ((L j ν).card : ENNReal) ≤ N)
    (henergy : (∑ j, ENNReal.ofReal (‖f j‖^2)) ≤ E₀) :
    (∑' σ : Fin m → Bool, ENNReal.ofReal (‖∑ j,
      ∑' ν : {ν // ν ∈ A j ∧ σ ∈ L j ν}, actualPacketInput (c j) r hr (f j) ν.val‖^2)) ≤
        ENNReal.ofReal M*N*E₀ := by
  apply actual_multicap_cell_budget c r hr f (fun σ j => {ν | ν ∈ A j ∧ σ ∈ L j ν})
    hM hoverlap N E₀ _ henergy
  intro j ν
  rw [cell_label_incidence]
  split_ifs with hν
  · exact hlabels j ν hν
  · exact zero_le _

end N2Restriction
#print axioms N2Restriction.actual_labelled_cell_budget
