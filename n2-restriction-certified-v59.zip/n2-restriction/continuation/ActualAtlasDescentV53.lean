import continuation.GroupedAtlasStepV53
import continuation.FiniteAtlasPacketDescentV53
namespace N2Restriction
open Set Metric MeasureTheory
open scoped BigOperators ENNReal
set_option maxHeartbeats 1800000

/-- Actual finite Section 6 iteration, relative only to explicit borrowed
geometric inputs. The grouped step is proved, not assumed. A single finite
budget and cellular error envelope precede R; termination gives the cellular
mass estimate, a genuine dimension-zero stage, or a prepared terminal stage. -/
theorem uniform_actual_atlas_descent {k : ℕ} (hk : 3 ≤ k)
    (hcutsExternal : UniformTangentCutsInput (k+2))
    (hpartitionExternal : UniformProjectedPartitionInput (k+2))
    (hcoverExternal : UniformPolynomialTubeCoverInput (k+2))
    (P : Fin k → SmoothPatch (k+2)) {ι γ : ℝ} (hι : 0 < ι)
    (hγ : 0 < γ) (hγsmall : 2*γ ≤ (1 : ℝ)/2) (hγι : γ ≤ ι/2)
    (Dsub : (i : Fin k) → DirectionalSubdivision (P i) ι)
    (b : (i : Fin k) → Fin (Dsub i).size)
    (hrank : ∀ (V : Submodule ℝ (Ambient (k+2))) (near : Finset (Fin k)),
      (∀ i ∈ near, directionPlaneAngle ((P i).normal ((Dsub i).anchor (b i))) V ≤ 4*ι) →
      k ≤ Module.finrank ℝ V+nearᶜ.card)
    (T : (i : Fin k) → PacketGraphAtlas ((Dsub i).piece (b i)))
    (Vfreq : Fin k → Set (Ambient (k+2))) (margin : ℝ) (hm : 0 < margin)
    (hW : ∀ i, ((Dsub i).piece (b i)).extendedSurface ∩ Vfreq i ⊆ ((Dsub i).piece (b i)).support)
    {τ c p : ℝ} (hτ : 0 < τ) (hc : 0 < c) (hp : 0 < p) (hp1 : p ≤ 1) (hpc : critical k < p) (Binit : PolynomialStageBudget) :
    ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∃ Bfinal : PolynomialStageBudget,
    Bfinal.width = 100^(k+2)*Binit.width ∧
    ∃ Krapid : ℝ → ENNReal, (∀ Bcap, Krapid Bcap ≠ ∞) ∧
    ∀ R : ℝ, R₀ ≤ R →
    ∀ (Q : (i : Fin k) → (j : Fin (T i).size) → CoordinateCapFamily ((T i).patch j).support (R^(-1/2 : ℝ)))
      (hr : 0 < R^(-1/2 : ℝ)), (∀ i, R^(-1/2 : ℝ) ≤ (T i).capRadius) →
    ∀ Bcap : ℝ, 0 ≤ Bcap → (∀ i j, ((Q i j).centers.card : ℝ) ≤ Bcap*R^(((k+1 : ℕ) : ℝ)/2)) →
    ∀ (g : (i : Fin k) → Lp ℂ 2 ((Dsub i).piece (b i)).surfaceMeasure)
      (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure),
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
    (∀ i j, HasFrequencySupport ((T i).graph j).surfaceMeasure ((T i).patch j).rotation
      (marginRegion (Vfreq i) (margin-R^(-1/4 : ℝ))) (f i j)) →
    ∀ (U₀ : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin (k+1) → ℤ))
      {M₀ err : ENNReal}
      (W₀ : PolynomialStage (fun _ => Measure.hausdorffMeasure ((k+1 : ℕ) : ℝ))
        (fun i => (T i).cellInput (Q i) hr (f i) (U₀ i)) p R (R^(1/2+τ)) M₀ err 0),
    W₀.withinBudget Binit →
    (M₀ ≤ ENNReal.ofReal c *
      (marginLocalConstant (fun i => ((Dsub i).piece (b i)).surfaceMeasure) (fun _ => id) Vfreq margin p (R/2))^p *
      (∏ i, ENNReal.ofReal ‖g i‖)^p + Krapid Bcap*(∏ i, ENNReal.ofReal ‖g i‖)^p + err) ∨
    (∃ m : ℕ, ∃ U : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin (k+1) → ℤ),
      (∀ i j a, U i j a ⊆ U₀ i j a) ∧
      ∃ W : PolynomialStage (fun _ => Measure.hausdorffMeasure ((k+1 : ℕ) : ℝ))
        (fun i => (T i).cellInput (Q i) hr (f i) (U i)) p R (R^(1/2+τ)) M₀ err m,
        W.withinBudget Bfinal ∧ (k+2)-m = 0) ∨
    (∃ m : ℕ, ∃ A : PreparedAtlasPacketStage (m := m) (fun i => (Dsub i).piece (b i)) T Q hr f U₀
      p R (R^(1/2+τ)) γ M₀ err Bfinal, m < k+2 ∧ (k+2)-m+A.nearᶜ.card = k) := by
  classical
  obtain ⟨R₀,hR₀,hsteps⟩ := uniform_grouped_atlas_step hk hcutsExternal hpartitionExternal hcoverExternal
    P hι hγ hγsmall hγι Dsub b hrank T Vfreq margin hm hW hτ hc hp hp1 hpc
  choose next hw hd hmnext Kr hKr hstep using hsteps
  let budgets := groupedBudgetSequence next Binit
  let Krapid : ℝ → ENNReal := fun Bcap => ∑ m ∈ Finset.range (k+2), Kr m (budgets m) Bcap
  have hK : ∀ Bcap, Krapid Bcap ≠ ∞ := by
    intro Bcap
    exact ENNReal.sum_ne_top.mpr (fun m _ => hKr m (budgets m) Bcap)
  refine ⟨R₀,hR₀,budgets (k+2),grouped_budget_sequence_width next Binit hw (k+2),Krapid,hK,?_⟩
  intro R hR Q hr hsmall Bcap hBcap hcount g f he hf U₀ M₀ err W₀ hB₀
  let Target : Prop := M₀ ≤ ENNReal.ofReal c *
      (marginLocalConstant (fun i => ((Dsub i).piece (b i)).surfaceMeasure) (fun _ => id) Vfreq margin p (R/2))^p *
      (∏ i, ENNReal.ofReal ‖g i‖)^p + Krapid Bcap*(∏ i, ENNReal.ofReal ‖g i‖)^p + err
  refine finite_atlas_packet_descent (fun i => (Dsub i).piece (b i)) T Q hr f U₀ Target next Binit hw hd hmnext
    ?_ 0 U₀ W₀ (fun _ _ _ => Set.Subset.rfl) hB₀
  intro m U W hB hmvar
  rcases hstep m (budgets m) R hR Q hr hsmall Bcap hBcap hcount g f he hf U W hB hmvar with hcell|ht|hc
  · left
    apply hcell.trans
    apply add_le_add_right
    apply add_le_add_left
    apply mul_le_mul_right'
    have hsum : Kr m (budgets m) Bcap ≤ Krapid Bcap :=
      Finset.single_le_sum (f := fun j => Kr j (budgets j) Bcap)
        (fun _ _ => zero_le _) (Finset.mem_range.mpr hmvar)
    exact hsum
  · obtain ⟨A,_,hterminal⟩ := ht
    exact Or.inr (Or.inl ⟨A,hterminal⟩)
  · obtain ⟨U',hU',W',_,hB'⟩ := hc
    exact Or.inr (Or.inr ⟨U',hU',W',hB'⟩)
end N2Restriction
#print axioms N2Restriction.uniform_actual_atlas_descent
