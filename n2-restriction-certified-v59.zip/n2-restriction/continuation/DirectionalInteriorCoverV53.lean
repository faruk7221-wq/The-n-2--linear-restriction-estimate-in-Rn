import continuation.DirectionalSubdivisionV22
namespace N2Restriction
open Set Metric MeasureTheory
set_option maxHeartbeats 500000

/-- Directional subdivision retaining the open cover that lies relatively
inside its compact pieces. This information must be carried through the
joint rank/Kakeya constructor for the remaining original-support transfer. -/
theorem SmoothPatch.exists_directionalSubdivision_with_relative_interiors {n : ℕ}
    (S : SmoothPatch n) {ε : ℝ} (hε : 0 < ε) :
    ∃ D : DirectionalSubdivision S ε,
    ∃ O : Fin D.size → Set (Ambient n),
      (∀ j, IsOpen (O j)) ∧ S.support ⊆ ⋃ j, O j ∧
      (∀ j, S.support ∩ O j ⊆ (D.piece j).support) := by
  classical
  have hloc (a : S.support) : ∃ δ : ℝ, 0 < δ ∧ ∀ z : Ambient n,
      dist z a < δ → dist (S.normal z) (S.normal a) < ε := by
    have hc := S.smooth_normal.continuousOn.continuousAt
      (S.open_neighborhood.mem_nhds (S.support_inside a.property))
    exact Metric.continuousAt_iff.mp hc ε hε
  choose δ hδ hlocal using hloc
  let B := fun a : S.support => Metric.ball (a : Ambient n) (δ a / 2)
  have hcover : S.support ⊆ ⋃ a : S.support, B a := by
    intro x hx
    exact Set.mem_iUnion.mpr ⟨⟨x, hx⟩, Metric.mem_ball_self (half_pos (hδ ⟨x, hx⟩))⟩
  obtain ⟨F, hF⟩ := S.compact_support.elim_finite_subcover B (fun _ => Metric.isOpen_ball) hcover
  let e := Fintype.equivFin ↥F
  let a : Fin (Fintype.card ↥F) → S.support := fun j => (e.symm j).val
  let K := fun j => S.support ∩ Metric.closedBall (a j : Ambient n) (δ (a j) / 2)
  let V := fun j => S.neighborhood ∩ S.normal ⁻¹' Metric.ball (S.normal (a j)) ε
  have hK j : IsCompact (K j) := S.compact_support.inter_right Metric.isClosed_closedBall
  have hV j : IsOpen (V j) :=
    S.smooth_normal.continuousOn.isOpen_inter_preimage S.open_neighborhood Metric.isOpen_ball
  have hKV j : K j ⊆ V j := by
    intro z hz
    refine ⟨S.support_inside hz.1, ?_⟩
    apply hlocal (a j) z
    exact lt_of_le_of_lt hz.2 (by have := hδ (a j); linarith)
  let P := fun j => S.subpatch (K j) (hK j) Set.inter_subset_left (V j) (hV j) (hKV j) Set.inter_subset_left
  refine ⟨⟨Fintype.card ↥F, P, (fun j => a j), (fun j => (a j).property),
    (fun _ => Set.inter_subset_left), ?_, (fun _ => rfl), ?_, ?_⟩,
    (fun j => B (a j)),(fun _ => Metric.isOpen_ball),?_,?_⟩
  · intro x hx
    obtain ⟨b, hbF, hxb⟩ := Set.mem_iUnion₂.mp (hF hx)
    refine Set.mem_iUnion.mpr ⟨e ⟨b, hbF⟩, ?_⟩
    change x ∈ S.support ∩ Metric.closedBall _ _
    simp only [a, Equiv.symm_apply_apply]
    exact ⟨hx, Metric.ball_subset_closedBall hxb⟩
  · intro j z hz
    exact ⟨hz.1.1, hz.2⟩
  · intro j z hz
    exact hz.2
  · intro x hx
    obtain ⟨b,hbF,hxb⟩ := Set.mem_iUnion₂.mp (hF hx)
    refine Set.mem_iUnion.mpr ⟨e ⟨b,hbF⟩,?_⟩
    simpa only [a,Equiv.symm_apply_apply] using hxb
  · intro j x hx
    exact ⟨hx.1,Metric.ball_subset_closedBall hx.2⟩
end N2Restriction
#print axioms N2Restriction.SmoothPatch.exists_directionalSubdivision_with_relative_interiors
