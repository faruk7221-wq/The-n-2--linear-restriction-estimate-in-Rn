import continuation.ActualTerminalExpansionV47

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal

/-- The exact positive F_tan in (7.3). Each ball uses its own actual
angular tangent/nontangent selection of the same original R-packets.
The all-nontangent binary choice is excluded. -/
noncomputable def actualTangentSum {d k L : ℕ} {S : Fin k → SmoothPatch (d+1)}
    (A : (i : Fin k) → PacketGraphAtlas (S i)) {r : ℝ}
    (Q : (i : Fin k) → (j : Fin (A i).size) → CoordinateCapFamily ((A i).patch j).support r)
    (hr : 0 < r)
    (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure)
    (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin d → ℤ))
    (Z : Set (Ambient (d+1))) (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1)))
    (c : Fin L → Ambient (d+1)) (ρ b C₀ R w : ℝ) (Ω : Set (Ambient (d+1))) :
    Ambient (d+1) → ENNReal :=
  fun x => ∑ l, (Ω ∩ ball (c l) ρ).indicator (fun y =>
    ∑ σ ∈ (Finset.univ : Finset (Fin k → Bool)).erase (fun _ => false),
      ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
        (fun i => (A i).cellInput (Q i) hr (f i)
          (if σ i then (A i).actualTangentSelection (Q i) (U i) Z T (c l) ρ b C₀ R w Ω
           else (A i).actualNontangentSelection (Q i) (U i) Z T (c l) ρ b C₀ R w Ω)) y‖ₑ) x

/-- The exact positive tangent sum is measurable. -/
theorem measurable_actualTangentSum {d k L : ℕ} {S : Fin k → SmoothPatch (d+1)}
    (A : (i : Fin k) → PacketGraphAtlas (S i)) {r : ℝ}
    (Q : (i : Fin k) → (j : Fin (A i).size) → CoordinateCapFamily ((A i).patch j).support r)
    (hr : 0 < r) (hsmall : ∀ i, r ≤ (A i).capRadius)
    (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure)
    (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin d → ℤ))
    (Z : Set (Ambient (d+1))) (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1)))
    (c : Fin L → Ambient (d+1)) (ρ b C₀ R w : ℝ) (Ω : Set (Ambient (d+1)))
    (hΩ : MeasurableSet Ω) : Measurable (actualTangentSum A Q hr f U Z T c ρ b C₀ R w Ω) := by
  unfold actualTangentSum
  exact Finset.measurable_sum _ (fun l _ =>
    (Finset.measurable_sum _ (fun σ _ => measurable_atlas_selected_product A Q hr hsmall f _)).indicator
      (hΩ.inter isOpen_ball.measurableSet))

end N2Restriction
#print axioms N2Restriction.measurable_actualTangentSum
