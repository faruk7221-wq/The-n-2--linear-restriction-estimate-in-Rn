import continuation.NontangentMassSummationV47

namespace N2Restriction
open scoped ENNReal

theorem energy_root_ofReal_sq (D : ENNReal) (a : ℝ) (ha : 0 ≤ a) :
    (D * ENNReal.ofReal (a^2))^(1/2 : ℝ) = D^(1/2 : ℝ) * ENNReal.ofReal a := by
  rw [ENNReal.ofReal_pow ha, ← ENNReal.rpow_two,
    ENNReal.mul_rpow_of_nonneg _ _ (by norm_num : (0 : ℝ) ≤ 1/2), ← ENNReal.rpow_mul]
  norm_num

/-- The energy estimate retains the product of original input norms,
including zero inputs and infinite formal local constants. -/
theorem energy_product_normalization {k : ℕ} (D : Fin k → ENNReal)
    (a : Fin k → ℝ) (ha : ∀ i, 0 ≤ a i) :
    (∏ i, (D i * ENNReal.ofReal ((a i)^2))^(1/2 : ℝ)) =
      (∏ i, (D i)^(1/2 : ℝ)) * ∏ i, ENNReal.ofReal (a i) := by
  simp_rw [energy_root_ofReal_sq _ _ (ha _)]
  exact Finset.prod_mul_distrib

end N2Restriction
#print axioms N2Restriction.energy_root_ofReal_sq
#print axioms N2Restriction.energy_product_normalization
