import continuation.AssumedLocalizedInputV38
namespace N2Restriction
open MeasureTheory

/-- The geometric atlas is constructed internally, independently of R. -/
noncomputable def canonicalArticleLocalizationAtlas {k : ℕ} (hk : 0 < k)
    (S : Fin k → SmoothPatch (k+2)) {κ : ℝ} (hκ : 0 < κ) : ArticleLocalizationAtlas S κ :=
  Classical.choice (exists_article_localization_atlas hk S hκ)

/-- Literal borrowed localized-restriction input on the internally constructed
atlas, uniformly over the actual geometric families. No corollary, strip bound,
energy estimate, recurrence or main theorem is a field. -/
def CanonicalLocalizedRestrictionInput {k : ℕ} (hk : 0 < k) : Prop :=
  ∀ (S : Fin k → SmoothPatch (k+2)) (ν κ : ℝ) (hgeo : GeometricHypotheses S ν κ),
    (canonicalArticleLocalizationAtlas hk S hgeo.2.1).UniformLocalizedInput (baseline k)

/-- Supply the proved atlas construction and only its borrowed analytic input. -/
theorem exists_canonical_localized_atlas {k : ℕ} (hk : 0 < k)
    (hexternal : CanonicalLocalizedRestrictionInput hk)
    (S : Fin k → SmoothPatch (k+2)) {ν κ : ℝ} (hgeo : GeometricHypotheses S ν κ) :
    ∃ B : ArticleLocalizationAtlas S κ, B.UniformLocalizedInput (baseline k) :=
  ⟨canonicalArticleLocalizationAtlas hk S hgeo.2.1,hexternal S ν κ hgeo⟩
end N2Restriction
#print axioms N2Restriction.exists_canonical_localized_atlas
