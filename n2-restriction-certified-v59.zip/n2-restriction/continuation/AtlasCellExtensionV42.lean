import continuation.AtlasCellSupportV42
import continuation.SelectedExtensionV20

namespace N2Restriction
open MeasureTheory Set
open scoped BigOperators

/-- The nested atlas cell input is the unconditional sum over its actual
single dependent packet index, as required by the rapid-tail theorem. -/
theorem PacketGraphAtlas.cellInput_eq_selected_tsum {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) {r : ℝ}
    (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r) (hr : 0 < r)
    (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
    (U : (j : Fin T.size) → (Q j).centers → Set (Fin d → ℤ)) :
    T.cellInput Q hr f U =
      ∑' p : {p : (j : Fin T.size) × ((Q j).centers × (Fin d → ℤ)) | p.2.2 ∈ U p.1 p.2.1},
        (T.graph p.val.1).rotatedAmbientInput (T.patch p.val.1).rotation
          ((T.graph p.val.1).packet (Q p.val.1) hr (f p.val.1) p.val.2.1 p.val.2.2) :=
  (T.selected_packet_hasSum Q hr f
    {p : (j : Fin T.size) × ((Q j).centers × (Fin d → ℤ)) | p.2.2 ∈ U p.1 p.2.1}).tsum_eq.symm

/-- Addition of integrable L2 inputs commutes with the ordinary extension,
despite the representatives in Lp only agreeing almost everywhere. -/
theorem extension_L2_add {n : ℕ} (μ : Measure (Ambient n))
    (f g : Lp ℂ 2 μ) (hf : Integrable f μ) (hg : Integrable g μ) (x : Ambient n) :
    extension μ id (f+g : Lp ℂ 2 μ) x = extension μ id f x + extension μ id g x := by
  unfold extension
  rw [← integral_add (integrable_extension_kernel measurable_id hf x)
    (integrable_extension_kernel measurable_id hg x)]
  apply integral_congr_ae
  filter_upwards [Lp.coeFn_add f g] with y hy
  rw [hy, Pi.add_apply, mul_add]

/-- The omitted-input extension is exactly the difference between the
selected-family extension and its restriction to a cell's packet labels. -/
theorem PacketGraphAtlas.cellInput_extension_split {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) {r : ℝ}
    (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r) (hr : 0 < r)
    (hsmall : r ≤ T.capRadius)
    (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
    (U V : (j : Fin T.size) → (Q j).centers → Set (Fin d → ℤ)) (x : Ambient (d+1)) :
    extension (Measure.hausdorffMeasure (d : ℝ)) id (T.cellInput Q hr f U) x -
      extension (Measure.hausdorffMeasure (d : ℝ)) id
        (T.cellInput Q hr f (fun j a => U j a ∩ V j a)) x =
      extension (Measure.hausdorffMeasure (d : ℝ)) id
        (T.cellInput Q hr f (fun j a => U j a \ V j a)) x := by
  rw [T.cellInput_split Q hr f U V, extension_L2_add _ _ _
    (T.cellInput_integrable Q hr hsmall f _) (T.cellInput_integrable Q hr hsmall f _)]
  exact add_sub_cancel_left _ _

end N2Restriction
#print axioms N2Restriction.PacketGraphAtlas.cellInput_eq_selected_tsum
#print axioms N2Restriction.extension_L2_add
#print axioms N2Restriction.PacketGraphAtlas.cellInput_extension_split
