import N2Restriction.CrossCapPackets
import N2Restriction.PacketBudgets

namespace N2Restriction
open MeasureTheory
open scoped BigOperators ENNReal

/-- Sum cell budgets across caps using support overlap, rather than the
number of caps. This avoids an R-dependent cap-count loss. -/
theorem cross_cap_cell_energy_budget {X C J : Type*} [MeasurableSpace X] [Fintype J]
    (μ : Measure X) (K : J → Set X) (f : C → J → Lp ℂ 2 μ)
    (hf : ∀ c j, HasFrequencySupport μ id (K j) (f c j))
    {M : ℝ} (hM : 0 ≤ M)
    (hoverlap : ∀ᵐ x ∂μ, (∑ j, (K j).indicator (fun _ : X => (1 : ℝ)) x) ≤ M)
    (A : ENNReal) (e : J → ENNReal)
    (hbudget : ∀ j, (∑' c, ENNReal.ofReal (‖f c j‖^2)) ≤ A * e j) :
    (∑' c, ENNReal.ofReal (‖∑ j, f c j‖^2)) ≤
      ENNReal.ofReal M * A * ∑ j, e j := by
  have hcell : ∀ c, ENNReal.ofReal (‖∑ j, f c j‖^2) ≤
      ENNReal.ofReal M * ∑ j, ENNReal.ofReal (‖f c j‖^2) := by
    intro c
    have h := ENNReal.ofReal_le_ofReal (finite_overlap_L2_energy μ K (f c) (hf c) hoverlap)
    rwa [ENNReal.ofReal_mul hM, ENNReal.ofReal_sum_of_nonneg (fun j _ => sq_nonneg _)] at h
  calc
    (∑' c, ENNReal.ofReal (‖∑ j, f c j‖^2)) ≤
        ∑' c, ENNReal.ofReal M * ∑ j, ENNReal.ofReal (‖f c j‖^2) := ENNReal.tsum_le_tsum hcell
    _ = ENNReal.ofReal M * ∑ j, ∑' c, ENNReal.ofReal (‖f c j‖^2) := by
      rw [ENNReal.tsum_mul_left]
      congr 1
      exact Summable.tsum_finsetSum (fun _ _ => ENNReal.summable)
    _ ≤ ENNReal.ofReal M * ∑ j, A * e j :=
      mul_le_mul_left' (Finset.sum_le_sum (fun j _ => hbudget j)) _
    _ = ENNReal.ofReal M * A * ∑ j, e j := by rw [← Finset.mul_sum, mul_assoc]

end N2Restriction
#print axioms N2Restriction.cross_cap_cell_energy_budget
