import N2Restriction

namespace N2Restriction
open Metric

/-- The normal-wedge constant persists on a fixed compact surface buffer,
uniformly in the selected index and in the admissible plane frame. -/
theorem geometric_buffered_wedge_bound {k : ℕ} (hk : 0 < k)
    (S : Fin k → SmoothPatch (k + 2)) {ν κ : ℝ}
    (hgeo : GeometricHypotheses S ν κ) :
    ∃ η c : ℝ, 0 < η ∧ 0 < c ∧
      ∃ K : Fin k → Set (Ambient (k + 2)),
        (∀ i, IsCompact (K i)) ∧ (∀ i, (S i).support ⊆ K i) ∧
        (∀ i, K i ⊆ (S i).extendedSurface) ∧
        (∀ i x, x ∈ (S i).support → ∀ y ∈ (S i).extendedSurface,
          dist y x ≤ η → y ∈ K i) ∧
        ∀ i z, (∀ j, z j ∈ K j) → ∀ q ∈ nearbyWedgeFrameSet S z i κ,
          c ≤ Matrix.det (Matrix.gram ℝ (nearbyWedgeVectors S z i q)) := by
  obtain ⟨η, hη, K, hK, hsub, hin, hbuf⟩ := uniform_compact_surface_buffers S
  let T := fun i => (S i).withSupport (K i) (hK i) (hin i)
  have hT : GeometricHypotheses T ν κ := hgeo
  obtain ⟨c, hc, hb⟩ :=
    geometric_nearby_frame_wedge_uniform_over_supported_tuples_all_indices hk T hT
  exact ⟨η, c, hη, hc, K, hK, hsub, hin, hbuf, hb⟩

/-- Small-residual correction stays inside one fixed compact surface buffer.
The buffer and chart constants are chosen before the tuple, plane and residual.
The same buffer carries the quantitative normal-wedge bound. -/
theorem geometric_buffered_thin_correction {k : ℕ} (hk : 0 < k)
    (S : Fin k → SmoothPatch (k + 2)) {ν κ : ℝ}
    (hgeo : GeometricHypotheses S ν κ) :
    ∃ δ r C c : ℝ, 0 < δ ∧ 0 < r ∧ 0 ≤ C ∧ 0 < c ∧
      ∃ B : ℕ → ℝ, (∀ m, 0 ≤ B m) ∧
      ∃ K : Fin k → Set (Ambient (k + 2)),
        (∀ i, IsCompact (K i)) ∧ (∀ i, (S i).support ⊆ K i) ∧
        (∀ i, K i ⊆ (S i).extendedSurface) ∧
        (∀ i z, (∀ j, z j ∈ K j) → ∀ q ∈ nearbyWedgeFrameSet S z i κ,
          c ≤ Matrix.det (Matrix.gram ℝ (nearbyWedgeVectors S z i q))) ∧
        ∀ (z : Fin k → Ambient (k + 2)), (∀ j, z j ∈ (S j).support) → ∀ i
          (H : Submodule ℝ (Ambient (k + 2))), Module.finrank ℝ H = 2 →
          ‖(commonTangent (fun j => (S j).normal (z j))).starProjection -
            H.starProjection‖ * ‖(S i).shape (z i)‖ ≤ κ / 2 →
          ‖H.orthogonalProjection ((S i).normal (z i))‖ < δ →
          ∃ y ∈ K i, H.orthogonalProjection ((S i).normal y) = 0 ∧
            dist (z i) y ≤ C * ‖H.orthogonalProjection ((S i).normal (z i))‖ ∧
            ThinChartAt (S i) H.orthogonalProjection y r B := by
  obtain ⟨η, c, hη, hc, K, hK, hsub, hin, hbuf, hw⟩ :=
    geometric_buffered_wedge_bound hk S hgeo
  obtain ⟨δ, r, C, hδ, hr, hC, B, hB, hb⟩ :=
    geometric_uniform_correction_and_thin_charts S hgeo
  refine ⟨min δ (η / (C + 1)), r, C, c,
    lt_min hδ (div_pos hη (by linarith)), hr, hC, hc,
    B, hB, K, hK, hsub, hin, hw, ?_⟩
  intro z hz i H hdim hgap hsmall
  obtain ⟨y, hy, hzero, hd, hchart⟩ :=
    hb z hz i H hdim hgap (hsmall.trans_le (min_le_left _ _))
  refine ⟨y, hbuf i (z i) (hz i) y hy ?_, hzero, hd, hchart⟩
  rw [dist_comm]
  apply hd.trans
  have he := (lt_div_iff₀ (by linarith : 0 < C + 1)).mp
    (hsmall.trans_le (min_le_right _ _))
  nlinarith [norm_nonneg (H.orthogonalProjection ((S i).normal (z i)))]

end N2Restriction

#print axioms N2Restriction.geometric_buffered_thin_correction
#print axioms N2Restriction.geometric_buffered_wedge_bound
