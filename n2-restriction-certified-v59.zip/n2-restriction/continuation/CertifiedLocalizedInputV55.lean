import continuation.CertifiedNormalGeometryV59
namespace N2Restriction
open MeasureTheory

/-- Borrowed localized restriction on full certified measured atlases.
Every atlas retains actual measured charts, normal coordinates, a strict
reference margin and a uniform normalized joint normal-space wedge bound.
ArticleFrame retains closeness to the COMMON tangent plane. The theorem
localized_normal_certificate verifies this geometry on the actual zero targets
and other carriers. No strip estimate or article-side recurrence is a field. -/
def CertifiedLocalizedRestrictionInput {k : ℕ} : Prop :=
  ∀ (S : Fin k → SmoothPatch (k+2)) (ν κ : ℝ), GeometricHypotheses S ν κ →
    ∀ A : CertifiedArticleLocalizationAtlas S κ,
      A.toArticleLocalizationAtlas.UniformLocalizedInput (baseline k)

/-- Select a full certified atlas, then forget geometry only at the analytic
adapter. The chosen object's type retains every measured-chart certificate. -/
theorem exists_certified_localized_atlas {k : ℕ} (hk : 0 < k)
    (hexternal : CertifiedLocalizedRestrictionInput (k := k))
    (S : Fin k → SmoothPatch (k+2)) {ν κ : ℝ} (hgeo : GeometricHypotheses S ν κ) :
    ∃ A : CertifiedArticleLocalizationAtlas S κ,
      A.toArticleLocalizationAtlas.UniformLocalizedInput (baseline k) := by
  let A := Classical.choice (exists_certified_article_localization_atlas hk S hgeo)
  exact ⟨A,hexternal S ν κ hgeo A⟩

/-- Compatibility with the retained reduced analytic interface is proved;
the atlas is not selected arbitrarily from its reduced type. -/
theorem exists_reduced_localized_atlas_from_certificates {k : ℕ} (hk : 0 < k)
    (hexternal : CertifiedLocalizedRestrictionInput (k := k))
    (S : Fin k → SmoothPatch (k+2)) {ν κ : ℝ} (hgeo : GeometricHypotheses S ν κ) :
    ∃ A : ArticleLocalizationAtlas S κ, A.UniformLocalizedInput (baseline k) := by
  obtain ⟨A,hA⟩ := exists_certified_localized_atlas hk hexternal S hgeo
  exact ⟨A.toArticleLocalizationAtlas,hA⟩
end N2Restriction
#print axioms N2Restriction.exists_certified_localized_atlas
#print axioms N2Restriction.exists_reduced_localized_atlas_from_certificates
