import continuation.CellMeetingWeightsV35

namespace N2Restriction
open MeasureTheory Set
open scoped ENNReal BigOperators

/-- Finite measurable covering cells patch local weighted estimates into
one estimate on the region. Overlaps are permitted for this upper bound. -/
theorem cell_local_estimate_sum {X I J : Type*}
    [MeasurableSpace X] [Fintype I] [Fintype J] {T : I → Type*}
    (μ : Measure X) (C : J → Set X) (S : Set X)
    (hcover : S ⊆ ⋃ j, C j) (hS : MeasurableSet S)
    (hC : ∀ j, MeasurableSet (C j))
    (U : ∀ i, T i → Set X) (u : ∀ i, T i → ℝ≥0∞)
    (p : ℝ) (K : ℝ≥0∞)
    (hlocal : ∀ j,
      (∫⁻ x in C j ∩ S, (∏ i, tubeDensity (U i)
        (cellMeetingWeight (U i) (u i) (C j ∩ S)) x) ^ p ∂μ) ≤
      K * (∏ i, ∑' t, cellMeetingWeight (U i) (u i) (C j ∩ S) t) ^ p) :
    (∫⁻ x in S, (∏ i, tubeDensity (U i) (u i) x) ^ p ∂μ) ≤
      K * ∑ j, (∏ i, ∑' t, cellMeetingWeight (U i) (u i) (C j ∩ S) t) ^ p := by
  classical
  have hcov : S ⊆ ⋃ j, C j ∩ S := by
    intro x hx
    obtain ⟨j, hj⟩ := mem_iUnion.mp (hcover hx)
    exact mem_iUnion.mpr ⟨j, hj, hx⟩
  calc
    _ ≤ ∫⁻ x in ⋃ j, C j ∩ S, (∏ i, tubeDensity (U i) (u i) x) ^ p ∂μ :=
      lintegral_mono_set hcov
    _ ≤ ∑ j, ∫⁻ x in C j ∩ S, (∏ i, tubeDensity (U i) (u i) x) ^ p ∂μ := by
      simpa only [tsum_fintype] using lintegral_iUnion_le (μ := μ)
        (fun j => C j ∩ S) (fun x => (∏ i, tubeDensity (U i) (u i) x) ^ p)
    _ ≤ ∑ j, K * (∏ i, ∑' t, cellMeetingWeight (U i) (u i) (C j ∩ S) t) ^ p := by
      apply Finset.sum_le_sum
      intro j _
      convert hlocal j using 1
      apply setLIntegral_congr_fun (hC j |>.inter hS)
      intro x hx
      simp only [cellMeetingWeight_density_eq (U _) (u _) _ hx]
    _ = _ := (Finset.mul_sum ..).symm

/-- Composing a local estimate with a meeting-weight budget is the analytic
cell recurrence step; geometry and scale choices remain explicit inputs. -/
theorem cell_local_estimate_of_budget {X I J : Type*}
    [MeasurableSpace X] [Fintype I] [Fintype J] {T : I → Type*}
    (μ : Measure X) (C : J → Set X) (S : Set X)
    (hcover : S ⊆ ⋃ j, C j) (hS : MeasurableSet S)
    (hC : ∀ j, MeasurableSet (C j))
    (U : ∀ i, T i → Set X) (u : ∀ i, T i → ℝ≥0∞)
    (p : ℝ) (K B : ℝ≥0∞)
    (hlocal : ∀ j,
      (∫⁻ x in C j ∩ S, (∏ i, tubeDensity (U i)
        (cellMeetingWeight (U i) (u i) (C j ∩ S)) x) ^ p ∂μ) ≤
      K * (∏ i, ∑' t, cellMeetingWeight (U i) (u i) (C j ∩ S) t) ^ p)
    (hbudget : (∑ j, (∏ i, ∑' t, cellMeetingWeight (U i) (u i) (C j ∩ S) t) ^ p) ≤ B) :
    (∫⁻ x in S, (∏ i, tubeDensity (U i) (u i) x) ^ p ∂μ) ≤ K * B :=
  (cell_local_estimate_sum μ C S hcover hS hC U u p K hlocal).trans
    (mul_le_mul_left' hbudget K)

end N2Restriction

#print axioms N2Restriction.cell_local_estimate_of_budget
#print axioms N2Restriction.cell_local_estimate_sum
