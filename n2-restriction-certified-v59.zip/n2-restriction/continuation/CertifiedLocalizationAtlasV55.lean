import continuation.AssumedLocalizedInputV38
import continuation.BoundedLocalizationAtlasV59
import continuation.GeometricAdjointNormalizedV26
namespace N2Restriction
open MeasureTheory Metric Set Filter
open scoped NNReal ENNReal BigOperators
set_option maxHeartbeats 1600000

/-- The full geometric data from the uniform measured-chart construction.
Unlike the reduced atlas, every inhabitant carries the chart certificates
needed to specialize the borrowed localized restriction theorem. -/
structure CertifiedArticleLocalizationAtlas {k : ℕ}
    (S : Fin k → SmoothPatch (k+2)) (κ : ℝ) where
  η : ℝ
  η_pos : 0 < η
  M : ℝ≥0
  δ : ℝ
  r : ℝ
  ρ : ℝ
  δ_pos : 0 < δ
  ρ_pos : 0 < ρ
  ρ_lt_r : ρ < r
  B : ℕ → ℝ
  B_nonneg : ∀ m, 0 ≤ B m
  c : ℝ≥0
  C : ℝ≥0
  c_pos : 0 < c
  L : ℝ
  α : ℝ
  β : ℝ
  τ : ℝ
  D : ℝ
  L_one : 1 ≤ L
  α_pos : 0 < α
  β_pos : 0 < β
  τ_pos : 0 < τ
  D_pos : 0 < D
  reference_margin : (L+1)*τ < r-ρ
  count : ℕ
  charts : Fin k → ℕ
  centers : ∀ i, Fin (charts i) → Ambient (k+2)
  count_bound : ∀ i, charts i ≤ count
  centers_support : ∀ i j, centers i j ∈ (S i).support
  measuredChart : ∀ (q : ArticleFrame S κ) i j,
    MeasuredTubularChart (S i) (pairFrameMap q.val) (centers i j) δ r ρ (η/2) B c C L
  normalCoordinates : ∀ (q : ArticleFrame S κ) i j,
    ChartNormalCoordinates (measuredChart q i j) α β
  covers : ∀ q i, (S i).support ⊆ ⋃ j, (measuredChart q i j).carrier
  normal_lipschitz : ∀ (_q : ArticleFrame S κ) i j, LipschitzOnWith M (S i).normal (closedBall (centers i j) η)
  zero_target : ∀ q i j y, y ∈ (normalCoordinates q i j).zeroTarget τ →
    y ∈ (S i).extendedSurface ∧ thinConstraint (S i) (pairPlane q.val) y = 0 ∧
      dist y (centers i j) ≤ η
  localizes : ∀ q i j x, x ∈ (measuredChart q i j).carrier →
    ‖pairFrameMap q.val ((S i).normal x)‖ ≤ τ →
    ∃ y ∈ (normalCoordinates q i j).zeroTarget τ,
      dist x y ≤ D * ‖pairFrameMap q.val ((S i).normal x)‖

  wedgeLower : ℝ
  wedgeLower_pos : 0 < wedgeLower
  joint_normalized : ∀ (q : ArticleFrame S κ) (i : Fin k)
    (a : ∀ j, Fin (charts j)) (y : Fin k → Ambient (k+2)),
    (∀ j, y j ∈ (S j).extendedSurface ∧ dist (y j) (centers j (a j)) ≤ η) →
    ∀ (φ : Ambient (k+2-3) → Ambient (k+2)) (t : Ambient (k+2-3)),
      φ t = y i → DifferentiableAt ℝ φ t → Function.Injective (fderiv ℝ φ t) →
      (∀ᶠ s in nhds t, thinConstraint (S i) (pairPlane q.val) (φ s) =
        thinConstraint (S i) (pairPlane q.val) (φ t)) →
      ∃ b : OrthonormalBasis (Fin 3) ℝ (LinearMap.range (fderiv ℝ φ t).toLinearMap)ᗮ,
        wedgeLower ≤ Matrix.det (Matrix.gram ℝ (Sum.elim
          (fun j : {j : Fin k // j ≠ i} => (S j).normal (y j))
          (fun j => (b j : Ambient (k+2)))))

/-- Forget only after retaining the full measured-chart geometry. -/
noncomputable def CertifiedArticleLocalizationAtlas.toArticleLocalizationAtlas
    {k : ℕ} {S : Fin k → SmoothPatch (k+2)} {κ : ℝ}
    (A : CertifiedArticleLocalizationAtlas S κ) : ArticleLocalizationAtlas S κ where
  count := A.count
  charts := A.charts
  count_bound := A.count_bound
  threshold := A.τ
  threshold_pos := A.τ_pos
  distanceCost := ⟨A.D,A.D_pos.le⟩
  distanceCost_pos := A.D_pos
  carrier := fun q i j => (A.measuredChart q i j).carrier
  target := fun q i j => (A.normalCoordinates q i j).zeroTarget A.τ
  compact_carrier := fun q i j => (A.measuredChart q i j).compact_carrier A.ρ_lt_r.le
  covers := A.covers
  zero_target := fun q i j y hy => ⟨(A.zero_target q i j y hy).1,(A.zero_target q i j y hy).2.1⟩
  localizes := A.localizes

/-- All certificates are proved by the existing uniform chart construction;
no analytic localized estimate is assumed in this geometric constructor. -/
theorem exists_certified_article_localization_atlas {k : ℕ} (hk : 0 < k)
    (S : Fin k → SmoothPatch (k+2)) {ν κ : ℝ} (hgeo : GeometricHypotheses S ν κ) :
    Nonempty (CertifiedArticleLocalizationAtlas S κ) := by
  classical
  obtain ⟨ηmax,wedge,hwRadius,hwedge,hjoint⟩ := geometric_nonzero_chart_normalized_bound hk S hgeo
  obtain ⟨η,hη,hηmax,M,δ,r,ρ,hδ,hρ,hρr,B,hB,c,C,hc,L,α,β,τ,D,
    hL,hα,hβ,hτ,hD,hmargin,N,m,z,hm,hz,hatlas⟩ :=
    uniform_distance_ready_atlases_bounded hk S hgeo.2.1 ηmax hwRadius
  have ha : ∀ (q : ArticleFrame S κ) i,
      ∃ F : ∀ j, MeasuredTubularChart (S i) (pairFrameMap q.val) (z i j) δ r ρ (η/2) B c C L,
      ∃ E : ∀ j, ChartNormalCoordinates (F j) α β,
        (S i).support ⊆ ⋃ j, (F j).carrier ∧
        ∀ j, LipschitzOnWith M (S i).normal (closedBall (z i j) η) ∧
          (∀ y ∈ (E j).zeroTarget τ, y ∈ (S i).extendedSurface ∧
            thinConstraint (S i) (pairPlane q.val) y = 0 ∧ dist y (z i j) ≤ η) ∧
          (∀ x ∈ (F j).carrier, ‖pairFrameMap q.val ((S i).normal x)‖ ≤ τ →
            ∃ y ∈ (E j).zeroTarget τ, dist x y ≤ D * ‖pairFrameMap q.val ((S i).normal x)‖) := by
    intro q i
    exact hatlas i q.val q.property.1 (fun j => q.property.2.1 i _ (hz i j))
  choose F E hcover hprops using ha
  exact ⟨{
    η := η, η_pos := hη, M := M, δ := δ, r := r, ρ := ρ,
    δ_pos := hδ, ρ_pos := hρ, ρ_lt_r := hρr, B := B, B_nonneg := hB,
    c := c, C := C, c_pos := hc, L := L, α := α, β := β, τ := τ, D := D,
    L_one := hL, α_pos := hα, β_pos := hβ, τ_pos := hτ, D_pos := hD, reference_margin := hmargin,
    count := N, charts := m, centers := z, count_bound := hm, centers_support := hz,
    measuredChart := F, normalCoordinates := E, covers := hcover,
    normal_lipschitz := fun q i j => (hprops q i j).1,
    zero_target := fun q i j y hy => (hprops q i j).2.1 y hy,
    localizes := fun q i j x hx hs => (hprops q i j).2.2 x hx hs,
    wedgeLower := wedge, wedgeLower_pos := hwedge,
    joint_normalized := by
      intro q i a y hy φ t hφt hφ hi hlevel
      exact hjoint (fun j => z j (a j)) (fun j => hz j (a j)) i q.val q.property.1
        (q.property.2.2 (fun j => z j (a j)) (fun j => hz j (a j)) i) y
        (fun j => ⟨(hy j).1, (hy j).2.trans hηmax⟩) (pairPlane q.val) rfl φ t hφt hφ hi hlevel }⟩
end N2Restriction
#print axioms N2Restriction.exists_certified_article_localization_atlas
