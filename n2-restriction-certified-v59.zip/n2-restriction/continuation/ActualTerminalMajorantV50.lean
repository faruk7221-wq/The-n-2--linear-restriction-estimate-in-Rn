import continuation.ActualTangentSumV48
import continuation.AtlasBallProductV47
import continuation.QuasiBanachProductErrorV49

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal

/-- The original selected product is controlled by the actual nontangent
and tangent positive sums plus one rapid error, with no ball-count loss. -/
theorem actual_terminal_power_majorant {d k L : ℕ} {S : Fin k → SmoothPatch (d+1)}
    (A : (i : Fin k) → PacketGraphAtlas (S i)) {r : ℝ}
    (Q : (i : Fin k) → (j : Fin (A i).size) → CoordinateCapFamily ((A i).patch j).support r)
    (hr : 0 < r) (hsmall : ∀ i, r ≤ (A i).capRadius)
    (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure)
    (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin d → ℤ))
    (Z : Set (Ambient (d+1))) (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1)))
    (c : Fin L → Ambient (d+1)) (ρ b C₀ R w : ℝ) (Ω : Set (Ambient (d+1)))
    {p δ : ℝ} (hp : 0 < p) (hp1 : p ≤ 1)
    (hcover : Ω ⊆ ⋃ l, ball (c l) ρ)
    (herror : ∀ l x, x ∈ Ω ∩ ball (c l) ρ →
      ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
          (fun i => (A i).cellInput (Q i) hr (f i) (U i)) x -
        extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
          (fun i => (A i).cellInput (Q i) hr (f i)
            ((A i).actualRetainedSelection (Q i) (U i) (c l) ρ R w Ω)) x‖ ≤ δ)
    (x : Ambient (d+1)) (hx : x ∈ Ω) :
    ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
        (fun i => (A i).cellInput (Q i) hr (f i) (U i)) x‖ₑ^p ≤
      (atlasBallProductSum A Q hr f
        (fun l i => (A i).actualNontangentSelection (Q i) (U i) Z T (c l) ρ b C₀ R w Ω) c ρ Ω x)^p +
      (actualTangentSum A Q hr f U Z T c ρ b C₀ R w Ω x)^p + (ENNReal.ofReal δ)^p := by
  classical
  obtain ⟨l,hl⟩ := mem_iUnion.mp (hcover hx)
  have hxl : x ∈ Ω ∩ ball (c l) ρ := ⟨hx,hl⟩
  have he := enorm_power_le_of_difference hp hp1 (herror l x hxl)
  have hb := actual_retained_product_majorant A Q hr hsmall f U Z T (c l) ρ b C₀ R w Ω x
  have hn : ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
      (fun i => (A i).cellInput (Q i) hr (f i)
        ((A i).actualNontangentSelection (Q i) (U i) Z T (c l) ρ b C₀ R w Ω)) x‖ₑ ≤
      atlasBallProductSum A Q hr f
        (fun l i => (A i).actualNontangentSelection (Q i) (U i) Z T (c l) ρ b C₀ R w Ω) c ρ Ω x := by
    unfold atlasBallProductSum
    have hh := Finset.single_le_sum (fun j (_ : j ∈ Finset.univ) => zero_le
      ((Ω ∩ ball (c j) ρ).indicator (fun y =>
        ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
          (fun i => (A i).cellInput (Q i) hr (f i)
            ((A i).actualNontangentSelection (Q i) (U i) Z T (c j) ρ b C₀ R w Ω)) y‖ₑ) x))
      (Finset.mem_univ l)
    simpa only [indicator_of_mem hxl] using hh
  have ht : (∑ σ ∈ (Finset.univ : Finset (Fin k → Bool)).erase (fun _ => false),
      ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
        (fun i => (A i).cellInput (Q i) hr (f i)
          (if σ i then (A i).actualTangentSelection (Q i) (U i) Z T (c l) ρ b C₀ R w Ω
           else (A i).actualNontangentSelection (Q i) (U i) Z T (c l) ρ b C₀ R w Ω)) x‖ₑ) ≤
      actualTangentSum A Q hr f U Z T c ρ b C₀ R w Ω x := by
    unfold actualTangentSum
    have hh := Finset.single_le_sum (fun j (_ : j ∈ Finset.univ) => zero_le
      ((Ω ∩ ball (c j) ρ).indicator (fun y =>
        ∑ σ ∈ (Finset.univ : Finset (Fin k → Bool)).erase (fun _ => false),
          ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
            (fun i => (A i).cellInput (Q i) hr (f i)
              (if σ i then (A i).actualTangentSelection (Q i) (U i) Z T (c j) ρ b C₀ R w Ω
               else (A i).actualNontangentSelection (Q i) (U i) Z T (c j) ρ b C₀ R w Ω)) y‖ₑ) x))
      (Finset.mem_univ l)
    simpa only [indicator_of_mem hxl] using hh
  apply he.trans
  apply add_le_add_right
  exact (ENNReal.rpow_le_rpow (hb.trans (add_le_add hn ht)) hp.le).trans
    (ENNReal.rpow_add_le_add_rpow _ _ hp.le hp1)

end N2Restriction
#print axioms N2Restriction.actual_terminal_power_majorant
