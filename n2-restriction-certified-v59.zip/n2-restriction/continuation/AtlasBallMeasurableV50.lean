import continuation.AtlasBallProductV47

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal

/-- The actual positive ball sum is measurable for every original-packet
selection, without requiring measurable choices of packet or variety data. -/
theorem measurable_atlasBallProductSum {d k L : ℕ} {S : Fin k → SmoothPatch (d+1)}
    (A : (i : Fin k) → PacketGraphAtlas (S i)) {r : ℝ}
    (Q : (i : Fin k) → (j : Fin (A i).size) → CoordinateCapFamily ((A i).patch j).support r)
    (hr : 0 < r) (hsmall : ∀ i, r ≤ (A i).capRadius)
    (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure)
    (U : Fin L → (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin d → ℤ))
    (c : Fin L → Ambient (d+1)) (ρ : ℝ) (Ω : Set (Ambient (d+1))) (hΩ : MeasurableSet Ω) :
    Measurable (atlasBallProductSum A Q hr f U c ρ Ω) := by
  apply Finset.measurable_sum
  intro l _
  exact (measurable_atlas_selected_product A Q hr hsmall f (U l)).indicator
    (hΩ.inter isOpen_ball.measurableSet)

end N2Restriction
#print axioms N2Restriction.measurable_atlasBallProductSum
