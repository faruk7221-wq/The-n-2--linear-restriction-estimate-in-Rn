import continuation.AtlasCellPartitionV42

namespace N2Restriction
open MeasureTheory Set
open scoped BigOperators

/-- Finite sums retain a common measurable essential support in L2. -/
theorem HasFrequencySupport.sum_L2 {n : ℕ} {I : Type*} [Fintype I]
    (μ : Measure (Ambient n)) (K : Set (Ambient n)) (hK : MeasurableSet K)
    (f : I → Lp ℂ 2 μ) (hf : ∀ i, HasFrequencySupport μ id K (f i)) :
    HasFrequencySupport μ id K (∑ i, f i : Lp ℂ 2 μ) := by
  simpa only [tsum_fintype] using HasFrequencySupport.tsum_L2 μ K hK f
    (hasSum_fintype f).summable hf

/-- Finite-measure essential support makes an L2 input integrable even
when its ambient Hausdorff measure is infinite. -/
theorem HasFrequencySupport.integrable_L2 {n : ℕ}
    (μ : Measure (Ambient n)) (K : Set (Ambient n)) (hK : MeasurableSet K)
    [IsFiniteMeasure (μ.restrict K)] (f : Lp ℂ 2 μ)
    (hf : HasFrequencySupport μ id K f) : Integrable f μ := by
  have hi : Integrable f (μ.restrict K) := ((Lp.memLp f).restrict K).integrable (by norm_num)
  apply ((integrable_indicator_iff hK).mpr hi).congr
  filter_upwards [hf] with x hx
  by_cases h : x ∈ K
  · exact indicator_of_mem h _
  · rw [indicator_of_notMem h]
    symm
    by_contra hn
    exact h (hx hn)

/-- Every selected cell input stays in the fixed compact atlas buffer. -/
theorem PacketGraphAtlas.cellInput_support {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) {r : ℝ}
    (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r) (hr : 0 < r)
    (hsmall : r ≤ T.capRadius)
    (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
    (U : (j : Fin T.size) → (Q j).centers → Set (Fin d → ℤ)) :
    HasFrequencySupport (Measure.hausdorffMeasure (d : ℝ)) id (⋃ j, T.buffer j)
      (T.cellInput Q hr f U) := by
  have hm : MeasurableSet (⋃ j, T.buffer j) :=
    MeasurableSet.iUnion (fun j => (T.compact_buffer j).measurableSet)
  apply HasFrequencySupport.sum_L2 _ _ hm
  intro j
  apply HasFrequencySupport.sum_L2 _ _ hm
  intro a
  apply HasFrequencySupport.tsum_L2 _ _ hm _ ((T.cap_packet_summable Q hr f j a).subtype (U j a))
  intro ν
  exact (T.packet_support Q hr hsmall f j a ν.val).mono (subset_iUnion (fun j => T.buffer j) j)

/-- The near/far and cell-selected inputs have well-defined ordinary
Fourier integrals, with no finite ambient-measure assumption. -/
theorem PacketGraphAtlas.cellInput_integrable {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) {r : ℝ}
    (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r) (hr : 0 < r)
    (hsmall : r ≤ T.capRadius)
    (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
    (U : (j : Fin T.size) → (Q j).centers → Set (Fin d → ℤ)) :
    Integrable (T.cellInput Q hr f U) (Measure.hausdorffMeasure (d : ℝ)) := by
  letI := T.finite_buffer_measure
  exact HasFrequencySupport.integrable_L2 _ _
    (MeasurableSet.iUnion (fun j => (T.compact_buffer j).measurableSet)) _
      (T.cellInput_support Q hr hsmall f U)

end N2Restriction
#print axioms N2Restriction.HasFrequencySupport.sum_L2
#print axioms N2Restriction.HasFrequencySupport.integrable_L2
#print axioms N2Restriction.PacketGraphAtlas.cellInput_support
#print axioms N2Restriction.PacketGraphAtlas.cellInput_integrable
