import continuation.CellDegreePowerV43

namespace N2Restriction

/-- A lower partition-cell count gives the required inverse D^s loss. -/
theorem cell_inverse_count_bound {J c D s : ℝ} (hc : 0 < c) (hD : 0 < D)
    (hcount : c*D^s ≤ J) : 1/J ≤ (1/c)*D^(-s) := by
  have hp : 0 < c*D^s := mul_pos hc (Real.rpow_pos_of_pos hD _)
  calc
    1/J ≤ 1/(c*D^s) := one_div_le_one_div_of_le hp hcount
    _ = _ := by rw [Real.rpow_neg hD.le]; field_simp

/-- Normalize the Markov cell-energy coefficient using the partition count.
The near budget is K D and the far budget is K; constants remain outside
all powers of the new degree. -/
theorem cell_count_energy_normalization {J c D s A B K N x e : ℝ}
    (far : Bool) (hc : 0 < c) (hD : 0 < D)
    (hcount : c*D^s ≤ J) (hA : 0 ≤ A) (hB : 0 ≤ B) (hN : 0 ≤ N)
    (hbudget : N ≤ K*D^(if far then (0 : ℝ) else 1))
    (he : e ≤ (A/J)*(B*N*x^2)) :
    e ≤ (A/c*B*K)*D^(1-s-(if far then (1 : ℝ) else 0))*x^2 := by
  have hi := cell_inverse_count_bound hc hD hcount
  have hfirst : A/J ≤ A*((1/c)*D^(-s)) := by
    simpa only [div_eq_mul_inv, one_mul] using mul_le_mul_of_nonneg_left hi hA
  calc
    e ≤ (A/J)*(B*N*x^2) := he
    _ ≤ (A*((1/c)*D^(-s)))*(B*N*x^2) :=
      mul_le_mul_of_nonneg_right hfirst (by positivity)
    _ ≤ (A*((1/c)*D^(-s)))*(B*(K*D^(if far then (0 : ℝ) else 1))*x^2) := by
      apply mul_le_mul_of_nonneg_left _ (by positivity)
      exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hbudget hB) (sq_nonneg x)
    _ = (A/c*B*K)*(D^(-s)*D^(if far then (0 : ℝ) else 1))*x^2 := by ring
    _ = _ := by
      rw [← Real.rpow_add hD]
      congr 2
      cases far <;> simp [sub_eq_add_neg, add_comm, add_left_comm, add_assoc]

end N2Restriction
#print axioms N2Restriction.cell_inverse_count_bound
#print axioms N2Restriction.cell_count_energy_normalization
