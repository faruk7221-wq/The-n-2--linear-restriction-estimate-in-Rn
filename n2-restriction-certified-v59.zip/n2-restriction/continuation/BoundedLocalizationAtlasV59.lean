import continuation.ZeroTargetSupportV30
import continuation.ReferenceMarginV59

namespace N2Restriction
open Metric Set
open scoped NNReal ENNReal

/-- Uniform measured atlases with both directions of the localization
interface available. The normal Lipschitz constant and all other constants
precede the frame. Only center admissibility is needed for this preparation. -/
theorem uniform_distance_ready_atlases_bounded {k : ℕ} (hk : 0 < k)
    (S : Fin k → SmoothPatch (k + 2)) {κ : ℝ} (hκ : 0 < κ)
    (ηmax : ℝ) (hmax : 0 < ηmax) :
    ∃ η : ℝ, 0 < η ∧ η ≤ ηmax ∧ ∃ M : ℝ≥0, ∃ δ r ρ : ℝ,
      0 < δ ∧ 0 < ρ ∧ ρ < r ∧ ∃ B : ℕ → ℝ, (∀ m, 0 ≤ B m) ∧
      ∃ c C : ℝ≥0, 0 < c ∧ ∃ L α β τ D : ℝ,
        1 ≤ L ∧ 0 < α ∧ 0 < β ∧ 0 < τ ∧ 0 < D ∧ (L+1)*τ < r-ρ ∧
      ∃ (N : ℕ) (m : Fin k → ℕ) (z : ∀ i, Fin (m i) → Ambient (k + 2)),
        (∀ i, m i ≤ N) ∧ (∀ i j, z i j ∈ (S i).support) ∧
        ∀ i q, q ∈ orthonormalPairSet (k + 2) →
          (∀ j, (pairFrameMap q, z i j) ∈ frameFrequencyAdmissibleImage (S i) κ) →
          ∃ F : ∀ j, MeasuredTubularChart (S i) (pairFrameMap q) (z i j) δ r ρ (η / 2) B c C L,
          ∃ E : ∀ j, ChartNormalCoordinates (F j) α β,
            (S i).support ⊆ ⋃ j, (F j).carrier ∧
            ∀ j, LipschitzOnWith M (S i).normal (closedBall (z i j) η) ∧
              (∀ y ∈ (E j).zeroTarget τ,
                y ∈ (S i).extendedSurface ∧ thinConstraint (S i) (pairPlane q) y = 0 ∧
                  dist y (z i j) ≤ η) ∧
              (∀ x ∈ (F j).carrier, ‖pairFrameMap q ((S i).normal x)‖ ≤ τ →
                ∃ y ∈ (E j).zeroTarget τ,
                  dist x y ≤ D * ‖pairFrameMap q ((S i).normal x)‖) := by
  classical
  obtain ⟨η₀, hη₀, M, hM⟩ := uniform_normal_lipschitz_buffers S
  let η := min η₀ ηmax
  have hη : 0 < η := lt_min hη₀ hmax
  have hηold : η ≤ η₀ := min_le_left _ _
  have hηmax : η ≤ ηmax := min_le_right _ _
  obtain ⟨δ, r, ρ, hδ, hρ, hρr, _, B, hB, c, C, hc, L, hL, N, m, z, hm, hz, hatlas⟩ :=
    uniform_measured_tubular_atlases hk S hκ (η / 2) (by positivity)
  obtain ⟨α, β, hα, hβ, hcoord⟩ := uniform_chart_normal_coordinates
    (k + 2) (by omega) (zero_le_one.trans hL)
  obtain ⟨τ, D, hτ, hD, hmargin, htarget⟩ := uniform_bundled_zero_targets_with_margin hρr hL hη B (hB 1)
  refine ⟨η, hη, hηmax, M, δ, r, ρ, hδ, hρ, hρr, B, hB, c, C, hc,
    L, α, β, τ, D, hL, hα, hβ, hτ, hD, hmargin, N, m, z, hm, hz, ?_⟩
  intro i q hq hadm
  obtain ⟨F, hcover⟩ := hatlas i (pairFrameMap q) hadm
  let E : ∀ j, ChartNormalCoordinates (F j) α β := fun j =>
    Classical.choice (hcoord (S i) (pairFrameMap q) (z i j) δ r ρ (η / 2) B c C (F j))
  refine ⟨F, E, hcover, ?_⟩
  intro j
  exact ⟨((hM i (z i j) (hz i j)).2.mono (closedBall_subset_closedBall hηold)), htarget (S i) q hq (z i j) δ c C α β (F j) (E j)⟩

end N2Restriction

#print axioms N2Restriction.uniform_distance_ready_atlases_bounded
