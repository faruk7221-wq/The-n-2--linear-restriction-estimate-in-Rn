import continuation.ActualFamilyBallApproximationV47
import continuation.ActualTerminalExpansionV47
import continuation.AtlasSelectedMajorantV42
import continuation.WeightedProductErrorV42

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal

/-- The product error from retaining packets in a covering ball is rapidly
decreasing and charged to the original product of input norms. The estimate
is uniform in the variety, ball, and every prior original-packet selection. -/
theorem actual_terminal_product_error {d k : ℕ}
    (S : Fin k → SmoothPatch (d+1)) (A : (i : Fin k) → PacketGraphAtlas (S i))
    {τ : ℝ} (hτ : 0 < τ) :
    ∃ M : ℝ, 1 ≤ M ∧ ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ N : ℝ, ∃ C : ℝ, 0 ≤ C ∧
    ∀ R : ℝ, R₀ ≤ R →
    ∀ (Q : (i : Fin k) → (j : Fin (A i).size) →
      CoordinateCapFamily ((A i).patch j).support (R^(-1/2 : ℝ)))
      (hr : 0 < R^(-1/2 : ℝ)), (∀ i, R^(-1/2 : ℝ) ≤ (A i).capRadius) →
    ∀ B : ℝ, 0 ≤ B → (∀ i j, ((Q i j).centers.card : ℝ) ≤ B*R^((d : ℝ)/2)) →
    ∀ (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure)
      (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure),
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
    ∀ (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin d → ℤ))
      (Ω : Set (Ambient (d+1))) (c : Ambient (d+1)) (ρ : ℝ)
      (x : Ambient (d+1)), ‖x‖ ≤ R → x ∈ Ω ∩ ball c ρ →
    ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
        (fun i => (A i).cellInput (Q i) hr (f i) (U i)) x -
      extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
        (fun i => (A i).cellInput (Q i) hr (f i)
          ((A i).actualRetainedSelection (Q i) (U i) c ρ R (R^(1/2+τ)/10) Ω)) x‖ ≤
      (k : ℝ)*(C*Real.sqrt B*R^(-N))*M^k*∏ i, ‖g i‖ := by
  classical
  choose D hD hmajor using fun i => (A i).selected_input_majorant
  let M := 1+∑ i, D i
  have hD0 i : 0 ≤ D i := zero_le_one.trans (hD i)
  have hM : 1 ≤ M := le_add_of_nonneg_right (Finset.sum_nonneg (fun i _ => hD0 i))
  have hiM i : D i ≤ M := (Finset.single_le_sum (fun j _ => hD0 j) (Finset.mem_univ i)).trans
    (le_add_of_nonneg_left zero_le_one)
  obtain ⟨R₀,hR₀,htail⟩ := atlas_family_ball_approximation S A hτ
  refine ⟨M,hM,R₀,hR₀,fun N => ?_⟩
  obtain ⟨C,hC,hc⟩ := htail N
  refine ⟨C,hC,?_⟩
  intro R hR Q hr hsmall B hB hcount g f he U Ω c ρ x hx hxΩ
  let F := fun i => extension (Measure.hausdorffMeasure (d : ℝ)) id
    ((A i).cellInput (Q i) hr (f i) (U i)) x
  let G := fun i => extension (Measure.hausdorffMeasure (d : ℝ)) id
    ((A i).cellInput (Q i) hr (f i)
      ((A i).actualRetainedSelection (Q i) (U i) c ρ R (R^(1/2+τ)/10) Ω)) x
  have hF i : ‖F i‖ ≤ M*‖g i‖ :=
    ((hmajor i (Q i) hr (g i) (f i) (he i) _).2 (hsmall i) x).trans
      (mul_le_mul_of_nonneg_right (hiM i) (norm_nonneg _))
  have hG i : ‖G i‖ ≤ M*‖g i‖ :=
    ((hmajor i (Q i) hr (g i) (f i) (he i) _).2 (hsmall i) x).trans
      (mul_le_mul_of_nonneg_right (hiM i) (norm_nonneg _))
  have hd i : ‖F i-G i‖ ≤ (C*Real.sqrt B*R^(-N))*‖g i‖ := by
    have hh := hc R hR i (Q i) hr (hsmall i) B hB (hcount i) (f i) (g i) (he i)
      Ω ∅ (fun _ => ⊥) c ρ 0 0 (U i) x hx hxΩ
    rw [← (A i).actual_retained_extension_split (Q i) hr (hsmall i) (f i) (U i)
      ∅ (fun _ => ⊥) c ρ 0 0 R (R^(1/2+τ)/10) Ω x] at hh
    exact hh
  have hδ : 0 ≤ C*Real.sqrt B*R^(-N) :=
    mul_nonneg (mul_nonneg hC (Real.sqrt_nonneg _))
      (Real.rpow_nonneg (zero_le_one.trans (hR₀.trans hR)) _)
  simpa only [Finset.card_univ,Fintype.card_fin,extensionProduct] using
    weighted_product_difference_bound Finset.univ F G (fun i => ‖g i‖)
      (fun _ => norm_nonneg _) hM hδ hF hG hd

end N2Restriction
#print axioms N2Restriction.actual_terminal_product_error
