import continuation.ReferenceTargetsV28

namespace N2Restriction
open MeasureTheory Set Metric
open scoped NNReal ENNReal

/-- The physical normal strip on an actual compact chart is compact. Its
closedness is proved through the affine normal identity on the parameter ball. -/
theorem MeasuredTubularChart.compact_frame_strip {n : ℕ} {S : SmoothPatch n}
    {Q : Ambient n →L[ℝ] ℝ × ℝ} {z : Ambient n} {δ r ρ s : ℝ}
    {B : ℕ → ℝ} {c C : ℝ≥0} {L : ℝ}
    (F : MeasuredTubularChart S Q z δ r ρ s B c C L) (hρ : ρ ≤ r) (ε : ℝ) :
    IsCompact {y ∈ F.carrier | ‖Q (S.normal y)‖ ≤ ε} := by
  let A := closedBall (0 : Ambient (n - 1)) ρ ∩
    {t | ‖Q (S.normal z) + F.normalCoord t‖ ≤ ε}
  have hA : IsCompact A := (isCompact_closedBall _ _).inter_right
    (isClosed_le (continuous_const.add F.normalCoord.continuous).norm continuous_const)
  have heq : {y ∈ F.carrier | ‖Q (S.normal y)‖ ≤ ε} = F.param '' A := by
    ext y
    constructor
    · rintro ⟨⟨t, ht, rfl⟩, hs⟩
      refine ⟨t, ⟨ht, ?_⟩, rfl⟩
      simpa only [(F.bounds t (closedBall_subset_closedBall hρ ht)).2.1] using hs
    · rintro ⟨t, ⟨ht, hs⟩, rfl⟩
      refine ⟨⟨t, ht, rfl⟩, ?_⟩
      simpa only [(F.bounds t (closedBall_subset_closedBall hρ ht)).2.1] using hs
  rw [heq]
  exact hA.image_of_continuousOn (fun t ht =>
    (F.bounds t (closedBall_subset_closedBall hρ ht.1)).2.2.1.continuousAt.continuousWithinAt)

/-- A measurable, everywhere supported representative of a function with
essential support in a measurable set. No null-set support assumption is
silently strengthened to a pointwise assumption. -/
theorem measurable_supported_representative {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) {T : Set Ω} (hT : MeasurableSet T)
    (g : Ω → ℂ) (hg : Measurable g) (hs : HasFrequencySupport μ id T g) :
    ∃ f : Ω → ℂ, Measurable f ∧ f =ᵐ[μ] g ∧ (∀ x, f x ≠ 0 → x ∈ T) := by
  classical
  refine ⟨T.indicator g, hg.indicator hT, ?_, ?_⟩
  · filter_upwards [hs] with x hx
    by_cases ht : x ∈ T
    · exact indicator_of_mem ht g
    · have hz : g x = 0 := by by_contra hn; exact ht (hx hn)
      simp [ht, hz]
  · intro x hx
    by_contra ht
    exact hx (indicator_of_notMem ht g)

end N2Restriction

#print axioms N2Restriction.MeasuredTubularChart.compact_frame_strip
#print axioms N2Restriction.measurable_supported_representative
