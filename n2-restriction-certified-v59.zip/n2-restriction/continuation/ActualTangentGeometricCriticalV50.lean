import continuation.ActualTangentCriticalV50
import continuation.TerminalCubeGeometryV50
import continuation.EmptyPatchTangentV50
namespace N2Restriction
open MeasureTheory Set Metric Filter
open scoped ENNReal NNReal

/-- Critical actual tangent bound from terminal near/far stage geometry.
Admissible cube frames are constructed internally, and empty subpatches
are handled by their zero contribution. -/
theorem actualTangentSum_geometric_critical_bound {k : ℕ} (hk : 3 ≤ k)
    (P : Fin k → SmoothPatch (k+2)) {ι : ℝ}
    (Dsub : ∀ i, DirectionalSubdivision (P i) ι) (a : ∀ i, Fin (Dsub i).size) (A : (i : Fin k) → PacketGraphAtlas ((fun i => (Dsub i).piece (a i)) i))
    {κ : ℝ} (B : ArticleLocalizationAtlas (fun i => (Dsub i).piece (a i)) κ)
    (V : Fin k → Set (Ambient (k+2))) (m : ℝ)
    (hS : ∀ i, ((fun i => (Dsub i).piece (a i)) i).extendedSurface ∩ V i ⊆ ((fun i => (Dsub i).piece (a i)) i).support) (hm : 0 < m)
    {ε τ lam : ℝ} (hε : 0 < ε)
    (hexternal : B.UniformLocalizedInput (baseline (k : ℝ))) (hτ : 0 < τ) (hτ' : τ < 1/4) (hlam : 1 ≤ lam)
    (C C₀ θ Cext Bcap : ℝ)
    (hC : 1 ≤ C) (hC₀ : 1+Real.sqrt (k+2 : ℕ)*(1+C)/2 ≤ C₀)
    (hθ : 0 < θ) (hBcap : 0 ≤ Bcap)
    (hKak : ∀ r w : ℝ, 1 ≤ w → w < r →
      FiniteDirectionalKakeya (volume.restrict (ball 0 r))
        (fun i => (P i).normal ((Dsub i).anchor (a i))) ι w (1/((k : ℝ)-1))
        (ENNReal.ofReal (Cext*r^(ε*(baseline (k : ℝ)))*w^((k+2 : ℕ)-ε*(baseline (k : ℝ))))))
    (hterminalFrame : (∀ i, ((Dsub i).piece (a i)).support.Nonempty) →
      ∀ (V₀ W : Submodule ℝ (Ambient (k+2))) (near : Finset (Fin k)),
      ‖V₀.starProjection-W.starProjection‖ < 2*ι →
      (∀ i ∈ near, directionPlaneAngle ((P i).normal ((Dsub i).anchor (a i))) V₀ ≤ 4*ι) →
      Module.finrank ℝ W+nearᶜ.card = k →
      ∃ q : ArticleFrame (fun i => (Dsub i).piece (a i)) κ,
        pairPlane q.val = (W ⊔ Submodule.span ℝ
          ((fun i => (P i).normal ((Dsub i).anchor (a i))) '' (↑nearᶜ : Set (Fin k))))ᗮ) :
    ∃ K : ENNReal, K ≠ ∞ ∧ ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ R : ℝ, R₀ ≤ R →
    ∀ (Q : (i : Fin k) → (j : Fin (A i).size) →
      CoordinateCapFamily ((A i).patch j).support (R^(-1/2 : ℝ)))
      (hr : 0 < R^(-1/2 : ℝ)), (∀ i, R^(-1/2 : ℝ) ≤ (A i).capRadius) →
    (∀ i j, ((Q i j).centers.card : ℝ) ≤ Bcap*R^(((k+1 : ℕ) : ℝ)/2)) →
    ∀ (g : (i : Fin k) → Lp ℂ 2 ((fun i => (Dsub i).piece (a i)) i).surfaceMeasure)
      (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure),
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
    (∀ i j, HasFrequencySupport ((A i).graph j).surfaceMeasure ((A i).patch j).rotation
      (marginRegion (V i) (m-R^(-1/4 : ℝ))) (f i j)) →
    ∀ (L : ℕ) (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin (k+1) → ℤ))
      (Z : Set (Ambient (k+2))) (T : Ambient (k+2) → Submodule ℝ (Ambient (k+2)))
      (c : Fin L → Ambient (k+2)) (Ω : Set (Ambient (k+2))),
    (∀ l t, l ≠ t → 2*(θ*(R^(1-τ))) ≤ dist (c l) (c t)) →
    MeasurableSet Ω → Ω ⊆ closedBall 0 R →
    (∀ (zgrid : meetingGrid (n := k+2) (lam*R^(1/2+τ)) R) (l : Fin L), ((Ω ∩ ball (c l) (R^(1-τ))) ∩ gridCube (gridCentre (lam*R^(1/2+τ)) zgrid.val) (lam*R^(1/2+τ))).Nonempty →
      HasTerminalCubeGeometry P Dsub a Z T (c l) (gridCentre (lam*R^(1/2+τ)) zgrid.val) (R^(1-τ)) (lam*R^(1/2+τ))) →
    positiveNorm
      (actualTangentSum A Q hr f U Z T c (R^(1-τ)) (lam*R^(1/2+τ)) C₀ R (R^(1/2+τ)/10) Ω) (critical (k : ℝ)) volume ≤
      K*ENNReal.ofReal (R^(sigma (k : ℝ) τ ε))*∏ i, ENNReal.ofReal ‖g i‖ := by
  classical
  by_cases hne : ∀ i, ((Dsub i).piece (a i)).support.Nonempty
  · obtain ⟨K,hK,R₀,hR₀,hb⟩ := actualTangentSum_critical_bound hk P Dsub a A B V m hS hm
      hε hexternal hτ hτ' hlam C C₀ θ Cext Bcap hC hC₀ hθ hBcap hKak
    refine ⟨K,hK,R₀,hR₀,?_⟩
    intro R hR Q hr hsmall hcount g f he hf L U Z T c Ω hsep hΩ hΩR hgeometry
    apply hb R hR Q hr hsmall hcount g f he hf L U Z T c Ω hsep hΩ hΩR
    intro zgrid l hactive
    exact terminal_cube_frame_of_geometry P Dsub a (hterminalFrame hne) (hgeometry zgrid l hactive)
  · obtain ⟨i,hi⟩ := not_forall.mp hne
    have hempty : ∃ i, ((Dsub i).piece (a i)).support = ∅ :=
      ⟨i,Set.not_nonempty_iff_eq_empty.mp hi⟩
    refine ⟨0,by simp,1,le_rfl,?_⟩
    intro R hR Q hr hsmall _hcount g f he _hf L U Z T c Ω hsep _hΩ _hΩR _hgeometry
    have hRpos : 0 < R := zero_lt_one.trans_le hR
    have hρ : 0 < R^(1-τ) := Real.rpow_pos_of_pos hRpos _
    have hz := actualTangentSum_eq_zero_of_empty_patch (fun i => (Dsub i).piece (a i)) A hθ Q hr
      hsmall g f he hempty U Z T c (R^(1-τ)) (lam*R^(1/2+τ)) C₀ R (R^(1/2+τ)/10) Ω hρ hsep
    rw [hz]
    have hk0 : (0 : ℝ) < k := by exact_mod_cast (show 0 < k by omega)
    have hpc := critical_pos hk0
    simp only [positiveNorm,Pi.zero_apply,ENNReal.zero_rpow_of_pos hpc,lintegral_zero,
      ENNReal.zero_rpow_of_pos (by positivity : 0 < 1/critical (k : ℝ)),zero_mul,le_refl]

end N2Restriction
#print axioms N2Restriction.actualTangentSum_geometric_critical_bound
