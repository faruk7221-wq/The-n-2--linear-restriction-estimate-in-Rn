import continuation.RegularizedOscillatoryBoundV55
namespace N2Restriction
set_option maxHeartbeats 800000

/-- Optimize the checked regularization budget algebraically: take e=t^2,
alpha=t and freq*t^5>=1. This yields a coefficient times t. -/
theorem fifth_power_regularization_budget {freq t c M N B l : ℝ}
    (hf : 0 < freq) (ht : 0 < t) (ht1 : t ≤ 1) (_hc : 0 < c)
    (hM : 0 ≤ M) (hN : 0 ≤ N) (hB : 0 ≤ B) (hl : 0 ≤ l)
    (hscale : 1 ≤ freq*t^5) :
    (2*M*(1/(t^2))+l*(N*(1/(t^2))+M*((1/(t^2)^2)*B)))/freq +
      (M*(2*t/c)+(M*((t^2)^2/t^2))*l) ≤
        (2*M+l*(N+M*B)+2*M/c+M*l)*t := by
  let K := 2*M+l*(N+M*B)
  have hK : 0 ≤ K := by dsimp [K]; positivity
  have ht0 := ht.ne'
  have ht2 : t^2 ≤ 1 := by nlinarith
  have ht2t : t^2 ≤ t := by nlinarith
  have heq : (2*M*(1/(t^2))+l*(N*(1/(t^2))+M*((1/(t^2)^2)*B)))*t^4 =
      2*M*t^2+l*(N*t^2+M*B) := by field_simp
  have hraw : 2*M*(1/(t^2))+l*(N*(1/(t^2))+M*((1/(t^2)^2)*B)) ≤ K/t^4 := by
    apply (le_div_iff₀ (pow_pos ht 4)).mpr
    rw [heq]
    dsimp [K]
    nlinarith [mul_nonneg (show 0 ≤ 2*M+l*N by positivity) (sub_nonneg.mpr ht2)]
  have hscale' : K/t^4 ≤ K*t*freq := by
    apply (div_le_iff₀ (pow_pos ht 4)).mpr
    calc
      K ≤ K*(freq*t^5) := by simpa only [mul_one] using mul_le_mul_of_nonneg_left hscale hK
      _ = K*t*freq*t^4 := by ring
  have hm : (2*M*(1/(t^2))+l*(N*(1/(t^2))+M*((1/(t^2)^2)*B)))/freq ≤ K*t :=
    (div_le_iff₀ hf).mpr (hraw.trans hscale')
  have her : (M*((t^2)^2/t^2))*l = M*l*t^2 := by field_simp
  have hr : M*(2*t/c)+(M*((t^2)^2/t^2))*l ≤ (2*M/c+M*l)*t := by
    rw [her]
    have hmul := mul_le_mul_of_nonneg_left ht2t (show 0 ≤ M*l by positivity)
    calc
      _ ≤ M*(2*t/c)+M*l*t := add_le_add_left hmul _
      _ = _ := by ring
  exact (add_le_add hm hr).trans_eq (by dsimp [K]; ring)
end N2Restriction
#print axioms N2Restriction.fifth_power_regularization_budget
