import continuation.NormalComplementProjectionV33

namespace N2Restriction

/-- Exact resolvent identity for two coordinate equivalences. -/
theorem coordinate_inverse_difference {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [NormedAddCommGroup F] [NormedSpace ℝ F]
    (e f : E ≃L[ℝ] F) :
    e.symm.toContinuousLinearMap - f.symm.toContinuousLinearMap =
      e.symm.toContinuousLinearMap.comp
        ((f.toContinuousLinearMap - e.toContinuousLinearMap).comp f.symm.toContinuousLinearMap) := by
  ext x
  simp only [ContinuousLinearMap.sub_apply, ContinuousLinearMap.comp_apply,
    ContinuousLinearEquiv.coe_coe, map_sub, f.apply_symm_apply, e.symm_apply_apply]

/-- Uniform inverse bounds turn frame-map closeness into inverse-coordinate
closeness, with the explicit squared conditioning cost. -/
theorem coordinate_inverse_difference_norm_le {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [NormedAddCommGroup F] [NormedSpace ℝ F]
    (e f : E ≃L[ℝ] F) (B : ℝ) (hB : 0 ≤ B)
    (he : ‖e.symm.toContinuousLinearMap‖ ≤ B) (hf : ‖f.symm.toContinuousLinearMap‖ ≤ B) :
    ‖e.symm.toContinuousLinearMap - f.symm.toContinuousLinearMap‖ ≤
      B ^ 2 * ‖e.toContinuousLinearMap - f.toContinuousLinearMap‖ := by
  rw [coordinate_inverse_difference]
  calc
    _ ≤ ‖e.symm.toContinuousLinearMap‖ *
        ‖(f.toContinuousLinearMap - e.toContinuousLinearMap).comp f.symm.toContinuousLinearMap‖ :=
      ContinuousLinearMap.opNorm_comp_le _ _
    _ ≤ B * (‖f.toContinuousLinearMap - e.toContinuousLinearMap‖ * B) := by
      apply mul_le_mul he _ (norm_nonneg _) hB
      exact (ContinuousLinearMap.opNorm_comp_le _ _).trans (mul_le_mul_of_nonneg_left hf (norm_nonneg _))
    _ = _ := by rw [norm_sub_rev]; ring

/-- Restricting inverse coordinates to the complementary block does not
increase the perturbation norm. -/
theorem normalComplementProjection_difference_norm_le {ι : Type*} [Fintype ι] {n d : ℕ}
    (e f : (Sum ι (Fin d) → ℝ) ≃L[ℝ] Ambient n) :
    ‖normalComplementProjection e - normalComplementProjection f‖ ≤
      ‖e.symm.toContinuousLinearMap - f.symm.toContinuousLinearMap‖ := by
  apply ContinuousLinearMap.opNorm_le_bound _ (norm_nonneg _)
  intro x
  apply (pi_norm_le_iff_of_nonneg (mul_nonneg (norm_nonneg _) (norm_nonneg _))).mpr
  intro i
  exact (norm_le_pi_norm (e.symm x - f.symm x) (Sum.inl i)).trans
    ((e.symm.toContinuousLinearMap - f.symm.toContinuousLinearMap).le_opNorm x)

end N2Restriction

#print axioms N2Restriction.coordinate_inverse_difference
#print axioms N2Restriction.coordinate_inverse_difference_norm_le
#print axioms N2Restriction.normalComplementProjection_difference_norm_le
