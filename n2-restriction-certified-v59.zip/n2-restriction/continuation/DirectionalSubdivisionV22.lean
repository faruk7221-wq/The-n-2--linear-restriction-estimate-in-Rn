import N2Restriction
import continuation.KakeyaDimensionV21

namespace N2Restriction
open MeasureTheory Set Filter

/-- A compact subpatch with a smaller open neighborhood and the original defining geometry. -/
def SmoothPatch.subpatch {n : ℕ} (S : SmoothPatch n) (K : Set (Ambient n))
    (hK : IsCompact K) (hKS : K ⊆ S.support) (V : Set (Ambient n)) (hV : IsOpen V)
    (hKV : K ⊆ V) (hVS : V ⊆ S.neighborhood) : SmoothPatch n where
  support := K
  compact_support := hK
  neighborhood := V
  open_neighborhood := hV
  support_inside := hKV
  defining := S.defining
  smooth_defining := S.smooth_defining.mono hVS
  support_on_surface := fun z hz => S.support_on_surface z (hKS hz)
  normal := S.normal
  smooth_normal := S.smooth_normal.mono hVS
  normal_unit := fun z hz => S.normal_unit z (hVS hz)
  normalScale := S.normalScale
  positive_normalScale := fun z hz => S.positive_normalScale z (hVS hz)
  normal_differential := fun z hz => S.normal_differential z (hVS hz)

/-- Data for a finite directional subdivision; closeness holds on each full open neighborhood. -/
structure DirectionalSubdivision {n : ℕ} (S : SmoothPatch n) (ε : ℝ) where
  size : ℕ
  piece : Fin size → SmoothPatch n
  anchor : Fin size → Ambient n
  anchor_mem : ∀ j, anchor j ∈ S.support
  support_subset : ∀ j, (piece j).support ⊆ S.support
  cover : S.support ⊆ ⋃ j, (piece j).support
  normal_eq : ∀ j, (piece j).normal = S.normal
  extended_subset : ∀ j, (piece j).extendedSurface ⊆ S.extendedSurface
  normal_close : ∀ j z, z ∈ (piece j).neighborhood →
    dist ((piece j).normal z) (S.normal (anchor j)) < ε

/-- Compact supports admit a finite subdivision with arbitrarily small normal variation,
including a neighborhood of every new support. -/
theorem SmoothPatch.exists_directionalSubdivision {n : ℕ} (S : SmoothPatch n)
    {ε : ℝ} (hε : 0 < ε) : Nonempty (DirectionalSubdivision S ε) := by
  classical
  have hloc (a : S.support) : ∃ δ : ℝ, 0 < δ ∧ ∀ z : Ambient n,
      dist z a < δ → dist (S.normal z) (S.normal a) < ε := by
    have hc := S.smooth_normal.continuousOn.continuousAt
      (S.open_neighborhood.mem_nhds (S.support_inside a.property))
    exact Metric.continuousAt_iff.mp hc ε hε
  choose δ hδ hlocal using hloc
  let B := fun a : S.support => Metric.ball (a : Ambient n) (δ a / 2)
  have hcover : S.support ⊆ ⋃ a : S.support, B a := by
    intro x hx
    exact Set.mem_iUnion.mpr ⟨⟨x, hx⟩, Metric.mem_ball_self (half_pos (hδ ⟨x, hx⟩))⟩
  obtain ⟨F, hF⟩ := S.compact_support.elim_finite_subcover B (fun _ => Metric.isOpen_ball) hcover
  let e := Fintype.equivFin ↥F
  let a : Fin (Fintype.card ↥F) → S.support := fun j => (e.symm j).val
  let K := fun j => S.support ∩ Metric.closedBall (a j : Ambient n) (δ (a j) / 2)
  let V := fun j => S.neighborhood ∩ S.normal ⁻¹' Metric.ball (S.normal (a j)) ε
  have hK j : IsCompact (K j) := S.compact_support.inter_right Metric.isClosed_closedBall
  have hV j : IsOpen (V j) :=
    S.smooth_normal.continuousOn.isOpen_inter_preimage S.open_neighborhood Metric.isOpen_ball
  have hKV j : K j ⊆ V j := by
    intro z hz
    refine ⟨S.support_inside hz.1, ?_⟩
    apply hlocal (a j) z
    exact lt_of_le_of_lt hz.2 (by have := hδ (a j); linarith)
  let P := fun j => S.subpatch (K j) (hK j) Set.inter_subset_left (V j) (hV j) (hKV j) Set.inter_subset_left
  refine ⟨⟨Fintype.card ↥F, P, (fun j => a j), (fun j => (a j).property),
    (fun _ => Set.inter_subset_left), ?_, (fun _ => rfl), ?_, ?_⟩⟩
  · intro x hx
    obtain ⟨b, hbF, hxb⟩ := Set.mem_iUnion₂.mp (hF hx)
    refine Set.mem_iUnion.mpr ⟨e ⟨b, hbF⟩, ?_⟩
    change x ∈ S.support ∩ Metric.closedBall _ _
    simp only [a, Equiv.symm_apply_apply]
    exact ⟨hx, Metric.ball_subset_closedBall hxb⟩
  · intro j z hz
    exact ⟨hz.1.1, hz.2⟩
  · intro j z hz
    exact hz.2

/-- Every chosen reference direction is an actual unit normal of the original support. -/
theorem DirectionalSubdivision.reference_unit {n : ℕ} {S : SmoothPatch n} {ε : ℝ}
    (D : DirectionalSubdivision S ε) (j : Fin D.size) : ‖S.normal (D.anchor j)‖ = 1 :=
  S.normal_unit _ (S.support_inside (D.anchor_mem j))

/-- The derivative of the normal, hence the shape operator, is unchanged by subdivision. -/
theorem DirectionalSubdivision.shape_eq {n : ℕ} {S : SmoothPatch n} {ε : ℝ}
    (D : DirectionalSubdivision S ε) (j : Fin D.size) : (D.piece j).shape = S.shape := by
  unfold SmoothPatch.shape
  rw [D.normal_eq j]

/-- Every tuple of subpatches inherits both quantitative geometric constants. -/
theorem DirectionalSubdivision.geometric_hypotheses {k : ℕ}
    {S : Fin k → SmoothPatch (k + 2)} {ε ν κ : ℝ}
    (D : ∀ i, DirectionalSubdivision (S i) ε) (j : ∀ i, Fin (D i).size)
    (h : GeometricHypotheses S ν κ) :
    GeometricHypotheses (fun i => (D i).piece (j i)) ν κ := by
  refine ⟨h.1, h.2.1, ?_⟩
  intro z hz
  have H := h.2.2 z (fun i => (D i).extended_subset (j i) (hz i))
  have he : (fun i => ((D i).piece (j i)).normal (z i)) =
      (fun i => (S i).normal (z i)) := by
    funext i
    rw [(D i).normal_eq]
  let P := fun (N : Fin k → Ambient (k + 2)) (A : Fin k → Ambient (k + 2) →L[ℝ] Ambient (k + 2)) =>
    ν ^ 2 ≤ Matrix.det (fun i l => inner ℝ (N i) (N l)) ∧
    ∀ i, ∀ v : commonTangent N,
      κ * ‖v‖ ≤ ‖(commonTangent N).orthogonalProjection (A i v)‖
  change P (fun i => ((D i).piece (j i)).normal (z i))
    (fun i => ((D i).piece (j i)).shape (z i))
  rw [he]
  have ha : (fun i => ((D i).piece (j i)).shape (z i)) =
      (fun i => (S i).shape (z i)) := by
    funext i
    rw [(D i).shape_eq]
  rw [ha]
  exact H


/-- Reference normals satisfy the original quantitative transversality bound. -/
theorem DirectionalSubdivision.reference_gram {k : ℕ}
    {S : Fin k → SmoothPatch (k + 2)} {ε ν κ : ℝ}
    (D : ∀ i, DirectionalSubdivision (S i) ε) (j : ∀ i, Fin (D i).size)
    (h : GeometricHypotheses S ν κ) :
    ν ^ 2 ≤ Matrix.det (fun i l => inner ℝ
      ((S i).normal ((D i).anchor (j i))) ((S l).normal ((D l).anchor (j l)))) := by
  apply (h.2.2 (fun i => (D i).anchor (j i)) _).1
  intro i
  exact ⟨(S i).support_inside ((D i).anchor_mem (j i)),
    (S i).support_on_surface _ ((D i).anchor_mem (j i))⟩

/-- In particular, the reference directions are linearly independent. -/
theorem DirectionalSubdivision.reference_independent {k : ℕ}
    {S : Fin k → SmoothPatch (k + 2)} {ε ν κ : ℝ}
    (D : ∀ i, DirectionalSubdivision (S i) ε) (j : ∀ i, Fin (D i).size)
    (h : GeometricHypotheses S ν κ) :
    LinearIndependent ℝ (fun i => (S i).normal ((D i).anchor (j i))) := by
  apply normals_independent_of_gram
  exact ne_of_gt (lt_of_lt_of_le (sq_pos_of_pos h.1) (DirectionalSubdivision.reference_gram D j h))

/-- Every reference tuple satisfies the dimension inequality required by the Kakeya input. -/
theorem DirectionalSubdivision.reference_kakeya_dimension {k : ℕ} (hk : 1 ≤ k)
    {S : Fin k → SmoothPatch (k + 2)} {ε ν κ : ℝ}
    (D : ∀ i, DirectionalSubdivision (S i) ε) (j : ∀ i, Fin (D i).size)
    (h : GeometricHypotheses S ν κ) (U : Submodule ℝ (Ambient (k + 2))) :
    (k - 1) * Module.finrank ℝ U ≤
      ∑ i, Module.finrank ℝ (U.map ((ℝ ∙ (S i).normal ((D i).anchor (j i)))ᗮ.orthogonalProjection :
        Ambient (k + 2) →ₗ[ℝ] (ℝ ∙ (S i).normal ((D i).anchor (j i)))ᗮ)) :=
  kakeya_projection_dimension_inequality hk _
    (DirectionalSubdivision.reference_independent D j h) U

end N2Restriction

#print axioms N2Restriction.DirectionalSubdivision.geometric_hypotheses
#print axioms N2Restriction.DirectionalSubdivision.reference_gram
#print axioms N2Restriction.DirectionalSubdivision.reference_independent
#print axioms N2Restriction.DirectionalSubdivision.reference_kakeya_dimension
#print axioms N2Restriction.DirectionalSubdivision.reference_unit
#print axioms N2Restriction.DirectionalSubdivision.shape_eq
#print axioms N2Restriction.SmoothPatch.exists_directionalSubdivision
