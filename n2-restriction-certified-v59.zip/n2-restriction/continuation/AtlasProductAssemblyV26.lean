import continuation.AtlasSupportV26
import continuation.SubdivisionProductV22

namespace N2Restriction
open MeasureTheory Set
open scoped ENNReal BigOperators

section
variable {k n : ℕ} (μ : Fin k → Measure (Ambient n))
  (S : Fin k → Set (Ambient n)) (hS : ∀ i, MeasurableSet (S i))
  (m : Fin k → ℕ) (K : ∀ i, Fin (m i) → Set (Ambient n))
  (hK : ∀ i j, MeasurableSet (K i j)) (hcover : ∀ i, S i ⊆ ⋃ j, K i j)
  [∀ i, IsFiniteMeasure ((μ i).restrict (S i))]
  (g : ∀ i, Lp ℂ 2 ((μ i).restrict (S i)))

include hcover

/-- The actual atlas inputs give an exact finite expansion of the original
multilinear extension product, with each input on its own chart measure. -/
theorem atlas_product_reconstruction (x : Ambient n) :
    (∏ i, extension ((μ i).restrict (S i)) id (g i) x) =
      ∑ a : (∀ i, Fin (m i)), ∏ i, extension ((μ i).restrict (K i (a i))) id
        (atlasPatchInput (μ i) (S i) (hS i) (K i) (hK i) (g i) (a i)) x := by
  classical
  simp_rw [← atlasPatchInput_reconstruction (μ _) (S _) (hS _) (K _) (hK _) (hcover _)]
  exact Fintype.prod_sum _

/-- Finite atlas assembly in power-integral form, valid for every positive
exponent, including the quasi-Banach range. -/
theorem atlas_product_integral_bound (σ : Measure (Ambient n)) {p : ℝ} (hp : 0 < p) :
    (∫⁻ x, ‖∏ i, extension ((μ i).restrict (S i)) id (g i) x‖ₑ ^ p ∂σ) ≤
      finitePowerLoss (Fintype.card (∀ i, Fin (m i))) p *
      ∑ a : (∀ i, Fin (m i)), ∫⁻ x, ‖∏ i, extension ((μ i).restrict (K i (a i))) id
        (atlasPatchInput (μ i) (S i) (hS i) (K i) (hK i) (g i) (a i)) x‖ₑ ^ p ∂σ := by
  have hm (a : ∀ i, Fin (m i)) : Measurable (fun x =>
      ‖∏ i, extension ((μ i).restrict (K i (a i))) id
        (atlasPatchInput (μ i) (S i) (hS i) (K i) (hK i) (g i) (a i)) x‖ₑ ^ p) := by
    have hc i : Continuous (extension ((μ i).restrict (K i (a i))) id
        (atlasPatchInput (μ i) (S i) (hS i) (K i) (hK i) (g i) (a i))) := by
      have he : extension ((μ i).restrict (K i (a i))) id
          (atlasPatchInput (μ i) (S i) (hS i) (K i) (hK i) (g i) (a i)) =
          extension ((μ i).restrict (S i)) id
            (finiteCoverInput ((μ i).restrict (S i)) (K i) (hK i) (g i) (a i)) := by
        funext x
        exact atlasPatchInput_extension _ _ _ _ _ _ _ _
      rw [he]
      exact continuous_extension_of_memLp measurable_id (Lp.memLp _)
    exact (continuous_finset_prod _ (fun i _ => hc i)).enorm.measurable.pow_const p
  calc
    _ ≤ ∫⁻ x, finitePowerLoss (Fintype.card (∀ i, Fin (m i))) p *
        ∑ a : (∀ i, Fin (m i)), ‖∏ i, extension ((μ i).restrict (K i (a i))) id
          (atlasPatchInput (μ i) (S i) (hS i) (K i) (hK i) (g i) (a i)) x‖ₑ ^ p ∂σ := by
      apply lintegral_mono
      intro x
      dsimp only
      rw [atlas_product_reconstruction μ S hS m K hK hcover g x]
      exact finite_sum_enorm_rpow_le _ hp
    _ = _ := by
      rw [lintegral_const_mul _ (Finset.measurable_sum _ (fun a _ => hm a)),
        lintegral_finset_sum _ (fun a _ => hm a)]

/-- Supplied estimates for every chart tuple assemble with an explicit finite
loss and the original surface L2 norms. No local estimate is assumed implicitly. -/
theorem atlas_assemble_local_estimates (σ : Measure (Ambient n)) {p : ℝ} (hp : 0 < p)
    (C : (∀ i, Fin (m i)) → ℝ≥0∞)
    (hC : ∀ a, (∫⁻ x, ‖∏ i, extension ((μ i).restrict (K i (a i))) id
        (atlasPatchInput (μ i) (S i) (hS i) (K i) (hK i) (g i) (a i)) x‖ₑ ^ p ∂σ) ≤
        C a * ∏ i, ‖atlasPatchInput (μ i) (S i) (hS i) (K i) (hK i) (g i) (a i)‖ₑ ^ p) :
    (∫⁻ x, ‖∏ i, extension ((μ i).restrict (S i)) id (g i) x‖ₑ ^ p ∂σ) ≤
      (finitePowerLoss (Fintype.card (∀ i, Fin (m i))) p * ∑ a, C a) *
        ∏ i, ‖g i‖ₑ ^ p := by
  apply (atlas_product_integral_bound μ S hS m K hK hcover g σ hp).trans
  rw [mul_assoc, Finset.sum_mul]
  apply mul_le_mul_left'
  apply Finset.sum_le_sum
  intro a _
  apply (hC a).trans
  apply mul_le_mul_left'
  exact Finset.prod_le_prod' (fun i _ => ENNReal.rpow_le_rpow
    (enorm_le_iff_norm_le.mpr (atlasPatchInput_norm_le (μ i) (S i) (hS i) (K i) (hK i) (g i) (a i))) hp.le)

end
end N2Restriction

#print axioms N2Restriction.atlas_assemble_local_estimates
#print axioms N2Restriction.atlas_product_integral_bound
#print axioms N2Restriction.atlas_product_reconstruction
