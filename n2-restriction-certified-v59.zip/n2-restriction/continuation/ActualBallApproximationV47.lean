import continuation.ActualBallRetentionTailV47

namespace N2Restriction
open MeasureTheory Set

/-- The Section 7 retained tangent and nontangent extensions add to the
original selected extension on Omega in the ball, up to a uniform rapid tail.
All selections use the same original R-scale packets. -/
theorem PacketGraphAtlas.actual_tangent_nontangent_approximation {d : ℕ} {S : SmoothPatch (d+1)}
    (A : PacketGraphAtlas S) {τ : ℝ} (hτ : 0 < τ) :
    ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ N : ℝ, ∃ C : ℝ, 0 ≤ C ∧
      ∀ R : ℝ, R₀ ≤ R →
      ∀ (Q : (j : Fin A.size) → CoordinateCapFamily (A.patch j).support (R^(-1/2 : ℝ)))
        (hr : 0 < R^(-1/2 : ℝ)) (_hsmall : R^(-1/2 : ℝ) ≤ A.capRadius) (B : ℝ), 0 ≤ B →
      (∀ j, ((Q j).centers.card : ℝ) ≤ B*R^((d : ℝ)/2)) →
      ∀ (f : (j : Fin A.size) → Lp ℂ 2 (A.graph j).surfaceMeasure)
        (g : Lp ℂ 2 S.surfaceMeasure), (∑ j, ‖f j‖^2) ≤ ‖g‖^2 →
      ∀ (Ω Z : Set (Ambient (d+1))) (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1)))
        (c : Ambient (d+1)) (ρ b C₀ : ℝ)
        (U : (j : Fin A.size) → (Q j).centers → Set (Fin d → ℤ))
        (x : Ambient (d+1)), ‖x‖ ≤ R → x ∈ Ω ∩ Metric.ball c ρ →
      ‖extension (Measure.hausdorffMeasure (d : ℝ)) id (A.cellInput Q hr f U) x -
        (extension (Measure.hausdorffMeasure (d : ℝ)) id (A.cellInput Q hr f
          (A.actualTangentSelection Q U Z T c ρ b C₀ R (R^(1/2+τ)/10) Ω)) x +
         extension (Measure.hausdorffMeasure (d : ℝ)) id (A.cellInput Q hr f
          (A.actualNontangentSelection Q U Z T c ρ b C₀ R (R^(1/2+τ)/10) Ω)) x)‖ ≤
        C*Real.sqrt B*R^(-N)*‖g‖ := by
  obtain ⟨R₀,hR₀,htail⟩ := A.omitted_ball_rapid_tail hτ
  refine ⟨R₀,hR₀,fun N => ?_⟩
  obtain ⟨C,hC,hc⟩ := htail N
  refine ⟨C,hC,?_⟩
  intro R hR Q hr hsmall B hB hcount f g he Ω Z T c ρ b C₀ U x hx hxΩ
  rw [← A.actual_retained_extension_split Q hr hsmall f U Z T c ρ b C₀ R (R^(1/2+τ)/10) Ω x]
  let V : (j : Fin A.size) → (Q j).centers → Set (Fin d → ℤ) := fun j a => {ν | (A.originalPacketTube j a (R^(-1/2 : ℝ)) ν R (R^(1/2+τ)/10) ∩
    (Ω ∩ Metric.ball c ρ)).Nonempty}
  have hs : A.actualRetainedSelection Q U c ρ R (R^(1/2+τ)/10) Ω =
      fun j a => U j a ∩ V j a := rfl
  rw [hs,A.cellInput_extension_split Q hr hsmall f U V x]
  exact hc R hR Q hr B hB hcount f g he Ω c ρ U x hx hxΩ

end N2Restriction
#print axioms N2Restriction.PacketGraphAtlas.actual_tangent_nontangent_approximation
