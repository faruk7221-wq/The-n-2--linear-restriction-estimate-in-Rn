import continuation.PolynomialStageV41
import N2Restriction.PositiveAnalysis
import N2Restriction.ExtensionRegularity

namespace N2Restriction
open MeasureTheory
open scoped BigOperators ENNReal

/-- Actual extension products expand over all binary input selections. -/
theorem binary_extension_product {n k : ℕ}
    (μ : Fin k → Measure (Ambient n)) (f : Fin k → Bool → Ambient n → ℂ)
    (hf : ∀ i b, Integrable (f i b) (μ i)) (x : Ambient n) :
    extensionProduct μ (fun _ => id) (fun i y => ∑ b, f i b y) x =
      ∑ σ : Fin k → Bool, extensionProduct μ (fun _ => id) (fun i => f i (σ i)) x := by
  have he : ∀ i, extension (μ i) id (fun y => ∑ b, f i b y) x =
      ∑ b, extension (μ i) id (f i b) x := by
    intro i
    unfold extension
    simp_rw [Finset.mul_sum]
    exact integral_finset_sum _ (fun b _ => integrable_extension_kernel measurable_id (hf i b) x)
  simp only [extensionProduct, he]
  exact Fintype.prod_sum _

/-- Equation (6.3) and largest-summand selection for the actual extension
integrals. This compares total integrals only; the new density is reset
after making this binary choice. -/
theorem binary_extension_mass_selection {n k : ℕ}
    (μ : Fin k → Measure (Ambient n)) (f : Fin k → Bool → Ambient n → ℂ)
    (hf : ∀ i b, Integrable (f i b) (μ i)) (Ω : Set (Ambient n))
    {p : ℝ} (hp : 0 < p) (hp1 : p ≤ 1) :
    ∃ σ : Fin k → Bool,
      (∫⁻ x in Ω, ‖extensionProduct μ (fun _ => id) (fun i y => ∑ b, f i b y) x‖ₑ ^ p) ≤
        (2^k : ENNReal) *
          (∫⁻ x in Ω, ‖extensionProduct μ (fun _ => id) (fun i => f i (σ i)) x‖ₑ ^ p) := by
  classical
  let F := fun (σ : Fin k → Bool) x =>
    ‖extensionProduct μ (fun _ => id) (fun i => f i (σ i)) x‖ₑ ^ p
  have hF : ∀ σ, Measurable (F σ) := by
    intro σ
    exact (continuous_finset_prod _ (fun i _ => continuous_extension measurable_id (hf i (σ i)))).enorm.measurable.pow_const p
  have hpoint : ∀ x,
      ‖extensionProduct μ (fun _ => id) (fun i y => ∑ b, f i b y) x‖ₑ ^ p ≤ ∑ σ, F σ x := by
    intro x
    rw [binary_extension_product μ f hf]
    exact (ENNReal.rpow_le_rpow (enorm_sum_le _ _) hp.le).trans
      (positive_sum_rpow_le _ _ hp hp1)
  have hsum : (∫⁻ x in Ω,
      ‖extensionProduct μ (fun _ => id) (fun i y => ∑ b, f i b y) x‖ₑ ^ p) ≤
      ∑ σ, ∫⁻ x in Ω, F σ x := by
    exact (lintegral_mono hpoint).trans_eq (lintegral_finset_sum _ (fun σ _ => hF σ))
  obtain ⟨σ, _, hmax⟩ := Finset.exists_max_image Finset.univ
    (fun σ => ∫⁻ x in Ω, F σ x) Finset.univ_nonempty
  refine ⟨σ, hsum.trans ?_⟩
  calc
    ∑ τ, ∫⁻ x in Ω, F τ x ≤ ∑ _τ : Fin k → Bool, ∫⁻ x in Ω, F σ x :=
      Finset.sum_le_sum (fun τ hτ => hmax τ hτ)
    _ = (2^k : ENNReal) * ∫⁻ x in Ω, F σ x := by simp

end N2Restriction
#print axioms N2Restriction.binary_extension_product
#print axioms N2Restriction.binary_extension_mass_selection
