import continuation.CoordinateCellBudgetV41
import N2Restriction.DensityPackets

namespace N2Restriction
open MeasureTheory
open scoped BigOperators ENNReal

/-- The constructed coordinate cell budget transfers to the original
weighted input through the proved density operators. No extra packet
energy hypothesis or cap-count loss is introduced. -/
theorem CoordinateCapFamily.density_cell_energy_budget {d : ℕ} {C : Type*}
    {K : Set (Ambient d)} {r : ℝ} (P : CoordinateCapFamily K r) (hr : 0 < r)
    (D : PositiveBoundedDensity (volume : Measure (Ambient d))) (g : Lp ℂ 2 D.measure)
    (S : C → P.centers → Set (Fin d → ℤ)) (N : ENNReal)
    (hincidence : ∀ j ν, (∑' c, (S c j).indicator (fun _ => (1 : ENNReal)) ν) ≤ N) :
    (∑' c, ENNReal.ofReal (‖∑ j, ∑' ν : S c j, P.densityPacket hr D g j ν.val‖^2)) ≤
      ENNReal.ofReal (1/D.lower) *
        (ENNReal.ofReal (9^d : ℝ)*N*(ENNReal.ofReal D.upper*ENNReal.ofReal (‖g‖^2))) := by
  let f := D.toCoordinate g
  have he : ∀ c, (∑ j, ∑' ν : S c j, P.densityPacket hr D g j ν.val) =
      D.fromCoordinate (∑ j, ∑' ν : S c j, P.packet hr f j ν.val) := by
    intro c
    rw [map_sum]
    apply Finset.sum_congr rfl
    intro j _
    exact (D.fromCoordinate.map_tsum ((P.packet_hasSum hr f j).summable.subtype (S c j))).symm
  have hpoint : ∀ c, ENNReal.ofReal (‖∑ j, ∑' ν : S c j, P.densityPacket hr D g j ν.val‖^2) ≤
      ENNReal.ofReal (1/D.lower) * ENNReal.ofReal (‖∑ j, ∑' ν : S c j, P.packet hr f j ν.val‖^2) := by
    intro c
    rw [he c]
    simpa only [ENNReal.ofReal_mul (one_div_pos.mpr D.lower_pos).le] using
      ENNReal.ofReal_le_ofReal (D.fromCoordinate_energy (∑ j, ∑' ν : S c j, P.packet hr f j ν.val))
  have hg : ENNReal.ofReal (‖f‖^2) ≤ ENNReal.ofReal D.upper*ENNReal.ofReal (‖g‖^2) := by
    simpa only [ENNReal.ofReal_mul D.upper_nonneg] using ENNReal.ofReal_le_ofReal (D.toCoordinate_energy g)
  calc
    _ ≤ ∑' c, ENNReal.ofReal (1/D.lower) * ENNReal.ofReal (‖∑ j, ∑' ν : S c j, P.packet hr f j ν.val‖^2) :=
      ENNReal.tsum_le_tsum hpoint
    _ = ENNReal.ofReal (1/D.lower) * ∑' c, ENNReal.ofReal (‖∑ j, ∑' ν : S c j, P.packet hr f j ν.val‖^2) :=
      ENNReal.tsum_mul_left
    _ ≤ _ := mul_le_mul_left' ((P.cell_energy_budget hr f S N hincidence).trans (mul_le_mul_left' hg _)) _

end N2Restriction
#print axioms N2Restriction.CoordinateCapFamily.density_cell_energy_budget
