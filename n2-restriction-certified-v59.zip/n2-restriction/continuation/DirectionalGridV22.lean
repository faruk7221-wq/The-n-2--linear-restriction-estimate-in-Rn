import continuation.DirectionalKakeyaV22
import continuation.SubdivisionInputsV22
import continuation.OriginalGridV21

set_option maxHeartbeats 300000
namespace N2Restriction
open MeasureTheory Set
open scoped ENNReal BigOperators

/-- For each directional tuple, the original-input grid estimate follows from the explicit
finite straight-tube Kakeya input. The chart inputs are fixed before all packet scales. -/
theorem directional_original_grid_energy {d : ℕ} {I : Type} [Fintype I]
    {S : I → SmoothPatch (d + 1)} {ε : ℝ} (Dsub : ∀ i, DirectionalSubdivision (S i) ε)
    (a : ∀ i, Fin (Dsub i).size) (T : ∀ i, PacketGraphAtlas ((Dsub i).piece (a i))) :
    ∃ Cenergy : I → ℝ, (∀ i, 0 ≤ Cenergy i) ∧
    ∀ g : (i : I) → Lp ℂ 2 (S i).surfaceMeasure,
    ∃ f : (i : I) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure,
      (∀ i, (∑ j, ‖f i j‖ ^ 2) ≤ ‖g i‖ ^ 2 ∧
        (∑ j, ((T i).graph j).rotatedAmbientInput ((T i).patch j).rotation (f i j)) =
          ((Dsub i).piece (a i)).hausdorffInput ((Dsub i).input (g i) (a i))) ∧
      ∀ {r : ℝ} (Q : (i : I) → (j : Fin (T i).size) →
        CoordinateCapFamily ((T i).patch j).support r) (hr : 0 < r),
      let P := fun i => (j : Fin (T i).size) × ((Q i j).centers × (Fin d → ℤ))
      let A := fun i (t : P i) => ((T i).patch t.1).rotation
      let c := fun i (t : P i) => graphGradient ((T i).graph t.1).phase t.2.1
      let v := fun i (t : P i) => r⁻¹ • latticeVector t.2.2
      let e := fun i => (T i).kakeyaWeight (Q i) hr (f i)
      ∀ {R w C D b p : ℝ}, 0 ≤ R → 0 < b → 0 ≤ C → w ≤ D * b → 0 ≤ p →
      ∀ K : ℝ≥0∞,
      FiniteDirectionalKakeya
        (volume.restrict (Metric.closedBall 0 (R + Real.sqrt ((d + 1 : ℕ) : ℝ) * b)))
        (fun i => (S i).normal ((Dsub i).anchor (a i))) ε
        ((D + Real.sqrt ((d + 1 : ℕ) : ℝ) * (1 + C) / 2) * b) p
        (ENNReal.ofReal b ^ (d + 1) * K) →
      (∑' z : meetingGrid (n := d + 1) b R,
        (∏ i, selectedEnergy
          (packetCubeSelection (A i) (c i) (v i) R w C b (gridCentre b z)) (e i)) ^ p) ≤
        K * (∏ i, ENNReal.ofReal (Cenergy i * ‖g i‖ ^ 2)) ^ p := by
  classical
  obtain ⟨Cenergy, hCenergy, hdecomp⟩ := original_surface_grid_energy_of_kakeya
    (fun i => (Dsub i).piece (a i)) T
  refine ⟨Cenergy, hCenergy, ?_⟩
  intro g
  obtain ⟨f, hf, hgrid⟩ := hdecomp (fun i => (Dsub i).input (g i) (a i))
  have hnorm i : ‖(Dsub i).input (g i) (a i)‖ ^ 2 ≤ ‖g i‖ ^ 2 := by
    exact pow_le_pow_left₀ (norm_nonneg _) ((Dsub i).input_norm_le (g i) (a i)) 2
  refine ⟨f, (fun i => ⟨(hf i).1.trans (hnorm i), (hf i).2⟩), ?_⟩
  intro r Q hr
  dsimp only
  intro R w C D b p hR hb hC hw hp K hK
  have hactual := DirectionalSubdivision.packet_kakeya Dsub a T Q hr f
    (volume.restrict (Metric.closedBall 0 (R + Real.sqrt ((d + 1 : ℕ) : ℝ) * b))) hp
    (ENNReal.ofReal b ^ (d + 1) * K) hK
  have hbound := hgrid Q hr hR hb hC hw hp K (by simpa only [mul_assoc] using hactual)
  apply hbound.trans
  apply mul_le_mul_left'
  apply ENNReal.rpow_le_rpow _ hp
  apply Finset.prod_le_prod'
  intro i _
  exact ENNReal.ofReal_le_ofReal (mul_le_mul_of_nonneg_left (hnorm i) (hCenergy i))

end N2Restriction

#print axioms N2Restriction.directional_original_grid_energy
