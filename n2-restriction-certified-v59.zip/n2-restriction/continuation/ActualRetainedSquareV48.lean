import continuation.ActualBinaryRetentionV48
import continuation.SupportedBallSquareV48

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal NNReal

/-- The square G_i^2 in (7.14), using both actual ball-dependent selections. -/
noncomputable def PacketGraphAtlas.actualRetainedSquare {d L : ℕ} {S : SmoothPatch (d+1)}
    (A : PacketGraphAtlas S) {r : ℝ}
    (Q : (j : Fin A.size) → CoordinateCapFamily (A.patch j).support r) (hr : 0 < r)
    (f : (j : Fin A.size) → Lp ℂ 2 (A.graph j).surfaceMeasure)
    (U : (j : Fin A.size) → (Q j).centers → Set (Fin d → ℤ))
    (Z : Set (Ambient (d+1))) (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1)))
    (c : Fin L → Ambient (d+1)) (ρ b C₀ R w : ℝ) (Ω : Set (Ambient (d+1))) :
    Ambient (d+1) → ENNReal :=
  fun x => ∑ ls : Fin L × Bool, (ball (c ls.1) ρ).indicator (fun y =>
    ‖extension (Measure.hausdorffMeasure (d : ℝ)) id (A.cellInput Q hr f
      (if ls.2 then A.actualTangentSelection Q U Z T (c ls.1) ρ b C₀ R w Ω else
        A.actualNontangentSelection Q U Z T (c ls.1) ρ b C₀ R w Ω)) y‖ₑ ^ (2 : ℝ)) x

/-- The exact square function has the local-Plancherel times retention
energy bound. The same fixed patch support is required for its selected inputs;
this is provided by the proved child-margin support invariant. -/
theorem PacketGraphAtlas.actual_retained_square_integral {d : ℕ} {S : SmoothPatch (d+1)}
    (A : PacketGraphAtlas S) :
    ∃ C : ℝ≥0, ∃ B K : ℝ, 0 ≤ B ∧ 0 < K ∧ ∀ {L : ℕ} {R ρ θ w r : ℝ},
    0 ≤ R → 0 < ρ → 0 < θ → w ≤ ρ →
    ∀ (Q : (j : Fin A.size) → CoordinateCapFamily (A.patch j).support r) (hr : 0 < r)
      (f : (j : Fin A.size) → Lp ℂ 2 (A.graph j).surfaceMeasure)
      (U : (j : Fin A.size) → (Q j).centers → Set (Fin d → ℤ))
      (Z : Set (Ambient (d+1))) (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1)))
      (c : Fin L → Ambient (d+1)) (b C₀ : ℝ) (Ω : Set (Ambient (d+1))),
    (∀ l t, l ≠ t → 2*(θ*ρ) ≤ dist (c l) (c t)) →
    (∀ ls : Fin L × Bool, HasFrequencySupport (Measure.hausdorffMeasure (d : ℝ)) id S.support
      (A.cellInput Q hr f (if ls.2 then A.actualTangentSelection Q U Z T (c ls.1) ρ b C₀ R w Ω else
        A.actualNontangentSelection Q U Z T (c ls.1) ρ b C₀ R w Ω))) →
    (∫⁻ x, A.actualRetainedSquare Q hr f U Z T c ρ b C₀ R w Ω x) ≤
      (C : ENNReal)*ENNReal.ofReal ρ*(ENNReal.ofReal B *
        ENNReal.ofReal ((2*R*K/ρ+2)*(3/θ+1)^(d+1))*ENNReal.ofReal (∑ j, ‖f j‖^2)) := by
  obtain ⟨C,hC⟩ := S.supported_ball_square_integral
  obtain ⟨B,K,hB,hK,henergy⟩ := A.actual_binary_retention_energy
  refine ⟨C,B,K,hB,hK,?_⟩
  intro L R ρ θ w r hR hρ hθ hw Q hr f U Z T c b C₀ Ω hsep hs
  apply hC _ (fun ls : Fin L × Bool => c ls.1) ρ hρ.le hs
  simpa only [tsum_fintype] using henergy hR hρ hθ hw Q hr f U Z T c b C₀ Ω hsep

end N2Restriction
#print axioms N2Restriction.PacketGraphAtlas.actual_retained_square_integral
