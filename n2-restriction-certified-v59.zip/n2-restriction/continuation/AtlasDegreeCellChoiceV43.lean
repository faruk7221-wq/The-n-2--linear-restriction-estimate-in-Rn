import continuation.AtlasGeometricCellChoiceV43
import continuation.CellCountNormalizationV43

namespace N2Restriction
open MeasureTheory
open scoped BigOperators ENNReal

/-- A single actual cell has substantial reset mass and all the degree-scaled
near/far energy bounds. The two cell-count comparisons and the partition
degree bound are the outputs required from the external partition. -/
theorem atlas_degree_cell_choice {d k : ℕ} (S : Fin k → SmoothPatch (d+1))
    (T : (i : Fin k) → PacketGraphAtlas (S i)) :
    ∃ B : Fin k → ℝ, (∀ i, 1 ≤ B i) ∧
      ∀ {m q H : ℕ} {C : Type*} [Fintype C] [Nonempty C] {r : ℝ}
        (Q : (i : Fin k) → (j : Fin (T i).size) → CoordinateCapFamily ((T i).patch j).support r)
        (hr : 0 < r) (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure)
        (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure),
      (∀ i, 0 < ‖g i‖) → (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
      ∀ (A : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ))
        (P : Fin m → MvPolynomial (Fin (d+1)) ℝ)
        (Z : Fin q → MvPolynomial (Fin (d+1)) ℝ) (cuts : Set (Ambient (d+1)))
        (V : Submodule ℝ (Ambient (d+1))) {γ K : ℝ}, 0 ≤ K →
      AlgebraicTubeCoverInput {x | polynomialLevelMap Z x = 0}
        (fun z => LinearMap.ker (fderiv ℝ (polynomialLevelMap Z) z).toLinearMap) γ H K →
      ∀ (Ω : Set (Ambient (d+1))) {b w : ℝ}, 0 < b → w < b →
      Ω ⊆ Metric.thickening b (planeWitnessSet Z cuts V (2*γ)) →
      ∀ (far : Finset (Fin k)),
      (∀ i ∈ far, ∀ j a ν, ν ∈ A i j a →
        4*γ < directionPlaneAngle ((T i).cellAxisDirection j a.val) V) →
      ∀ (label : C → (Fin m → Bool)), Function.Injective label →
      ∀ (mass : C → ℝ) {M θ E : ℝ}, 0 < M → 0 < θ → 0 < E →
      θ*M ≤ ∑ c, mass c → (∀ c, mass c ≤ E*M/Fintype.card C) →
      ∀ {D c₀ c₁ s : ℝ}, 1 ≤ D → 0 < c₀ →
      c₀*D^s ≤ Fintype.card C → (Fintype.card C : ℝ) ≤ c₁*D^s →
      ((∏ l, P l).totalDegree : ℝ) ≤ D →
      ∃ c, M ≤ (2*c₁/θ)*D^s*mass c ∧
        ∀ i, ‖(T i).cellInput (Q i) hr (f i)
          (fun j a => {ν | ν ∈ A i j a ∧ label c ∈ trimmedCellLabels P
            ((T i).cellAxisPoint j r ν) ((T i).cellAxisDirection j a.val) Ω b w})‖^2 ≤
          ((2*E*((k : ℝ)+1)/θ)/c₀ * B i * max 2 (max 1 ((H : ℝ)*(K+2)^(d+1)))) *
            D^(1-s-(if i ∈ far then (1 : ℝ) else 0))*‖g i‖^2 := by
  classical
  obtain ⟨B, hB, hb⟩ := atlas_geometric_cell_choice S T
  refine ⟨B, hB, ?_⟩
  intro m q H C _ _ r Q hr g f hg he A P Z cuts V γ K hK hexternal Ω b w hbpos hw hregion far hangle label hinj mass M θ E hM hθ hE htotal hupper D c₀ c₁ s hD hc₀ hcount hcountupper hdeg
  obtain ⟨c, hmass, henergy⟩ := hb Q hr g f hg he A P Z cuts V hK hexternal Ω hbpos hw hregion far hangle label hinj mass hM hθ hE htotal hupper
  have hJ : (0 : ℝ) < Fintype.card C := by exact_mod_cast Fintype.card_pos
  have hDp : 0 < D := zero_lt_one.trans_le hD
  have hm0 : 0 ≤ mass c := (by positivity : 0 ≤ θ*M/(2*Fintype.card C)).trans hmass
  refine ⟨c, ?_, ?_⟩
  · have h1 := (div_le_iff₀ (show (0 : ℝ) < 2*Fintype.card C by positivity)).mp hmass
    have h2 : θ*M ≤ mass c * (2*c₁*D^s) := h1.trans
      (mul_le_mul_of_nonneg_left (by nlinarith [hcountupper]) hm0)
    calc
      M ≤ (mass c*(2*c₁*D^s))/θ := (le_div_iff₀ hθ).2 (by nlinarith [h2])
      _ = _ := by ring
  · intro i
    have hn0 : 0 ≤ (if i ∈ far then max 1 ((H : ℝ)*(K+2)^(d+1))
      else ((∏ l, P l).totalDegree+1 : ℕ)) := by
      split_ifs
      · exact zero_le_one.trans (le_max_left _ _)
      · positivity
    have hn : (if i ∈ far then max 1 ((H : ℝ)*(K+2)^(d+1))
      else ((∏ l, P l).totalDegree+1 : ℕ)) ≤
      max 2 (max 1 ((H : ℝ)*(K+2)^(d+1))) * D^(if decide (i ∈ far) then (0 : ℝ) else 1) := by
      by_cases hi : i ∈ far
      · simp only [hi, decide_true, ↓reduceIte, Real.rpow_zero, mul_one]
        exact le_max_right _ _
      · simp only [hi, decide_false, Bool.false_eq_true, ↓reduceIte, Real.rpow_one, Nat.cast_add, Nat.cast_one]
        have hh : (2 : ℝ) ≤ max 2 (max 1 ((H : ℝ)*(K+2)^(d+1))) := le_max_left _ _
        nlinarith
    have hh := cell_count_energy_normalization (decide (i ∈ far)) hc₀ hDp hcount
      (show 0 ≤ 2*E*((k : ℝ)+1)/θ by positivity)
      (zero_le_one.trans (hB i)) hn0 hn
      (show _ ≤ ((2*E*((k : ℝ)+1)/θ)/(Fintype.card C)) *
        (B i * (if i ∈ far then max 1 ((H : ℝ)*(K+2)^(d+1))
                    else ((∏ l, P l).totalDegree+1 : ℕ)) * ‖g i‖^2) by
        simpa only [div_div] using (henergy i).le)
    simpa only [decide_eq_true_eq] using hh

end N2Restriction
#print axioms N2Restriction.atlas_degree_cell_choice
