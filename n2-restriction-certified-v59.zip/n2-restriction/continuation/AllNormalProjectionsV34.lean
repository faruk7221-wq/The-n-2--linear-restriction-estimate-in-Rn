import continuation.CoordinateDeletionStabilityV34
import continuation.ThinNormalProjectionV33

namespace N2Restriction
open scoped BigOperators

/-- One actual synthesis equivalence simultaneously identifies every normal
kernel. All projection and lifting bounds use the same constant. -/
theorem uniform_thin_normal_all_projections {k : ℕ} (i : Fin k)
    (M c : ℝ) (hM : 0 ≤ M) (hc : 0 < c) :
    ∃ B : ℝ, 0 < B ∧ ∀ (S : Fin k → SmoothPatch (k + 2))
      (z : Fin k → Ambient (k + 2)) (q : Ambient (k + 2) × Ambient (k + 2))
      (N : Submodule ℝ (Ambient (k + 2))) (b : OrthonormalBasis (Fin 3) ℝ N),
      (∀ j, ‖(S j).normal (z j)‖ = 1) → ‖(S i).shape (z i)‖ ≤ M →
      ‖q.1‖ ≤ 1 → ‖q.2‖ ≤ 1 →
      (S i).normal (z i) ∈ N → (S i).shape (z i) q.1 ∈ N →
      (S i).shape (z i) q.2 ∈ N →
      c ≤ Matrix.det (Matrix.gram ℝ (nearbyWedgeVectors S z i q)) →
      ∃ e : (Sum {j : Fin k // j ≠ i} (Fin 3) → ℝ) ≃L[ℝ] Ambient (k + 2),
        (∀ x, e x = ∑ j, x j • Sum.elim
          (fun t : {j : Fin k // j ≠ i} => (S t).normal (z t))
          (fun t => (b t : Ambient (k + 2))) j) ∧
        ‖e.toContinuousLinearMap‖ ≤ B ∧ ‖e.symm.toContinuousLinearMap‖ ≤ B ∧
        LinearMap.ker (normalComplementProjection e).toLinearMap = N ∧
        ‖normalComplementProjection e‖ ≤ B ∧
        (∀ y, ∃ x, normalComplementProjection e x = y ∧ ‖x‖ ≤ B * ‖y‖) ∧
        ∀ j : {j : Fin k // j ≠ i},
          LinearMap.ker (coordinateDeletion e (Sum.inl j)).toLinearMap =
            Submodule.span ℝ {(S j).normal (z j)} ∧
          ‖coordinateDeletion e (Sum.inl j)‖ ≤ B ∧
          ∀ y, ∃ x, coordinateDeletion e (Sum.inl j) x = y ∧ ‖x‖ ≤ B * ‖y‖ := by
  classical
  obtain ⟨B,hB,hcoord⟩ := uniform_thin_normal_synthesis_equiv i M c hM hc
  refine ⟨B,hB,?_⟩
  intro S z q N b hunit hshape hq₁ hq₂ hN hA₁ hA₂ hG
  obtain ⟨e,he,hen,hein⟩ := hcoord S z q N b hunit hshape hq₁ hq₂ hN hA₁ hA₂ hG
  refine ⟨e,he,hen,hein,normalComplementProjection_ker N b _ e he,
    (normalComplementProjection_norm_le e).trans hein, ?_, ?_⟩
  · intro y
    obtain ⟨x,hx,hn⟩ := normalComplementProjection_bounded_preimages e y
    exact ⟨x,hx,hn.trans (mul_le_mul_of_nonneg_right hen (norm_nonneg _))⟩
  · intro j
    refine ⟨coordinateDeletion_ker _ e he (Sum.inl j),
      (coordinateDeletion_norm_le e (Sum.inl j)).trans hein, ?_⟩
    intro y
    obtain ⟨x,hx,hn⟩ := coordinateDeletion_bounded_preimages e (Sum.inl j) y
    exact ⟨x,hx,hn.trans (mul_le_mul_of_nonneg_right hen (norm_nonneg _))⟩

end N2Restriction

#print axioms N2Restriction.uniform_thin_normal_all_projections
