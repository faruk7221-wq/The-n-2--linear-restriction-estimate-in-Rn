import continuation.AtlasZeroInputV43

namespace N2Restriction
open MeasureTheory Set
open scoped BigOperators ENNReal

/-- Empty packet selection gives the zero actual Hausdorff L2 input. -/
theorem PacketGraphAtlas.cellInput_empty_selection {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) {r : ℝ}
    (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r) (hr : 0 < r)
    (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
    (A : (j : Fin T.size) → (Q j).centers → Set (Fin d → ℤ))
    (hA : ¬ ∃ j a ν, ν ∈ A j a) : T.cellInput Q hr f A = 0 := by
  classical
  have he : ∀ j a, A j a = ∅ := by
    intro j a
    apply Set.eq_empty_iff_forall_notMem.mpr
    intro ν hν
    exact hA ⟨j, a, ν, hν⟩
  simp [PacketGraphAtlas.cellInput, he]

/-- Nonzero reset mass forces every selected packet family to be nonempty.
This supplies the nonemptiness premise for the geometric feasible-count bound. -/
theorem atlas_nonzero_mass_nonempty_selection {d k : ℕ}
    (S : Fin k → SmoothPatch (d+1)) (T : (i : Fin k) → PacketGraphAtlas (S i))
    {r : ℝ} (hr : 0 < r)
    (Q : (i : Fin k) → (j : Fin (T i).size) → CoordinateCapFamily ((T i).patch j).support r)
    (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure)
    (A : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ))
    (Ω : Set (Ambient (d+1))) {p : ℝ} (hp : 0 < p)
    (hmass : (∫⁻ x in Ω, ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
      (fun i => (T i).cellInput (Q i) hr (f i) (A i)) x‖ₑ ^ p) ≠ 0) :
    ∀ i, ∃ j a ν, ν ∈ A i j a := by
  classical
  intro i
  by_contra hi
  have hzero := (T i).cellInput_empty_selection (Q i) hr (f i) (A i) hi
  have hprod (x : Ambient (d+1)) :
      extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
        (fun i => (T i).cellInput (Q i) hr (f i) (A i)) x = 0 := by
    apply Finset.prod_eq_zero (Finset.mem_univ i)
    dsimp only
    rw [hzero]
    unfold extension
    calc
      _ = ∫ ξ, (0 : ℂ) ∂(Measure.hausdorffMeasure (d : ℝ) : Measure (Ambient (d+1))) := integral_congr_ae (by
        filter_upwards [Lp.coeFn_zero ℂ 2 (Measure.hausdorffMeasure (d : ℝ) : Measure (Ambient (d+1)))] with ξ hξ
        exact mul_eq_zero_of_right _ hξ)
      _ = 0 := integral_zero _ _
  apply hmass
  simp only [hprod, enorm_zero, ENNReal.zero_rpow_of_pos hp, lintegral_zero]

end N2Restriction
#print axioms N2Restriction.PacketGraphAtlas.cellInput_empty_selection
#print axioms N2Restriction.atlas_nonzero_mass_nonempty_selection
