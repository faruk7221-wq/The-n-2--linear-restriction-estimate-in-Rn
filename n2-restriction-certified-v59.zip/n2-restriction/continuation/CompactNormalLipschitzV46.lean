import Mathlib.Analysis.Calculus.MeanValue
import continuation.AtlasPacketAxesV42

namespace N2Restriction
open Set Metric
open scoped NNReal

/-- Uniform normal control near any compact part of the extended chart,
including atlas buffer points outside the original supported surface. -/
theorem SmoothPatch.normal_lipschitz_near_compact {n : ℕ} (S : SmoothPatch n)
    (K : Set (Ambient n)) (hK : IsCompact K) (hinside : K ⊆ S.neighborhood) :
    ∃ η : ℝ, 0 < η ∧ ∃ M : ℝ≥0, ∀ z ∈ K,
      closedBall z η ⊆ S.neighborhood ∧ LipschitzOnWith M S.normal (closedBall z η) := by
  obtain ⟨η, hη, hsub⟩ := hK.exists_cthickening_subset_open S.open_neighborhood hinside
  have hcompact : IsCompact (cthickening η K) := hK.cthickening
  have hc := (S.smooth_normal.continuousOn_fderiv_of_isOpen S.open_neighborhood (by simp)).mono hsub
  obtain ⟨A, hA⟩ := hcompact.exists_bound_of_continuousOn hc
  let M : ℝ≥0 := ⟨max A 0, le_max_right _ _⟩
  refine ⟨η, hη, M, ?_⟩
  intro z hz
  have hball : closedBall z η ⊆ cthickening η K := by
    intro y hy
    exact mem_cthickening_of_dist_le y z η K hz hy
  refine ⟨hball.trans hsub, ?_⟩
  apply (convex_closedBall z η).lipschitzOnWith_of_nnnorm_fderiv_le (𝕜 := ℝ)
  · intro y hy
    exact ((S.smooth_normal y (hsub (hball hy))).contDiffAt
      (S.open_neighborhood.mem_nhds (hsub (hball hy)))).differentiableAt (by simp)
  · intro y hy
    change ‖fderiv ℝ S.normal y‖ ≤ max A 0
    exact (hA y (hball hy)).trans (le_max_left _ _)

/-- Every actual cap center has a common ambient neighborhood of normal
Lipschitz control, fixed before the cap scale and packet selection. -/
theorem PacketGraphAtlas.normal_lipschitz_at_cap_centers {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) :
    ∃ η : ℝ, 0 < η ∧ ∃ M : ℝ≥0, ∀ j a, a ∈ (T.patch j).support →
      closedBall ((T.patch j).rotation ((T.graph j).parametrization a)) η ⊆ S.neighborhood ∧
      LipschitzOnWith M S.normal
        (closedBall ((T.patch j).rotation ((T.graph j).parametrization a)) η) := by
  let K := ⋃ j, T.buffer j
  have hK : IsCompact K := isCompact_iUnion T.compact_buffer
  have hinside : K ⊆ S.neighborhood := by
    intro x hx
    obtain ⟨j,hj⟩ := mem_iUnion.mp hx
    exact (T.buffer_inside j hj).1.1
  obtain ⟨η,hη,M,hM⟩ := S.normal_lipschitz_near_compact K hK hinside
  refine ⟨η,hη,M,?_⟩
  intro j a ha
  apply hM
  apply mem_iUnion.mpr
  refine ⟨j, ?_⟩
  exact ⟨_, ⟨a, (closedBall_subset_closedBall (T.inner_lt j).le)
    ((T.patch j).support_inside ha), rfl⟩, rfl⟩

end N2Restriction
#print axioms N2Restriction.SmoothPatch.normal_lipschitz_near_compact
#print axioms N2Restriction.PacketGraphAtlas.normal_lipschitz_at_cap_centers
