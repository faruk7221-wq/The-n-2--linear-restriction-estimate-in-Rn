import continuation.ActualNontangentIncidenceV47

namespace N2Restriction
open Set Metric MeasureTheory
open scoped ENNReal

/-- Equation (7.5) for actual selected original packets. The scale-free
constant precedes the radius, cap family, input and nontangent selection. -/
theorem PacketGraphAtlas.actual_nontangent_energy {d : ℕ} {S : SmoothPatch (d+1)}
    (A : PacketGraphAtlas S) :
    ∃ B : ℝ, 0 ≤ B ∧ ∀ {I : Type} [Fintype I] {M : ℕ}
      (Z : Set (Ambient (d+1))) (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1)))
      (K C₀ b ρ θ R w r : ℝ),
      0 ≤ K → 0 ≤ C₀ → 0 < b → 0 < ρ → 0 < θ → 0 ≤ R → w ≤ b →
      UniformAlgebraicTubeCoverInput Z T M K →
      ∀ (Q : (j : Fin A.size) → CoordinateCapFamily (A.patch j).support r) (hr : 0 < r)
      (f : (j : Fin A.size) → Lp ℂ 2 (A.graph j).surfaceMeasure)
      (x : I → Ambient (d+1)),
      (∀ i l, i ≠ l → 2*(θ*ρ) ≤ dist (x i) (x l)) →
      ∀ U : I → (j : Fin A.size) → (Q j).centers → Set (Fin d → ℤ),
      (∀ i j a ν, ν ∈ U i j a →
        ¬ PacketTangentInBall Z (A.originalPacketTube j a r ν R w)
          T (A.cellAxisDirection j a) (x i) ρ b C₀) →
      (∑' i, ENNReal.ofReal (‖A.cellInput Q hr f (U i)‖^2)) ≤
        ENNReal.ofReal B * ENNReal.ofReal (M * ((K*(C₀+1)+2)/θ+1)^(d+1)) *
          ENNReal.ofReal (∑ j, ‖f j‖^2) := by
  obtain ⟨B,hB,hbudget⟩ := A.cell_energy_budget
  refine ⟨B,hB,?_⟩
  intro I inst M Z T K C₀ b ρ θ R w r hK hC₀ hb hρ hθ hR hw hext Q hr f x hsep U hnt
  exact hbudget Q hr f U _
    (A.actual_nontangent_incidence Z T hK hC₀ hb hρ hθ hR hw hext Q x hsep U hnt)

end N2Restriction
#print axioms N2Restriction.PacketGraphAtlas.actual_nontangent_energy
