import continuation.RetainedPacketEnergyV48

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal

/-- A retained packet belongs to exactly one of the two angular classes,
so summing incidence over both classifications costs no extra multiplicity. -/
theorem PacketGraphAtlas.actual_binary_incidence {d L : ℕ} {S : SmoothPatch (d+1)}
    (A : PacketGraphAtlas S) {r : ℝ}
    (Q : (j : Fin A.size) → CoordinateCapFamily (A.patch j).support r)
    (U : (j : Fin A.size) → (Q j).centers → Set (Fin d → ℤ))
    (Z : Set (Ambient (d+1))) (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1)))
    (c : Fin L → Ambient (d+1)) (ρ b C₀ R w : ℝ) (Ω : Set (Ambient (d+1)))
    (j : Fin A.size) (a : (Q j).centers) (ν : Fin d → ℤ) :
    (∑' ls : Fin L × Bool, (if ls.2 then
      A.actualTangentSelection Q U Z T (c ls.1) ρ b C₀ R w Ω j a else
      A.actualNontangentSelection Q U Z T (c ls.1) ρ b C₀ R w Ω j a).indicator
        (fun _ => (1 : ENNReal)) ν) =
    ∑' l, (A.actualRetainedSelection Q U (c l) ρ R w Ω j a).indicator
      (fun _ => (1 : ENNReal)) ν := by
  classical
  simp only [tsum_fintype,Fintype.sum_prod_type,Fintype.sum_bool]
  apply Finset.sum_congr rfl
  intro l _
  by_cases hu : ν ∈ U j a <;>
    by_cases hm : (A.originalPacketTube j a r ν R w ∩ (Ω ∩ ball (c l) ρ)).Nonempty <;>
    by_cases ht : PacketTangentInBall Z (A.originalPacketTube j a r ν R w)
      T (A.cellAxisDirection j a) (c l) ρ b C₀ <;>
    simp [actualTangentSelection,actualNontangentSelection,actualRetainedSelection,hu,hm,ht]

/-- The squared norms of both actual angular classes obey one common
retention energy budget, with constants fixed before scale and stage data. -/
theorem PacketGraphAtlas.actual_binary_retention_energy {d : ℕ} {S : SmoothPatch (d+1)}
    (A : PacketGraphAtlas S) :
    ∃ B K : ℝ, 0 ≤ B ∧ 0 < K ∧ ∀ {L : ℕ} {R ρ θ w r : ℝ},
    0 ≤ R → 0 < ρ → 0 < θ → w ≤ ρ →
    ∀ (Q : (j : Fin A.size) → CoordinateCapFamily (A.patch j).support r) (hr : 0 < r)
      (f : (j : Fin A.size) → Lp ℂ 2 (A.graph j).surfaceMeasure)
      (U : (j : Fin A.size) → (Q j).centers → Set (Fin d → ℤ))
      (Z : Set (Ambient (d+1))) (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1)))
      (c : Fin L → Ambient (d+1)) (b C₀ : ℝ) (Ω : Set (Ambient (d+1))),
    (∀ l t, l ≠ t → 2*(θ*ρ) ≤ dist (c l) (c t)) →
    (∑' ls : Fin L × Bool, ENNReal.ofReal (‖A.cellInput Q hr f
      (if ls.2 then A.actualTangentSelection Q U Z T (c ls.1) ρ b C₀ R w Ω else
        A.actualNontangentSelection Q U Z T (c ls.1) ρ b C₀ R w Ω)‖^2)) ≤
      ENNReal.ofReal B * ENNReal.ofReal ((2*R*K/ρ+2)*(3/θ+1)^(d+1)) *
        ENNReal.ofReal (∑ j, ‖f j‖^2) := by
  obtain ⟨B,hB,hbudget⟩ := A.cell_energy_budget
  obtain ⟨K,hK,hinc⟩ := A.retained_packet_incidence
  refine ⟨B,K,hB,hK,?_⟩
  intro L R ρ θ w r hR hρ hθ hw Q hr f U Z T c b C₀ Ω hsep
  apply hbudget Q hr f (fun ls : Fin L × Bool => if ls.2 then
    A.actualTangentSelection Q U Z T (c ls.1) ρ b C₀ R w Ω else
    A.actualNontangentSelection Q U Z T (c ls.1) ρ b C₀ R w Ω)
  intro j a ν
  have he := A.actual_binary_incidence Q U Z T c ρ b C₀ R w Ω j a ν
  simp only [ite_apply]
  rw [he]
  apply hinc hR hρ hθ hw Q c hsep (fun l => A.actualRetainedSelection Q U (c l) ρ R w Ω)
  intro l j a ν hν
  obtain ⟨x,hxt,hxΩ,hxb⟩ := hν.2
  exact ⟨x,hxt,hxb⟩

end N2Restriction
#print axioms N2Restriction.PacketGraphAtlas.actual_binary_incidence
#print axioms N2Restriction.PacketGraphAtlas.actual_binary_retention_energy
