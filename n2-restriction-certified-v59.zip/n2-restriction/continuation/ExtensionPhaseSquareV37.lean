import continuation.PhaseSeriesSquareV37

namespace N2Restriction
open MeasureTheory Filter
open scoped BigOperators

/-- The exact uncertainty-scale square-function domination for the
extension operator. Every term uses the fixed reference parametrization;
the explicit coefficient exp(n) is independent of R and the input.
The remaining vector-valued restriction estimate is a separate step. -/
theorem extension_frozen_phase_square_bound {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} {n : ℕ} (ζ h : Ω → Ambient n)
    (hζ : Measurable ζ) (hh : Measurable h) (g : Ω → ℂ) (hg : Integrable g μ)
    (x : Ambient n) (R : ℝ) (hR : 0 < R) (hx : ∀ i, |x i| ≤ R)
    (hfreq : ∀ᵐ ω ∂μ, g ω ≠ 0 → ∀ i, |R*h ω i| ≤ 1) :
    ‖extension μ (fun ω => ζ ω+h ω) g x‖^2 ≤
      Real.exp n * ∑' a : Fin n → ℕ, phaseSeriesWeight a *
        ‖extension μ ζ (fun ω => phaseSeriesAmplitude R (h ω) a*g ω) x‖^2 := by
  let z := fun a : Fin n → ℕ => extension μ ζ (fun ω => phaseSeriesAmplitude R (h ω) a*g ω) x
  have hz (a : Fin n → ℕ) : ‖z a‖ ≤ ∫ ω, ‖g ω‖ ∂μ := by
    have hm : Measurable (fun ω => phaseSeriesAmplitude R (h ω) a) := by
      unfold phaseSeriesAmplitude
      fun_prop
    have hb : ∀ᵐ ω ∂μ, ‖phaseSeriesAmplitude R (h ω) a*g ω‖ ≤ ‖g ω‖ := by
      filter_upwards [hfreq] with ω hω
      by_cases h0 : g ω = 0
      · simp [h0]
      · rw [norm_mul]
        exact (mul_le_mul_of_nonneg_right
          (phase_series_amplitude_norm_le (h ω) R (hω h0) a) (norm_nonneg _)).trans_eq (one_mul _)
    have ha : Integrable (fun ω => phaseSeriesAmplitude R (h ω) a*g ω) μ :=
      hg.norm.mono' (hm.aestronglyMeasurable.mul hg.aestronglyMeasurable) hb
    have hk := integrable_extension_kernel hζ ha x
    apply (norm_integral_le_integral_norm _).trans
    apply integral_mono_ae hk.norm hg.norm
    filter_upwards [hb] with ω hω
    simpa only [norm_mul,norm_extension_kernel,one_mul] using hω
  have hw (a : Fin n → ℕ) : 0 ≤ phaseSeriesWeight a := by
    unfold phaseSeriesWeight
    positivity
  have hsum : Summable (fun a : Fin n → ℕ => phaseSeriesWeight a*‖z a‖^2) := by
    apply Summable.of_nonneg_of_le (fun a => mul_nonneg (hw a) (sq_nonneg _))
      (fun a => mul_le_mul_of_nonneg_left (pow_le_pow_left₀ (norm_nonneg _) (hz a) 2) (hw a))
    exact (phaseSeriesWeight_hasSum n).summable.mul_right ((∫ ω, ‖g ω‖ ∂μ)^2)
  exact phase_series_square_bound (phaseSeriesCoefficient R x) z _
    (phase_series_coefficient_norm_le x R hR hx) hsum
    (extension_frozen_phase_series ζ h hζ hh g hg x R hR hx hfreq)

end N2Restriction

#print axioms N2Restriction.extension_frozen_phase_square_bound
