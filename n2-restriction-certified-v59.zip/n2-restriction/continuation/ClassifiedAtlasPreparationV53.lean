import continuation.UniformCutPreparedStageV52
import continuation.ActualPreparedAlternativesV52
import continuation.GroupedStageBudgetV53
namespace N2Restriction
open Set Metric MeasureTheory
open scoped ENNReal
set_option maxHeartbeats 800000

/-- Actual geometric and packet data after same-dimension preparation.
Only the original packet subset changes; the chart inputs and scale stay fixed. -/
structure PreparedAtlasPacketStage {k m : ℕ}
    (S : Fin k → SmoothPatch (k+2)) (T : (i : Fin k) → PacketGraphAtlas (S i))
    {r : ℝ} (Q : (i : Fin k) → (j : Fin (T i).size) → CoordinateCapFamily ((T i).patch j).support r)
    (hr : 0 < r)
    (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure)
    (U₀ : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin (k+1) → ℤ))
    (p R width γ : ℝ) (M₀ err : ENNReal) (B : PolynomialStageBudget) where
  selected : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin (k+1) → ℤ)
  subset : ∀ i j a, selected i j a ⊆ U₀ i j a
  stage : PolynomialStage (fun _ => Measure.hausdorffMeasure ((k+1 : ℕ) : ℝ))
    (fun i => (T i).cellInput (Q i) hr (f i) (selected i)) p R width M₀ err m
  bounded : stage.withinBudget B
  cuts : Set (Ambient (k+2))
  cuts_closed : IsClosed cuts
  plane : Submodule ℝ (Ambient (k+2))
  dimension : Module.finrank ℝ plane = (k+2)-m
  near : Finset (Fin k)
  near_angle : ∀ i ∈ near, ∀ j a ν, ν ∈ selected i j a →
    directionPlaneAngle ((T i).cellAxisDirection j a.val) plane ≤ 4*γ
  far_angle : ∀ i ∈ nearᶜ, ∀ j a ν, ν ∈ selected i j a →
    4*γ < directionPlaneAngle ((T i).cellAxisDirection j a.val) plane
  lifts : ∀ x ∈ stage.region, Nonempty (ShortLiftWitness plane (polynomialLevelMap stage.equations)
    {x | polynomialLevelMap stage.equations x = 0} cuts (stage.multiplier*width) x)
  plane_region : stage.region ⊆ thickening (stage.multiplier*width)
    (planeWitnessSet stage.equations cuts plane (2*γ))

/-- Combine actual cut/away preparation with the reference-rank classification.
All plane/count/degree bounds precede the radius and selected data. -/
theorem uniform_classified_atlas_preparation {k m : ℕ} (hk : 3 ≤ k)
    (hexternal : UniformTangentCutsInput (k+2))
    (P : Fin k → SmoothPatch (k+2)) {ι γ : ℝ} (hι : 0 < ι)
    (hγ : 0 < γ) (hγsmall : 2*γ ≤ (1 : ℝ)/2) (hγι : γ ≤ ι/2)
    (Dsub : (i : Fin k) → DirectionalSubdivision (P i) ι)
    (b : (i : Fin k) → Fin (Dsub i).size)
    (hrank : ∀ (V : Submodule ℝ (Ambient (k+2))) (near : Finset (Fin k)),
      (∀ i ∈ near, directionPlaneAngle ((P i).normal ((Dsub i).anchor (b i))) V ≤ 4*ι) →
      k ≤ Module.finrank ℝ V+nearᶜ.card)
    (B : PolynomialStageBudget) :
    ∃ N D t : ℕ,
    ∀ (T : (i : Fin k) → PacketGraphAtlas ((Dsub i).piece (b i)))
    {r : ℝ} (hr : 0 < r)
    (Q : (i : Fin k) → (j : Fin (T i).size) → CoordinateCapFamily ((T i).patch j).support r)
    (_hsmall : ∀ i, r ≤ (T i).capRadius)
    (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure)
    (U : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin (k+1) → ℤ))
    {p R width : ℝ} {M₀ err : ENNReal} (_hp : 0 < p) (_hp1 : p ≤ 1) (_hpc : critical k < p)
    (W : PolynomialStage (fun _ => Measure.hausdorffMeasure ((k+1 : ℕ) : ℝ))
      (fun i => (T i).cellInput (Q i) hr (f i) (U i)) p R width M₀ err m)
    (_hB : W.withinBudget B) (_hm : m < k+2),
    M₀ ≤ err ∨
    (∃ W' : PolynomialStage (fun _ => Measure.hausdorffMeasure ((k+1 : ℕ) : ℝ))
      (fun i => (T i).cellInput (Q i) hr (f i) (U i)) p R width M₀ err (m+1),
      W'.region ⊆ W.region ∧ W'.withinBudget (B.advance D 100 (by norm_num)
        ((N : ENNReal)/(2 : ENNReal)⁻¹) (ENNReal.div_ne_top (by simp) (by norm_num)))) ∨
    (∃ A : PreparedAtlasPacketStage (m := m) (fun i => (Dsub i).piece (b i)) T Q hr f U
      p R width γ M₀ err (B.prepared t k),
      A.stage.region ⊆ W.region ∧
      (((k+2)-m ≤ k ∧ (k+2)-m+A.nearᶜ.card = k) ∨
       k+1 ≤ (k+2)-m+A.nearᶜ.card)) := by
  classical
  obtain ⟨N,D,t,hd,hprep⟩ := uniform_cut_or_prepared_atlas_stage (d := k+1) (k := k) (m := m)
    hexternal B hγ hγsmall
  refine ⟨N,D,t.card,?_⟩
  intro T r hr Q hsmall f U p R width M₀ err hp hp1 hpc W hB hm
  obtain ⟨C,hcases⟩ := hprep (fun i => (Dsub i).piece (b i)) T hr Q hsmall f U hp hp1 W hB hm
  rcases hcases with hz|hc|ha
  · exact Or.inl hz
  · obtain ⟨i,W',_,_,_,hsub,hbudget⟩ := hc
    exact Or.inr (Or.inl ⟨W',hsub,hbudget⟩)
  obtain ⟨ell,σ,U',hU,hnear,hfar,W',_,_,_,hsub,hplane,hw,hbudget⟩ := ha
  let near : Finset (Fin k) := Finset.univ.filter (fun i => σ i = true)
  have hn : ∀ i ∈ near, ∀ j a ν, ν ∈ U' i j a →
      directionPlaneAngle ((T i).cellAxisDirection j a.val) ell.val ≤ 4*γ := by
    intro i hi
    exact hnear i (Finset.mem_filter.mp hi).2
  have hf : ∀ i ∈ nearᶜ, ∀ j a ν, ν ∈ U' i j a →
      4*γ < directionPlaneAngle ((T i).cellAxisDirection j a.val) ell.val := by
    intro i hi
    have hi' : i ∉ near := Finset.mem_compl.mp hi
    have hnot : σ i ≠ true := fun he => hi' (Finset.mem_filter.mpr ⟨Finset.mem_univ i,he⟩)
    exact hfar i (Bool.eq_false_of_not_eq_true hnot)
  have hclosed : IsClosed (⋃ i, {x | polynomialLevelMap (C.equations i) x = 0}) :=
    isClosed_iUnion_of_finite (fun i => polynomialLevelMap_isClosed_zero (C.equations i))
  let A : PreparedAtlasPacketStage (m := m) (fun i => (Dsub i).piece (b i)) T Q hr f U
      p R width γ M₀ err (B.prepared t.card k) :=
    ⟨U',hU,W',hbudget,_,hclosed,ell.val,hd ell.val ell.property,near,hn,hf,hw,hplane⟩
  rcases actual_prepared_stage_alternatives hk P hι hγι Dsub b T hrank hr Q f U' hp hpc W'
    ell.val (hd ell.val ell.property) near hn with hz|⟨_,hzero|ht|hgap⟩
  · exact Or.inl hz
  · omega
  · exact Or.inr (Or.inr ⟨A,hsub,Or.inl ⟨ht.2.1,ht.2.2⟩⟩)
  · exact Or.inr (Or.inr ⟨A,hsub,Or.inr hgap.1⟩)

end N2Restriction
#print axioms N2Restriction.uniform_classified_atlas_preparation
