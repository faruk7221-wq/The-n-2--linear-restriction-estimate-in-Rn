import continuation.MarginLpMassAdapterV51
namespace N2Restriction
open MeasureTheory
open scoped ENNReal BigOperators
section
variable {n k : ℕ} {Ω : Fin k → Type*} [∀ i, MeasurableSpace (Ω i)]
variable (μ : ∀ i, Measure (Ω i)) [∀ i, IsFiniteMeasure (μ i)]
variable (ζ : ∀ i, Ω i → Ambient n) (U : Fin k → Set (Ambient n)) (margin : ℝ)

/-- Finite coefficient produced by the actual descent, with independent
leaf coefficient and dimension-zero child radius multiplier. -/
noncomputable def descentMassCoefficient (p τ σ lam R : ℝ) (K : ENNReal) : ENNReal :=
  ENNReal.ofReal (1/4)*(marginLocalConstant μ ζ U margin p (R/2))^p +
  K*((marginLocalConstant μ ζ U margin p (R^(1-τ)))^p+
    (marginLocalConstant μ ζ U margin p (lam*R^(1/2+τ)))^p+(ENNReal.ofReal (R^σ))^p+1)

theorem descentMassCoefficient_ne_top {p : ℝ} (hp : 0 < p)
    (τ σ lam R : ℝ) (K : ENNReal) (hK : K ≠ ∞) :
    descentMassCoefficient μ ζ U margin p τ σ lam R K ≠ ∞ := by
  have hf (r : ℝ) : (marginLocalConstant μ ζ U margin p r)^p ≠ ∞ :=
    ENNReal.rpow_ne_top_of_nonneg hp.le (marginLocalConstant_ne_top μ ζ U margin hp)
  exact ENNReal.add_ne_top.mpr ⟨ENNReal.mul_ne_top (by simp) (hf _),ENNReal.mul_ne_top hK
    (ENNReal.add_ne_top.mpr ⟨ENNReal.add_ne_top.mpr ⟨ENNReal.add_ne_top.mpr ⟨hf _,hf _⟩,
      ENNReal.rpow_ne_top_of_nonneg hp.le (by simp)⟩,by simp⟩)⟩

/-- Exact conversion of the assembled ENNReal mass coefficient to its
real scalar recurrence, without comparing two margin classes at different radii. -/
theorem descentMassCoefficient_toReal {p : ℝ} (hp : 0 < p)
    (τ σ lam R : ℝ) (hR : 0 ≤ R) (K : ENNReal) (hK : K ≠ ∞) :
    (descentMassCoefficient μ ζ U margin p τ σ lam R K).toReal =
      1/4*marginPowerConstant μ ζ U margin p (R/2)+
      K.toReal*(marginPowerConstant μ ζ U margin p (R^(1-τ))+
        marginPowerConstant μ ζ U margin p (lam*R^(1/2+τ))+R^(σ*p)+1) := by
  have hf (r : ℝ) : (marginLocalConstant μ ζ U margin p r)^p ≠ ∞ :=
    ENNReal.rpow_ne_top_of_nonneg hp.le (marginLocalConstant_ne_top μ ζ U margin hp)
  have herr : (ENNReal.ofReal (R^σ))^p ≠ ∞ := ENNReal.rpow_ne_top_of_nonneg hp.le (by simp)
  have hsum : (marginLocalConstant μ ζ U margin p (R^(1-τ)))^p+
    (marginLocalConstant μ ζ U margin p (lam*R^(1/2+τ)))^p+(ENNReal.ofReal (R^σ))^p+1 ≠ ∞ :=
    ENNReal.add_ne_top.mpr ⟨ENNReal.add_ne_top.mpr ⟨ENNReal.add_ne_top.mpr ⟨hf _,hf _⟩,herr⟩,by simp⟩
  unfold descentMassCoefficient
  rw [ENNReal.toReal_add (ENNReal.mul_ne_top (by simp) (hf _)) (ENNReal.mul_ne_top hK hsum),
    ENNReal.toReal_mul,ENNReal.toReal_mul,
    ENNReal.toReal_add (ENNReal.add_ne_top.mpr ⟨ENNReal.add_ne_top.mpr ⟨hf _,hf _⟩,herr⟩) (by simp),
    ENNReal.toReal_add (ENNReal.add_ne_top.mpr ⟨hf _,hf _⟩) herr,
    ENNReal.toReal_add (hf _) (hf _)]
  simp only [← ENNReal.toReal_rpow,ENNReal.toReal_ofReal (by norm_num : (0 : ℝ) ≤ 1/4),
    ENNReal.toReal_ofReal (Real.rpow_nonneg hR σ),ENNReal.toReal_one,←Real.rpow_mul hR,marginPowerConstant]

/-- Original L2 mass estimates imply the actual scalar inequality for all
centers and all MemLp representatives through the proved modulation adapter. -/
theorem margin_power_of_descent_Lp_mass (hζ : ∀ i, Measurable (ζ i))
    {p τ σ lam R : ℝ} (hp : 0 < p) (hR : 0 ≤ R) (K : ENNReal) (hK : K ≠ ∞)
    (h : ∀ g : (i : Fin k) → Lp ℂ 2 (μ i),
      MarginAdmissible μ ζ U margin R (fun i => g i) →
      (∫⁻ x in Metric.ball 0 R, ‖extensionProduct μ ζ (fun i => g i) x‖ₑ^p) ≤
        descentMassCoefficient μ ζ U margin p τ σ lam R K*(∏ i, ENNReal.ofReal ‖g i‖)^p) :
    marginPowerConstant μ ζ U margin p R ≤
      1/4*marginPowerConstant μ ζ U margin p (R/2)+
      K.toReal*(marginPowerConstant μ ζ U margin p (R^(1-τ))+
        marginPowerConstant μ ζ U margin p (lam*R^(1/2+τ))+R^(σ*p)+1) := by
  have hh := marginPowerConstant_le_of_Lp_origin_mass_bound μ ζ hζ U margin hp _
    (descentMassCoefficient_ne_top μ ζ U margin hp τ σ lam R K hK) h
  rwa [descentMassCoefficient_toReal μ ζ U margin hp τ σ lam R hR K hK] at hh
end
end N2Restriction
#print axioms N2Restriction.descentMassCoefficient_ne_top
#print axioms N2Restriction.descentMassCoefficient_toReal
#print axioms N2Restriction.margin_power_of_descent_Lp_mass
