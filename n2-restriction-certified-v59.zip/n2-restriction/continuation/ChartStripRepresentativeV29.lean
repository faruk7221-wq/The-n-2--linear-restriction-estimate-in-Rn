import continuation.CompactFrameStripV29
import continuation.BundledSurfaceEnergyV28

namespace N2Restriction
open MeasureTheory Set Metric
open scoped NNReal ENNReal

/-- An actual chart L2 input in an essential normal strip has a measurable
representative supported everywhere in that physical strip and chart. -/
theorem MeasuredTubularChart.strip_representative {n : ℕ} {S : SmoothPatch n}
    {Q : Ambient n →L[ℝ] ℝ × ℝ} {z : Ambient n} {δ r ρ s : ℝ}
    {B : ℕ → ℝ} {c C : ℝ≥0} {L ε : ℝ}
    (F : MeasuredTubularChart S Q z δ r ρ s B c C L) (hρ : ρ ≤ r)
    (g : Lp ℂ 2 ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier))
    (hg : HasFrequencySupport ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier)
      id {y | ‖Q (S.normal y)‖ ≤ ε} g) :
    ∃ f : Ambient n → ℂ, Measurable f ∧
      f =ᵐ[(Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier] g ∧
      (∀ y, f y ≠ 0 → y ∈ F.carrier ∧ ‖Q (S.normal y)‖ ≤ ε) := by
  apply measurable_supported_representative _ (F.compact_frame_strip hρ ε).measurableSet
    g (Lp.stronglyMeasurable g).measurable
  have hc := ae_restrict_mem (μ := Measure.hausdorffMeasure ((n : ℝ) - 1))
    (F.compact_carrier hρ).measurableSet
  filter_upwards [hc, hg] with y hy hs hne
  exact ⟨hy, hs hne⟩

/-- Physical orthogonal-projection strip support supplies the frame-coordinate
representative required for normal slicing. The two norms need not be equal. -/
theorem MeasuredTubularChart.projected_strip_representative {n : ℕ} {S : SmoothPatch n}
    {q : Ambient n × Ambient n} {z : Ambient n} {δ r ρ s : ℝ}
    {B : ℕ → ℝ} {c C : ℝ≥0} {L ε : ℝ}
    (F : MeasuredTubularChart S (pairFrameMap q) z δ r ρ s B c C L)
    (hρ : ρ ≤ r) (hq : q ∈ orthonormalPairSet n)
    (g : Lp ℂ 2 ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier))
    (hg : HasFrequencySupport ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier)
      id {y | ‖(pairPlane q).orthogonalProjection (S.normal y)‖ ≤ ε} g) :
    ∃ f : Ambient n → ℂ, Measurable f ∧
      f =ᵐ[(Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier] g ∧
      (∀ y, f y ≠ 0 → y ∈ F.carrier ∧ ‖pairFrameMap q (S.normal y)‖ ≤ ε) := by
  apply F.strip_representative hρ g
  exact hg.mono (fun y hy => projected_strip_frame_bound S hq hy)

end N2Restriction

#print axioms N2Restriction.MeasuredTubularChart.projected_strip_representative
#print axioms N2Restriction.MeasuredTubularChart.strip_representative
