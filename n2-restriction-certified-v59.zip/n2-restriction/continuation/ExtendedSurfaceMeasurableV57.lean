import continuation.ExtendedTestMassV56
namespace N2Restriction
open Set MeasureTheory
set_option maxHeartbeats 600000

/-- The full regular extended surface is Borel, although the defining
function is only assumed smooth on its specified open neighborhood. -/
theorem SmoothPatch.measurableSet_extendedSurface {n : ℕ} (S : SmoothPatch n) :
    MeasurableSet S.extendedSurface := by
  classical
  let f : Ambient n → ℝ := S.neighborhood.piecewise S.defining (fun _ => 1)
  have hf : Measurable f := S.smooth_defining.continuousOn.measurable_piecewise
    continuous_const.continuousOn S.open_neighborhood.measurableSet
  have he : S.extendedSurface = f ⁻¹' {0} := by
    ext x
    by_cases hx : x ∈ S.neighborhood <;> simp [SmoothPatch.extendedSurface,f,hx]
  rw [he]
  exact hf (measurableSet_singleton 0)

/-- Multiplying by a smooth partition weight preserves the actual full
surface integrability of a compact ambient test density. -/
theorem SmoothPatch.integrable_weighted_extended_test {n : ℕ} (hn : 1 ≤ n) (S : SmoothPatch n)
    (ψ : Ambient n → ℂ) (hψ : Continuous ψ) (hs : HasCompactSupport ψ)
    (hinside : tsupport ψ ⊆ S.neighborhood) (β : Ambient n → ℝ) (hβ : Continuous β) :
    Integrable (fun z => ψ z*(β z : ℂ))
      ((Measure.hausdorffMeasure ((n : ℝ)-1)).restrict S.extendedSurface) := by
  apply S.integrable_extended_test hn _
    (hψ.mul (Complex.continuous_ofReal.comp hβ))
  · exact hs.mul_right
  · exact tsupport_mul_subset_left.trans hinside
end N2Restriction
#print axioms N2Restriction.SmoothPatch.measurableSet_extendedSurface
#print axioms N2Restriction.SmoothPatch.integrable_weighted_extended_test
