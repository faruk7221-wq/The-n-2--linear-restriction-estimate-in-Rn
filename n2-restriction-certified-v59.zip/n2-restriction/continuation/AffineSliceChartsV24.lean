import continuation.BoundedSliceJacobianV24

set_option maxHeartbeats 800000
set_option synthInstance.maxHeartbeats 100000

namespace N2Restriction
open Metric Filter

/-- A controlled augmented chart has an actual physical affine-slice parametrization
whose derivative obeys uniform upper and lower bounds everywhere on the
closed coordinate ball. All constants are inherited from the original atlas. -/
theorem SubmersionChartModel.Controls.physical_affine_slice_bounds
    {P F : Type*} {n d : ℕ}
    [NormedAddCommGroup P] [NormedSpace ℝ P] [FiniteDimensional ℝ P]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    {c : SubmersionChartModel (P × Ambient n) (P × F)} {f : P × Ambient n → F}
    {U : Set (P × Ambient n)} {x : P × Ambient n} {r : ℝ} {B : ℕ → ℝ}
    (h : c.Controls (fun q => (q.1, f q)) U x r B) (hU : IsOpen U)
    (hB : 0 ≤ B 1)
    (g : Ambient d →L[ℝ] (P × F) × c.free)
    (hg : ∀ v, (g v).1.1 = 0) (hgn : ‖g‖ ≤ 1)
    {L : ℝ} (hL : 1 ≤ L) (hgl : ∀ v, ‖v‖ ≤ L * ‖g v‖) :
    ∃ φ : Ambient d → Ambient n,
      φ 0 = x.2 ∧ Set.InjOn φ (closedBall 0 r) ∧
      (∀ t ∈ closedBall 0 r, (x.1, φ t) ∈ U ∧ f (x.1, φ t) = f x + (g t).1.2 ∧
        ContDiffAt ℝ (⊤ : ℕ∞) φ t ∧
        ‖fderiv ℝ φ t‖ ≤ B 1 * L ∧ ∀ v, ‖v‖ ≤ (B 1 * L) * ‖fderiv ℝ φ t v‖) ∧
      (∀ m t, t ∈ closedBall 0 r → ‖iteratedFDeriv ℝ m φ t‖ ≤ B m) ∧
      ∀ t, φ t = (c.chart.symm (c.chart x + g t)).2 := by
  let a := c.chart x
  let ψ := fun t => c.chart.symm (a + g t)
  let φ := fun t => (ψ t).2
  have hctrl := h
  obtain ⟨_, _, hx, _, he, _, ht, hinto, hs, hderiv, _⟩ := h
  have hball : ∀ t ∈ closedBall 0 r, a + g t ∈ closedBall a r := by
    intro t ht'
    have hb := g.le_of_opNorm_le hgn t
    simpa [mem_closedBall, dist_eq_norm] using hb.trans (by simpa using ht')
  have hlev : ∀ t ∈ closedBall 0 r, (ψ t).1 = x.1 ∧ f (ψ t) = f x + (g t).1.2 := by
    intro t ht'
    have hp := congrArg Prod.fst (c.chart.right_inv (ht (hball t ht')))
    rw [he] at hp
    have ha : (a + g t).1 = (x.1, f x + (g t).1.2) := by
      have hax := he x
      change a.1 = (x.1, f x) at hax
      rw [Prod.fst_add, hax]
      apply Prod.ext
      · change x.1 + (g t).1.1 = x.1
        rw [hg, add_zero]
      · rfl
    rw [ha] at hp
    exact ⟨congrArg (fun w : P × F => w.1) hp, congrArg (fun w : P × F => w.2) hp⟩
  have hp : ∀ t ∈ closedBall 0 r, (x.1, φ t) = ψ t :=
    fun t ht' => Prod.ext (hlev t ht').1.symm rfl
  refine ⟨φ, by simp [φ, ψ, a, c.chart.left_inv hx], ?_, ?_, ?_, fun _ => rfl⟩
  · intro s hs' t ht' heq
    have hψ : ψ s = ψ t := by rw [← hp s hs', ← hp t ht', heq]
    have hh := congrArg c.chart hψ
    change c.chart (c.chart.symm (a + g s)) = c.chart (c.chart.symm (a + g t)) at hh
    rw [c.chart.right_inv (ht (hball s hs')), c.chart.right_inv (ht (hball t ht'))] at hh
    have heq : g (s - t) = 0 := by rw [map_sub, add_left_cancel hh, sub_self]
    have hb := hgl (s - t)
    rw [heq, norm_zero, mul_zero] at hb
    exact sub_eq_zero.mp (norm_eq_zero.mp (le_antisymm hb (norm_nonneg _)))
  · intro t ht'
    have hc := hs _ (hball t ht')
    have hsm : ContDiffAt ℝ (⊤ : ℕ∞) ψ t :=
      hc.comp t (contDiffAt_const.add g.contDiff.contDiffAt)
    have hd : fderiv ℝ φ t = ((ContinuousLinearMap.snd ℝ P (Ambient n)).comp
        (fderiv ℝ (c.chart.symm : (P × F) × c.free → P × Ambient n) (a + g t))).comp
          g := by
      have hder := hc.differentiableAt (by simp)
      have ha := (hasFDerivAt_const (𝕜 := ℝ) a t).add g.hasFDerivAt
      simpa only [zero_add] using (hder.hasFDerivAt.comp t ha).snd.fderiv
    obtain ⟨hup, hlo⟩ := hctrl.bounded_physical_slice_derivative hU hB (hball t ht') g hg
      (zero_le_one.trans hL) (hgn.trans hL) hgl
    refine ⟨?_, ?_, hsm.snd, ?_, ?_⟩
    · rw [hp t ht']; exact hinto (hball t ht')
    · rw [hp t ht']; exact (hlev t ht').2
    · rw [hd]; exact hup
    · rw [hd]; exact hlo
  · intro m t ht
    have hsm := (hs _ (hball t ht)).comp t (contDiffAt_const.add g.contDiff.contDiffAt)
    have hp := norm_iteratedFDeriv_contraction_comp (ContinuousLinearMap.snd ℝ P (Ambient n))
      (ContinuousLinearMap.norm_snd_le ..) m hsm
    have ha := norm_iteratedFDeriv_affine_slice g
      hgn a m (hs _ (hball t ht))
    exact hp.trans (ha.trans (hderiv m _ (hball t ht)))

end N2Restriction

#print axioms N2Restriction.SubmersionChartModel.Controls.physical_affine_slice_bounds
