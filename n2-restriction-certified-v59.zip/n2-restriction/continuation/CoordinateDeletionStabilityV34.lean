import continuation.CoordinateDeletionV34

namespace N2Restriction

theorem coordinateDeletion_difference_norm_le {ι : Type*} [Fintype ι] [DecidableEq ι] {n : ℕ}
    (e f : (ι → ℝ) ≃L[ℝ] Ambient n) (i : ι) :
    ‖coordinateDeletion e i - coordinateDeletion f i‖ ≤
      ‖e.symm.toContinuousLinearMap - f.symm.toContinuousLinearMap‖ := by
  apply ContinuousLinearMap.opNorm_le_bound _ (norm_nonneg _)
  intro x
  apply (pi_norm_le_iff_of_nonneg (mul_nonneg (norm_nonneg _) (norm_nonneg _))).mpr
  intro j
  exact (norm_le_pi_norm ((e.symm.toContinuousLinearMap - f.symm.toContinuousLinearMap) x) j.val).trans
    ((e.symm.toContinuousLinearMap - f.symm.toContinuousLinearMap).le_opNorm x)

theorem coordinateDeletion_frame_stability {ι : Type*} [Fintype ι] [DecidableEq ι] {n : ℕ}
    (u v : ι → Ambient n) (e f : (ι → ℝ) ≃L[ℝ] Ambient n)
    (he : ∀ x, e x = ∑ i, x i • u i) (hf : ∀ x, f x = ∑ i, x i • v i)
    (B : ℝ) (hB : 0 ≤ B) (hei : ‖e.symm.toContinuousLinearMap‖ ≤ B)
    (hfi : ‖f.symm.toContinuousLinearMap‖ ≤ B) (i : ι) :
    ‖coordinateDeletion e i - coordinateDeletion f i‖ ≤
      B ^ 2 * (Fintype.card ι : ℝ) * ‖u-v‖ := by
  refine (coordinateDeletion_difference_norm_le e f i).trans
    ((coordinate_inverse_difference_norm_le e f B hB hei hfi).trans ?_)
  simpa only [mul_assoc] using mul_le_mul_of_nonneg_left
    (frame_synthesis_difference_norm_le u v e f he hf) (sq_nonneg B)

end N2Restriction

#print axioms N2Restriction.coordinateDeletion_difference_norm_le
#print axioms N2Restriction.coordinateDeletion_frame_stability
