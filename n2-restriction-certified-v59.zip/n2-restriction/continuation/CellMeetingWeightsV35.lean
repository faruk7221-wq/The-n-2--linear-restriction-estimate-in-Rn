import continuation.ProjectionDensityV32

namespace N2Restriction
open Set
open scoped ENNReal BigOperators

/-- Retain the original weight exactly when a tube meets the region. -/
noncomputable def cellMeetingWeight {X T : Type*} (U : T → Set X)
    (u : T → ℝ≥0∞) (S : Set X) (t : T) : ℝ≥0∞ := by
  classical
  exact if (S ∩ U t).Nonempty then u t else 0

/-- Localization never increases an individual weight. -/
theorem cellMeetingWeight_le {X T : Type*} (U : T → Set X)
    (u : T → ℝ≥0∞) (S : Set X) (t : T) : cellMeetingWeight U u S t ≤ u t := by
  classical
  unfold cellMeetingWeight
  split_ifs <;> simp

/-- Local total weights are bounded by the original total weight. -/
theorem cellMeetingWeight_tsum_le {X T : Type*} (U : T → Set X)
    (u : T → ℝ≥0∞) (S : Set X) :
    (∑' t, cellMeetingWeight U u S t) ≤ ∑' t, u t :=
  ENNReal.tsum_le_tsum (cellMeetingWeight_le U u S)

/-- Keeping only tubes that meet the region preserves density throughout it. -/
theorem cellMeetingWeight_density_eq {X T : Type*} (U : T → Set X)
    (u : T → ℝ≥0∞) (S : Set X) {x : X} (hx : x ∈ S) :
    tubeDensity U (cellMeetingWeight U u S) x = tubeDensity U u x := by
  classical
  unfold tubeDensity
  apply tsum_congr
  intro t
  by_cases ht : x ∈ U t
  · simp [ht, cellMeetingWeight, show (S ∩ U t).Nonempty from ⟨x, hx, ht⟩]
  · simp [ht]

/-- A whole cell covered by the enlarged versions of all meeting tubes has
reference density at least their local total weight. -/
theorem cellMeetingWeight_le_density {X Y T : Type*}
    (U : T → Set X) (V : T → Set Y) (u : T → ℝ≥0∞) (S : Set X)
    {y : Y} (hcover : ∀ t, (S ∩ U t).Nonempty → y ∈ V t) :
    (∑' t, cellMeetingWeight U u S t) ≤ tubeDensity V u y := by
  classical
  apply ENNReal.tsum_le_tsum
  intro t
  by_cases ht : (S ∩ U t).Nonempty
  · simp [cellMeetingWeight, ht, Set.indicator_of_mem (hcover t ht)]
  · simp [cellMeetingWeight, ht]

end N2Restriction

#print axioms N2Restriction.cellMeetingWeight_density_eq
#print axioms N2Restriction.cellMeetingWeight_le
#print axioms N2Restriction.cellMeetingWeight_le_density
#print axioms N2Restriction.cellMeetingWeight_tsum_le
