import continuation.IntervalSamplingV48

namespace N2Restriction
open Set Metric

/-- Separated ball centers within two radii of a finite curve of bounded
speed have multiplicity linear in curve length over radius, not a dimensional
power of that ratio. This is the counting scale needed in (7.15). -/
theorem separated_centers_near_curve_card {n : ℕ} {I : Type*} [Fintype I]
    (c : I → Ambient n) (γ : ℝ → Ambient n) {R ρ θ K : ℝ}
    (hR : 0 ≤ R) (hρ : 0 < ρ) (hθ : 0 < θ) (hK : 0 < K)
    (hγ : ∀ s t, dist (γ s) (γ t) ≤ K*|s-t|)
    (hsep : ∀ i j, i ≠ j → 2*(θ*ρ) ≤ dist (c i) (c j))
    (hnear : ∀ i, ∃ t ∈ Icc (-R) R, dist (c i) (γ t) ≤ 2*ρ) :
    (Fintype.card I : ℝ) ≤ (2*R*K/ρ+2)*(3/θ+1)^n := by
  obtain ⟨M,s,hM,hs⟩ := exists_interval_sampling hR (div_pos hρ hK)
  have hcover : ∀ i, ∃ j, dist (c i) (γ (s j)) ≤ (3/θ)*(θ*ρ) := by
    intro i
    obtain ⟨t,ht,hct⟩ := hnear i
    obtain ⟨j,hj⟩ := hs t ht
    refine ⟨j,?_⟩
    have hdist := (hγ t (s j)).trans (mul_le_mul_of_nonneg_left hj hK.le)
    have he : K*(ρ/K) = ρ := by field_simp
    rw [he] at hdist
    have he' : (3/θ)*(θ*ρ) = 3*ρ := by field_simp
    rw [he']
    exact (dist_triangle _ _ _).trans (by linarith)
  have hh := separated_representatives_card_bound c (fun j => γ (s j))
    (mul_pos hθ hρ) (by positivity : 0 ≤ 3/θ) hsep hcover
  have he : 2*R/(ρ/K) = 2*R*K/ρ := by field_simp
  rw [he] at hM
  exact hh.trans (mul_le_mul_of_nonneg_right hM (by positivity))

end N2Restriction
#print axioms N2Restriction.separated_centers_near_curve_card
