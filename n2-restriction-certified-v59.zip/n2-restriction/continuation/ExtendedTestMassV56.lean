import continuation.ExtendedTestIntegralV56
import N2Restriction.SurfaceMeasure
namespace N2Restriction
open Set MeasureTheory
set_option maxHeartbeats 800000

/-- The complete test-supported part of the extended surface has finite
Hausdorff measure, even when it is outside the original compact support. -/
theorem SmoothPatch.finite_extended_test_mass {n : ℕ} (hn : 1 ≤ n) (S : SmoothPatch n)
    (ψ : Ambient n → ℂ) (hψ : HasCompactSupport ψ)
    (hinside : tsupport ψ ⊆ S.neighborhood) :
    Measure.hausdorffMeasure ((n : ℝ)-1) (tsupport ψ ∩ S.extendedSurface) < ⊤ := by
  obtain ⟨P,hP,-,-,-⟩ := S.exists_extended_test_patch ψ hψ hinside
  simpa only [hP] using P.finite_surface_mass hn

/-- A continuous compact test density is genuinely integrable on the full
extended surface, without global finiteness of that surface measure. -/
theorem SmoothPatch.integrable_extended_test {n : ℕ} (hn : 1 ≤ n) (S : SmoothPatch n)
    (ψ : Ambient n → ℂ) (hcont : Continuous ψ) (hψ : HasCompactSupport ψ)
    (hinside : tsupport ψ ⊆ S.neighborhood) :
    Integrable ψ ((Measure.hausdorffMeasure ((n : ℝ)-1)).restrict S.extendedSurface) := by
  let μ := (Measure.hausdorffMeasure ((n : ℝ)-1)).restrict S.extendedSurface
  have hs : MeasurableSet (tsupport ψ) := (isClosed_tsupport ψ).measurableSet
  have hm : μ (tsupport ψ) ≠ ⊤ := by
    rw [Measure.restrict_apply hs]
    exact (S.finite_extended_test_mass hn ψ hψ hinside).ne
  obtain ⟨M,hM⟩ := hψ.bddAbove_image hcont.norm.continuousOn
  have hb : ∀ᵐ y ∂(μ.restrict (tsupport ψ)), ‖ψ y‖ ≤ M := by
    filter_upwards [ae_restrict_mem hs] with y hy
    exact hM (mem_image_of_mem _ hy)
  have hi : IntegrableOn ψ (tsupport ψ) μ :=
    Measure.integrableOn_of_bounded hm hcont.aestronglyMeasurable hb
  have h := (integrable_indicator_iff hs).2 hi
  have he : (tsupport ψ).indicator ψ = ψ := by
    funext y
    by_cases hy : y ∈ tsupport ψ
    · exact indicator_of_mem hy ψ
    · rw [indicator_of_notMem hy,image_eq_zero_of_notMem_tsupport hy]
  rwa [he] at h
end N2Restriction
#print axioms N2Restriction.SmoothPatch.finite_extended_test_mass
#print axioms N2Restriction.SmoothPatch.integrable_extended_test
