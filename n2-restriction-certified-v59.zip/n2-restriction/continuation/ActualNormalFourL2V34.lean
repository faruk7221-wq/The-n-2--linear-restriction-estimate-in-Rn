import continuation.ThinNormalFourCoordinatesV34
import continuation.UniformFourL2V34

set_option maxHeartbeats 800000
namespace N2Restriction
open MeasureTheory
open scoped ENNReal
attribute [local instance] tripleProductHaar fourProductHaar

/-- The concrete product kernels agree with the selected normal space and
all three remaining normal lines. The scalar ordering is explicitly retained. -/
def FourNormalKernels (S : Fin 4 → SmoothPatch 6) (z : Fin 4 → Ambient 6)
    (i : Fin 4) (N : Submodule ℝ (Ambient 6))
    (C : Ambient 6 ≃L[ℝ] ((Ambient 1 × Ambient 1) × Ambient 3) × Ambient 1) : Prop :=
  LinearMap.ker (fourProjectionOne C).toLinearMap = N ∧
  ∃ r : Fin 3 ≃ {j : Fin 4 // j ≠ i},
    LinearMap.ker (fourProjectionZero C).toLinearMap = Submodule.span ℝ {(S (r 2)).normal (z (r 2))} ∧
    LinearMap.ker (fourProjectionTwo C).toLinearMap = Submodule.span ℝ {(S (r 0)).normal (z (r 0))} ∧
    LinearMap.ker (fourProjectionThree C).toLinearMap = Submodule.span ℝ {(S (r 1)).normal (z (r 1))}

/-- The flat four-block L2 estimate instantiated on the article's actual
normal configuration, with its constant before the geometric data and inputs. -/
theorem uniform_actual_normal_four_L2 (i : Fin 4)
    (M c : ℝ) (hM : 0 ≤ M) (hc : 0 < c) :
    ∃ K : ℝ≥0∞, 0 < K ∧ K ≠ ⊤ ∧ ∀ (S : Fin 4 → SmoothPatch (6))
      (z : Fin 4 → Ambient (6)) (q : Ambient (6) × Ambient (6))
      (N : Submodule ℝ (Ambient (6))) (_b : OrthonormalBasis (Fin 3) ℝ N),
      (∀ j, ‖(S j).normal (z j)‖ = 1) → ‖(S i).shape (z i)‖ ≤ M →
      ‖q.1‖ ≤ 1 → ‖q.2‖ ≤ 1 →
      (S i).normal (z i) ∈ N → (S i).shape (z i) q.1 ∈ N →
      (S i).shape (z i) q.2 ∈ N →
      c ≤ Matrix.det (Matrix.gram ℝ (nearbyWedgeVectors S z i q)) →
      ∃ e : Ambient 6 ≃L[ℝ] ((Ambient 1 × Ambient 1) × Ambient 3) × Ambient 1,
        FourNormalKernels S z i N e ∧ ∀
  (f₀ : Lp ℂ 2 (((volume : Measure (Ambient 1)).prod (volume : Measure (Ambient 1))).prod (volume : Measure (Ambient 3))))
  (f₁ : Lp ℂ 2 (((volume : Measure (Ambient 1)).prod (volume : Measure (Ambient 1))).prod (volume : Measure (Ambient 1))))
  (f₂ : Lp ℂ 2 (((volume : Measure (Ambient 3)).prod (volume : Measure (Ambient 1))).prod (volume : Measure (Ambient 1))))
  (f₃ : Lp ℂ 2 (((volume : Measure (Ambient 3)).prod (volume : Measure (Ambient 1))).prod (volume : Measure (Ambient 1)))),
    eLpNorm' (fun x => fourBlockProduct volume volume volume volume f₀ f₁ f₂ f₃ (e x)) (2 / 3) volume ≤
      K * (‖f₀‖ₑ * ‖f₁‖ₑ * ‖f₂‖ₑ * ‖f₃‖ₑ) := by
  obtain ⟨B,hB,hcoord⟩ := uniform_thin_normal_four_coordinates i M c hM hc
  obtain ⟨K,hK,hfin,hbound⟩ := uniform_linear_3111_L2 B hB.le
  refine ⟨K,hK,hfin,?_⟩
  intro S z q N b hunit hshape hq₁ hq₂ hN hA₁ hA₂ hG
  obtain ⟨e,he,hei,hker⟩ := hcoord S z q N b hunit hshape hq₁ hq₂ hN hA₁ hA₂ hG
  exact ⟨e,hker,hbound e he hei⟩

end N2Restriction

#print axioms N2Restriction.uniform_actual_normal_four_L2
