import N2Restriction.CoordinatePacketFamily

namespace N2Restriction
open MeasureTheory Set
noncomputable local instance : MeasureSpace UnitAddCircle := ⟨AddCircle.haarAddCircle⟩

/-- A cap piece can be nonzero only if its partition multiplier meets the
actual essential input support. The support set need not contain all centres. -/
theorem active_partition_piece_witness {d : ℕ} {ι : Type*} [Fintype ι]
    {K : Set (Ambient d)} (ρ : PartitionOfUnity ι (Ambient d) K)
    (f : Lp ℂ 2 (volume : Measure (Ambient d))) {E : Type*}
    (ζ : Ambient d → E) (F : Set E) (hf : HasFrequencySupport volume ζ F f)
    (j : ι) (hj : partitionL2Piece ρ f j ≠ 0) :
    ∃ y, ζ y ∈ F ∧ ρ j y ≠ 0 := by
  classical
  by_contra hn
  apply hj
  apply Lp.ext
  filter_upwards [partitionL2Piece_coe ρ f j, hf, Lp.coeFn_zero ℂ 2 volume] with y hy hs hz
  rw [hy, hz]
  by_cases hfy : f y = 0
  · simp [hfy]
  · have hρ : ρ j y = 0 := by
      by_contra h
      exact hn ⟨y, hs hfy, h⟩
    simp [hρ]

/-- Zero cap pieces give zero ordinary cap inputs. -/
theorem CoordinateCapFamily.input_zero_of_piece_zero {d : ℕ} {K : Set (Ambient d)} {r : ℝ}
    (P : CoordinateCapFamily K r) (hr : 0 < r)
    (f : Lp ℂ 2 (volume : Measure (Ambient d))) (j : P.centers)
    (hj : partitionL2Piece P.partition f j = 0) : P.input hr f j = 0 := by
  apply norm_eq_zero.mp
  change ‖partitionCapInput P.partition (fun j => j.val) r hr f j‖ = 0
  rw [partitionCapInput_norm P.partition _ r hr P.support, hj, norm_zero]

/-- A zero ordinary cap input has no Fourier packets. -/
theorem actualPacketInput_zero {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (ν : Fin d → ℤ) : actualPacketInput c r hr 0 ν = 0 := by
  rw [actualPacketInput_eq_mode]
  have hz : normalizedCapInput (fun _ => -(1 / 2 : ℝ)) c
      (2 * Real.pi * r) (by positivity) 0 = 0 := by
    apply norm_eq_zero.mp
    rw [normalizedCapInput_norm, norm_zero, mul_zero]
  rw [hz]
  rw [capFourierCoeff, map_zero, ← UnitAddTorus.mFourierBasis_repr, map_zero]
  simp

/-- Inactive caps disappear before any frequency-support enlargement. -/
theorem CoordinateCapFamily.packet_zero_of_piece_zero {d : ℕ} {K : Set (Ambient d)} {r : ℝ}
    (P : CoordinateCapFamily K r) (hr : 0 < r)
    (f : Lp ℂ 2 (volume : Measure (Ambient d))) (j : P.centers)
    (hj : partitionL2Piece P.partition f j = 0) (ν : Fin d → ℤ) : P.packet hr f j ν = 0 := by
  change actualPacketInput _ _ _ (P.input hr f j) ν = 0
  rw [P.input_zero_of_piece_zero hr f j hj, actualPacketInput_zero]

end N2Restriction
#print axioms N2Restriction.active_partition_piece_witness
#print axioms N2Restriction.CoordinateCapFamily.input_zero_of_piece_zero
#print axioms N2Restriction.actualPacketInput_zero
#print axioms N2Restriction.CoordinateCapFamily.packet_zero_of_piece_zero
