import continuation.BlockBallVolumeV32

namespace N2Restriction
open MeasureTheory Metric
open scoped ENNReal BigOperators

/-- Fixed normalization for the 3+1+1 product-ball cross-sections. -/
noncomputable def block311VolumeConstant : ℝ≥0∞ :=
  ((volume.prod volume) (closedBall (0 : Ambient 1 × Ambient 1) 1)) ^ (1 / 2 : ℝ) *
  ((volume.prod volume) (closedBall (0 : Ambient 3 × Ambient 1) 1)) ^ (1 / 2 : ℝ) *
  ((volume.prod volume) (closedBall (0 : Ambient 3 × Ambient 1) 1)) ^ (1 / 2 : ℝ)

theorem block311VolumeConstant_ne_top : block311VolumeConstant ≠ ⊤ := by
  unfold block311VolumeConstant
  have h11 := block_unit_ball_volume_ne_top 1 1
  have h31 := block_unit_ball_volume_ne_top 3 1
  finiteness

theorem block311VolumeConstant_pos : 0 < block311VolumeConstant := by
  have h11 : 0 < (volume.prod volume) (closedBall (0 : Ambient 1 × Ambient 1) 1) :=
    measure_closedBall_pos _ _ (by norm_num)
  have h31 : 0 < (volume.prod volume) (closedBall (0 : Ambient 3 × Ambient 1) 1) :=
    measure_closedBall_pos _ _ (by norm_num)
  unfold block311VolumeConstant
  positivity

/-- Exact fifth-power scaling, with the fixed volume constant separated from
the three total weights. -/
theorem block311_ball_mass (r : ℝ) (hr : 0 ≤ r) (u v s : ℝ≥0∞) :
    ((u * (volume.prod volume) (closedBall (0 : Ambient 1 × Ambient 1) r)) ^ (1 / 2 : ℝ) *
     (v * (volume.prod volume) (closedBall (0 : Ambient 3 × Ambient 1) r)) ^ (1 / 2 : ℝ) *
     (s * (volume.prod volume) (closedBall (0 : Ambient 3 × Ambient 1) r)) ^ (1 / 2 : ℝ)) =
    block311VolumeConstant * ENNReal.ofReal r ^ 5 *
      (u ^ (1 / 2 : ℝ) * v ^ (1 / 2 : ℝ) * s ^ (1 / 2 : ℝ)) := by
  rw [block_ball_volume 1 1 _ r hr, block_ball_volume 3 1 _ r hr]
  norm_num only [Nat.reduceAdd]
  rw [block_311_width_scaling]
  simp only [ENNReal.mul_rpow_of_nonneg _ _ (by norm_num : (0 : ℝ) ≤ 1 / 2),
    block311VolumeConstant]
  ring

end N2Restriction

#print axioms N2Restriction.block311VolumeConstant_ne_top
#print axioms N2Restriction.block311VolumeConstant_pos
#print axioms N2Restriction.block311_ball_mass
