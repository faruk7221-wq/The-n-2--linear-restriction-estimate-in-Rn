import continuation.BinaryStageConstructionV41
import continuation.PolynomialStageBudgetV51
namespace N2Restriction
open Set Metric MeasureTheory
open scoped BigOperators ENNReal

/-- The actual selection propagates the same fixed numerical stage ceilings. -/
theorem polynomial_binary_input_stage_with_budget {n k m : ℕ}
    (μ : Fin k → Measure (Ambient n)) (f : Fin k → Bool → Ambient n → ℂ)
    (hf : ∀ i b, Integrable (f i b) (μ i)) {p R r : ℝ} {M₀ err : ENNReal}
    (hp : 0 < p) (hp1 : p ≤ 1)
    (S : PolynomialStage μ (fun i y => ∑ b, f i b y) p R r M₀ err m)
    (B : PolynomialStageBudget) (hB : S.withinBudget B) :
    ∃ σ : Fin k → Bool,
    ∃ S' : PolynomialStage μ (fun i => f i (σ i)) p R r M₀ err m,
      S'.equations = S.equations ∧ S'.degreeBound = S.degreeBound ∧
      S'.region = S.region ∧ S'.multiplier = S.multiplier ∧
      S'.constant = max 1 (S.constant*(2^k : ENNReal)) ∧ S'.withinBudget (B.advance 0 1 le_rfl (2^k : ENNReal) (by simp)) := by
  obtain ⟨σ,S',heq,hdeg,hregion,hmult,hconst⟩ := polynomial_binary_input_stage μ f hf hp hp1 S
  refine ⟨σ,S',heq,hdeg,hregion,hmult,hconst,?_⟩
  apply polynomial_stage_budget_update S S' B hB 0 1 le_rfl (2^k : ENNReal) (by simp)
  · simp only [hdeg,Nat.max_zero,le_refl]
  · simp only [hmult,one_mul,le_refl]
  · rw [hconst]

end N2Restriction
#print axioms N2Restriction.polynomial_binary_input_stage_with_budget
