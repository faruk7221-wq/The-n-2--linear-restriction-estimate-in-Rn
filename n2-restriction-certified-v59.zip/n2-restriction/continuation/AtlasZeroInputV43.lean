import continuation.AtlasSelectedMajorantV42

namespace N2Restriction
open MeasureTheory Set
open scoped BigOperators ENNReal

/-- A zero original input forces the selected atlas extension product to
vanish, even after arbitrary packet selection. -/
theorem atlas_selected_product_zero {d k : ℕ} (S : Fin k → SmoothPatch (d+1))
    (T : (i : Fin k) → PacketGraphAtlas (S i)) {r : ℝ} (hr : 0 < r)
    (Q : (i : Fin k) → (j : Fin (T i).size) → CoordinateCapFamily ((T i).patch j).support r)
    (hsmall : ∀ i, r ≤ (T i).capRadius)
    (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure)
    (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure)
    (he : ∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2)
    (A : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ))
    (i : Fin k) (hi : ‖g i‖ = 0) (x : Ambient (d+1)) :
    extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
      (fun i => (T i).cellInput (Q i) hr (f i) (A i)) x = 0 := by
  obtain ⟨C, _, hc⟩ := (T i).selected_input_majorant
  have hh := (hc (Q i) hr (g i) (f i) (he i) (A i)).2 (hsmall i) x
  rw [hi, mul_zero] at hh
  apply Finset.prod_eq_zero (Finset.mem_univ i)
  exact norm_eq_zero.mp (le_antisymm hh (norm_nonneg _))

/-- Nonzero selected reset mass discharges every positive-norm hypothesis
in the simultaneous Markov cell-selection theorem. -/
theorem atlas_nonzero_mass_positive_norms {d k : ℕ} (S : Fin k → SmoothPatch (d+1))
    (T : (i : Fin k) → PacketGraphAtlas (S i)) {r : ℝ} (hr : 0 < r)
    (Q : (i : Fin k) → (j : Fin (T i).size) → CoordinateCapFamily ((T i).patch j).support r)
    (hsmall : ∀ i, r ≤ (T i).capRadius)
    (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure)
    (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure)
    (he : ∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2)
    (A : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ))
    (Ω : Set (Ambient (d+1))) {p : ℝ} (hp : 0 < p)
    (hmass : (∫⁻ x in Ω, ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
      (fun i => (T i).cellInput (Q i) hr (f i) (A i)) x‖ₑ ^ p) ≠ 0) : ∀ i, 0 < ‖g i‖ := by
  intro i
  by_contra hi
  have hz : ‖g i‖ = 0 := le_antisymm (not_lt.mp hi) (norm_nonneg _)
  apply hmass
  simp only [atlas_selected_product_zero S T hr Q hsmall g f he A i hz,
    enorm_zero, ENNReal.zero_rpow_of_pos hp, lintegral_zero]

end N2Restriction
#print axioms N2Restriction.atlas_selected_product_zero
#print axioms N2Restriction.atlas_nonzero_mass_positive_norms
