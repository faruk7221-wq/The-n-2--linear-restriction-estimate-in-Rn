import continuation.CylinderPerturbationV32

namespace N2Restriction
open Set Metric

/-- At an arbitrary physical center, the reference cylinder's center must be
corrected by the projection mismatch evaluated at that center. -/
theorem centered_perturbed_projection_cylinder_subset
    {E F : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    (P Q : E →L[ℝ] F) (x₀ : E) (z : F) (R w δ : ℝ) (hδ : 0 ≤ δ)
    (hPQ : ‖P - Q‖ ≤ δ) :
    closedBall x₀ R ∩ P ⁻¹' closedBall z w ⊆
      Q ⁻¹' closedBall (z + (Q - P) x₀) (w + δ * R) := by
  intro x hx
  have hxR : ‖x - x₀‖ ≤ R := by simpa [dist_eq_norm] using hx.1
  have hxw : ‖P x - z‖ ≤ w := by simpa [dist_eq_norm] using hx.2
  have hop := (P - Q).le_of_opNorm_le hPQ (x - x₀)
  have hnorm : ‖(Q - P) (x - x₀)‖ ≤ δ * ‖x - x₀‖ := by
    simpa only [ContinuousLinearMap.sub_apply, norm_sub_rev] using hop
  have hid : Q x - (z + (Q - P) x₀) = (P x - z) + (Q - P) (x - x₀) := by
    simp only [map_sub, ContinuousLinearMap.sub_apply]
    abel
  change dist (Q x) (z + (Q - P) x₀) ≤ w + δ * R
  rw [dist_eq_norm, hid]
  exact (norm_add_le _ _).trans (add_le_add hxw
    (hnorm.trans (mul_le_mul_of_nonneg_left hxR hδ)))

end N2Restriction

#print axioms N2Restriction.centered_perturbed_projection_cylinder_subset
