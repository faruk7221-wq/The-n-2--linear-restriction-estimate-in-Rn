import continuation.AdjointCompressionV26

set_option maxHeartbeats 800000

namespace N2Restriction

/-- Ambient normals followed by two adjoint shape images. This frame applies
at nonzero projected-normal levels as well as at zero levels. -/
noncomputable def adjointWedgeVectors {k : ℕ} (S : Fin k → SmoothPatch (k + 2))
    (z : Fin k → Ambient (k + 2)) (i : Fin k)
    (q : Ambient (k + 2) × Ambient (k + 2)) :
    Sum (Fin k) (Fin 2) → Ambient (k + 2) :=
  Sum.elim (fun j => (S j).normal (z j)) (fun a =>
    ((S i).shape (z i)).adjoint (if a = 0 then q.1 else q.2))

/-- Curvature-scaled proximity gives independence of the adjoint frame,
without imposing that the nearby plane be tangent to the selected surface. -/
theorem geometric_adjoint_frame_independent {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) {ν κ : ℝ}
    (hgeo : GeometricHypotheses S ν κ)
    (z : Fin k → Ambient (k + 2))
    (hz : ∀ j, z j ∈ (S j).extendedSurface) (i : Fin k)
    (q : Ambient (k + 2) × Ambient (k + 2))
    (hq : q ∈ orthonormalPairSet (k + 2))
    (hgap : ‖(commonTangent (fun j => (S j).normal (z j))).starProjection -
      pairProjection q‖ * ‖(S i).shape (z i)‖ ≤ κ / 2) :
    LinearIndependent ℝ (adjointWedgeVectors S z i q) := by
  let N : Fin k → Ambient (k + 2) := fun j => (S j).normal (z j)
  let W := commonTangent N
  let H := pairPlane q
  let A := (S i).shape (z i)
  have hnormals : LinearIndependent ℝ N := by
    apply normals_independent_of_gram N
    have hdet := (hgeo.2.2 z hz).1
    exact ne_of_gt (lt_of_lt_of_le (sq_pos_of_pos hgeo.1) hdet)
  have hdim : Module.finrank ℝ W = Module.finrank ℝ H := by
    rw [geometric_commonTangent_two S hgeo z hz, pairPlane_finrank_two hq]
  have hA : ∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (A v)‖ :=
    (hgeo.2.2 z hz).2 i
  have hgap' : ‖W.starProjection - H.starProjection‖ * ‖A‖ ≤ κ / 2 := by
    simpa only [pairProjection_eq_planeProjection hq] using hgap
  have hreverse := nearby_reverse_adjoint_coercive A W H hdim hgeo.2.1 hA hgap'
  rw [Fintype.linearIndependent_iff]
  intro c hc a
  let u := c (Sum.inr (0 : Fin 2)) • q.1 + c (Sum.inr (1 : Fin 2)) • q.2
  let h : H := ⟨u, by
    change u ∈ Submodule.span ℝ ({q.1, q.2} : Set _)
    exact Submodule.mem_span_pair.mpr ⟨c (Sum.inr 0), c (Sum.inr 1), rfl⟩⟩
  have hcombine : (∑ j : Fin k, c (Sum.inl j) • N j) + A.adjoint (h : Ambient (k + 2)) = 0 := by
    have hs := hc
    simp only [adjointWedgeVectors, Fintype.sum_sum_type, Fin.sum_univ_two] at hs
    simpa [h, u, map_add, map_smul, add_assoc] using hs
  have hNproj : ∀ j : Fin k, W.orthogonalProjection (N j) = 0 := by
    intro j
    apply Submodule.orthogonalProjection_eq_zero_iff.mpr
    rw [Submodule.mem_orthogonal]
    intro v hv
    exact (real_inner_comm _ _).trans (commonTangent_orthogonal N ⟨v, hv⟩ j)
  have hsumproj : W.orthogonalProjection
      (∑ j : Fin k, c (Sum.inl j) • N j) = 0 := by
    rw [map_sum]
    apply Finset.sum_eq_zero
    intro j hj
    rw [map_smul, hNproj, smul_zero]
  have hAproj : W.orthogonalProjection (A.adjoint (h : Ambient (k + 2))) = 0 := by
    have hp := congrArg W.orthogonalProjection hcombine
    rw [map_add, hsumproj, zero_add] at hp
    simpa using hp
  have hh : (h : Ambient (k + 2)) = 0 := by
    have hb := hreverse h
    rw [hAproj, norm_zero] at hb
    have hκpos : 0 < κ := hgeo.2.1
    have hκ2 : 0 < κ / 2 := by positivity
    have hnorm : ‖(h : Ambient (k + 2))‖ = 0 := by
      apply le_antisymm
      · by_contra hnot
        have hpos : 0 < ‖(h : Ambient (k + 2))‖ := lt_of_not_ge hnot
        have hprod := mul_pos hκ2 hpos
        exact (not_le_of_gt hprod) hb
      · exact norm_nonneg _
    exact norm_eq_zero.mp hnorm
  have hcoeff₀ : c (Sum.inr (0 : Fin 2)) = 0 := by
    have hinner := congrArg (fun x : Ambient (k + 2) => inner ℝ q.1 x) hh
    have huu : inner ℝ q.1 q.1 = 1 := by
      rw [real_inner_self_eq_norm_sq, hq.1]
      norm_num
    have huv : inner ℝ q.1 q.2 = 0 := hq.2.2
    simpa [h, u, inner_add_right, inner_smul_right, huu, huv] using hinner
  have hcoeff₁ : c (Sum.inr (1 : Fin 2)) = 0 := by
    have hinner := congrArg (fun x : Ambient (k + 2) => inner ℝ q.2 x) hh
    have hvv : inner ℝ q.2 q.2 = 1 := by
      rw [real_inner_self_eq_norm_sq, hq.2.1]
      norm_num
    have hvu : inner ℝ q.2 q.1 = 0 := by rw [real_inner_comm, hq.2.2]
    simpa [h, u, inner_add_right, inner_smul_right, hvu, hvv] using hinner
  have hnormalsum : (∑ j : Fin k, c (Sum.inl j) • N j) = 0 := by
    have hs := hcombine
    rw [hh, map_zero, add_zero] at hs
    exact hs
  have hnormalcoeff := (Fintype.linearIndependent_iff.mp hnormals)
    (fun j => c (Sum.inl j)) hnormalsum
  cases a with
  | inl j => exact hnormalcoeff j
  | inr j =>
      fin_cases j
      · exact hcoeff₀
      · exact hcoeff₁


end N2Restriction

#print axioms N2Restriction.geometric_adjoint_frame_independent
