import continuation.ActualTangentCubeIntegralV48
import continuation.CubeNormProductV49

namespace N2Restriction
open MeasureTheory Set Metric Filter
open scoped ENNReal NNReal

/-- The actual tangent-cube integral is controlled by the common original
Kakeya cube energies. These energies do not depend on the covering ball or
binary angular choice. Both the selected support and norm-budget bridges
are proved; only the borrowed localized restriction input remains external. -/
theorem eventually_actual_cube_kakeya_integral {k : ℕ}
    (S : Fin k → SmoothPatch (k+2)) (A : (i : Fin k) → PacketGraphAtlas (S i))
    {κ : ℝ} (B : ArticleLocalizationAtlas S κ)
    (V : Fin k → Set (Ambient (k+2))) (m : ℝ)
    (hS : ∀ i, (S i).extendedSurface ∩ V i ⊆ (S i).support) (hm : 0 < m)
    {p ε τ lam : ℝ} (hp : 0 < p) (hε : 0 < ε)
    (hexternal : B.UniformLocalizedInput p) (hτ : 0 < τ) (hτ' : τ < 1/4) (hlam : 0 < lam) :
    ∃ D : ℝ≥0, ∃ H : ℝ, 0 ≤ H ∧ ∀ᶠ R : ℝ in atTop,
    ∀ (Q : (i : Fin k) → (j : Fin (A i).size) →
      CoordinateCapFamily ((A i).patch j).support (R^(-1/2 : ℝ)))
      (hr : 0 < R^(-1/2 : ℝ)), (∀ i, R^(-1/2 : ℝ) ≤ (A i).capRadius) →
    ∀ (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure),
    (∀ i j, HasFrequencySupport ((A i).graph j).surfaceMeasure ((A i).patch j).rotation
      (marginRegion (V i) (m-R^(-1/4 : ℝ))) (f i j)) →
    ∀ (i₀ : Fin k) (Z : Set (Ambient (k+2)))
      (T : Ambient (k+2) → Submodule ℝ (Ambient (k+2))) (F : Submodule ℝ (Ambient (k+2)))
      (center q x z : Ambient (k+2)) (C C₀ : ℝ) (Ω E : Set (Ambient (k+2)))
      (Ubase : (j : Fin (A i₀).size) → (Q i₀ j).centers → Set (Fin (k+1) → ℤ))
      (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin (k+1) → ℤ))
      (frame : ArticleFrame S κ),
    pairPlane frame.val = (T z ⊔ F)ᗮ →
    0 ≤ C → 1+Real.sqrt (k+2 : ℕ)*(1+C)/2 ≤ C₀ →
    z ∈ Z → x ∈ ball center (R^(1-τ)) → x ∈ gridCube q (lam*R^(1/2+τ)) →
    dist z x ≤ lam*R^(1/2+τ) → E ⊆ gridCube q (lam*R^(1/2+τ)) →
    U i₀ = (fun j a => (A i₀).actualTangentSelection (Q i₀) Ubase Z T center (R^(1-τ))
      (lam*R^(1/2+τ)) C₀ R (R^(1/2+τ)/10) Ω j a ∩
      {ν | ((A i₀).originalPacketTube j a (R^(-1/2 : ℝ)) ν R (R^(1/2+τ)/10) ∩
        gridCube q (C*(lam*R^(1/2+τ)))).Nonempty}) →
    (∀ i j a ν, ν ∈ U i j a →
      ((A i).originalPacketTube j a (R^(-1/2 : ℝ)) ν R (R^(1/2+τ)/10) ∩
        gridCube q (C*(lam*R^(1/2+τ)))).Nonempty) →
    (∫⁻ y in E, ‖extensionProduct (fun _ => Measure.hausdorffMeasure ((k+1 : ℕ) : ℝ))
      (fun _ => id) (fun i => (A i).cellInput (Q i) hr (f i) (U i)) y‖ₑ ^ p) ≤
      (((D : ENNReal)*ENNReal.ofReal (((1+Real.sqrt (k+2 : ℕ))*(lam*R^(1/2+τ)))^ε))^p *
        (ENNReal.ofReal (lam*R^(-1/2+2*τ)))^p) *
      ((ENNReal.ofReal H)^(p/2) *
        (∏ i, (A i).cubeEnergy (Q i) hr (f i) R (R^(1/2+τ)/10) C (lam*R^(1/2+τ)) q)^(p/2)) := by
  obtain ⟨D,hd⟩ := eventually_actual_tangent_cube_integral S A B V m hS hm hp hε hexternal hτ hτ' hlam
  obtain ⟨H,hH,hcube⟩ := atlas_cube_norm_product S A
  refine ⟨D,H,hH,?_⟩
  filter_upwards [hd] with R hR
  intro Q hr hsmall f hf i₀ Z T F center q x z C C₀ Ω E Ubase U frame hplane
    hC hC₀ hz hxb hxq hzx hE hU hmeet
  apply (hR Q hr hsmall f hf i₀ Z T F center q x z C C₀ Ω E Ubase U frame hplane
    hC hC₀ hz hxb hxq hzx hE hU).trans
  exact mul_le_mul_left' (hcube Q hr f U R (R^(1/2+τ)/10) C (lam*R^(1/2+τ)) q hmeet p hp.le) _

end N2Restriction
#print axioms N2Restriction.eventually_actual_cube_kakeya_integral
