import continuation.GeometricWallLocationV40
import Mathlib.MeasureTheory.Measure.MeasureSpace
import Mathlib.Data.Finset.Max

namespace N2Restriction
open Set Metric MeasureTheory
open scoped BigOperators

/-- The lifted product zero set is exactly the union of its factor intersections. -/
theorem product_intersection_eq_union {E H I : Type*} [Fintype I]
    (Z : Set E) (π : E → H) (P : I → H → ℝ) :
    Z ∩ {x | (∏ i, P i (π x)) = 0} = ⋃ i, Z ∩ {x | P i (π x) = 0} := by
  classical
  ext x
  simp only [mem_inter_iff, mem_setOf_eq, Finset.prod_eq_zero_iff, Finset.mem_univ,
    true_and, mem_iUnion]
  exact ⟨fun ⟨hz, i, hi⟩ => ⟨i, hz, hi⟩, fun ⟨i, hz, hi⟩ => ⟨hz, i, hi⟩⟩

/-- The geometric wall is covered by neighborhoods of the actual factor
intersections. The number of factors is finite, but the proof is pointwise. -/
theorem geometric_wall_factor_cover {n : ℕ} {G I : Type*} [Fintype I]
    [NormedAddCommGroup G] [InnerProductSpace ℝ G] [FiniteDimensional ℝ G]
    (V : Submodule ℝ (Ambient n)) (q : Ambient n → G) (Z cuts Ω : Set (Ambient n))
    {b : ℝ} (hZ : IsClosed Z) (hc : IsClosed cuts) (hZeq : Z = {y | q y = 0})
    (hw : ∀ x ∈ Ω, Nonempty (ShortLiftWitness V q Z cuts b x)) (P : I → V → ℝ) :
    Ω ∩ thickening b {x | (∏ i, P i (V.orthogonalProjection x)) = 0} ⊆
      ⋃ i, Ω ∩ thickening (5*b) (Z ∩ {x | P i (V.orthogonalProjection x) = 0}) := by
  classical
  intro x hx
  have hl := retained_wall_subset_intersection V q Z cuts Ω hZ hc hZeq hw
    (fun v => ∏ i, P i v) hx
  obtain ⟨z, ⟨hz, hp⟩, hxz⟩ := mem_thickening_iff.mp hl.2
  obtain ⟨i, _, hi⟩ := Finset.prod_eq_zero_iff.mp hp
  exact mem_iUnion.mpr ⟨i, hl.1, mem_thickening_iff.mpr ⟨z, ⟨hz, hi⟩, hxz⟩⟩

/-- A finite cover has a member carrying at least the inverse-cardinality
fraction of the covered mass. This also allows infinite measures. -/
theorem finite_cover_mass_selection {E I : Type*} [MeasurableSpace E] [Fintype I] [Nonempty I]
    (μ : Measure E) (A : Set E) (B : I → Set E) (hcover : A ⊆ ⋃ i, B i) :
    ∃ i, μ A ≤ (Fintype.card I : ENNReal) * μ (B i) := by
  classical
  obtain ⟨i, _, hi⟩ := Finset.exists_max_image Finset.univ (fun i => μ (B i)) Finset.univ_nonempty
  refine ⟨i, (measure_mono hcover).trans ((measure_iUnion_fintype_le μ B).trans ?_)⟩
  calc
    ∑ j, μ (B j) ≤ ∑ _j : I, μ (B i) := Finset.sum_le_sum (fun j hj => hi j hj)
    _ = (Fintype.card I : ENNReal) * μ (B i) := by simp

end N2Restriction
#print axioms N2Restriction.product_intersection_eq_union
#print axioms N2Restriction.geometric_wall_factor_cover
#print axioms N2Restriction.finite_cover_mass_selection
