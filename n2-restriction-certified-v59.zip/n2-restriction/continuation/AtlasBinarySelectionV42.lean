import continuation.AtlasCellSupportV42
import continuation.BinaryExtensionSelectionV41

namespace N2Restriction
open MeasureTheory Set
open scoped BigOperators ENNReal

/-- Binary mass selection is valid for actual L2 sums, whose chosen
representatives need only agree almost everywhere with pointwise sums. -/
theorem binary_L2_extension_mass_selection {n k : ℕ}
    (μ : Fin k → Measure (Ambient n)) (f : (i : Fin k) → Bool → Lp ℂ 2 (μ i))
    (hf : ∀ i b, Integrable (f i b) (μ i)) (Ω : Set (Ambient n))
    {p : ℝ} (hp : 0 < p) (hp1 : p ≤ 1) :
    ∃ σ : Fin k → Bool,
      (∫⁻ x in Ω, ‖extensionProduct μ (fun _ => id)
        (fun i => (∑ b, f i b : Lp ℂ 2 (μ i))) x‖ₑ ^ p) ≤
      (2^k : ENNReal) * (∫⁻ x in Ω, ‖extensionProduct μ (fun _ => id)
        (fun i => f i (σ i)) x‖ₑ ^ p) := by
  have he i x : extension (μ i) id (∑ b, f i b : Lp ℂ 2 (μ i)) x =
      extension (μ i) id (fun y => ∑ b, f i b y) x := by
    unfold extension
    apply integral_congr_ae
    simp only [Fintype.sum_bool]
    filter_upwards [Lp.coeFn_add (f i true) (f i false)] with y hy
    rw [hy]
    rfl
  simpa only [extensionProduct, he] using
    binary_extension_mass_selection μ (fun i b => f i b) hf Ω hp hp1

/-- The actual two pieces used in the near/far choice. -/
noncomputable def PacketGraphAtlas.binaryCellInput {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) {r : ℝ}
    (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r) (hr : 0 < r)
    (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
    (U V : (j : Fin T.size) → (Q j).centers → Set (Fin d → ℤ))
    (b : Bool) : Lp ℂ 2 (Measure.hausdorffMeasure (d : ℝ) : Measure (Ambient (d+1))) :=
  if b then T.cellInput Q hr f (fun j a => U j a ∩ V j a)
  else T.cellInput Q hr f (fun j a => U j a \ V j a)

theorem PacketGraphAtlas.binaryCellInput_sum {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) {r : ℝ}
    (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r) (hr : 0 < r)
    (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
    (U V : (j : Fin T.size) → (Q j).centers → Set (Fin d → ℤ)) :
    (∑ b, T.binaryCellInput Q hr f U V b) = T.cellInput Q hr f U := by
  simpa only [Fintype.sum_bool, binaryCellInput, Bool.true_eq, ↓reduceIte, Bool.false_eq_true] using
    (T.cellInput_split Q hr f U V).symm

/-- Equation (6.3), instantiated with the actual atlas packet partition.
No arbitrary input decomposition or integrability premise remains. -/
theorem atlas_binary_mass_selection {d k : ℕ} (S : Fin k → SmoothPatch (d+1))
    (T : (i : Fin k) → PacketGraphAtlas (S i)) {r : ℝ} (hr : 0 < r)
    (Q : (i : Fin k) → (j : Fin (T i).size) → CoordinateCapFamily ((T i).patch j).support r)
    (hsmall : ∀ i, r ≤ (T i).capRadius)
    (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure)
    (U V : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ))
    (Ω : Set (Ambient (d+1))) {p : ℝ} (hp : 0 < p) (hp1 : p ≤ 1) :
    ∃ σ : Fin k → Bool,
      (∫⁻ x in Ω, ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
        (fun i => (T i).cellInput (Q i) hr (f i) (U i)) x‖ₑ ^ p) ≤
      (2^k : ENNReal) * (∫⁻ x in Ω,
        ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
          (fun i => (T i).binaryCellInput (Q i) hr (f i) (U i) (V i) (σ i)) x‖ₑ ^ p) := by
  have hi i b : Integrable ((T i).binaryCellInput (Q i) hr (f i) (U i) (V i) b)
      (Measure.hausdorffMeasure (d : ℝ)) := by
    cases b <;> exact (T i).cellInput_integrable (Q i) hr (hsmall i) (f i) _
  simpa only [PacketGraphAtlas.binaryCellInput_sum] using
    binary_L2_extension_mass_selection (fun _ => Measure.hausdorffMeasure (d : ℝ))
      (fun i => (T i).binaryCellInput (Q i) hr (f i) (U i) (V i)) hi Ω hp hp1

end N2Restriction
#print axioms N2Restriction.binary_L2_extension_mass_selection
#print axioms N2Restriction.PacketGraphAtlas.binaryCellInput_sum
#print axioms N2Restriction.atlas_binary_mass_selection
