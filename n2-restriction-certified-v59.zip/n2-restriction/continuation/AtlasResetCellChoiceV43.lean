import continuation.AtlasDegreeCellChoiceV43
import continuation.ResetCellMassV43

namespace N2Restriction
open MeasureTheory
open scoped BigOperators ENNReal

/-- The substantial-cell choice for the actual reset partition measure.
Its conclusion supplies simultaneously the integral retention and the
near/far energy premises of the actual non-wall mass estimate. -/
theorem atlas_reset_cell_choice {d k : ℕ} (S : Fin k → SmoothPatch (d+1))
    (T : (i : Fin k) → PacketGraphAtlas (S i)) :
    ∃ B : Fin k → ℝ, (∀ i, 1 ≤ B i) ∧
      ∀ {m q H : ℕ} {C : Type*} [Fintype C] [Nonempty C] {r : ℝ}
        (Q : (i : Fin k) → (j : Fin (T i).size) → CoordinateCapFamily ((T i).patch j).support r)
        (hr : 0 < r) (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure)
        (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure),
      (∀ i, 0 < ‖g i‖) → (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
      ∀ (A : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ))
        (P : Fin m → MvPolynomial (Fin (d+1)) ℝ)
        (Z : Fin q → MvPolynomial (Fin (d+1)) ℝ) (cuts : Set (Ambient (d+1)))
        (V : Submodule ℝ (Ambient (d+1))) {γ K : ℝ}, 0 ≤ K →
      AlgebraicTubeCoverInput {x | polynomialLevelMap Z x = 0}
        (fun z => LinearMap.ker (fderiv ℝ (polynomialLevelMap Z) z).toLinearMap) γ H K →
      ∀ (Ω : Set (Ambient (d+1))) {b w : ℝ}, 0 < b → w < b →
      Ω ⊆ Metric.thickening b (planeWitnessSet Z cuts V (2*γ)) →
      ∀ (far : Finset (Fin k)),
      (∀ i ∈ far, ∀ j a ν, ν ∈ A i j a →
        4*γ < directionPlaneAngle ((T i).cellAxisDirection j a.val) V) →
      ∀ (label : C → (Fin m → Bool)), Function.Injective label →
      ∀ (Δ : C → Set (Ambient (d+1))), (∀ c, MeasurableSet (Δ c)) →
      (∀ c, Δ c ⊆ Ω) → ∀ {p θ E : ℝ}, 0 < p → 0 < θ → 0 < E → volume Ω ≠ ⊤ →
      let ρ := partitionDensity (fun _ => Measure.hausdorffMeasure (d : ℝ))
        (fun i => (T i).cellInput (Q i) hr (f i) (A i)) Ω p
      0 < (ρ Set.univ).toReal → θ*(ρ Set.univ).toReal ≤ ∑ c, (ρ (Δ c)).toReal →
      (∀ c, (ρ (Δ c)).toReal ≤ E*(ρ Set.univ).toReal/Fintype.card C) →
      ∀ {D c₀ c₁ s : ℝ}, 1 ≤ D → 0 < c₀ →
      c₀*D^s ≤ Fintype.card C → (Fintype.card C : ℝ) ≤ c₁*D^s →
      ((∏ l, P l).totalDegree : ℝ) ≤ D →
      ∃ c, (∫⁻ x in Ω, ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ))
          (fun _ => id) (fun i => (T i).cellInput (Q i) hr (f i) (A i)) x‖ₑ ^ p) ≤
        ENNReal.ofReal (2*c₁/θ)*ENNReal.ofReal (D^s) *
          (∫⁻ x in Δ c, ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ))
            (fun _ => id) (fun i => (T i).cellInput (Q i) hr (f i) (A i)) x‖ₑ ^ p) ∧
        ∀ i, ‖(T i).cellInput (Q i) hr (f i)
          (fun j a => {ν | ν ∈ A i j a ∧ label c ∈ trimmedCellLabels P
            ((T i).cellAxisPoint j r ν) ((T i).cellAxisDirection j a.val) Ω b w})‖^2 ≤
          ((2*E*((k : ℝ)+1)/θ)/c₀ * B i * max 2 (max 1 ((H : ℝ)*(K+2)^(d+1)))) *
            D^(1-s-(if i ∈ far then (1 : ℝ) else 0))*‖g i‖^2 := by
  classical
  obtain ⟨B, hB, hb⟩ := atlas_degree_cell_choice S T
  refine ⟨B, hB, ?_⟩
  intro m q H C _ _ r Q hr g f hg he A P Z cuts V γ K hK hexternal Ω b w hbpos hw hregion far hangle label hinj Δ hmeas hsub p θ E hp hθ hE hvol
  dsimp only
  intro hM htotal hupper D c₀ c₁ s hD hc₀ hcount hcountupper hdeg
  let ρ := partitionDensity (fun _ => Measure.hausdorffMeasure (d : ℝ))
    (fun i => (T i).cellInput (Q i) hr (f i) (A i)) Ω p
  obtain ⟨c, hret, henergy⟩ := hb Q hr g f hg he A P Z cuts V hK hexternal Ω hbpos hw hregion far hangle label hinj
    (fun c => (ρ (Δ c)).toReal) hM hθ hE htotal hupper hD hc₀ hcount hcountupper hdeg
  refine ⟨c, ?_, henergy⟩
  have hJ : (0 : ℝ) < Fintype.card C := by exact_mod_cast Fintype.card_pos
  have hDp : 0 < D := zero_lt_one.trans_le hD
  have hc₁ : 0 ≤ c₁ := by nlinarith [Real.rpow_pos_of_pos hDp s]
  have hcoef : 0 ≤ 2*c₁/θ := by positivity
  have hh := partitionDensity_mass_retention (fun _ => Measure.hausdorffMeasure (d : ℝ))
    (fun i => (T i).cellInput (Q i) hr (f i) (A i)) Ω (Δ c) hvol (hmeas c) (hsub c)
    hp.le (mul_nonneg hcoef (Real.rpow_nonneg hDp.le _)) hret
  rw [ENNReal.ofReal_mul hcoef] at hh
  exact hh

end N2Restriction
#print axioms N2Restriction.atlas_reset_cell_choice
