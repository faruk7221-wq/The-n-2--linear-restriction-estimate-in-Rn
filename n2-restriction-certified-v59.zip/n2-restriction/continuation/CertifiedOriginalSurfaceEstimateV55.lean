import continuation.InteriorSurfaceEstimateV54
import continuation.BufferedCoreFamilyV54
import continuation.CertifiedLocalizedInputV55
import continuation.FiniteSurfaceCoverV54
import continuation.FixedMarginSurfaceClassV44
namespace N2Restriction
open Set Metric MeasureTheory
open scoped BigOperators ENNReal NNReal
set_option maxHeartbeats 1800000

/-- The original-surface fixed-loss estimate. The SAME retained directional
cover creates the compact cores, positive margins and exact surface inputs;
all tuple estimates and finite-cover constants precede R and the original data. -/
theorem certified_original_surface_fixed_loss {k : ℕ} (hk : 3 ≤ k)
    (S : Fin k → SmoothPatch (k+2)) {ν κ : ℝ} (hgeo : GeometricHypotheses S ν κ)
    (hKexternal : WeightedKakeyaExternalGoal (k+2) k)
    (hLocalized : CertifiedLocalizedRestrictionInput (k := k))
    (hcutsExternal : UniformTangentCutsInput (k+2))
    (hpartitionExternal : UniformProjectedPartitionInput (k+2))
    (hcoverExternal : UniformPolynomialTubeCoverInput (k+2))
    (hpointsExternal : ZeroDimensionalPointCountInput (k+2))
    {δ p : ℝ} (hδ : 0 < δ) (hpc : critical k < p) (hpb : p < baseline k) :
    ∃ C : ℝ≥0, ∀ R : ℝ, 2 ≤ R →
    ∀ (x : Ambient (k+2)) (f : Fin k → Ambient (k+2) → ℂ),
      (∀ i, MemLp (f i) 2 (S i).surfaceMeasure) →
      eLpNorm' (extensionProduct (fun i => (S i).surfaceMeasure) (fun _ => id) f) p
        (volume.restrict (ball x R)) ≤
        (C : ENNReal)*ENNReal.ofReal (R^δ)*inputNormProduct (fun i => (S i).surfaceMeasure) f := by
  classical
  obtain ⟨W,U,m,hm,hW,hopen,hSW,hmargin,hext,hclass⟩ := exists_fixed_margin_surface_class S hgeo
  obtain ⟨ι,hι,Dsub,hrelative,hbound⟩ := exists_constructed_subpatch_surface_estimate_with_interiors hk W hW
    hKexternal hcutsExternal hpartitionExternal hcoverExternal hpointsExternal hδ
  choose O hO hcov hinside using hrelative
  let F : (i : Fin k) → BufferedDirectionalCoreFamily (S i) (W i) (Dsub i) := fun i =>
    Classical.choice (exists_buffered_directional_core_family (S i) (W i) (Dsub i) (hSW i) (U i)
      (hopen i) ((hmargin i).trans (marginRegion_subset (U i) hm)) (hclass i) (O i) (hO i) (hcov i) (hinside i))
  have htuple (a : (i : Fin k) → Fin (F i).size) :
      ∃ C : ℝ≥0, ∀ R : ℝ, 2 ≤ R →
      ∀ (x : Ambient (k+2)) (f : Fin k → Ambient (k+2) → ℂ),
        (∀ i, MemLp (f i) 2 ((F i).patch (a i)).surfaceMeasure) →
        eLpNorm' (extensionProduct (fun i => ((F i).patch (a i)).surfaceMeasure) (fun _ => id) f) p
          (volume.restrict (ball x R)) ≤
          (C : ENNReal)*ENNReal.ofReal (R^δ)*inputNormProduct (fun i => ((F i).patch (a i)).surfaceMeasure) f := by
    let b := fun i => (F i).label (a i)
    obtain ⟨margin,hmarginpos,hmarginle⟩ := fin_common_positive_core_margin
      (fun i => (F i).collar (a i)) (fun i => (F i).collar_pos (a i))
    obtain ⟨B,hB⟩ := exists_reduced_localized_atlas_from_certificates (by omega : 0 < k) hLocalized
      (fun i => (Dsub i).piece (b i)) (DirectionalSubdivision.geometric_hypotheses Dsub b hW)
    exact hbound b B (fun i => (F i).domain (a i)) margin (fun i => (F i).active (a i))
      hmarginpos hB (fun i => (F i).patch (a i)) (fun i => (F i).directional (a i))
      (fun i => ((F i).margin (a i)).trans (marginRegion_antitone _ (hmarginle i))) p hpc hpb
  choose C hC using htuple
  have hp : 0 < p := (critical_pos (by exact_mod_cast (show 0 < k by omega))).trans hpc
  exact finite_surface_cover_fixed_loss (by omega : 1 ≤ k+2) S (fun i => (F i).size)
    (fun i j => (F i).patch j) (fun i => (F i).cover) hp C hC
end N2Restriction
#print axioms N2Restriction.certified_original_surface_fixed_loss
