import continuation.NormalThicknessV25

namespace N2Restriction
open MeasureTheory Set Metric
open scoped NNReal ENNReal

/-- A normal strip inside a bounded full-coordinate ball has quadratic
volume in its two-dimensional normal thickness. -/
theorem coordinate_strip_volume_le {d k : ℕ}
    (e : Ambient d ≃L[ℝ] (ℝ × ℝ) × Ambient k) {M : ℝ}
    (hM : ‖e.toContinuousLinearMap‖ ≤ M) (a : ℝ × ℝ) (ρ ε : ℝ) :
    (volume : Measure (Ambient d)) {t ∈ closedBall 0 ρ | ‖a + (e t).1‖ ≤ ε} ≤
      (coordinateMeasureFactor e volume (volume.prod volume) : ℝ≥0∞) *
        (ENNReal.ofReal (2 * ε) ^ 2 * (volume : Measure (Ambient k)) (closedBall 0 (M * ρ))) := by
  let T := closedBall (-a) ε ×ˢ closedBall (0 : Ambient k) (M * ρ)
  have hT : MeasurableSet T := isClosed_closedBall.measurableSet.prod isClosed_closedBall.measurableSet
  have hsub : {t ∈ closedBall (0 : Ambient d) ρ | ‖a + (e t).1‖ ≤ ε} ⊆ e ⁻¹' T := by
    rintro t ⟨ht, hs⟩
    refine ⟨?_, ?_⟩
    · simpa [mem_closedBall, dist_eq_norm, add_comm] using hs
    · apply mem_closedBall_zero_iff.mpr
      calc
        ‖(e t).2‖ ≤ ‖e t‖ := norm_snd_le (e t)
        _ ≤ ‖e.toContinuousLinearMap‖ * ‖t‖ := e.toContinuousLinearMap.le_opNorm t
        _ ≤ M * ‖t‖ := mul_le_mul_of_nonneg_right hM (norm_nonneg _)
        _ ≤ M * ρ := mul_le_mul_of_nonneg_left (mem_closedBall_zero_iff.mp ht)
          ((norm_nonneg _).trans hM)
  calc
    _ ≤ (volume : Measure (Ambient d)) (e ⁻¹' T) := measure_mono hsub
    _ = (volume.map e) T := (Measure.map_apply e.continuous.measurable hT).symm
    _ = _ := by
      rw [map_linear_coordinates e volume (volume.prod volume), Measure.smul_apply]
      change (coordinateMeasureFactor e volume (volume.prod volume) : ℝ≥0∞) *
        (volume.prod volume) T = _
      rw [Measure.prod_prod, normal_pair_closedBall_volume]

end N2Restriction

#print axioms N2Restriction.coordinate_strip_volume_le
