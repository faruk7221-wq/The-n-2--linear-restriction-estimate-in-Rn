import continuation.FiniteCellBudgetV41

namespace N2Restriction
open scoped BigOperators ENNReal

/-- Simultaneous substantial-cell selection from the checked packet
budgets, restricted to the actual partition labels. The mass hypotheses
refer only to the reset density; no cellwise near/far comparison is used. -/
theorem substantial_cell_from_checked_budgets {C D I : Type*}
    [Fintype C] [Nonempty C] [Fintype I]
    (E : I → Type*) [∀ i, NormedAddCommGroup (E i)]
    (label : C → D) (hinj : Function.Injective label)
    (f : ∀ i, D → E i) (mass : C → ℝ)
    {M θ A : ℝ} (hM : 0 < M) (hθ : 0 < θ) (hA : 0 < A)
    (htotal : θ*M ≤ ∑ c, mass c)
    (hupper : ∀ c, mass c ≤ A*M/Fintype.card C)
    (B : I → ℝ) (hB : ∀ i, 0 < B i)
    (hbudget : ∀ i, (∑' d, ENNReal.ofReal (‖f i d‖^2)) ≤ ENNReal.ofReal (B i)) :
    ∃ c, θ*M/(2*Fintype.card C) ≤ mass c ∧
      ∀ i, ‖f i (label c)‖^2 <
        (2*A*((Fintype.card I : ℝ)+1)/(θ*Fintype.card C))*B i := by
  have hb : ∀ i, (∑ c, ‖f i (label c)‖^2) ≤ B i := by
    intro i
    apply real_energy_budget_of_ennreal (fun c => f i (label c)) (hB i).le
    rw [tsum_fintype]
    exact finite_subcollection_energy_budget label hinj _ (hbudget i)
  exact substantial_cell_with_energy_bounds mass (fun i c => ‖f i (label c)‖^2)
    (fun _ _ => sq_nonneg _) hM hθ hA htotal hupper B hB hb

end N2Restriction
#print axioms N2Restriction.substantial_cell_from_checked_budgets
