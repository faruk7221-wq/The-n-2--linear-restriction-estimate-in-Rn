import continuation.AtlasMassFeasibleCountsV45
namespace N2Restriction
open Set MeasureTheory
open scoped ENNReal
/-- Exhaustive cases for an actual selected atlas stage; no feasible-count
assumption is supplied by the caller. This classifies stages but does not yet
prove their terminal analytic estimates or assemble the descent. -/
theorem atlas_selected_stage_alternatives {k : ℕ} (S : Fin k → SmoothPatch (k+2))
    (T : (i : Fin k) → PacketGraphAtlas (S i))
    {ν κ : ℝ} (hgeo : GeometricHypotheses S ν κ) (hk : 3 ≤ k) :
    ∃ γ₀ : ℝ, 0 < γ₀ ∧ ∀ {r γ : ℝ}, γ ≤ γ₀ → (hr : 0 < r) →
      ∀ (Q : (i : Fin k) → (j : Fin (T i).size) →
        CoordinateCapFamily ((T i).patch j).support r)
      (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure)
      (A : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin (k+1) → ℤ))
      (Ω : Set (Ambient (k+2))) {p : ℝ}, 0 < p → critical k < p →
      ∀ (V : Submodule ℝ (Ambient (k+2))) (far : Finset (Fin k)),
      (∀ i, i ∉ far → ∀ j a ν, ν ∈ A i j a →
        directionPlaneAngle ((T i).cellAxisDirection j a.val) V ≤ 4*γ) →
      (∫⁻ x in Ω, ‖extensionProduct (fun _ => Measure.hausdorffMeasure ((k+1 : ℕ) : ℝ)) (fun _ => id)
        (fun i => (T i).cellInput (Q i) hr (f i) (A i)) x‖ₑ ^ p) = 0 ∨
      Module.finrank ℝ V = 0 ∨
      (1 ≤ Module.finrank ℝ V ∧ Module.finrank ℝ V ≤ k ∧ far.card = k - Module.finrank ℝ V) ∨
      cellular k (Module.finrank ℝ V) far.card p < 0 := by
  obtain ⟨γ₀, hγ₀, he⟩ := atlas_nonzero_mass_feasible_counts S T hgeo
  refine ⟨γ₀, hγ₀, ?_⟩
  intro r γ hγ hr Q f A Ω p hp hpcrit V far hnear
  by_cases hmass : (∫⁻ x in Ω, ‖extensionProduct (fun _ => Measure.hausdorffMeasure ((k+1 : ℕ) : ℝ)) (fun _ => id)
      (fun i => (T i).cellInput (Q i) hr (f i) (A i)) x‖ₑ ^ p) = 0
  · exact Or.inl hmass
  right
  have hdim : Module.finrank ℝ V ≤ k+2 := by
    simpa using Submodule.finrank_le V
  exact feasible_stage_cases hk hdim (he hγ hr Q f A Ω hp hmass V far hnear) hpcrit

end N2Restriction
#print axioms N2Restriction.atlas_selected_stage_alternatives
