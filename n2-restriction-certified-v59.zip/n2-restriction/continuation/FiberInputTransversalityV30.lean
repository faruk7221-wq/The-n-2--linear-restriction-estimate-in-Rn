import continuation.FiberInputGeometryV30
import continuation.ActualFiberTransversalityV26

namespace N2Restriction
open MeasureTheory Metric
open scoped NNReal ENNReal

/-- The actual normalized L2 inputs, not only the ambient coordinate charts,
have uniformly transverse thin-fiber normal spaces on essential support.
The positive constants precede every chart, frame, level and input. -/
theorem geometric_normalizedFiberInput_transversality {k : ℕ} (hk : 0 < k)
    (S : Fin k → SmoothPatch (k + 2)) {ν κ : ℝ} (hgeo : GeometricHypotheses S ν κ) :
    ∃ η a : ℝ, 0 < η ∧ 0 < a ∧
      ∀ (z : Fin k → Ambient (k + 2)), (∀ j, z j ∈ (S j).support) →
      ∀ i q, q ∈ orthonormalPairSet (k + 2) →
        ‖(commonTangent (fun j => (S j).normal (z j))).starProjection - pairProjection q‖ *
          ‖(S i).shape (z i)‖ ≤ κ / 2 →
      ∀ {δ r ρ s L α β ε : ℝ} {B : ℕ → ℝ} {c C : ℝ≥0}, ρ < r → s ≤ η →
      ∀ (F : ∀ j, MeasuredTubularChart (S j) (pairFrameMap q) (z j) δ r ρ s B c C L)
        (E : ChartNormalCoordinates (F i) α β)
        (g : Lp ℂ 2 ((Measure.hausdorffMeasure ((k + 2 : ℕ) - 1 : ℝ)).restrict (F i).carrier))
        (A : StripChartAmplitude (F i) E g ε) (u : ℝ × ℝ),
        ∀ᵐ v ∂volume, A.normalizedFiberInput u v ≠ 0 →
          ∀ y : Fin k → Ambient (k + 2),
            (F i).param (E.equiv.symm (u, v)) = y i →
            (∀ j, j ≠ i → y j ∈ (F j).carrier) →
            ∃ b : OrthonormalBasis (Fin 3) ℝ
              (LinearMap.range (fderiv ℝ
                (fun w => (F i).param (E.equiv.symm (u, w))) v).toLinearMap)ᗮ,
              a ≤ Matrix.det (Matrix.gram ℝ (Sum.elim
                (fun j : {j : Fin k // j ≠ i} => (S j).normal (y j))
                (fun j => (b j : Ambient (k + 2))))) := by
  obtain ⟨η, a, hη, ha, htrans⟩ := geometric_actual_fiber_normalized_bound hk S hgeo
  refine ⟨η, a, hη, ha, ?_⟩
  intro z hz i q hq hgap δ r ρ s L α β ε B c C hρ hs F E g A u
  filter_upwards [A.normalizedFiberInput_parameter_support u] with v hv hn
  have ht := hv hn
  have htr := closedBall_subset_closedBall hρ.le ht
  intro y hyi hy
  have hybuf : ∀ j, y j ∈ (S j).extendedSurface ∧ dist (y j) (z j) ≤ η := by
    intro j
    by_cases hji : j = i
    · subst j
      rw [← hyi]
      exact ⟨((F i).bounds _ htr).1, ((F i).image_buffer _ ht).trans hs⟩
    · obtain ⟨t, hyt, heq⟩ := hy j hji
      rw [← heq]
      exact ⟨((F j).bounds t (closedBall_subset_closedBall hρ.le hyt)).1,
        ((F j).image_buffer t hyt).trans hs⟩
  exact htrans z hz i q hq hgap y hybuf E.equiv (F i).normalCoord E.normal_eq
    (F i).param (ball 0 r) isOpen_ball (pairFrameMap q ((S i).normal (z i)))
    (fun t htt => ⟨((F i).bounds t (ball_subset_closedBall htt)).1,
      ((F i).bounds t (ball_subset_closedBall htt)).2.1⟩)
    u v (closedBall_subset_ball hρ ht) hyi
    (((F i).bounds _ htr).2.2.1.differentiableAt (by simp)) ((F i).bounds _ htr).2.2.2.1

end N2Restriction

#print axioms N2Restriction.geometric_normalizedFiberInput_transversality
