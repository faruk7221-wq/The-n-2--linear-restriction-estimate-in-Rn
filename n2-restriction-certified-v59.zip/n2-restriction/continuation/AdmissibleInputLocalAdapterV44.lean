import continuation.FixedMarginSurfaceClassV44

namespace N2Restriction
open MeasureTheory Set
open scoped ENNReal

/-- Start from arbitrary admissible inputs on one fixed surface class, construct
their actual chart inputs, and estimate every original-packet selection using
the SAME class at child scale. The radius threshold precedes the inputs. -/
theorem eventually_admissible_input_cell_local {d k : ℕ}
    (W : Fin k → SmoothPatch (d + 1)) (T : (i : Fin k) → PacketGraphAtlas (W i))
    (V : Fin k → Set (Ambient (d + 1))) (m : ℝ)
    (hW : ∀ i, (W i).extendedSurface ∩ V i ⊆ (W i).support) :
    ∀ᶠ R : ℝ in Filter.atTop,
      ∀ g : (i : Fin k) → Lp ℂ 2 (W i).surfaceMeasure,
      MarginAdmissible (fun i => (W i).surfaceMeasure) (fun _ => id) V m R (fun i => g i) →
      ∃ f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure,
      (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) ∧
      (∀ i j, HasFrequencySupport ((T i).graph j).surfaceMeasure id
        (((T i).graph j).parametrization '' ((T i).patch j).support) (f i j)) ∧
      (∀ i x, (∑ j, extension ((T i).graph j).surfaceMeasure ((T i).patch j).rotation (f i j) x) =
        extension (W i).surfaceMeasure id (g i) x) ∧
      ∀ (L : ℝ), 1 ≤ L → L ≤ R / 2 → 0 < m - L ^ (-1 / 4 : ℝ) →
      ∀ (Q : (i : Fin k) → (j : Fin (T i).size) →
        CoordinateCapFamily ((T i).patch j).support (R ^ (-1 / 2 : ℝ)))
      (hr : 0 < R ^ (-1 / 2 : ℝ)), (∀ i, R ^ (-1 / 2 : ℝ) ≤ (T i).capRadius) →
      ∀ (A : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ))
      (p : ℝ), 0 < p → ∀ x₀ : Ambient (d + 1),
      (∫⁻ x in Metric.ball x₀ L,
        ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
          (fun i => (T i).cellInput (Q i) hr (f i) (A i)) x‖ₑ ^ p) ≤
        (marginLocalConstant (fun i => (W i).surfaceMeasure) (fun _ => id) V m p L *
          ∏ i, ENNReal.ofReal ‖(T i).cellInput (Q i) hr (f i) (A i)‖)^p := by
  filter_upwards [eventually_atlas_common_class_local W W T V m hW] with R hR
  intro g hg
  choose f he hs hm hx using fun i => (T i).input_decomposition_supported (g i) _ (hg i)
  refine ⟨f, he, hs, hx, ?_⟩
  intro L hL hLR hpos Q hr hsmall A p hp x₀
  exact hR L hL hLR hpos Q hr hsmall f hm A p hp x₀

end N2Restriction
#print axioms N2Restriction.eventually_admissible_input_cell_local
