import N2Restriction.ExtensionRegularity
import N2Restriction.LocalConstant
import Mathlib.Analysis.SpecialFunctions.Exp

namespace N2Restriction
open MeasureTheory
open scoped NNReal ENNReal

/-- A uniform real-phase exponential bound, sufficient for quantitative
stability without assuming the phase difference is small. -/
theorem imaginary_exp_difference_bound (a b : ℝ) :
    ‖Complex.exp ((a : ℂ) * Complex.I) - Complex.exp ((b : ℂ) * Complex.I)‖ ≤ 2 * |a - b| := by
  have hd : ‖(a : ℂ) * Complex.I - (b : ℂ) * Complex.I‖ = |a - b| := by
    rw [← sub_mul, ← Complex.ofReal_sub, norm_mul, Complex.norm_I, mul_one, Complex.norm_real, Real.norm_eq_abs]
  by_cases h : |a - b| < 1
  · have hh := Complex.locally_lipschitz_exp (r := 1) (by norm_num) le_rfl
      ((b : ℂ) * Complex.I) ((a : ℂ) * Complex.I) (by rwa [hd])
    norm_num [hd] at hh
    exact hh
  · have hh := norm_sub_le (Complex.exp ((a : ℂ) * Complex.I)) (Complex.exp ((b : ℂ) * Complex.I))
    simp only [Complex.norm_exp_ofReal_mul_I] at hh
    linarith

/-- Moving a frequency point by a changes its phase by at most 2*norm(x)*a. -/
theorem extension_phase_difference_bound {n : ℕ} (x y z : Ambient n) :
    ‖Complex.exp ((inner ℝ x y : ℂ) * Complex.I) -
      Complex.exp ((inner ℝ x z : ℂ) * Complex.I)‖ ≤ 2 * ‖x‖ * dist y z := by
  have hh := imaginary_exp_difference_bound (inner ℝ x y) (inner ℝ x z)
  rw [← inner_sub_right] at hh
  exact hh.trans (by simpa only [Real.norm_eq_abs, dist_eq_norm, mul_assoc] using
    mul_le_mul_of_nonneg_left (norm_inner_le_norm (𝕜 := ℝ) x (y-z)) (by norm_num : (0 : ℝ) ≤ 2))

/-- Quantitative stability under an a.e. perturbation of the frequency
parametrization, on the actual same L2 input. The finite frequency-mass cost
is explicit; this is a pointwise bound, not localized restriction stability. -/
theorem extension_parametrization_difference {Ω : Type*} [MeasurableSpace Ω] {n : ℕ}
    (μ : Measure Ω) [IsFiniteMeasure μ] (ζ ξ : Ω → Ambient n)
    (hζ : Measurable ζ) (hξ : Measurable ξ) (g : Lp ℂ 2 μ) {a : ℝ}
    (hclose : ∀ᵐ ω ∂μ, g ω ≠ 0 → dist (ζ ω) (ξ ω) ≤ a) (x : Ambient n) :
    ‖extension μ ζ g x - extension μ ξ g x‖ₑ ≤
      ENNReal.ofReal (2 * ‖x‖ * a) * (‖g‖ₑ * (μ Set.univ) ^ (1 / 2 : ℝ)) := by
  have hi := (Lp.memLp g).integrable (by norm_num : (1 : ℝ≥0∞) ≤ 2)
  have hiz := integrable_extension_kernel hζ hi x
  have hix := integrable_extension_kernel hξ hi x
  unfold extension
  rw [← integral_sub hiz hix]
  refine (enorm_integral_le_lintegral_enorm _).trans ?_
  have hpoint : ∀ᵐ ω ∂μ,
      ‖Complex.exp ((inner ℝ x (ζ ω) : ℂ) * Complex.I) * g ω -
        Complex.exp ((inner ℝ x (ξ ω) : ℂ) * Complex.I) * g ω‖ₑ ≤
        ENNReal.ofReal (2 * ‖x‖ * a) * ‖g ω‖ₑ := by
    filter_upwards [hclose] with ω hω
    by_cases hg : g ω = 0
    · simp [hg]
    · rw [← sub_mul, enorm_mul]
      apply mul_le_mul_right'
      rw [← ofReal_norm_eq_enorm]
      apply ENNReal.ofReal_le_ofReal
      exact (extension_phase_difference_bound x (ζ ω) (ξ ω)).trans
        (mul_le_mul_of_nonneg_left (hω hg) (by positivity))
  refine (lintegral_mono_ae hpoint).trans ?_
  rw [lintegral_const_mul' _ _ ENNReal.ofReal_ne_top]
  apply mul_le_mul_left'
  have hh := eLpNorm_le_eLpNorm_mul_rpow_measure_univ
    (show (1 : ℝ≥0∞) ≤ 2 by norm_num) (Lp.memLp g).aestronglyMeasurable
  norm_num [eLpNorm_one_eq_lintegral_enorm, ← Lp.enorm_def] at hh
  exact hh

end N2Restriction

#print axioms N2Restriction.extension_parametrization_difference
#print axioms N2Restriction.extension_phase_difference_bound
#print axioms N2Restriction.imaginary_exp_difference_bound
