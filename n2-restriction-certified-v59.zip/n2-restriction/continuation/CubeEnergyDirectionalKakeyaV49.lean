import continuation.DilatedKakeyaGridV22
import continuation.CellKakeyaEnergyV49
namespace N2Restriction
open MeasureTheory Set
open scoped ENNReal BigOperators

/-- The common cube energies used by the actual tangent sum obey the borrowed
finite directional Kakeya estimate, with every dilation displayed. -/
theorem directional_cubeEnergy_grid_kakeya {d : ℕ} {I : Type} [Fintype I]
    {S : I → SmoothPatch (d + 1)} {ε : ℝ} (Dsub : ∀ i, DirectionalSubdivision (S i) ε)
    (a : ∀ i, Fin (Dsub i).size) (T : ∀ i, PacketGraphAtlas ((Dsub i).piece (a i)))
    {r : ℝ} (Q : (i : I) → (j : Fin (T i).size) → CoordinateCapFamily ((T i).patch j).support r)
    (hr : 0 < r) (f : (i : I) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure)
    {R w C D b α β Cext η p : ℝ}
    (hR : 0 ≤ R) (hb : 0 < b) (hC : 0 ≤ C) (hw : w ≤ D * b) (hp : 0 ≤ p)
    (hα : 0 ≤ α) (hβ : 0 ≤ β)
    (hwidth : β = D + Real.sqrt ((d + 1 : ℕ) : ℝ) * (1 + C) / 2)
    (hball : R + Real.sqrt ((d + 1 : ℕ) : ℝ) * b < α * R)
    (E : I → ℝ≥0∞) (hE : ∀ i, (∑' t, (T i).kakeyaWeight (Q i) hr (f i) t) ≤ E i)
    (hK : FiniteDirectionalKakeya (volume.restrict (Metric.ball 0 (α * R)))
      (fun i => (S i).normal ((Dsub i).anchor (a i))) ε (β * b) p
      (ENNReal.ofReal (Cext * (α * R) ^ η * (β * b) ^ (((d + 1 : ℕ) : ℝ) - η)))) :
    (∑' z : meetingGrid (n := d + 1) b R,
      (∏ i, (T i).cubeEnergy (Q i) hr (f i) R w C b (gridCentre b z)) ^ p) ≤
      ENNReal.ofReal (Cext * α ^ η * β ^ (((d + 1 : ℕ) : ℝ) - η) * (R / b) ^ η) *
        (∏ i, E i) ^ p := by
  simpa only [PacketGraphAtlas.cubeEnergy] using
    directional_packet_grid_dilated_kakeya Dsub a T Q hr f hR hb hC hw hp hα hβ hwidth hball E hE hK

end N2Restriction
#print axioms N2Restriction.directional_cubeEnergy_grid_kakeya
