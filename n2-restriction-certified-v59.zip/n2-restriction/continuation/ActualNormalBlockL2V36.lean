import continuation.ThinNormalBlockCoordinatesV36
import continuation.UniformDependentBlockL2V36

namespace N2Restriction
open MeasureTheory
open scoped ENNReal BigOperators

/-- The flat mixed-block L2 estimate instantiated on the article's actual
normal configuration, with its constant before the geometric data and inputs. -/
theorem uniform_actual_normal_block_L2 {n : ℕ} (i : Fin (n+2))
    (M c : ℝ) (hM : 0 ≤ M) (hc : 0 < c) :
    ∃ K : ℝ≥0∞, 0 < K ∧ K ≠ ⊤ ∧ ∀ (S : Fin (n+2) → SmoothPatch (n+4))
      (z : Fin (n+2) → Ambient (n+4)) (q : Ambient (n+4) × Ambient (n+4))
      (N : Submodule ℝ (Ambient (n+4))) (_b : OrthonormalBasis (Fin 3) ℝ N),
      (∀ j, ‖(S j).normal (z j)‖ = 1) → ‖(S i).shape (z i)‖ ≤ M →
      ‖q.1‖ ≤ 1 → ‖q.2‖ ≤ 1 →
      (S i).normal (z i) ∈ N → (S i).shape (z i) q.1 ∈ N →
      (S i).shape (z i) q.2 ∈ N →
      c ≤ Matrix.det (Matrix.gram ℝ (nearbyWedgeVectors S z i q)) →
      ∃ e : Ambient (n+4) ≃L[ℝ] (∀ j, Ambient (normalBlockDimensions n j)),
        NormalBlockKernels S z i N e ∧ ∀
      (f : ∀ j : Fin (n+2), Lp ℂ 2 (Measure.pi (fun t =>
        (volume : Measure (Ambient (normalBlockDimensions n (j.succAbove t))))))),
      eLpNorm' (fun x => dependentBlockProduct n
        (fun j => Ambient (normalBlockDimensions n j)) (fun _ => volume) f (e x))
        (2/((n:ℝ)+1)) volume ≤ K * ∏ j, ‖f j‖ₑ := by
  obtain ⟨B,hB,hcoord⟩ := uniform_thin_normal_block_coordinates i M c hM hc
  obtain ⟨K,hK,hfin,hbound⟩ := uniform_linear_dependent_block_L2 (n+4) n (normalBlockDimensions n) B hB.le
  refine ⟨K,hK,hfin,?_⟩
  intro S z q N b hunit hshape hq₁ hq₂ hN hA₁ hA₂ hG
  obtain ⟨e,he,hei,hker⟩ := hcoord S z q N b hunit hshape hq₁ hq₂ hN hA₁ hA₂ hG
  exact ⟨e,hker,hbound e he hei⟩

end N2Restriction

#print axioms N2Restriction.uniform_actual_normal_block_L2
