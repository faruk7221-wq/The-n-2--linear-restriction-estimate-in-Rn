import continuation.CellRapidErrorV43
import continuation.AtlasTrimmedCellMassV43

namespace N2Restriction
open MeasureTheory Set
open scoped BigOperators ENNReal

/-- Normalize the exact atlas product-error term, including the original
input norm product. All geometric and packet-count constants are retained. -/
theorem atlas_product_rapid_error {d k : ℕ} {R p C B M : ℝ}
    (hR : 0 < R) (hp : 0 < p) (hC : 0 ≤ C) (_hB : 0 ≤ B) (hM : 0 ≤ M)
    (J : ℝ) (g : Fin k → ℝ) (hg : ∀ i, 0 ≤ g i)
    (Δ : Set (Ambient (d+1))) (hΔ : Δ ⊆ Metric.closedBall 0 R) :
    (ENNReal.ofReal ((k : ℝ)*(C*Real.sqrt B*R^(-((J+(d+1 : ℕ))/p)))*M^k*∏ i, g i))^p * volume Δ ≤
      (volume (Metric.ball (0 : Ambient (d+1)) 1) *
        (ENNReal.ofReal ((k : ℝ)*C*Real.sqrt B*M^k))^p) *
        ENNReal.ofReal (R^(-J)) * (∏ i, ENNReal.ofReal (g i))^p := by
  have hcoeff : 0 ≤ (k : ℝ)*C*Real.sqrt B*M^k := by positivity
  have hid : (k : ℝ)*(C*Real.sqrt B*R^(-((J+(d+1 : ℕ))/p)))*M^k*∏ i, g i =
      ((k : ℝ)*C*Real.sqrt B*M^k) * R^(-((J+(d+1 : ℕ))/p)) * (∏ i, g i) := by ring
  rw [hid, ENNReal.ofReal_mul (mul_nonneg hcoeff (Real.rpow_nonneg hR.le _)),
    ENNReal.ofReal_mul hcoeff, ENNReal.ofReal_prod_of_nonneg (fun i _ => hg i)]
  exact cell_rapid_error_normalization hR hp J _ _ Δ hΔ

end N2Restriction
#print axioms N2Restriction.atlas_product_rapid_error
