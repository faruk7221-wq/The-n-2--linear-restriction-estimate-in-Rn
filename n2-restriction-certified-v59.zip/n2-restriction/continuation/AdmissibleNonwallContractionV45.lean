import continuation.ConstructedCapsNonwallV45
import continuation.NonwallDegreeChoiceV43
set_option maxHeartbeats 1600000
namespace N2Restriction
open MeasureTheory Set
open scoped BigOperators ENNReal
/-- The actual same-class non-wall branch with a fixed covering and an integer degree
chosen before the radius and partition. Its leading coefficient is any prescribed c.
The nonterminal dimension/count and retained partition geometry remain premises. -/
theorem admissible_nonwall_contraction {d k : ℕ} (S : Fin k → SmoothPatch (d+1))
    (T : (i : Fin k) → PacketGraphAtlas (S i))
    (Vfreq : Fin k → Set (Ambient (d+1))) (m : ℝ) (hmpos : 0 < m)
    (hW : ∀ i, (S i).extendedSurface ∩ Vfreq i ⊆ (S i).support) {τ : ℝ} (hτ : 0 < τ)
    {s t Hgeom : ℕ} {p c θ E c₀ c₁ Kgeom : ℝ} (K : ENNReal)
    (hk : 3 ≤ k) (hs : 1 ≤ s) (hsmax : s ≤ k+2) (hst : k+1 ≤ s+t)
    (hpcrit : critical k < p) (hp : 0 < p) (hp1 : p ≤ 1) (hc : 0 < c)
    (hθ : 0 < θ) (hE : 0 < E) (hc₀ : 0 < c₀) (hKg : 0 ≤ Kgeom) (hK : K ≠ ⊤) :
    ∃ B : ℝ, 0 ≤ B ∧ ∃ B₀ : Fin k → ℝ, (∀ i, 1 ≤ B₀ i) ∧
    ∃ D : ℕ, 1 ≤ D ∧ ∃ M : ℝ, 1 ≤ M ∧ ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ J : ℝ, ∃ C : ℝ, 0 ≤ C ∧
    ∀ R : ℝ, R₀ ≤ R →
    ∃ Q : (i : Fin k) → (j : Fin (T i).size) →
      CoordinateCapFamily ((T i).patch j).support (R^(-1/2 : ℝ)),
    (∀ i, R^(-1/2 : ℝ) ≤ (T i).capRadius) ∧
    (∀ i j, ((Q i j).centers.card : ℝ) ≤ B*R^((d : ℝ)/2)) ∧
    ∀ (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure),
    MarginAdmissible (fun i => (S i).surfaceMeasure) (fun _ => id) Vfreq m R (fun i => g i) →
    ∃ f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure,
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) ∧
    (∀ i j, HasFrequencySupport ((T i).graph j).surfaceMeasure id
      (((T i).graph j).parametrization '' ((T i).patch j).support) (f i j)) ∧
    (∀ i x, (∑ j, extension ((T i).graph j).surfaceMeasure ((T i).patch j).rotation (f i j) x) =
      extension (S i).surfaceMeasure id (g i) x) ∧
    ∀ (hr : 0 < R^(-1/2 : ℝ)),
    ∀ (A : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ))
      (Ω : Set (Ambient (d+1))), Ω ⊆ Metric.closedBall 0 R →
    let ρ := partitionDensity (fun _ => Measure.hausdorffMeasure (d : ℝ))
      (fun i => (T i).cellInput (Q i) hr (f i) (A i)) Ω p
    ∀ {l u : ℕ} (P : Fin l → MvPolynomial (Fin (d+1)) ℝ)
      (Z : Fin u → MvPolynomial (Fin (d+1)) ℝ) (cuts : Set (Ambient (d+1)))
      (V : Submodule ℝ (Ambient (d+1))) {γ b : ℝ},
    AlgebraicTubeCoverInput {x | polynomialLevelMap Z x = 0}
      (fun z => LinearMap.ker (fderiv ℝ (polynomialLevelMap Z) z).toLinearMap) γ Hgeom Kgeom →
    0 < b → R^(1/2+τ)/10 < b →
    Ω ⊆ Metric.thickening b (planeWitnessSet Z cuts V (2*γ)) →
    ∀ (far : Finset (Fin k)), far.card = t →
    (∀ i ∈ far, ∀ j a ν, ν ∈ A i j a →
      4*γ < directionPlaneAngle ((T i).cellAxisDirection j a.val) V) →
    ∀ {Cells : Type*} [Fintype Cells] [Nonempty Cells]
      (label : Cells → (Fin l → Bool)), Function.Injective label →
    ∀ (Δ : Cells → Set (Ambient (d+1))), (∀ c, MeasurableSet (Δ c)) →
    (∀ c, Δ c ⊆ Ω) → (∀ c, Δ c ⊆ PolynomialSignRegion P (label c)) →
    (∀ c x, x ∈ Δ c → ∀ z, ambientPolynomial (∏ l, P l) z = 0 → b ≤ dist x z) →
    θ*(ρ univ).toReal ≤ ∑ c, (ρ (Δ c)).toReal →
    (∀ c, (ρ (Δ c)).toReal ≤ E*(ρ univ).toReal/Fintype.card Cells) →
    c₀*(D : ℝ)^(s : ℝ) ≤ Fintype.card Cells → (Fintype.card Cells : ℝ) ≤ c₁*(D : ℝ)^(s : ℝ) →
    ((∏ l, P l).totalDegree : ℝ) ≤ (D : ℝ) →
    ∀ M₀ err : ENNReal, M₀ ≤ K*ρ univ+err →
    M₀ ≤ ENNReal.ofReal c *
      (marginLocalConstant (fun i => (S i).surfaceMeasure) (fun _ => id)
        (fun i => Vfreq i) m p (R/2))^p *
      (∏ i, ENNReal.ofReal ‖g i‖)^p +
      (K*ENNReal.ofReal (2*c₁/θ)*ENNReal.ofReal ((D : ℝ)^(s : ℝ))*
        ((volume (Metric.ball (0 : Ambient (d+1)) 1) *
          (ENNReal.ofReal ((k : ℝ)*C*Real.sqrt B*M^k))^p) *
          ENNReal.ofReal (R^(-J)) * (∏ i, ENNReal.ofReal ‖g i‖)^p)+err) := by
  classical
  obtain ⟨q, hq⟩ := uniform_half_ball_cover (d+1)
  obtain ⟨B, hB, B₀, hB₀, M, hM, R₀, hR₀, ht⟩ :=
    admissible_nonwall_with_constructed_caps S T Vfreq m hmpos hW hτ
  let Ec : Fin k → ℝ := fun i => ((2*E*((k : ℝ)+1)/θ)/c₀ * B₀ i *
    max 2 (max 1 ((Hgeom : ℝ)*(Kgeom+2)^(d+1))))
  obtain ⟨D, hD, hd⟩ := nonwall_contracting_degree hk hs hsmax hst hpcrit hc
    K (ENNReal.ofReal (2*c₁/θ)) (q.card : ENNReal) hK ENNReal.ofReal_ne_top (by simp) Ec
  refine ⟨B, hB, B₀, hB₀, D, hD, M, hM, R₀, hR₀, ?_⟩
  intro J
  obtain ⟨C, hC, hCbound⟩ := ht p hp hp1 J
  refine ⟨C, hC, ?_⟩
  intro R hR
  obtain ⟨Q, hsmall, hcount, hinputs⟩ := hCbound R hR
  refine ⟨Q, hsmall, hcount, ?_⟩
  intro g hg
  obtain ⟨f, he, hsup, hx, hb⟩ := hinputs g hg
  refine ⟨f, he, hsup, hx, ?_⟩
  intro hr A Ω hΩ
  dsimp only
  intro l u P Z cuts V γ b htube hbpos hwall hnear far hfarcard hfar
    Cells inst instN label hlabel Δ hΔ hΔΩ hsign htrim hret hmass hlow hhigh hdeg M₀ err hstage
  have hDreal : (1 : ℝ) ≤ D := by exact_mod_cast hD
  have hRpos : 0 < R := lt_of_lt_of_le zero_lt_one (hR₀.trans hR)
  have hbound := hb hr A Ω hΩ P Z cuts V hKg htube hbpos hwall hnear far hfar
    label hlabel Δ hΔ hΔΩ hsign htrim hθ hE hDreal hc₀ hret hmass hlow hhigh hdeg q (hq R hRpos) K M₀ err hstage
  dsimp only at hbound
  rw [hfarcard] at hbound
  exact hbound.trans (add_le_add_right
    (mul_le_mul_right' (mul_le_mul_right' hd.le _) _) _)

end N2Restriction
#print axioms N2Restriction.admissible_nonwall_contraction
