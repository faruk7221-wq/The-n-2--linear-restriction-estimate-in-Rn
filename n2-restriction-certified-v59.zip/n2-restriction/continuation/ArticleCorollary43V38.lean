import continuation.AssumedLocalizedInputV38
import continuation.GeometricMeasuredAtlasV28

set_option maxHeartbeats 1600000
namespace N2Restriction
open MeasureTheory Metric Set
open scoped NNReal ENNReal BigOperators

/-- The nearby-plane condition in Lemma 4.1 supplies the admissible-frame
condition used by the uniform atlas. -/
theorem article_frame_of_geometric_gap {k : ℕ}
    (S : Fin k → SmoothPatch (k+2)) {ν κ : ℝ} (hgeo : GeometricHypotheses S ν κ)
    (hne : ∀ i, (S i).support.Nonempty)
    (q : Ambient (k+2) × Ambient (k+2)) (hq : q ∈ orthonormalPairSet (k+2))
    (hgap : ∀ w : Fin k → Ambient (k+2), (∀ i, w i ∈ (S i).support) → ∀ i,
      ‖(commonTangent (fun j => (S j).normal (w j))).starProjection - pairProjection q‖ *
        ‖(S i).shape (w i)‖ ≤ κ/2) :
    ∀ i x, x ∈ (S i).support →
      (pairFrameMap q,x) ∈ frameFrequencyAdmissibleImage (S i) κ := by
  classical
  choose w hw using hne
  intro i x hx
  let w' := Function.update w i x
  have hw' : ∀ j, w' j ∈ (S j).support := by
    intro j
    by_cases hji : j = i
    · subst j; simpa [w'] using hx
    · simpa [w', Function.update_of_ne hji] using hw j
  simpa [w'] using geometric_pairFrame_admissible S hgeo w' hw' i q hq (hgap w' hw' i)

namespace ArticleLocalizationAtlas
variable {k : ℕ} {S : Fin k → SmoothPatch (k+2)} {κ : ℝ}

/-- The article's C*mu strip convention with a threshold chosen before
planes, scales and inputs. The conclusion has exactly the linear mu gain.
The only analytic premise is the explicitly supplied localized chart input. -/
theorem corollary43_small_width (A : ArticleLocalizationAtlas S κ)
    {p ε : ℝ} (hp : 0 < p) (hε : 0 < ε)
    (hexternal : A.UniformLocalizedInput p) (c : ℝ≥0) (hc : 0 < c) :
    ∃ μ₀ : ℝ, 0 < μ₀ ∧ ∃ C : ℝ≥0,
      ∀ (q : ArticleFrame S κ) (i₀ : Fin k) (μ : ℝ≥0) (R : ℝ) (x₀ : Ambient (k+2)),
      0 < μ → (μ : ℝ) < μ₀ → 1 ≤ R →
      ∀ g : ∀ i, Lp ℂ 2 (S i).surfaceMeasure,
      HasFrequencySupport (S i₀).surfaceMeasure id
        {x | ‖(pairPlane q.val).orthogonalProjection ((S i₀).normal x)‖ ≤ (c : ℝ)*μ} (g i₀) →
      eLpNorm' (fun x => ∏ i, extension (S i).surfaceMeasure id (g i) x) p
        (volume.restrict (ball x₀ R)) ≤
          ((C : ℝ≥0∞) * ENNReal.ofReal (R ^ ε) * (μ : ℝ≥0∞)) * ∏ i, ‖g i‖ₑ := by
  obtain ⟨C,hC⟩ := A.strip_bound_of_external_input hp hε hexternal
  let μ₀ := min (A.threshold / c) (1 / (2 * (A.distanceCost : ℝ) * c))
  have hcR : 0 < (c : ℝ) := hc
  have hDR : 0 < (A.distanceCost : ℝ) := A.distanceCost_pos
  have hμ₀ : 0 < μ₀ := lt_min (div_pos A.threshold_pos hcR) (by positivity)
  refine ⟨μ₀,hμ₀,C*c,?_⟩
  intro q i₀ μ R x₀ hμ hsmall hR g hg
  have h₁ : (c : ℝ)*(μ : ℝ) ≤ A.threshold := by
    have hh := hsmall.trans_le (min_le_left _ _)
    have hh' := (lt_div_iff₀ hcR).mp hh
    nlinarith
  have h₂ : (A.distanceCost : ℝ) * ((c*μ : ℝ≥0) : ℝ) < 1 := by
    have hh := hsmall.trans_le (min_le_right _ _)
    have hh' := (lt_div_iff₀ (show 0 < 2*(A.distanceCost : ℝ)*c by positivity)).mp hh
    simp only [NNReal.coe_mul]
    nlinarith [mul_nonneg (le_of_lt hDR) (mul_nonneg c.coe_nonneg μ.coe_nonneg)]
  have hh := hC q i₀ (c*μ) R x₀ (mul_pos hc hμ) h₁ h₂ hR g hg
  simpa only [ENNReal.coe_mul, mul_assoc, mul_left_comm, mul_comm] using hh

/-- The integral version has gain mu^p, not mu. This remains valid for
0<p<1 and uses powers of the quasi-norm, without Minkowski. -/
theorem localized_integral_gain {n k : ℕ} (μS : Fin k → Measure (Ambient n))
    (g : ∀ i, Lp ℂ 2 (μS i)) (σ : Measure (Ambient n)) {p : ℝ} (hp : 0 < p)
    (C w : ℝ≥0∞)
    (h : eLpNorm' (fun x => ∏ i, extension (μS i) id (g i) x) p σ ≤
      (C*w) * ∏ i, ‖g i‖ₑ) :
    (∫⁻ x, ‖∏ i, extension (μS i) id (g i) x‖ₑ ^ p ∂σ) ≤
      (C^p*w^p) * ∏ i, ‖g i‖ₑ ^ p := by
  have hh := ENNReal.rpow_le_rpow h hp.le
  simpa only [eLpNorm'_eq_lintegral_enorm, ← ENNReal.rpow_mul,
    one_div_mul_cancel hp.ne', ENNReal.rpow_one,
    ENNReal.mul_rpow_of_nonneg _ _ hp.le, ENNReal.prod_rpow_of_nonneg hp.le] using hh

end ArticleLocalizationAtlas
end N2Restriction

#print axioms N2Restriction.article_frame_of_geometric_gap
#print axioms N2Restriction.ArticleLocalizationAtlas.corollary43_small_width
#print axioms N2Restriction.ArticleLocalizationAtlas.localized_integral_gain
