import continuation.AtlasPacketNormalStripV46
import continuation.NormalCapScaleV46

namespace N2Restriction
open Set MeasureTheory Filter

/-- The actual original-packet selection lies in a strip of width twice
the article's tangent angle. The threshold is independent of the selected
plane, cap family, input, and packet subfamily. -/
theorem PacketGraphAtlas.eventually_selected_tangent_strip {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) {τ lam : ℝ} (hτ : 0 < τ) (hlam : 0 < lam) :
    ∀ᶠ R : ℝ in atTop,
      ∀ (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support (R ^ (-1/2 : ℝ)))
      (hr : 0 < R ^ (-1/2 : ℝ))
      (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
      (H : Submodule ℝ (Ambient (d+1)))
      (U : (j : Fin T.size) → (Q j).centers → Set (Fin d → ℤ)),
      (∀ j c, (U j c).Nonempty → ‖H.starProjection (T.cellAxisDirection j c)‖ ≤
        lam * R ^ (-1/2 + 2*τ)) →
      HasFrequencySupport (Measure.hausdorffMeasure (d : ℝ)) id
        (normalStrip S H (2 * (lam * R ^ (-1/2 + 2*τ)))) (T.cellInput Q hr f U) := by
  obtain ⟨η,hη,M,hM⟩ := T.selected_normal_strip
  have hcap (j : Fin T.size) := eventually_power_small (a := (1/2 : ℝ))
    (by norm_num) hη (2*(1 + ((T.graph j).lipConstant : ℝ)))
  have herr (j : Fin T.size) := eventually_cap_normal_error
    ((M : ℝ)*(2*(1 + ((T.graph j).lipConstant : ℝ)))) hτ hlam
  filter_upwards [Filter.eventually_all.mpr hcap, Filter.eventually_all.mpr herr] with R hc he
  intro Q hr f H U haxis
  apply hM _ Q hr f H (lam * R ^ (-1/2 + 2*τ)) _ U
  · intro j
    nlinarith only [hc j]
  · intro j
    nlinarith only [he j]
  · exact haxis

/-- Witness-tangent angular control suffices for the plane in (7.6).
This statement keeps the geometric witness premise visible. -/
theorem PacketGraphAtlas.eventually_selected_witness_strip {d : ℕ} {S : SmoothPatch (d+1)}
    (T : PacketGraphAtlas S) {τ lam : ℝ} (hτ : 0 < τ) (hlam : 0 < lam) :
    ∀ᶠ R : ℝ in atTop,
      ∀ (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support (R ^ (-1/2 : ℝ)))
      (hr : 0 < R ^ (-1/2 : ℝ))
      (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
      (V F : Submodule ℝ (Ambient (d+1)))
      (U : (j : Fin T.size) → (Q j).centers → Set (Fin d → ℤ)),
      (∀ j c, (U j c).Nonempty →
        ‖V.starProjection (T.cellAxisDirection j c) - T.cellAxisDirection j c‖ ≤
          lam * R ^ (-1/2 + 2*τ)) →
      HasFrequencySupport (Measure.hausdorffMeasure (d : ℝ)) id
        (normalStrip S (V ⊔ F)ᗮ (2 * (lam * R ^ (-1/2 + 2*τ)))) (T.cellInput Q hr f U) := by
  filter_upwards [T.eventually_selected_tangent_strip hτ hlam] with R hR
  intro Q hr f V F U hangle
  apply hR Q hr f (V ⊔ F)ᗮ U
  intro j c hc
  exact (projection_le_tangent_deviation _ V (Submodule.orthogonal_le le_sup_left) _).trans
    (hangle j c hc)

end N2Restriction
#print axioms N2Restriction.PacketGraphAtlas.eventually_selected_tangent_strip
#print axioms N2Restriction.PacketGraphAtlas.eventually_selected_witness_strip
