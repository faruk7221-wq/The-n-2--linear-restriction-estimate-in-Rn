import continuation.ActualMulticapCellBudgetV41
import N2Restriction.CoordinatePacketFamily

namespace N2Restriction
open MeasureTheory
open scoped BigOperators ENNReal

/-- For constructed coordinate caps, the overlap and cap-input energy
bounds are proved internally. Cell incidence is the only remaining input
to the original-input squared-norm budget. -/
theorem CoordinateCapFamily.cell_energy_budget {d : ℕ} {C : Type*}
    {K : Set (Ambient d)} {r : ℝ} (P : CoordinateCapFamily K r) (hr : 0 < r)
    (f : Lp ℂ 2 (volume : Measure (Ambient d)))
    (S : C → P.centers → Set (Fin d → ℤ)) (N : ENNReal)
    (hincidence : ∀ j ν, (∑' c, (S c j).indicator (fun _ => (1 : ENNReal)) ν) ≤ N) :
    (∑' c, ENNReal.ofReal (‖∑ j, ∑' ν : S c j, P.packet hr f j ν.val‖^2)) ≤
      ENNReal.ofReal (9^d : ℝ) * N * ENNReal.ofReal (‖f‖^2) := by
  have he : (∑ j, ENNReal.ofReal (‖P.input hr f j‖^2)) ≤ ENNReal.ofReal (‖f‖^2) := by
    rw [← ENNReal.ofReal_sum_of_nonneg (fun j _ => sq_nonneg _)]
    exact ENNReal.ofReal_le_ofReal (P.input_energy hr f)
  exact actual_multicap_cell_budget (fun j : P.centers => j.val) r hr (P.input hr f) S
    (by positivity) (Filter.Eventually.of_forall P.overlap) N _ hincidence he

end N2Restriction
#print axioms N2Restriction.CoordinateCapFamily.cell_energy_budget
