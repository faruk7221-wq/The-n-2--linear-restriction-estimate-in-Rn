import N2Restriction.Translation
import N2Restriction.RestrictedInput

namespace N2Restriction
open MeasureTheory
open scoped ENNReal NNReal

/-- Modulation as an actual L2 equivalence class. -/
noncomputable def modulateL2 {Ω : Type*} [MeasurableSpace Ω] {n : ℕ}
    (μ : Measure Ω) (ζ : Ω → Ambient n) (hζ : Measurable ζ)
    (y : Ambient n) (g : Lp ℂ 2 μ) : Lp ℂ 2 μ :=
  (memLp_modulate hζ (Lp.memLp g) y).toLp (modulate ζ y g)

theorem modulateL2_coe {Ω : Type*} [MeasurableSpace Ω] {n : ℕ}
    (μ : Measure Ω) (ζ : Ω → Ambient n) (hζ : Measurable ζ) (y : Ambient n) (g : Lp ℂ 2 μ) :
    (modulateL2 μ ζ hζ y g : Ω → ℂ) =ᵐ[μ] modulate ζ y g := MemLp.coeFn_toLp _

theorem modulateL2_enorm {Ω : Type*} [MeasurableSpace Ω] {n : ℕ}
    (μ : Measure Ω) (ζ : Ω → Ambient n) (hζ : Measurable ζ) (y : Ambient n) (g : Lp ℂ 2 μ) :
    ‖modulateL2 μ ζ hζ y g‖ₑ = ‖g‖ₑ := by
  rw [Lp.enorm_def, eLpNorm_congr_ae (modulateL2_coe μ ζ hζ y g), eLpNorm_modulate, ← Lp.enorm_def]

theorem modulateL2_support {Ω : Type*} [MeasurableSpace Ω] {n : ℕ}
    (μ : Measure Ω) (ζ : Ω → Ambient n) (hζ : Measurable ζ) (y : Ambient n) (g : Lp ℂ 2 μ)
    {T : Set (Ambient n)} (hg : HasFrequencySupport μ ζ T g) :
    HasFrequencySupport μ ζ T (modulateL2 μ ζ hζ y g) := by
  filter_upwards [modulateL2_coe μ ζ hζ y g, hg] with ω he hs hn
  apply hs
  intro hz
  exact hn (he.trans (by simp [modulate, hz]))

theorem extension_modulateL2 {Ω : Type*} [MeasurableSpace Ω] {n : ℕ}
    (μ : Measure Ω) (ζ : Ω → Ambient n) (hζ : Measurable ζ) (y : Ambient n) (g : Lp ℂ 2 μ)
    (x : Ambient n) : extension μ ζ (modulateL2 μ ζ hζ y g) x = extension μ ζ g (x + y) := by
  rw [← extension_modulate μ ζ y g x]
  apply integral_congr_ae
  filter_upwards [modulateL2_coe μ ζ hζ y g] with ω he
  rw [he]

end N2Restriction

#print axioms N2Restriction.extension_modulateL2
#print axioms N2Restriction.modulateL2_coe
#print axioms N2Restriction.modulateL2_enorm
#print axioms N2Restriction.modulateL2_support
