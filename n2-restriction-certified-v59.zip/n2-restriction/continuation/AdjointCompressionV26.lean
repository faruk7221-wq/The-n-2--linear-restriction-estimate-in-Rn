import continuation.NonzeroFiberNormalsV25

set_option maxHeartbeats 800000

namespace N2Restriction

/-- Reverse compression for the adjoint is coercive without assuming the nearby plane is tangent. -/
theorem nearby_reverse_adjoint_coercive {n : ℕ} (A : Ambient n →L[ℝ] Ambient n)
    (W H : Submodule ℝ (Ambient n)) (hdim : Module.finrank ℝ W = Module.finrank ℝ H)
    {κ : ℝ} (hκ : 0 < κ)
    (hA : ∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (A v)‖)
    (hgap : ‖W.starProjection - H.starProjection‖ * ‖A‖ ≤ κ / 2) :
    ∀ h : H, (κ / 2) * ‖h‖ ≤ ‖W.orthogonalProjection (A.adjoint h)‖ := by
  obtain ⟨J, hJ, _, hnorm⟩ := nearby_projected_shape_inverse W H hdim A hκ hA hgap
  have hsolve (h : H) : H.orthogonalProjection (A (J h)) = h :=
    congrArg (fun L : H →L[ℝ] H => L h) hJ
  intro h
  have hi : inner ℝ (W.orthogonalProjection (A.adjoint h)) (J h) = ‖h‖ ^ 2 := by
    rw [W.inner_orthogonalProjection_eq_of_mem_right]
    rw [ContinuousLinearMap.adjoint_inner_left]
    rw [← H.inner_orthogonalProjection_eq_of_mem_left, hsolve, real_inner_self_eq_norm_sq]
  have hb : ‖J h‖ ≤ (2 / κ) * ‖h‖ :=
    (J.le_opNorm h).trans (mul_le_mul_of_nonneg_right hnorm (norm_nonneg _))
  have hc : ‖h‖ ^ 2 ≤ ‖W.orthogonalProjection (A.adjoint h)‖ * ((2 / κ) * ‖h‖) := by
    calc
      ‖h‖ ^ 2 = inner ℝ (W.orthogonalProjection (A.adjoint h)) (J h) := hi.symm
      _ ≤ ‖W.orthogonalProjection (A.adjoint h)‖ * ‖J h‖ := real_inner_le_norm _ _
      _ ≤ _ := mul_le_mul_of_nonneg_left hb (norm_nonneg _)
  by_cases hh : h = 0
  · simp [hh]
  have hhpos : 0 < ‖h‖ := norm_pos_iff.mpr hh
  have hh' : ‖h‖ ≤ ‖W.orthogonalProjection (A.adjoint h)‖ * (2 / κ) := by
    nlinarith
  have hm := mul_le_mul_of_nonneg_right hh' hκ.le
  field_simp [hκ.ne'] at hm
  nlinarith


end N2Restriction

#print axioms N2Restriction.nearby_reverse_adjoint_coercive
