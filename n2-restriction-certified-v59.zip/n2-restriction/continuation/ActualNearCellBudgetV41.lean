import continuation.ActualLabelledCellBudgetV41

namespace N2Restriction
open MeasureTheory UnitAddTorus Set
open scoped BigOperators ENNReal
noncomputable local instance nearCellCircleMeasure : MeasureSpace UnitAddCircle := ⟨AddCircle.haarAddCircle⟩

/-- Section 6's degree-dependent cell budget for actual selected graph
packets across caps. Axes are assigned to the original packet indices. -/
theorem actual_near_cell_budget {d n m : ℕ} {J : Type*} [Fintype J]
    (c : J → Ambient d) (r : ℝ) (hr : 0 < r)
    (f : (j : J) → Lp ℂ 2 (volume.restrict (packetFrequencyCube (c j) r hr)))
    (A : J → Set (Fin d → ℤ)) (P : Fin m → MvPolynomial (Fin n) ℝ)
    (a v : J → (Fin d → ℤ) → Ambient n) (Ω : Set (Ambient n))
    {b w : ℝ} (hw : w < b) {M : ℝ} (hM : 0 ≤ M)
    (hoverlap : ∀ᵐ y ∂(volume : Measure (Ambient d)),
      (∑ j, (Metric.ball (c j) (2*r)).indicator (fun _ => (1 : ℝ)) y) ≤ M)
    (E₀ : ENNReal) (henergy : (∑ j, ENNReal.ofReal (‖f j‖^2)) ≤ E₀) :
    (∑' σ : Fin m → Bool, ENNReal.ofReal (‖∑ j,
      ∑' ν : {ν // ν ∈ A j ∧ σ ∈ trimmedCellLabels P (a j ν) (v j ν) Ω b w},
        actualPacketInput (c j) r hr (f j) ν.val‖^2)) ≤
      ENNReal.ofReal M * (((∏ l, P l).totalDegree+1 : ℕ) : ENNReal) * E₀ := by
  apply actual_labelled_cell_budget c r hr f A
    (fun j ν => trimmedCellLabels P (a j ν) (v j ν) Ω b w) hM hoverlap _ E₀ _ henergy
  intro j ν _
  exact_mod_cast trimmedCellLabels_card_le_degree P (a j ν) (v j ν) Ω hw

end N2Restriction
#print axioms N2Restriction.actual_near_cell_budget
