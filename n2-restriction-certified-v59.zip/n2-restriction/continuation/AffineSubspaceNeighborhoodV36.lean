import continuation.SubspaceProjectionV36

namespace N2Restriction
open Set Metric

/-- The affine plane through a with direction N is a closed set. -/
theorem isClosed_affineSubspace {m : ℕ} (N : Submodule ℝ (Ambient m)) (a : Ambient m) :
    IsClosed {x | x-a ∈ N} :=
  N.closed_of_finiteDimensional.preimage (continuous_id.sub continuous_const)

/-- Witness tubes agree with closed distance neighborhoods of affine subspaces. -/
theorem affineSubspaceTube_eq_infDist {m : ℕ} (N : Submodule ℝ (Ambient m))
    (a : Ambient m) (w : ℝ) :
    affineSubspaceTube N a w = {x | infDist x {y | y-a ∈ N} ≤ w} := by
  ext x
  constructor
  · rintro ⟨v,hv,hd⟩
    have hm : a+v ∈ {y | y-a ∈ N} := by simpa only [mem_setOf_eq, add_sub_cancel_left] using hv
    exact (infDist_le_dist_of_mem hm).trans hd
  · intro hx
    have hn : ({y : Ambient m | y-a ∈ N} : Set (Ambient m)).Nonempty := ⟨a, by simp⟩
    obtain ⟨y,hy,heq⟩ := (isClosed_affineSubspace N a).exists_infDist_eq_dist hn x
    refine ⟨y-a,hy,?_⟩
    simpa only [add_sub_cancel] using heq ▸ hx

theorem measurableSet_affineSubspaceTube {m : ℕ} (N : Submodule ℝ (Ambient m))
    (a : Ambient m) (w : ℝ) : MeasurableSet (affineSubspaceTube N a w) := by
  rw [affineSubspaceTube_eq_infDist]
  exact (isClosed_le (continuous_infDist_pt _) continuous_const).measurableSet

/-- Affine line tubes are the rank-one special case of affine-subspace tubes. -/
theorem affineSubspaceTube_span_singleton {m : ℕ} (a v : Ambient m) (w : ℝ) :
    affineSubspaceTube (Submodule.span ℝ {v}) a w = affineLineTube a v w := by
  ext x
  constructor
  · rintro ⟨u,hu,hd⟩
    obtain ⟨s,rfl⟩ := Submodule.mem_span_singleton.mp hu
    exact ⟨s,hd⟩
  · rintro ⟨s,hs⟩
    exact ⟨s•v, Submodule.smul_mem _ _ (Submodule.subset_span (by simp)), hs⟩

end N2Restriction

#print axioms N2Restriction.affineSubspaceTube_eq_infDist
#print axioms N2Restriction.affineSubspaceTube_span_singleton
#print axioms N2Restriction.isClosed_affineSubspace
#print axioms N2Restriction.measurableSet_affineSubspaceTube
