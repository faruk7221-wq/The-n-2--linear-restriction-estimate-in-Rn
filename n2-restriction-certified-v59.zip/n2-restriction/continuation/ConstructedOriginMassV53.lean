import continuation.ActualAtlasDescentV53
import continuation.InitialFullPacketStageV53
import continuation.PacketNearTerminalMassV52
import continuation.PolynomialZeroDimensionalMassV51
import continuation.TerminationErrorEnvelopeV53
namespace N2Restriction
open MeasureTheory Set Metric Filter
open scoped BigOperators ENNReal
set_option maxHeartbeats 2400000

/-- The article's actual original-input mass inequality after all finite
polynomial drops. The same chart inputs support the initial reconstruction,
cellular bound and both terminal estimates. Only borrowed inputs are assumed.
The child radius multiplier is fixed as 100^(k+2), before the subdivision. -/
theorem exists_constructed_origin_mass_descent {k : ℕ} (hk : 3 ≤ k)
    (P : Fin k → SmoothPatch (k+2)) {ν κ : ℝ} (hgeo : GeometricHypotheses P ν κ)
    (hKexternal : WeightedKakeyaExternalGoal (k+2) k)
    (hcutsExternal : UniformTangentCutsInput (k+2))
    (hpartitionExternal : UniformProjectedPartitionInput (k+2))
    (hcoverExternal : UniformPolynomialTubeCoverInput (k+2))
    (hpointsExternal : ZeroDimensionalPointCountInput (k+2))
    {ε τ : ℝ} (hε : 0 < ε) (hτ : 0 < τ) (hτ' : τ < 1/4) :
    ∃ ι : ℝ, 0 < ι ∧ ∃ Dsub : (i : Fin k) → DirectionalSubdivision (P i) ι,
    ∀ (a : (i : Fin k) → Fin (Dsub i).size)
      (B : ArticleLocalizationAtlas (fun i => (Dsub i).piece (a i)) κ)
      (V : Fin k → Set (Ambient (k+2))) (margin : ℝ),
    (∀ i, ((Dsub i).piece (a i)).extendedSurface ∩ V i ⊆ ((Dsub i).piece (a i)).support) →
    0 < margin → B.UniformLocalizedInput (baseline (k : ℝ)) →
    ∀ C C₀ : ℝ, 1 ≤ C → 1+Real.sqrt (k+2 : ℕ)*(1+C)/2 ≤ C₀ →
    ∀ p : ℝ, critical k < p → p < baseline k →
    ∃ K : ENNReal, K ≠ ∞ ∧ ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ R : ℝ, R₀ ≤ R →
    ∀ g : (i : Fin k) → Lp ℂ 2 ((Dsub i).piece (a i)).surfaceMeasure,
    MarginAdmissible (fun i => ((Dsub i).piece (a i)).surfaceMeasure) (fun _ => id) V margin R (fun i => g i) →
    (∫⁻ x in ball 0 R, ‖extensionProduct (fun i => ((Dsub i).piece (a i)).surfaceMeasure)
      (fun _ => id) (fun i => g i) x‖ₑ^p) ≤
    (ENNReal.ofReal (1/4) *
      (marginLocalConstant (fun i => ((Dsub i).piece (a i)).surfaceMeasure) (fun _ => id) V margin p (R/2))^p +
      K*((marginLocalConstant (fun i => ((Dsub i).piece (a i)).surfaceMeasure) (fun _ => id) V margin p (R^(1-τ)))^p +
        (marginLocalConstant (fun i => ((Dsub i).piece (a i)).surfaceMeasure) (fun _ => id) V margin p
          ((100 : ℝ)^(k+2)*R^(1/2+τ)))^p + (ENNReal.ofReal (R^(sigma k τ ε)))^p+1))*
      (∏ i, ENNReal.ofReal ‖g i‖)^p := by
  classical
  let lam : ℝ := 100^(k+2)
  have hlam : 1 ≤ lam := by dsimp only [lam]; exact one_le_pow₀ (by norm_num)
  obtain ⟨ι,Cext,hι,hCext,Dsub,hrank,hterminal⟩ := exists_constructed_terminal_mass_of_packet_near
    hk P hgeo hKexternal hε hτ hτ' hlam
  refine ⟨ι,hι,Dsub,?_⟩
  intro a B V margin hS hm hexternal C C₀ hC hC₀ p hpc hpb
  let A : (i : Fin k) → PacketGraphAtlas ((Dsub i).piece (a i)) :=
    fun i => Classical.choice (((Dsub i).piece (a i)).exists_packetGraphAtlas)
  have hkR : (3 : ℝ) ≤ k := by exact_mod_cast hk
  have hp : 0 < p := (critical_pos (by linarith : (0 : ℝ) < k)).trans hpc
  have hp1 : p ≤ 1 := hpb.le.trans (baseline_le_one hkR)
  let γ : ℝ := min (ι/2) (1/4)
  have hγ : 0 < γ := lt_min (by positivity) (by norm_num)
  have hγsmall : 2*γ ≤ (1 : ℝ)/2 := by have h := min_le_right (ι/2) (1/4 : ℝ); dsimp only [γ]; linarith
  have hγι : γ ≤ ι/2 := min_le_left _ _
  obtain ⟨Rd,hRd,Bfinal,hwidth,Kr,hKr,hdescent⟩ := uniform_actual_atlas_descent hk hcutsExternal
    hpartitionExternal hcoverExternal P hι hγ hγsmall hγι Dsub a (hrank a) A V margin hm hS
    hτ (by norm_num : (0 : ℝ) < 1/4) hp hp1 hpc PolynomialStageBudget.initial
  have hwidth' : Bfinal.width = lam := by simpa only [PolynomialStageBudget.initial,mul_one] using hwidth
  obtain ⟨Hcover,Kcover,hKcover,hcovers⟩ := exists_uniform_actual_polynomial_covers hcoverExternal Bfinal
  obtain ⟨Bcap,hBcap,Kt,hKt,Rt,hRt,ht⟩ := hterminal a A B V margin hS hm hexternal C C₀ hC hC₀
    Hcover Kcover hKcover p hpc hpb Bfinal.mass Bfinal.mass_finite
  obtain ⟨Kz,hKz,hz⟩ := eventually_polynomial_zero_dimensional_stage_mass
    (fun i => (Dsub i).piece (a i)) (fun i => (Dsub i).piece (a i)) A V margin hS hm hτ
    (by linarith : τ < 1/2) (by linarith : 0 < lam) hpointsExternal Bfinal.degree p hp Bfinal.mass Bfinal.mass_finite
  obtain ⟨Rz,hRz⟩ := Filter.eventually_atTop.1 hz
  obtain ⟨K,hK,henvelope⟩ := termination_mass_envelope_with_cell_error hp hp1 Kt Kz (Kr Bcap) hKt hKz (hKr Bcap)
  refine ⟨K,hK,max Rd (max Rt Rz),hRd.trans (le_max_left _ _),?_⟩
  intro R hR g hg
  have hdR : Rd ≤ R := (le_max_left _ _).trans hR
  have htR : Rt ≤ R := (le_max_left _ _).trans ((le_max_right _ _).trans hR)
  have hzR : Rz ≤ R := (le_max_right _ _).trans ((le_max_right _ _).trans hR)
  have hRpos : 0 < R := lt_of_lt_of_le zero_lt_one (hRd.trans hdR)
  obtain ⟨Q,L,c,hsmall,hcount,hcover,hsep,hinputs⟩ := ht R htR
  obtain ⟨f,he,hs,hf,hx,hterminalBound⟩ := hinputs g hg
  have hr : 0 < R^(-1/2 : ℝ) := Real.rpow_pos_of_pos hRpos _
  obtain ⟨W₀,_,hB₀⟩ := initial_full_packet_polynomial_stage (fun i => (Dsub i).piece (a i)) A hr
    (Real.rpow_pos_of_pos hRpos _) Q g f hs hx p (ball 0 R) isOpen_ball.measurableSet Set.Subset.rfl
  have hout := hdescent R hdR Q hr hsmall Bcap hBcap hcount g f he hf
    (fun _ _ _ => Set.univ) W₀ hB₀
  apply henvelope _ _ _ _ _ _ _
  rcases hout with hcell|hzero|hterm
  · exact Or.inl (by simpa only [add_zero] using hcell)
  · obtain ⟨mvar,U,_,Zs,hbudget,hzero⟩ := hzero
    have hmult : Zs.multiplier ≤ lam := hbudget.2.1.trans_eq hwidth'
    have hh := hRz R hzR Q hr hsmall g f he hf U mvar Zs hzero hbudget.1 hmult hbudget.2.2
    exact Or.inr (Or.inr (by simpa only [add_zero] using hh))
  · obtain ⟨mvar,F,_,hcount'⟩ := hterm
    have hmult : F.stage.multiplier ≤ lam := F.bounded.2.1.trans_eq hwidth'
    have hh := hterminalBound hr F.selected mvar F.stage F.cuts F.plane F.near γ hγι hmult
      F.bounded.2.2 hcount' F.near_angle F.plane_region (hcovers F.stage F.bounded)
    exact Or.inr (Or.inl (by simpa only [add_zero] using hh))
end N2Restriction
#print axioms N2Restriction.exists_constructed_origin_mass_descent
