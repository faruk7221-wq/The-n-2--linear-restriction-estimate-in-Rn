import continuation.DependentBlockProjectionV35

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal BigOperators

/-- Fixed unit-ball normalization for arbitrary complementary Euclidean blocks. -/
noncomputable def dependentBlockVolumeConstant (n : ℕ) (d : Fin (n+2) → ℕ) : ℝ≥0∞ :=
  (∏ i : Fin (n+2), (Measure.pi (fun j => (volume : Measure (Ambient (d (i.succAbove j))))))
    (closedBall 0 1)) ^ (1 / ((n:ℝ)+1))

theorem dependentBlockVolumeConstant_pos (n : ℕ) (d : Fin (n+2) → ℕ) :
    0 < dependentBlockVolumeConstant n d := by
  unfold dependentBlockVolumeConstant
  apply ENNReal.rpow_pos
  · exact pos_iff_ne_zero.mpr (Finset.prod_ne_zero_iff.mpr
      (fun _ _ => (measure_closedBall_pos _ _ (by norm_num)).ne'))
  · exact (ENNReal.prod_lt_top (fun _ _ => measure_closedBall_lt_top)).ne

theorem dependentBlockVolumeConstant_ne_top (n : ℕ) (d : Fin (n+2) → ℕ) :
    dependentBlockVolumeConstant n d ≠ ⊤ := by
  unfold dependentBlockVolumeConstant
  have hf : (∏ i : Fin (n+2), (Measure.pi (fun j => (volume : Measure (Ambient (d (i.succAbove j))))))
    (closedBall 0 1)) ≠ ⊤ := (ENNReal.prod_lt_top (fun _ _ => measure_closedBall_lt_top)).ne
  finiteness

/-- The product of all complementary ball masses scales with the physical
dimension sum(d), after taking the power 1/(k-1). -/
theorem dependent_block_ball_mass (n : ℕ) (d : Fin (n+2) → ℕ)
    (r : ℝ) (hr : 0 ≤ r) (u : Fin (n+2) → ℝ≥0∞) :
    (∏ i, u i * (Measure.pi (fun j => (volume : Measure (Ambient (d (i.succAbove j))))))
      (closedBall 0 r)) ^ (1/((n:ℝ)+1)) =
      dependentBlockVolumeConstant n d * ENNReal.ofReal r ^ (∑ i, d i) *
        (∏ i, u i) ^ (1/((n:ℝ)+1)) := by
  have hp : 0 ≤ 1/((n:ℝ)+1) := by positivity
  simp_rw [dependent_block_ball_volume n d _ 0 r hr]
  simp only [Finset.prod_mul_distrib, Finset.prod_pow_eq_pow_sum,
    ENNReal.mul_rpow_of_nonneg _ _ hp]
  rw [sum_complementary_dimensions]
  have hpow : (ENNReal.ofReal r ^ ((n+1)*(∑ i, d i))) ^ (1/((n:ℝ)+1)) =
      ENNReal.ofReal r ^ (∑ i, d i) := by
    rw [← ENNReal.rpow_natCast, ← ENNReal.rpow_mul, ← ENNReal.rpow_natCast]
    congr 1
    push_cast
    field_simp
  rw [hpow]
  unfold dependentBlockVolumeConstant
  ring

end N2Restriction

#print axioms N2Restriction.dependentBlockVolumeConstant_ne_top
#print axioms N2Restriction.dependentBlockVolumeConstant_pos
#print axioms N2Restriction.dependent_block_ball_mass
