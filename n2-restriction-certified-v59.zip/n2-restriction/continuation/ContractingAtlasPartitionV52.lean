import continuation.AtlasOnePartitionV52
import continuation.ConcretePartitionDegreeV52
namespace N2Restriction
open Set Metric MeasureTheory
open scoped BigOperators ENNReal
set_option maxHeartbeats 1200000

/-- The actual one-partition alternative with any prescribed cellular
contraction. A single degree is fixed before R and every subsequently selected
nonterminal case; its wall continuation has a fixed degree/width/mass budget. -/
theorem atlas_contracting_partition_stage_alternative {k : ℕ} (hk : 3 ≤ k)
    (S : Fin k → SmoothPatch (k+2)) (T : (i : Fin k) → PacketGraphAtlas (S i))
    (Vfreq : Fin k → Set (Ambient (k+2))) (margin : ℝ) (hm : 0 < margin)
    (hW : ∀ i, (S i).extendedSurface ∩ Vfreq i ⊆ (S i).support) {τ : ℝ} (hτ : 0 < τ) {c : ℝ} (hc : 0 < c) :
    ∃ B₀ : Fin k → ℝ, (∀ i, 1 ≤ B₀ i) ∧ ∃ M : ℝ, 1 ≤ M ∧
    ∃ q : Finset (Ambient (k+2)), ∃ R₀ : ℝ, 1 ≤ R₀ ∧
    ∀ p : ℝ, 0 < p → p ≤ 1 → critical k < p → ∀ J : ℝ, ∃ C : ℝ, 0 ≤ C ∧
    ∀ (Bstage : PolynomialStageBudget) (Hgeom : ℕ) (Kgeom γ E c₀ c₁ : ℝ),
    0 ≤ Kgeom → 0 < E → 0 < c₀ →
    ∀ (Nfac : ℕ → ℕ), ∃ D : ℕ, 1 ≤ D ∧
    ∀ R : ℝ, R₀ ≤ R →
    ∀ (Q : (i : Fin k) → (j : Fin (T i).size) → CoordinateCapFamily ((T i).patch j).support (R^(-1/2 : ℝ)))
      (hr : 0 < R^(-1/2 : ℝ)), (∀ i, R^(-1/2 : ℝ) ≤ (T i).capRadius) →
    ∀ Bcap : ℝ, 0 ≤ Bcap → (∀ i j, ((Q i j).centers.card : ℝ) ≤ Bcap*R^(((k+1 : ℕ) : ℝ)/2)) →
    ∀ (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure)
      (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure),
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
    (∀ i j, HasFrequencySupport ((T i).graph j).surfaceMeasure ((T i).patch j).rotation
      (marginRegion (Vfreq i) (margin-R^(-1/4 : ℝ))) (f i j)) →
    ∀ (U : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin (k+1) → ℤ))
      {M₀ err : ENNReal} (mvar : ℕ)
      (Zs : PolynomialStage (fun _ => Measure.hausdorffMeasure ((k+1 : ℕ) : ℝ))
        (fun i => (T i).cellInput (Q i) hr (f i) (U i)) p R (R^(1/2+τ)) M₀ err mvar),
    Zs.withinBudget Bstage →
    ∀ (cuts : Set (Ambient (k+2))) (V : Submodule ℝ (Ambient (k+2))), IsClosed cuts →
    (∀ x ∈ Zs.region, Nonempty (ShortLiftWitness V (polynomialLevelMap Zs.equations)
      {x | polynomialLevelMap Zs.equations x = 0} cuts (Zs.multiplier*R^(1/2+τ)) x)) →
    Zs.region ⊆ thickening (Zs.multiplier*R^(1/2+τ)) (planeWitnessSet Zs.equations cuts V (2*γ)) →
    ∀ (s : Fin (k+3)) (far : Finset (Fin k)), 1 ≤ s.val → k+1 ≤ s.val+far.card →
    (∀ i ∈ far, ∀ j a ν, ν ∈ U i j a → 4*γ < directionPlaneAngle ((T i).cellAxisDirection j a.val) V) →
    AlgebraicTubeCoverInput {x | polynomialLevelMap Zs.equations x = 0}
      (fun z => LinearMap.ker (fderiv ℝ (polynomialLevelMap Zs.equations) z).toLinearMap) γ Hgeom Kgeom →
    ∀ PC : ProjectedPartitionCertificate Zs.equations V
      (partitionDensity (fun _ => Measure.hausdorffMeasure ((k+1 : ℕ) : ℝ))
        (fun i => (T i).cellInput (Q i) hr (f i) (U i)) Zs.region p) Zs.region D (Nfac D) (s.val : ℝ) c₀ c₁ E,
    (M₀ ≤ ENNReal.ofReal c *
      (marginLocalConstant (fun i => (S i).surfaceMeasure) (fun _ => id) Vfreq margin p (R/2))^p *
      (∏ i, ENNReal.ofReal ‖g i‖)^p +
      (Bstage.mass*ENNReal.ofReal (2*c₁/(1/2))*ENNReal.ofReal ((D : ℝ)^(s.val : ℝ))*
        ((volume (ball (0 : Ambient (k+2)) 1)*(ENNReal.ofReal ((k : ℝ)*C*Real.sqrt Bcap*M^k))^p)*
        ENNReal.ofReal (R^(-J))*(∏ i, ENNReal.ofReal ‖g i‖)^p)+err)) ∨
    (mvar < k+2 ∧ ∃ i : Fin PC.factorCount,
      ∃ Z' : PolynomialStage (fun _ => Measure.hausdorffMeasure ((k+1 : ℕ) : ℝ))
        (fun i => (T i).cellInput (Q i) hr (f i) (U i)) p R (R^(1/2+τ)) M₀ err (mvar+1),
      Z'.equations = Fin.cons (PC.factors i) Zs.equations ∧
      Z'.degreeBound = max Zs.degreeBound D ∧ Z'.multiplier = 5*Zs.multiplier ∧
      Z'.region ⊆ Zs.region ∧ Z'.withinBudget (Bstage.advance D 5 (by norm_num)
        ((Nfac D : ENNReal)/(2 : ENNReal)⁻¹) (ENNReal.div_ne_top (by simp) (by norm_num)))) := by
  obtain ⟨B₀,hB₀,M,hM,q,R₀,hR₀,hb⟩ := atlas_one_partition_stage_alternative S T Vfreq margin hm hW hτ
  refine ⟨B₀,hB₀,M,hM,q,R₀,hR₀,?_⟩
  intro p hp hp1 hpc J
  obtain ⟨C,hC,hbound⟩ := hb p hp hp1 J
  refine ⟨C,hC,?_⟩
  intro Bstage Hgeom Kgeom γ E c₀ c₁ hKgeom hE hc₀ Nfac
  obtain ⟨D,hD,hcontract⟩ := concrete_partition_contracting_degree (n := k+2) hk hpc hc Bstage B₀ Hgeom Kgeom E c₀ c₁ q
  refine ⟨D,hD,?_⟩
  intro R hR Q hr hsmall Bcap hBcap hcount g f he hf U M₀ err mvar Zs hB cuts V hcuts hw hregion s far hs hfeasible hfar hAlg PC
  rcases hbound Bstage Hgeom Kgeom γ E c₀ c₁ (s.val : ℝ) hKgeom hE hc₀ D (Nfac D) hD R hR Q hr hsmall Bcap hBcap hcount
    g f he hf U mvar Zs hB cuts V hcuts hw hregion far hfar hAlg PC with hcell|hwall
  · left
    have ht : far.card < k+1 := by
      have hh := Finset.card_le_univ far
      simp only [Fintype.card_fin] at hh
      omega
    have hcoef := hcontract s ⟨far.card,ht⟩ hs hfeasible
    apply hcell.trans
    apply add_le_add_right
    apply mul_le_mul_right'
    apply mul_le_mul_right'
    exact hcoef.le
  · exact Or.inr hwall

end N2Restriction
#print axioms N2Restriction.atlas_contracting_partition_stage_alternative
