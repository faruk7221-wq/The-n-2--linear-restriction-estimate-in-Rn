import N2Restriction.Scales
import Mathlib.Analysis.SpecialFunctions.Pow.NNReal

namespace N2Restriction
open scoped BigOperators ENNReal

/-- Convert simultaneous squared-energy bounds into the product power used
by the local restriction estimate. Zero inputs and infinite local constants
are allowed; there is no division by an input norm. -/
theorem cell_energy_product {k : ℕ} (a b E : Fin k → ENNReal) {p : ℝ}
    (hp : 0 ≤ p) (he : ∀ i, a i ^ (2 : ℕ) ≤ E i * b i ^ (2 : ℕ)) :
    (∏ i, a i)^p ≤ (∏ i, E i)^(p/2) * (∏ i, b i)^p := by
  have h := ENNReal.rpow_le_rpow (Finset.prod_le_prod' (s := Finset.univ) (fun i _ => he i))
    (show 0 ≤ p/2 by positivity)
  rw [Finset.prod_mul_distrib, Finset.prod_pow, Finset.prod_pow,
    ENNReal.mul_rpow_of_nonneg _ _ (by positivity)] at h
  simpa only [← ENNReal.rpow_natCast, ← ENNReal.rpow_mul,
    Nat.cast_ofNat, show (2 : ℝ)*(p/2)=p by ring] using h

/-- Insert the product-energy estimate into the local constant without
assuming that the constant is finite. -/
theorem cell_local_energy_product {k : ℕ} (a b E : Fin k → ENNReal)
    (L : ENNReal) {p : ℝ} (hp : 0 ≤ p)
    (he : ∀ i, a i ^ (2 : ℕ) ≤ E i * b i ^ (2 : ℕ)) :
    (L * ∏ i, a i)^p ≤ L^p * (∏ i, E i)^(p/2) * (∏ i, b i)^p := by
  rw [ENNReal.mul_rpow_of_nonneg _ _ hp, mul_assoc]
  exact mul_le_mul_left' (cell_energy_product a b E hp he) _

end N2Restriction
#print axioms N2Restriction.cell_energy_product
#print axioms N2Restriction.cell_local_energy_product
