import continuation.CertifiedGlobalAssemblyV55
import continuation.GeometricSurfaceHalfDecayV58
namespace N2Restriction
set_option maxHeartbeats 1000000

/-- The named global theorem, with the article-side full-surface decay proved
internally. All remaining premises are explicit borrowed external inputs. -/
theorem mainGlobalGoal_of_certified_borrowed_inputs
    (harea : SmoothGraphAreaFormulaInput)
    (hK : ∀ k : ℕ, 3 ≤ k → WeightedKakeyaExternalGoal (k+2) k)
    (hL : ∀ (k : ℕ) (_hk : 3 ≤ k), CertifiedLocalizedRestrictionInput (k := k))
    (hcuts : ∀ k : ℕ, 3 ≤ k → UniformTangentCutsInput (k+2))
    (hpartition : ∀ k : ℕ, 3 ≤ k → UniformProjectedPartitionInput (k+2))
    (hcover : ∀ k : ℕ, 3 ≤ k → UniformPolynomialTubeCoverInput (k+2))
    (hpoints : ∀ k : ℕ, 3 ≤ k → ZeroDimensionalPointCountInput (k+2))
    (hRemoval : SurfaceEpsilonRemovalInput) : MainGlobalGoal := by
  apply mainGlobalGoal_of_certified_inputs_and_nonempty_decay hK hL hcuts hpartition hcover hpoints hRemoval
  intro k hk S ν κ hgeo hn
  exact surfaceTestDecay_of_geometric_inputs harea S hgeo hn

/-- Both named main goals, relative only to the certified borrowed inputs. -/
theorem mainGoals_of_certified_borrowed_inputs
    (harea : SmoothGraphAreaFormulaInput)
    (hK : ∀ k : ℕ, 3 ≤ k → WeightedKakeyaExternalGoal (k+2) k)
    (hL : ∀ (k : ℕ) (_hk : 3 ≤ k), CertifiedLocalizedRestrictionInput (k := k))
    (hcuts : ∀ k : ℕ, 3 ≤ k → UniformTangentCutsInput (k+2))
    (hpartition : ∀ k : ℕ, 3 ≤ k → UniformProjectedPartitionInput (k+2))
    (hcover : ∀ k : ℕ, 3 ≤ k → UniformPolynomialTubeCoverInput (k+2))
    (hpoints : ∀ k : ℕ, 3 ≤ k → ZeroDimensionalPointCountInput (k+2))
    (hRemoval : SurfaceEpsilonRemovalInput) : MainLocalGoal ∧ MainGlobalGoal := by
  exact ⟨mainLocalGoal_of_certified_borrowed_inputs hK hL hcuts hpartition hcover hpoints,
    mainGlobalGoal_of_certified_borrowed_inputs harea hK hL hcuts hpartition hcover hpoints hRemoval⟩
end N2Restriction
#print axioms N2Restriction.mainGlobalGoal_of_certified_borrowed_inputs
#print axioms N2Restriction.mainGoals_of_certified_borrowed_inputs
