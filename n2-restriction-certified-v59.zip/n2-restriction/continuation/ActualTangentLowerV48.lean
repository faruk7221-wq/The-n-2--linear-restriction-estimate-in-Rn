import continuation.ActualTangentSquareMajorantV48
import continuation.ActualSquareLinearBoundV48
import continuation.SquareFunctionHolderV48

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal

/-- Equation (7.9) for the same actual F_tan as (7.10). The fixed-class
support invariant is explicit; no estimate for an unselected product is used. -/
theorem actualTangentSum_lower_bound {d k : ℕ} (hk : 0 < k)
    (S : Fin k → SmoothPatch (d+1)) (A : (i : Fin k) → PacketGraphAtlas (S i))
    {θ : ℝ} (hθ : 0 < θ) :
    ∃ D : ENNReal, D ≠ ∞ ∧ ∀ {r : ℝ}
    (Q : (i : Fin k) → (j : Fin (A i).size) → CoordinateCapFamily ((A i).patch j).support r)
    (hr : 0 < r), (∀ i, r ≤ (A i).capRadius) →
    ∀ (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure)
    (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure),
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
    ∀ {L : ℕ} (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin d → ℤ))
    (Z : Set (Ambient (d+1))) (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1)))
    (c : Fin L → Ambient (d+1)) (ρ b C₀ R w : ℝ) (Ω : Set (Ambient (d+1))),
    0 ≤ R → 0 < ρ → ρ ≤ R → w ≤ ρ →
    (∀ l t, l ≠ t → 2*(θ*ρ) ≤ dist (c l) (c t)) →
    (∀ i (ls : Fin L × Bool), HasFrequencySupport (Measure.hausdorffMeasure (d : ℝ)) id (S i).support
      ((A i).cellInput (Q i) hr (f i) (if ls.2 then
        (A i).actualTangentSelection (Q i) (U i) Z T (c ls.1) ρ b C₀ R w Ω else
        (A i).actualNontangentSelection (Q i) (U i) Z T (c ls.1) ρ b C₀ R w Ω))) →
    positiveNorm (actualTangentSum A Q hr f U Z T c ρ b C₀ R w Ω) (2/(k : ℝ)) volume ≤
      D*(ENNReal.ofReal R)^((k : ℝ)/2)*∏ i, ENNReal.ofReal ‖g i‖ := by
  choose C B K hB hK hb using fun i => (A i).actual_retained_square_linear_bound
  let a : Fin k → ENNReal := fun i => (C i : ENNReal)*ENNReal.ofReal (B i)*
    ENNReal.ofReal ((2*K i+2)*(3/θ+1)^(d+1))
  have ha i : a i ≠ ∞ := ENNReal.mul_ne_top
    (ENNReal.mul_ne_top ENNReal.coe_ne_top ENNReal.ofReal_ne_top) ENNReal.ofReal_ne_top
  let O : ENNReal := ENNReal.ofReal ((1/θ+1)^(d+1))*(2^k : ENNReal)
  have hO : O ≠ ∞ := ENNReal.mul_ne_top ENNReal.ofReal_ne_top (by simp)
  refine ⟨O*∏ i, (a i)^(1/2 : ℝ),ENNReal.mul_ne_top hO
    (ENNReal.prod_ne_top (fun i _ => ENNReal.rpow_ne_top_of_nonneg (by norm_num) (ha i))),?_⟩
  intro r Q hr hsmall g f he L U Z T c ρ b C₀ R w Ω hR hρ hρR hw hsep hs
  let G : Fin k → Ambient (d+1) → ENNReal := fun i =>
    (A i).actualRetainedSquare (Q i) hr (f i) (U i) Z T c ρ b C₀ R w Ω
  have hG i : Measurable (G i) := by
    apply Finset.measurable_sum
    intro ls _
    exact ((continuous_extension measurable_id ((A i).cellInput_integrable (Q i) hr (hsmall i) (f i) _)).enorm.measurable.pow_const (2 : ℝ)).indicator isOpen_ball.measurableSet
  have hholder := square_function_holder volume hk _ G (fun i => (hG i).aemeasurable) O
    (fun x => by simpa only [O,mul_assoc] using actualTangentSum_square_majorant A Q hr f U Z T c ρ b C₀ R w Ω hρ hθ hsep x)
  have hroot i : (∫⁻ x, G i x)^(1/2 : ℝ) ≤
      (a i)^(1/2 : ℝ)*(ENNReal.ofReal R)^(1/2 : ℝ)*ENNReal.ofReal ‖g i‖ := by
    have hb' := (hb i hR hρ hρR hθ hw (Q i) hr (f i) (U i) Z T c b C₀ Ω hsep (hs i)).trans
      (mul_le_mul_left' (ENNReal.ofReal_le_ofReal (he i)) (a i*ENNReal.ofReal R))
    have hh := ENNReal.rpow_le_rpow hb' (by norm_num : (0 : ℝ) ≤ 1/2)
    have hsq : (ENNReal.ofReal (‖g i‖^2))^(1/2 : ℝ) = ENNReal.ofReal ‖g i‖ := by
      rw [ENNReal.ofReal_pow (norm_nonneg _),← ENNReal.rpow_natCast,← ENNReal.rpow_mul]
      norm_num
    simpa only [ENNReal.mul_rpow_of_nonneg _ _ (by norm_num : (0 : ℝ) ≤ 1/2),hsq] using hh
  have hrad : (∏ _i : Fin k, (ENNReal.ofReal R)^(1/2 : ℝ)) = (ENNReal.ofReal R)^((k : ℝ)/2) := by
    simp only [Finset.prod_const,Finset.card_univ,Fintype.card_fin]
    rw [← ENNReal.rpow_natCast,← ENNReal.rpow_mul]
    congr 1
    ring
  apply hholder.trans
  have hp := mul_le_mul_left' (Finset.prod_le_prod' (fun (i : Fin k) (_ : i ∈ Finset.univ) => hroot i)) O
  simpa only [Finset.prod_mul_distrib,hrad,mul_assoc] using hp

end N2Restriction
#print axioms N2Restriction.actualTangentSum_lower_bound
