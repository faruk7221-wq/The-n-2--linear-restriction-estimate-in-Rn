import continuation.GlobalCoveredGraphV57
import continuation.GraphProductCoordinatesV57
import continuation.HorizontalAffineMeasureV57
namespace N2Restriction
open Set Filter Metric
set_option maxHeartbeats 800000

noncomputable def graphFiberHomeomorph (d : ℕ) : Ambient d × ℝ ≃ₜ Ambient (d+1) where
  toEquiv := (graphFiberEquiv d).toEquiv
  continuous_toFun := graphPointCLM.continuous
  continuous_invFun := graphProjection_lipschitz.continuous.prodMk
    (EuclideanSpace.proj (0 : Fin (d+1))).continuous

/-- Every genuine parameter neighborhood gives an ambient open localization
neighborhood when the graph germ retains its surface-cover property. -/
theorem exists_open_chart_localization {d : ℕ} (S : SmoothPatch (d+1))
    (G : Ambient d → Ambient (d+1)) (u : Ambient d) (x : Ambient (d+1))
    (hcover : ∀ W : Set (Ambient d), W ∈ nhds u → ∀ᶠ z in nhds x,
      z ∈ S.extendedSurface → z ∈ G '' W)
    (K : Set (Ambient d)) (hK : K ∈ nhds u) :
    ∃ V : Set (Ambient (d+1)), IsOpen V ∧ x ∈ V ∧ S.extendedSurface ∩ V ⊆ G '' K := by
  obtain ⟨V,hV,hVo,hx⟩ := _root_.mem_nhds_iff.mp (hcover K hK)
  exact ⟨V,hVo,hx,fun z hz => hV hz.2 hz.1⟩

/-- The closed product rectangle has a full parameter neighborhood at its center. -/
theorem affine_rectangle_mem_nhds {d : ℕ} (u : Ambient (d+1))
    (R : Ambient (d+1) ≃ₗᵢ[ℝ] Ambient (d+1)) {r : ℝ} (hr : 0 < r)
    {δ : ℝ} (hδ : 0 < δ) :
    (horizontalAffine u R r hr.ne') ''
      ((graphFiberEquiv d) '' (closedBall (0 : Ambient d) δ ×ˢ Icc (-δ) δ)) ∈ nhds u := by
  have hp : closedBall (0 : Ambient d) δ ×ˢ Icc (-δ) δ ∈ nhds ((0 : Ambient d), (0 : ℝ)) :=
    prod_mem_nhds (closedBall_mem_nhds _ hδ) (Icc_mem_nhds (neg_neg_of_pos hδ) hδ)
  have he := Filter.image_mem_map (m := graphFiberHomeomorph d) hp
  rw [(graphFiberHomeomorph d).map_nhds_eq] at he
  have hf := Filter.image_mem_map (m := horizontalAffine u R r hr.ne') he
  rw [(horizontalAffine u R r hr.ne').map_nhds_eq] at hf
  have hz : graphPoint (0 : Ambient d) (0 : ℝ) = 0 := by
    ext j
    refine Fin.cases ?_ (fun k => ?_) j <;> simp [graphPoint]
  change _ ∈ nhds (u+r • R (graphPoint (0 : Ambient d) 0)) at hf
  simpa only [hz,map_zero,smul_zero,add_zero] using hf
end N2Restriction
#print axioms N2Restriction.exists_open_chart_localization
#print axioms N2Restriction.affine_rectangle_mem_nhds
