import continuation.ComplementaryDensityV32
import Mathlib.Analysis.Normed.Operator.Basic

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal BigOperators

/-- On a ball of radius R, changing a projection by operator norm δ enlarges
its cross-sectional radius by at most δ R. -/
theorem perturbed_projection_cylinder_subset
    {E F : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    (P Q : E →L[ℝ] F) (z : F) (R w δ : ℝ) (hδ : 0 ≤ δ)
    (hPQ : ‖P - Q‖ ≤ δ) :
    closedBall (0 : E) R ∩ P ⁻¹' closedBall z w ⊆
      Q ⁻¹' closedBall z (w + δ * R) := by
  intro x hx
  have hxR : ‖x‖ ≤ R := by simpa using hx.1
  have hxw : ‖P x - z‖ ≤ w := by simpa [dist_eq_norm] using hx.2
  have hop := (P - Q).le_of_opNorm_le hPQ x
  have hnorm : ‖Q x - P x‖ ≤ δ * ‖x‖ := by
    simpa only [ContinuousLinearMap.sub_apply, norm_sub_rev] using hop
  have htri : ‖Q x - z‖ ≤ ‖Q x - P x‖ + ‖P x - z‖ := by
    simpa only [sub_add_sub_cancel] using norm_add_le (Q x - P x) (P x - z)
  change dist (Q x) z ≤ w + δ * R
  rw [dist_eq_norm]
  linarith [mul_le_mul_of_nonneg_left hxR hδ]

/-- The aperture restriction δ R ≤ w gives a uniform factor-two enlargement.
The scale condition is retained explicitly. -/
theorem perturbed_projection_cylinder_subset_double
    {E F : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    (P Q : E →L[ℝ] F) (z : F) (R w δ : ℝ) (hδ : 0 ≤ δ)
    (hPQ : ‖P - Q‖ ≤ δ) (hscale : δ * R ≤ w) :
    closedBall (0 : E) R ∩ P ⁻¹' closedBall z w ⊆
      Q ⁻¹' closedBall z (2 * w) := by
  exact (perturbed_projection_cylinder_subset P Q z R w δ hδ hPQ).trans
    (preimage_mono (closedBall_subset_closedBall (by linarith)))

/-- Weighted densities preserve containment, including countably many tubes. -/
theorem tubeDensity_mono_sets {X P : Type*} (U V : P → Set X) (e : P → ℝ≥0∞)
    (hUV : ∀ t, U t ⊆ V t) (x : X) : tubeDensity U e x ≤ tubeDensity V e x := by
  apply ENNReal.tsum_le_tsum
  intro t
  exact Set.indicator_le_indicator_of_subset (hUV t) (fun _ => zero_le _) x

/-- Restricting each tube to a common region commutes pointwise with density. -/
theorem tubeDensity_inter {X P : Type*} (U : P → Set X) (e : P → ℝ≥0∞)
    (S : Set X) (x : X) :
    tubeDensity (fun t => S ∩ U t) e x = S.indicator (tubeDensity U e) x := by
  classical
  by_cases hx : x ∈ S
  · simp only [tubeDensity, Set.indicator_of_mem hx]
    congr 1
    funext t
    by_cases ht : x ∈ U t <;> simp [ht, hx]
  · simp [tubeDensity, hx]

end N2Restriction

#print axioms N2Restriction.perturbed_projection_cylinder_subset
#print axioms N2Restriction.perturbed_projection_cylinder_subset_double
#print axioms N2Restriction.tubeDensity_inter
#print axioms N2Restriction.tubeDensity_mono_sets
