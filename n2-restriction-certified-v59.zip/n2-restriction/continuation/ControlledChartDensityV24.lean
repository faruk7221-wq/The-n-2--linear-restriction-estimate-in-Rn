import continuation.CompactChartDensityV24

namespace N2Restriction
open Metric MeasureTheory
open scoped NNReal ENNReal

/-- First and second derivative control gives a uniform compact bi-Lipschitz
chart radius. The constants are selected before the parametrization. -/
theorem uniform_controlled_chart_bilipschitz (d n : ℕ)
    {r M D : ℝ} (hr : 0 < r) (_hM : 0 ≤ M) (hD : 0 ≤ D) :
    ∃ ρ : ℝ, 0 < ρ ∧ ρ ≤ r ∧ ∃ L A : ℝ≥0, 0 < L ∧ 0 < A ∧
      ∀ φ : Ambient d → Ambient n,
        (∀ t ∈ closedBall 0 r, ContDiffAt ℝ (⊤ : ℕ∞) φ t) →
        (∀ t ∈ closedBall 0 r, ‖fderiv ℝ φ t‖ ≤ M) →
        (∀ t ∈ closedBall 0 r, ‖iteratedFDeriv ℝ 2 φ t‖ ≤ D) →
        (∀ v, ‖v‖ ≤ M * ‖fderiv ℝ φ 0 v‖) →
        LipschitzWith L (fun t : closedBall (0 : Ambient d) ρ => φ t) ∧
        AntilipschitzWith A (fun t : closedBall (0 : Ambient d) ρ => φ t) := by
  let M' := max M 1
  have hM' : 0 < M' := zero_lt_one.trans_le (le_max_right M 1)
  obtain ⟨ρ, hρ, hρr, hsmall⟩ := uniform_chart_separation_radius hr hM'.le hD
  let L : ℝ≥0 := ⟨M', hM'.le⟩
  let A : ℝ≥0 := ⟨2 * M', by positivity⟩
  refine ⟨ρ, hρ, hρr, L, A, hM', by change 0 < 2 * M'; positivity, ?_⟩
  intro φ hs hfirst hsecond hl
  have hsub : closedBall (0 : Ambient d) ρ ⊆ closedBall 0 r := closedBall_subset_closedBall hρr
  have hlow := chart_lower_distance_bound φ hρ.le hM'.le
    (fun t ht => hs t (hsub ht)) (fun t ht => hsecond t (hsub ht))
    (fun v => (hl v).trans (mul_le_mul_of_nonneg_right (le_max_left M 1) (norm_nonneg _))) hsmall
  constructor
  · apply LipschitzWith.of_dist_le_mul
    intro x y
    have hh := (convex_closedBall (0 : Ambient d) r).norm_image_sub_le_of_norm_fderiv_le
      (fun t ht => (hs t ht).differentiableAt (by simp)) hfirst (hsub y.property) (hsub x.property)
    change dist (φ x) (φ y) ≤ M' * dist (x : Ambient d) (y : Ambient d)
    rw [dist_eq_norm, dist_eq_norm]
    exact hh.trans (mul_le_mul_of_nonneg_right (le_max_left M 1) (norm_nonneg _))
  · apply AntilipschitzWith.of_le_mul_dist
    intro x y
    exact hlow x x.property y y.property

/-- Uniformly controlled immersions have uniformly bounded coordinate
surface densities after one common shrinking. This is an actual measure
identity on each compact chart image. -/
theorem uniform_controlled_chart_surface_density (d n : ℕ)
    {r M D : ℝ} (hr : 0 < r) (hM : 0 ≤ M) (hD : 0 ≤ D) :
    ∃ ρ : ℝ, 0 < ρ ∧ ρ ≤ r ∧ ∃ c C : ℝ≥0, 0 < c ∧
      ∀ φ : Ambient d → Ambient n,
        (∀ t ∈ closedBall 0 r, ContDiffAt ℝ (⊤ : ℕ∞) φ t) →
        (∀ t ∈ closedBall 0 r, ‖fderiv ℝ φ t‖ ≤ M) →
        (∀ t ∈ closedBall 0 r, ‖iteratedFDeriv ℝ 2 φ t‖ ≤ D) →
        (∀ v, ‖v‖ ≤ M * ‖fderiv ℝ φ 0 v‖) →
        let K := closedBall (0 : Ambient d) ρ
        let μ := (volume : Measure (Ambient d)).comap (Subtype.val : K → Ambient d)
        ∃ J : K → ℝ≥0, Measurable J ∧ (∀ᵐ t ∂μ, c ≤ J t ∧ J t ≤ C) ∧
          (μ.withDensity (fun t => (J t : ℝ≥0∞))).map (fun t : K => φ t) =
            (Measure.hausdorffMeasure (d : ℝ)).restrict (φ '' K) := by
  obtain ⟨ρ, hρ, hρr, L, A, _, hA, hb⟩ := uniform_controlled_chart_bilipschitz d n hr hM hD
  refine ⟨ρ, hρ, hρr, (A ^ d)⁻¹ * coordinateHausdorffFactor d,
    L ^ d * coordinateHausdorffFactor d, mul_pos (inv_pos.mpr (pow_pos hA _))
      (coordinateHausdorffFactor_pos d), ?_⟩
  intro φ hs hfirst hsecond hl
  obtain ⟨hLip, hAnti⟩ := hb φ hs hfirst hsecond hl
  obtain ⟨J, hJ, hbound, _, hmap⟩ := exists_compact_chart_surface_density
    (closedBall (0 : Ambient d) ρ) (isCompact_closedBall _ _) _ hA hLip hAnti
  refine ⟨J, hJ, hbound, ?_⟩
  convert hmap using 2
  ext x
  simp

end N2Restriction

#print axioms N2Restriction.uniform_controlled_chart_bilipschitz
#print axioms N2Restriction.uniform_controlled_chart_surface_density
