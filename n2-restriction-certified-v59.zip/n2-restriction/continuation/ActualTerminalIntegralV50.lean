import continuation.ActualTerminalMajorantV50
import continuation.AtlasBallMeasurableV50
namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal

/-- Integrate the true original selected product against the actual Fnt and
Ftan. The rapid error is paid only once on the physical region. -/
theorem actual_terminal_integral_majorant {d k L : ℕ} {S : Fin k → SmoothPatch (d+1)}
    (A : (i : Fin k) → PacketGraphAtlas (S i)) {r : ℝ}
    (Q : (i : Fin k) → (j : Fin (A i).size) → CoordinateCapFamily ((A i).patch j).support r)
    (hr : 0 < r) (hsmall : ∀ i, r ≤ (A i).capRadius)
    (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure)
    (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin d → ℤ))
    (Z : Set (Ambient (d+1))) (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1)))
    (c : Fin L → Ambient (d+1)) (ρ b C₀ R w : ℝ) (Ω : Set (Ambient (d+1)))
    {p δ : ℝ} (hp : 0 < p) (hp1 : p ≤ 1)
    (hcover : Ω ⊆ ⋃ l, ball (c l) ρ)
    (herror : ∀ l x, x ∈ Ω ∩ ball (c l) ρ →
      ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
          (fun i => (A i).cellInput (Q i) hr (f i) (U i)) x -
        extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
          (fun i => (A i).cellInput (Q i) hr (f i)
            ((A i).actualRetainedSelection (Q i) (U i) (c l) ρ R w Ω)) x‖ ≤ δ)
    (hΩ : MeasurableSet Ω) :
    (∫⁻ x in Ω, ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
      (fun i => (A i).cellInput (Q i) hr (f i) (U i)) x‖ₑ^p) ≤
      (∫⁻ x, (atlasBallProductSum A Q hr f
        (fun l i => (A i).actualNontangentSelection (Q i) (U i) Z T (c l) ρ b C₀ R w Ω) c ρ Ω x)^p) + (∫⁻ x, (actualTangentSum A Q hr f U Z T c ρ b C₀ R w Ω x)^p) +
      (ENNReal.ofReal δ)^p*volume Ω := by
  let Fnt := atlasBallProductSum A Q hr f
        (fun l i => (A i).actualNontangentSelection (Q i) (U i) Z T (c l) ρ b C₀ R w Ω) c ρ Ω
  let Ftan := actualTangentSum A Q hr f U Z T c ρ b C₀ R w Ω
  have hn : Measurable Fnt := measurable_atlasBallProductSum A Q hr hsmall f _ c ρ Ω hΩ
  have ht : Measurable Ftan := measurable_actualTangentSum A Q hr hsmall f U Z T c ρ b C₀ R w Ω hΩ
  change _ ≤ (∫⁻ x, (Fnt x)^p)+(∫⁻ x, (Ftan x)^p)+(ENNReal.ofReal δ)^p*volume Ω
  calc
    _ ≤ ∫⁻ x in Ω, ((Fnt x)^p+(Ftan x)^p)+(ENNReal.ofReal δ)^p := by
      apply setLIntegral_mono' hΩ
      intro x hx
      exact actual_terminal_power_majorant A Q hr hsmall f U Z T c ρ b C₀ R w Ω hp hp1 hcover herror x hx
    _ = ((∫⁻ x in Ω, (Fnt x)^p)+(∫⁻ x in Ω, (Ftan x)^p))+(ENNReal.ofReal δ)^p*volume Ω := by
      rw [lintegral_add_left ((hn.pow_const p).add (ht.pow_const p)),
        lintegral_add_left (hn.pow_const p),setLIntegral_const]
    _ ≤ _ := by
      gcongr
      · exact Measure.restrict_le_self
      · exact Measure.restrict_le_self

end N2Restriction
#print axioms N2Restriction.actual_terminal_integral_majorant
