import continuation.SeparatedBallOverlapV47
import continuation.TerminalAngularScalesV46

namespace N2Restriction
open Set Metric

/-- A b-cube meets only boundedly many separated rho-balls when b<=rho.
This is the cube/ball multiplicity used when summing (7.13). -/
theorem cube_meeting_balls_card {n L : ℕ} {ρ θ b : ℝ}
    (hρ : 0 < ρ) (hθ : 0 < θ) (hb : 0 ≤ b) (hbρ : b ≤ ρ)
    (c : Fin L → Ambient n)
    (hsep : ∀ l t, l ≠ t → 2*(θ*ρ) ≤ dist (c l) (c t)) (q : Ambient n)
    [DecidablePred (fun l => (gridCube q b ∩ ball (c l) ρ).Nonempty)] :
    (Fintype.card {l : Fin L // (gridCube q b ∩ ball (c l) ρ).Nonempty} : ℝ) ≤
      ((1+Real.sqrt n/2)/θ+1)^n := by
  classical
  let J := {l : Fin L // (gridCube q b ∩ ball (c l) ρ).Nonempty}
  have hcover (l : J) : dist (c l.val) q ≤ ((1+Real.sqrt n/2)/θ)*(θ*ρ) := by
    obtain ⟨x,hxq,hxc⟩ := l.property
    have hx := gridCube_subset_ball q hb hxq
    change dist x q ≤ _ at hx
    have hc : dist (c l.val) x ≤ ρ := by simpa only [dist_comm] using hxc.le
    have ht := dist_triangle (c l.val) x q
    have hm := mul_le_mul_of_nonneg_left hbρ (Real.sqrt_nonneg (n : ℝ))
    have he : ((1+Real.sqrt n/2)/θ)*(θ*ρ) = (1+Real.sqrt n/2)*ρ := by field_simp
    rw [he]
    nlinarith
  have hh := separated_representatives_card_bound (fun l : J => c l.val)
    (fun _ : Fin 1 => q) (mul_pos hθ hρ)
    (by positivity : 0 ≤ (1+Real.sqrt n/2)/θ)
    (fun l t hlt => hsep l.val t.val (fun he => hlt (Subtype.ext he)))
    (fun l => ⟨0,hcover l⟩)
  simpa only [Nat.cast_one,one_mul] using hh

/-- The same uniform cube/ball multiplicity at the actual terminal scales. -/
theorem eventually_terminal_cube_ball_overlap {n : ℕ} {τ lam θ : ℝ}
    (hτ : τ < 1/4) (hlam : 0 < lam) (hθ : 0 < θ) :
    ∀ᶠ R : ℝ in Filter.atTop, ∀ (L : ℕ) (c : Fin L → Ambient n),
      (∀ l t, l ≠ t → 2*(θ*(R^(1-τ))) ≤ dist (c l) (c t)) →
      ∀ q : Ambient n,
      ∀ [DecidablePred (fun l => (gridCube q (lam*R^(1/2+τ)) ∩ ball (c l) (R^(1-τ))).Nonempty)],
      (Fintype.card {l : Fin L // (gridCube q (lam*R^(1/2+τ)) ∩ ball (c l) (R^(1-τ))).Nonempty} : ℝ) ≤
        ((1+Real.sqrt n/2)/θ+1)^n := by
  filter_upwards [eventually_terminal_width_le_radius hτ lam,
    Filter.eventually_gt_atTop (0 : ℝ)] with R hwidth hR
  intro L c hsep q inst
  exact cube_meeting_balls_card (Real.rpow_pos_of_pos hR _) hθ
    (mul_nonneg hlam.le (Real.rpow_nonneg hR.le _)) hwidth c hsep q

end N2Restriction
#print axioms N2Restriction.cube_meeting_balls_card
#print axioms N2Restriction.eventually_terminal_cube_ball_overlap
