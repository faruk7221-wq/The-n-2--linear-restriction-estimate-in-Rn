import continuation.FiniteIncidenceCountV47
import continuation.ActualNontangentMultiplicityV46

namespace N2Restriction
open Set Metric
open scoped ENNReal

/-- The geometric nontangent multiplicity bounds the exact incidence sum
used by the original-packet energy estimate. -/
theorem PacketGraphAtlas.actual_nontangent_incidence {d M : ℕ}
    {S : SmoothPatch (d+1)} (A : PacketGraphAtlas S)
    {I : Type*} [Fintype I] (Z : Set (Ambient (d+1)))
    (T : Ambient (d+1) → Submodule ℝ (Ambient (d+1)))
    {K C₀ b ρ θ R w r : ℝ} (hK : 0 ≤ K) (hC₀ : 0 ≤ C₀)
    (hb : 0 < b) (hρ : 0 < ρ) (hθ : 0 < θ) (hR : 0 ≤ R) (hw : w ≤ b)
    (hexternal : UniformAlgebraicTubeCoverInput Z T M K)
    (Q : (j : Fin A.size) → CoordinateCapFamily (A.patch j).support r)
    (x : I → Ambient (d+1))
    (hsep : ∀ i l, i ≠ l → 2*(θ*ρ) ≤ dist (x i) (x l))
    (U : I → (j : Fin A.size) → (Q j).centers → Set (Fin d → ℤ))
    (hnontan : ∀ i j a ν, ν ∈ U i j a →
      ¬ PacketTangentInBall Z (A.originalPacketTube j a r ν R w)
        T (A.cellAxisDirection j a) (x i) ρ b C₀) :
    ∀ j a ν, (∑' i, (U i j a).indicator (fun _ => (1 : ENNReal)) ν) ≤
      ENNReal.ofReal (M * ((K*(C₀+1)+2)/θ+1)^(d+1)) := by
  classical
  intro j a ν
  let J := {i : I // ν ∈ U i j a}
  have hc := A.actual_nontangent_ball_multiplicity (I := J) Z T hK hC₀ hb hρ hθ hR hw
    hexternal j a ((Q j).centers_mem a.property) r ν (fun i => x i.val)
    (fun i l hil => hsep i.val l.val (fun h => hil (Subtype.ext h)))
    (fun i => hnontan i.val j a ν i.property)
  rw [finite_packet_incidence_count]
  simpa only [ENNReal.ofReal_natCast] using ENNReal.ofReal_le_ofReal hc

end N2Restriction
#print axioms N2Restriction.PacketGraphAtlas.actual_nontangent_incidence
