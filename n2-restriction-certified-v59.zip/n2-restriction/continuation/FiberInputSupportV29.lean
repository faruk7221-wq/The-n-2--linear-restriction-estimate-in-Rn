import continuation.FiberInputNormsV29

namespace N2Restriction
open MeasureTheory Set Metric
open scoped NNReal ENNReal

namespace StripChartAmplitude
variable {n : ℕ} {S : SmoothPatch n} {Q : Ambient n →L[ℝ] ℝ × ℝ} {z : Ambient n}
  {δ r ρ s : ℝ} {B : ℕ → ℝ} {c C : ℝ≥0} {L α β ε : ℝ}
  {F : MeasuredTubularChart S Q z δ r ρ s B c C L}
  {E : ChartNormalCoordinates F α β}
  {g : Lp ℂ 2 ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier)}

/-- Every actual L2 fiber input has essential support in the same fixed thin
ball. This also holds for exceptional fibers, which were assigned zero. -/
theorem fiberInput_thin_support (A : StripChartAmplitude F E g ε) (u : ℝ × ℝ) :
    HasFrequencySupport volume id (closedBall (0 : Ambient (n - 3)) ((L + 1) * ρ)) (A.fiberInput u) := by
  classical
  by_cases hm : MemLp (A.fiberAmplitude u) 2 volume
  · rw [fiberInput, dif_pos hm]
    filter_upwards [MemLp.coeFn_toLp hm] with v hv hn
    have hi : A.input (E.equiv.symm (u, v)) ≠ 0 := by
      intro hz
      exact hn (hv.trans (by simp [fiberAmplitude, hz]))
    exact mem_closedBall_zero_iff.mpr (A.coordinate_support hi).2
  · rw [fiberInput, dif_neg hm]
    filter_upwards [Lp.coeFn_zero (E := ℂ) (p := (2 : ℝ≥0∞))
      (μ := (volume : Measure (Ambient (n - 3))))] with v hv hn
    exact (hn hv).elim

/-- The normal-parameter integral of the actual fiber extensions is a genuine
integrable complex function at every physical point. -/
theorem fiber_extension_integrable (A : StripChartAmplitude F E g ε) (x : Ambient n) :
    Integrable (fun u => extension volume (fun v => F.param (E.equiv.symm (u, v))) (A.fiberInput u) x) := by
  let f : Ambient (n - 1) → ℂ := fun t =>
    A.weight t • (Complex.exp ((inner ℝ x (F.param t) : ℂ) * Complex.I) * A.input t)
  have hi : Integrable f := (A.extension_identity x).1
  have hp := (integrable_linear_coordinates_iff E.equiv volume (volume.prod volume) f).mpr hi
  have hout := hp.integral_prod_left
  apply hout.congr
  filter_upwards [A.fiberInput_coe_ae] with u hu
  symm
  apply integral_congr_ae
  filter_upwards [hu] with v hv
  rw [hv]
  exact mul_smul_comm _ _ _

end StripChartAmplitude
end N2Restriction

#print axioms N2Restriction.StripChartAmplitude.fiberInput_thin_support
#print axioms N2Restriction.StripChartAmplitude.fiber_extension_integrable
