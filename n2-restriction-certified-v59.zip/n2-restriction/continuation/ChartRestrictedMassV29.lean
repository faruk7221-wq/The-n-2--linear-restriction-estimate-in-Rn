import continuation.CompactFrameStripV29
import continuation.CoordinateStripVolumeV29

namespace N2Restriction
open MeasureTheory Set Metric
open scoped NNReal ENNReal

/-- A bounded coordinate density controls the mass of every measurable
physical subset by the volume of its actual parameter preimage. -/
theorem chart_restricted_mass_le {d n : ℕ}
    (K : Set (Ambient d)) (hK : MeasurableSet K)
    (φ : Ambient d → Ambient n) (hφ : Measurable (fun t : K => φ t))
    (J : K → ℝ≥0) (C : ℝ≥0)
    (hC : ∀ᵐ t ∂(volume : Measure (Ambient d)).comap Subtype.val, J t ≤ C)
    (ν : Measure (Ambient n))
    (hpush : (((volume : Measure (Ambient d)).comap Subtype.val).withDensity
      (fun t => (J t : ℝ≥0∞))).map (fun t : K => φ t) = ν)
    (T : Set (Ambient n)) (hT : MeasurableSet T) :
    ν T ≤ (C : ℝ≥0∞) * (volume : Measure (Ambient d)) {t ∈ K | φ t ∈ T} := by
  let μ := (volume : Measure (Ambient d)).comap (Subtype.val : K → Ambient d)
  have hle : μ.withDensity (fun t => (J t : ℝ≥0∞)) ≤ (C : ℝ≥0∞) • μ := by
    rw [← withDensity_const]
    apply withDensity_mono
    filter_upwards [hC] with t ht
    exact_mod_cast ht
  rw [← hpush, Measure.map_apply hφ hT]
  refine (hle _).trans_eq ?_
  rw [Measure.smul_apply, smul_eq_mul]
  congr 1
  dsimp [μ]
  rw [(MeasurableEmbedding.subtype_coe hK).comap_apply]
  congr 1
  ext t
  simp only [mem_image, mem_preimage, mem_setOf_eq, Subtype.exists]
  constructor
  · rintro ⟨u, hu, hTu, rfl⟩
    exact ⟨hu, hTu⟩
  · rintro ⟨ht, hTt⟩
    exact ⟨t, ht, hTt, rfl⟩

/-- Quadratic physical strip mass on the same measured surface chart, retaining
the exact Haar factor and fixed thin-coordinate ball. -/
theorem MeasuredTubularChart.frame_strip_mass_le {n : ℕ} {S : SmoothPatch n}
    {Q : Ambient n →L[ℝ] ℝ × ℝ} {z : Ambient n} {δ r ρ s : ℝ}
    {B : ℕ → ℝ} {c C : ℝ≥0} {L α β : ℝ}
    (F : MeasuredTubularChart S Q z δ r ρ s B c C L)
    (hn : 1 ≤ n) (hρ : ρ ≤ r) (E : ChartNormalCoordinates F α β) (ε : ℝ) :
    ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier)
      {y ∈ F.carrier | ‖Q (S.normal y)‖ ≤ ε} ≤
      (C : ℝ≥0∞) * ((coordinateMeasureFactor E.equiv volume (volume.prod volume) : ℝ≥0∞) *
        (ENNReal.ofReal (2 * ε) ^ 2 *
          (volume : Measure (Ambient (n - 3))) (closedBall 0 ((L + 1) * ρ)))) := by
  let K := closedBall (0 : Ambient (n - 1)) ρ
  have hφ : Measurable (fun t : K => F.param t) := by
    apply Continuous.measurable
    exact continuousOn_iff_continuous_restrict.mp (fun t ht =>
      (F.bounds t (closedBall_subset_closedBall hρ ht)).2.2.1.continuousAt.continuousWithinAt)
  obtain ⟨J, _, hJ, hpush⟩ := F.density
  have hd : ((n - 1 : ℕ) : ℝ) = (n : ℝ) - 1 := by simp [Nat.cast_sub hn]
  rw [hd] at hpush
  have hh := chart_restricted_mass_le K isClosed_closedBall.measurableSet F.param hφ J C
    (hJ.mono fun _ h => h.2) _ hpush _ (F.compact_frame_strip hρ ε).measurableSet
  have heq : {t ∈ K | F.param t ∈ {y ∈ F.carrier | ‖Q (S.normal y)‖ ≤ ε}} =
      {t ∈ closedBall (0 : Ambient (n - 1)) ρ | ‖Q (S.normal z) + (E.equiv t).1‖ ≤ ε} := by
    ext t
    constructor
    · rintro ⟨ht, _, hs⟩
      refine ⟨ht, ?_⟩
      simpa only [E.normal_eq, (F.bounds t (closedBall_subset_closedBall hρ ht)).2.1] using hs
    · rintro ⟨ht, hs⟩
      refine ⟨ht, ⟨t, ht, rfl⟩, ?_⟩
      simpa only [E.normal_eq, (F.bounds t (closedBall_subset_closedBall hρ ht)).2.1] using hs
  rw [heq] at hh
  exact hh.trans (mul_le_mul_left' (coordinate_strip_volume_le E.equiv E.norm_le
    (Q (S.normal z)) ρ ε) _)

end N2Restriction

#print axioms N2Restriction.MeasuredTubularChart.frame_strip_mass_le
#print axioms N2Restriction.chart_restricted_mass_le
