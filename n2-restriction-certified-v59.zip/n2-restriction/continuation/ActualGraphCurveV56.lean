import continuation.GraphTangentLiftV56
import continuation.SmoothGraphGermV56
namespace N2Restriction
open Set Filter
set_option maxHeartbeats 1200000

/-- Construct an actual smooth curve inside an existing regular graph chart,
with any prescribed surface tangent as its velocity. The horizontal path is
a straight line in that full chart, so this curve is compatible with slicing. -/
theorem SmoothPatch.exists_actual_graph_curve {d : ℕ} (S : SmoothPatch (d+1))
    (A : Ambient (d+1) ≃ₗᵢ[ℝ] Ambient (d+1)) {U : Set (Ambient d)} (hU : IsOpen U)
    {φ : Ambient d → ℝ} (hφ : ContDiffOn ℝ (⊤ : ℕ∞) φ U)
    (hgraph : ∀ u ∈ U, A (graphPoint u (φ u)) ∈ S.extendedSurface)
    {u : Ambient d} (hu : u ∈ U) (w : Ambient (d+1))
    (ht : inner ℝ (S.normal (A (graphPoint u (φ u)))) w = 0)
    (hv : fderiv ℝ S.defining (A (graphPoint u (φ u)))
      (A (graphPoint (0 : Ambient d) 1)) ≠ 0) :
    ∃ (Φ : Ambient d → ℝ) (g : ℝ → Ambient (d+1)),
      ContDiff ℝ (⊤ : ℕ∞) Φ ∧ Φ =ᶠ[nhds u] φ ∧
      (∀ t, g t = A (graphPoint (u+t • graphProjection (A.symm w))
        (Φ (u+t • graphProjection (A.symm w))))) ∧
      ContDiff ℝ (⊤ : ℕ∞) g ∧ g 0 = A (graphPoint u (φ u)) ∧ deriv g 0 = w ∧
      ∀ᶠ t in nhds (0 : ℝ), g t ∈ S.extendedSurface := by
  obtain ⟨Φ,hΦ,heq⟩ := exists_smooth_graph_germ hU hφ hu
  let v := graphProjection (A.symm w)
  let l : ℝ → Ambient d := fun t => u+t • v
  let g : ℝ → Ambient (d+1) := fun t => A (graphPoint (l t) (Φ (l t)))
  have hl : ContDiff ℝ (⊤ : ℕ∞) l := contDiff_const.add (contDiff_id.smul contDiff_const)
  have hg : ContDiff ℝ (⊤ : ℕ∞) g :=
    A.contDiff.comp (graphPointCLM.contDiff.comp (hl.prodMk (hΦ.comp hl)))
  have hl0 : l 0 = u := by simp [l]
  have hnear : Filter.Tendsto l (nhds (0 : ℝ)) (nhds u) := by
    simpa only [hl0] using hl.continuous.continuousAt.tendsto (x := (0 : ℝ))
  refine ⟨Φ,g,hΦ,heq,fun _ => rfl,hg,?_,?_,?_⟩
  · change A (graphPoint (l 0) (Φ (l 0))) = _
    rw [hl0,heq.self_of_nhds]
  · change deriv (fun t : ℝ => A (graphPoint (u+t • v) (Φ (u+t • v)))) 0 = w
    rw [rotated_graph_line_derivative A Φ hΦ u v,heq.fderiv_eq]
    exact S.graph_tangent_lift A hU hφ hgraph hu w ht hv
  · filter_upwards [hnear.eventually (hU.mem_nhds hu),hnear.eventually heq] with t htU htΦ
    change A (graphPoint (l t) (Φ (l t))) ∈ _
    rw [htΦ]
    exact hgraph (l t) htU
end N2Restriction
#print axioms N2Restriction.SmoothPatch.exists_actual_graph_curve
