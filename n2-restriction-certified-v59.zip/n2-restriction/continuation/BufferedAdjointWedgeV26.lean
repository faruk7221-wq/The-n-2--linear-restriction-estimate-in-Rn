import continuation.UniformAdjointWedgeV26

namespace N2Restriction
open Metric

theorem geometric_buffered_adjoint_wedge_stability {k : ℕ} (hk : 0 < k)
    (S : Fin k → SmoothPatch (k + 2)) {ν κ : ℝ}
    (hgeo : GeometricHypotheses S ν κ) :
    ∃ η c : ℝ, 0 < η ∧ 0 < c ∧
      ∀ (z : Fin k → Ambient (k + 2)), (∀ j, z j ∈ (S j).support) →
      ∀ i q, q ∈ orthonormalPairSet (k + 2) →
        ‖(commonTangent (fun j => (S j).normal (z j))).starProjection - pairProjection q‖ *
          ‖(S i).shape (z i)‖ ≤ κ / 2 →
      ∀ (y : Fin k → Ambient (k + 2)),
        (∀ j, y j ∈ (S j).extendedSurface ∧ dist (y j) (z j) ≤ η) →
        c ≤ Matrix.det (Matrix.gram ℝ (adjointWedgeVectors S y i q)) := by
  classical
  obtain ⟨η, hη, K, hK, hsub, hin, hbuf⟩ := uniform_compact_surface_buffers S
  obtain ⟨c, hc, hw⟩ := geometric_adjoint_wedge_uniform_supported_all_indices hk S hgeo
  let T := fun i => (S i).withSupport (K i) (hK i) (hin i)
  letI : CompactSpace (TupleWedgeBase T) :=
    isCompact_iff_compactSpace.mp (isCompact_tupleWedgeBaseSet T)
  let F := fun i (r : TupleWedgeBase T) =>
    Matrix.det (Matrix.gram ℝ (tupleAdjointVectors T i r))
  have hF : ∀ i, Continuous (F i) := by
    intro i
    apply Continuous.matrix_det
    refine continuous_pi fun a => continuous_pi fun b => ?_
    exact ((continuous_apply a).comp (continuous_tupleAdjointVectors T i)).inner
      ((continuous_apply b).comp (continuous_tupleAdjointVectors T i))
  choose δ hδ hstab using fun i => compact_positive_bound_stability (hF i) hc
  have hne : (Finset.univ : Finset (Fin k)).Nonempty :=
    ⟨⟨0, hk⟩, Finset.mem_univ _⟩
  let ε := min η (Finset.univ.inf' hne δ)
  have hε : 0 < ε := lt_min hη ((Finset.lt_inf'_iff _).2 (fun i _ => hδ i))
  refine ⟨ε, c / 2, hε, by positivity, ?_⟩
  intro z hz i q hq hgap y hy
  have hzK : ∀ j, z j ∈ (T j).support := fun j => hsub j (hz j)
  have hyK : ∀ j, y j ∈ (T j).support := fun j =>
    hbuf j (z j) (hz j) (y j) (hy j).1 ((hy j).2.trans (min_le_left _ _))
  let p : TupleWedgeBase T := ⟨(z, (q, q)), ⟨hzK, hq, hq⟩⟩
  let p' : TupleWedgeBase T := ⟨(y, (q, q)), ⟨hyK, hq, hq⟩⟩
  have hp : c ≤ F i p := hw i z hz q hq hgap
  have hdist : dist p p' ≤ δ i := by
    have hzdist : dist z y ≤ ε := by
      apply (dist_pi_le_iff hε.le).mpr
      intro j
      simpa only [dist_comm] using (hy j).2
    have hd : dist p p' = dist z y := by
      simp [p, p', Subtype.dist_eq, Prod.dist_eq]
    rw [hd]
    exact hzdist.trans ((min_le_right _ _).trans (Finset.inf'_le _ (Finset.mem_univ i)))
  exact hstab i p p' hp hdist


end N2Restriction

#print axioms N2Restriction.geometric_buffered_adjoint_wedge_stability
