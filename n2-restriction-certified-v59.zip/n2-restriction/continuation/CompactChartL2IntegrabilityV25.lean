import continuation.SurfaceIntegralSlicingV25

namespace N2Restriction
open MeasureTheory
open scoped ENNReal NNReal

/-- The bounded coordinate density on a compact chart defines a finite
measure, even if its bounds hold only almost everywhere. -/
theorem compact_chart_density_finite {d : ℕ}
    (K : Set (Ambient d)) (hK : IsCompact K) (J : K → ℝ≥0) (C : ℝ≥0)
    (hC : ∀ᵐ x ∂(volume : Measure (Ambient d)).comap Subtype.val, J x ≤ C) :
    IsFiniteMeasure (((volume : Measure (Ambient d)).comap Subtype.val).withDensity
      (fun x => (J x : ℝ≥0∞))) := by
  let μ := (volume : Measure (Ambient d)).comap (Subtype.val : K → Ambient d)
  have hv := hK.isClosed.isClosedEmbedding_subtypeVal.measurableEmbedding
  have hμ : μ Set.univ < ∞ := by
    dsimp [μ]
    rw [hv.comap_apply]
    simpa using hK.measure_lt_top (μ := (volume : Measure (Ambient d)))
  letI : IsFiniteMeasure μ := ⟨hμ⟩
  have hh : μ.withDensity (fun x => (J x : ℝ≥0∞)) ≤ (C : ℝ≥0∞) • μ := by
    rw [← withDensity_const]
    apply withDensity_mono
    filter_upwards [hC] with x hx
    exact_mod_cast hx
  letI : IsFiniteMeasure ((C : ℝ≥0∞) • μ) := inferInstanceAs (IsFiniteMeasure (C • μ))
  exact isFiniteMeasure_of_le ((C : ℝ≥0∞) • μ) hh

/-- Surface L2 inputs on a measured compact chart are integrable, supplying the
integrability hypothesis for the complex-valued Fubini formula. -/
theorem measured_compact_chart_L2_integrable {d n : ℕ}
    (K : Set (Ambient d)) (hK : IsCompact K) (φ : K → Ambient n)
    (J : K → ℝ≥0) (C : ℝ≥0)
    (hC : ∀ᵐ x ∂(volume : Measure (Ambient d)).comap Subtype.val, J x ≤ C)
    (hpush : (((volume : Measure (Ambient d)).comap Subtype.val).withDensity
      (fun x => (J x : ℝ≥0∞))).map φ =
        (Measure.hausdorffMeasure (d : ℝ)).restrict (Set.range φ))
    (g : Ambient n → ℂ)
    (hg : MemLp g 2 ((Measure.hausdorffMeasure (d : ℝ)).restrict (Set.range φ))) :
    Integrable g ((Measure.hausdorffMeasure (d : ℝ)).restrict (Set.range φ)) := by
  letI := compact_chart_density_finite K hK J C hC
  have hfin : IsFiniteMeasure ((Measure.hausdorffMeasure (d : ℝ)).restrict (Set.range φ)) := by
    rw [← hpush]
    infer_instance
  letI := hfin
  exact hg.integrable (by norm_num)

end N2Restriction

#print axioms N2Restriction.compact_chart_density_finite
#print axioms N2Restriction.measured_compact_chart_L2_integrable
