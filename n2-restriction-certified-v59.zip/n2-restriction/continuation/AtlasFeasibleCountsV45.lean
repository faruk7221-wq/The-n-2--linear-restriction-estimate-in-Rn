import continuation.AtlasNearPlaneRankV45
import continuation.TrimmedNontangentCellsV38

namespace N2Restriction
open Set Metric

/-- Equation (6.5) for actual selected atlas packets. The angular threshold
is fixed before the cap scale, plane, and selection. -/
theorem atlas_feasible_near_far_counts {k : ℕ} (S : Fin k → SmoothPatch (k+2))
    (T : (i : Fin k) → PacketGraphAtlas (S i))
    {ν κ : ℝ} (hgeo : GeometricHypotheses S ν κ) :
    ∃ γ₀ : ℝ, 0 < γ₀ ∧ ∀ {r γ : ℝ}, γ ≤ γ₀ →
      ∀ (Q : (i : Fin k) → (j : Fin (T i).size) →
        CoordinateCapFamily ((T i).patch j).support r)
      (A : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin (k+1) → ℤ)),
      (∀ i, ∃ j a ν, ν ∈ A i j a) →
      ∀ (V : Submodule ℝ (Ambient (k+2))) (far : Finset (Fin k)),
      (∀ i, i ∉ far → ∀ j a ν, ν ∈ A i j a →
        directionPlaneAngle ((T i).cellAxisDirection j a.val) V ≤ 4*γ) →
      k ≤ Module.finrank ℝ V + far.card := by
  classical
  obtain ⟨ε, hε, he⟩ := atlas_near_plane_rank S T hgeo
  refine ⟨ε/8, by positivity, ?_⟩
  intro r γ hγ Q A hnon V far hnear
  choose j a ν hν using hnon
  have hrank := he j (fun i => (a i).val)
    (fun i => (Q i (j i)).centers_mem (a i).property) V farᶜ
  have hcount : farᶜ.card ≤ Module.finrank ℝ V := hrank (by
    intro i hi
    have h := hnear i (Finset.mem_compl.mp hi) (j i) (a i) (ν i) (hν i)
    change ‖V.starProjection _ - _‖ < ε
    rw [norm_sub_rev]
    change directionPlaneAngle _ V < ε
    linarith)
  have hcard := Finset.card_compl_add_card far
  simp only [Fintype.card_fin] at hcard
  omega

end N2Restriction
#print axioms N2Restriction.atlas_feasible_near_far_counts
