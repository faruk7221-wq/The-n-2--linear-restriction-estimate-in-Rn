import continuation.MulticapHilbertBudgetV41

namespace N2Restriction
open MeasureTheory UnitAddTorus
open scoped BigOperators ENNReal
noncomputable local instance actualCellCircleMeasure : MeasureSpace UnitAddCircle := ⟨AddCircle.haarAddCircle⟩

/-- Cell energy for actual graph packets across all caps. Fourier
normalization cancels exactly: only overlap and incidence multiply the
original cap-input energy, with no scale-dependent loss. -/
theorem actual_multicap_cell_budget {d : ℕ} {C J : Type*} [Fintype J]
    (c : J → Ambient d) (r : ℝ) (hr : 0 < r)
    (f : (j : J) → Lp ℂ 2 (volume.restrict (packetFrequencyCube (c j) r hr)))
    (S : C → J → Set (Fin d → ℤ)) {M : ℝ} (hM : 0 ≤ M)
    (hoverlap : ∀ᵐ y ∂(volume : Measure (Ambient d)),
      (∑ j, (Metric.ball (c j) (2*r)).indicator (fun _ => (1 : ℝ)) y) ≤ M)
    (N E₀ : ENNReal)
    (hincidence : ∀ j ν, (∑' a, (S a j).indicator (fun _ => (1 : ENNReal)) ν) ≤ N)
    (henergy : (∑ j, ENNReal.ofReal (‖f j‖^2)) ≤ E₀) :
    (∑' a, ENNReal.ofReal (‖∑ j, ∑' ν : S a j,
      actualPacketInput (c j) r hr (f j) ν.val‖^2)) ≤ ENNReal.ofReal M * N * E₀ := by
  let u := (2*Real.pi)^((d : ℝ)/2)
  let v := (2*Real.pi)^(-(d : ℝ)/2)
  have hv : 0 ≤ v := Real.rpow_nonneg (by positivity) _
  have huv : u*v = 1 := by
    dsimp [u,v]
    rw [← Real.rpow_add (by positivity : 0 < 2*Real.pi)]
    ring_nf
    simp
  have henergy' : (∑ j, ENNReal.ofReal (‖packetTorusInput (c j) r hr (f j)‖^2)) ≤
      ENNReal.ofReal (v^2)*E₀ := by
    simp_rw [packetTorusInput_norm, mul_pow, ENNReal.ofReal_mul (sq_nonneg _)]
    rw [← Finset.mul_sum]
    exact mul_le_mul_left' henergy _
  have hs : ∀ j ν, HasFrequencySupport volume id (Metric.ball (c j) (2*r))
      (actualPacketSynthesis (c j) r hr
        (mFourierBasis.repr (packetTorusInput (c j) r hr (f j)) ν • mFourierBasis ν)) := by
    intro j ν
    simpa only [actualPacketInput_eq_synthesis, mFourierBasis_repr, coe_mFourierBasis] using
      actualPacketInput_support (c j) r hr (f j) ν
  have h := multicap_hilbert_cell_budget volume (fun j => Metric.ball (c j) (2*r))
    (fun _ => measurableSet_ball) mFourierBasis (fun j => actualPacketSynthesis (c j) r hr)
    (fun j => packetTorusInput (c j) r hr (f j)) S hs hM hoverlap
    (fun j => actualPacketSynthesis_norm_le (c j) r hr) N (ENNReal.ofReal (v^2)*E₀)
    hincidence henergy'
  have hcancel : ENNReal.ofReal (u^2) * ENNReal.ofReal (v^2) = 1 := by
    rw [← ENNReal.ofReal_mul (sq_nonneg _), ← mul_pow, huv]
    norm_num
  have he : ENNReal.ofReal M * (ENNReal.ofReal (u^2)*N) * (ENNReal.ofReal (v^2)*E₀) =
      ENNReal.ofReal M*N*E₀ := by
    calc
      _ = (ENNReal.ofReal (u^2)*ENNReal.ofReal (v^2))*(ENNReal.ofReal M*N*E₀) := by ac_rfl
      _ = _ := by rw [hcancel, one_mul]
  rw [he] at h
  simpa only [actualPacketInput_eq_synthesis, mFourierBasis_repr, coe_mFourierBasis] using h

end N2Restriction
#print axioms N2Restriction.actual_multicap_cell_budget
