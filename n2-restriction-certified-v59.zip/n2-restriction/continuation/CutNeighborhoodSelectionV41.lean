import continuation.SelectedPolynomialWallV41

namespace N2Restriction
open Set Metric MeasureTheory
open scoped BigOperators ENNReal

/-- Thickening a finite union of tangent cuts can be selected with only
the number of cuts as a mass loss. No smoothness or degree claim is assumed
implicitly here; the exact selected polynomial family is returned. -/
theorem polynomial_cut_neighborhood_selection {n c D : ℕ} {I : Type*}
    [Fintype I] [Nonempty I] (Q : I → Fin c → MvPolynomial (Fin n) ℝ)
    (hD : ∀ i j, (Q i j).totalDegree ≤ D)
    (hr : ∀ i x, polynomialLevelMap (Q i) x = 0 →
      Function.Surjective (fderiv ℝ (polynomialLevelMap (Q i)) x))
    (Ω : Set (Ambient n)) (hΩ : MeasurableSet Ω) (b : ℝ)
    (μ : Measure (Ambient n)) (θ : ENNReal)
    (hcut : θ*μ Ω ≤ μ (Ω ∩ thickening b (⋃ i, {x | polynomialLevelMap (Q i) x = 0}))) :
    ∃ i, ∃ Ω' : Set (Ambient n), MeasurableSet Ω' ∧ Ω' ⊆ Ω ∧
      Ω' ⊆ thickening b {x | polynomialLevelMap (Q i) x = 0} ∧
      (∀ j, (Q i j).totalDegree ≤ D) ∧
      (∀ x, polynomialLevelMap (Q i) x = 0 →
        Function.Surjective (fderiv ℝ (polynomialLevelMap (Q i)) x) ∧
        Module.finrank ℝ (LinearMap.ker (fderiv ℝ (polynomialLevelMap (Q i)) x).toLinearMap) = n-c) ∧
      θ*μ Ω ≤ (Fintype.card I : ENNReal)*μ Ω' := by
  let B := fun i => Ω ∩ thickening b {x | polynomialLevelMap (Q i) x = 0}
  have hcover : Ω ∩ thickening b (⋃ i, {x | polynomialLevelMap (Q i) x = 0}) ⊆ ⋃ i, B i := by
    intro x hx
    obtain ⟨z, hz, hn⟩ := mem_thickening_iff.mp hx.2
    obtain ⟨i, hi⟩ := mem_iUnion.mp hz
    exact mem_iUnion.mpr ⟨i, hx.1, mem_thickening_iff.mpr ⟨z, hi, hn⟩⟩
  obtain ⟨i, hi⟩ := finite_cover_mass_selection μ _ B hcover
  refine ⟨i, B i, hΩ.inter isOpen_thickening.measurableSet,
    inter_subset_left, inter_subset_right, hD i, ?_, hcut.trans hi⟩
  intro x hx
  exact ⟨hr i x hx, polynomialLevelMap_kernel_dimension (Q i) (hr i x hx)⟩

/-- The cut-near / cut-away alternatives use the current measure. Either
restriction retains at least half its mass, including infinite-mass cases. -/
theorem cut_near_or_away_mass {n : ℕ} (μ : Measure (Ambient n))
    (Ω cuts : Set (Ambient n)) (b : ℝ) :
    μ Ω ≤ 2*μ (Ω ∩ thickening b cuts) ∨
      μ Ω ≤ 2*μ (Ω \ thickening b cuts) := by
  have hcover : Ω ⊆ (Ω ∩ thickening b cuts) ∪ (Ω \ thickening b cuts) := by
    intro x hx
    by_cases h : x ∈ thickening b cuts
    · exact Or.inl ⟨hx, h⟩
    · exact Or.inr ⟨hx, h⟩
  have hsum := (measure_mono (μ := μ) hcover).trans (measure_union_le _ _)
  rcases le_total (μ (Ω ∩ thickening b cuts)) (μ (Ω \ thickening b cuts)) with h | h
  · right
    calc
      μ Ω ≤ μ (Ω ∩ thickening b cuts) + μ (Ω \ thickening b cuts) := hsum
      _ ≤ μ (Ω \ thickening b cuts) + μ (Ω \ thickening b cuts) := add_le_add_right h _
      _ = 2*μ (Ω \ thickening b cuts) := (two_mul _).symm
  · left
    calc
      μ Ω ≤ μ (Ω ∩ thickening b cuts) + μ (Ω \ thickening b cuts) := hsum
      _ ≤ μ (Ω ∩ thickening b cuts) + μ (Ω ∩ thickening b cuts) := add_le_add_left h _
      _ = 2*μ (Ω ∩ thickening b cuts) := (two_mul _).symm

end N2Restriction
#print axioms N2Restriction.polynomial_cut_neighborhood_selection
#print axioms N2Restriction.cut_near_or_away_mass
