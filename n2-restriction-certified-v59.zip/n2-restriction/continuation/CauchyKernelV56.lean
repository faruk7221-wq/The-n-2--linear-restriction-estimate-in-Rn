import continuation.RegularizedInverseV55
import Mathlib.Analysis.SpecialFunctions.Trigonometric.ArctanDeriv
namespace N2Restriction
set_option maxHeartbeats 800000

noncomputable def cauchyKernel (e z : ℝ) : ℝ := 1/(z^2+e^2)
noncomputable def cauchyPrimitive (e z : ℝ) : ℝ := (1/e)*Real.arctan (z/e)

theorem continuous_cauchyKernel {e : ℝ} (he : 0 < e) : Continuous (cauchyKernel e) := by
  apply continuous_const.div ((continuous_id.pow 2).add continuous_const)
  intro z
  nlinarith [sq_nonneg z,sq_pos_of_pos he]

theorem cauchyKernel_nonneg {e : ℝ} (he : 0 < e) (z : ℝ) : 0 ≤ cauchyKernel e z := by
  unfold cauchyKernel
  positivity

/-- The sharper inverse derivative bound retains the integrable Cauchy
kernel, rather than discarding it in a pointwise e^-2 bound. -/
theorem abs_deriv_regularizedInverse_le_kernel {e : ℝ} (he : 0 < e) (z : ℝ) :
    |deriv (regularizedInverse e) z| ≤ cauchyKernel e z := by
  rw [(hasDerivAt_regularizedInverse he z).deriv]
  have hd : 0 < z^2+e^2 := by nlinarith [sq_nonneg z,sq_pos_of_pos he]
  rw [abs_div,abs_of_pos (sq_pos_of_pos hd)]
  have hn : |e^2-z^2| ≤ z^2+e^2 := by
    rw [abs_le]
    constructor <;> nlinarith [sq_nonneg z]
  calc
    _ ≤ (z^2+e^2)/(z^2+e^2)^2 := (div_le_div_iff_of_pos_right (sq_pos_of_pos hd)).mpr hn
    _ = cauchyKernel e z := by unfold cauchyKernel; field_simp

/-- Exact arctangent primitive of the actual regularization kernel. -/
theorem hasDerivAt_cauchyPrimitive {e : ℝ} (he : 0 < e) (z : ℝ) :
    HasDerivAt (cauchyPrimitive e) (cauchyKernel e z) z := by
  have h := (((hasDerivAt_id z).div_const e).arctan).const_mul (1/e)
  change HasDerivAt (fun s => (1/e)*Real.arctan (s/e)) _ z
  convert h using 1
  dsimp [cauchyKernel,id_eq]
  have he0 := he.ne'
  field_simp
  ring

/-- A primitive increment costs at most pi/e on any interval. -/
theorem cauchyPrimitive_increment_le {e : ℝ} (he : 0 < e) (x y : ℝ) :
    cauchyPrimitive e y - cauchyPrimitive e x ≤ Real.pi/e := by
  have h := sub_le_sub (Real.arctan_lt_pi_div_two (y/e)).le
    (Real.neg_pi_div_two_lt_arctan (x/e)).le
  have h' := mul_le_mul_of_nonneg_left h (show 0 ≤ 1/e by positivity)
  unfold cauchyPrimitive
  calc
    _ = (1/e)*(Real.arctan (y/e)-Real.arctan (x/e)) := by ring
    _ ≤ (1/e)*(Real.pi/2- -(Real.pi/2)) := h'
    _ = _ := by ring
end N2Restriction
#print axioms N2Restriction.continuous_cauchyKernel
#print axioms N2Restriction.cauchyKernel_nonneg
#print axioms N2Restriction.abs_deriv_regularizedInverse_le_kernel
#print axioms N2Restriction.hasDerivAt_cauchyPrimitive
#print axioms N2Restriction.cauchyPrimitive_increment_le
