import continuation.ConstructedSubpatchGrowthV53
import continuation.FixedGrowthRestrictionV53
namespace N2Restriction
open MeasureTheory Set Metric Filter
open scoped ENNReal NNReal
set_option maxHeartbeats 800000

/-- The actual surface estimate for compact original supports carried with
positive frequency margin by a chosen directional piece. The unresolved global
transfer is construction of a compatible family covering the entire article
support; it is not hidden in this theorem's hypotheses. -/
theorem exists_constructed_subpatch_surface_estimate {k : ℕ} (hk : 3 ≤ k)
    (P : Fin k → SmoothPatch (k+2)) {ν κ : ℝ} (hgeo : GeometricHypotheses P ν κ)
    (hKexternal : WeightedKakeyaExternalGoal (k+2) k)
    (hcutsExternal : UniformTangentCutsInput (k+2))
    (hpartitionExternal : UniformProjectedPartitionInput (k+2))
    (hcoverExternal : UniformPolynomialTubeCoverInput (k+2))
    (hpointsExternal : ZeroDimensionalPointCountInput (k+2))
    {δ : ℝ} (hδ : 0 < δ) :
    ∃ ι : ℝ, 0 < ι ∧ ∃ Dsub : (i : Fin k) → DirectionalSubdivision (P i) ι,
    ∀ (a : (i : Fin k) → Fin (Dsub i).size)
      (B : ArticleLocalizationAtlas (fun i => (Dsub i).piece (a i)) κ)
      (V : Fin k → Set (Ambient (k+2))) (margin : ℝ),
    (∀ i, ((Dsub i).piece (a i)).extendedSurface ∩ V i ⊆ ((Dsub i).piece (a i)).support) →
    0 < margin → B.UniformLocalizedInput (baseline (k : ℝ)) →
    ∀ S : Fin k → SmoothPatch (k+2),
    (∀ i, (S i).support ⊆ ((Dsub i).piece (a i)).support) →
    (∀ i, (S i).support ⊆ marginRegion (V i) margin) →
    ∀ p : ℝ, critical k < p → p < baseline k →
    ∃ C : ℝ≥0, ∀ R : ℝ, 2 ≤ R →
    ∀ (x : Ambient (k+2)) (f : Fin k → Ambient (k+2) → ℂ),
      (∀ i, MemLp (f i) 2 (S i).surfaceMeasure) →
      eLpNorm' (extensionProduct (fun i => (S i).surfaceMeasure) (fun _ => id) f) p
        (volume.restrict (ball x R)) ≤
        (C : ENNReal)*ENNReal.ofReal (R^δ)*inputNormProduct (fun i => (S i).surfaceMeasure) f := by
  obtain ⟨ι,hι,Dsub,hbound⟩ := exists_constructed_subpatch_margin_growth hk P hgeo hKexternal
    hcutsExternal hpartitionExternal hcoverExternal hpointsExternal hδ
  refine ⟨ι,hι,Dsub,?_⟩
  intro a B V margin hS hm hexternal S hST hmargin p hpc hpb
  have hp : 0 < p := (critical_pos (by exact_mod_cast (show 0 < k by omega))).trans hpc
  exact surface_estimate_of_fixed_margin_growth S (fun i => (Dsub i).piece (a i)) hST V margin hmargin
    hp (hbound a B V margin hS hm hexternal p hpc hpb)
end N2Restriction
#print axioms N2Restriction.exists_constructed_subpatch_surface_estimate
