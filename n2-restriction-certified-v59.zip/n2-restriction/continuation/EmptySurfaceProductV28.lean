import N2Restriction.SurfaceMeasure

namespace N2Restriction
open MeasureTheory Set
open scoped BigOperators

/-- The empty-support branch is identically zero, so the geometric product
atlas may restrict its nontrivial branch to nonempty supports. -/
theorem surface_product_zero_of_empty_support {k n : ℕ}
    (S : Fin k → SmoothPatch n) (i : Fin k) (hi : (S i).support = ∅)
    (g : ∀ j, Lp ℂ 2 (S j).surfaceMeasure) :
    (fun x => ∏ j, extension (S j).surfaceMeasure id (g j) x) = 0 := by
  funext x
  apply Finset.prod_eq_zero (Finset.mem_univ i)
  simp [extension, SmoothPatch.surfaceMeasure, hi]

end N2Restriction

#print axioms N2Restriction.surface_product_zero_of_empty_support
