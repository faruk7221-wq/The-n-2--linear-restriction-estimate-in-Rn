import N2Restriction
namespace N2Restriction
open MeasureTheory Set
open scoped ENNReal BigOperators

/-- One empty original support annihilates the product for arbitrary
representatives, so no curvature-to-decay hypothesis is needed in this branch. -/
theorem extensionProduct_zero_of_empty_surface {n k : ℕ}
    (S : Fin k → SmoothPatch n) (i : Fin k) (hi : (S i).support = ∅)
    (f : Fin k → Ambient n → ℂ) :
    extensionProduct (fun j => (S j).surfaceMeasure) (fun _ => id) f = 0 := by
  funext x
  unfold extensionProduct
  apply Finset.prod_eq_zero (Finset.mem_univ i)
  simp [extension,SmoothPatch.surfaceMeasure,hi]

/-- The global estimate is trivial in the empty-support branch, even when
the tuplewise geometric hypothesis would otherwise be vacuous. -/
theorem globalRestriction_of_empty_surface {n k : ℕ}
    (S : Fin k → SmoothPatch n) (hempty : ∃ i, (S i).support = ∅)
    {p : ℝ} (hp : 0 < p) :
    GlobalRestriction (fun i => (S i).surfaceMeasure) (fun _ => id) p := by
  obtain ⟨i,hi⟩ := hempty
  refine ⟨0,?_⟩
  intro f hf
  rw [extensionProduct_zero_of_empty_surface S i hi f,eLpNorm'_zero hp]
  simp
end N2Restriction
#print axioms N2Restriction.extensionProduct_zero_of_empty_surface
#print axioms N2Restriction.globalRestriction_of_empty_surface
