import continuation.TrimmedCellLabelsV38
import N2Restriction.PacketBudgets

namespace N2Restriction
open Set Classical
open scoped BigOperators ENNReal

/-- The exact incidence sum is the number of cell labels met by a packet. -/
theorem cell_label_incidence {ι : Type*} {m : ℕ} (L : ι → Finset (Fin m → Bool))
    (J : Set ι) (ν : ι) :
    (∑' σ : Fin m → Bool,
      ({ν | ν ∈ J ∧ σ ∈ L ν} : Set ι).indicator (fun _ => (1 : ℝ≥0∞)) ν) =
        if ν ∈ J then ((L ν).card : ℝ≥0∞) else 0 := by
  classical
  by_cases hν : ν ∈ J
  · simp [Set.indicator_apply, hν, tsum_fintype]
  · simp [hν]

section Budgets
variable {ι E F : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E]
  [CompleteSpace E] [NormedAddCommGroup F] [NormedSpace ℂ F]

/-- Section 6's O(D) cell energy budget, for actual selected bounded
Hilbert packet sums. The degree multiplicity is proved by Lemma 5.2. -/
theorem polynomial_cell_packet_budget {n m : ℕ}
    (P : Fin m → MvPolynomial (Fin n) ℝ)
    (a v : ι → Ambient n) (Ω : Set (Ambient n)) {b w : ℝ} (hw : w < b)
    (basis : HilbertBasis ι ℂ E) (T : E →L[ℂ] F) (x : E) (J : Set ι) :
    (∑' σ : Fin m → Bool, ENNReal.ofReal
      (‖∑' ν : {ν // ν ∈ J ∧ σ ∈ trimmedCellLabels P (a ν) (v ν) Ω b w},
        T (basis.repr x ν.val • basis ν.val)‖ ^ 2)) ≤
      ENNReal.ofReal (‖T‖ ^ 2) * (((∏ l, P l).totalDegree+1 : ℕ) : ℝ≥0∞) *
        ENNReal.ofReal (‖x‖ ^ 2) := by
  apply hilbert_packet_incidence_budget basis T x
    (fun σ => {ν | ν ∈ J ∧ σ ∈ trimmedCellLabels P (a ν) (v ν) Ω b w})
  intro ν
  rw [cell_label_incidence]
  split_ifs
  · exact_mod_cast trimmedCellLabels_card_le_degree P (a ν) (v ν) Ω hw
  · exact zero_le _

/-- Section 6's degree-independent far-family energy budget. The
algebraic covering theorem is borrowed; all incidence and energy steps
are checked, and the original Hilbert input norm is retained. -/
theorem nontangent_cell_packet_budget {n m M : ℕ}
    (P : Fin m → MvPolynomial (Fin n) ℝ)
    (Z : Set (Ambient n)) (tangent : Ambient n → Submodule ℝ (Ambient n))
    (V : Submodule ℝ (Ambient n)) {γ K : ℝ} (hK : 0 ≤ K)
    (hexternal : AlgebraicTubeCoverInput Z tangent γ M K)
    (a v : ι → Ambient n) (Ω : Set (Ambient n)) {b w : ℝ} (hb : 0 < b) (hw : w ≤ b)
    (hwitness : ∀ x ∈ Ω, ∃ z ∈ Z, dist x z < b ∧
      ‖(tangent z).starProjection - V.starProjection‖ < 2*γ)
    (basis : HilbertBasis ι ℂ E) (T : E →L[ℂ] F) (x : E) (J : Set ι)
    (hv : ∀ ν ∈ J, ‖v ν‖ = 1)
    (hangle : ∀ ν ∈ J, 4*γ < directionPlaneAngle (v ν) V) :
    (∑' σ : Fin m → Bool, ENNReal.ofReal
      (‖∑' ν : {ν // ν ∈ J ∧ σ ∈ trimmedCellLabels P (a ν) (v ν) Ω b w},
        T (basis.repr x ν.val • basis ν.val)‖ ^ 2)) ≤
      ENNReal.ofReal (‖T‖ ^ 2) * ENNReal.ofReal (M * (K+2)^n) * ENNReal.ofReal (‖x‖ ^ 2) := by
  apply hilbert_packet_incidence_budget basis T x
    (fun σ => {ν | ν ∈ J ∧ σ ∈ trimmedCellLabels P (a ν) (v ν) Ω b w})
  intro ν
  rw [cell_label_incidence]
  split_ifs with hν
  · have hh := trimmedCellLabels_card_le_nontangent P Z tangent V hK hexternal
      (a ν) (v ν) (hv ν hν) Ω hb hw hwitness (hangle ν hν)
    exact_mod_cast ENNReal.ofReal_le_ofReal hh
  · exact zero_le _

end Budgets
end N2Restriction

#print axioms N2Restriction.cell_label_incidence
#print axioms N2Restriction.polynomial_cell_packet_budget
#print axioms N2Restriction.nontangent_cell_packet_budget
