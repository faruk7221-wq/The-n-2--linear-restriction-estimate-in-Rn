import continuation.CompactNearPlaneRankV45
import continuation.AtlasPacketAxesV42

namespace N2Restriction
open Set Metric

/-- A single tolerance works for every actual cap center in the fixed atlases.
No radius or selected packet enters its choice. -/
theorem atlas_near_plane_rank {k : ℕ} (S : Fin k → SmoothPatch (k+2))
    (T : (i : Fin k) → PacketGraphAtlas (S i))
    {ν κ : ℝ} (hgeo : GeometricHypotheses S ν κ) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ (j : (i : Fin k) → Fin (T i).size)
      (a : Fin k → Ambient (k+1)),
      (∀ i, a i ∈ ((T i).patch (j i)).support) →
      ∀ (V : Submodule ℝ (Ambient (k+2))) (near : Finset (Fin k)),
      (∀ i ∈ near, ‖V.starProjection ((T i).cellAxisDirection (j i) (a i)) -
        (T i).cellAxisDirection (j i) (a i)‖ < ε) →
      near.card ≤ Module.finrank ℝ V := by
  classical
  let K : Fin k → Set (Ambient (k+2)) := fun i => ⋃ j, (T i).buffer j
  have hK (i : Fin k) : IsCompact (K i) := isCompact_iUnion (fun j => (T i).compact_buffer j)
  have hinside (i : Fin k) : K i ⊆ (S i).extendedSurface := by
    intro x hx
    obtain ⟨j, hj⟩ := mem_iUnion.mp hx
    exact ((T i).buffer_inside j hj).1
  let N : (Fin k → Ambient (k+2)) → (Fin k → Ambient (k+2)) :=
    fun z i => (S i).normal (z i)
  have hcont : ContinuousOn N (Set.univ.pi K) := by
    apply continuousOn_pi.mpr
    intro i
    exact ((S i).smooth_normal.continuousOn.mono (fun x hx => (hinside i hx).1)).comp
      (continuous_apply i).continuousOn (fun z hz => hz i (mem_univ i))
  have hbase : IsCompact (Set.univ.pi K) := by
    simpa only [Set.pi, Set.mem_univ, forall_const] using isCompact_pi_infinite hK
  have hcompact := hbase.image_of_continuousOn hcont
  have hind : ∀ v ∈ N '' (Set.univ.pi K), LinearIndependent ℝ v := by
    rintro v ⟨z, hz, rfl⟩
    apply normals_independent_of_gram
    exact ne_of_gt ((sq_pos_of_pos hgeo.1).trans_le
      (hgeo.2.2 z (fun i => hinside i (hz i (mem_univ i)))).1)
  obtain ⟨ε, hε, he⟩ := compact_near_plane_rank _ hcompact hind
  refine ⟨ε, hε, ?_⟩
  intro j a ha V near hnear
  let z : Fin k → Ambient (k+2) := fun i =>
    ((T i).patch (j i)).rotation (((T i).graph (j i)).parametrization (a i))
  have hz : z ∈ Set.univ.pi K := by
    intro i _
    apply mem_iUnion.mpr
    refine ⟨j i, ?_⟩
    exact ⟨_, ⟨a i, (closedBall_subset_closedBall ((T i).inner_lt (j i)).le)
      (((T i).patch (j i)).support_inside (ha i)), rfl⟩, rfl⟩
  exact he (N z) ⟨z, hz, rfl⟩ V near hnear

end N2Restriction
#print axioms N2Restriction.atlas_near_plane_rank
