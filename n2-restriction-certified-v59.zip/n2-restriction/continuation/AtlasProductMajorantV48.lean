import continuation.AtlasSelectedMajorantV42

namespace N2Restriction
open MeasureTheory Set
open scoped ENNReal

/-- Uniform pointwise control of every selected original packet product,
with the original input norms retained as a product. -/
theorem atlas_selected_product_majorant {d k : ℕ}
    (S : Fin k → SmoothPatch (d+1)) (A : (i : Fin k) → PacketGraphAtlas (S i)) :
    ∃ C : ℝ, 1 ≤ C ∧ ∀ {r : ℝ}
    (Q : (i : Fin k) → (j : Fin (A i).size) → CoordinateCapFamily ((A i).patch j).support r)
    (hr : 0 < r), (∀ i, r ≤ (A i).capRadius) →
    ∀ (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure)
      (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure),
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
    ∀ (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin d → ℤ))
      (x : Ambient (d+1)),
    ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
      (fun i => (A i).cellInput (Q i) hr (f i) (U i)) x‖ₑ ≤
      ENNReal.ofReal C * ∏ i, ENNReal.ofReal ‖g i‖ := by
  choose D hD hd using fun i => (A i).selected_input_majorant
  have hD0 i : 0 ≤ D i := zero_le_one.trans (hD i)
  refine ⟨∏ i, D i, (by simpa using (Finset.prod_le_prod (fun (i : Fin k) _ => (zero_le_one : (0 : ℝ) ≤ 1)) (fun i _ => hD i) : (∏ _i : Fin k, (1 : ℝ)) ≤ ∏ i, D i)), ?_⟩
  intro r Q hr hsmall g f he U x
  have hh : ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
      (fun i => (A i).cellInput (Q i) hr (f i) (U i)) x‖ ≤
        (∏ i, D i)*(∏ i, ‖g i‖) := by
    unfold extensionProduct
    rw [norm_prod,← Finset.prod_mul_distrib]
    exact Finset.prod_le_prod (fun _ _ => norm_nonneg _)
      (fun i _ => (hd i (Q i) hr (g i) (f i) (he i) (U i)).2 (hsmall i) x)
  have hh' := ENNReal.ofReal_le_ofReal hh
  rw [ENNReal.ofReal_mul (Finset.prod_nonneg (fun i _ => hD0 i)),
    ENNReal.ofReal_prod_of_nonneg (fun i _ => norm_nonneg (g i))] at hh'
  simpa only [ofReal_norm] using hh'

end N2Restriction
#print axioms N2Restriction.atlas_selected_product_majorant
