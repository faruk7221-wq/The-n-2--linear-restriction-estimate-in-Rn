import continuation.ActualTangentNormV50
namespace N2Restriction
open MeasureTheory Set Metric Filter
open scoped ENNReal NNReal

/-- The normalized tangent bound with all tube-width and open-ball scale
conditions discharged. Only terminal geometry and the uniform borrowed
finite directional Kakeya input remain, besides original input invariants. -/
theorem eventually_actualTangentSum_q0_bound {k : ℕ}
    (P : Fin k → SmoothPatch (k+2)) {ι : ℝ}
    (Dsub : ∀ i, DirectionalSubdivision (P i) ι) (a : ∀ i, Fin (Dsub i).size) (A : (i : Fin k) → PacketGraphAtlas ((fun i => (Dsub i).piece (a i)) i))
    {κ : ℝ} (B : ArticleLocalizationAtlas (fun i => (Dsub i).piece (a i)) κ)
    (V : Fin k → Set (Ambient (k+2))) (m : ℝ)
    (hS : ∀ i, ((fun i => (Dsub i).piece (a i)) i).extendedSurface ∩ V i ⊆ ((fun i => (Dsub i).piece (a i)) i).support) (hm : 0 < m)
    {p ε τ lam : ℝ} (hp : 0 < p) (hp1 : p ≤ 1) (hε : 0 < ε)
    (hexternal : B.UniformLocalizedInput p) (hτ : 0 < τ) (hτ' : τ < 1/4) (hlam : 1 ≤ lam)
    (C C₀ θ Cext Bcap : ℝ)
    (hC : 1 ≤ C) (hC₀ : 1+Real.sqrt (k+2 : ℕ)*(1+C)/2 ≤ C₀)
    (hθ : 0 < θ) (hBcap : 0 ≤ Bcap)
    (hKak : ∀ r w : ℝ, 1 ≤ w → w < r →
      FiniteDirectionalKakeya (volume.restrict (ball 0 r))
        (fun i => (P i).normal ((Dsub i).anchor (a i))) ι w (p/2)
        (ENNReal.ofReal (Cext*r^(ε*p)*w^((k+2 : ℕ)-ε*p)))) :
    ∃ K : ENNReal, K ≠ ∞ ∧ ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ R : ℝ, R₀ ≤ R →
    ∀ (Q : (i : Fin k) → (j : Fin (A i).size) →
      CoordinateCapFamily ((A i).patch j).support (R^(-1/2 : ℝ)))
      (hr : 0 < R^(-1/2 : ℝ)), (∀ i, R^(-1/2 : ℝ) ≤ (A i).capRadius) →
    (∀ i j, ((Q i j).centers.card : ℝ) ≤ Bcap*R^(((k+1 : ℕ) : ℝ)/2)) →
    ∀ (g : (i : Fin k) → Lp ℂ 2 ((fun i => (Dsub i).piece (a i)) i).surfaceMeasure)
      (f : (i : Fin k) → (j : Fin (A i).size) → Lp ℂ 2 ((A i).graph j).surfaceMeasure),
    (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
    (∀ i j, HasFrequencySupport ((A i).graph j).surfaceMeasure ((A i).patch j).rotation
      (marginRegion (V i) (m-R^(-1/4 : ℝ))) (f i j)) →
    ∀ (L : ℕ) (U : (i : Fin k) → (j : Fin (A i).size) → (Q i j).centers → Set (Fin (k+1) → ℤ))
      (Z : Set (Ambient (k+2))) (T : Ambient (k+2) → Submodule ℝ (Ambient (k+2)))
      (c : Fin L → Ambient (k+2)) (Ω : Set (Ambient (k+2))),
    (∀ l t, l ≠ t → 2*(θ*(R^(1-τ))) ≤ dist (c l) (c t)) →
    MeasurableSet Ω → Ω ⊆ closedBall 0 R →
    (∀ (zgrid : meetingGrid (n := k+2) (lam*R^(1/2+τ)) R) (l : Fin L), ((Ω ∩ ball (c l) (R^(1-τ))) ∩ gridCube (gridCentre (lam*R^(1/2+τ)) zgrid.val) (lam*R^(1/2+τ))).Nonempty →
      HasTerminalCubeFrame (fun i => (Dsub i).piece (a i)) κ Z T (c l) (gridCentre (lam*R^(1/2+τ)) zgrid.val) (R^(1-τ)) (lam*R^(1/2+τ))) →
    positiveNorm
      (actualTangentSum A Q hr f U Z T c (R^(1-τ)) (lam*R^(1/2+τ)) C₀ R (R^(1/2+τ)/10) Ω) p volume ≤
      K*ENNReal.ofReal (R^(-1/2+2*τ+ε))*∏ i, ENNReal.ofReal ‖g i‖ := by
  let α : ℝ := 2*(1+Real.sqrt (k+2 : ℕ))
  let β : ℝ := 1+Real.sqrt (k+2 : ℕ)*(1+C)/2
  have hα : 0 ≤ α := by dsimp [α]; positivity
  have hβ : 1 ≤ β := by
    dsimp [β]
    have hs := Real.sqrt_nonneg (k+2 : ℕ)
    nlinarith
  obtain ⟨K,hK,R₀,hR₀,hb⟩ := actualTangentSum_normalized_bound P Dsub a A B V m hS hm
    hp hp1 hε hexternal hτ hτ' (zero_lt_one.trans_le hlam) C C₀ θ α β 1 Cext Bcap
    hC hC₀ hθ hα (zero_le_one.trans hβ) hBcap rfl
  obtain ⟨R₁,hR₁,hscale⟩ := eventually_open_kakeya_grid_scales (k+2) hτ (by linarith) hlam hβ
  refine ⟨K,hK,max R₀ R₁,hR₀.trans (le_max_left _ _),?_⟩
  intro R hR Q hr hsmall hcount g f he hf L U Z T c Ω hsep hΩ hΩR hframe
  have hR0 := (le_max_left R₀ R₁).trans hR
  have hR1 := (le_max_right R₀ R₁).trans hR
  obtain ⟨_,hwide,hwideR,hball⟩ := hscale R hR1
  have hRpos : 0 < R := zero_lt_one.trans_le (hR₀.trans hR0)
  have hpow : 0 ≤ R^(1/2+τ) := Real.rpow_nonneg hRpos.le _
  have hw : R^(1/2+τ)/10 ≤ 1*(lam*R^(1/2+τ)) := by nlinarith
  exact hb R hR0 Q hr hsmall hcount g f he hf L U Z T c Ω hsep hΩ hΩR hframe hw hball
    (hKak (α*R) (β*(lam*R^(1/2+τ))) hwide hwideR)

end N2Restriction
#print axioms N2Restriction.eventually_actualTangentSum_q0_bound
