import continuation.ConstructedOriginMassV53
import continuation.DescentMarginGrowthV53
namespace N2Restriction
open MeasureTheory Set Metric Filter
open scoped ENNReal
set_option maxHeartbeats 1000000

/-- Choose the small losses and initial subdivision, carry out the actual
finite polynomial iteration, and close the resulting scalar recurrence.
This is the subpatch margin-constant growth theorem; final subdivision/support
transfer and the global main theorem are separate assembly obligations. -/
theorem exists_constructed_subpatch_margin_growth {k : ℕ} (hk : 3 ≤ k)
    (P : Fin k → SmoothPatch (k+2)) {ν κ : ℝ} (hgeo : GeometricHypotheses P ν κ)
    (hKexternal : WeightedKakeyaExternalGoal (k+2) k)
    (hcutsExternal : UniformTangentCutsInput (k+2))
    (hpartitionExternal : UniformProjectedPartitionInput (k+2))
    (hcoverExternal : UniformPolynomialTubeCoverInput (k+2))
    (hpointsExternal : ZeroDimensionalPointCountInput (k+2))
    {δ : ℝ} (hδ : 0 < δ) :
    ∃ ι : ℝ, 0 < ι ∧ ∃ Dsub : (i : Fin k) → DirectionalSubdivision (P i) ι,
    ∀ (a : (i : Fin k) → Fin (Dsub i).size)
      (B : ArticleLocalizationAtlas (fun i => (Dsub i).piece (a i)) κ)
      (V : Fin k → Set (Ambient (k+2))) (margin : ℝ),
    (∀ i, ((Dsub i).piece (a i)).extendedSurface ∩ V i ⊆ ((Dsub i).piece (a i)).support) →
    0 < margin → B.UniformLocalizedInput (baseline (k : ℝ)) →
    ∀ p : ℝ, critical k < p → p < baseline k →
    ∃ C : ℝ, 0 ≤ C ∧ ∀ R : ℝ, 1 ≤ R →
      (marginLocalConstant (fun i => ((Dsub i).piece (a i)).surfaceMeasure) (fun _ => id) V margin p R).toReal ≤ C*R^δ := by
  have hk0 : (0 : ℝ) < k := by exact_mod_cast (show 0 < k by omega)
  obtain ⟨τ,η,hτ,hτsmall,hη,hσ⟩ := choose_small_parameters hk0 hδ
  obtain ⟨ι,hι,Dsub,hbound⟩ := exists_constructed_origin_mass_descent hk P hgeo hKexternal hcutsExternal
    hpartitionExternal hcoverExternal hpointsExternal hη hτ (by linarith : τ < 1/4)
  refine ⟨ι,hι,Dsub,?_⟩
  intro a B V margin hS hm hexternal p hpc hpb
  letI : ∀ i, IsFiniteMeasure (((Dsub i).piece (a i)).surfaceMeasure) :=
    fun i => ((Dsub i).piece (a i)).isFiniteMeasure_surfaceMeasure (by omega)
  obtain ⟨K,hK,R₀,hR₀,hb⟩ := hbound a B V margin hS hm hexternal 1
    (1+Real.sqrt (k+2 : ℕ)*(1+1)/2) (by norm_num) le_rfl p hpc hpb
  have hp : 0 < p := (critical_pos hk0).trans hpc
  have hsigma : 0 ≤ sigma k τ η := by unfold sigma theta; positivity
  apply margin_growth_of_descent_mass (fun i => ((Dsub i).piece (a i)).surfaceMeasure)
    (fun _ => id) (fun _ => measurable_id) V margin hp hτ (by linarith : τ < 1/2)
    (by positivity : (0 : ℝ) < 100^(k+2)) hsigma hδ (by linarith : sigma k τ η < δ) K hK
  filter_upwards [eventually_ge_atTop R₀] with R hR
  exact hb R hR
end N2Restriction
#print axioms N2Restriction.exists_constructed_subpatch_margin_growth
