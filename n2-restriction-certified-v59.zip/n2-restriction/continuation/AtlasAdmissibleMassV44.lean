import continuation.AtlasAdmissibleHalfBallV44
import continuation.AtlasSelectedMajorantV42
import continuation.IntegratedProductErrorV42

namespace N2Restriction
open MeasureTheory Set
open scoped BigOperators ENNReal

/-- The analytic cell-mass estimate: the selected local term at R/2 plus
an explicit product error. The uniform majorant is constructed from the
actual atlas energy and buffer estimates. The pointwise omission hypothesis
is precisely the conclusion of `cell_restriction_rapid_approximation`. -/
theorem atlas_cell_admissible_mass_estimate {d k : ℕ} (S : Fin k → SmoothPatch (d+1))
    (T : (i : Fin k) → PacketGraphAtlas (S i))
    (W : Fin k → Set (Ambient (d+1))) :
    ∃ M : ℝ, 1 ≤ M ∧ ∀ {r : ℝ} (hr : 0 < r)
      (Q : (i : Fin k) → (j : Fin (T i).size) → CoordinateCapFamily ((T i).patch j).support r),
      (∀ i, r ≤ (T i).capRadius) →
      ∀ (g : (i : Fin k) → Lp ℂ 2 (S i).surfaceMeasure)
        (f : (i : Fin k) → (j : Fin (T i).size) → Lp ℂ 2 ((T i).graph j).surfaceMeasure),
      (∀ i, (∑ j, ‖f i j‖^2) ≤ ‖g i‖^2) →
      ∀ (A V : (i : Fin k) → (j : Fin (T i).size) → (Q i j).centers → Set (Fin d → ℤ))
        {m R p δ : ℝ},
      MarginAdmissible (fun i => (T i).bufferMeasure) (fun _ => id) W m (R/2)
        (fun i => (T i).bufferInput ((T i).cellInput (Q i) hr (f i) (V i))) → 0 < p → p ≤ 1 → 0 ≤ δ →
      ∀ (q : Finset (Ambient (d+1))),
      (Metric.closedBall 0 R ⊆ ⋃ a : q, Metric.ball (R • a.val) (R/2)) →
      ∀ Δ : Set (Ambient (d+1)), MeasurableSet Δ → Δ ⊆ Metric.closedBall 0 R →
      (∀ x ∈ Δ, ∀ i,
        ‖extension (Measure.hausdorffMeasure (d : ℝ)) id ((T i).cellInput (Q i) hr (f i) (A i)) x -
          extension (Measure.hausdorffMeasure (d : ℝ)) id ((T i).cellInput (Q i) hr (f i) (V i)) x‖ ≤ δ*‖g i‖) →
      (∫⁻ x in Δ, ‖extensionProduct (fun _ => Measure.hausdorffMeasure (d : ℝ)) (fun _ => id)
        (fun i => (T i).cellInput (Q i) hr (f i) (A i)) x‖ₑ ^ p) ≤
      (q.card : ENNReal) *
        (marginLocalConstant (fun i => (T i).bufferMeasure) (fun _ => id)
          W m p (R/2) *
            ∏ i, ENNReal.ofReal (‖(T i).cellInput (Q i) hr (f i) (V i)‖))^p +
        (ENNReal.ofReal ((k : ℝ)*δ*M^k*∏ i, ‖g i‖))^p * volume Δ := by
  classical
  choose C hC hc using fun i => (T i).selected_input_majorant
  let M := 1+∑ i, C i
  have hC0 i : 0 ≤ C i := zero_le_one.trans (hC i)
  have hM : 1 ≤ M := le_add_of_nonneg_right (Finset.sum_nonneg (fun i _ => hC0 i))
  have hiM i : C i ≤ M := (Finset.single_le_sum (fun j _ => hC0 j) (Finset.mem_univ i)).trans
    (le_add_of_nonneg_left zero_le_one)
  refine ⟨M, hM, ?_⟩
  intro r hr Q hsmall g f he A V m R p δ hm hp hp1 hδ q hcover Δ hΔ hin hd
  let F := fun i x => extension (Measure.hausdorffMeasure (d : ℝ)) id
    ((T i).cellInput (Q i) hr (f i) (A i)) x
  let G := fun i x => extension (Measure.hausdorffMeasure (d : ℝ)) id
    ((T i).cellInput (Q i) hr (f i) (V i)) x
  have hF x : ∀ i, ‖F i x‖ ≤ M*‖g i‖ := by
    intro i
    exact ((hc i (Q i) hr (g i) (f i) (he i) (A i)).2 (hsmall i) x).trans
      (mul_le_mul_of_nonneg_right (hiM i) (norm_nonneg _))
  have hG x : ∀ i, ‖G i x‖ ≤ M*‖g i‖ := by
    intro i
    exact ((hc i (Q i) hr (g i) (f i) (he i) (V i)).2 (hsmall i) x).trans
      (mul_le_mul_of_nonneg_right (hiM i) (norm_nonneg _))
  have herror := integrated_product_approximation volume Δ hΔ F G (fun i => ‖g i‖)
    (fun _ => norm_nonneg _) hM hδ hp hp1 (fun x _ => hF x) (fun x _ => hG x) hd
  exact herror.trans (add_le_add_right
    (atlas_cell_admissible_half_ball_bound S T hr Q hsmall f V W hm hp q hcover Δ hin) _)

end N2Restriction
#print axioms N2Restriction.atlas_cell_admissible_mass_estimate
