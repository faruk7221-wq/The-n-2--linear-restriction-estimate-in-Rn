import continuation.AdjointCompressionV26

set_option maxHeartbeats 800000

namespace N2Restriction

/-- A quantitative inverse for the reverse projected adjoint map H to W. -/
theorem nearby_reverse_adjoint_inverse {n : ℕ} (A : Ambient n →L[ℝ] Ambient n)
    (W H : Submodule ℝ (Ambient n)) (hdim : Module.finrank ℝ W = Module.finrank ℝ H)
    {κ : ℝ} (hκ : 0 < κ)
    (hA : ∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (A v)‖)
    (hgap : ‖W.starProjection - H.starProjection‖ * ‖A‖ ≤ κ / 2) :
    ∃ B : W →L[ℝ] H,
      (W.orthogonalProjection.comp ((A.adjoint).comp H.subtypeL)).comp B = ContinuousLinearMap.id ℝ W ∧
      B.comp (W.orthogonalProjection.comp ((A.adjoint).comp H.subtypeL)) = ContinuousLinearMap.id ℝ H ∧
      ‖B‖ ≤ 2 / κ := by
  obtain ⟨B, h₁, h₂, hB⟩ := inverse_between_equal_dimensions
    (W.orthogonalProjection.comp ((A.adjoint).comp H.subtypeL)) hdim.symm
    (by positivity : 0 < κ / 2)
    (nearby_reverse_adjoint_coercive A W H hdim hκ hA hgap)
  exact ⟨B, h₁, h₂, by simpa [div_eq_mul_inv, mul_comm] using hB⟩

/-- Quantitative decomposition using the adjoint image A†(H). -/
theorem nearby_adjoint_decomposition {n : ℕ} (A : Ambient n →L[ℝ] Ambient n)
    (W H : Submodule ℝ (Ambient n)) (hdim : Module.finrank ℝ W = Module.finrank ℝ H)
    {κ : ℝ} (hκ : 0 < κ)
    (hA : ∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (A v)‖)
    (hgap : ‖W.starProjection - H.starProjection‖ * ‖A‖ ≤ κ / 2)
    (x : Ambient n) :
    ∃ h : H, x - A.adjoint h ∈ Wᗮ ∧ ‖h‖ ≤ (2 / κ) * ‖x‖ := by
  obtain ⟨B, hright, _, hB⟩ := nearby_reverse_adjoint_inverse A W H hdim hκ hA hgap
  let h := B (W.orthogonalProjection x)
  have hproj : W.orthogonalProjection (A.adjoint h) = W.orthogonalProjection x :=
    congrArg (fun L : W →L[ℝ] W => L (W.orthogonalProjection x)) hright
  refine ⟨h, ?_, ?_⟩
  · apply Submodule.orthogonalProjection_eq_zero_iff.mp
    rw [map_sub, hproj, sub_self]
  · calc
      ‖h‖ ≤ ‖B‖ * ‖W.orthogonalProjection x‖ := B.le_opNorm _
      _ ≤ (2 / κ) * ‖x‖ := mul_le_mul hB (W.norm_orthogonalProjection_apply_le x)
        (norm_nonneg _) (by positivity)

/-- The adjoint image of a nearby plane complements the orthogonal of W. -/
theorem nearby_adjoint_transversality {n : ℕ} (A : Ambient n →L[ℝ] Ambient n)
    (W H : Submodule ℝ (Ambient n)) (hdim : Module.finrank ℝ W = Module.finrank ℝ H)
    {κ : ℝ} (hκ : 0 < κ)
    (hA : ∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (A v)‖)
    (hgap : ‖W.starProjection - H.starProjection‖ * ‖A‖ ≤ κ / 2) :
    Disjoint Wᗮ (H.map (A.adjoint).toLinearMap) ∧
      Wᗮ ⊔ H.map (A.adjoint).toLinearMap = ⊤ := by
  constructor
  · rw [Submodule.disjoint_def]
    intro x hx hxA
    obtain ⟨h, hh, hAh⟩ := Submodule.mem_map.mp hxA
    change A.adjoint h = x at hAh
    have hzero' : W.orthogonalProjection (A.adjoint h) = 0 := by
      rw [hAh]
      exact Submodule.orthogonalProjection_eq_zero_iff.mpr hx
    have hc := nearby_reverse_adjoint_coercive A W H hdim hκ hA hgap ⟨h, hh⟩
    change (κ / 2) * ‖h‖ ≤ ‖W.orthogonalProjection (A.adjoint h)‖ at hc
    rw [hzero', norm_zero] at hc
    have hh0 : h = 0 := norm_eq_zero.mp (by nlinarith [norm_nonneg h])
    simpa [hh0] using hAh.symm
  · apply top_unique
    intro x _
    obtain ⟨h, hh, _⟩ := nearby_adjoint_decomposition A W H hdim hκ hA hgap x
    exact Submodule.mem_sup.mpr ⟨x - A.adjoint h, hh, A.adjoint h,
      Submodule.mem_map.mpr ⟨h, h.property, rfl⟩, sub_add_cancel _ _⟩


end N2Restriction

#print axioms N2Restriction.nearby_adjoint_decomposition
#print axioms N2Restriction.nearby_adjoint_transversality
#print axioms N2Restriction.nearby_reverse_adjoint_inverse
