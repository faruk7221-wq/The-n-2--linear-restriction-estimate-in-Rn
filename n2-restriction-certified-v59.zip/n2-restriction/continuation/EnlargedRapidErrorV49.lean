import N2Restriction.BallEstimates

namespace N2Restriction
open MeasureTheory Set
open scoped ENNReal

/-- A fixed ball dilation costs only its dimension power. Choosing the packet
omission exponent (J+n)/p leaves any prescribed rapid decay R^(-J). -/
theorem enlarged_ball_rapid_error_normalization {n : ℕ} {R p α : ℝ}
    (hR : 0 < R) (hp : 0 < p) (hα : 0 ≤ α) (J : ℝ) (C P : ENNReal)
    (Δ : Set (Ambient n)) (hΔ : Δ ⊆ Metric.closedBall 0 (α*R)) :
    (C * ENNReal.ofReal (R^(-((J+n)/p))) * P)^p * volume Δ ≤
      (volume (Metric.ball (0 : Ambient n) 1) * ENNReal.ofReal (α^n) * C^p) *
        ENNReal.ofReal (R^(-J)) * P^p := by
  have hvol : volume Δ ≤ volume (Metric.closedBall (0 : Ambient n) (α*R)) := measure_mono hΔ
  rw [Measure.addHaar_closedBall volume 0 (mul_nonneg hα hR.le)] at hvol
  simp only [Ambient, finrank_euclideanSpace, Fintype.card_fin] at hvol
  rw [mul_pow, ENNReal.ofReal_mul (pow_nonneg hα n)] at hvol
  have hid : (ENNReal.ofReal (R^(-((J+n)/p))))^p * ENNReal.ofReal (R^n) =
      ENNReal.ofReal (R^(-J)) := by
    rw [ENNReal.ofReal_rpow_of_pos (Real.rpow_pos_of_pos hR _),
      ← ENNReal.ofReal_mul (Real.rpow_nonneg (Real.rpow_nonneg hR.le _) _),
      ← Real.rpow_mul hR.le, ← Real.rpow_natCast R n, ← Real.rpow_add hR]
    congr 2
    field_simp [hp.ne']
    ring
  calc
    _ ≤ (C * ENNReal.ofReal (R^(-((J+n)/p))) * P)^p *
        (ENNReal.ofReal (α^n) * ENNReal.ofReal (R^n) * volume (Metric.ball (0 : Ambient n) 1)) :=
      mul_le_mul_left' hvol _
    _ = (volume (Metric.ball (0 : Ambient n) 1) * ENNReal.ofReal (α^n) * C^p) *
        ((ENNReal.ofReal (R^(-((J+n)/p))))^p * ENNReal.ofReal (R^n)) * P^p := by
      simp only [ENNReal.mul_rpow_of_nonneg _ _ hp.le]
      ac_rfl
    _ = _ := by rw [hid]

end N2Restriction
#print axioms N2Restriction.enlarged_ball_rapid_error_normalization
