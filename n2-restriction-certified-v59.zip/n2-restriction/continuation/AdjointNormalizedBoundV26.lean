import continuation.BufferedAdjointWedgeV26

namespace N2Restriction
open Filter

/-- A fixed lower bound for the mixed normal/shape frame yields a uniform
bound for every orthonormal basis of a normal space containing its three
selected vectors. The shape norm bound is explicit. -/
theorem uniform_adjoint_normalized_gram_bound {k : ℕ} (i : Fin k)
    (M c : ℝ) (hM : 0 ≤ M) (hc : 0 < c) :
    ∃ a : ℝ, 0 < a ∧ ∀ (S : Fin k → SmoothPatch (k + 2))
      (z : Fin k → Ambient (k + 2)) (q : Ambient (k + 2) × Ambient (k + 2))
      (N : Submodule ℝ (Ambient (k + 2))) (b : OrthonormalBasis (Fin 3) ℝ N),
      (∀ j, ‖(S j).normal (z j)‖ = 1) → ‖(S i).shape (z i)‖ ≤ M →
      ‖q.1‖ ≤ 1 → ‖q.2‖ ≤ 1 →
      (S i).normal (z i) ∈ N → ((S i).shape (z i)).adjoint q.1 ∈ N →
      ((S i).shape (z i)).adjoint q.2 ∈ N →
      c ≤ Matrix.det (Matrix.gram ℝ (adjointWedgeVectors S z i q)) →
      a ≤ Matrix.det (Matrix.gram ℝ (Sum.elim
        (fun j : {j : Fin k // j ≠ i} => (S j).normal (z j))
        (fun j => (b j : Ambient (k + 2))))) := by
  classical
  have hk : 0 < k := Fin.pos i
  have hcard : Fintype.card (Sum (Fin k) (Fin 2)) =
      Fintype.card {j : Fin k // j ≠ i} + 3 := by simp; omega
  obtain ⟨a, ha, hb⟩ := uniform_normal_frame_bound_of_membership
    (Sum (Fin k) (Fin 2)) {j : Fin k // j ≠ i} (k + 2) 3 hcard 1 (max 1 M) c hc
  refine ⟨a, ha, ?_⟩
  intro S z q N b hunit hshape hq1 hq2 hN hA1 hA2 hG
  apply hb N b _ (adjointWedgeVectors S z i q) ?_ ?_ ?_ hG
  · exact (pi_norm_le_iff_of_nonneg zero_le_one).mpr (fun j => (hunit j).le)
  · intro j
    cases j with
    | inl j => simpa only [adjointWedgeVectors, Sum.elim_inl, hunit] using (le_max_left 1 M)
    | inr j =>
      have hq : ‖(if j = 0 then q.1 else q.2)‖ ≤ 1 := by split_ifs <;> assumption
      have hb := (((S i).shape (z i)).adjoint).le_of_opNorm_le (by simpa using hshape) (if j = 0 then q.1 else q.2)
      exact (hb.trans ((mul_le_mul_of_nonneg_left hq hM).trans_eq (mul_one M))).trans
        (le_max_right 1 M)
  · intro j
    cases j with
    | inl j =>
      by_cases he : j = i
      · subst j; exact Or.inr hN
      · exact Or.inl ⟨⟨j, he⟩, rfl⟩
    | inr j =>
      right
      change ((S i).shape (z i)).adjoint (if j = 0 then q.1 else q.2) ∈ N
      split_ifs <;> assumption


end N2Restriction

#print axioms N2Restriction.uniform_adjoint_normalized_gram_bound
