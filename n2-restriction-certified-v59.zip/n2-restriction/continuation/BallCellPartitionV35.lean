import continuation.GridEnergyV21

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal

/-- Every half-open cube has Euclidean diameter at most its diagonal. -/
theorem gridCube_dist_le {n : ℕ} (q : Ambient n) {b : ℝ} (hb : 0 ≤ b)
    {x y : Ambient n} (hx : x ∈ gridCube q b) (hy : y ∈ gridCube q b) :
    dist x y ≤ Real.sqrt n * b := by
  have hxq := gridCube_subset_ball q hb hx
  have hyq := gridCube_subset_ball q hb hy
  have ht := dist_triangle x q y
  change dist x q ≤ _ at hxq
  change dist y q ≤ _ at hyq
  rw [dist_comm q y] at ht
  linarith

/-- A finite disjoint family of full equal-volume cubes covers any translated
ball. The cells are not cut at the ball boundary. The radius of each cell's
containing ball and its diameter are independent of the large ball's center. -/
theorem finite_ball_cell_partition (n : ℕ) (x₀ : Ambient n) (R b : ℝ) (hb : 0 < b) :
    ∃ (J : Type) (_ : Fintype J) (q : J → Ambient n),
      (closedBall x₀ R ⊆ ⋃ j, gridCube (q j) b) ∧
      Pairwise (fun j k => Disjoint (gridCube (q j) b) (gridCube (q k) b)) ∧
      (∀ j, MeasurableSet (gridCube (q j) b)) ∧
      (∀ j, volume (gridCube (q j) b) = ENNReal.ofReal b ^ n) ∧
      (∀ j, gridCube (q j) b ⊆ closedBall (q j) (Real.sqrt n * (b / 2))) ∧
      (∀ j, ∀ x ∈ gridCube (q j) b, ∀ y ∈ gridCube (q j) b, dist x y ≤ Real.sqrt n * b) := by
  let J := meetingGrid (n := n) b (R + ‖x₀‖)
  letI : Fintype J := (finite_meetingGrid (n := n) (R := R + ‖x₀‖) hb).fintype
  refine ⟨J, inferInstance, fun j => gridCentre b j.val, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · intro x hx
    obtain ⟨z, hz⟩ := gridCube_lattice_cover hb x
    have hx0 : x ∈ closedBall 0 (R + ‖x₀‖) := by
      change dist x 0 ≤ R + ‖x₀‖
      calc
        dist x 0 ≤ dist x x₀ + dist x₀ 0 := dist_triangle _ _ _
        _ ≤ R + ‖x₀‖ := by simpa only [dist_zero_right] using add_le_add_right hx (dist x₀ 0)
    exact mem_iUnion.mpr ⟨⟨z, x, hz, hx0⟩, hz⟩
  · intro j k hjk
    exact gridCube_lattice_pairwise hb (fun h => hjk (Subtype.ext h))
  · exact fun _ => measurableSet_gridCube _ _
  · exact fun _ => volume_gridCube _ _
  · exact fun _ => gridCube_subset_ball _ hb.le
  · exact fun _ _ hx _ hy => gridCube_dist_le _ hb.le hx hy

end N2Restriction

#print axioms N2Restriction.finite_ball_cell_partition
#print axioms N2Restriction.gridCube_dist_le
