import continuation.LocalizedCylinderComparisonV32
import continuation.BlockBallVolumeV32
import continuation.CenteredCylinderPerturbationV32

namespace N2Restriction
open MeasureTheory Set Metric
open scoped ENNReal BigOperators
attribute [local instance] tripleProductHaar

/-- Mixed-dimensional cylinders with individually perturbed projections obey
a sharp flat comparison at width w+δR on every physical ball. -/
theorem centered_perturbed_block_cylinders {n a b c : ℕ} {P Q T : Type*}
    [Countable P] [Countable Q] [Countable T]
    (e : Ambient n ≃L[ℝ] (Ambient b × Ambient c) × Ambient a)
    (A : P → Ambient n →L[ℝ] Ambient b × Ambient c)
    (B : Q → Ambient n →L[ℝ] Ambient a × Ambient c)
    (C : T → Ambient n →L[ℝ] Ambient a × Ambient b)
    (za : P → Ambient b × Ambient c) (zb : Q → Ambient a × Ambient c)
    (zc : T → Ambient a × Ambient b)
    (u : P → ℝ≥0∞) (v : Q → ℝ≥0∞) (s : T → ℝ≥0∞)
    (x₀ : Ambient n) (R w δ : ℝ) (hδ : 0 ≤ δ)
    (hA : ∀ t, ‖A t - blockProjectionOne e‖ ≤ δ)
    (hB : ∀ t, ‖B t - blockProjectionTwo e‖ ≤ δ)
    (hC : ∀ t, ‖C t - blockProjectionThree e‖ ≤ δ) :
    (∫⁻ x in closedBall x₀ R,
      (tubeDensity (fun t => A t ⁻¹' closedBall (za t) w) u x *
       tubeDensity (fun t => B t ⁻¹' closedBall (zb t) w) v x *
       tubeDensity (fun t => C t ⁻¹' closedBall (zc t) w) s x) ^ (1 / 2 : ℝ)) ≤
      (coordinateMeasureFactor e volume ((volume.prod volume).prod volume) : ℝ≥0∞) *
      (((∑' t, u t) * (volume.prod volume) (closedBall (0 : Ambient b × Ambient c) (w + δ * R))) ^ (1 / 2 : ℝ) *
       ((∑' t, v t) * (volume.prod volume) (closedBall (0 : Ambient a × Ambient c) (w + δ * R))) ^ (1 / 2 : ℝ) *
       ((∑' t, s t) * (volume.prod volume) (closedBall (0 : Ambient a × Ambient b) (w + δ * R))) ^ (1 / 2 : ℝ)) := by
  apply localized_cylinder_comparison e (closedBall x₀ R) measurableSet_closedBall
    _ _ _ (fun t => closedBall (za t + (blockProjectionOne e - A t) x₀) (w + δ * R))
    (fun t => closedBall (zb t + (blockProjectionTwo e - B t) x₀) (w + δ * R)) (fun t => closedBall (zc t + (blockProjectionThree e - C t) x₀) (w + δ * R))
    (fun _ => measurableSet_closedBall) (fun _ => measurableSet_closedBall)
    (fun _ => measurableSet_closedBall)
  · intro t
    exact centered_perturbed_projection_cylinder_subset (A t) (blockProjectionOne e) x₀ (za t) R w δ hδ (hA t)
  · intro t
    exact centered_perturbed_projection_cylinder_subset (B t) (blockProjectionTwo e) x₀ (zb t) R w δ hδ (hB t)
  · intro t
    exact centered_perturbed_projection_cylinder_subset (C t) (blockProjectionThree e) x₀ (zc t) R w δ hδ (hC t)
  all_goals intro t; exact (Measure.addHaar_closedBall_center (volume.prod volume) _ _).le

end N2Restriction

#print axioms N2Restriction.centered_perturbed_block_cylinders
