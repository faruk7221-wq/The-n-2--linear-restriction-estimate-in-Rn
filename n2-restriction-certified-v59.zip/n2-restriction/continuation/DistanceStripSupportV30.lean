import continuation.NormalLipschitzBufferV30
import continuation.StripChartAmplitudeV29
import continuation.UniformStripExtensionV29

namespace N2Restriction
open MeasureTheory Set Metric
open scoped NNReal ENNReal

/-- Frame coordinates contract the ambient norm; their product norm is max. -/
theorem pairFrameMap_norm_le {n : ℕ} {q : Ambient n × Ambient n}
    (hq : q ∈ orthonormalPairSet n) (v : Ambient n) : ‖pairFrameMap q v‖ ≤ ‖v‖ := by
  change max ‖inner ℝ q.1 v‖ ‖inner ℝ q.2 v‖ ≤ ‖v‖
  exact max_le (by simpa [hq.1] using norm_inner_le_norm (𝕜 := ℝ) q.1 v)
    (by simpa [hq.2.1] using norm_inner_le_norm (𝕜 := ℝ) q.2 v)

/-- Proximity to a zero target implies a strip bound on a common normal
Lipschitz region. The target need not be nonempty or measurable. -/
theorem normal_strip_of_zero_target_distance {n : ℕ} (S : SmoothPatch n)
    {q : Ambient n × Ambient n} (hq : q ∈ orthonormalPairSet n)
    {U Z : Set (Ambient n)} {M : ℝ≥0} (hN : LipschitzOnWith M S.normal U)
    (hZU : Z ⊆ U) (hzero : ∀ y ∈ Z, pairFrameMap q (S.normal y) = 0)
    {x : Ambient n} (hx : x ∈ U) {a : ℝ}
    (hd : ∃ y ∈ Z, dist x y ≤ a) : ‖pairFrameMap q (S.normal x)‖ ≤ M * a := by
  obtain ⟨y, hy, hxy⟩ := hd
  calc
    ‖pairFrameMap q (S.normal x)‖ = ‖pairFrameMap q (S.normal x - S.normal y)‖ := by
      rw [map_sub, hzero y hy, sub_zero]
    _ ≤ ‖S.normal x - S.normal y‖ := pairFrameMap_norm_le hq _
    _ = dist (S.normal x) (S.normal y) := (dist_eq_norm _ _).symm
    _ ≤ M * dist x y := hN.dist_le_mul _ hx _ (hZU hy)
    _ ≤ M * a := mul_le_mul_of_nonneg_left hxy M.coe_nonneg

/-- Distance-supported actual chart inputs satisfy the affine strip condition.
The almost-everywhere chart membership is retained explicitly. -/
theorem MeasuredTubularChart.distance_support_to_strip {n : ℕ} {S : SmoothPatch n}
    {q : Ambient n × Ambient n} {z : Ambient n} {δ r ρ s : ℝ}
    {B : ℕ → ℝ} {c C : ℝ≥0} {L : ℝ}
    (F : MeasuredTubularChart S (pairFrameMap q) z δ r ρ s B c C L)
    (hρ : ρ ≤ r) (hq : q ∈ orthonormalPairSet n)
    {U Z : Set (Ambient n)} {M : ℝ≥0} (hN : LipschitzOnWith M S.normal U)
    (hFU : F.carrier ⊆ U) (hZU : Z ⊆ U)
    (hzero : ∀ y ∈ Z, pairFrameMap q (S.normal y) = 0) (a : ℝ)
    (g : Lp ℂ 2 ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier))
    (hg : HasFrequencySupport ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier)
      id {x | ∃ y ∈ Z, dist x y ≤ a} g) :
    HasFrequencySupport ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier)
      id {x | ‖pairFrameMap q (S.normal x)‖ ≤ M * a} g := by
  filter_upwards [ae_restrict_mem (μ := Measure.hausdorffMeasure ((n : ℝ) - 1))
    (F.compact_carrier hρ).measurableSet, hg] with x hx hh hn
  exact normal_strip_of_zero_target_distance S hq hN hZU hzero (hFU hx) (hh hn)

/-- Full coordinate preparation is available for distance-supported inputs,
with exactly the converted thickness M*a. -/
theorem MeasuredTubularChart.distance_supported_amplitude {n : ℕ} {S : SmoothPatch n}
    {q : Ambient n × Ambient n} {z : Ambient n} {δ r ρ s : ℝ}
    {B : ℕ → ℝ} {c C : ℝ≥0} {L α β : ℝ}
    (F : MeasuredTubularChart S (pairFrameMap q) z δ r ρ s B c C L)
    (hn : 1 ≤ n) (hρ : ρ ≤ r) (hq : q ∈ orthonormalPairSet n)
    (E : ChartNormalCoordinates F α β)
    {U Z : Set (Ambient n)} {M : ℝ≥0} (hN : LipschitzOnWith M S.normal U)
    (hFU : F.carrier ⊆ U) (hZU : Z ⊆ U)
    (hzero : ∀ y ∈ Z, pairFrameMap q (S.normal y) = 0) (a : ℝ)
    (g : Lp ℂ 2 ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier))
    (hg : HasFrequencySupport ((Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict F.carrier)
      id {x | ∃ y ∈ Z, dist x y ≤ a} g) :
    Nonempty (StripChartAmplitude F E g (M * a)) :=
  exists_strip_chart_amplitude F hn hρ E g
    (F.distance_support_to_strip hρ hq hN hFU hZU hzero a g hg)

end N2Restriction

#print axioms N2Restriction.MeasuredTubularChart.distance_support_to_strip
#print axioms N2Restriction.MeasuredTubularChart.distance_supported_amplitude
#print axioms N2Restriction.normal_strip_of_zero_target_distance
#print axioms N2Restriction.pairFrameMap_norm_le
