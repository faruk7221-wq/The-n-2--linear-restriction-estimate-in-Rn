import N2Restriction.FiniteCapCover

namespace N2Restriction
open MeasureTheory Metric Set

/-- Euclidean packing estimate obtained from disjoint small balls.
The dimension-zero case is included. -/
theorem separated_cap_packing {d : ℕ} (t : Finset (Ambient d)) (z : Ambient d)
    {s L : ℝ} (hs : 0 < s) (hL : 0 ≤ L)
    (hsep : (↑t : Set (Ambient d)).Pairwise (fun x y => 2 * s ≤ dist x y))
    (hcenter : ∀ c ∈ t, dist c z ≤ L) :
    (t.card : ℝ) * s ^ d ≤ (L + s) ^ d := by
  have hdisj : (↑t : Set (Ambient d)).PairwiseDisjoint (fun c => ball c s) := by
    intro x hx y hy hxy
    exact ball_disjoint_ball (by simpa only [two_mul] using hsep hx hy hxy)
  have hsub : (⋃ c ∈ t, ball c s) ⊆ ball z (L + s) := by
    intro x hx
    obtain ⟨c, hc, hxc⟩ := Set.mem_iUnion₂.mp hx
    have hxc' : dist x c < s := hxc
    have hcz := hcenter c hc
    have := dist_triangle x c z
    change dist x z < L + s
    linarith
  have hvol := measure_mono (μ := (volume : Measure (Ambient d))) hsub
  rw [measure_biUnion_finset hdisj (fun _ _ => measurableSet_ball)] at hvol
  simp_rw [Measure.addHaar_ball_of_pos volume _ hs] at hvol
  rw [Measure.addHaar_ball_of_pos volume z (by positivity : 0 < L + s)] at hvol
  simp only [Ambient, finrank_euclideanSpace, Fintype.card_fin, Finset.sum_const,
    nsmul_eq_mul, ← mul_assoc] at hvol
  have hcancel := (ENNReal.mul_le_mul_right
    (ne_of_gt (measure_ball_pos volume (0 : Ambient d) (by norm_num : (0 : ℝ) < 1)))
    measure_ball_lt_top.ne).mp hvol
  have hreal := ENNReal.toReal_mono (by finiteness) hcancel
  simpa only [ENNReal.toReal_mul, ENNReal.toReal_natCast,
    ENNReal.toReal_ofReal (pow_nonneg hs.le _),
    ENNReal.toReal_ofReal (pow_nonneg (by positivity : 0 ≤ L + s) _)] using hreal

open Classical in
/-- At most 9^d of the enlarged radius-2r caps can cover any point. -/
theorem separated_cap_overlap {d : ℕ} (t : Finset (Ambient d)) {r : ℝ} (hr : 0 < r)
    (hsep : (↑t : Set (Ambient d)).Pairwise (fun x y => r / 2 < dist x y))
    (x : Ambient d) :
    ((t.filter (fun c => x ∈ ball c (2 * r))).card : ℝ) ≤ (9 : ℝ) ^ d := by
  classical
  have h := separated_cap_packing (t.filter (fun c => x ∈ ball c (2 * r))) x
    (show 0 < r / 4 by positivity) (show 0 ≤ 2 * r by positivity) ?_ ?_
  · have hp : (2 * r + r / 4) ^ d = (9 : ℝ) ^ d * (r / 4) ^ d := by
      rw [← mul_pow]
      congr 1
      ring
    rw [hp] at h
    exact (mul_le_mul_iff_left₀ (pow_pos (show 0 < r / 4 by positivity) d)).mp h
  · intro a ha b hb hab
    have hh := hsep (Finset.mem_filter.mp ha).1 (Finset.mem_filter.mp hb).1 hab
    linarith
  · intro c hc
    have hh : dist x c < 2 * r := (Finset.mem_filter.mp hc).2
    simpa only [dist_comm] using hh.le

/-- A global cap-count estimate with the correct inverse-radius power. -/
theorem separated_cap_count {d : ℕ} (t : Finset (Ambient d)) (z : Ambient d)
    {r D : ℝ} (hr : 0 < r) (hr1 : r ≤ 1) (hD : 0 ≤ D)
    (hsep : (↑t : Set (Ambient d)).Pairwise (fun x y => r / 2 < dist x y))
    (hcenter : ∀ c ∈ t, dist c z ≤ D) :
    (t.card : ℝ) ≤ (4 * D + 1) ^ d * r ^ (-(d : ℝ)) := by
  have h := separated_cap_packing t z (show 0 < r / 4 by positivity) hD
    (fun a ha b hb hab => by have := hsep ha hb hab; linarith) hcenter
  have hbound : (D + r / 4) ^ d ≤ ((4 * D + 1) / 4) ^ d := by
    apply pow_le_pow_left₀ (by positivity)
    linarith
  have hh := h.trans hbound
  have hfour : (0 : ℝ) < (4 : ℝ) ^ d := by positivity
  rw [div_pow, div_pow] at hh
  have hh' : (t.card : ℝ) * r ^ d ≤ (4 * D + 1) ^ d := by
    have := (div_le_div_iff_of_pos_right hfour).mp (show
      (t.card : ℝ) * r ^ d / 4 ^ d ≤ (4 * D + 1) ^ d / 4 ^ d by simpa only [mul_div_assoc] using hh)
    exact this
  rw [Real.rpow_neg hr.le, Real.rpow_natCast]
  exact (le_div_iff₀ (pow_pos hr d)).mpr hh'

end N2Restriction
