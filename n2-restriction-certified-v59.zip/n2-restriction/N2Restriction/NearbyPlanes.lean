import N2Restriction.ThinSupportChart

namespace N2Restriction

/-- Quantitative inverse between different finite-dimensional spaces of equal
rank. This permits the projected curvature map to have output H instead of W. -/
theorem inverse_between_equal_dimensions {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    (A : E →L[ℝ] F) (hdim : Module.finrank ℝ E = Module.finrank ℝ F)
    {κ : ℝ} (hκ : 0 < κ) (hA : ∀ v, κ * ‖v‖ ≤ ‖A v‖) :
    ∃ B : F →L[ℝ] E, A.comp B = ContinuousLinearMap.id ℝ F ∧
      B.comp A = ContinuousLinearMap.id ℝ E ∧ ‖B‖ ≤ κ⁻¹ := by
  let e : E ≃L[ℝ] F := (A.toLinearMap.linearEquivOfInjective
    (injective_of_coercive A hκ hA) hdim).toContinuousLinearEquiv
  have he (v : E) : e v = A v := rfl
  refine ⟨e.symm.toContinuousLinearMap, ?_, ?_, ?_⟩
  · ext v
    exact (he (e.symm v)).symm.trans (e.apply_symm_apply v)
  · ext v
    exact congrArg e.symm (he v).symm |>.trans (e.symm_apply_apply v)
  · apply ContinuousLinearMap.opNorm_le_bound _ (inv_nonneg.mpr hκ.le)
    intro v
    have h := hA (e.symm v)
    rw [← he, e.apply_symm_apply] at h
    rw [← div_eq_inv_mul, le_div_iff₀ hκ]
    simpa [mul_comm] using h

/-- Replacing the output projection by a nearby plane loses at most half the
coercivity constant; the distance is the norm of the ambient projection difference. -/
theorem nearby_projection_coercive {E : Type*} [NormedAddCommGroup E]
    [InnerProductSpace ℝ E] [FiniteDimensional ℝ E] (W H : Submodule ℝ E)
    (A : E →L[ℝ] E) {κ : ℝ}
    (hA : ∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (A v)‖)
    (hgap : ‖W.starProjection - H.starProjection‖ * ‖A‖ ≤ κ / 2) :
    ∀ v : W, (κ / 2) * ‖v‖ ≤ ‖H.orthogonalProjection (A v)‖ := by
  have hdiff (v : W) : ‖W.starProjection (A v) - H.starProjection (A v)‖ ≤
      (κ / 2) * ‖v‖ := by
    calc
      ‖W.starProjection (A v) - H.starProjection (A v)‖ ≤
          ‖W.starProjection - H.starProjection‖ * ‖A v‖ :=
        (W.starProjection - H.starProjection).le_opNorm _
      _ ≤ ‖W.starProjection - H.starProjection‖ * (‖A‖ * ‖v‖) :=
        mul_le_mul_of_nonneg_left (A.le_opNorm _) (norm_nonneg _)
      _ ≤ (κ / 2) * ‖v‖ := by rw [← mul_assoc]; exact mul_le_mul_of_nonneg_right hgap (norm_nonneg _)
  have h := coercivity_under_perturbation
    (fun v : W => W.starProjection (A v)) (fun v : W => H.starProjection (A v)) hA hdiff
  simpa only [show κ - κ / 2 = κ / 2 by ring] using h

/-- The projected shape map W to a nearby H has a right inverse with norm
at most 2/kappa. This proves the linear perturbation step in Lemma 4.1. -/
theorem nearby_projected_shape_inverse {E : Type*} [NormedAddCommGroup E]
    [InnerProductSpace ℝ E] [FiniteDimensional ℝ E] (W H : Submodule ℝ E)
    (hdim : Module.finrank ℝ W = Module.finrank ℝ H) (A : E →L[ℝ] E)
    {κ : ℝ} (hκ : 0 < κ)
    (hA : ∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (A v)‖)
    (hgap : ‖W.starProjection - H.starProjection‖ * ‖A‖ ≤ κ / 2) :
    ∃ B : H →L[ℝ] W,
      (H.orthogonalProjection.comp (A.comp W.subtypeL)).comp B = ContinuousLinearMap.id ℝ H ∧
      B.comp (H.orthogonalProjection.comp (A.comp W.subtypeL)) = ContinuousLinearMap.id ℝ W ∧
      ‖B‖ ≤ 2 / κ := by
  obtain ⟨B, h₁, h₂, hb⟩ := inverse_between_equal_dimensions
    (H.orthogonalProjection.comp (A.comp W.subtypeL)) hdim
    (by positivity : 0 < κ / 2) (nearby_projection_coercive W H A hA hgap)
  exact ⟨B, h₁, h₂, by simpa [div_eq_mul_inv, mul_comm] using hb⟩

/-- The combined hypersurface and projected-normal constraints remain a
submersion when the projection plane is perturbed. -/
theorem nearby_thinDifferential_surjective {n : ℕ} (S : SmoothPatch n)
    (W H : Submodule ℝ (Ambient n)) (hdim : Module.finrank ℝ W = Module.finrank ℝ H)
    {z : Ambient n} (hz : z ∈ S.neighborhood)
    (hW : ∀ v : W, inner ℝ (S.normal z) (v : Ambient n) = 0)
    {κ : ℝ} (hκ : 0 < κ)
    (hA : ∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (S.shape z v)‖)
    (hgap : ‖W.starProjection - H.starProjection‖ * ‖S.shape z‖ ≤ κ / 2) :
    Function.Surjective (thinDifferential S H z) := by
  obtain ⟨J, hJ, _, _⟩ := nearby_projected_shape_inverse W H hdim (S.shape z) hκ hA hgap
  have hsolve (w : H) : H.orthogonalProjection (S.shape z (J w)) = w :=
    congrArg (fun L : H →L[ℝ] H => L w) hJ
  have hnsolve (w : H) : H.orthogonalProjection (fderiv ℝ S.normal z (J w)) = -w := by
    have h := hsolve w
    change H.orthogonalProjection (-(fderiv ℝ S.normal z (J w))) = w at h
    rw [map_neg] at h
    exact neg_eq_iff_eq_neg.mp h
  intro t
  let u : Ambient n := (t.1 / S.normalScale z) • S.normal z
  let v : W := J (H.orthogonalProjection (fderiv ℝ S.normal z u) - t.2)
  refine ⟨u + v, ?_⟩
  apply Prod.ext
  · change fderiv ℝ S.defining z (u + v) = t.1
    rw [map_add, S.normal_differential z hz (v : Ambient n), hW v, mul_zero, add_zero]
    rw [S.normal_differential z hz u]
    dsimp [u]
    rw [inner_smul_right, real_inner_self_eq_norm_sq, S.normal_unit z hz]
    field_simp [ne_of_gt (S.positive_normalScale z hz)]
  · change H.orthogonalProjection (fderiv ℝ S.normal z (u + v)) = t.2
    rw [map_add, map_add]
    dsimp only [v]
    rw [hnsolve]
    abel

/-- A genuine local chart for each admissible nearby plane. The statement
is pointwise in the plane parameter and does not assert uniform chart radii. -/
theorem exists_nearby_thin_chart {n : ℕ} (S : SmoothPatch n)
    (W H : Submodule ℝ (Ambient n)) (hdim : Module.finrank ℝ W = Module.finrank ℝ H)
    {z : Ambient n} (hz : z ∈ S.neighborhood)
    (hW : ∀ v : W, inner ℝ (S.normal z) (v : Ambient n) = 0)
    {κ : ℝ} (hκ : 0 < κ)
    (hA : ∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (S.shape z v)‖)
    (hgap : ‖W.starProjection - H.starProjection‖ * ‖S.shape z‖ ≤ κ / 2) :
    ∃ e : OpenPartialHomeomorph (Ambient n)
      ((ℝ × H) × LinearMap.ker (thinDifferential S H z).toLinearMap),
      z ∈ e.source ∧ e z = (thinConstraint S H z, 0) ∧
      ∀ y : Ambient n, (e y).1 = thinConstraint S H y := by
  have hds := S.smooth_defining.contDiffAt (S.open_neighborhood.mem_nhds hz)
  have hns := S.smooth_normal.contDiffAt (S.open_neighborhood.mem_nhds hz)
  have hs : ContDiffAt ℝ (⊤ : ℕ∞) (thinConstraint S H) z :=
    hds.prodMk (H.orthogonalProjection.contDiff.contDiffAt.comp z hns)
  have hd := hs.hasStrictFDerivAt' (hasFDerivAt_thinConstraint S H hz) (by simp)
  have hr : LinearMap.range (thinDifferential S H z).toLinearMap = ⊤ :=
    LinearMap.range_eq_top.mpr (nearby_thinDifferential_surjective S W H hdim hz hW hκ hA hgap)
  exact ⟨hd.implicitToOpenPartialHomeomorph _ _ hr,
    hd.mem_implicitToOpenPartialHomeomorph_source hr,
    hd.implicitToOpenPartialHomeomorph_self hr,
    fun y => hd.implicitToOpenPartialHomeomorph_fst hr y⟩

end N2Restriction
