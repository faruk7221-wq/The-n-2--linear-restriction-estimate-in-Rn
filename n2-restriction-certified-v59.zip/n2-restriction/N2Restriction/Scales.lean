import N2Restriction.PowerRecurrence
import N2Restriction.Exponents

namespace N2Restriction
open Filter

/-- The new partition degree can be chosen after all old constants.
This is the quantified numerical implication used after (6.10). -/
theorem exists_contracting_degree {e c : ℝ} (he : e < 0) (hc : 0 < c) (C : ℝ) :
    ∃ D : ℕ, 1 ≤ D ∧ C * (D : ℝ) ^ e < c := by
  have h := eventually_power_small (a := -e) (by linarith) hc C
  simp only [neg_neg] at h
  obtain ⟨T, hT⟩ := eventually_atTop.1 h
  obtain ⟨D, hD⟩ := exists_nat_gt (max 1 T)
  have hD1 : (1 : ℝ) < D := (le_max_left _ _).trans_lt hD
  refine ⟨D, ?_, hT D ((le_max_right 1 T).trans hD.le)⟩
  exact_mod_cast hD1.le

/-- Combine the exact nonterminal exponent calculation with degree selection. -/
theorem nonterminal_degree_choice {k s t : ℕ} {p c : ℝ}
    (hk : 3 ≤ k) (hs : 1 ≤ s) (hsmax : s ≤ k + 2)
    (ht : k + 1 ≤ s + t) (hp : critical k < p) (hc : 0 < c) (Cold : ℝ) :
    ∃ D : ℕ, 1 ≤ D ∧ Cold * (D : ℝ) ^ cellular k s t p < c :=
  exists_contracting_degree (nonterminal_cellular_negative hk hs hsmax ht hp) hc Cold

/-- Uniform support-margin inequality (8.1). It holds for every child in
[1,R/2], simultaneously, so no separate enlargement loss is needed along
the finite dimension descent. -/
theorem eventually_support_margin (C : ℝ) :
    ∀ᶠ R : ℝ in atTop, ∀ L : ℝ, 1 ≤ L → L ≤ R / 2 →
      C * R ^ (-1 / 2 : ℝ) ≤ L ^ (-1 / 4 : ℝ) - R ^ (-1 / 4 : ℝ) := by
  have hgap : 0 < (2 : ℝ) ^ (1 / 4 : ℝ) - 1 := by
    have h := Real.one_lt_rpow (by norm_num : (1 : ℝ) < 2) (by norm_num : (0 : ℝ) < 1 / 4)
    linarith
  have hsmall := eventually_power_small (a := 1 / 4) (by norm_num) hgap C
  filter_upwards [hsmall, eventually_ge_atTop (1 : ℝ)] with R hsmall hR
  intro L hL hLhalf
  have hRp : 0 < R := by linarith
  have hLp : 0 < L := by linarith
  have hW : 0 < R ^ (-1 / 4 : ℝ) := Real.rpow_pos_of_pos hRp _
  have hratio := half_scale_ratio (R := R) (d := -1 / 4) hRp
  have hprod : (R / 2) ^ (-1 / 4 : ℝ) =
      (2 : ℝ) ^ (1 / 4 : ℝ) * R ^ (-1 / 4 : ℝ) := by
    apply (div_eq_iff (ne_of_gt hW)).mp
    convert hratio using 1
    norm_num
  have hmono := Real.rpow_le_rpow_of_nonpos hLp hLhalf (by norm_num : (-1 / 4 : ℝ) ≤ 0)
  have hid : C * R ^ (-1 / 2 : ℝ) =
      (C * R ^ (-1 / 4 : ℝ)) * R ^ (-1 / 4 : ℝ) := by
    rw [mul_assoc, ← Real.rpow_add hRp]
    norm_num
  rw [hid]
  have hs := mul_le_mul_of_nonneg_right hsmall.le hW.le
  rw [hprod] at hmono
  nlinarith

end N2Restriction
