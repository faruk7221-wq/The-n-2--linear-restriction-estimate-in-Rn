import N2Restriction.SmoothCompactIntegral
import N2Restriction.GraphPackets
import Mathlib.MeasureTheory.Integral.IntervalIntegral.IntegrationByParts

namespace N2Restriction
open MeasureTheory Set

/-- The integral Taylor remainder is defined also at radius zero. -/
noncomputable def graphTaylorRemainder {d : ℕ} (φ : Ambient d → ℝ)
    (q : (Ambient d × ℝ) × Ambient d) : ℝ :=
  ∫ s in Icc (0 : ℝ) 1, (1 - s) *
    fderiv ℝ (fderiv ℝ φ) (q.1.1 + (s * q.1.2) • q.2) q.2 q.2

/-- The rescaled second-order remainder is jointly smooth in center, scale,
and frequency, including zero and negative scales. -/
theorem smooth_graphTaylorRemainder {d : ℕ} {φ : Ambient d → ℝ}
    (hφ : ContDiff ℝ (⊤ : ℕ∞) φ) :
    ContDiff ℝ (⊤ : ℕ∞) (graphTaylorRemainder φ) := by
  have hd := (contDiff_infty_iff_fderiv.mp (contDiff_infty_iff_fderiv.mp hφ).2).2
  have hp : ContDiff ℝ (⊤ : ℕ∞)
      (fun q : ((Ambient d × ℝ) × Ambient d) × ℝ =>
        q.1.1.1 + (q.2 * q.1.1.2) • q.1.2) := by fun_prop
  have he : ContDiff ℝ (⊤ : ℕ∞)
      (fun q : ((Ambient d × ℝ) × Ambient d) × ℝ =>
        (1 - q.2) * fderiv ℝ (fderiv ℝ φ)
          (q.1.1.1 + (q.2 * q.1.1.2) • q.1.2) q.1.2 q.1.2) :=
    (contDiff_const.sub contDiff_snd).mul
      (((hd.comp hp).clm_apply (contDiff_snd.comp contDiff_fst)).clm_apply
        (contDiff_snd.comp contDiff_fst))
  exact smooth_compact_integral he 0 1

/-- The one-dimensional second-order Taylor formula on the unit interval,
proved by integration by parts and the fundamental theorem of calculus. -/
theorem unit_interval_second_order {g g' g'' : ℝ → ℝ}
    (hg : ∀ s, HasDerivAt g (g' s) s)
    (hg' : ∀ s, HasDerivAt g' (g'' s) s)
    (hc : Continuous g'') :
    g 1 = g 0 + g' 0 + ∫ s in Icc (0 : ℝ) 1, (1 - s) * g'' s := by
  have hc' : Continuous g' := continuous_iff_continuousAt.mpr (fun s => (hg' s).continuousAt)
  have hi := intervalIntegral.integral_mul_deriv_eq_deriv_mul
    (u := fun s : ℝ => 1 - s) (u' := fun _ => (-1 : ℝ)) (v := g') (v' := g'')
    (a := 0) (b := 1)
    (fun s _ => by simpa using (hasDerivAt_const s (1 : ℝ)).sub (hasDerivAt_id s))
    (fun s _ => hg' s) (continuous_const.intervalIntegrable 0 1) (hc.intervalIntegrable 0 1)
  have ht := intervalIntegral.integral_eq_sub_of_hasDerivAt
    (a := 0) (b := 1) (fun s _ => hg s) (hc'.intervalIntegrable 0 1)
  simp only [sub_self, zero_mul, sub_zero, one_mul, neg_one_mul,
    intervalIntegral.integral_neg] at hi
  rw [ht] at hi
  rw [integral_Icc_eq_integral_Ioc, ← intervalIntegral.integral_of_le (by norm_num : (0 : ℝ) ≤ 1)]
  linarith

/-- First derivative along the affine frequency path. -/
theorem graph_path_hasDerivAt {d : ℕ} {φ : Ambient d → ℝ}
    (hφ : ContDiff ℝ (⊤ : ℕ∞) φ) (c η : Ambient d) (r s : ℝ) :
    HasDerivAt (fun z => φ (c + (z * r) • η))
      (r * fderiv ℝ φ (c + (s * r) • η) η) s := by
  have hp : HasDerivAt (fun z : ℝ => c + (z * r) • η) (r • η) s := by
    simpa using (((hasDerivAt_id s).mul_const r).smul_const η).const_add c
  have h := (hφ.differentiable (by simp) _).hasFDerivAt.comp_hasDerivAt s hp
  simpa using h

/-- The path's second derivative is the scaled Hessian quadratic form. -/
theorem graph_path_second_hasDerivAt {d : ℕ} {φ : Ambient d → ℝ}
    (hφ : ContDiff ℝ (⊤ : ℕ∞) φ) (c η : Ambient d) (r s : ℝ) :
    HasDerivAt (fun z => r * fderiv ℝ φ (c + (z * r) • η) η)
      (r ^ 2 * fderiv ℝ (fderiv ℝ φ) (c + (s * r) • η) η η) s := by
  have hp : HasDerivAt (fun z : ℝ => c + (z * r) • η) (r • η) s := by
    simpa using (((hasDerivAt_id s).mul_const r).smul_const η).const_add c
  have hd := (contDiff_infty_iff_fderiv.mp hφ).2
  have hh := (hd.differentiable (by simp) _).hasFDerivAt.comp_hasDerivAt s hp
  have he := (hh.clm_apply (hasDerivAt_const s η)).const_mul r
  convert he using 1
  simp [pow_two, mul_assoc]

/-- Exact smooth-graph Taylor rescaling, with a remainder smooth at r=0. -/
theorem graphTaylorRemainder_identity {d : ℕ} {φ : Ambient d → ℝ}
    (hφ : ContDiff ℝ (⊤ : ℕ∞) φ) (c η : Ambient d) (r : ℝ) :
    φ (c + r • η) = φ c + r * fderiv ℝ φ c η +
      r ^ 2 * graphTaylorRemainder φ ((c, r), η) := by
  have hd := (contDiff_infty_iff_fderiv.mp (contDiff_infty_iff_fderiv.mp hφ).2).2
  have hc : Continuous (fun s : ℝ => r ^ 2 *
      fderiv ℝ (fderiv ℝ φ) (c + (s * r) • η) η η) :=
    continuous_const.mul (((hd.continuous.comp (by fun_prop)).clm_apply continuous_const).clm_apply
      continuous_const)
  have h := unit_interval_second_order (graph_path_hasDerivAt hφ c η r)
    (graph_path_second_hasDerivAt hφ c η r) hc
  simp only [one_mul, zero_mul, zero_smul, add_zero] at h
  rw [graphTaylorRemainder, ← integral_const_mul]
  convert h using 1
  congr 1
  apply integral_congr_ae
  filter_upwards with s
  ring

end N2Restriction
