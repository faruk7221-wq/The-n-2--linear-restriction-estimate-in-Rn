import N2Restriction.Recurrence

/-! Analytic-independent power comparisons and the three-child recurrence (8.2).
A below models A_p^p, so d is epsilon*p and a is sigma*p.
The recurrence itself is an explicit hypothesis, not an axiom. -/

namespace N2Restriction
open Filter
open scoped Topology

lemma eventually_power_small {a δ : ℝ} (ha : 0 < a) (hδ : 0 < δ) (C : ℝ) :
    ∀ᶠ R : ℝ in atTop, C * R ^ (-a) < δ := by
  have hlim : Tendsto (fun R : ℝ => C * R ^ (-a)) atTop (𝓝 0) := by
    simpa using (tendsto_rpow_neg_atTop ha).const_mul C
  exact hlim.eventually (gt_mem_nhds hδ)

lemma power_scale_ratio {R c α d : ℝ} (hR : 0 < R) (hc : 0 ≤ c) :
    (c * R ^ α) ^ d / R ^ d = c ^ d * R ^ (-d * (1 - α)) := by
  rw [Real.mul_rpow hc (Real.rpow_nonneg hR.le _), ← Real.rpow_mul hR.le,
    mul_div_assoc, ← Real.rpow_sub hR]
  congr 2
  ring

lemma half_scale_ratio {R d : ℝ} (hR : 0 < R) :
    (R / 2) ^ d / R ^ d = (2 : ℝ) ^ (-d) := by
  rw [Real.div_rpow hR.le (by norm_num), div_div]
  have hn : R ^ d ≠ 0 := ne_of_gt (Real.rpow_pos_of_pos hR d)
  rw [mul_comm (2 ^ d), ← div_div, div_self hn, one_div, Real.rpow_neg (by norm_num : (0 : ℝ) ≤ 2)]

/-- Exact normalized exponents used in Section 8. -/
lemma child_power_ratios {R C τ d : ℝ} (hR : 0 < R) (hC : 0 < C) :
    (R ^ (1 - τ)) ^ d / R ^ d = R ^ (-d * τ) ∧
    C * (C * R ^ (1 / 2 + τ)) ^ d / R ^ d =
      C ^ (1 + d) * R ^ (-d * (1 / 2 - τ)) := by
  constructor
  · simpa using power_scale_ratio (R := R) (c := 1) (α := 1 - τ) (d := d) hR (by norm_num)
  · have hr := power_scale_ratio (R := R) (c := C) (α := 1 / 2 + τ) (d := d) hR hC.le
    calc
      C * (C * R ^ (1 / 2 + τ)) ^ d / R ^ d =
          C * ((C * R ^ (1 / 2 + τ)) ^ d / R ^ d) := by ring
      _ = C * (C ^ d * R ^ (-d * (1 - (1 / 2 + τ)))) := by rw [hr]
      _ = C ^ (1 + d) * R ^ (-d * (1 / 2 - τ)) := by
        rw [Real.rpow_add hC, Real.rpow_one]
        rw [show 1 - (1 / 2 + τ) = 1 / 2 - τ by ring]
        ring

/-- A generic weighted three-child recurrence closes once its eventual
scale inequalities hold. No monotonicity of A is required. -/
theorem close_three_child_recurrence
    (A : ℝ → ℝ) (C D d a τ R₀ C₀ : ℝ)
    (hR₀ : 1 ≤ R₀) (hd : 0 < d) (ha : a ≤ d) (hC : 0 < C) (hD : 0 ≤ D)
    (hbase : ∀ R, 1 ≤ R → R ≤ R₀ → A R ≤ C₀ * R ^ d)
    (hchild : ∀ R, R₀ < R →
      1 ≤ R / 2 ∧ 1 ≤ R ^ (1 - τ) ∧ R ^ (1 - τ) ≤ R / 2 ∧
      1 ≤ C * R ^ (1 / 2 + τ) ∧ C * R ^ (1 / 2 + τ) ≤ R / 2)
    (hsmall : ∀ R, R₀ < R →
      C * R ^ (-d * τ) ≤ 1 / 8 ∧
      C ^ (1 + d) * R ^ (-d * (1 / 2 - τ)) ≤ 1 / 8)
    (hrec : ∀ R, R₀ < R →
      A R ≤ 1 / 4 * A (R / 2) + C * A (R ^ (1 - τ)) +
        C * A (C * R ^ (1 / 2 + τ)) + D * R ^ a) :
    ∃ K : ℝ, 0 ≤ K ∧ ∀ R, 1 ≤ R → A R ≤ K * R ^ d := by
  let child : Fin 3 → ℝ → ℝ := ![fun R => R / 2,
    fun R => R ^ (1 - τ), fun R => C * R ^ (1 / 2 + τ)]
  let coeff : Fin 3 → ℝ → ℝ := ![fun _ => 1 / 4, fun _ => C, fun _ => C]
  apply close_radius_recurrence A (fun R => R ^ d) child coeff
    (fun R => D * R ^ a) R₀ (1 / 2) D C₀ hR₀ (by norm_num)
  · intro R hR
    exact Real.rpow_pos_of_pos (by linarith) d
  · intro i R _
    fin_cases i <;> simp [coeff, hC.le]
  · intro i R hR
    obtain ⟨h0, h1, h1', h2, h2'⟩ := hchild R hR
    fin_cases i <;> simp only [child]
    · exact ⟨h0, le_rfl⟩
    · exact ⟨h1, h1'⟩
    · exact ⟨h2, h2'⟩
  · exact hbase
  · intro R hR
    simpa [child, coeff, Fin.sum_univ_succ, add_assoc] using hrec R hR
  · intro R hR
    have hRp : 0 < R := by linarith
    have hRone : 1 ≤ R := by linarith
    have hpow : 0 < R ^ d := Real.rpow_pos_of_pos hRp d
    obtain ⟨h1, h2⟩ := hsmall R hR
    obtain ⟨hr1, hr2⟩ := child_power_ratios (d := d) (τ := τ) hRp hC
    have hh : (2 : ℝ) ^ (-d) ≤ 1 := Real.rpow_le_one_of_one_le_of_nonpos
      (by norm_num) (by linarith)
    have hhalf := half_scale_ratio (d := d) hRp
    change (∑ i, coeff i R * (child i R) ^ d) ≤ (1 / 2) * R ^ d
    rw [← div_le_iff₀ hpow]
    simp only [Fin.sum_univ_succ, coeff, child, Matrix.cons_val_zero,
      Matrix.cons_val_succ, Fin.sum_univ_zero, add_zero]
    simp only [add_div, mul_div_assoc, hhalf, hr1]
    rw [← mul_div_assoc C, hr2]
    nlinarith
  · intro R hR
    exact mul_le_mul_of_nonneg_left
      (Real.rpow_le_rpow_of_exponent_le (by linarith : 1 ≤ R) ha) hD

/-- The three actual child radii eventually lie in [1,R/2]. -/
lemma eventually_children {τ C : ℝ} (hτ : 0 < τ) (hτ' : τ < 1 / 2)
    (hC : 0 < C) :
    ∀ᶠ R : ℝ in atTop,
      1 ≤ R / 2 ∧ 1 ≤ R ^ (1 - τ) ∧ R ^ (1 - τ) ≤ R / 2 ∧
      1 ≤ C * R ^ (1 / 2 + τ) ∧ C * R ^ (1 / 2 + τ) ≤ R / 2 := by
  have h1 := eventually_power_small (a := τ) hτ (by norm_num : (0 : ℝ) < 1 / 2) 1
  have h2 := eventually_power_small (a := 1 / 2 - τ) (by linarith)
    (by norm_num : (0 : ℝ) < 1 / 2) C
  have hlo : ∀ᶠ R : ℝ in atTop, 1 ≤ C * R ^ (1 / 2 + τ) := by
    have ht := (tendsto_rpow_atTop (show 0 < 1 / 2 + τ by linarith)).const_mul_atTop hC
    exact ht.eventually (eventually_ge_atTop 1)
  filter_upwards [h1, h2, hlo, eventually_ge_atTop (2 : ℝ)] with R h1 h2 hlo hR
  have hRp : 0 < R := by linarith
  have hp1 := power_scale_ratio (R := R) (c := 1) (α := 1 - τ) (d := 1) hRp (by norm_num)
  have hp2 := power_scale_ratio (R := R) (c := C) (α := 1 / 2 + τ) (d := 1) hRp hC.le
  simp only [one_mul, Real.rpow_one] at hp1 hp2
  have he1 : -(1 : ℝ) * (1 - (1 - τ)) = -τ := by ring
  have he2 : -(1 : ℝ) * (1 - (1 / 2 + τ)) = -(1 / 2 - τ) := by ring
  rw [he1] at hp1
  rw [he2] at hp2
  refine ⟨by linarith, Real.one_le_rpow (by linarith) (by linarith), ?_, hlo, ?_⟩
  · have h := (div_lt_iff₀ hRp).mp (hp1.trans_lt (by simpa using h1))
    linarith
  · have h := (div_lt_iff₀ hRp).mp (hp2.trans_lt h2)
    linarith

/-- Full power-growth conclusion from the scalar recurrence (8.2), with a
forcing exponent a<d. Local boundedness handles every bounded radius.
This theorem does not assume monotonicity or an inductive growth bound. -/
theorem power_recurrence_growth
    (A : ℝ → ℝ) (C D d a τ : ℝ)
    (hC : 0 < C) (hD : 0 ≤ D) (hd : 0 < d) (ha : a < d)
    (hτ : 0 < τ) (hτ' : τ < 1 / 2)
    (hbounded : ∀ T : ℝ, 1 ≤ T → ∃ M : ℝ, ∀ R, 1 ≤ R → R ≤ T → A R ≤ M)
    (hrec : ∀ᶠ R : ℝ in atTop,
      A R ≤ 1 / 4 * A (R / 2) + C * A (R ^ (1 - τ)) +
        C * A (C * R ^ (1 / 2 + τ)) + D * R ^ a) :
    ∃ K : ℝ, 0 ≤ K ∧ ∀ R, 1 ≤ R → A R ≤ K * R ^ d := by
  have hs1 := eventually_power_small (a := d * τ) (mul_pos hd hτ)
    (by norm_num : (0 : ℝ) < 1 / 8) C
  have hs2 := eventually_power_small (a := d * (1 / 2 - τ)) (mul_pos hd (by linarith))
    (by norm_num : (0 : ℝ) < 1 / 8) (C ^ (1 + d))
  have hall : ∀ᶠ R : ℝ in atTop,
      (1 ≤ R / 2 ∧ 1 ≤ R ^ (1 - τ) ∧ R ^ (1 - τ) ≤ R / 2 ∧
        1 ≤ C * R ^ (1 / 2 + τ) ∧ C * R ^ (1 / 2 + τ) ≤ R / 2) ∧
      (C * R ^ (-d * τ) ≤ 1 / 8 ∧
        C ^ (1 + d) * R ^ (-d * (1 / 2 - τ)) ≤ 1 / 8) ∧
      (A R ≤ 1 / 4 * A (R / 2) + C * A (R ^ (1 - τ)) +
        C * A (C * R ^ (1 / 2 + τ)) + D * R ^ a) := by
    filter_upwards [eventually_children hτ hτ' hC, hs1, hs2, hrec] with R hc hs1 hs2 hr
    exact ⟨hc, ⟨by simpa [neg_mul] using hs1.le, by simpa [neg_mul] using hs2.le⟩, hr⟩
  obtain ⟨T, hT⟩ := eventually_atTop.1 hall
  let R₀ := max 1 T
  have hR₀ : 1 ≤ R₀ := le_max_left _ _
  obtain ⟨M, hM⟩ := hbounded R₀ hR₀
  apply close_three_child_recurrence A C D d a τ R₀ (max 0 M) hR₀ hd ha.le hC hD
  · intro R hR hRR
    have hM0 : M ≤ max 0 M := le_max_right _ _
    have hW : 1 ≤ R ^ d := Real.one_le_rpow hR hd.le
    exact (hM R hR hRR).trans (by nlinarith [le_max_left (0 : ℝ) M])
  · intro R hR
    exact (hT R ((le_max_right 1 T).trans hR.le)).1
  · intro R hR
    exact (hT R ((le_max_right 1 T).trans hR.le)).2.1
  · intro R hR
    exact (hT R ((le_max_right 1 T).trans hR.le)).2.2


/-- Convert a bound for A_p^p into a bound for A_p, with the constants
and exponent conversion that follow (8.3). -/
theorem growth_from_power_bound (A : ℝ → ℝ) {p ε C : ℝ}
    (hp : 0 < p) (hC : 0 ≤ C)
    (hA : ∀ R, 1 ≤ R → 0 ≤ A R)
    (hbound : ∀ R, 1 ≤ R → (A R) ^ p ≤ C * R ^ (ε * p)) :
    ∀ R, 1 ≤ R → A R ≤ C ^ (1 / p) * R ^ ε := by
  intro R hR
  have hRp : 0 < R := by linarith
  have hid : p * (1 / p) = 1 := by field_simp
  have hid' : (ε * p) * (1 / p) = ε := by field_simp
  have h := Real.rpow_le_rpow (Real.rpow_nonneg (hA R hR) p)
    (hbound R hR) (show 0 ≤ 1 / p by positivity)
  rw [← Real.rpow_mul (hA R hR), hid, Real.rpow_one,
    Real.mul_rpow hC (Real.rpow_nonneg hRp.le _),
    ← Real.rpow_mul hRp.le, hid'] at h
  exact h

end N2Restriction
