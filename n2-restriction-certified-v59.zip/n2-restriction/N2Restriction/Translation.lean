import N2Restriction.LocalConstant

namespace N2Restriction
open MeasureTheory
open scoped ENNReal NNReal BigOperators

/-- Frequency modulation corresponding to spatial translation. -/
noncomputable def modulate {n : ℕ} {Ω : Type*} (ζ : Ω → Ambient n)
    (y : Ambient n) (f : Ω → ℂ) (ω : Ω) : ℂ :=
  Complex.exp ((inner ℝ y (ζ ω) : ℂ) * Complex.I) * f ω

lemma norm_modulate {n : ℕ} {Ω : Type*} (ζ : Ω → Ambient n)
    (y : Ambient n) (f : Ω → ℂ) (ω : Ω) : ‖modulate ζ y f ω‖ = ‖f ω‖ := by
  simp [modulate]

lemma memLp_modulate {n : ℕ} {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} {ζ : Ω → Ambient n} {f : Ω → ℂ} {p : ℝ≥0∞}
    (hζ : Measurable ζ) (hf : MemLp f p μ) (y : Ambient n) : MemLp (modulate ζ y f) p μ := by
  have hk : Measurable (fun ω => Complex.exp ((inner ℝ y (ζ ω) : ℂ) * Complex.I)) := by fun_prop
  exact hf.congr_norm (hk.aestronglyMeasurable.mul hf.aestronglyMeasurable)
    (Filter.Eventually.of_forall (fun ω => (norm_modulate ζ y f ω).symm))

lemma eLpNorm_modulate {n : ℕ} {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) (ζ : Ω → Ambient n) (y : Ambient n) (f : Ω → ℂ) (p : ℝ≥0∞) :
    eLpNorm (modulate ζ y f) p μ = eLpNorm f p μ :=
  eLpNorm_congr_norm_ae (Filter.Eventually.of_forall (norm_modulate ζ y f))

/-- The phase identity is exact, including the sign and normalization in (1.3). -/
lemma extension_modulate {n : ℕ} {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) (ζ : Ω → Ambient n) (y : Ambient n) (f : Ω → ℂ) (x : Ambient n) :
    extension μ ζ (modulate ζ y f) x = extension μ ζ f (x + y) := by
  simp only [extension, modulate, inner_add_left, Complex.ofReal_add,
    add_mul, Complex.exp_add, mul_assoc]

/-- Translation of a ball preserves its actual extension norm. -/
lemma ball_norm_translate {n : ℕ} {F : Ambient n → ℂ} (hF : Continuous F)
    (y : Ambient n) (R p : ℝ) :
    eLpNorm' (fun x => F (x + y)) p (volume.restrict (Metric.ball 0 R)) =
      eLpNorm' F p (volume.restrict (Metric.ball y R)) := by
  have hm := (measurePreserving_add_right (volume : Measure (Ambient n)) y).restrict_preimage
    (s := Metric.ball y R) measurableSet_ball
  rw [Metric.preimage_add_right_ball, sub_self] at hm
  simp only [eLpNorm'_eq_lintegral_enorm]
  rw [hm.lintegral_comp (hF.measurable.enorm.pow_const p)]

section
variable {n k : ℕ} {Ω : Fin k → Type*} [∀ i, MeasurableSpace (Ω i)]
variable {μ : ∀ i, Measure (Ω i)} [∀ i, IsFiniteMeasure (μ i)]
variable {ζ : ∀ i, Ω i → Ambient n}

/-- Estimates for the origin-centered ball extend to every center with exactly
the same constant. Modulation preserves each L2 input norm. -/
theorem all_centers_of_origin_bound (hζ : ∀ i, Measurable (ζ i)) {p R : ℝ} {C : ℝ≥0∞}
    (h : ∀ f : ∀ i, Ω i → ℂ, (∀ i, MemLp (f i) 2 (μ i)) →
      eLpNorm' (extensionProduct μ ζ f) p (volume.restrict (Metric.ball 0 R)) ≤
        C * inputNormProduct μ f) :
    ∀ (y : Ambient n) (f : ∀ i, Ω i → ℂ), (∀ i, MemLp (f i) 2 (μ i)) →
      eLpNorm' (extensionProduct μ ζ f) p (volume.restrict (Metric.ball y R)) ≤
        C * inputNormProduct μ f := by
  intro y f hf
  let g : ∀ i, Ω i → ℂ := fun i => modulate (ζ i) y (f i)
  have hg : ∀ i, MemLp (g i) 2 (μ i) := fun i => memLp_modulate (hζ i) (hf i) y
  have hprod : extensionProduct μ ζ g = fun x => extensionProduct μ ζ f (x + y) := by
    funext x
    simp only [extensionProduct, g, extension_modulate]
  have hnorm : inputNormProduct μ g = inputNormProduct μ f := by
    simp only [inputNormProduct, g, eLpNorm_modulate]
  have hb := h g hg
  rw [hprod, hnorm, ball_norm_translate (continuous_extensionProduct hζ hf) y R p] at hb
  exact hb

/-- The best constant can therefore be bounded using only centered balls. -/
lemma localConstant_le_of_origin_bound (hζ : ∀ i, Measurable (ζ i)) {p R : ℝ} {C : ℝ≥0∞}
    (h : ∀ f : ∀ i, Ω i → ℂ, (∀ i, MemLp (f i) 2 (μ i)) →
      eLpNorm' (extensionProduct μ ζ f) p (volume.restrict (Metric.ball 0 R)) ≤
        C * inputNormProduct μ f) : localConstant μ ζ p R ≤ C :=
  localConstant_le_of_bound μ ζ (all_centers_of_origin_bound hζ h)

end
end N2Restriction
