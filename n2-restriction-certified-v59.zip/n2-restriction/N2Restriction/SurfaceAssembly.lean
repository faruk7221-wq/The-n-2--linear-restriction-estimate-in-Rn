import N2Restriction.SurfaceMeasure
import N2Restriction.LocalAssembly

namespace N2Restriction

/-- The conditional local conclusion for the actual Hausdorff surface measures.
There is no remaining finite-surface-mass assumption in this interface. -/
theorem surface_local_range_of_recurrences {k : ℕ} (hk : 3 ≤ k)
    (S : Fin k → SmoothPatch (k + 2))
    (hrec : ∀ p : ℝ, critical k < p → p < baseline k →
      RestrictionRecurrences (fun i => (S i).surfaceMeasure) (fun _ => id) p) :
    ∀ p : ℝ, critical k ≤ p →
      LocalRestriction (fun i => (S i).surfaceMeasure) (fun _ => id) p := by
  letI (i : Fin k) := (S i).isFiniteMeasure_surfaceMeasure (by omega : 1 ≤ k + 2)
  exact local_range_of_recurrences hk (fun _ => measurable_id) hrec

/-- A precise remaining obligation implies the named local theorem target.
This does not claim that curvature supplies those recurrences. -/
theorem mainLocalGoal_of_surface_recurrences
    (hrec : ∀ k : ℕ, 3 ≤ k → ∀ S : Fin k → SmoothPatch (k + 2),
      ∀ ν κ : ℝ, GeometricHypotheses S ν κ →
      ∀ p : ℝ, critical k < p → p < baseline k →
        RestrictionRecurrences (fun i => (S i).surfaceMeasure) (fun _ => id) p) :
    MainLocalGoal := by
  intro k hk S ν κ hgeo
  exact surface_local_range_of_recurrences hk S (hrec k hk S ν κ hgeo) _ le_rfl

end N2Restriction
