import N2Restriction.RegularGraphCover

namespace N2Restriction
open MeasureTheory Set Filter

/-- The L2 ball estimate of Lemma 3.1 for every original regular-level-set surface input.
The constant is for the fixed patch; it is independent of input, center and radius. -/
theorem SmoothPatch.local_Plancherel_ball {d : ℕ} (S : SmoothPatch (d + 1)) :
    ∃ C : ℝ, 0 ≤ C ∧ HasBallEnergyBound S.surfaceMeasure C := by
  obtain ⟨m, P, hP, _, _⟩ := S.exists_finite_graph_cover
  exact S.ball_bound_of_graph_cover P hP

/-- Both estimates of Lemma 3.1, with one positive constant for the fixed smooth patch. -/
theorem SmoothPatch.local_Plancherel_bounds {d : ℕ} (S : SmoothPatch (d + 1)) :
    ∃ C : ℝ, 0 < C ∧ ∀ g : Lp ℂ 2 S.surfaceMeasure,
      (∀ x, ‖extension S.surfaceMeasure id g x‖ ≤ C * ‖g‖) ∧
      ∀ (x₀ : Ambient (d + 1)) (R : ℝ), 0 ≤ R →
        (∫ y in Metric.ball x₀ R, ‖extension S.surfaceMeasure id g y‖ ^ 2) ≤ C * R * ‖g‖ ^ 2 := by
  haveI : IsFiniteMeasure S.surfaceMeasure := S.isFiniteMeasure_surfaceMeasure (by omega)
  obtain ⟨C, _, hC⟩ := S.local_Plancherel_ball
  let B := (eLpNorm (fun _ : Ambient (d + 1) => (1 : ℂ)) 2 S.surfaceMeasure).toReal
  let D := max 1 (max C B)
  have hD : 0 < D := lt_of_lt_of_le zero_lt_one (le_max_left _ _)
  have hCD : C ≤ D := (le_max_left _ _).trans (le_max_right _ _)
  have hBD : B ≤ D := (le_max_right _ _).trans (le_max_right _ _)
  refine ⟨D, hD, fun g => ⟨?_, ?_⟩⟩
  · intro x
    have h := (extensionEvaluation S.surfaceMeasure id measurable_id x).le_opNorm g
    rw [extensionEvaluation_eq, extensionEvaluation_norm] at h
    exact h.trans (mul_le_mul_of_nonneg_right hBD (norm_nonneg _))
  · exact (hC.mono hCD) g

/-- Representative-independent formulation for arbitrary measurable L2 functions. -/
theorem SmoothPatch.local_Plancherel_memLp {d : ℕ} (S : SmoothPatch (d + 1)) :
    ∃ C : ℝ, 0 < C ∧ ∀ (f : Ambient (d + 1) → ℂ), MemLp f 2 S.surfaceMeasure →
      (∀ x, ‖extension S.surfaceMeasure id f x‖ ≤ C * (eLpNorm f 2 S.surfaceMeasure).toReal) ∧
      ∀ (x₀ : Ambient (d + 1)) (R : ℝ), 0 ≤ R →
        (∫ y in Metric.ball x₀ R, ‖extension S.surfaceMeasure id f y‖ ^ 2) ≤
          C * R * (eLpNorm f 2 S.surfaceMeasure).toReal ^ 2 := by
  obtain ⟨C, hC, hb⟩ := S.local_Plancherel_bounds
  refine ⟨C, hC, ?_⟩
  intro f hf
  have he (x) : extension S.surfaceMeasure id (hf.toLp f) x = extension S.surfaceMeasure id f x := by
    apply integral_congr_ae
    filter_upwards [hf.coeFn_toLp] with y hy
    simp only [hy]
  have hn : ‖hf.toLp f‖ = (eLpNorm f 2 S.surfaceMeasure).toReal := by
    rw [Lp.norm_def, eLpNorm_congr_ae hf.coeFn_toLp]
  simpa only [he, hn] using hb (hf.toLp f)

end N2Restriction
