import N2Restriction.CoordinatePacketTails

namespace N2Restriction
open MeasureTheory

/-- Flatten finitely many unconditional series into one unconditional product-indexed series.
No absolute summability of vector norms is assumed. -/
theorem finite_fiber_hasSum {ι ν E : Type*} [Fintype ι] [NormedAddCommGroup E]
    (f : ι → ν → E) (a : ι → E) (hf : ∀ j, HasSum (f j) (a j)) :
    HasSum (fun p : ι × ν => f p.1 p.2) (∑ j, a j) := by
  classical
  let F : ι → (ι × ν) → E := fun j p => if p.1 = j then f j p.2 else 0
  have hF (j : ι) : HasSum (F j) (a j) := by
    have hinj : Function.Injective (fun n : ν => (j, n)) := fun _ _ h => (Prod.mk.inj h).2
    apply (hinj.hasSum_iff ?_).mp
    · simpa only [F, Function.comp_def, if_pos rfl] using hf j
    · intro p hp
      have hn : p.1 ≠ j := by
        intro he
        apply hp
        exact ⟨p.2, by cases p; simp_all⟩
      simp only [F, if_neg hn]
  have h := hasSum_sum (s := Finset.univ) (fun j _ => hF j)
  simpa [F] using h

namespace CoordinateCapFamily

/-- All cap/mode packets form one unconditionally summable L2 family. -/
theorem packet_summable {d : ℕ} {K : Set (Ambient d)} {r : ℝ}
    (P : CoordinateCapFamily K r) (hr : 0 < r) (f : Lp ℂ 2 (volume : Measure (Ambient d))) :
    Summable (fun p : P.centers × (Fin d → ℤ) => P.packet hr f p.1 p.2) :=
  (finite_fiber_hasSum (P.packet hr f) (partitionL2Piece P.partition f) (P.packet_hasSum hr f)).summable

/-- Single-index unconditional packet reconstruction of the original coordinate input. -/
theorem packet_hasSum_original {d : ℕ} {K : Set (Ambient d)} {r : ℝ}
    (P : CoordinateCapFamily K r) (hr : 0 < r) (f : Lp ℂ 2 (volume : Measure (Ambient d)))
    (hf : HasFrequencySupport volume id K f) :
    HasSum (fun p : P.centers × (Fin d → ℤ) => P.packet hr f p.1 p.2) f := by
  have h := finite_fiber_hasSum (P.packet hr f) (partitionL2Piece P.partition f) (P.packet_hasSum hr f)
  rwa [partitionL2Piece_reconstruction P.partition f hf] at h

/-- Every arbitrary subset of the full packet index set converges unconditionally in L2. -/
theorem packet_subcollection_summable {d : ℕ} {K : Set (Ambient d)} {r : ℝ}
    (P : CoordinateCapFamily K r) (hr : 0 < r) (f : Lp ℂ 2 (volume : Measure (Ambient d)))
    (S : Set (P.centers × (Fin d → ℤ))) :
    Summable (fun p : S => P.packet hr f p.val.1 p.val.2) :=
  (P.packet_summable hr f).subtype S

end CoordinateCapFamily
end N2Restriction
