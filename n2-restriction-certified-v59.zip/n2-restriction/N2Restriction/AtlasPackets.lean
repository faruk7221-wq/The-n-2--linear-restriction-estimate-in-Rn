import N2Restriction.SurfaceAtlasInputs
import N2Restriction.AtlasSeries
import N2Restriction.BufferedGraphChart
import N2Restriction.DensityAlmostOrthogonal
import N2Restriction.SurfaceGraphTails

set_option maxHeartbeats 800000

namespace N2Restriction
open MeasureTheory Set Filter

/-- Finitely many unconditional series with different index types form one sigma-indexed series. -/
theorem finite_dependent_fiber_hasSum {ι E : Type*} {ν : ι → Type*}
    [Fintype ι] [NormedAddCommGroup E]
    (f : (j : ι) → ν j → E) (a : ι → E) (hf : ∀ j, HasSum (f j) (a j)) :
    HasSum (fun p : Sigma ν => f p.1 p.2) (∑ j, a j) := by
  classical
  let F : ι → Sigma ν → E := fun j p => if h : p.1 = j then f j (h ▸ p.2) else 0
  have hF (j : ι) : HasSum (F j) (a j) := by
    have hinj : Function.Injective (Sigma.mk j : ν j → Sigma ν) := sigma_mk_injective
    apply (hinj.hasSum_iff ?_).mp
    · simpa only [F, Function.comp_def, dif_pos rfl] using hf j
    · intro p hp
      have hn : p.1 ≠ j := by
        intro he
        apply hp
        cases p with
        | mk k v => cases he; exact ⟨v, rfl⟩
      simp only [F, dif_neg hn]
  have h := hasSum_sum (s := Finset.univ) (fun j _ => hF j)
  have he (p : Sigma ν) : (∑ j, F j p) = f p.1 p.2 := by
    rw [Finset.sum_eq_single p.1]
    · simp only [F, dif_pos rfl]
    · intro j _ hj
      exact dif_neg (Ne.symm hj)
    · intro hp
      exact False.elim (hp (Finset.mem_univ _))
  simpa only [he] using h

/-- Orthogonal input transport preserves arbitrary actual-frequency support sets. -/
theorem rotatedInput_frequency_support {n : ℕ} (A : Ambient n ≃ₗᵢ[ℝ] Ambient n)
    (μ : Measure (Ambient n)) (K : Set (Ambient n)) (f : Lp ℂ 2 μ)
    (hf : HasFrequencySupport μ A K f) :
    HasFrequencySupport (μ.map A) id K (rotatedInput A μ f) := by
  apply A.toHomeomorph.measurableEmbedding.ae_map_iff.mpr
  filter_upwards [ae_of_ae_map A.continuous.measurable.aemeasurable
    (imageInput_coe μ A A.symm A.continuous.measurable A.symm.continuous.measurable
      A.symm_apply_apply f), hf] with x hx hs hn
  apply hs
  change (rotatedInput A μ f) (A x) ≠ 0 at hn
  change (rotatedInput A μ f) (A x) = f (A.symm (A x)) at hx
  simpa only [hx, A.symm_apply_apply] using hn

end N2Restriction

namespace N2Restriction
open MeasureTheory Set Filter

/-- Original inputs on a rotated Hausdorff patch have full-graph inputs of the same norm. -/
theorem SurfaceGraphChart.rotated_patch_input {d : ℕ} (G : SurfaceGraphChart d)
    (A : Ambient (d + 1) ≃ₗᵢ[ℝ] Ambient (d + 1)) {K : Set (Ambient d)}
    (hK : IsCompact K)
    (g : Lp ℂ 2 ((Measure.hausdorffMeasure (d : ℝ)).restrict (A '' (G.parametrization '' K)))) :
    ∃ f : Lp ℂ 2 G.surfaceMeasure, ‖f‖ = ‖g‖ ∧
      HasFrequencySupport G.surfaceMeasure id (G.parametrization '' K) f ∧
      ∀ x, extension G.surfaceMeasure A f x =
        extension ((Measure.hausdorffMeasure (d : ℝ)).restrict (A '' (G.parametrization '' K))) id g x := by
  have hmeas : MeasurableSet (G.parametrization '' K) :=
    (hK.image (graphMap_lipschitz G.lipschitz).continuous).measurableSet
  revert g
  rw [← orthogonal_surface_measure A (d : ℝ), ← G.surfaceMeasure_restrict_image]
  intro g
  obtain ⟨u, rfl⟩ := rotatedInput_surjective A (G.surfaceMeasure.restrict (G.parametrization '' K)) g
  refine ⟨G.patchInput hmeas u, ?_, G.patchInput_support hmeas u, ?_⟩
  · rw [rotatedInput_norm]
    exact zeroExtendL2_norm _ _ _ _
  · intro x
    rw [show extension ((G.surfaceMeasure.restrict (G.parametrization '' K)).map A) id
        (rotatedInput A _ u) x = extension (G.surfaceMeasure.restrict (G.parametrization '' K)) A u x from
      imageInput_extension _ A A.symm A.toHomeomorph.measurableEmbedding
        A.symm.continuous.measurable A.symm_apply_apply u x]
    exact zeroExtendL2_extension _ _ _ _ A _

/-- A change between equal measures is a linear isometry with the same coefficient representative. -/
noncomputable def equalMeasureInput {Ω : Type*} [MeasurableSpace Ω]
    {μ ν : Measure Ω} (h : μ = ν) : Lp ℂ 2 μ →ₗᵢ[ℂ] Lp ℂ 2 ν := by
  subst ν
  exact LinearIsometry.id

theorem equalMeasureInput_coe {Ω : Type*} [MeasurableSpace Ω]
    {μ ν : Measure Ω} (h : μ = ν) (f : Lp ℂ 2 μ) :
    equalMeasureInput h f =ᵐ[ν] f := by
  subst ν
  exact Filter.Eventually.of_forall (fun _ => rfl)

theorem equalMeasureInput_extension {n : ℕ} {μ ν : Measure (Ambient n)} (h : μ = ν)
    (ζ : Ambient n → Ambient n) (f : Lp ℂ 2 μ) (x : Ambient n) :
    extension ν ζ (equalMeasureInput h f) x = extension μ ζ f x := by
  subst ν
  rfl

theorem equalMeasureInput_support {n : ℕ} {μ ν : Measure (Ambient n)} (h : μ = ν)
    (ζ : Ambient n → Ambient n) (K : Set (Ambient n)) (f : Lp ℂ 2 μ)
    (hf : HasFrequencySupport μ ζ K f) :
    HasFrequencySupport ν ζ K (equalMeasureInput h f) := by
  subst ν
  exact hf

/-- Embed a full graph input into ambient Hausdorff L2 by zero extension. -/
noncomputable def SurfaceGraphChart.ambientInput {d : ℕ} (G : SurfaceGraphChart d) :
    Lp ℂ 2 G.surfaceMeasure →ₗᵢ[ℂ] Lp ℂ 2 (Measure.hausdorffMeasure (d : ℝ) : Measure (Ambient (d + 1))) :=
  (zeroExtendIsometry _ (range G.parametrization)
    G.measurableEmbedding_parametrization.measurableSet_range).comp
      (equalMeasureInput G.surfaceMeasure_eq)

/-- Ambient embedding preserves extension for any frequency map. -/
theorem SurfaceGraphChart.ambientInput_extension {d : ℕ} (G : SurfaceGraphChart d)
    (ζ : Ambient (d + 1) → Ambient (d + 1)) (f : Lp ℂ 2 G.surfaceMeasure) (x : Ambient (d + 1)) :
    extension (Measure.hausdorffMeasure (d : ℝ)) ζ (G.ambientInput f) x =
      extension G.surfaceMeasure ζ f x := by
  change extension _ ζ (zeroExtendL2 _ _ G.measurableEmbedding_parametrization.measurableSet_range
    (equalMeasureInput G.surfaceMeasure_eq f)) x = _
  rw [zeroExtendL2_extension, equalMeasureInput_extension]

/-- Ambient embedding preserves actual frequency support. -/
theorem SurfaceGraphChart.ambientInput_support {d : ℕ} (G : SurfaceGraphChart d)
    (ζ : Ambient (d + 1) → Ambient (d + 1)) (K : Set (Ambient (d + 1)))
    (f : Lp ℂ 2 G.surfaceMeasure) (hf : HasFrequencySupport G.surfaceMeasure ζ K f) :
    HasFrequencySupport (Measure.hausdorffMeasure (d : ℝ)) ζ K (G.ambientInput f) := by
  exact zeroExtendL2_frequency_support _ _ G.measurableEmbedding_parametrization.measurableSet_range
    ζ K _ (equalMeasureInput_support G.surfaceMeasure_eq ζ K f hf)

end N2Restriction

namespace N2Restriction
open MeasureTheory Set Filter

/-- Orthogonal action on ambient Hausdorff L2, including singular Hausdorff measures. -/
noncomputable def hausdorffRotation {n : ℕ} (A : Ambient n ≃ₗᵢ[ℝ] Ambient n) (s : ℝ) :
    Lp ℂ 2 (Measure.hausdorffMeasure s : Measure (Ambient n)) →ₗᵢ[ℂ]
      Lp ℂ 2 (Measure.hausdorffMeasure s : Measure (Ambient n)) :=
  (equalMeasureInput (A.toIsometryEquiv.map_hausdorffMeasure s)).comp
    (rotatedInput A (Measure.hausdorffMeasure s))

/-- The rotated full graph embeds isometrically into a common ambient Hausdorff space. -/
noncomputable def SurfaceGraphChart.rotatedAmbientInput {d : ℕ} (G : SurfaceGraphChart d)
    (A : Ambient (d + 1) ≃ₗᵢ[ℝ] Ambient (d + 1)) :
    Lp ℂ 2 G.surfaceMeasure →ₗᵢ[ℂ]
      Lp ℂ 2 (Measure.hausdorffMeasure (d : ℝ) : Measure (Ambient (d + 1))) :=
  (hausdorffRotation A (d : ℝ)).comp G.ambientInput

theorem SurfaceGraphChart.rotatedAmbientInput_extension {d : ℕ} (G : SurfaceGraphChart d)
    (A : Ambient (d + 1) ≃ₗᵢ[ℝ] Ambient (d + 1))
    (f : Lp ℂ 2 G.surfaceMeasure) (x : Ambient (d + 1)) :
    extension (Measure.hausdorffMeasure (d : ℝ)) id (G.rotatedAmbientInput A f) x =
      extension G.surfaceMeasure A f x := by
  change extension _ id (equalMeasureInput _ (rotatedInput A _ (G.ambientInput f))) x = _
  rw [equalMeasureInput_extension]
  rw [show extension ((Measure.hausdorffMeasure (d : ℝ)).map A) id
      (rotatedInput A _ (G.ambientInput f)) x =
      extension (Measure.hausdorffMeasure (d : ℝ)) A (G.ambientInput f) x from
    imageInput_extension _ A A.symm A.toHomeomorph.measurableEmbedding
      A.symm.continuous.measurable A.symm_apply_apply _ x]
  exact G.ambientInput_extension A f x

theorem SurfaceGraphChart.rotatedAmbientInput_support {d : ℕ} (G : SurfaceGraphChart d)
    (A : Ambient (d + 1) ≃ₗᵢ[ℝ] Ambient (d + 1)) (K : Set (Ambient (d + 1)))
    (f : Lp ℂ 2 G.surfaceMeasure) (hf : HasFrequencySupport G.surfaceMeasure A K f) :
    HasFrequencySupport (Measure.hausdorffMeasure (d : ℝ)) id K (G.rotatedAmbientInput A f) := by
  apply equalMeasureInput_support
  exact rotatedInput_frequency_support A _ K _ (G.ambientInput_support A K f hf)

/-- The actual graph packet series and energy survive orthogonal transport into common Hausdorff L2. -/
theorem SurfaceGraphChart.rotated_packet_reconstruction_energy {d : ℕ} (G : SurfaceGraphChart d)
    (A : Ambient (d + 1) ≃ₗᵢ[ℝ] Ambient (d + 1)) {K : Set (Ambient d)} {r : ℝ}
    (Q : CoordinateCapFamily K r) (hr : 0 < r) (f : Lp ℂ 2 G.surfaceMeasure)
    (hf : HasFrequencySupport G.surfaceMeasure id (G.parametrization '' K) f) :
    HasSum (fun p : Q.centers × (Fin d → ℤ) => G.rotatedAmbientInput A (G.packet Q hr f p.1 p.2))
      (G.rotatedAmbientInput A f) ∧
    (∑ j, ∑' ν, ‖G.rotatedAmbientInput A (G.packet Q hr f j ν)‖ ^ 2) ≤
      (G.density.upper / G.density.lower) *
        (packetCutoffEnergy d * (2 * Real.pi) ^ (-(d : ℝ))) * ‖f‖ ^ 2 := by
  refine ⟨(G.rotatedAmbientInput A).toContinuousLinearMap.hasSum (G.packet_hasSum Q hr f hf), ?_⟩
  simpa only [LinearIsometry.norm_map] using G.packet_total_energy Q hr f

end N2Restriction

namespace N2Restriction
open MeasureTheory Set Filter

/-- Fixed geometric atlas data with room for enlarged caps; no packet or analytic estimates are fields. -/
structure PacketGraphAtlas {d : ℕ} (S : SmoothPatch (d + 1)) where
  size : ℕ
  patch : Fin size → LocalGraphPatch d
  graph : Fin size → SurfaceGraphChart d
  bufferRadius : Fin size → ℝ
  capRadius : ℝ
  margin : ℝ
  capRadius_pos : 0 < capRadius
  margin_pos : 0 < margin
  cover : S.support ⊆ ⋃ j, (patch j).carrier
  smooth : ∀ j, ContDiff ℝ (⊤ : ℕ∞) (graph j).phase
  inner_lt : ∀ j, (patch j).innerRadius < bufferRadius j
  outer_gt : ∀ j, bufferRadius j < (patch j).outerRadius
  phase_eq : ∀ j, EqOn (graph j).phase (patch j).phase (Metric.closedBall (patch j).center (bufferRadius j))
  carrier_eq : ∀ j, (patch j).carrier = (patch j).rotation '' ((graph j).parametrization '' (patch j).support)
  buffer_inside : ∀ j, (patch j).rotation '' ((graph j).parametrization ''
    Metric.closedBall (patch j).center (bufferRadius j)) ⊆ S.extendedSurface ∩ marginRegion S.neighborhood margin
  cap_inside : ∀ j c, c ∈ (patch j).support → ∀ r : ℝ, r ≤ capRadius →
    Metric.ball c (2 * r) ⊆ Metric.closedBall (patch j).center (bufferRadius j)

/-- The atlas structure is constructed from regular-level-set hypotheses alone. -/
theorem SmoothPatch.exists_packetGraphAtlas {d : ℕ} (S : SmoothPatch (d + 1)) :
    Nonempty (PacketGraphAtlas S) := by
  obtain ⟨m, P, G, a, ρ, δ, hρ, hδ, hcover, hG, hcarrier, hbuffer, hcap⟩ := S.exists_packet_buffered_atlas
  exact ⟨⟨m, P, G, a, ρ, δ, hρ, hδ, hcover, fun j => (hG j).1,
    fun j => (hG j).2.1, fun j => (hG j).2.2.1, fun j => (hG j).2.2.2,
    hcarrier, hbuffer, hcap⟩⟩

/-- Chart inputs are obtained from the original surface with no energy loss. -/
theorem PacketGraphAtlas.input_decomposition {d : ℕ} {S : SmoothPatch (d + 1)} (T : PacketGraphAtlas S)
    (g : Lp ℂ 2 S.surfaceMeasure) :
    ∃ f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure,
      (∑ j, ‖f j‖ ^ 2) ≤ ‖g‖ ^ 2 ∧
      (∀ j, HasFrequencySupport (T.graph j).surfaceMeasure id
        ((T.graph j).parametrization '' (T.patch j).support) (f j)) ∧
      ∀ x, (∑ j, extension (T.graph j).surfaceMeasure (T.patch j).rotation (f j) x) =
        extension S.surfaceMeasure id g x := by
  have hdim : ((d + 1 : ℕ) : ℝ) - 1 = (d : ℝ) := by push_cast; ring
  have hμ : S.surfaceMeasure = (Measure.hausdorffMeasure (d : ℝ)).restrict S.support := by
    rw [SmoothPatch.surfaceMeasure, hdim]
  haveI : IsFiniteMeasure S.surfaceMeasure := S.isFiniteMeasure_surfaceMeasure (by omega)
  revert g
  rw [hμ] at *
  intro g
  let K := fun j => (T.patch j).carrier
  have hK j : MeasurableSet (K j) := (T.patch j).compact_carrier.measurableSet
  let u := atlasPatchInput _ S.support S.compact_support.measurableSet K hK g
  have hu j : ∃ f : Lp ℂ 2 (T.graph j).surfaceMeasure, ‖f‖ = ‖u j‖ ∧
      HasFrequencySupport (T.graph j).surfaceMeasure id ((T.graph j).parametrization '' (T.patch j).support) f ∧
      ∀ x, extension (T.graph j).surfaceMeasure (T.patch j).rotation f x =
        extension ((Measure.hausdorffMeasure (d : ℝ)).restrict (K j)) id (u j) x := by
    generalize u j = v
    revert v
    dsimp only [K]
    rw [T.carrier_eq j]
    exact fun v => (T.graph j).rotated_patch_input (T.patch j).rotation (T.patch j).compact_support v
  choose f hn hs he using hu
  refine ⟨f, ?_, hs, ?_⟩
  · simp_rw [hn]
    exact atlasPatchInput_energy _ S.support S.compact_support.measurableSet K hK g
  · intro x
    simp_rw [he]
    exact atlasPatchInput_reconstruction _ S.support S.compact_support.measurableSet K hK T.cover g x

namespace PacketGraphAtlas
variable {d : ℕ} {S : SmoothPatch (d + 1)} (T : PacketGraphAtlas S)

def buffer (j : Fin T.size) : Set (Ambient (d + 1)) :=
  (T.patch j).rotation '' ((T.graph j).parametrization ''
    Metric.closedBall (T.patch j).center (T.bufferRadius j))

theorem compact_buffer (j : Fin T.size) : IsCompact (T.buffer j) :=
  ((isCompact_closedBall _ _).image (graphMap_lipschitz (T.graph j).lipschitz).continuous).image
    (T.patch j).rotation.continuous

/-- Every transported packet lies in the fixed compact atlas buffer. -/
theorem packet_support {r : ℝ} (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r)
    (hr : 0 < r) (hsmall : r ≤ T.capRadius)
    (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
    (j : Fin T.size) (c : (Q j).centers) (ν : Fin d → ℤ) :
    HasFrequencySupport (Measure.hausdorffMeasure (d : ℝ)) id (T.buffer j)
      ((T.graph j).rotatedAmbientInput (T.patch j).rotation ((T.graph j).packet (Q j) hr (f j) c ν)) := by
  apply (T.graph j).rotatedAmbientInput_support
  filter_upwards [(T.graph j).packet_support (Q j) hr (f j) c ν] with x hx hn
  exact ⟨x, image_mono (T.cap_inside j c ((Q j).centers_mem c.property) r hsmall) (hx hn), rfl⟩

/-- Actual transported chart packets combine into one unconditional ambient Hausdorff L2 series. -/
theorem packet_hasSum {r : ℝ} (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r)
    (hr : 0 < r) (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
    (hf : ∀ j, HasFrequencySupport (T.graph j).surfaceMeasure id
      ((T.graph j).parametrization '' (T.patch j).support) (f j)) :
    HasSum (fun p : (j : Fin T.size) × ((Q j).centers × (Fin d → ℤ)) =>
      (T.graph p.1).rotatedAmbientInput (T.patch p.1).rotation
        ((T.graph p.1).packet (Q p.1) hr (f p.1) p.2.1 p.2.2))
      (∑ j, (T.graph j).rotatedAmbientInput (T.patch j).rotation (f j)) :=
by
  refine finite_dependent_fiber_hasSum (ν := fun j : Fin T.size => (Q j).centers × (Fin d → ℤ))
    (fun j p => (T.graph j).rotatedAmbientInput (T.patch j).rotation
      ((T.graph j).packet (Q j) hr (f j) p.1 p.2))
    (fun j => (T.graph j).rotatedAmbientInput (T.patch j).rotation (f j)) ?_
  intro j
  exact ((T.graph j).rotatedAmbientInput (T.patch j).rotation).toContinuousLinearMap.hasSum
    ((T.graph j).packet_hasSum (Q j) hr (f j) (hf j))

end PacketGraphAtlas
end N2Restriction

namespace N2Restriction
open MeasureTheory Set Filter
namespace PacketGraphAtlas
variable {d : ℕ} {S : SmoothPatch (d + 1)} (T : PacketGraphAtlas S)

/-- The common compact atlas buffer has finite actual Hausdorff measure. -/
theorem finite_buffer_measure :
    IsFiniteMeasure ((Measure.hausdorffMeasure (d : ℝ)).restrict (⋃ j, T.buffer j)) := by
  have hfin j : (Measure.hausdorffMeasure (d : ℝ)) (T.buffer j) < ⊤ := by
    have h := finite_hausdorff_lipschitz_image (isCompact_closedBall (T.patch j).center (T.bufferRadius j))
      (((T.patch j).rotation.lipschitz.comp (graphMap_lipschitz (T.graph j).lipschitz)).lipschitzOnWith)
    simpa only [Ambient, finrank_euclideanSpace, Fintype.card_fin, buffer, image_image, Function.comp_def] using h
  constructor
  rw [Measure.restrict_apply_univ]
  simpa using measure_biUnion_lt_top (Set.finite_univ : (Set.univ : Set (Fin T.size)).Finite)
    (fun j _ => hfin j)

/-- A single constant controls the energies of every chart packet at every admissible scale. -/
theorem packet_total_energy : ∃ C : ℝ, 0 ≤ C ∧
    ∀ {r : ℝ} (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r)
      (hr : 0 < r) (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure),
    (∑ j, ∑ c, ∑' ν, ‖(T.graph j).rotatedAmbientInput (T.patch j).rotation
      ((T.graph j).packet (Q j) hr (f j) c ν)‖ ^ 2) ≤ C * ∑ j, ‖f j‖ ^ 2 := by
  classical
  let D := fun j => ((T.graph j).density.upper / (T.graph j).density.lower) *
    (packetCutoffEnergy d * (2 * Real.pi) ^ (-(d : ℝ)))
  have hD j : 0 ≤ D j := by
    dsimp [D]
    have hupper := (T.graph j).density.upper_nonneg
    have hlower := (T.graph j).density.lower_pos
    have hcut := packetCutoffEnergy_pos d
    positivity
  refine ⟨∑ j, D j, Finset.sum_nonneg (fun j _ => hD j), ?_⟩
  intro r Q hr f
  calc
    _ ≤ ∑ j, D j * ‖f j‖ ^ 2 := by
      apply Finset.sum_le_sum
      intro j _
      simpa only [LinearIsometry.norm_map] using (T.graph j).packet_total_energy (Q j) hr (f j)
    _ ≤ ∑ j, (∑ k, D k) * ‖f j‖ ^ 2 := by
      apply Finset.sum_le_sum
      intro j _
      apply mul_le_mul_of_nonneg_right _ (sq_nonneg _)
      exact Finset.single_le_sum (fun k _ => hD k) (Finset.mem_univ j)
    _ = _ := by rw [Finset.mul_sum]

/-- Every graph input and its transported version are supported in the atlas buffer. -/
theorem input_support (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
    (hf : ∀ j, HasFrequencySupport (T.graph j).surfaceMeasure id
      ((T.graph j).parametrization '' (T.patch j).support) (f j)) (j : Fin T.size) :
    HasFrequencySupport (Measure.hausdorffMeasure (d : ℝ)) id (⋃ k, T.buffer k)
      ((T.graph j).rotatedAmbientInput (T.patch j).rotation (f j)) := by
  apply (T.graph j).rotatedAmbientInput_support
  filter_upwards [hf j] with x hx hn
  obtain ⟨u, hu, rfl⟩ := hx hn
  apply mem_iUnion.mpr
  refine ⟨j, ?_⟩
  exact ⟨_, ⟨u, (Metric.closedBall_subset_closedBall (T.inner_lt j).le)
    ((T.patch j).support_inside hu), rfl⟩, rfl⟩

/-- Uniform reconstruction for the actual combined packet series on the fixed atlas. -/
theorem packet_uniform_extension {r : ℝ}
    (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r)
    (hr : 0 < r) (hsmall : r ≤ T.capRadius)
    (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
    (hf : ∀ j, HasFrequencySupport (T.graph j).surfaceMeasure id
      ((T.graph j).parametrization '' (T.patch j).support) (f j)) :
    ∀ ε : ℝ, 0 < ε → ∀ᶠ F : Finset ((j : Fin T.size) × ((Q j).centers × (Fin d → ℤ))) in atTop,
      ∀ x : Ambient (d + 1),
      dist (∑ p ∈ F, extension (Measure.hausdorffMeasure (d : ℝ)) id
        ((T.graph p.1).rotatedAmbientInput (T.patch p.1).rotation
          ((T.graph p.1).packet (Q p.1) hr (f p.1) p.2.1 p.2.2)) x)
        (extension (Measure.hausdorffMeasure (d : ℝ)) id
          (∑ j, (T.graph j).rotatedAmbientInput (T.patch j).rotation (f j) :
            Lp ℂ 2 (Measure.hausdorffMeasure (d : ℝ))) x) < ε := by
  letI := T.finite_buffer_measure
  have hm : MeasurableSet (⋃ j, T.buffer j) := MeasurableSet.iUnion (fun j => (T.compact_buffer j).measurableSet)
  have hi := T.input_support f hf
  have hsumSupport : HasFrequencySupport (Measure.hausdorffMeasure (d : ℝ)) id (⋃ j, T.buffer j)
      (∑ j, (T.graph j).rotatedAmbientInput (T.patch j).rotation (f j) :
        Lp ℂ 2 (Measure.hausdorffMeasure (d : ℝ))) := by
    have h := HasFrequencySupport.tsum_L2 (Measure.hausdorffMeasure (d : ℝ)) _ hm _
      (hasSum_fintype _).summable hi
    simpa only [tsum_fintype] using h
  apply supported_extension_uniform _ _ hm id measurable_id _ _ _ hsumSupport (T.packet_hasSum Q hr f hf)
  intro p
  exact (T.packet_support Q hr hsmall f p.1 p.2.1 p.2.2).mono (subset_iUnion _ p.1)

end PacketGraphAtlas
end N2Restriction

namespace N2Restriction
open MeasureTheory Set Filter

/-- Finite supported L2 sums commute with extension even when the ambient measure is infinite. -/
theorem extension_finite_sum_supported {n : ℕ} {ι : Type*} [Fintype ι]
    (μ : Measure (Ambient n)) (K : Set (Ambient n)) (hK : MeasurableSet K)
    [IsFiniteMeasure (μ.restrict K)] (f : ι → Lp ℂ 2 μ)
    (hf : ∀ j, HasFrequencySupport μ id K (f j)) (x : Ambient n) :
    extension μ id (∑ j, f j : Lp ℂ 2 μ) x = ∑ j, extension μ id (f j) x := by
  have hs : HasFrequencySupport μ id K (∑ j, f j : Lp ℂ 2 μ) := by
    have h := HasFrequencySupport.tsum_L2 μ K hK f (hasSum_fintype f).summable hf
    simpa only [tsum_fintype] using h
  have h := supported_extension_hasSum μ K hK id measurable_id f _ hf hs (hasSum_fintype f) x
  simpa only [tsum_fintype] using h.tsum_eq.symm

namespace PacketGraphAtlas
variable {d : ℕ} {S : SmoothPatch (d + 1)} (T : PacketGraphAtlas S)

/-- Actual atlas synthesis has exactly the sum of the original chart extension integrals. -/
theorem input_extension (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
    (hf : ∀ j, HasFrequencySupport (T.graph j).surfaceMeasure id
      ((T.graph j).parametrization '' (T.patch j).support) (f j)) (x : Ambient (d + 1)) :
    extension (Measure.hausdorffMeasure (d : ℝ)) id
      (∑ j, (T.graph j).rotatedAmbientInput (T.patch j).rotation (f j) :
        Lp ℂ 2 (Measure.hausdorffMeasure (d : ℝ))) x =
      ∑ j, extension (T.graph j).surfaceMeasure (T.patch j).rotation (f j) x := by
  letI := T.finite_buffer_measure
  rw [extension_finite_sum_supported _ (⋃ j, T.buffer j)
    (MeasurableSet.iUnion (fun j => (T.compact_buffer j).measurableSet)) _ (T.input_support f hf)]
  simp only [SurfaceGraphChart.rotatedAmbientInput_extension]

/-- Construct actual cap families on every chart with one total polynomial count constant. -/
theorem exists_cap_families : ∃ A : ℝ, 0 ≤ A ∧ ∀ r : ℝ, 0 < r → r ≤ 1 →
    ∃ Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r,
      (∑ j, ((Q j).centers.card : ℝ)) ≤ A * r ^ (-(d : ℝ)) := by
  classical
  choose A hA hfamily using fun j => exists_coordinate_cap_families (T.patch j).compact_support
  refine ⟨∑ j, A j, Finset.sum_nonneg (fun j _ => hA j), ?_⟩
  intro r hr hr1
  choose Q hQ using fun j => hfamily j r hr hr1
  refine ⟨Q, ?_⟩
  calc
    _ ≤ ∑ j, A j * r ^ (-(d : ℝ)) := Finset.sum_le_sum (fun j _ => hQ j)
    _ = _ := by rw [Finset.sum_mul]

/-- Actual transported packet supports lie in the extended surface with a fixed positive margin. -/
theorem packet_surface_margin {r : ℝ}
    (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r)
    (hr : 0 < r) (hsmall : r ≤ T.capRadius)
    (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
    (j : Fin T.size) (c : (Q j).centers) (ν : Fin d → ℤ) :
    HasFrequencySupport (Measure.hausdorffMeasure (d : ℝ)) id
      (S.extendedSurface ∩ marginRegion S.neighborhood T.margin)
      ((T.graph j).rotatedAmbientInput (T.patch j).rotation ((T.graph j).packet (Q j) hr (f j) c ν)) :=
  (T.packet_support Q hr hsmall f j c ν).mono (T.buffer_inside j)

/-- For every original surface input, constructed rotated packets have uniform extension
reconstruction and a scale-independent total energy bound in the actual Hausdorff measure. -/
theorem packet_decomposition {d : ℕ} {S : SmoothPatch (d + 1)} (T : PacketGraphAtlas S) :
    ∃ C A : ℝ, 0 ≤ C ∧ 0 ≤ A ∧ ∀ g : Lp ℂ 2 S.surfaceMeasure,
      ∃ f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure,
        (∑ j, ‖f j‖ ^ 2) ≤ ‖g‖ ^ 2 ∧
        ∀ r : ℝ, 0 < r → r ≤ min 1 T.capRadius →
        ∃ Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r,
          (∑ j, ((Q j).centers.card : ℝ)) ≤ A * r ^ (-(d : ℝ)) ∧
          ∀ hr : 0 < r,
          (∑ j, ∑ c, ∑' ν, ‖(T.graph j).rotatedAmbientInput (T.patch j).rotation
            ((T.graph j).packet (Q j) hr (f j) c ν)‖ ^ 2) ≤ C * ‖g‖ ^ 2 ∧
          ∀ ε : ℝ, 0 < ε → ∀ᶠ F : Finset ((j : Fin T.size) × ((Q j).centers × (Fin d → ℤ))) in atTop,
            ∀ x : Ambient (d + 1), dist
              (∑ p ∈ F, extension (Measure.hausdorffMeasure (d : ℝ)) id
                ((T.graph p.1).rotatedAmbientInput (T.patch p.1).rotation
                  ((T.graph p.1).packet (Q p.1) hr (f p.1) p.2.1 p.2.2)) x)
              (extension S.surfaceMeasure id g x) < ε := by
  obtain ⟨C, hC, henergy⟩ := T.packet_total_energy
  obtain ⟨A, hA, hcaps⟩ := T.exists_cap_families
  refine ⟨C, A, hC, hA, ?_⟩
  intro g
  obtain ⟨f, hfenergy, hfsupport, hfextension⟩ := T.input_decomposition g
  refine ⟨f, hfenergy, ?_⟩
  intro r hr hsmall
  obtain ⟨Q, hQ⟩ := hcaps r hr (hsmall.trans (min_le_left _ _))
  refine ⟨Q, hQ, fun hr => ⟨?_, ?_⟩⟩
  · exact (henergy Q hr f).trans (mul_le_mul_of_nonneg_left hfenergy hC)
  · have he x := (T.input_extension f hfsupport x).trans (hfextension x)
    simpa only [he] using T.packet_uniform_extension Q hr (hsmall.trans (min_le_right _ _)) f hfsupport

end PacketGraphAtlas
end N2Restriction

namespace N2Restriction
open MeasureTheory Set Filter

/-- Orthogonal ambient embedding preserves the fixed-graph selected-packet estimate exactly. -/
theorem SurfaceGraphChart.rotated_selected_energy {d : ℕ} (G : SurfaceGraphChart d)
    (A : Ambient (d + 1) ≃ₗᵢ[ℝ] Ambient (d + 1)) {K : Set (Ambient d)} {r : ℝ}
    (Q : CoordinateCapFamily K r) (hr : 0 < r) (f : Lp ℂ 2 G.surfaceMeasure)
    (U : Q.centers → Set (Fin d → ℤ)) :
    packetCutoffEnergy d * ‖G.rotatedAmbientInput A (∑ c, ∑' ν : U c, G.packet Q hr f c ν)‖ ^ 2 ≤
      (G.density.upper / G.density.lower) * (9 ^ d * (2 * Real.pi) ^ d) *
        ∑ c, ∑' ν : U c, ‖G.rotatedAmbientInput A (G.packet Q hr f c ν)‖ ^ 2 := by
  simpa only [LinearIsometry.norm_map] using G.packet_selected_energy Q hr f U

/-- The transported selected sum equals the sum of the actual transported packets. -/
theorem SurfaceGraphChart.rotated_selected_sum {d : ℕ} (G : SurfaceGraphChart d)
    (A : Ambient (d + 1) ≃ₗᵢ[ℝ] Ambient (d + 1)) {K : Set (Ambient d)} {r : ℝ}
    (Q : CoordinateCapFamily K r) (hr : 0 < r) (f : Lp ℂ 2 G.surfaceMeasure)
    (U : Q.centers → Set (Fin d → ℤ)) :
    G.rotatedAmbientInput A (∑ c, ∑' ν : U c, G.packet Q hr f c ν) =
      ∑ c, ∑' ν : U c, G.rotatedAmbientInput A (G.packet Q hr f c ν) := by
  rw [map_sum]
  apply Finset.sum_congr rfl
  intro c _
  apply (G.rotatedAmbientInput A).toContinuousLinearMap.map_tsum
  exact (G.liftInput.toContinuousLinearMap.hasSum
    (Q.densityPacket_selected_summable hr G.density (G.pullInput f) c (U c)).hasSum).summable

/-- Arbitrary selected packets across a finite atlas obey one scale-independent L2 bound. -/
theorem PacketGraphAtlas.packet_selected_energy {d : ℕ} {S : SmoothPatch (d + 1)} (T : PacketGraphAtlas S) :
    ∃ B : ℝ, 0 ≤ B ∧ ∀ {r : ℝ}
      (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support r) (hr : 0 < r)
      (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
      (U : (j : Fin T.size) → (Q j).centers → Set (Fin d → ℤ)),
      packetCutoffEnergy d * ‖∑ j, ∑ c, ∑' ν : U j c,
        (T.graph j).rotatedAmbientInput (T.patch j).rotation
          ((T.graph j).packet (Q j) hr (f j) c ν)‖ ^ 2 ≤
        B * ∑ j, ∑ c, ∑' ν : U j c, ‖(T.graph j).rotatedAmbientInput (T.patch j).rotation
          ((T.graph j).packet (Q j) hr (f j) c ν)‖ ^ 2 := by
  classical
  let D := fun j => ((T.graph j).density.upper / (T.graph j).density.lower) *
    (9 ^ d * (2 * Real.pi) ^ d)
  have hD j : 0 ≤ D j := by
    dsimp [D]
    have := (T.graph j).density.upper_nonneg
    have := (T.graph j).density.lower_pos
    positivity
  refine ⟨T.size * ∑ j, D j, mul_nonneg (Nat.cast_nonneg _) (Finset.sum_nonneg (fun j _ => hD j)), ?_⟩
  intro r Q hr f U
  let v := fun j => (T.graph j).rotatedAmbientInput (T.patch j).rotation
    (∑ c, ∑' ν : U j c, (T.graph j).packet (Q j) hr (f j) c ν)
  let E := fun j => ∑ c, ∑' ν : U j c, ‖(T.graph j).rotatedAmbientInput (T.patch j).rotation
    ((T.graph j).packet (Q j) hr (f j) c ν)‖ ^ 2
  have hE j : 0 ≤ E j := by dsimp [E]; positivity
  have hv : ‖∑ j, v j‖ ^ 2 ≤ T.size * ∑ j, ‖v j‖ ^ 2 := by
    have hn := pow_le_pow_left₀ (norm_nonneg (∑ j, v j)) (norm_sum_le _ _) 2
    have hc := Finset.sum_mul_sq_le_sq_mul_sq Finset.univ (fun _ : Fin T.size => (1 : ℝ))
      (fun j => ‖v j‖)
    simp only [one_mul, one_pow, Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul, mul_one] at hc
    exact hn.trans hc
  have hj j : packetCutoffEnergy d * ‖v j‖ ^ 2 ≤ D j * E j :=
    (T.graph j).rotated_selected_energy (T.patch j).rotation (Q j) hr (f j) (U j)
  have hmain : packetCutoffEnergy d * ‖∑ j, v j‖ ^ 2 ≤ (T.size * ∑ j, D j) * ∑ j, E j := by
    calc
      _ ≤ packetCutoffEnergy d * (T.size * ∑ j, ‖v j‖ ^ 2) :=
        mul_le_mul_of_nonneg_left hv (packetCutoffEnergy_pos d).le
      _ = T.size * ∑ j, packetCutoffEnergy d * ‖v j‖ ^ 2 := by rw [← Finset.mul_sum]; ring
      _ ≤ T.size * ∑ j, D j * E j := mul_le_mul_of_nonneg_left (Finset.sum_le_sum (fun j _ => hj j)) (by positivity)
      _ ≤ T.size * ∑ j, (∑ k, D k) * E j := by
        apply mul_le_mul_of_nonneg_left _ (by positivity)
        apply Finset.sum_le_sum
        intro j _
        exact mul_le_mul_of_nonneg_right
          (Finset.single_le_sum (fun k _ => hD k) (Finset.mem_univ j)) (hE j)
      _ = _ := by rw [← Finset.mul_sum]; ring
  simpa only [v, E, SurfaceGraphChart.rotated_selected_sum] using hmain

end N2Restriction

namespace N2Restriction
open MeasureTheory Set Filter

/-- Actual transported packet extensions have rapid tails outside orthogonally rotated tubes.
The physical-scale threshold precedes every decay order and every admissible cap family. -/
theorem SurfaceGraphChart.rotated_packet_rapid_tail {d : ℕ} (G : SurfaceGraphChart d)
    (A : Ambient (d + 1) ≃ₗᵢ[ℝ] Ambient (d + 1))
    {U : Set (Ambient d)} (hU : IsOpen U) (hφ : ContDiffOn ℝ (⊤ : ℕ∞) G.phase U)
    (z : Ambient d) {a b : ℝ} (ha : 0 < a) (hab : a < b)
    (hball : Metric.closedBall z b ⊆ U) {K : Set (Ambient d)} (hK : IsCompact K)
    (hcenter : K ⊆ Metric.ball z (a / 2)) {τ : ℝ} (hτ : 0 < τ) :
    ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ N : ℝ, ∃ C : ℝ, 0 ≤ C ∧
      ∀ (R : ℝ), R₀ ≤ R → ∀ (Q : CoordinateCapFamily K (R ^ (-1 / 2 : ℝ)))
      (hr : 0 < R ^ (-1 / 2 : ℝ)) (B : ℝ), 0 ≤ B →
      (Q.centers.card : ℝ) ≤ B * R ^ ((d : ℝ) / 2) →
      ∀ (f : Lp ℂ 2 G.surfaceMeasure) (u : Ambient d) (t : ℝ), |t| ≤ R →
      ∀ V : Q.centers → Set (Fin d → ℤ),
      (∀ j ν, ν ∈ V j → R ^ (1 / 2 + τ) / 10 ≤ Metric.infDist (A (graphPoint u t))
        (A '' packetSegment (graphGradient G.phase (j : Ambient d))
          ((R ^ (-1 / 2 : ℝ))⁻¹ • latticeVector ν) R)) →
      (∑ j, ∑' ν : V j, ‖extension (Measure.hausdorffMeasure (d : ℝ)) id
        (G.rotatedAmbientInput A (G.packet Q hr f j ν)) (A (graphPoint u t))‖) ≤
          C * Real.sqrt B * R ^ (-N) * ‖f‖ := by
  obtain ⟨R₀, hR₀, htail⟩ := coordinate_family_rapid_tail hU hφ z ha hab hball hK hcenter hτ
  refine ⟨R₀, hR₀, fun N => ?_⟩
  obtain ⟨C, hC, hb⟩ := htail N
  refine ⟨C * Real.sqrt G.density.upper, mul_nonneg hC (Real.sqrt_nonneg _), ?_⟩
  intro R hR Q hr B hB hcount f u t ht V hV
  have hV' : ∀ j ν, ν ∈ V j → R ^ (1 / 2 + τ) / 10 ≤ Metric.infDist (graphPoint u t)
      (packetSegment (graphGradient G.phase (j : Ambient d))
        ((R ^ (-1 / 2 : ℝ))⁻¹ • latticeVector ν) R) := by
    simpa only [Metric.infDist_image A.isometry] using hV
  have h := hb R hR Q hr B hB hcount (G.density.toCoordinate (G.pullInput f)) u t ht V hV'
  have he (j : Q.centers) (ν : Fin d → ℤ) :
      extension (Measure.hausdorffMeasure (d : ℝ)) id
        (G.rotatedAmbientInput A (G.packet Q hr f j ν)) (A (graphPoint u t)) =
      extension G.surfaceMeasure id (G.packet Q hr f j ν) (graphPoint u t) := by
    rw [G.rotatedAmbientInput_extension]
    exact orthogonal_extension_covariance A _ id _ _
  simp_rw [he, G.packet_extension]
  have hn : ‖G.density.toCoordinate (G.pullInput f)‖ ≤ Real.sqrt G.density.upper * ‖f‖ := by
    simpa only [LinearIsometry.norm_map] using G.density.toCoordinate_norm_le (G.pullInput f)
  have hRp : 0 < R := lt_of_lt_of_le zero_lt_one (hR₀.trans hR)
  apply h.trans
  calc
    _ ≤ C * Real.sqrt B * R ^ (-N) * (Real.sqrt G.density.upper * ‖f‖) :=
      mul_le_mul_of_nonneg_left hn (by positivity)
    _ = _ := by ring

end N2Restriction

namespace N2Restriction
open MeasureTheory Set Filter

/-- Pairing a horizontal vector and a height is a bounded linear coordinate map. -/
noncomputable def graphPointCLM {d : ℕ} : (Ambient d × ℝ) →L[ℝ] Ambient (d + 1) :=
  (show (Ambient d × ℝ) →ₗ[ℝ] Ambient (d + 1) from
    { toFun := fun p => graphPoint p.1 p.2
      map_add' := by
        intro x y
        ext j
        refine Fin.cases ?_ (fun k => ?_) j <;> simp [graphPoint]
      map_smul' := by
        intro c x
        ext j
        refine Fin.cases ?_ (fun k => ?_) j <;> simp [graphPoint] }).toContinuousLinearMap

/-- The differentiated original defining function annihilates every rotated graph tangent. -/
theorem SmoothPatch.graph_tangent_normal {d : ℕ} (S : SmoothPatch (d + 1))
    (A : Ambient (d + 1) ≃ₗᵢ[ℝ] Ambient (d + 1)) {U : Set (Ambient d)} (hU : IsOpen U)
    {φ : Ambient d → ℝ} (hφ : ContDiffOn ℝ (⊤ : ℕ∞) φ U)
    (hgraph : ∀ u ∈ U, A (graphPoint u (φ u)) ∈ S.extendedSurface)
    {u : Ambient d} (hu : u ∈ U) (v : Ambient d) :
    inner ℝ (S.normal (A (graphPoint u (φ u))))
      (A (graphPoint v (fderiv ℝ φ u v))) = 0 := by
  have hφd := ((hφ.contDiffAt (hU.mem_nhds hu)).differentiableAt (by simp)).hasFDerivAt
  have hg := graphPointCLM.hasFDerivAt.comp u ((hasFDerivAt_id u).prodMk hφd)
  have hAg := A.toContinuousLinearMap.hasFDerivAt.comp u hg
  have hz := (hgraph u hu).1
  have hSd := ((S.smooth_defining.contDiffAt (S.open_neighborhood.mem_nhds hz)).differentiableAt (by simp)).hasFDerivAt
  have hall := hSd.comp u hAg
  have he : (fun x => S.defining (A (graphPoint x (φ x)))) =ᶠ[nhds u] fun _ => (0 : ℝ) := by
    filter_upwards [hU.mem_nhds hu] with x hx
    exact (hgraph x hx).2
  have hzero : HasFDerivAt (fun x => S.defining (A (graphPoint x (φ x)))) 0 u :=
    (hasFDerivAt_const (𝕜 := ℝ) (0 : ℝ) u).congr_of_eventuallyEq he
  have hv := congrArg (fun L : Ambient d →L[ℝ] ℝ => L v) (hall.unique hzero)
  change fderiv ℝ S.defining (A (graphPoint u (φ u)))
    (A (graphPoint v (fderiv ℝ φ u v))) = 0 at hv
  rw [S.normal_differential _ hz] at hv
  exact (mul_eq_zero.mp hv).resolve_left (S.positive_normalScale _ hz).ne'

end N2Restriction

namespace N2Restriction
open MeasureTheory Set Filter

/-- A vector orthogonal to every graph tangent is a scalar multiple of its packet-axis direction. -/
theorem graph_normal_axis {d : ℕ} (φ : Ambient d → ℝ) (u : Ambient d) (n : Ambient (d + 1))
    (hn : ∀ v : Ambient d, inner ℝ n (graphPoint v (fderiv ℝ φ u v)) = 0) :
    n = (n 0) • graphPoint (-graphGradient φ u) 1 := by
  have hh (j : Fin d) : graphProjection n j + n 0 * graphGradient φ u j = 0 := by
    have h := hn (EuclideanSpace.single j 1)
    rw [← graphPoint_projection_height n, graphPoint_inner, ← graphGradient_inner] at h
    simpa [EuclideanSpace.inner_single_right] using h
  ext j
  refine Fin.cases ?_ (fun k => ?_) j
  · change n 0 = n 0 * 1
    ring
  · change n k.succ = n 0 * (-graphGradient φ u k)
    have h := hh k
    change n k.succ + n 0 * graphGradient φ u k = 0 at h
    linarith

/-- The actual surface normal is parallel to the orthogonally rotated packet axis. -/
theorem SmoothPatch.graph_normal_axis {d : ℕ} (S : SmoothPatch (d + 1))
    (A : Ambient (d + 1) ≃ₗᵢ[ℝ] Ambient (d + 1)) {U : Set (Ambient d)} (hU : IsOpen U)
    {φ : Ambient d → ℝ} (hφ : ContDiffOn ℝ (⊤ : ℕ∞) φ U)
    (hgraph : ∀ u ∈ U, A (graphPoint u (φ u)) ∈ S.extendedSurface)
    {u : Ambient d} (hu : u ∈ U) :
    ∃ c : ℝ, c ≠ 0 ∧ S.normal (A (graphPoint u (φ u))) =
      c • A (graphPoint (-graphGradient φ u) 1) := by
  let n := A.symm (S.normal (A (graphPoint u (φ u))))
  have hn : ∀ v : Ambient d, inner ℝ n (graphPoint v (fderiv ℝ φ u v)) = 0 := by
    intro v
    have he := A.inner_map_map n (graphPoint v (fderiv ℝ φ u v))
    rw [show A n = S.normal (A (graphPoint u (φ u))) from A.apply_symm_apply _] at he
    rw [← he]
    exact S.graph_tangent_normal A hU hφ hgraph hu v
  have haxis := N2Restriction.graph_normal_axis φ u n hn
  have he : S.normal (A (graphPoint u (φ u))) = n 0 • A (graphPoint (-graphGradient φ u) 1) := by
    have h := congrArg A haxis
    simpa only [n, A.apply_symm_apply, map_smul] using h
  refine ⟨n 0, ?_, he⟩
  intro hzero
  have hunit := S.normal_unit _ (hgraph u hu).1
  rw [he, hzero, zero_smul, norm_zero] at hunit
  norm_num at hunit

end N2Restriction

namespace N2Restriction
open MeasureTheory Set Filter

/-- Every cap center in the constructed atlas has the article's normal as its packet-axis direction. -/
theorem PacketGraphAtlas.packet_axis_normal {d : ℕ} {S : SmoothPatch (d + 1)} (T : PacketGraphAtlas S)
    (j : Fin T.size) {u : Ambient d} (hu : u ∈ (T.patch j).support) :
    ∃ c : ℝ, c ≠ 0 ∧ S.normal ((T.patch j).rotation ((T.graph j).parametrization u)) =
      c • (T.patch j).rotation (graphPoint (-graphGradient (T.graph j).phase u) 1) := by
  apply S.graph_normal_axis (T.patch j).rotation
    (U := Metric.ball (T.patch j).center (T.bufferRadius j))
    (φ := (T.graph j).phase) Metric.isOpen_ball (T.smooth j).contDiffOn
  · intro x hx
    exact (T.buffer_inside j ⟨_, ⟨x, (show dist x (T.patch j).center < T.bufferRadius j from hx).le, rfl⟩, rfl⟩).1
  · exact lt_of_le_of_lt (show dist u (T.patch j).center ≤ (T.patch j).innerRadius from
      (T.patch j).support_inside hu) (T.inner_lt j)

end N2Restriction


namespace N2Restriction
open MeasureTheory Set Filter

/-- One fixed-atlas scale threshold gives every rapid-decay order for actual rotated packets.
Cap-count and input-energy quantities remain explicit, so the constructed families can be substituted. -/
theorem PacketGraphAtlas.rapid_tail {d : ℕ} {S : SmoothPatch (d + 1)} (T : PacketGraphAtlas S)
    {τ : ℝ} (hτ : 0 < τ) :
    ∃ R₀ : ℝ, 1 ≤ R₀ ∧ (∀ R : ℝ, R₀ ≤ R → R ^ (-1 / 2 : ℝ) ≤ T.capRadius) ∧
      ∀ N : ℝ, ∃ C : ℝ, 0 ≤ C ∧ ∀ (R : ℝ), R₀ ≤ R →
      ∀ (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support (R ^ (-1 / 2 : ℝ)))
      (hr : 0 < R ^ (-1 / 2 : ℝ)) (B : ℝ), 0 ≤ B →
      (∀ j, ((Q j).centers.card : ℝ) ≤ B * R ^ ((d : ℝ) / 2)) →
      ∀ (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
      (u : Fin T.size → Ambient d) (t : Fin T.size → ℝ), (∀ j, |t j| ≤ R) →
      ∀ V : (j : Fin T.size) → (Q j).centers → Set (Fin d → ℤ),
      (∀ j c ν, ν ∈ V j c → R ^ (1 / 2 + τ) / 10 ≤
        Metric.infDist ((T.patch j).rotation (graphPoint (u j) (t j)))
          ((T.patch j).rotation '' packetSegment (graphGradient (T.graph j).phase (c : Ambient d))
            ((R ^ (-1 / 2 : ℝ))⁻¹ • latticeVector ν) R)) →
      (∑ j, ∑ c, ∑' ν : V j c, ‖extension (Measure.hausdorffMeasure (d : ℝ)) id
        ((T.graph j).rotatedAmbientInput (T.patch j).rotation
          ((T.graph j).packet (Q j) hr (f j) c ν)) ((T.patch j).rotation (graphPoint (u j) (t j)))‖) ≤
          C * Real.sqrt B * R ^ (-N) * Real.sqrt (∑ j, ‖f j‖ ^ 2) := by
  classical
  have hchart (j : Fin T.size) := (T.graph j).rotated_packet_rapid_tail (T.patch j).rotation
    (U := Set.univ) isOpen_univ (T.smooth j).contDiffOn (T.patch j).center
    (a := 2 * ((T.patch j).innerRadius + 1)) (b := 2 * ((T.patch j).innerRadius + 1) + 1)
    (by have := (T.patch j).positive_inner; positivity) (by linarith)
    (subset_univ _) (T.patch j).compact_support
    (fun x hx => show dist x (T.patch j).center < 2 * ((T.patch j).innerRadius + 1) / 2 from by
      have h := (T.patch j).support_inside hx
      change dist x (T.patch j).center ≤ (T.patch j).innerRadius at h
      linarith) hτ
  choose Rj hRj htail using hchart
  obtain ⟨Rb, hRb, hb⟩ := exists_parabolic_radius_threshold T.capRadius_pos
  let R₀ := max Rb (∑ j, Rj j)
  have hR₀ : 1 ≤ R₀ := hRb.trans (le_max_left _ _)
  have hRj₀ j : Rj j ≤ R₀ :=
    (Finset.single_le_sum (fun k _ => (by linarith [hRj k] : 0 ≤ Rj k)) (Finset.mem_univ j)).trans
      (le_max_right _ _)
  refine ⟨R₀, hR₀, fun R hR => hb R ((le_max_left _ _).trans hR), fun N => ?_⟩
  choose C hC hc using fun j => htail j N
  let D := ∑ j, C j
  have hD : 0 ≤ D := Finset.sum_nonneg (fun j _ => hC j)
  have hCD j : C j ≤ D := Finset.single_le_sum (fun k _ => hC k) (Finset.mem_univ j)
  refine ⟨D * Real.sqrt T.size, mul_nonneg hD (Real.sqrt_nonneg _), ?_⟩
  intro R hR Q hr B hB hcount f u t ht V hV
  have hRp : 0 < R := lt_of_lt_of_le zero_lt_one (hR₀.trans hR)
  let F := fun j => ∑ c, ∑' ν : V j c, ‖extension (Measure.hausdorffMeasure (d : ℝ)) id
    ((T.graph j).rotatedAmbientInput (T.patch j).rotation ((T.graph j).packet (Q j) hr (f j) c ν))
      ((T.patch j).rotation (graphPoint (u j) (t j)))‖
  have hF j : F j ≤ (D * Real.sqrt B * R ^ (-N)) * ‖f j‖ := by
    apply (hc j R ((hRj₀ j).trans hR) (Q j) hr B hB (hcount j) (f j) (u j) (t j) (ht j) (V j) (hV j)).trans
    gcongr
    exact hCD j
  have h := finite_cap_absolute_tail (fun j => ‖f j‖) F (δ := D * Real.sqrt B * R ^ (-N)) (by positivity)
    (fun j => by simpa only [norm_norm] using hF j)
  simp only [Fintype.card_fin, norm_norm] at h
  exact h.trans_eq (by ring)

end N2Restriction

namespace N2Restriction
open MeasureTheory Set Filter

/-- Common-atlas rapid tails on one original physical ball, charged to the original input energy. -/
theorem PacketGraphAtlas.rapid_tail_on_ball {d : ℕ} {S : SmoothPatch (d + 1)} (T : PacketGraphAtlas S)
    {τ : ℝ} (hτ : 0 < τ) :
    ∃ R₀ : ℝ, 1 ≤ R₀ ∧ (∀ R : ℝ, R₀ ≤ R → R ^ (-1 / 2 : ℝ) ≤ T.capRadius) ∧
      ∀ N : ℝ, ∃ C : ℝ, 0 ≤ C ∧ ∀ (R : ℝ), R₀ ≤ R →
      ∀ (Q : (j : Fin T.size) → CoordinateCapFamily (T.patch j).support (R ^ (-1 / 2 : ℝ)))
      (hr : 0 < R ^ (-1 / 2 : ℝ)) (B : ℝ), 0 ≤ B →
      (∀ j, ((Q j).centers.card : ℝ) ≤ B * R ^ ((d : ℝ) / 2)) →
      ∀ (f : (j : Fin T.size) → Lp ℂ 2 (T.graph j).surfaceMeasure)
      (g : Lp ℂ 2 S.surfaceMeasure), (∑ j, ‖f j‖ ^ 2) ≤ ‖g‖ ^ 2 →
      ∀ x : Ambient (d + 1), ‖x‖ ≤ R →
      ∀ V : (j : Fin T.size) → (Q j).centers → Set (Fin d → ℤ),
      (∀ j c ν, ν ∈ V j c → R ^ (1 / 2 + τ) / 10 ≤ Metric.infDist x
          ((T.patch j).rotation '' packetSegment (graphGradient (T.graph j).phase (c : Ambient d))
            ((R ^ (-1 / 2 : ℝ))⁻¹ • latticeVector ν) R)) →
      (∑ j, ∑ c, ∑' ν : V j c, ‖extension (Measure.hausdorffMeasure (d : ℝ)) id
        ((T.graph j).rotatedAmbientInput (T.patch j).rotation
          ((T.graph j).packet (Q j) hr (f j) c ν)) x‖) ≤ C * Real.sqrt B * R ^ (-N) * ‖g‖ := by
  obtain ⟨R₀, hR₀, hsmall, htail⟩ := T.rapid_tail hτ
  refine ⟨R₀, hR₀, hsmall, fun N => ?_⟩
  obtain ⟨C, hC, hc⟩ := htail N
  refine ⟨C, hC, ?_⟩
  intro R hR Q hr B hB hcount f g henergy x hx V hV
  let u := fun j => graphProjection ((T.patch j).rotation.symm x)
  let t := fun j => ((T.patch j).rotation.symm x) 0
  have he j : (T.patch j).rotation (graphPoint (u j) (t j)) = x := by
    rw [show graphPoint (u j) (t j) = (T.patch j).rotation.symm x from graphPoint_projection_height _]
    exact (T.patch j).rotation.apply_symm_apply x
  have ht j : |t j| ≤ R := by
    have h := PiLp.norm_apply_le ((T.patch j).rotation.symm x) 0
    rw [Real.norm_eq_abs, (T.patch j).rotation.symm.norm_map] at h
    exact h.trans hx
  have hV' : ∀ j c ν, ν ∈ V j c → R ^ (1 / 2 + τ) / 10 ≤
      Metric.infDist ((T.patch j).rotation (graphPoint (u j) (t j)))
        ((T.patch j).rotation '' packetSegment (graphGradient (T.graph j).phase (c : Ambient d))
          ((R ^ (-1 / 2 : ℝ))⁻¹ • latticeVector ν) R) := by
    simpa only [he] using hV
  have h := hc R hR Q hr B hB hcount f u t ht V hV'
  simp only [he] at h
  have hnorm := Real.sqrt_le_sqrt henergy
  rw [Real.sqrt_sq (norm_nonneg g)] at hnorm
  exact h.trans (mul_le_mul_of_nonneg_left hnorm (by
    have hRp : 0 < R := lt_of_lt_of_le zero_lt_one (hR₀.trans hR)
    positivity))

end N2Restriction

namespace N2Restriction
open MeasureTheory Set Filter

/-- Nested zero extension agrees with direct zero extension to the intersection.
This is the measure-transport identity needed for the original atlas L2 reconstruction. -/
theorem zeroExtendL2_nested {n : ℕ} (μ : Measure (Ambient n)) (B K : Set (Ambient n))
    (hB : MeasurableSet B) (hK : MeasurableSet K)
    (hμ : (μ.restrict B).restrict K = μ.restrict (B ∩ K))
    (f : Lp ℂ 2 ((μ.restrict B).restrict K)) :
    zeroExtendL2 μ B hB (zeroExtendL2 (μ.restrict B) K hK f) =
      zeroExtendL2 μ (B ∩ K) (hB.inter hK) (equalMeasureInput hμ f) := by
  apply Lp.ext
  have hi := (ae_restrict_iff' hB).mp (zeroExtendL2_coe (μ.restrict B) K hK f)
  have hc := (ae_restrict_iff' (hB.inter hK)).mp (equalMeasureInput_coe hμ f)
  filter_upwards [zeroExtendL2_coe μ B hB (zeroExtendL2 (μ.restrict B) K hK f),
    zeroExtendL2_coe μ (B ∩ K) (hB.inter hK) (equalMeasureInput hμ f), hi, hc] with x hx hy hi hc
  rw [hx, hy]
  by_cases hb : x ∈ B
  · rw [indicator_of_mem hb, hi hb]
    by_cases hk : x ∈ K
    · simp only [indicator_of_mem hk, indicator_of_mem (show x ∈ B ∩ K from ⟨hb, hk⟩), hc ⟨hb, hk⟩]
    · simp only [indicator_of_notMem hk, indicator_of_notMem (show x ∉ B ∩ K from fun h => hk h.2)]
  · simp only [indicator_of_notMem hb, indicator_of_notMem (show x ∉ B ∩ K from fun h => hb h.1)]

end N2Restriction
