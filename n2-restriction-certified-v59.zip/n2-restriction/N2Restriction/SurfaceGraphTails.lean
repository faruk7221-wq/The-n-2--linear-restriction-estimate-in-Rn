import N2Restriction.SurfaceGraphPackets

namespace N2Restriction
open MeasureTheory Set

namespace SurfaceGraphChart
variable {d : ℕ} (G : SurfaceGraphChart d)

/-- One constructed family gives rapid tails for the original surface input.
The family and scale threshold precede every requested decay order. -/
theorem exists_packet_rapid_family {U : Set (Ambient d)} (hU : IsOpen U)
    (hφ : ContDiffOn ℝ (⊤ : ℕ∞) G.phase U)
    (z : Ambient d) {a b : ℝ} (ha : 0 < a) (hab : a < b)
    (hball : Metric.closedBall z b ⊆ U) {K : Set (Ambient d)} (hK : IsCompact K)
    (hcenter : K ⊆ Metric.ball z (a / 2)) {τ : ℝ} (hτ : 0 < τ) :
    ∃ P : (R : ℝ) → 1 ≤ R → CoordinateCapFamily K (R ^ (-1 / 2 : ℝ)),
      ∃ R₀ : ℝ, ∃ hR₀ : 1 ≤ R₀, ∀ N : ℝ, ∃ C : ℝ, 0 ≤ C ∧
      ∀ (R : ℝ) (hR : R₀ ≤ R) (hr : 0 < R ^ (-1 / 2 : ℝ))
      (g : Lp ℂ 2 G.surfaceMeasure) (u : Ambient d) (t : ℝ), |t| ≤ R →
      ∀ S : (P R (hR₀.trans hR)).centers → Set (Fin d → ℤ),
      (∀ j ν, ν ∈ S j → R ^ (1 / 2 + τ) / 10 ≤ Metric.infDist (graphPoint u t)
        (packetSegment (graphGradient G.phase (j : Ambient d))
          ((R ^ (-1 / 2 : ℝ))⁻¹ • latticeVector ν) R)) →
      (∑ j, ∑' ν : S j, ‖extension G.surfaceMeasure id
        (G.packet (P R (hR₀.trans hR)) hr g j ν) (graphPoint u t)‖) ≤
          C * R ^ (-N) * ‖g‖ := by
  obtain ⟨P, R₀, hR₀, htail⟩ := exists_coordinate_packet_rapid_family hU hφ z ha hab hball hK hcenter hτ
  refine ⟨P, R₀, hR₀, fun N => ?_⟩
  obtain ⟨C, hC, hb⟩ := htail N
  refine ⟨C * Real.sqrt G.density.upper, mul_nonneg hC (Real.sqrt_nonneg _), ?_⟩
  intro R hR hr g u t ht S hS
  have h := hb R hR hr (G.density.toCoordinate (G.pullInput g)) u t ht S hS
  have hn : ‖G.density.toCoordinate (G.pullInput g)‖ ≤ Real.sqrt G.density.upper * ‖g‖ := by
    simpa only [LinearIsometry.norm_map] using G.density.toCoordinate_norm_le (G.pullInput g)
  simp only [G.packet_extension] at ⊢
  calc
    _ ≤ C * R ^ (-N) * ‖G.density.toCoordinate (G.pullInput g)‖ := h
    _ ≤ C * R ^ (-N) * (Real.sqrt G.density.upper * ‖g‖) :=
      mul_le_mul_of_nonneg_left hn (mul_nonneg hC (Real.rpow_nonneg (by
        have := hR₀.trans hR
        linarith) _))
    _ = _ := by ring

/-- Absolute convergence of selected surface-packet extension sums. -/
theorem packet_absolute_convergence {U : Set (Ambient d)} (hU : IsOpen U)
    (hφ : ContDiffOn ℝ (⊤ : ℕ∞) G.phase U)
    (z : Ambient d) {a b : ℝ} (ha : 0 < a) (hab : a < b)
    (hball : Metric.closedBall z b ⊆ U) {K : Set (Ambient d)} (hK : IsCompact K)
    (hcenter : K ⊆ Metric.ball z (a / 2)) :
    ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ (R : ℝ), R₀ ≤ R →
      ∀ (P : CoordinateCapFamily K (R ^ (-1 / 2 : ℝ))) (hr : 0 < R ^ (-1 / 2 : ℝ))
      (g : Lp ℂ 2 G.surfaceMeasure) (u : Ambient d) (t : ℝ), |t| ≤ R →
      ∀ (j : P.centers) (S : Set (Fin d → ℤ)),
      Summable (fun ν : S => ‖extension G.surfaceMeasure id (G.packet P hr g j ν) (graphPoint u t)‖) := by
  obtain ⟨R₀, hR₀, hb⟩ := coordinate_family_absolute_convergence hU hφ z ha hab hball hK hcenter
  refine ⟨R₀, hR₀, ?_⟩
  intro R hR P hr g u t ht j S
  simpa only [G.packet_extension, parametrization] using
    hb R hR P hr (G.density.toCoordinate (G.pullInput g)) u t ht j S

end SurfaceGraphChart
end N2Restriction
