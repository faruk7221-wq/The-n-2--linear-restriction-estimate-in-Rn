import N2Restriction.ScaledCube
import N2Restriction.CutoffFourierPackets

namespace N2Restriction
open MeasureTheory UnitAddTorus
noncomputable local instance capFourierCircleMeasure : MeasureSpace UnitAddCircle := ⟨AddCircle.haarAddCircle⟩

/-- The Fourier torus and a translated, scaled frequency cube with normalized measure. -/
noncomputable def torusCapEquiv {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : r ≠ 0) : Lp ℂ 2 (volume : Measure (UnitAddTorus (Fin d))) ≃ₗᵢ[ℂ]
      Lp ℂ 2 (capProbability t c r hr) :=
  (cubeTorusEquiv t).trans (cubeCapEquiv t c r hr)

noncomputable def capFourierCoeff {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : r ≠ 0) (f : Lp ℂ 2 (capProbability t c r hr)) (ν : Fin d → ℤ) : ℂ :=
  mFourierCoeff ((torusCapEquiv t c r hr).symm f) ν

noncomputable def capFourierAtom {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : r ≠ 0) (ν : Fin d → ℤ) : Lp ℂ 2 (capProbability t c r hr) :=
  torusCapEquiv t c r hr (mFourierLp 2 ν)

/-- Fourier reconstruction for an arbitrary input on the actual frequency cube. -/
theorem cap_fourier_reconstruction {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : r ≠ 0) (f : Lp ℂ 2 (capProbability t c r hr)) :
    HasSum (fun ν => capFourierCoeff t c r hr f ν • capFourierAtom t c r hr ν) f := by
  have h := (torusCapEquiv t c r hr).toContinuousLinearEquiv.toContinuousLinearMap.hasSum
    (hasSum_mFourier_series_L2 ((torusCapEquiv t c r hr).symm f))
  simpa only [ContinuousLinearEquiv.coe_coe, LinearIsometryEquiv.coe_toContinuousLinearEquiv,
    map_smul, LinearIsometryEquiv.apply_symm_apply, capFourierCoeff, capFourierAtom] using h

/-- Parseval, with no assumed coefficient family: these coefficients are extracted from f. -/
theorem cap_fourier_energy {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : r ≠ 0) (f : Lp ℂ 2 (capProbability t c r hr)) :
    (∑' ν, ‖capFourierCoeff t c r hr f ν‖ ^ 2) = ‖f‖ ^ 2 := by
  have h := (hilbert_coefficient_energy mFourierBasis ((torusCapEquiv t c r hr).symm f)).tsum_eq
  simpa only [mFourierBasis_repr, capFourierCoeff, LinearIsometryEquiv.norm_map] using h

/-- Every cap Fourier mode has unit norm for the explicitly normalized cap measure. -/
theorem cap_fourier_atom_norm {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : r ≠ 0) (ν : Fin d → ℤ) : ‖capFourierAtom t c r hr ν‖ = 1 := by
  unfold capFourierAtom
  rw [LinearIsometryEquiv.norm_map]
  exact orthonormal_mFourier.1 ν

/-- Pointwise identification of a cap Fourier mode, up to the usual L2 null set. -/
theorem cap_fourier_atom_coe {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : r ≠ 0) (ν : Fin d → ℤ) :
    ∀ᵐ ξ ∂capProbability t c r hr,
      capFourierAtom t c r hr ν ξ =
        mFourier ν (cubeQuotient ((capAffine c r hr).symm ξ)) := by
  filter_upwards [Lp.coeFn_compMeasurePreserving (torusToCube t (mFourierLp 2 ν))
      (capAffine_symm_measurePreserving t c r hr),
    (capAffine_symm_measurePreserving t c r hr).quasiMeasurePreserving.ae
      (torusToCube_coe t (mFourierLp 2 ν)),
    ((cubeQuotient_measurePreserving t).comp (capAffine_symm_measurePreserving t c r hr)).quasiMeasurePreserving.ae (coeFn_mFourierLp 2 ν)] with ξ hx hy hz
  change capFourierAtom t c r hr ν ξ = _ at hx
  exact hx.trans (hy.trans hz)

/-- Reconstruction persists under a bounded operator, for example cutoff and extension. -/
theorem cap_fourier_synthesis {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : r ≠ 0) {F : Type*} [NormedAddCommGroup F] [NormedSpace ℂ F]
    (T : Lp ℂ 2 (capProbability t c r hr) →L[ℂ] F)
    (f : Lp ℂ 2 (capProbability t c r hr)) :
    HasSum (fun ν => capFourierCoeff t c r hr f ν • T (capFourierAtom t c r hr ν)) (T f) := by
  simpa only [map_smul] using T.hasSum (cap_fourier_reconstruction t c r hr f)

end N2Restriction
