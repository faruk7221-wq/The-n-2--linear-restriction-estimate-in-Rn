import N2Restriction.GraphAtlasMargins

namespace N2Restriction
open MeasureTheory Set
namespace LocalGraphPatch

/-- A fixed positive gap keeps enlarged packet caps in the local graph domain. -/
theorem exists_buffered_chart {d : ℕ} (P : LocalGraphPatch d) :
    ∃ (G : SurfaceGraphChart d) (a ρ : ℝ), ContDiff ℝ (⊤ : ℕ∞) G.phase ∧
      P.innerRadius < a ∧ a < P.outerRadius ∧ 0 < ρ ∧
      EqOn G.phase P.phase (Metric.closedBall P.center a) ∧
      ∀ (c : Ambient d), c ∈ P.support → ∀ r : ℝ, r ≤ ρ →
        Metric.ball c (2 * r) ⊆ Metric.closedBall P.center a := by
  let a := (P.innerRadius + P.outerRadius) / 2
  have hia : P.innerRadius < a := by dsimp [a]; linarith [P.radii_lt]
  have hao : a < P.outerRadius := by dsimp [a]; linarith [P.radii_lt]
  obtain ⟨G, hG, he⟩ := exists_local_surfaceGraphChart P.open_domain P.smooth_phase P.center
    (P.positive_inner.trans hia) hao P.ball_inside
  refine ⟨G, a, (a - P.innerRadius) / 2, hG, hia, hao, by linarith, he, ?_⟩
  intro c hc r hr x hx
  have hc' : dist c P.center ≤ P.innerRadius := P.support_inside hc
  have hx' : dist x c < 2 * r := hx
  have ht := dist_triangle x c P.center
  change dist x P.center ≤ a
  linarith

/-- Agreement on a buffered ball identifies the original rotated carrier exactly. -/
theorem buffered_carrier_eq {d : ℕ} (P : LocalGraphPatch d) (G : SurfaceGraphChart d)
    {a : ℝ} (hia : P.innerRadius ≤ a)
    (he : EqOn G.phase P.phase (Metric.closedBall P.center a)) :
    P.carrier = P.rotation '' (G.parametrization '' P.support) := by
  unfold carrier
  congr 1
  apply image_congr
  intro x hx
  change graphPoint x (P.phase x) = graphPoint x (G.phase x)
  rw [he ((Metric.closedBall_subset_closedBall hia) (P.support_inside hx))]

/-- On the buffer the global auxiliary graph still parametrizes the actual extended surface. -/
theorem buffered_graph_inside {d : ℕ} (P : LocalGraphPatch d) (S : SmoothPatch (d + 1))
    (hPS : ∀ u ∈ P.domain, P.rotation (graphPoint u (P.phase u)) ∈ S.extendedSurface)
    (G : SurfaceGraphChart d) {a : ℝ} (hao : a ≤ P.outerRadius)
    (he : EqOn G.phase P.phase (Metric.closedBall P.center a)) :
    P.rotation '' (G.parametrization '' Metric.closedBall P.center a) ⊆ S.extendedSurface := by
  rintro y ⟨x, ⟨u, hu, rfl⟩, rfl⟩
  change P.rotation (graphPoint u (G.phase u)) ∈ S.extendedSurface
  rw [he hu]
  exact hPS u (P.ball_inside (Metric.closedBall_subset_closedBall hao hu))

/-- Enlarged cap packets on a buffered chart remain on the original extended surface. -/
theorem buffered_packet_support {d : ℕ} (P : LocalGraphPatch d) (S : SmoothPatch (d + 1))
    (hPS : ∀ u ∈ P.domain, P.rotation (graphPoint u (P.phase u)) ∈ S.extendedSurface)
    (G : SurfaceGraphChart d) {a r : ℝ} (hao : a ≤ P.outerRadius)
    (he : EqOn G.phase P.phase (Metric.closedBall P.center a))
    (Q : CoordinateCapFamily P.support r) (hr : 0 < r)
    (hcap : ∀ c ∈ P.support, Metric.ball c (2 * r) ⊆ Metric.closedBall P.center a)
    (g : Lp ℂ 2 G.surfaceMeasure) (j : Q.centers) (ν : Fin d → ℤ) :
    HasFrequencySupport G.surfaceMeasure P.rotation S.extendedSurface (G.packet Q hr g j ν) := by
  filter_upwards [G.packet_support Q hr g j ν] with x hx hn
  apply P.buffered_graph_inside S hPS G hao he
  refine ⟨x, ?_, rfl⟩
  exact image_mono (hcap j (Q.centers_mem j.property)) (hx hn)

end LocalGraphPatch

/-- A finite atlas admits smooth global graph extensions and common positive packet and
ambient buffers. All choices precede the input, cap family, and decay order. -/
theorem SmoothPatch.exists_packet_buffered_atlas {d : ℕ} (S : SmoothPatch (d + 1)) :
    ∃ (m : ℕ) (P : Fin m → LocalGraphPatch d) (G : Fin m → SurfaceGraphChart d)
      (a : Fin m → ℝ) (ρ δ : ℝ), 0 < ρ ∧ 0 < δ ∧
      (S.support ⊆ ⋃ j, (P j).carrier) ∧
      (∀ j, ContDiff ℝ (⊤ : ℕ∞) (G j).phase ∧
        (P j).innerRadius < a j ∧ a j < (P j).outerRadius ∧
        EqOn (G j).phase (P j).phase (Metric.closedBall (P j).center (a j))) ∧
      (∀ j, (P j).carrier = (P j).rotation '' ((G j).parametrization '' (P j).support)) ∧
      (∀ j, (P j).rotation '' ((G j).parametrization '' Metric.closedBall (P j).center (a j)) ⊆
        S.extendedSurface ∩ marginRegion S.neighborhood δ) ∧
      ∀ j c, c ∈ (P j).support → ∀ r : ℝ, r ≤ ρ →
        Metric.ball c (2 * r) ⊆ Metric.closedBall (P j).center (a j) := by
  classical
  obtain ⟨m, P, hcover, _, hdomain⟩ := S.exists_finite_graph_cover
  choose G a ρ hs hia hao hρ he hcap using fun j => (P j).exists_buffered_chart
  let q : Option (Fin m) → ℝ := fun j => j.elim 1 ρ
  let r₀ := Finset.univ.inf' (Finset.univ_nonempty : (Finset.univ : Finset (Option (Fin m))).Nonempty) q
  have hr₀ : 0 < r₀ := by
    apply (Finset.lt_inf'_iff _).mpr
    intro j _
    cases j with
    | none => exact zero_lt_one
    | some j => exact hρ j
  have hr (j : Fin m) : r₀ ≤ ρ j := Finset.inf'_le q (Finset.mem_univ (some j))
  let B := fun j => (P j).rotation '' ((G j).parametrization '' Metric.closedBall (P j).center (a j))
  have hB (j) : IsCompact (B j) :=
    ((isCompact_closedBall _ _).image (graphMap_lipschitz (G j).lipschitz).continuous).image
      (P j).rotation.continuous
  have hBS (j) : B j ⊆ S.extendedSurface := (P j).buffered_graph_inside S (hdomain j) (G j) (hao j).le (he j)
  have hBU : (⋃ j, B j) ⊆ S.neighborhood := by
    intro x hx
    obtain ⟨j, hj⟩ := mem_iUnion.mp hx
    exact (hBS j hj).1
  obtain ⟨δ, hδ, hmargin⟩ := compact_subset_positive_margin (isCompact_iUnion hB) S.open_neighborhood hBU
  refine ⟨m, P, G, a, r₀, δ, hr₀, hδ, hcover,
    fun j => ⟨hs j, hia j, hao j, he j⟩,
    fun j => (P j).buffered_carrier_eq (G j) (hia j).le (he j), ?_, ?_⟩
  · intro j x hx
    exact ⟨hBS j hx, hmargin (mem_iUnion.mpr ⟨j, hx⟩)⟩
  · intro j c hc r hrr
    exact hcap j c hc r (hrr.trans (hr j))

end N2Restriction
