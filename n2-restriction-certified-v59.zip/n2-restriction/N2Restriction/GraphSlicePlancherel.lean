import N2Restriction.FourierPlancherel

namespace N2Restriction
open MeasureTheory

/-- At a fixed height, the graph extension is a flat transform of a unit-modulus modulation. -/
theorem graph_extension_slice {d : ℕ} (φ : Ambient d → ℝ) (f : Ambient d → ℂ)
    (t : ℝ) (u : Ambient d) :
    extension volume (fun x => graphPoint x (φ x)) f (graphPoint u t) =
      extension volume id (fun x => Complex.exp (((t * φ x : ℝ) : ℂ) * Complex.I) * f x) u := by
  unfold extension
  apply integral_congr_ae
  filter_upwards with x
  rw [graphPoint_inner]
  simp only [Complex.ofReal_add, add_mul, Complex.exp_add, mul_assoc, id_eq]

/-- Graph modulation preserves the frequency-side energy exactly. -/
theorem graph_modulation_energy {d : ℕ} (φ : Ambient d → ℝ) (f : Ambient d → ℂ) (t : ℝ) :
    (∫ x, ‖Complex.exp (((t * φ x : ℝ) : ℂ) * Complex.I) * f x‖ ^ 2) =
      ∫ x, ‖f x‖ ^ 2 := by
  simp only [norm_mul, Complex.norm_exp_ofReal_mul_I, one_mul]

/-- Smooth graph extensions have the same slice energy at every height.
This statement currently assumes smooth compactly supported coordinate input. -/
theorem smooth_graph_slice_plancherel {d : ℕ} {φ : Ambient d → ℝ}
    (hφ : ContDiff ℝ (⊤ : ℕ∞) φ) {f : Ambient d → ℂ}
    (hf : ContDiff ℝ (⊤ : ℕ∞) f) (hs : HasCompactSupport f) (t : ℝ) :
    (∫ u, ‖extension volume (fun x => graphPoint x (φ x)) f (graphPoint u t)‖ ^ 2) =
      (2 * Real.pi) ^ d * ∫ x, ‖f x‖ ^ 2 := by
  let g : Ambient d → ℂ := fun x => Complex.exp (((t * φ x : ℝ) : ℂ) * Complex.I) * f x
  have hg : ContDiff ℝ (⊤ : ℕ∞) g := by
    dsimp [g]
    have hreal : ContDiff ℝ (⊤ : ℕ∞) (fun x => ((t * φ x : ℝ) : ℂ)) :=
      Complex.ofRealCLM.contDiff.comp (contDiff_const.mul hφ)
    fun_prop
  have hgs : HasCompactSupport g := hs.mul_left
  simp_rw [graph_extension_slice]
  rw [smooth_compact_flat_plancherel hg hgs, graph_modulation_energy]

/-- Integration over a finite interval of heights has exactly its length as the additional factor. -/
theorem smooth_graph_slab_energy {d : ℕ} {φ : Ambient d → ℝ}
    (hφ : ContDiff ℝ (⊤ : ℕ∞) φ) {f : Ambient d → ℂ}
    (hf : ContDiff ℝ (⊤ : ℕ∞) f) (hs : HasCompactSupport f) (a b : ℝ) :
    (∫ t in Set.Icc a b, ∫ u,
      ‖extension volume (fun x => graphPoint x (φ x)) f (graphPoint u t)‖ ^ 2) =
      (max (b - a) 0) * ((2 * Real.pi) ^ d * ∫ x, ‖f x‖ ^ 2) := by
  simp_rw [smooth_graph_slice_plancherel hφ hf hs]
  rw [integral_const]
  simp [Real.volume_Icc, Measure.real, ENNReal.toReal_ofReal', smul_eq_mul]

end N2Restriction
