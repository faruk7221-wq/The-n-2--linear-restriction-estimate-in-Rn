import N2Restriction.UniformImplicit
import N2Restriction.CompactFrames
import N2Restriction.FiniteImplicitAtlas

namespace N2Restriction

/-- Adding the parameter as an output coordinate turns vertical regularity
into ordinary surjectivity. -/
theorem augmented_parameter_derivative_surjective {P E F : Type*}
    [NormedAddCommGroup P] [NormedSpace ℝ P]
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    (L : P × E →L[ℝ] F)
    (hL : Function.Surjective (fun x : E => L (0, x))) :
    Function.Surjective ((ContinuousLinearMap.fst ℝ P E).prod L) := by
  rintro ⟨p, t⟩
  obtain ⟨x, hx⟩ := hL (t - L (p, 0))
  change L (0, x) = t - L (p, 0) at hx
  refine ⟨(p, x), Prod.ext rfl ?_⟩
  change L (p, x) = t
  have he : (p, x) = (p, 0) + (0, x) := by simp
  rw [he, map_add, hx]
  abel

/-- Compact smooth families with surjective vertical derivatives have common
parameter-preserving chart radii and all-order inverse derivative bounds. -/
theorem compact_parameter_submersion_charts {P E F : Type*}
    [NormedAddCommGroup P] [NormedSpace ℝ P] [FiniteDimensional ℝ P]
    [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    {f : P × E → F} {U K : Set (P × E)} (hU : IsOpen U)
    (hf : ContDiffOn ℝ (⊤ : ℕ∞) f U) (hK : IsCompact K) (hKU : K ⊆ U)
    (hreg : ∀ z ∈ K, Function.Surjective (fun x : E => fderiv ℝ f z (0, x))) :
    ∃ r : ℝ, 0 < r ∧ ∃ B : ℕ → ℝ, (∀ m, 0 ≤ B m) ∧
      ∀ x ∈ K, ControlledSubmersionChart (fun q => (q.1, f q)) U x r B := by
  apply compact_controlled_submersion_charts hU (contDiffOn_fst.prodMk hf) hK hKU
  intro z hz
  have hd := hasFDerivAt_fst.prodMk
    ((hf.contDiffAt (hU.mem_nhds (hKU hz))).differentiableAt (by simp)).hasFDerivAt
  rw [hd.fderiv]
  exact augmented_parameter_derivative_surjective _ (hreg z hz)

/-- The normal-frame constraint is jointly smooth in the coordinate map and
the frequency, on the full extended neighborhood. -/
theorem contDiffOn_frameConstraint {n : ℕ} {F : Type*}
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    (S : SmoothPatch n) :
    ContDiffOn ℝ (⊤ : ℕ∞) (frameConstraint (F := F) S)
      (Set.univ ×ˢ S.neighborhood) := by
  have hd : ContDiffOn ℝ (⊤ : ℕ∞)
      (fun q : (Ambient n →L[ℝ] F) × Ambient n => S.defining q.2)
      (Set.univ ×ˢ S.neighborhood) :=
    S.smooth_defining.comp contDiffOn_snd (fun _ h => h.2)
  have hn : ContDiffOn ℝ (⊤ : ℕ∞)
      (fun q : (Ambient n →L[ℝ] F) × Ambient n => S.normal q.2)
      (Set.univ ×ˢ S.neighborhood) :=
    S.smooth_normal.comp contDiffOn_snd (fun _ h => h.2)
  exact hd.prodMk (contDiffOn_fst.clm_apply hn)

/-- Every point of the compact admissible family is vertically regular;
the projected normal need not vanish at the base point. -/
theorem frameFrequencyAdmissibleImage_vertical_regular {n : ℕ}
    (S : SmoothPatch n) {κ : ℝ} (hκ : 0 < κ)
    {q : (Ambient n →L[ℝ] (ℝ × ℝ)) × Ambient n}
    (hq : q ∈ frameFrequencyAdmissibleImage S κ) :
    Function.Surjective (fun x : Ambient n => frameDifferential S q (0, x)) := by
  rcases hq with ⟨r, hr, rfl⟩
  rcases r.2 with ⟨hpW, hpH, hz⟩
  rcases hr with ⟨ht₀, ht₁, hgap, hcurv⟩
  let W := pairPlane r.1.1
  let H := pairPlane r.1.2.1
  let e : H ≃L[ℝ] (ℝ × ℝ) := pairFrameEquiv H r.1.2.1 hpH rfl
  have hW : ∀ v : W, inner ℝ (S.normal r.1.2.2) (v : Ambient n) = 0 := by
    intro v
    obtain ⟨a, b, hab⟩ := Submodule.mem_span_pair.mp v.property
    rw [← hab, inner_add_right, inner_smul_right, inner_smul_right, ht₀, ht₁]
    ring
  have hA : ∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (S.shape r.1.2.2 v)‖ := by
    intro v
    obtain ⟨a, b, hab⟩ := Submodule.mem_span_pair.mp v.property
    have hc := hcurv (a, b)
    have hc' : κ * ‖(v : Ambient n)‖ ≤
        ‖pairProjection r.1.1 (S.shape r.1.2.2 v)‖ := by simpa [hab] using hc
    rw [pairProjection_eq_planeProjection hpW] at hc'
    exact hc'
  have hg : ‖W.starProjection - H.starProjection‖ * ‖S.shape r.1.2.2‖ ≤ κ / 2 := by
    rw [← pairProjection_eq_planeProjection hpW, ← pairProjection_eq_planeProjection hpH]
    exact hgap
  apply frameDifferential_vertical_surjective S (S.support_inside hz) W hW
  change Function.Surjective ((pairFrameMap r.1.2.1).comp ((S.shape r.1.2.2).comp W.subtypeL))
  rw [← pairFrameEquiv_comp_projection H r.1.2.1 hpH rfl]
  exact nearby_frame_shape_surjective S r.1.2.2 W H
    ((pairPlane_finrank_two hpW).trans (pairPlane_finrank_two hpH).symm) e hκ hA hg

/-- Common parameter-preserving chart radii and all-order inverse derivative
bounds for the complete compact nearby-plane frame-frequency family. -/
theorem compact_frameFrequencyAdmissible_charts {n : ℕ}
    (S : SmoothPatch n) {κ : ℝ} (hκ : 0 < κ) :
    ∃ r : ℝ, 0 < r ∧ ∃ B : ℕ → ℝ, (∀ m, 0 ≤ B m) ∧
      ∀ q ∈ frameFrequencyAdmissibleImage S κ,
        ControlledSubmersionChart (fun q => (q.1, frameConstraint S q))
          (Set.univ ×ˢ S.neighborhood) q r B := by
  have hsub : frameFrequencyAdmissibleImage S κ ⊆ Set.univ ×ˢ S.neighborhood := by
    rintro q ⟨r, hr, rfl⟩
    exact ⟨Set.mem_univ _, S.support_inside r.2.2.2⟩
  apply compact_parameter_submersion_charts (isOpen_univ.prod S.open_neighborhood)
    (contDiffOn_frameConstraint S) (isCompact_frameFrequencyAdmissibleImage S κ) hsub
  intro q hq
  rw [(hasStrictFDerivAt_frameConstraint S (hsub hq).2).hasFDerivAt.fderiv]
  exact frameFrequencyAdmissibleImage_vertical_regular S hκ hq

/-- One radius and one derivative-bound sequence work simultaneously for all
patch indices, all supported frequencies, and all admissible nearby frames. -/
theorem uniform_frameFrequencyAdmissible_charts {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) {κ : ℝ} (hκ : 0 < κ) :
    ∃ r : ℝ, 0 < r ∧ ∃ B : ℕ → ℝ, (∀ m, 0 ≤ B m) ∧ ∀ i,
      ∀ q ∈ frameFrequencyAdmissibleImage (S i) κ,
        ControlledSubmersionChart (fun q => (q.1, frameConstraint (S i) q))
          (Set.univ ×ˢ (S i).neighborhood) q r B := by
  classical
  by_cases hk : k = 0
  · subst k
    exact ⟨1, by norm_num, fun _ => 0, fun _ => le_rfl, fun i => Fin.elim0 i⟩
  have hkpos : 0 < k := Nat.pos_of_ne_zero hk
  letI : Nonempty (Fin k) := ⟨⟨0, hkpos⟩⟩
  have hne : (Finset.univ : Finset (Fin k)).Nonempty := Finset.univ_nonempty
  choose r hr B hB hb using fun i => compact_frameFrequencyAdmissible_charts (S i) hκ
  let r₀ := (Finset.univ : Finset (Fin k)).inf' hne r
  let B₀ := fun m => ∑ i : Fin k, B i m
  refine ⟨r₀, (Finset.lt_inf'_iff _).2 (fun i _ => hr i), B₀,
    fun m => Finset.sum_nonneg (fun i _ => hB i m), fun i q hq => ?_⟩
  apply (hb i q hq).mono
  · exact Finset.inf'_le _ (Finset.mem_univ i)
  · intro m
    exact Finset.single_le_sum (fun j _ => hB j m) (Finset.mem_univ i)

/-- The article's supported geometric tuples and arbitrary nearby two-planes
are covered by the common controlled charts. The frame is an actual coordinate
equivalence on the specified plane, rather than an additional hypothesis. -/
theorem geometric_uniform_nearby_plane_charts {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) {ν κ : ℝ}
    (hgeo : GeometricHypotheses S ν κ) :
    ∃ r : ℝ, 0 < r ∧ ∃ B : ℕ → ℝ, (∀ m, 0 ≤ B m) ∧
      ∀ (z : Fin k → Ambient (k + 2)), (∀ j, z j ∈ (S j).support) →
      ∀ i (H : Submodule ℝ (Ambient (k + 2))), Module.finrank ℝ H = 2 →
      ‖(commonTangent (fun j => (S j).normal (z j))).starProjection - H.starProjection‖ *
          ‖(S i).shape (z i)‖ ≤ κ / 2 →
      ∃ e : H ≃L[ℝ] (ℝ × ℝ),
        ControlledSubmersionChart (fun q => (q.1, frameConstraint (S i) q))
          (Set.univ ×ˢ (S i).neighborhood)
          (e.toContinuousLinearMap.comp H.orthogonalProjection, z i) r B := by
  obtain ⟨r, hr, B, hB, hb⟩ := uniform_frameFrequencyAdmissible_charts S hgeo.2.1
  refine ⟨r, hr, B, hB, fun z hz i H hdim hgap => ?_⟩
  obtain ⟨q, hq, hqz, _, e, he⟩ :=
    exists_frameFrequencyAdmissible_for_geometricTuple_and_plane S hgeo z hz i H hdim hgap
  refine ⟨e, ?_⟩
  have hqe : q = (e.toContinuousLinearMap.comp H.orthogonalProjection, z i) :=
    Prod.ext he hqz
  exact hqe ▸ hb i q hq

/-- An explicit finite atlas covers the entire compact frame-frequency family,
with a common source/target radius and one bound for every derivative order. -/
theorem compact_frameFrequencyAdmissible_finite_atlas {n : ℕ}
    (S : SmoothPatch n) {κ : ℝ} (hκ : 0 < κ) :
    ∃ r : ℝ, 0 < r ∧ ∃ B : ℕ → ℝ, (∀ m, 0 ≤ B m) ∧
      ∃ A : Finset (SubmersionChartModel
        ((Ambient n →L[ℝ] (ℝ × ℝ)) × Ambient n)
        ((Ambient n →L[ℝ] (ℝ × ℝ)) × (ℝ × (ℝ × ℝ)))),
      ∀ q ∈ frameFrequencyAdmissibleImage S κ, ∃ c ∈ A,
        c.Controls (fun q => (q.1, frameConstraint S q))
          (Set.univ ×ˢ S.neighborhood) q r B := by
  obtain ⟨r, hr, B, hB, hb⟩ := compact_frameFrequencyAdmissible_charts S hκ
  apply compact_finite_controlled_atlas (isCompact_frameFrequencyAdmissibleImage S κ)
  exact fun q hq => ⟨r, hr, B, hB, hb q hq⟩

/-- The chart type for joint normal-frame and frequency coordinates. -/
abbrev FrameChartModel (n : ℕ) := SubmersionChartModel
  ((Ambient n →L[ℝ] (ℝ × ℝ)) × Ambient n)
  ((Ambient n →L[ℝ] (ℝ × ℝ)) × (ℝ × (ℝ × ℝ)))

/-- Uniformly finite atlases for the finite patch family, with one positive
radius, all-order bounds in both coordinate directions, and one chart-count
bound independent of the patch, frequency, and nearby plane. -/
theorem uniform_frameFrequencyAdmissible_finite_atlases {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) {κ : ℝ} (hκ : 0 < κ) :
    ∃ r : ℝ, 0 < r ∧ ∃ B : ℕ → ℝ, (∀ m, 0 ≤ B m) ∧
      ∃ N : ℕ, ∃ A : Fin k → Finset (FrameChartModel (k + 2)),
      (∀ i, (A i).card ≤ N) ∧ ∀ i,
      ∀ q ∈ frameFrequencyAdmissibleImage (S i) κ, ∃ c ∈ A i,
        c.Controls (fun q => (q.1, frameConstraint (S i) q))
          (Set.univ ×ˢ (S i).neighborhood) q r B := by
  classical
  by_cases hk : k = 0
  · subst k
    refine ⟨1, by norm_num, fun _ => 0, fun _ => le_rfl, 0, fun _ => ∅, ?_, ?_⟩
    · simp
    · intro i
      exact Fin.elim0 i
  have hkpos : 0 < k := Nat.pos_of_ne_zero hk
  letI : Nonempty (Fin k) := ⟨⟨0, hkpos⟩⟩
  have hne : (Finset.univ : Finset (Fin k)).Nonempty := Finset.univ_nonempty
  choose r hr B hB A ha using fun i => compact_frameFrequencyAdmissible_finite_atlas (S i) hκ
  let r₀ := (Finset.univ : Finset (Fin k)).inf' hne r
  let B₀ := fun m => ∑ i : Fin k, B i m
  refine ⟨r₀, (Finset.lt_inf'_iff _).2 (fun i _ => hr i), B₀,
    (fun m => Finset.sum_nonneg (fun i _ => hB i m)),
    ∑ i : Fin k, (A i).card, A, ?_, ?_⟩
  · intro i
    exact Finset.single_le_sum (f := fun j => (A j).card)
      (fun j _ => Nat.zero_le _) (Finset.mem_univ i)
  · intro i q hq
    obtain ⟨c, hc, hctrl⟩ := ha i q hq
    refine ⟨c, hc, hctrl.mono (Finset.inf'_le _ (Finset.mem_univ i)) ?_⟩
    intro m
    exact Finset.single_le_sum (fun j _ => hB j m) (Finset.mem_univ i)

end N2Restriction
