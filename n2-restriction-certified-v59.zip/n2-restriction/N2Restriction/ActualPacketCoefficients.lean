import N2Restriction.GlobalGraphModes

namespace N2Restriction
open MeasureTheory UnitAddTorus
noncomputable local instance actualPacketCircleMeasure : MeasureSpace UnitAddCircle := ⟨AddCircle.haarAddCircle⟩

/-- The fixed complex cutoff used by the actual coordinate packets. -/
noncomputable def packetCutoff (d : ℕ) (η : Ambient d) : ℂ := referenceBump d η

theorem packetCutoff_smooth (d : ℕ) : ContDiff ℝ (⊤ : ℕ∞) (packetCutoff d) := by
  exact Complex.ofRealCLM.contDiff.comp (referenceBump d).contDiff

theorem packetCutoff_compact (d : ℕ) : HasCompactSupport (packetCutoff d) := by
  apply (referenceBump d).hasCompactSupport.mono
  intro η hη
  simpa only [Function.mem_support, packetCutoff, ne_eq, Complex.ofReal_eq_zero] using hη

/-- The cap center only changes Fourier coefficients by a unit-modulus phase. -/
noncomputable def packetCenterPhase {d : ℕ} (c : Ambient d) (r : ℝ) (ν : Fin d → ℤ) : ℂ :=
  Complex.exp (-((inner ℝ (r⁻¹ • latticeVector ν) c : ℂ) * Complex.I))

theorem packetCenterPhase_norm {d : ℕ} (c : Ambient d) (r : ℝ) (ν : Fin d → ℤ) :
    ‖packetCenterPhase c r ν‖ = 1 := by
  unfold packetCenterPhase
  rw [← neg_mul, ← Complex.ofReal_neg, Complex.norm_exp_ofReal_mul_I]

/-- The actual ordinary cap input, transported to the torus with the graph-packet
rather than unit-cube normalization. -/
noncomputable def packetTorusInput {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume.restrict (packetFrequencyCube c r hr))) :
    Lp ℂ 2 (volume : Measure (UnitAddTorus (Fin d))) :=
  ((r ^ ((d : ℝ) / 2) : ℝ) : ℂ) •
    (torusCapEquiv (fun _ => -(1 / 2 : ℝ)) c (2 * Real.pi * r) (by positivity)).symm
      (normalizedCapInput (fun _ => -(1 / 2 : ℝ)) c (2 * Real.pi * r) (by positivity) f)

/-- Coefficients extracted from the original cap input, with its center phase. -/
noncomputable def actualPacketCoeff {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume.restrict (packetFrequencyCube c r hr))) (ν : Fin d → ℤ) : ℂ :=
  packetCenterPhase c r ν * mFourierCoeff (packetTorusInput c r hr f) ν

theorem packetTorusInput_norm {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume.restrict (packetFrequencyCube c r hr))) :
    ‖packetTorusInput c r hr f‖ = (2 * Real.pi) ^ (-(d : ℝ) / 2) * ‖f‖ := by
  unfold packetTorusInput
  rw [norm_smul, Complex.norm_real, Real.norm_eq_abs,
    abs_of_nonneg (Real.rpow_nonneg hr.le _), LinearIsometryEquiv.norm_map,
    normalizedCapInput_norm, cap_packet_normalization r hr]
  have hc : r ^ ((d : ℝ) / 2) * r ^ (-(d : ℝ) / 2) = 1 := by
    rw [← Real.rpow_add hr, show (d : ℝ) / 2 + -(d : ℝ) / 2 = 0 by ring, Real.rpow_zero]
  calc
    _ = (r ^ ((d : ℝ) / 2) * r ^ (-(d : ℝ) / 2)) *
        ((2 * Real.pi) ^ (-(d : ℝ) / 2) * ‖f‖) := by ring
    _ = _ := by rw [hc, one_mul]

theorem packetTorusInput_coefficient {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume.restrict (packetFrequencyCube c r hr))) (ν : Fin d → ℤ) :
    mFourierCoeff (packetTorusInput c r hr f) ν =
      (r ^ ((d : ℝ) / 2) : ℝ) *
        capFourierCoeff (fun _ => -(1 / 2 : ℝ)) c (2 * Real.pi * r) (by positivity)
          (normalizedCapInput (fun _ => -(1 / 2 : ℝ)) c (2 * Real.pi * r) (by positivity) f) ν := by
  simp only [packetTorusInput, ← mFourierBasis_repr, map_smul,
    lp.coeFn_smul, Pi.smul_apply, smul_eq_mul, capFourierCoeff]

theorem actualPacketCoeff_norm {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume.restrict (packetFrequencyCube c r hr))) (ν : Fin d → ℤ) :
    ‖actualPacketCoeff c r hr f ν‖ = ‖mFourierCoeff (packetTorusInput c r hr f) ν‖ := by
  rw [actualPacketCoeff, norm_mul, packetCenterPhase_norm, one_mul]

/-- Exact coefficient energy, independent of the cap radius and center. -/
theorem actualPacketCoeff_energy {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume.restrict (packetFrequencyCube c r hr))) :
    (∑' ν, ‖actualPacketCoeff c r hr f ν‖ ^ 2) = (2 * Real.pi) ^ (-(d : ℝ)) * ‖f‖ ^ 2 := by
  simp_rw [actualPacketCoeff_norm, ← mFourierBasis_repr]
  rw [(hilbert_coefficient_energy mFourierBasis (packetTorusInput c r hr f)).tsum_eq,
    packetTorusInput_norm, mul_pow, ← Real.rpow_natCast,
    ← Real.rpow_mul (by positivity : 0 ≤ 2 * Real.pi)]
  congr 2
  push_cast
  ring

/-- The original coefficients are square summable, including every selected subfamily. -/
theorem actualPacketCoeff_summable {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume.restrict (packetFrequencyCube c r hr))) :
    Summable (fun ν => ‖actualPacketCoeff c r hr f ν‖ ^ 2) := by
  simpa only [actualPacketCoeff_norm, mFourierBasis_repr] using
    (hilbert_coefficient_energy mFourierBasis (packetTorusInput c r hr f)).summable

end N2Restriction
