import N2Restriction.GraphSlicePlancherel
import N2Restriction.GraphPatchInput

namespace N2Restriction
open MeasureTheory

namespace SurfaceGraphChart
variable {d : ℕ} (G : SurfaceGraphChart d)

/-- The original surface input has exactly the coordinate extension of its density-weighted pullback. -/
theorem coordinate_extension (g : Lp ℂ 2 G.surfaceMeasure) (y : Ambient (d + 1)) :
    extension G.surfaceMeasure id g y =
      extension volume G.parametrization (G.density.toCoordinate (G.pullInput g)) y := by
  have h := G.density.fromCoordinate_extension (G.density.toCoordinate (G.pullInput g))
    G.parametrization y
  rw [G.density.from_to] at h
  have he := G.lift_extension (G.pullInput g) y
  rw [G.lift_pull] at he
  exact he.trans h

/-- The density distortion is bounded by the already-constructed graph density. -/
theorem coordinate_energy (g : Lp ℂ 2 G.surfaceMeasure) :
    ‖G.density.toCoordinate (G.pullInput g)‖ ^ 2 ≤ G.density.upper * ‖g‖ ^ 2 := by
  simpa only [LinearIsometry.norm_map] using G.density.toCoordinate_energy (G.pullInput g)

/-- Slice Plancherel for actual Hausdorff surface inputs whose weighted coordinate representative
is smooth and compactly supported. The regularity condition is explicit. -/
theorem smooth_coordinate_slice_energy
    (hφ : ContDiff ℝ (⊤ : ℕ∞) G.phase) (g : Lp ℂ 2 G.surfaceMeasure)
    {f : Ambient d → ℂ} (hf : ContDiff ℝ (⊤ : ℕ∞) f) (hs : HasCompactSupport f)
    (he : G.density.toCoordinate (G.pullInput g) =ᵐ[volume] f) (t : ℝ) :
    (∫ u, ‖extension G.surfaceMeasure id g (graphPoint u t)‖ ^ 2) =
      (2 * Real.pi) ^ d * ‖G.density.toCoordinate (G.pullInput g)‖ ^ 2 := by
  have hext (u : Ambient d) : extension G.surfaceMeasure id g (graphPoint u t) =
      extension volume (fun x => graphPoint x (G.phase x)) f (graphPoint u t) := by
    rw [G.coordinate_extension]
    apply integral_congr_ae
    filter_upwards [he] with x hx
    rw [hx]
    rfl
  simp_rw [hext]
  rw [smooth_graph_slice_plancherel hφ hf hs, l2_norm_sq_eq_integral]
  congr 1
  exact integral_congr_ae (he.mono fun x hx => by dsimp only; rw [hx])

/-- A proved local Plancherel bound for smooth weighted coordinate representatives. -/
theorem smooth_coordinate_slice_bound
    (hφ : ContDiff ℝ (⊤ : ℕ∞) G.phase) (g : Lp ℂ 2 G.surfaceMeasure)
    {f : Ambient d → ℂ} (hf : ContDiff ℝ (⊤ : ℕ∞) f) (hs : HasCompactSupport f)
    (he : G.density.toCoordinate (G.pullInput g) =ᵐ[volume] f) (t : ℝ) :
    (∫ u, ‖extension G.surfaceMeasure id g (graphPoint u t)‖ ^ 2) ≤
      ((2 * Real.pi) ^ d * G.density.upper) * ‖g‖ ^ 2 := by
  rw [G.smooth_coordinate_slice_energy hφ g hf hs he t]
  exact (mul_le_mul_of_nonneg_left (G.coordinate_energy g) (by positivity)).trans_eq (by ring)

end SurfaceGraphChart
end N2Restriction
