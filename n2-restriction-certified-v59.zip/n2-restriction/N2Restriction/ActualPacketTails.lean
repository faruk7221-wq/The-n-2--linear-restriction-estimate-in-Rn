import N2Restriction.ActualPacketEnergy
import N2Restriction.LocalGraphTails

namespace N2Restriction
open MeasureTheory UnitAddTorus
noncomputable local instance actualTailCircleMeasure : MeasureSpace UnitAddCircle := ⟨AddCircle.haarAddCircle⟩

/-- Absolute convergence and selected tails for a locally smooth graph, with
one common cap-radius threshold valid for every decay order. -/
theorem local_smooth_graph_selected_packet_norm_tail {d : ℕ} {U : Set (Ambient d)} (hU : IsOpen U)
    {φ : Ambient d → ℝ} (hφ : ContDiffOn ℝ (⊤ : ℕ∞) φ U)
    (z : Ambient d) {a b : ℝ} (ha : 0 < a) (hab : a < b)
    (hball : Metric.closedBall z b ⊆ U) {Q : Set (Ambient d)} (hQ : IsCompact Q)
    (hcenter : Q ⊆ Metric.ball z (a / 2))
    {χ : Ambient d → ℂ} (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hs : HasCompactSupport χ) :
    ∃ r₀ : ℝ, 0 < r₀ ∧ ∀ M : ℕ, ∃ C : ℝ, 0 ≤ C ∧
      ∀ {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E],
      ∀ (b : HilbertBasis (Fin d → ℤ) ℂ E) (x : E) (c : Ambient d), c ∈ Q →
      ∀ (u : Ambient d) (r : ℝ), 0 < r → r ≤ r₀ →
      ∀ (t L : ℝ), |t * r ^ 2| ≤ 1 → 0 ≤ L →
      ∀ S : Set (Fin d → ℤ),
      (∀ ν ∈ S, L ≤ ‖latticeVector ν - (-(r • (u + t • graphGradient φ c)))‖) →
      Summable (fun ν : S => ‖b.repr x ν * graphPacket φ χ c r (r⁻¹ • latticeVector ν) u t‖) ∧
      (∑' ν : S, ‖b.repr x ν * graphPacket φ χ c r (r⁻¹ • latticeVector ν) u t‖) ≤
        r ^ ((d : ℝ) / 2) * (C / (1 + L) ^ M) * ‖x‖ := by
  obtain ⟨r₀, hr₀, hdecay⟩ := local_smooth_graph_packet_decay hU hφ z ha hab hball hQ hcenter hχ hs
  refine ⟨r₀, hr₀, fun M => ?_⟩
  obtain ⟨C, hC, hb⟩ := hdecay (d + M)
  refine ⟨C * (2 ^ d * ‖latticeWeight d‖), by positivity, ?_⟩
  intro E _ _ b x c hc u r hr hr1 t L ht hL S hS
  let a : Ambient d := -(r • (u + t • graphGradient φ c))
  let packet : (Fin d → ℤ) → ℂ := fun ν => b.repr x ν *
    graphPacket φ χ c r (r⁻¹ • latticeVector ν) u t
  have hC' : 0 ≤ r ^ ((d : ℝ) / 2) * C := by positivity
  have hp (ν : Fin d → ℤ) : ‖packet ν‖ ≤
      (r ^ ((d : ℝ) / 2) * C) * ‖b.repr x ν‖ /
        (1 + ‖latticeVector ν - a‖) ^ (d + M) := by
    have hd := hb c hc r hr hr1 (r⁻¹ • latticeVector ν) u t ht
    have he : r * ‖u + r⁻¹ • latticeVector ν + t • graphGradient φ c‖ =
        ‖latticeVector ν - a‖ := by
      have hh := congrArg norm (rescaled_packet_axis u (graphGradient φ c) t hr.ne' ν)
      simpa only [norm_smul, Real.norm_eq_abs, abs_of_pos hr, a] using hh
    rw [he] at hd
    change ‖b.repr x ν * _‖ ≤ _
    rw [norm_mul]
    exact (mul_le_mul_of_nonneg_left hd (norm_nonneg _)).trans_eq (by ring)
  have hsum := (radial_packet_norm_summable b x a packet hC' M hp).subtype S
  refine ⟨hsum, ?_⟩
  exact (radial_packet_absolute_tail b x a packet hC' hL M hp S hS).trans_eq (by ring)


/-- The center phase does not change the norm of an extended actual packet. -/
theorem actualPacketInput_extension_norm {d : ℕ} (φ : Ambient d → ℝ)
    (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume.restrict (packetFrequencyCube c r hr))) (ν : Fin d → ℤ)
    (u : Ambient d) (t : ℝ) :
    ‖extension volume (fun ξ => graphPoint ξ (φ ξ)) (actualPacketInput c r hr f ν) (graphPoint u t)‖ =
      ‖mFourierBasis.repr (packetTorusInput c r hr f) ν *
        graphPacket φ (packetCutoff d) c r (r⁻¹ • latticeVector ν) u t‖ := by
  rw [actualPacketInput_extension, norm_mul, actualPacketCoeff_norm, mFourierBasis_repr, norm_mul]

/-- Absolute selected tails for packets constructed from actual coordinate cap inputs.
The norm on the right is the original ordinary Lebesgue cap norm. -/
theorem actualPacketInput_selected_tail {d : ℕ} {U : Set (Ambient d)} (hU : IsOpen U)
    {φ : Ambient d → ℝ} (hφ : ContDiffOn ℝ (⊤ : ℕ∞) φ U)
    (z : Ambient d) {a b : ℝ} (ha : 0 < a) (hab : a < b)
    (hball : Metric.closedBall z b ⊆ U) {Q : Set (Ambient d)} (hQ : IsCompact Q)
    (hcenter : Q ⊆ Metric.ball z (a / 2)) :
    ∃ r₀ : ℝ, 0 < r₀ ∧ ∀ M : ℕ, ∃ C : ℝ, 0 ≤ C ∧
      ∀ (c : Ambient d), c ∈ Q → ∀ (r : ℝ) (hr : 0 < r), r ≤ r₀ →
      ∀ (f : Lp ℂ 2 (volume.restrict (packetFrequencyCube c r hr)))
      (u : Ambient d) (t L : ℝ), |t * r ^ 2| ≤ 1 → 0 ≤ L →
      ∀ S : Set (Fin d → ℤ),
      (∀ ν ∈ S, L ≤ ‖latticeVector ν - (-(r • (u + t • graphGradient φ c)))‖) →
      Summable (fun ν : S => ‖extension volume (fun ξ => graphPoint ξ (φ ξ))
        (actualPacketInput c r hr f ν) (graphPoint u t)‖) ∧
      (∑' ν : S, ‖extension volume (fun ξ => graphPoint ξ (φ ξ))
        (actualPacketInput c r hr f ν) (graphPoint u t)‖) ≤
        r ^ ((d : ℝ) / 2) * (C / (1 + L) ^ M) * ‖f‖ := by
  obtain ⟨r₀, hr₀, htail⟩ := local_smooth_graph_selected_packet_norm_tail hU hφ z ha hab hball
    hQ hcenter (packetCutoff_smooth d) (packetCutoff_compact d)
  refine ⟨r₀, hr₀, fun M => ?_⟩
  obtain ⟨C, hC, hb⟩ := htail M
  refine ⟨C * (2 * Real.pi) ^ (-(d : ℝ) / 2), by positivity, ?_⟩
  intro c hc r hr hr₀' f u t L ht hL S hS
  have h := hb mFourierBasis (packetTorusInput c r hr f) c hc u r hr hr₀' t L ht hL S hS
  simp_rw [actualPacketInput_extension_norm]
  refine ⟨h.1, h.2.trans_eq ?_⟩
  rw [packetTorusInput_norm]
  ring

/-- Arbitrary selected actual cap packets outside their round finite tubes have
rapid absolute tails in terms of the original cap input. -/
theorem actualPacketInput_rapid_tail {d : ℕ} {U : Set (Ambient d)} (hU : IsOpen U)
    {φ : Ambient d → ℝ} (hφ : ContDiffOn ℝ (⊤ : ℕ∞) φ U)
    (z : Ambient d) {a b₀ : ℝ} (ha : 0 < a) (hab : a < b₀)
    (hball : Metric.closedBall z b₀ ⊆ U) {Q : Set (Ambient d)} (hQ : IsCompact Q)
    (hcenter : Q ⊆ Metric.ball z (a / 2)) {τ : ℝ} (hτ : 0 < τ) :
    ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ b N : ℝ, ∃ C : ℝ, 0 ≤ C ∧ ∀ (R : ℝ), R₀ ≤ R →
      ∀ (c : Ambient d), c ∈ Q → ∀ (hr : 0 < R ^ (-1 / 2 : ℝ))
      (f : Lp ℂ 2 (volume.restrict (packetFrequencyCube c (R ^ (-1 / 2 : ℝ)) hr)))
      (u : Ambient d) (t : ℝ), |t| ≤ R → ∀ S : Set (Fin d → ℤ),
      (∀ ν ∈ S, R ^ (1 / 2 + τ) / 10 ≤ Metric.infDist (graphPoint u t)
        (packetSegment (graphGradient φ c) ((R ^ (-1 / 2 : ℝ))⁻¹ • latticeVector ν) R)) →
      R ^ b * (∑' ν : S, ‖extension volume (fun ξ => graphPoint ξ (φ ξ))
        (actualPacketInput c (R ^ (-1 / 2 : ℝ)) hr f ν) (graphPoint u t)‖) ≤ C * R ^ (-N) * ‖f‖ := by
  obtain ⟨R₀, hR₀, htail⟩ := local_smooth_graph_rapid_tail hU hφ z ha hab hball hQ hcenter
    (packetCutoff_smooth d) (packetCutoff_compact d) hτ
  refine ⟨R₀, hR₀, fun b N => ?_⟩
  obtain ⟨C, hC, hb⟩ := htail b N
  refine ⟨C * (2 * Real.pi) ^ (-(d : ℝ) / 2), by positivity, ?_⟩
  intro R hR c hc hr f u t ht S hS
  have h := hb R hR mFourierBasis (packetTorusInput c (R ^ (-1 / 2 : ℝ)) hr f) c hc u t ht S hS
  simp_rw [actualPacketInput_extension_norm]
  apply h.trans_eq
  rw [packetTorusInput_norm]
  ring

/-- Pointwise decay of the actual cap packets, with their actual coefficients.
The admissible cap radius is chosen before the decay order. -/
theorem actualPacketInput_pointwise_decay {d : ℕ} {U : Set (Ambient d)} (hU : IsOpen U)
    {φ : Ambient d → ℝ} (hφ : ContDiffOn ℝ (⊤ : ℕ∞) φ U)
    (z : Ambient d) {a b : ℝ} (ha : 0 < a) (hab : a < b)
    (hball : Metric.closedBall z b ⊆ U) {Q : Set (Ambient d)} (hQ : IsCompact Q)
    (hcenter : Q ⊆ Metric.ball z (a / 2)) :
    ∃ r₀ : ℝ, 0 < r₀ ∧ ∀ M : ℕ, ∃ C : ℝ, 0 ≤ C ∧
      ∀ (c : Ambient d), c ∈ Q → ∀ (r : ℝ) (hr : 0 < r), r ≤ r₀ →
      ∀ (f : Lp ℂ 2 (volume.restrict (packetFrequencyCube c r hr)))
      (ν : Fin d → ℤ) (u : Ambient d) (t : ℝ), |t * r ^ 2| ≤ 1 →
      ‖extension volume (fun ξ => graphPoint ξ (φ ξ))
        (actualPacketInput c r hr f ν) (graphPoint u t)‖ ≤
      ‖actualPacketCoeff c r hr f ν‖ * r ^ ((d : ℝ) / 2) *
        (C / (1 + r * ‖u + r⁻¹ • latticeVector ν + t • graphGradient φ c‖) ^ M) := by
  obtain ⟨r₀, hr₀, hdecay⟩ := local_smooth_graph_packet_decay hU hφ z ha hab hball
    hQ hcenter (packetCutoff_smooth d) (packetCutoff_compact d)
  refine ⟨r₀, hr₀, fun M => ?_⟩
  obtain ⟨C, hC, hb⟩ := hdecay M
  refine ⟨C, hC, ?_⟩
  intro c hc r hr hrr f ν u t ht
  rw [actualPacketInput_extension, norm_mul]
  exact (mul_le_mul_of_nonneg_left (hb c hc r hr hrr (r⁻¹ • latticeVector ν) u t ht)
    (norm_nonneg _)).trans_eq (by ring)

end N2Restriction
