import N2Restriction.SupportedExtensionSynthesis

namespace N2Restriction
open MeasureTheory Set Metric
namespace CoordinateCapFamily

/-- Every packet in a constructed family lies in one common bounded frequency region. -/
theorem packet_common_support {d : ℕ} {K : Set (Ambient d)} {r D : ℝ}
    (P : CoordinateCapFamily K r) (hr : 0 < r)
    (hK : ∀ x ∈ K, ‖x‖ ≤ D) (f : Lp ℂ 2 (volume : Measure (Ambient d)))
    (j : P.centers) (ν : Fin d → ℤ) :
    HasFrequencySupport volume id (closedBall (0 : Ambient d) (D + 2 * r)) (P.packet hr f j ν) := by
  apply (P.packet_frequency_support hr f j ν).mono
  intro x hx
  have hc := hK j.val (P.centers_mem j.property)
  have hh : dist x j.val < 2 * r := hx
  have ht := norm_add_le (x - j.val) j.val
  rw [sub_add_cancel] at ht
  rw [dist_eq_norm] at hh
  change ‖x - 0‖ ≤ D + 2 * r
  rw [sub_zero]
  linarith

/-- The complete constructed coordinate packet expansion reconstructs the actual
Fourier extension uniformly on all physical space. -/
theorem packet_uniform_extension_reconstruction {d n : ℕ} {K : Set (Ambient d)} {r : ℝ}
    (P : CoordinateCapFamily K r) (hK : IsCompact K) (hr : 0 < r)
    (f : Lp ℂ 2 (volume : Measure (Ambient d))) (hf : HasFrequencySupport volume id K f)
    (ζ : Ambient d → Ambient n) (hζ : Measurable ζ) :
    ∀ ε : ℝ, 0 < ε → ∀ᶠ F : Finset (P.centers × (Fin d → ℤ)) in Filter.atTop,
      ∀ x : Ambient n, dist (∑ p ∈ F, extension volume ζ (P.packet hr f p.1 p.2) x)
        (extension volume ζ f x) < ε := by
  obtain ⟨D, hD, hb⟩ := hK.isBounded.exists_pos_norm_le
  let B := closedBall (0 : Ambient d) (D + 2 * r)
  letI : IsFiniteMeasure (volume.restrict B) := ⟨by
    rw [Measure.restrict_apply_univ]
    exact measure_closedBall_lt_top⟩
  have hfB : HasFrequencySupport volume id B f := hf.mono (by
    intro x hx
    have hh := hb x hx
    change dist x 0 ≤ D + 2 * r
    rw [dist_zero_right]
    linarith)
  exact supported_extension_uniform volume B measurableSet_closedBall ζ hζ
    (fun p : P.centers × (Fin d → ℤ) => P.packet hr f p.1 p.2) f
    (fun p => P.packet_common_support hr hb f p.1 p.2) hfB (P.packet_hasSum_original hr f hf)

end CoordinateCapFamily
end N2Restriction
