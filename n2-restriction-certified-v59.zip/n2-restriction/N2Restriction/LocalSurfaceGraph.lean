import N2Restriction.SurfaceGraphTails

namespace N2Restriction
open MeasureTheory Set Metric

/-- A local smooth phase gives a constructed surface chart agreeing on a smaller ball. -/
theorem exists_local_surfaceGraphChart {d : ℕ} {U : Set (Ambient d)} (hU : IsOpen U)
    {φ : Ambient d → ℝ} (hφ : ContDiffOn ℝ (⊤ : ℕ∞) φ U)
    (z : Ambient d) {a b : ℝ} (ha : 0 < a) (hab : a < b)
    (hball : closedBall z b ⊆ U) :
    ∃ G : SurfaceGraphChart d, ContDiff ℝ (⊤ : ℕ∞) G.phase ∧
      EqOn G.phase φ (closedBall z a) := by
  obtain ⟨Φ, L, hs, _, hL, he⟩ := exists_smooth_lipschitz_graph_extension hU hφ z ha hab hball
  obtain ⟨G, hG⟩ := exists_surfaceGraphChart hL
  exact ⟨G, hG.symm ▸ hs, hG.symm ▸ he⟩

namespace SurfaceGraphChart
variable {d : ℕ} (G : SurfaceGraphChart d)

/-- Restriction to a graph patch is exactly its Hausdorff surface measure. -/
theorem surfaceMeasure_restrict_image (K : Set (Ambient d)) :
    G.surfaceMeasure.restrict (G.parametrization '' K) =
      (Measure.hausdorffMeasure (d : ℝ)).restrict (G.parametrization '' K) := by
  rw [G.surfaceMeasure_eq]
  exact Measure.restrict_restrict_of_subset (image_subset_range _ _)

/-- The auxiliary global extension induces exactly the original local graph's patch measure. -/
theorem surfaceMeasure_local_patch {φ : Ambient d → ℝ} {K : Set (Ambient d)}
    (he : EqOn G.phase φ K) :
    G.surfaceMeasure.restrict (G.parametrization '' K) =
      (Measure.hausdorffMeasure (d : ℝ)).restrict ((fun x => graphPoint x (φ x)) '' K) := by
  rw [G.surfaceMeasure_restrict_image]
  congr 1
  exact image_congr (fun x hx => by simp only [parametrization, he hx])

end SurfaceGraphChart
end N2Restriction
