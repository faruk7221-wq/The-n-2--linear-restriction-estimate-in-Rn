import N2Restriction.Exponents

/-! Quasi-Banach safe inequalities on the same positive function.
All integral inequalities use lower Lebesgue integrals in ENNReal, including
infinite values. No Banach-space interpolation is invoked. -/

namespace N2Restriction
open MeasureTheory
open scoped ENNReal NNReal BigOperators

/-- The scalar inequality behind (2.1). -/
lemma positive_sum_rpow_le {I : Type*} (s : Finset I) (f : I → ℝ≥0∞)
    {p : ℝ} (hp : 0 < p) (hp1 : p ≤ 1) :
    (∑ i ∈ s, f i) ^ p ≤ ∑ i ∈ s, (f i) ^ p := by
  classical
  induction s using Finset.induction_on with
  | empty => simp [ENNReal.zero_rpow_of_pos hp]
  | @insert i s hi ih =>
      simp only [Finset.sum_insert hi]
      exact (ENNReal.rpow_add_le_add_rpow _ _ hp.le hp1).trans (add_le_add_left ih _)

/-- Integral interpolation in power form. This avoids the technicalities of
finite norm extraction and applies directly to the selected positive Ftan. -/
theorem integral_interpolation {X : Type*} [MeasurableSpace X] (μ : Measure X)
    (F : X → ℝ≥0∞) (hF : AEMeasurable F μ)
    {a b p u v : ℝ} (ha0 : 0 ≤ a) (hb0 : 0 ≤ b) (hu : 0 < u) (hv : 0 < v) (huv : u + v = 1)
    (hp : p = a * u + b * v) :
    (∫⁻ x, F x ^ p ∂μ) ≤
      (∫⁻ x, F x ^ a ∂μ) ^ u * (∫⁻ x, F x ^ b ∂μ) ^ v := by
  have hu1 : u < 1 := by linarith
  have hconj : (1 / u).HolderConjugate (1 / v) := by
    simpa only [one_div] using Real.HolderConjugate.inv_inv hu hv huv
  have h := ENNReal.lintegral_mul_le_Lp_mul_Lq μ hconj
    (hF.pow_const (a * u)) (hF.pow_const (b * v))
  have ha : a * u * (1 / u) = a := by field_simp
  have hb : b * v * (1 / v) = b := by field_simp
  simp only [← ENNReal.rpow_mul, ha, hb, one_div_one_div] at h
  have hsplit : (fun x => F x ^ p) = fun x => F x ^ (a * u) * F x ^ (b * v) := by
    funext x
    rw [hp]
    exact ENNReal.rpow_add_of_nonneg _ _ (by positivity) (by positivity)
  rw [hsplit]
  exact h

/-- The critical tangential interpolation, specialized to the exponents of
(7.16), in integral form on the very same selected positive function. -/
theorem tangential_integral_interpolation {X : Type*} [MeasurableSpace X]
    (μ : Measure X) (F : X → ℝ≥0∞) (hF : AEMeasurable F μ)
    {k : ℝ} (hk : 1 < k) :
    (∫⁻ x, F x ^ critical k ∂μ) ≤
      (∫⁻ x, F x ^ baseline k ∂μ) ^ ((k - 1) / k) *
      (∫⁻ x, F x ^ lower k ∂μ) ^ (1 / k) := by
  have hk0 : 0 < k := by linarith
  have hkm : 0 < k - 1 := by linarith
  apply integral_interpolation μ F hF
  · unfold baseline; positivity
  · unfold lower; positivity
  · exact div_pos (by linarith) (by linarith)
  · positivity
  · field_simp; ring
  · unfold critical baseline lower
    field_simp [ne_of_gt hk0, ne_of_gt hkm]

/-- Positive Lp quasi-norm, including p<1 and infinite values. -/
noncomputable def positiveNorm {X : Type*} [MeasurableSpace X]
    (F : X → ℝ≥0∞) (p : ℝ) (μ : Measure X) : ℝ≥0∞ :=
  (∫⁻ x, F x ^ p ∂μ) ^ (1 / p)

/-- The quasi-norm version of (7.17), with no finiteness assumptions and
with both endpoint bounds on the same selected positive function. -/
theorem tangential_norm_interpolation {X : Type*} [MeasurableSpace X]
    (μ : Measure X) (F : X → ℝ≥0∞) (hF : AEMeasurable F μ)
    {k : ℝ} (hk : 1 < k) :
    positiveNorm F (critical k) μ ≤
      positiveNorm F (baseline k) μ ^ theta k *
      positiveNorm F (lower k) μ ^ (1 - theta k) := by
  have hk0 : 0 < k := by linarith
  have hkm : 0 < k - 1 := by linarith
  have hkp : 0 < k + 1 := by linarith
  have he1 : ((k - 1) / k) * (1 / critical k) = (1 / baseline k) * theta k := by
    unfold critical baseline theta
    field_simp [ne_of_gt hk0, ne_of_gt hkm, ne_of_gt hkp]
  have he2 : (1 / k) * (1 / critical k) = (1 / lower k) * (1 - theta k) := by
    unfold critical lower theta
    field_simp [ne_of_gt hk0, ne_of_gt hkp]
    ring
  have h := ENNReal.rpow_le_rpow (tangential_integral_interpolation μ F hF hk)
    (show 0 ≤ 1 / critical k by exact le_of_lt (one_div_pos.mpr (critical_pos hk0)))
  simpa only [positiveNorm, ENNReal.mul_rpow_of_nonneg _ _
    (show 0 ≤ 1 / critical k by exact le_of_lt (one_div_pos.mpr (critical_pos hk0))),
    ← ENNReal.rpow_mul, he1, he2] using h

/-- Insert the two selected-input endpoint estimates into critical interpolation. -/
theorem tangential_norm_bound {X : Type*} [MeasurableSpace X]
    (μ : Measure X) (F : X → ℝ≥0∞) (hF : AEMeasurable F μ)
    {k : ℝ} (hk : 1 < k) {M₀ M₁ : ℝ≥0∞}
    (h₀ : positiveNorm F (baseline k) μ ≤ M₀)
    (h₁ : positiveNorm F (lower k) μ ≤ M₁) :
    positiveNorm F (critical k) μ ≤ M₀ ^ theta k * M₁ ^ (1 - theta k) := by
  obtain ⟨hθ, hθ1⟩ := theta_range (show 0 < k by linarith)
  exact (tangential_norm_interpolation μ F hF hk).trans
    (mul_le_mul' (ENNReal.rpow_le_rpow h₀ hθ.le)
      (ENNReal.rpow_le_rpow h₁ (by linarith)))

/-- Finite-volume Hölder, as used at the end of Section 8. -/
theorem finite_volume_comparison {X E : Type*} [MeasurableSpace X]
    [NormedAddCommGroup E] (μ : Measure X) (F : X → E)
    (hF : AEStronglyMeasurable F μ) {q p : ℝ} (hq : 0 < q) (hqp : q ≤ p) :
    eLpNorm' F q μ ≤ eLpNorm' F p μ * (μ Set.univ) ^ (1 / q - 1 / p) :=
  eLpNorm'_le_eLpNorm'_mul_rpow_measure_univ hq hqp hF

/-- Raising the exponent on a pointwise bounded nonnegative function.
This is the integral step following (7.17). -/
theorem raise_exponent {X : Type*} [MeasurableSpace X] (μ : Measure X)
    (F : X → ℝ≥0∞) (hF : AEMeasurable F μ) {M : ℝ≥0∞} {q p : ℝ}
    (hq : 0 ≤ q) (hqp : q < p) (hM : ∀ x, F x ≤ M) :
    (∫⁻ x, F x ^ p ∂μ) ≤ M ^ (p - q) * ∫⁻ x, F x ^ q ∂μ := by
  have he : p = (p - q) + q := by ring
  calc
    (∫⁻ x, F x ^ p ∂μ) ≤ ∫⁻ x, M ^ (p - q) * F x ^ q ∂μ := by
      apply lintegral_mono
      intro x
      change F x ^ p ≤ M ^ (p - q) * F x ^ q
      calc
        F x ^ p = F x ^ (p - q) * F x ^ q := by
          rw [← ENNReal.rpow_add_of_nonneg _ _ (by linarith) hq, ← he]
        _ ≤ M ^ (p - q) * F x ^ q :=
          mul_le_mul_right' (ENNReal.rpow_le_rpow (hM x) (by linarith)) _
    _ = M ^ (p - q) * ∫⁻ x, F x ^ q ∂μ :=
      lintegral_const_mul'' _ (hF.pow_const q)

end N2Restriction
