import N2Restriction.PacketTails
import Mathlib.Analysis.PSeries
import Mathlib.Analysis.Normed.Ring.InfiniteSum

namespace N2Restriction
open scoped BigOperators ENNReal

/-- Summability of products over the full integer lattice, proved by dimension induction. -/
theorem lattice_product_summable (d : ℕ) (f : Fin d → ℤ → ℝ)
    (hf : ∀ j, Summable (f j)) (hpos : ∀ j n, 0 ≤ f j n) :
    Summable (fun ν : Fin d → ℤ => ∏ j, f j (ν j)) := by
  induction d with
  | zero => exact (hasSum_fintype _).summable
  | succ d ih =>
    have ht := (hf 0).mul_of_nonneg
      (ih (fun j => f j.succ) (fun j => hf j.succ) (fun j => hpos j.succ))
      (hpos 0) (fun ν => Finset.prod_nonneg (fun j _ => hpos j.succ (ν j)))
    have hc := ht.comp_injective (Fin.consEquiv (fun _ : Fin (d + 1) => ℤ)).symm.injective
    simpa only [Fin.consEquiv, Equiv.coe_fn_symm_mk, Fin.prod_univ_succ, Fin.tail] using hc

/-- A concrete square-summable one-dimensional polynomial weight. -/
theorem integer_weight_square_summable :
    Summable (fun n : ℤ => ((1 + |(n : ℝ)|)⁻¹) ^ 2) := by
  have hn : Summable (fun n : ℕ => (1 / ((n : ℝ) + 1) ^ 2)) := by
    have h := (summable_nat_add_iff 1).mpr
      (Real.summable_one_div_nat_pow.mpr (by norm_num : 1 < (2 : ℕ)))
    simpa only [Nat.cast_add, Nat.cast_one] using h
  apply Summable.of_nat_of_neg
  · simpa [abs_of_nonneg (Nat.cast_nonneg _ : (0 : ℝ) ≤ _), inv_pow, one_div, add_comm] using hn
  · simpa [abs_of_nonneg (Nat.cast_nonneg _ : (0 : ℝ) ≤ _), inv_pow, one_div, add_comm] using hn

/-- Product polynomial weight on the packet frequency lattice. -/
noncomputable def latticeDecay {d : ℕ} (ν : Fin d → ℤ) : ℝ :=
  ∏ j, (1 + |(ν j : ℝ)|)⁻¹

lemma latticeDecay_nonneg {d : ℕ} (ν : Fin d → ℤ) : 0 ≤ latticeDecay ν := by
  exact Finset.prod_nonneg (fun _ _ => by positivity)

theorem latticeDecay_square_summable (d : ℕ) :
    Summable (fun ν : Fin d → ℤ => latticeDecay ν ^ 2) := by
  have h := lattice_product_summable d (fun _ n => ((1 + |(n : ℝ)|)⁻¹) ^ 2)
    (fun _ => integer_weight_square_summable) (fun _ _ => sq_nonneg _)
  simpa only [latticeDecay, Finset.prod_pow] using h

/-- The explicit l2 weight can be supplied directly to the absolute packet-tail lemmas. -/
noncomputable def latticeWeight (d : ℕ) : lp (fun _ : Fin d → ℤ => ℂ) 2 :=
  ⟨fun ν => (latticeDecay ν : ℂ), memℓp_gen (by
    simpa only [ENNReal.toReal_ofNat, Real.rpow_two, Complex.norm_real,
      Real.norm_eq_abs, abs_of_nonneg (latticeDecay_nonneg _)] using latticeDecay_square_summable d)⟩

/-- Concrete polynomial domination suffices for uniform absolute bounds on all packet selections. -/
theorem lattice_packet_absolute_tail {d : ℕ} {E F : Type*}
    [NormedAddCommGroup E] [InnerProductSpace ℂ E] [NormedAddCommGroup F]
    (b : HilbertBasis (Fin d → ℤ) ℂ E) (x : E) (r : (Fin d → ℤ) → F)
    {δ : ℝ} (hδ : 0 ≤ δ)
    (hr : ∀ ν, ‖r ν‖ ≤ δ * (‖b.repr x ν‖ * latticeDecay ν)) (S : Set (Fin d → ℤ)) :
    (∑' ν : S, ‖r ν‖) ≤ δ * ‖x‖ * ‖latticeWeight d‖ := by
  apply packet_error_absolute_tail b x (latticeWeight d) r hδ
  intro ν
  change ‖r ν‖ ≤ δ * (‖b.repr x ν‖ * ‖(latticeDecay ν : ℂ)‖)
  simpa only [Complex.norm_real, Real.norm_eq_abs,
    abs_of_nonneg (latticeDecay_nonneg _)] using hr ν

end N2Restriction
