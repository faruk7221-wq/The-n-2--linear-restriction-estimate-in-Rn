import N2Restriction.GraphSurfaceDensity
import N2Restriction.LocalGraphPackets
import Mathlib.Analysis.Calculus.ContDiff.RCLike

namespace N2Restriction
open MeasureTheory Set Metric
open scoped NNReal ENNReal

/-- The local graph extension can be chosen compactly supported and Lipschitz.
This supplies the global graph measure construction without an added hypothesis. -/
theorem exists_smooth_lipschitz_graph_extension {d : ℕ} {U : Set (Ambient d)} (hU : IsOpen U)
    {φ : Ambient d → ℝ} (hφ : ContDiffOn ℝ (⊤ : ℕ∞) φ U)
    (z : Ambient d) {a b : ℝ} (ha : 0 < a) (hab : a < b)
    (hball : closedBall z b ⊆ U) :
    ∃ Φ : Ambient d → ℝ, ∃ L : ℝ≥0, ContDiff ℝ (⊤ : ℕ∞) Φ ∧
      HasCompactSupport Φ ∧ LipschitzWith L Φ ∧ EqOn Φ φ (closedBall z a) := by
  let β : ContDiffBump z := ⟨a, b, ha, hab⟩
  let Φ : Ambient d → ℝ := fun x => β x * φ x
  have hs : ContDiff ℝ (⊤ : ℕ∞) Φ := smooth_local_cutoff_product hU hφ β.contDiff
    (by simpa only [β.tsupport_eq] using hball)
  have hc : HasCompactSupport Φ := β.hasCompactSupport.mul_right
  obtain ⟨L, hL⟩ := ContDiff.lipschitzWith_of_hasCompactSupport hc hs (by simp)
  refine ⟨Φ, L, hs, hc, hL, ?_⟩
  intro x hx
  change β x * φ x = φ x
  rw [β.one_of_mem_closedBall hx, one_mul]

/-- A local smooth phase has an extended graph whose actual Hausdorff measure
is represented by a positive bounded coordinate density. -/
theorem local_graph_surface_density {d : ℕ} {U : Set (Ambient d)} (hU : IsOpen U)
    {φ : Ambient d → ℝ} (hφ : ContDiffOn ℝ (⊤ : ℕ∞) φ U)
    (z : Ambient d) {a b : ℝ} (ha : 0 < a) (hab : a < b)
    (hball : closedBall z b ⊆ U) :
    ∃ Φ : Ambient d → ℝ, ∃ L : ℝ≥0, ∃ J : Ambient d → ℝ≥0,
      ContDiff ℝ (⊤ : ℕ∞) Φ ∧ LipschitzWith L Φ ∧ EqOn Φ φ (closedBall z a) ∧
      Measurable J ∧
      (∀ᵐ x ∂volume, coordinateHausdorffFactor d ≤ J x ∧
        J x ≤ (1 + L) ^ d * coordinateHausdorffFactor d) ∧
      (volume.withDensity (fun x => (J x : ℝ≥0∞))).map (fun x => graphPoint x (Φ x)) =
        (Measure.hausdorffMeasure (d : ℝ)).restrict (range (fun x => graphPoint x (Φ x))) := by
  obtain ⟨Φ, L, hs, _, hL, he⟩ := exists_smooth_lipschitz_graph_extension hU hφ z ha hab hball
  obtain ⟨J, hJ, hb, hmap⟩ := exists_lipschitz_graph_density hL
  exact ⟨Φ, L, J, hs, hL, he, hJ, hb, hmap⟩

end N2Restriction
