import N2Restriction.NormalTransversality

namespace N2Restriction

/-- The combined level-set constraints defining a thin-support zero set.
The first component restricts to the hypersurface, and the second kills the
projection of the normal. -/
noncomputable def thinConstraint {n : ℕ} (S : SmoothPatch n) (W : Submodule ℝ (Ambient n))
    (y : Ambient n) : ℝ × W := (S.defining y, W.orthogonalProjection (S.normal y))

noncomputable def thinDifferential {n : ℕ} (S : SmoothPatch n)
    (W : Submodule ℝ (Ambient n)) (z : Ambient n) : Ambient n →L[ℝ] ℝ × W :=
  (fderiv ℝ S.defining z).prod (W.orthogonalProjection.comp (fderiv ℝ S.normal z))

lemma hasFDerivAt_thinConstraint {n : ℕ} (S : SmoothPatch n)
    (W : Submodule ℝ (Ambient n)) {z : Ambient n} (hz : z ∈ S.neighborhood) :
    HasFDerivAt (thinConstraint S W) (thinDifferential S W z) z := by
  have hd := (S.smooth_defining.differentiableOn (by simp)).differentiableAt
    (S.open_neighborhood.mem_nhds hz)
  have hn := (S.smooth_normal.differentiableOn (by simp)).differentiableAt
    (S.open_neighborhood.mem_nhds hz)
  exact hd.hasFDerivAt.prodMk (W.orthogonalProjection.hasFDerivAt.comp z hn.hasFDerivAt)

/-- Surjectivity of the three combined constraints at the unperturbed common
tangent plane. This is the differential hypothesis for the local implicit
function theorem in Lemma 4.1, on the hypersurface rather than just in ambient
space. No uniform chart or distance estimate is asserted here. -/
theorem thinDifferential_surjective {n : ℕ} (S : SmoothPatch n)
    (W : Submodule ℝ (Ambient n)) {z : Ambient n} (hz : z ∈ S.neighborhood)
    (hW : ∀ v : W, inner ℝ (S.normal z) (v : Ambient n) = 0)
    {κ : ℝ} (hκ : 0 < κ)
    (hA : ∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (S.shape z v)‖) :
    Function.Surjective (thinDifferential S W z) := by
  obtain ⟨J, hJ, _, _⟩ := projected_shape_inverse W (S.shape z) hκ hA
  have hsolve (w : W) : W.orthogonalProjection (S.shape z (J w)) = w :=
    congrArg (fun L : W →L[ℝ] W => L w) hJ
  have hnsolve (w : W) : W.orthogonalProjection (fderiv ℝ S.normal z (J w)) = -w := by
    have h := hsolve w
    change W.orthogonalProjection (-(fderiv ℝ S.normal z (J w))) = w at h
    rw [map_neg] at h
    exact neg_eq_iff_eq_neg.mp h
  intro t
  let u : Ambient n := (t.1 / S.normalScale z) • S.normal z
  let v : W := J (W.orthogonalProjection (fderiv ℝ S.normal z u) - t.2)
  refine ⟨u + v, ?_⟩
  apply Prod.ext
  · change fderiv ℝ S.defining z (u + v) = t.1
    rw [map_add, S.normal_differential z hz (v : Ambient n), hW v, mul_zero, add_zero]
    rw [S.normal_differential z hz u]
    dsimp [u]
    rw [inner_smul_right, real_inner_self_eq_norm_sq, S.normal_unit z hz]
    field_simp [ne_of_gt (S.positive_normalScale z hz)]
  · change W.orthogonalProjection (fderiv ℝ S.normal z (u + v)) = t.2
    rw [map_add, map_add]
    dsimp only [v]
    rw [hnsolve]
    abel

/-- The actual geometric hypotheses imply the required submersion property. -/
theorem geometric_thinDifferential_surjective {k : ℕ} (S : Fin k → SmoothPatch (k + 2))
    {ν κ : ℝ} (hgeo : GeometricHypotheses S ν κ)
    (z : Fin k → Ambient (k + 2)) (hz : ∀ i, z i ∈ (S i).extendedSurface) (i : Fin k) :
    Function.Surjective
      (thinDifferential (S i) (commonTangent (fun j => (S j).normal (z j))) (z i)) := by
  apply thinDifferential_surjective (S i) _ (hz i).1
    (fun v => commonTangent_orthogonal (fun j => (S j).normal (z j)) v i)
    hgeo.2.1
  exact (hgeo.2.2 z hz).2 i

/-- The kernel of the combined differential has the article's dimension n-3.
This is the tangent-space dimension required for the thin-support level set;
constructing uniform nonlinear charts remains a separate task. -/
theorem thinDifferential_kernel_dimension {k : ℕ} (S : Fin k → SmoothPatch (k + 2))
    {ν κ : ℝ} (hgeo : GeometricHypotheses S ν κ)
    (z : Fin k → Ambient (k + 2)) (hz : ∀ i, z i ∈ (S i).extendedSurface) (i : Fin k) :
    Module.finrank ℝ (LinearMap.ker
      (thinDifferential (S i) (commonTangent (fun j => (S j).normal (z j))) (z i)).toLinearMap) = k - 1 := by
  let W := commonTangent (fun j => (S j).normal (z j))
  let L := thinDifferential (S i) W (z i)
  have hrange : LinearMap.range L.toLinearMap = ⊤ :=
    LinearMap.range_eq_top.mpr (geometric_thinDifferential_surjective S hgeo z hz i)
  have hdim := L.toLinearMap.finrank_range_add_finrank_ker
  rw [hrange] at hdim
  have hW : Module.finrank ℝ W = 2 := geometric_commonTangent_two S hgeo z hz
  simp only [finrank_top, Module.finrank_prod, Module.finrank_self, hW,
    Ambient, finrank_euclideanSpace, Fintype.card_fin] at hdim
  change Module.finrank ℝ (LinearMap.ker L.toLinearMap) = k - 1
  have he : 3 + Module.finrank ℝ (LinearMap.ker L.toLinearMap) = k + 2 := hdim
  omega

end N2Restriction
