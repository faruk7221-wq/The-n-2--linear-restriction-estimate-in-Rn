import N2Restriction.PartitionPackets

namespace N2Restriction
open MeasureTheory Set

/-- Concrete coordinate cap data. All coverage, support and overlap properties
are proved for the constructed family, rather than supplied to the packet estimates. -/
structure CoordinateCapFamily {d : ℕ} (K : Set (Ambient d)) (r : ℝ) where
  centers : Finset (Ambient d)
  partition : PartitionOfUnity centers (Ambient d) K
  centers_mem : (↑centers : Set (Ambient d)) ⊆ K
  smooth : ∀ j, ContDiff ℝ (⊤ : ℕ∞) (partition j)
  support : ∀ j, Function.support (partition j) ⊆ Metric.ball (j : Ambient d) r
  overlap : ∀ x, (∑ j : centers, (Metric.ball (j : Ambient d) (2 * r)).indicator
    (fun _ => (1 : ℝ)) x) ≤ 9 ^ d

/-- Constructed families have one count constant valid at every small radius. -/
theorem exists_coordinate_cap_families {d : ℕ} {K : Set (Ambient d)} (hK : IsCompact K) :
    ∃ A : ℝ, 0 ≤ A ∧ ∀ r : ℝ, 0 < r → r ≤ 1 →
      ∃ P : CoordinateCapFamily K r, (P.centers.card : ℝ) ≤ A * r ^ (-(d : ℝ)) := by
  obtain ⟨D, hD, hb⟩ := hK.isBounded.exists_pos_norm_le
  refine ⟨(4 * D + 1) ^ d, by positivity, ?_⟩
  intro r hr hr1
  obtain ⟨t, ρ, htK, hcount, hover, hsmooth, hsupp, _⟩ :=
    quantitative_cap_partition hK (0 : Ambient d) hD.le (by simpa only [dist_zero_right] using hb) hr hr1
  exact ⟨⟨t, ρ, htK, hsmooth, hsupp, hover⟩, hcount⟩

namespace CoordinateCapFamily

noncomputable def input {d : ℕ} {K : Set (Ambient d)} {r : ℝ}
    (P : CoordinateCapFamily K r) (hr : 0 < r) (f : Lp ℂ 2 (volume : Measure (Ambient d)))
    (j : P.centers) : Lp ℂ 2 (volume.restrict (packetFrequencyCube (j : Ambient d) r hr)) :=
  partitionCapInput P.partition (fun j => j.val) r hr f j

noncomputable def packet {d : ℕ} {K : Set (Ambient d)} {r : ℝ}
    (P : CoordinateCapFamily K r) (hr : 0 < r) (f : Lp ℂ 2 (volume : Measure (Ambient d)))
    (j : P.centers) (ν : Fin d → ℤ) : Lp ℂ 2 (volume : Measure (Ambient d)) :=
  partitionPacket P.partition (fun j => j.val) r hr f j ν

theorem input_energy {d : ℕ} {K : Set (Ambient d)} {r : ℝ}
    (P : CoordinateCapFamily K r) (hr : 0 < r) (f : Lp ℂ 2 (volume : Measure (Ambient d))) :
    (∑ j, ‖P.input hr f j‖ ^ 2) ≤ ‖f‖ ^ 2 :=
  partitionCapInput_energy P.partition _ r hr P.support f

theorem packet_hasSum {d : ℕ} {K : Set (Ambient d)} {r : ℝ}
    (P : CoordinateCapFamily K r) (hr : 0 < r) (f : Lp ℂ 2 (volume : Measure (Ambient d)))
    (j : P.centers) : HasSum (P.packet hr f j) (partitionL2Piece P.partition f j) :=
  partitionPacket_hasSum P.partition _ r hr P.support f j

theorem packet_reconstruction {d : ℕ} {K : Set (Ambient d)} {r : ℝ}
    (P : CoordinateCapFamily K r) (hr : 0 < r) (f : Lp ℂ 2 (volume : Measure (Ambient d)))
    (hf : HasFrequencySupport volume id K f) : (∑ j, ∑' ν, P.packet hr f j ν) = f :=
  partitionPacket_reconstruction P.partition _ r hr P.support f hf

theorem packet_total_energy {d : ℕ} {K : Set (Ambient d)} {r : ℝ}
    (P : CoordinateCapFamily K r) (hr : 0 < r) (f : Lp ℂ 2 (volume : Measure (Ambient d))) :
    (∑ j, ∑' ν, ‖P.packet hr f j ν‖ ^ 2) ≤
      packetCutoffEnergy d * (2 * Real.pi) ^ (-(d : ℝ)) * ‖f‖ ^ 2 :=
  partitionPacket_total_energy P.partition _ r hr P.support f

/-- The overlap constant is now supplied by the constructed geometry. -/
theorem packet_selected_energy {d : ℕ} {K : Set (Ambient d)} {r : ℝ}
    (P : CoordinateCapFamily K r) (hr : 0 < r) (f : Lp ℂ 2 (volume : Measure (Ambient d)))
    (S : P.centers → Set (Fin d → ℤ)) :
    packetCutoffEnergy d * ‖∑ j, ∑' ν : S j, P.packet hr f j ν‖ ^ 2 ≤
      9 ^ d * (2 * Real.pi) ^ d * ∑ j, ∑' ν : S j, ‖P.packet hr f j ν‖ ^ 2 :=
  partitionPacket_selected_energy P.partition _ r hr f S (by positivity)
    (Filter.Eventually.of_forall P.overlap)

theorem packet_frequency_support {d : ℕ} {K : Set (Ambient d)} {r : ℝ}
    (P : CoordinateCapFamily K r) (hr : 0 < r) (f : Lp ℂ 2 (volume : Measure (Ambient d)))
    (j : P.centers) (ν : Fin d → ℤ) :
    HasFrequencySupport volume id (Metric.ball (j : Ambient d) (2 * r)) (P.packet hr f j ν) :=
  partitionPacket_support P.partition _ r hr f j ν

end CoordinateCapFamily
end N2Restriction
