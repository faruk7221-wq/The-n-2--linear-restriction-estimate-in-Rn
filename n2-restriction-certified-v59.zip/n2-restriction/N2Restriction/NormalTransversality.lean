import N2Restriction.CurvatureInverse

namespace N2Restriction

/-- Quantitative ambient decomposition behind the normal-space transversality
argument. The component in W is controlled by the reciprocal curvature bound. -/
theorem shape_decomposition {E : Type*} [NormedAddCommGroup E]
    [InnerProductSpace ℝ E] [FiniteDimensional ℝ E] (W : Submodule ℝ E)
    (A : E →L[ℝ] E) {κ : ℝ} (hκ : 0 < κ)
    (hA : ∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (A v)‖) (x : E) :
    ∃ v : W, x - A v ∈ Wᗮ ∧ ‖v‖ ≤ κ⁻¹ * ‖x‖ := by
  obtain ⟨B, hright, _, hB⟩ := projected_shape_inverse W A hκ hA
  let v := B (W.orthogonalProjection x)
  have hproj : W.orthogonalProjection (A v) = W.orthogonalProjection x := by
    exact congrArg (fun L : W →L[ℝ] W => L (W.orthogonalProjection x)) hright
  refine ⟨v, ?_, ?_⟩
  · apply Submodule.orthogonalProjection_eq_zero_iff.mp
    rw [map_sub, hproj, sub_self]
  · calc
      ‖v‖ ≤ ‖B‖ * ‖W.orthogonalProjection x‖ := B.le_opNorm _
      _ ≤ κ⁻¹ * ‖x‖ := mul_le_mul hB (W.norm_orthogonalProjection_apply_le x)
        (norm_nonneg _) (inv_nonneg.mpr hκ.le)

/-- No nonzero shape image of W lies in the orthogonal complement of W. -/
lemma shape_image_disjoint {E : Type*} [NormedAddCommGroup E]
    [InnerProductSpace ℝ E] [FiniteDimensional ℝ E] (W : Submodule ℝ E)
    (A : E →L[ℝ] E) {κ : ℝ} (hκ : 0 < κ)
    (hA : ∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (A v)‖) :
    Disjoint Wᗮ (W.map A.toLinearMap) := by
  rw [Submodule.disjoint_def]
  intro x hx hxA
  obtain ⟨v, hv, hAv⟩ := Submodule.mem_map.mp hxA
  change A v = x at hAv
  have hzero : W.orthogonalProjection (A v) = 0 := by
    rw [hAv]
    exact Submodule.orthogonalProjection_eq_zero_iff.mpr hx
  have h := hA ⟨v, hv⟩
  change κ * ‖v‖ ≤ ‖W.orthogonalProjection (A v)‖ at h
  rw [hzero, norm_zero] at h
  have hv0 : v = 0 := norm_eq_zero.mp (by nlinarith [norm_nonneg v])
  simpa [hv0] using hAv.symm

/-- The original normals and the shape images of the common tangent span the
whole ambient space. This is the unperturbed linear-algebra content of (4.2). -/
theorem shape_image_spans {E : Type*} [NormedAddCommGroup E]
    [InnerProductSpace ℝ E] [FiniteDimensional ℝ E] (W : Submodule ℝ E)
    (A : E →L[ℝ] E) {κ : ℝ} (hκ : 0 < κ)
    (hA : ∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (A v)‖) :
    Wᗮ ⊔ W.map A.toLinearMap = ⊤ := by
  apply top_unique
  intro x _
  obtain ⟨v, hv, _⟩ := shape_decomposition W A hκ hA x
  exact Submodule.mem_sup.mpr
    ⟨x - A v, hv, A v, Submodule.mem_map.mpr ⟨v, v.property, rfl⟩, sub_add_cancel _ _⟩

/-- Application to the article's actual differentiated normals. This proves
spanning and disjointness at H=W; perturbation to nearby H and a uniform wedge
lower bound are separate remaining obligations. -/
theorem geometric_normal_transversality {k : ℕ} (S : Fin k → SmoothPatch (k + 2))
    {ν κ : ℝ} (hgeo : GeometricHypotheses S ν κ)
    (z : Fin k → Ambient (k + 2)) (hz : ∀ i, z i ∈ (S i).extendedSurface) (i : Fin k) :
    let N : Fin k → Ambient (k + 2) := fun j => (S j).normal (z j)
    let V := Submodule.span ℝ (Set.range N)
    let W := commonTangent N
    Disjoint V (W.map ((S i).shape (z i)).toLinearMap) ∧
      V ⊔ W.map ((S i).shape (z i)).toLinearMap = ⊤ := by
  dsimp only
  have hA := (hgeo.2.2 z hz).2 i
  constructor
  · simpa [commonTangent] using shape_image_disjoint _ _ hgeo.2.1 hA
  · simpa [commonTangent] using shape_image_spans _ _ hgeo.2.1 hA

end N2Restriction
