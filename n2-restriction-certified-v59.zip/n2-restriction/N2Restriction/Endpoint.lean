import N2Restriction.Exponents

namespace N2Restriction

/-- Select the strict exponent in the final finite-volume Hölder argument.
The estimate is quantitative; no assertion at a global endpoint is made. -/
theorem exists_strict_exponent {q q₀ ε n : ℝ}
    (hq : 0 < q) (hqq : q < q₀) (hε : 0 < ε) (hn : 0 < n) :
    ∃ p : ℝ, q < p ∧ p < q₀ ∧ n * (1 / q - 1 / p) < ε / 2 := by
  let δ := min ((q₀ - q) / 2) (ε * q ^ 2 / (4 * n))
  have hδ : 0 < δ := lt_min (by linarith) (by positivity)
  have hδ1 : δ ≤ (q₀ - q) / 2 := min_le_left _ _
  have hδ2 : δ ≤ ε * q ^ 2 / (4 * n) := min_le_right _ _
  have hp : 0 < q + δ := by linarith
  refine ⟨q + δ, by linarith, by linarith, ?_⟩
  have hid : n * (1 / q - 1 / (q + δ)) = n * δ / (q * (q + δ)) := by
    field_simp
    ring
  rw [hid, div_lt_iff₀ (mul_pos hq hp)]
  have hsmall : 4 * n * δ ≤ ε * q ^ 2 := by
    have := (le_div_iff₀ (show 0 < 4 * n by positivity)).mp hδ2
    nlinarith
  have : 0 < ε * q * δ := by positivity
  nlinarith [sq_pos_of_pos hq]

lemma exists_p_near_critical {k ε n : ℝ}
    (hk : 3 ≤ k) (hε : 0 < ε) (hn : 0 < n) :
    ∃ p : ℝ, critical k < p ∧ p < baseline k ∧
      n * (1 / critical k - 1 / p) < ε / 2 :=
  exists_strict_exponent (critical_pos (by linarith))
    (critical_lt_baseline (by linarith)) hε hn


/-- Abstract endpoint passage at the end of Section 8. The finite-volume
comparison is an explicit hypothesis; the choice of p and control of all
losses are proved here. -/
theorem endpoint_from_strict_range (A : ℝ → ℝ → ℝ) {q q₀ n : ℝ}
    (hq : 0 < q) (hqq : q < q₀) (hn : 0 < n)
    (hstrict : ∀ p : ℝ, q < p → p < q₀ → ∀ δ : ℝ, 0 < δ →
      ∃ C : ℝ, 0 ≤ C ∧ ∀ R : ℝ, 1 ≤ R → A p R ≤ C * R ^ δ)
    (hvolume : ∀ p : ℝ, q < p → p < q₀ → ∀ R : ℝ, 1 ≤ R →
      A q R ≤ R ^ (n * (1 / q - 1 / p)) * A p R) :
    ∀ ε : ℝ, 0 < ε → ∃ C : ℝ, 0 ≤ C ∧ ∀ R : ℝ, 1 ≤ R → A q R ≤ C * R ^ ε := by
  intro ε hε
  obtain ⟨p, hqp, hpq₀, hgap⟩ := exists_strict_exponent hq hqq hε hn
  obtain ⟨C, hC, hCR⟩ := hstrict p hqp hpq₀ (ε / 2) (by positivity)
  refine ⟨C, hC, fun R hR => ?_⟩
  have hRp : 0 < R := by linarith
  calc
    A q R ≤ R ^ (n * (1 / q - 1 / p)) * A p R := hvolume p hqp hpq₀ R hR
    _ ≤ R ^ (n * (1 / q - 1 / p)) * (C * R ^ (ε / 2)) :=
      mul_le_mul_of_nonneg_left (hCR R hR) (Real.rpow_nonneg hRp.le _)
    _ = C * R ^ (n * (1 / q - 1 / p) + ε / 2) := by rw [Real.rpow_add hRp]; ring
    _ ≤ C * R ^ ε := mul_le_mul_of_nonneg_left
      (Real.rpow_le_rpow_of_exponent_le hR (by linarith)) hC

end N2Restriction
