import N2Restriction.LocalSurfaceGraph
import N2Restriction.SupportMargins

namespace N2Restriction
open MeasureTheory Set

/-- actual surface packets spend at most their ambient cap radius in margin. -/
theorem SurfaceGraphChart.packet_margin {d : ℕ} (G : SurfaceGraphChart d) {K : Set (Ambient d)} {r : ℝ}
    (P : CoordinateCapFamily K r) (hr : 0 < r) (g : Lp ℂ 2 G.surfaceMeasure)
    (U : Set (Ambient (d + 1))) (a : ℝ)
    (hK : ∀ x ∈ K, G.parametrization x ∈ marginRegion U a)
    (j : P.centers) (ν : Fin d → ℤ) :
    HasFrequencySupport G.surfaceMeasure id
      (marginRegion U (a - (1 + (G.lipConstant : ℝ)) * (2 * r))) (G.packet P hr g j ν) := by
  apply (G.packet_ambient_support P hr g j ν).mono
  intro x hx
  exact marginRegion_enlargement U (by linarith)
    (hK j (P.centers_mem j.property)) hx.le

/-- a compact graph patch has finite actual surface measure. -/
theorem SurfaceGraphChart.finite_patch_measure {d : ℕ} (G : SurfaceGraphChart d) {K : Set (Ambient d)} (hK : IsCompact K) :
    IsFiniteMeasure (G.surfaceMeasure.restrict (G.parametrization '' K)) := by
  rw [G.surfaceMeasure_restrict_image]
  constructor
  rw [Measure.restrict_apply_univ]
  have h := finite_hausdorff_lipschitz_image hK (graphMap_lipschitz G.lipschitz).lipschitzOnWith
  simpa only [Ambient, finrank_euclideanSpace, Fintype.card_fin] using h

/-- packet margins satisfy the article's child-radius loss rule. -/
theorem SurfaceGraphChart.eventually_packet_child_margin {d : ℕ} (G : SurfaceGraphChart d) (U : Set (Ambient (d + 1))) (m : ℝ) :
    ∀ᶠ R : ℝ in Filter.atTop, ∀ L : ℝ, 1 ≤ L → L ≤ R / 2 →
      ∀ {K : Set (Ambient d)} (P : CoordinateCapFamily K (R ^ (-1 / 2 : ℝ)))
      (hr : 0 < R ^ (-1 / 2 : ℝ)) (g : Lp ℂ 2 G.surfaceMeasure),
      (∀ x ∈ K, G.parametrization x ∈ marginRegion U (m - R ^ (-1 / 4 : ℝ))) →
      ∀ (j : P.centers) (ν : Fin d → ℤ),
      HasFrequencySupport G.surfaceMeasure id (marginRegion U (m - L ^ (-1 / 4 : ℝ)))
        (G.packet P hr g j ν) := by
  filter_upwards [eventually_marginRegion_children U m (2 * (1 + (G.lipConstant : ℝ)))] with R hR
  intro L hL hLR K P hr g hK j ν
  apply (G.packet_ambient_support P hr g j ν).mono
  intro x hx
  apply hR L hL hLR x (G.parametrization j) (hK j (P.centers_mem j.property))
  calc
    dist x (G.parametrization j) ≤ (1 + (G.lipConstant : ℝ)) * (2 * R ^ (-1 / 2 : ℝ)) := hx.le
    _ = _ := by ring

/-- every selected L2 subseries retains the spent ambient support margin. -/
theorem SurfaceGraphChart.selected_packet_margin {d : ℕ} (G : SurfaceGraphChart d) {K : Set (Ambient d)} {r : ℝ}
    (P : CoordinateCapFamily K r) (hr : 0 < r) (g : Lp ℂ 2 G.surfaceMeasure)
    (U : Set (Ambient (d + 1))) (a : ℝ)
    (hK : ∀ x ∈ K, G.parametrization x ∈ marginRegion U a)
    (S : Set (P.centers × (Fin d → ℤ))) :
    HasFrequencySupport G.surfaceMeasure id
      (marginRegion U (a - (1 + (G.lipConstant : ℝ)) * (2 * r)))
      (∑' p : S, G.packet P hr g p.val.1 p.val.2 : Lp ℂ 2 G.surfaceMeasure) := by
  apply HasFrequencySupport.tsum_L2 G.surfaceMeasure _ (isClosed_marginRegion U _).measurableSet
    _ (G.packet_subcollection_summable P hr g S)
  intro p
  apply (G.packet_ambient_support P hr g p.val.1 p.val.2).mono
  intro x hx
  exact marginRegion_enlargement U (by linarith)
    (hK p.val.1 (P.centers_mem p.val.1.property)) hx.le

end N2Restriction
