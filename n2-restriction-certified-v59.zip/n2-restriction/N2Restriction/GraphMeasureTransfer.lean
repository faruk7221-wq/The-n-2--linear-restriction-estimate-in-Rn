import N2Restriction.LocalGraphDensity
import N2Restriction.DensityPackets

namespace N2Restriction
open MeasureTheory
open scoped NNReal ENNReal

/-- A measurable left inverse pushes the image measure back to its source. -/
theorem retraction_measurePreserving {Ω Ξ : Type*} [MeasurableSpace Ω] [MeasurableSpace Ξ]
    (μ : Measure Ω) (F : Ω → Ξ) (P : Ξ → Ω) (hF : Measurable F) (hP : Measurable P)
    (hleft : Function.LeftInverse P F) : MeasurePreserving P (μ.map F) μ := by
  refine ⟨hP, ?_⟩
  rw [Measure.map_map hP hF]
  have he : P ∘ F = id := funext hleft
  rw [he, Measure.map_id]

/-- Surface input on the image, obtained by composing a coordinate input with a retraction. -/
noncomputable def imageInput {Ω Ξ : Type*} [MeasurableSpace Ω] [MeasurableSpace Ξ]
    (μ : Measure Ω) (F : Ω → Ξ) (P : Ξ → Ω) (hF : Measurable F) (hP : Measurable P)
    (hleft : Function.LeftInverse P F) : Lp ℂ 2 μ →ₗᵢ[ℂ] Lp ℂ 2 (μ.map F) :=
  Lp.compMeasurePreservingₗᵢ ℂ P (retraction_measurePreserving μ F P hF hP hleft)

theorem imageInput_coe {Ω Ξ : Type*} [MeasurableSpace Ω] [MeasurableSpace Ξ]
    (μ : Measure Ω) (F : Ω → Ξ) (P : Ξ → Ω) (hF : Measurable F) (hP : Measurable P)
    (hleft : Function.LeftInverse P F) (f : Lp ℂ 2 μ) :
    imageInput μ F P hF hP hleft f =ᵐ[μ.map F] fun z => f (P z) :=
  Lp.coeFn_compMeasurePreserving f _

/-- Pulling back a surface L2 input and then lifting it recovers the input exactly. -/
theorem imageInput_pullback {Ω Ξ : Type*} [MeasurableSpace Ω] [MeasurableSpace Ξ]
    (μ : Measure Ω) (F : Ω → Ξ) (P : Ξ → Ω) (hF : MeasurableEmbedding F) (hP : Measurable P)
    (hleft : Function.LeftInverse P F) (g : Lp ℂ 2 (μ.map F)) :
    imageInput μ F P hF.measurable hP hleft (Lp.compMeasurePreserving F ⟨hF.measurable, rfl⟩ g) = g := by
  apply Lp.ext
  apply hF.ae_map_iff.mpr
  filter_upwards [ae_of_ae_map hF.measurable.aemeasurable
    (imageInput_coe μ F P hF.measurable hP hleft (Lp.compMeasurePreserving F ⟨hF.measurable, rfl⟩ g)),
    Lp.coeFn_compMeasurePreserving g (show MeasurePreserving F μ (μ.map F) from ⟨hF.measurable, rfl⟩)]
      with x h1 h2
  rw [hleft x] at h1
  exact h1.trans h2

/-- Surface extension of the lifted input equals coordinate extension with the graph parametrization. -/
theorem imageInput_extension {Ω : Type*} [MeasurableSpace Ω] {n : ℕ}
    (μ : Measure Ω) (F : Ω → Ambient n) (P : Ambient n → Ω)
    (hF : MeasurableEmbedding F) (hP : Measurable P)
    (hleft : Function.LeftInverse P F) (f : Lp ℂ 2 μ) (y : Ambient n) :
    extension (μ.map F) id (imageInput μ F P hF.measurable hP hleft f) y =
      extension μ F f y := by
  unfold extension
  rw [hF.integral_map]
  apply integral_congr_ae
  filter_upwards [ae_of_ae_map hF.measurable.aemeasurable
    (imageInput_coe μ F P hF.measurable hP hleft f)] with x hx
  simp only [id_eq, hx, hleft x]

/-- The lift preserves frequency support after applying the parametrization. -/
theorem imageInput_support {Ω : Type*} [MeasurableSpace Ω] {n : ℕ}
    (μ : Measure Ω) (F : Ω → Ambient n) (P : Ambient n → Ω)
    (hF : MeasurableEmbedding F) (hP : Measurable P) (hleft : Function.LeftInverse P F)
    (f : Lp ℂ 2 μ) (K : Set Ω) (hf : HasFrequencySupport μ id K f) :
    HasFrequencySupport (μ.map F) id (F '' K) (imageInput μ F P hF.measurable hP hleft f) := by
  apply hF.ae_map_iff.mpr
  filter_upwards [ae_of_ae_map hF.measurable.aemeasurable (imageInput_coe μ F P hF.measurable hP hleft f), hf]
    with x hx hs hn
  exact ⟨x, hs (by simpa only [hx, hleft x] using hn), rfl⟩

end N2Restriction
