import N2Restriction.HilbertPackets
import Mathlib.Analysis.Fourier.AddCircleMulti

/-! The Fourier-series input to packet decomposition, on a unit frequency torus.
The operator T can represent a bounded cutoff. Its construction with the
paper's scaled support and spatial decay is not asserted here. -/
namespace N2Restriction
open MeasureTheory UnitAddTorus
noncomputable local instance : MeasureSpace UnitAddCircle := ⟨AddCircle.haarAddCircle⟩
variable {d F : Type*} [Fintype d] [NormedAddCommGroup F] [NormedSpace ℂ F]
local notation "TorusL2" => Lp ℂ 2 (volume : Measure (UnitAddTorus d))

/-- Actual Fourier coefficients reconstruct after any bounded synthesis operator. -/
theorem fourier_packet_reconstruction (T : TorusL2 →L[ℂ] F) (f : TorusL2) :
    HasSum (fun i => T (mFourierCoeff f i • mFourierLp 2 i)) (T f) :=
  T.hasSum (hasSum_mFourier_series_L2 f)

/-- The Fourier packet subcollection estimate uses the original Fourier energy. -/
theorem fourier_packet_selection (T : TorusL2 →L[ℂ] F) (f : TorusL2)
    (S : Set (d → ℤ)) :
    ‖∑' i : S, T (mFourierCoeff f i • mFourierLp 2 i)‖ ^ 2 ≤
      ‖T‖ ^ 2 * ∑' i : S, ‖mFourierCoeff f i‖ ^ 2 := by
  simpa only [mFourierBasis_repr, coe_mFourierBasis] using
    bounded_packet_selection mFourierBasis T f S

/-- Explicit L2 error of a Fourier truncation, rather than only formal series equality. -/
theorem fourier_packet_truncation (f : TorusL2) (s : Finset (d → ℤ)) :
    ‖f - ∑ i ∈ s, mFourierCoeff f i • mFourierLp 2 i‖ ^ 2 =
      ∑' i : {i // i ∉ s}, ‖mFourierCoeff f i‖ ^ 2 := by
  simpa only [mFourierBasis_repr, coe_mFourierBasis] using
    hilbert_truncation_error mFourierBasis f s

end N2Restriction
