import N2Restriction.ParaboloidPackets
import N2Restriction.CapEnergy

namespace N2Restriction
open MeasureTheory
open scoped BigOperators

/-- Cauchy-Schwarz combines per-cap absolute tails using the original cap
energy, with only the square root of the number of caps lost. -/
theorem finite_cap_absolute_tail {ι E : Type*} [Fintype ι] [NormedAddCommGroup E]
    (x : ι → E) (tail : ι → ℝ) {δ : ℝ} (hδ : 0 ≤ δ)
    (ht : ∀ j, tail j ≤ δ * ‖x j‖) :
    (∑ j, tail j) ≤ δ * Real.sqrt (Fintype.card ι) * Real.sqrt (∑ j, ‖x j‖ ^ 2) := by
  have hc := Real.sum_mul_le_sqrt_mul_sqrt Finset.univ
    (fun _ : ι => (1 : ℝ)) (fun j => ‖x j‖)
  simp only [one_mul, one_pow, Finset.sum_const, Finset.card_univ, nsmul_eq_mul,
    mul_one] at hc
  calc
    _ ≤ ∑ j, δ * ‖x j‖ := Finset.sum_le_sum (fun j _ => ht j)
    _ = δ * ∑ j, ‖x j‖ := (Finset.mul_sum _ _ _).symm
    _ ≤ δ * (Real.sqrt (Fintype.card ι) * Real.sqrt (∑ j, ‖x j‖ ^ 2)) :=
      mul_le_mul_of_nonneg_left hc hδ
    _ = _ := (mul_assoc _ _ _).symm

/-- For the actual bounded-overlap cutoff family, the cap-energy factor is
controlled by the original L2 input norm. -/
theorem cutoff_cap_absolute_tail {ι Ω : Type*} [Fintype ι] [MeasurableSpace Ω]
    {μ : Measure Ω} (χ : ι → Ω → ℂ)
    (hχ : ∀ j, AEStronglyMeasurable (χ j) μ) {A : ℝ}
    (hA : ∀ j, ∀ᵐ ω ∂μ, ‖χ j ω‖ ≤ A) {B : ℝ} (hB : 0 ≤ B)
    (hoverlap : ∀ᵐ ω ∂μ, (∑ j, ‖χ j ω‖ ^ 2) ≤ B)
    (f : Lp ℂ 2 μ) (tail : ι → ℝ) {δ : ℝ} (hδ : 0 ≤ δ)
    (ht : ∀ j, tail j ≤ δ * ‖cutoffOperator (χ j) (hχ j) (hA j) f‖) :
    (∑ j, tail j) ≤ δ * Real.sqrt (Fintype.card ι) * Real.sqrt B * ‖f‖ := by
  have hb := finite_cap_absolute_tail _ tail hδ ht
  have he := Real.sqrt_le_sqrt (cutoff_cap_energy χ hχ hA hoverlap f)
  rw [Real.sqrt_mul hB, Real.sqrt_sq (norm_nonneg f)] at he
  exact hb.trans ((mul_le_mul_of_nonneg_left he (by positivity)).trans_eq (by ring))

/-- The proved paraboloid tail bounds assemble over arbitrary finitely many
caps with one constant and the original sum of squared cap input norms. -/
theorem paraboloid_finite_cap_tail (d M : ℕ) {χ : Ambient d → ℂ}
    (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hs : HasCompactSupport χ) :
    ∃ C : ℝ, 0 ≤ C ∧
      ∀ {ι E : Type*} [Fintype ι] [NormedAddCommGroup E] [InnerProductSpace ℂ E],
      ∀ (b : HilbertBasis (Fin d → ℤ) ℂ E) (x : ι → E) (c : ι → Ambient d)
        (u : Ambient d) (r : ℝ), 0 < r → ∀ (t L : ℝ), |t * r ^ 2| ≤ 1 → 0 ≤ L →
      ∀ S : ι → Set (Fin d → ℤ),
      (∀ j ν, ν ∈ S j → L ≤ ‖latticeVector ν - (-(r • (u + t • c j)))‖) →
      (∑ j, ∑' ν : S j, ‖b.repr (x j) ν *
        graphPacket (fun ξ => inner ℝ ξ ξ / 2) χ (c j) r (r⁻¹ • latticeVector ν) u t‖) ≤
        (r ^ ((d : ℝ) / 2) * (C / (1 + L) ^ M)) *
          Real.sqrt (Fintype.card ι) * Real.sqrt (∑ j, ‖x j‖ ^ 2) := by
  obtain ⟨C, hC, hb⟩ := paraboloid_selected_packet_tail d M hχ hs
  refine ⟨C, hC, ?_⟩
  intro ι E _ _ _ b x c u r hr t L ht hL S hS
  apply finite_cap_absolute_tail x _ (by positivity)
  intro j
  exact (hb b (x j) (c j) u r hr t L ht hL (S j) (hS j)).2

/-- Polynomially many caps with a common input-energy budget retain rapid
decrease of the full absolute packet tail. Count and overlap bounds are
explicit hypotheses, ready for the still-unconstructed cap partition. -/
theorem paraboloid_finite_cap_rapid_tail (d : ℕ) {χ : Ambient d → ℂ}
    (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hs : HasCompactSupport χ)
    {τ : ℝ} (hτ : 0 < τ) (a N : ℝ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (R : ℝ), 1 ≤ R →
      ∀ {ι E : Type*} [Fintype ι] [NormedAddCommGroup E] [InnerProductSpace ℂ E],
      ∀ (b : HilbertBasis (Fin d → ℤ) ℂ E) (x : ι → E) (c : ι → Ambient d)
        (u : Ambient d) (t : ℝ), |t| ≤ R →
      ∀ (A B F : ℝ), 0 ≤ A → 0 ≤ B → 0 ≤ F →
      (Fintype.card ι : ℝ) ≤ A * R ^ a → (∑ j, ‖x j‖ ^ 2) ≤ B * F ^ 2 →
      ∀ S : ι → Set (Fin d → ℤ),
      (∀ j ν, ν ∈ S j → R ^ (1 / 2 + τ) / 10 ≤
        ‖u + (R ^ (-1 / 2 : ℝ))⁻¹ • latticeVector ν + t • c j‖) →
      (∑ j, ∑' ν : S j, ‖b.repr (x j) ν * graphPacket (fun ξ => inner ℝ ξ ξ / 2)
        χ (c j) (R ^ (-1 / 2 : ℝ)) ((R ^ (-1 / 2 : ℝ))⁻¹ • latticeVector ν) u t‖) ≤
        C * Real.sqrt A * Real.sqrt B * R ^ (-N) * F := by
  obtain ⟨C, hC, hb⟩ := paraboloid_rapid_selected_packet_tail d hχ hs hτ 0 (N + a / 2)
  refine ⟨C, hC, ?_⟩
  intro R hR ι E _ _ _ b x c u t ht A B F hA hB hF hcard henergy S hS
  have hRp : 0 < R := by linarith
  have htail := finite_cap_absolute_tail x
    (fun j => ∑' ν : S j, ‖b.repr (x j) ν * graphPacket (fun ξ => inner ℝ ξ ξ / 2)
      χ (c j) (R ^ (-1 / 2 : ℝ)) ((R ^ (-1 / 2 : ℝ))⁻¹ • latticeVector ν) u t‖)
    (δ := C * R ^ (-(N + a / 2))) (by positivity) (fun j => by
      simpa only [Real.rpow_zero, one_mul] using hb R hR b (x j) (c j) u t ht (S j) (hS j))
  have hpower : Real.sqrt (R ^ a) = R ^ (a / 2) := by
    rw [Real.sqrt_eq_rpow, ← Real.rpow_mul hRp.le]
    congr 1
    ring
  have hc := Real.sqrt_le_sqrt hcard
  rw [Real.sqrt_mul hA, hpower] at hc
  have he := Real.sqrt_le_sqrt henergy
  rw [Real.sqrt_mul hB, Real.sqrt_sq hF] at he
  have hcancel : R ^ (-(N + a / 2)) * R ^ (a / 2) = R ^ (-N) := by
    rw [← Real.rpow_add hRp]
    congr 1
    ring
  apply htail.trans
  calc
    _ ≤ (C * R ^ (-(N + a / 2))) * (Real.sqrt A * R ^ (a / 2)) *
        (Real.sqrt B * F) := by gcongr
    _ = (C * Real.sqrt A * Real.sqrt B * F) *
        (R ^ (-(N + a / 2)) * R ^ (a / 2)) := by ring
    _ = _ := by rw [hcancel]; ring

end N2Restriction
