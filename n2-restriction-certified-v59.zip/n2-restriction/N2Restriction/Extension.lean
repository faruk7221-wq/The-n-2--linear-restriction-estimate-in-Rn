import N2Restriction.PositiveAnalysis
import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.Analysis.Complex.Trigonometric
import Mathlib.MeasureTheory.Integral.Bochner.Basic

import Mathlib.MeasureTheory.Measure.Haar.InnerProductSpace
/-! A concrete Fourier extension integral and statements of the desired
local/global estimates. The main estimates are definitions of propositions,
not theorems asserted or proved by this file. Frequency spaces can be the
surface patches themselves, with ζ the inclusion and μ surface measure. -/

namespace N2Restriction
open MeasureTheory
open scoped ENNReal NNReal BigOperators

abbrev Ambient (n : ℕ) := EuclideanSpace ℝ (Fin n)

noncomputable def extension {n : ℕ} {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) (ζ : Ω → Ambient n) (f : Ω → ℂ) (x : Ambient n) : ℂ :=
  ∫ ω, Complex.exp ((inner ℝ x (ζ ω) : ℂ) * Complex.I) * f ω ∂μ

/-- The absolute extension kernel has modulus one. -/
lemma norm_extension_kernel {n : ℕ} (x ζ : Ambient n) :
    ‖Complex.exp ((inner ℝ x ζ : ℂ) * Complex.I)‖ = 1 :=
  Complex.norm_exp_ofReal_mul_I _

/-- The L1-to-Linfinity part of Lemma 3.1, with the actual Fourier integral. -/
theorem extension_le_L1 {n : ℕ} {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) (ζ : Ω → Ambient n) (f : Ω → ℂ) (x : Ambient n) :
    ‖extension μ ζ f x‖ ≤ ∫ ω, ‖f ω‖ ∂μ := by
  unfold extension
  have h := norm_integral_le_integral_norm
    (fun ω => Complex.exp ((inner ℝ x (ζ ω) : ℂ) * Complex.I) * f ω) (μ := μ)
  simpa only [norm_mul, norm_extension_kernel, one_mul] using h

/-- The L2-to-Linfinity part of Lemma 3.1 on a finite patch, with its
explicit square-root surface-mass constant. -/
theorem extension_le_L2 {n : ℕ} {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsFiniteMeasure μ] (ζ : Ω → Ambient n) (f : Ω → ℂ)
    (hf : MemLp f 2 μ) (x : Ambient n) :
    ‖extension μ ζ f x‖ ≤
      (∫ ω, ‖f ω‖ ^ (2 : ℝ) ∂μ) ^ (1 / 2 : ℝ) * (μ.real Set.univ) ^ (1 / 2 : ℝ) := by
  have hpq : (2 : ℝ).HolderConjugate 2 := by
    exact Real.holderConjugate_iff.mpr ⟨by norm_num, by norm_num⟩
  have hf' : MemLp f (ENNReal.ofReal (2 : ℝ)) μ := by simpa using hf
  have hg : MemLp (fun _ : Ω => (1 : ℂ)) (ENNReal.ofReal (2 : ℝ)) μ := memLp_const _
  have h := integral_mul_norm_le_Lp_mul_Lq hpq hf' hg
  simp only [norm_one, mul_one, Real.one_rpow, integral_const, smul_eq_mul, mul_one] at h
  exact (extension_le_L1 μ ζ f x).trans h

section Estimates
variable {n k : ℕ} {Ω : Fin k → Type*} [∀ i, MeasurableSpace (Ω i)]

noncomputable def extensionProduct (μ : ∀ i, Measure (Ω i))
    (ζ : ∀ i, Ω i → Ambient n) (f : ∀ i, Ω i → ℂ) (x : Ambient n) : ℂ :=
  ∏ i, extension (μ i) (ζ i) (f i) x

noncomputable def inputNormProduct (μ : ∀ i, Measure (Ω i))
    (f : ∀ i, Ω i → ℂ) : ℝ≥0∞ := ∏ i, eLpNorm (f i) 2 (μ i)

/-- Literal local estimate (1.7), on all balls and for arbitrary L2 inputs.
A proof from the paper's geometric hypotheses is still outstanding. -/
def LocalRestriction (μ : ∀ i, Measure (Ω i)) (ζ : ∀ i, Ω i → Ambient n)
    (p : ℝ) : Prop :=
  ∀ ε : ℝ, 0 < ε → ∃ C : ℝ≥0, ∀ R : ℝ, 2 ≤ R → ∀ x₀ : Ambient n,
    ∀ f : ∀ i, Ω i → ℂ, (∀ i, MemLp (f i) 2 (μ i)) →
    eLpNorm' (extensionProduct μ ζ f) p (volume.restrict (Metric.ball x₀ R)) ≤
      (C : ℝ≥0∞) * ENNReal.ofReal (R ^ ε) * inputNormProduct μ f

/-- Literal global estimate (1.8) at a fixed strict exponent. -/
def GlobalRestriction (μ : ∀ i, Measure (Ω i)) (ζ : ∀ i, Ω i → Ambient n)
    (p : ℝ) : Prop :=
  ∃ C : ℝ≥0, ∀ f : ∀ i, Ω i → ℂ, (∀ i, MemLp (f i) 2 (μ i)) →
    eLpNorm' (extensionProduct μ ζ f) p volume ≤ (C : ℝ≥0∞) * inputNormProduct μ f

end Estimates
end N2Restriction
