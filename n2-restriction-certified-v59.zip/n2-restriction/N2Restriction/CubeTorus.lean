import N2Restriction.FourierPackets
import N2Restriction.RadialPacketTails
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Periodic
import Mathlib.MeasureTheory.Measure.Haar.InnerProductSpace

namespace N2Restriction
open MeasureTheory Set UnitAddTorus
noncomputable local instance cubeTorusCircleMeasure : MeasureSpace UnitAddCircle := ⟨AddCircle.haarAddCircle⟩

def unitCube {d : ℕ} (t : Fin d → ℝ) : Set (Fin d → ℝ) :=
  univ.pi (fun i => Ioc (t i) (t i + 1))

def cubeQuotient {d : ℕ} (x : Fin d → ℝ) : UnitAddTorus (Fin d) :=
  fun i => (x i : UnitAddCircle)

noncomputable def cubeRepresentative {d : ℕ} (t : Fin d → ℝ)
    (q : UnitAddTorus (Fin d)) : Fin d → ℝ :=
  fun i => (AddCircle.measurableEquivIoc 1 (t i) (q i) : ℝ)

theorem unitCube_measurable {d : ℕ} (t : Fin d → ℝ) : MeasurableSet (unitCube t) :=
  MeasurableSet.univ_pi (fun _ => measurableSet_Ioc)

theorem cubeQuotient_measurePreserving {d : ℕ} (t : Fin d → ℝ) :
    MeasurePreserving (@cubeQuotient d) (volume.restrict (unitCube t)) volume := by
  refine ⟨measurable_pi_lambda _ (fun i =>
    (UnitAddCircle.measurePreserving_mk (t i)).measurable.comp (measurable_pi_apply i)), ?_⟩
  change (Measure.map _ ((Measure.pi (fun _ : Fin d => (volume : Measure ℝ))).restrict _)) = _
  unfold unitCube cubeQuotient
  rw [Measure.restrict_pi_pi, Measure.pi_map_pi]
  · congr 1
    funext i
    have h := (UnitAddCircle.measurePreserving_mk (t i)).map_eq
    rw [AddCircle.volume_eq_smul_haarAddCircle] at h
    simpa using h
  · intro i
    exact (UnitAddCircle.measurePreserving_mk (t i)).aemeasurable

theorem cubeRepresentative_measurable {d : ℕ} (t : Fin d → ℝ) :
    Measurable (cubeRepresentative t) :=
  measurable_pi_lambda _ (fun i => (measurable_subtype_coe.comp
    (AddCircle.measurableEquivIoc 1 (t i)).measurable).comp (measurable_pi_apply i))

theorem cubeRepresentative_mem {d : ℕ} (t : Fin d → ℝ) (q : UnitAddTorus (Fin d)) :
    cubeRepresentative t q ∈ unitCube t := by
  intro i _
  exact (AddCircle.measurableEquivIoc 1 (t i) (q i)).property

theorem cubeQuotient_representative {d : ℕ} (t : Fin d → ℝ) (q : UnitAddTorus (Fin d)) :
    cubeQuotient (cubeRepresentative t q) = q := by
  funext i
  exact (AddCircle.measurableEquivIoc 1 (t i)).symm_apply_apply (q i)

theorem cubeRepresentative_quotient {d : ℕ} (t : Fin d → ℝ)
    {x : Fin d → ℝ} (hx : x ∈ unitCube t) : cubeRepresentative t (cubeQuotient x) = x := by
  funext i
  exact congrArg Subtype.val
    ((AddCircle.measurableEquivIoc 1 (t i)).apply_symm_apply ⟨x i, hx i (mem_univ i)⟩)

theorem cubeRepresentative_measurePreserving {d : ℕ} (t : Fin d → ℝ) :
    MeasurePreserving (cubeRepresentative t) volume (volume.restrict (unitCube t)) := by
  refine ⟨cubeRepresentative_measurable t, ?_⟩
  rw [← (cubeQuotient_measurePreserving t).map_eq,
    Measure.map_map (cubeRepresentative_measurable t) (cubeQuotient_measurePreserving t).measurable]
  calc
    _ = Measure.map id (volume.restrict (unitCube t)) := by
      apply Measure.map_congr
      filter_upwards [ae_restrict_mem (unitCube_measurable t)] with x hx
      exact cubeRepresentative_quotient t hx
    _ = _ := Measure.map_id

/-- Pullback from the probability torus to the actual half-open unit cube. -/
noncomputable def torusToCube {d : ℕ} (t : Fin d → ℝ) :
    Lp ℂ 2 (volume : Measure (UnitAddTorus (Fin d))) →ₗᵢ[ℂ]
      Lp ℂ 2 (volume.restrict (unitCube t)) :=
  Lp.compMeasurePreservingₗᵢ ℂ cubeQuotient (cubeQuotient_measurePreserving t)

/-- The inverse pullback uses the unique half-open-cube representative. -/
noncomputable def cubeToTorus {d : ℕ} (t : Fin d → ℝ) :
    Lp ℂ 2 (volume.restrict (unitCube t)) →ₗᵢ[ℂ]
      Lp ℂ 2 (volume : Measure (UnitAddTorus (Fin d))) :=
  Lp.compMeasurePreservingₗᵢ ℂ (cubeRepresentative t) (cubeRepresentative_measurePreserving t)

theorem torusToCube_coe {d : ℕ} (t : Fin d → ℝ)
    (f : Lp ℂ 2 (volume : Measure (UnitAddTorus (Fin d)))) :
    ∀ᵐ x ∂volume.restrict (unitCube t), torusToCube t f x = f (cubeQuotient x) :=
  Lp.coeFn_compMeasurePreserving f (cubeQuotient_measurePreserving t)

theorem cubeToTorus_coe {d : ℕ} (t : Fin d → ℝ)
    (f : Lp ℂ 2 (volume.restrict (unitCube t))) :
    ∀ᵐ q, cubeToTorus t f q = f (cubeRepresentative t q) :=
  Lp.coeFn_compMeasurePreserving f (cubeRepresentative_measurePreserving t)

theorem torusToCube_cubeToTorus {d : ℕ} (t : Fin d → ℝ)
    (f : Lp ℂ 2 (volume.restrict (unitCube t))) : torusToCube t (cubeToTorus t f) = f := by
  apply Lp.ext
  filter_upwards [torusToCube_coe t (cubeToTorus t f),
    (cubeQuotient_measurePreserving t).quasiMeasurePreserving.ae (cubeToTorus_coe t f),
    ae_restrict_mem (unitCube_measurable t)] with x hx hq hmem
  rw [hx, hq, cubeRepresentative_quotient t hmem]

theorem cubeToTorus_torusToCube {d : ℕ} (t : Fin d → ℝ)
    (f : Lp ℂ 2 (volume : Measure (UnitAddTorus (Fin d)))) : cubeToTorus t (torusToCube t f) = f := by
  apply Lp.ext
  filter_upwards [cubeToTorus_coe t (torusToCube t f),
    (cubeRepresentative_measurePreserving t).quasiMeasurePreserving.ae (torusToCube_coe t f)]
      with q hq hx
  rw [hq, hx, cubeQuotient_representative]

/-- Actual two-way isometric identification, not only an embedding. -/
noncomputable def cubeTorusEquiv {d : ℕ} (t : Fin d → ℝ) :
    Lp ℂ 2 (volume : Measure (UnitAddTorus (Fin d))) ≃ₗᵢ[ℂ]
      Lp ℂ 2 (volume.restrict (unitCube t)) :=
  { torusToCube t with
    invFun := cubeToTorus t
    left_inv := cubeToTorus_torusToCube t
    right_inv := torusToCube_cubeToTorus t }

end N2Restriction
