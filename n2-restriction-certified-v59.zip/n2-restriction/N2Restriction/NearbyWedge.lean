import N2Restriction.CompactFrames
import N2Restriction.CompactGramBound

/-! A compact-frame form of the uniform normal-wedge statement in Lemma 4.1.
For a fixed supported tuple, the original normals together with the two shape
images of an admissible nearby-plane frame stay quantitatively independent. -/

namespace N2Restriction

set_option maxHeartbeats 800000

/-- The `k` original normals followed by the shape images of an orthonormal
frame for the nearby two-plane. -/
noncomputable def nearbyWedgeVectors {k : ℕ} (S : Fin k → SmoothPatch (k + 2))
    (z : Fin k → Ambient (k + 2)) (i : Fin k)
    (q : Ambient (k + 2) × Ambient (k + 2)) :
    Sum (Fin k) (Fin 2) → Ambient (k + 2) :=
  Sum.elim (fun j => (S j).normal (z j)) (fun a =>
    (S i).shape (z i) (if a = 0 then q.1 else q.2))

/-- The compact family of nearby-plane frames tangent to the selected surface
and obeying the curvature-scaled projection gap at a fixed frequency tuple. -/
def nearbyWedgeFrameSet {k : ℕ} (S : Fin k → SmoothPatch (k + 2))
    (z : Fin k → Ambient (k + 2)) (i : Fin k) (κ : ℝ) :
    Set (Ambient (k + 2) × Ambient (k + 2)) :=
  {q | q ∈ orthonormalPairSet (k + 2) ∧
    inner ℝ ((S i).normal (z i)) q.1 = 0 ∧
    inner ℝ ((S i).normal (z i)) q.2 = 0 ∧
    ‖(commonTangent (fun j => (S j).normal (z j))).starProjection -
      pairProjection q‖ * ‖(S i).shape (z i)‖ ≤ κ / 2}

theorem isClosed_nearbyWedgeFrameSet {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) (z : Fin k → Ambient (k + 2))
    (i : Fin k) (κ : ℝ) : IsClosed (nearbyWedgeFrameSet S z i κ) := by
  let N := (S i).normal (z i)
  let W := commonTangent (fun j => (S j).normal (z j))
  let A := (S i).shape (z i)
  have h₀ : Continuous (fun q : Ambient (k + 2) × Ambient (k + 2) =>
      inner ℝ N q.1) := (innerSL ℝ N).continuous.comp continuous_fst
  have h₁ : Continuous (fun q : Ambient (k + 2) × Ambient (k + 2) =>
      inner ℝ N q.2) := (innerSL ℝ N).continuous.comp continuous_snd
  have hgap : Continuous (fun q : Ambient (k + 2) × Ambient (k + 2) =>
      ‖W.starProjection - pairProjection q‖ * ‖A‖) := by
    exact (continuous_const.sub (continuous_pairProjection (k + 2))).norm.mul continuous_const
  change IsClosed (orthonormalPairSet (k + 2) ∩
    ({q | inner ℝ N q.1 = 0} ∩
      ({q | inner ℝ N q.2 = 0} ∩ {q | ‖W.starProjection - pairProjection q‖ *
        ‖A‖ ≤ κ / 2})))
  exact isClosed_orthonormalPairSet (k + 2) |>.inter
    ((isClosed_eq h₀ continuous_const).inter
      ((isClosed_eq h₁ continuous_const).inter
        (isClosed_le hgap continuous_const)))

theorem isCompact_nearbyWedgeFrameSet {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) (z : Fin k → Ambient (k + 2))
    (i : Fin k) (κ : ℝ) : IsCompact (nearbyWedgeFrameSet S z i κ) := by
  apply (isCompact_orthonormalPairSet (k + 2)).of_isClosed_subset
    (isClosed_nearbyWedgeFrameSet S z i κ)
  intro q hq
  exact hq.1

theorem continuous_nearbyWedgeVectors {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) (z : Fin k → Ambient (k + 2))
    (i : Fin k) :
    Continuous (fun q : Ambient (k + 2) × Ambient (k + 2) =>
      nearbyWedgeVectors S z i q) := by
  refine continuous_pi fun a => ?_
  cases a with
  | inl j => exact continuous_const
  | inr j =>
      fin_cases j
      · simpa [nearbyWedgeVectors] using
          ((S i).shape (z i)).continuous.comp continuous_fst
      · simpa [nearbyWedgeVectors] using
          ((S i).shape (z i)).continuous.comp continuous_snd

/-- At any admissible nearby plane, the normals and its two shape-frame
vectors are linearly independent. The proof uses the reverse compression
bound on the plane coordinates, then the Gram lower bound for the original
normals. -/
theorem geometric_nearby_frame_wedge_independent {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) {ν κ : ℝ}
    (hgeo : GeometricHypotheses S ν κ)
    (z : Fin k → Ambient (k + 2))
    (hz : ∀ j, z j ∈ (S j).extendedSurface) (i : Fin k)
    (q : Ambient (k + 2) × Ambient (k + 2))
    (hq : q ∈ orthonormalPairSet (k + 2))
    (h₀ : inner ℝ ((S i).normal (z i)) q.1 = 0)
    (h₁ : inner ℝ ((S i).normal (z i)) q.2 = 0)
    (hgap : ‖(commonTangent (fun j => (S j).normal (z j))).starProjection -
      pairProjection q‖ * ‖(S i).shape (z i)‖ ≤ κ / 2) :
    LinearIndependent ℝ (nearbyWedgeVectors S z i q) := by
  let N : Fin k → Ambient (k + 2) := fun j => (S j).normal (z j)
  let W := commonTangent N
  let H := pairPlane q
  let A := (S i).shape (z i)
  have hnormals : LinearIndependent ℝ N := by
    apply normals_independent_of_gram N
    have hdet := (hgeo.2.2 z hz).1
    exact ne_of_gt (lt_of_lt_of_le (sq_pos_of_pos hgeo.1) hdet)
  have hdim : Module.finrank ℝ W = Module.finrank ℝ H := by
    rw [geometric_commonTangent_two S hgeo z hz, pairPlane_finrank_two hq]
  have hzero : H.orthogonalProjection (N i) = 0 := by
    apply Submodule.orthogonalProjection_eq_zero_iff.mpr
    rw [Submodule.mem_orthogonal]
    intro x hx
    change inner ℝ (x : Ambient (k + 2)) (N i) = 0
    change (x : Ambient (k + 2)) ∈ Submodule.span ℝ ({q.1, q.2} : Set _)
      at hx
    refine Submodule.span_induction ?_ ?_ ?_ ?_ hx
    · intro x hx
      simp only [Set.mem_insert_iff, Set.mem_singleton_iff] at hx
      rcases hx with rfl | rfl
      · exact (real_inner_comm _ _).trans h₀
      · exact (real_inner_comm _ _).trans h₁
    · simp
    · intro x y hx hy hx0 hy0
      rw [inner_add_left, hx0, hy0, add_zero]
    · intro a x hx hx0
      simp [inner_smul_left, hx0]
  have hW : ∀ v : W, inner ℝ (N i) (v : Ambient (k + 2)) = 0 :=
    fun v => commonTangent_orthogonal N v i
  have hA : ∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (A v)‖ :=
    (hgeo.2.2 z hz).2 i
  have hgap' : ‖W.starProjection - H.starProjection‖ * ‖A‖ ≤ κ / 2 := by
    simpa only [pairProjection_eq_planeProjection hq] using hgap
  have hreverse := nearby_reverse_shape_coercive (S i) W H hdim (hz i).1
    hzero hW hgeo.2.1 hA hgap'
  rw [Fintype.linearIndependent_iff]
  intro c hc a
  let u := c (Sum.inr (0 : Fin 2)) • q.1 + c (Sum.inr (1 : Fin 2)) • q.2
  let h : H := ⟨u, by
    change u ∈ Submodule.span ℝ ({q.1, q.2} : Set _)
    exact Submodule.mem_span_pair.mpr ⟨c (Sum.inr 0), c (Sum.inr 1), rfl⟩⟩
  have hcombine : (∑ j : Fin k, c (Sum.inl j) • N j) + A (h : Ambient (k + 2)) = 0 := by
    have hs := hc
    simp only [nearbyWedgeVectors, Fintype.sum_sum_type, Fin.sum_univ_two] at hs
    simpa [h, u, map_add, map_smul, add_assoc] using hs
  have hNproj : ∀ j : Fin k, W.orthogonalProjection (N j) = 0 := by
    intro j
    apply Submodule.orthogonalProjection_eq_zero_iff.mpr
    rw [Submodule.mem_orthogonal]
    intro v hv
    exact (real_inner_comm _ _).trans (commonTangent_orthogonal N ⟨v, hv⟩ j)
  have hsumproj : W.orthogonalProjection
      (∑ j : Fin k, c (Sum.inl j) • N j) = 0 := by
    rw [map_sum]
    apply Finset.sum_eq_zero
    intro j hj
    rw [map_smul, hNproj, smul_zero]
  have hAproj : W.orthogonalProjection (A (h : Ambient (k + 2))) = 0 := by
    have hp := congrArg W.orthogonalProjection hcombine
    rw [map_add, hsumproj, zero_add] at hp
    simpa using hp
  have hh : (h : Ambient (k + 2)) = 0 := by
    have hb := hreverse h
    rw [hAproj, norm_zero] at hb
    have hκpos : 0 < κ := hgeo.2.1
    have hκ2 : 0 < κ / 2 := by positivity
    have hnorm : ‖(h : Ambient (k + 2))‖ = 0 := by
      apply le_antisymm
      · by_contra hnot
        have hpos : 0 < ‖(h : Ambient (k + 2))‖ := lt_of_not_ge hnot
        have hprod := mul_pos hκ2 hpos
        exact (not_le_of_gt hprod) hb
      · exact norm_nonneg _
    exact norm_eq_zero.mp hnorm
  have hcoeff₀ : c (Sum.inr (0 : Fin 2)) = 0 := by
    have hinner := congrArg (fun x : Ambient (k + 2) => inner ℝ q.1 x) hh
    have huu : inner ℝ q.1 q.1 = 1 := by
      rw [real_inner_self_eq_norm_sq, hq.1]
      norm_num
    have huv : inner ℝ q.1 q.2 = 0 := hq.2.2
    simpa [h, u, inner_add_right, inner_smul_right, huu, huv] using hinner
  have hcoeff₁ : c (Sum.inr (1 : Fin 2)) = 0 := by
    have hinner := congrArg (fun x : Ambient (k + 2) => inner ℝ q.2 x) hh
    have hvv : inner ℝ q.2 q.2 = 1 := by
      rw [real_inner_self_eq_norm_sq, hq.2.1]
      norm_num
    have hvu : inner ℝ q.2 q.1 = 0 := by rw [real_inner_comm, hq.2.2]
    simpa [h, u, inner_add_right, inner_smul_right, hvu, hvv] using hinner
  have hnormalsum : (∑ j : Fin k, c (Sum.inl j) • N j) = 0 := by
    have hs := hcombine
    rw [hh, map_zero, add_zero] at hs
    exact hs
  have hnormalcoeff := (Fintype.linearIndependent_iff.mp hnormals)
    (fun j => c (Sum.inl j)) hnormalsum
  cases a with
  | inl j => exact hnormalcoeff j
  | inr j =>
      fin_cases j
      · exact hcoeff₀
      · exact hcoeff₁

/-- For each fixed geometric tuple, all admissible nearby-plane normal wedges
share one positive lower bound. This is the compact-parameter form of the
transversality constant used by the localized restriction input. -/
theorem geometric_nearby_frame_wedge_uniform {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) {ν κ : ℝ}
    (hgeo : GeometricHypotheses S ν κ)
    (z : Fin k → Ambient (k + 2))
    (hz : ∀ j, z j ∈ (S j).extendedSurface) (i : Fin k) :
    ∃ c : ℝ, 0 < c ∧ ∀ q ∈ nearbyWedgeFrameSet S z i κ,
      c ≤ Matrix.det (Matrix.gram ℝ (nearbyWedgeVectors S z i q)) := by
  exact compact_uniform_gram_det_lower_bound
    (isCompact_nearbyWedgeFrameSet S z i κ)
    (nearbyWedgeVectors S z i)
    (continuous_nearbyWedgeVectors S z i)
    (fun q hq => geometric_nearby_frame_wedge_independent S hgeo z hz i q
      hq.1 hq.2.1 hq.2.2.1 hq.2.2.2)

end N2Restriction
