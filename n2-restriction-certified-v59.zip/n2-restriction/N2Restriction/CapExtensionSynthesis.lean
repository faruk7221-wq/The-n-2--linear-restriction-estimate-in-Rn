import N2Restriction.ActualPacketSynthesis
import N2Restriction.ExtensionSynthesis

namespace N2Restriction
open MeasureTheory Set UnitAddTorus
noncomputable local instance capExtensionCircleMeasure : MeasureSpace UnitAddCircle := ⟨AddCircle.haarAddCircle⟩
local instance capExtensionProbability : IsProbabilityMeasure (volume : Measure UnitAddCircle) :=
  inferInstanceAs (IsProbabilityMeasure AddCircle.haarAddCircle)

/-- The explicitly normalized cap measure has total mass one. -/
theorem capProbability_univ {d : ℕ} (t : Fin d → ℝ) (c : Ambient d) (r : ℝ) (hr : r ≠ 0) :
    capProbability t c r hr univ = 1 := by
  have h := ((capAffine_measurePreserving t c r hr).comp (cubeRepresentative_measurePreserving t)).measure_preimage MeasurableSet.univ
  simpa only [preimage_univ, measure_univ] using h.symm

/-- The ordinary Lebesgue volume of the actual affine cube. -/
theorem scaledCube_volume {d : ℕ} (t : Fin d → ℝ) (c : Ambient d) (r : ℝ) (hr : 0 < r) :
    volume (scaledCube t c r hr.ne') = ENNReal.ofReal (r ^ d) := by
  have h := congrArg (fun μ : Measure (Ambient d) => μ univ) (capLebesgue_eq t c r hr)
  simpa only [Measure.restrict_apply_univ, Measure.smul_apply, smul_eq_mul,
    capProbability_univ, mul_one] using h

theorem scaledCube_isFiniteMeasure {d : ℕ} (t : Fin d → ℝ) (c : Ambient d) (r : ℝ) (hr : 0 < r) :
    IsFiniteMeasure (volume.restrict (scaledCube t c r hr.ne')) := by
  constructor
  rw [Measure.restrict_apply_univ, scaledCube_volume t c r hr]
  exact ENNReal.ofReal_lt_top

/-- Zero extension does not change the Fourier extension integral. -/
theorem extension_zeroExtendL2 {d n : ℕ} (s : Set (Ambient d)) (hs : MeasurableSet s)
    (ζ : Ambient d → Ambient n) (f : Lp ℂ 2 (volume.restrict s)) (x : Ambient n) :
    extension volume ζ (zeroExtendL2 volume s hs f) x = extension (volume.restrict s) ζ f x := by
  unfold extension
  rw [← integral_indicator hs]
  apply integral_congr_ae
  filter_upwards [zeroExtendL2_coe volume s hs f] with ξ hξ
  rw [hξ]
  by_cases h : ξ ∈ s
  · simp only [indicator_of_mem h]
  · simp only [indicator_of_notMem h, mul_zero]

/-- A bounded evaluation on ordinary cap L2 agrees with the full-space extension
of its zero extension. -/
theorem cap_extension_hasSum {d n : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : 0 < r) (ζ : Ambient d → Ambient n) (hζ : Measurable ζ)
    {ι : Type*} {f : ι → Lp ℂ 2 (volume.restrict (scaledCube t c r hr.ne'))}
    {g : Lp ℂ 2 (volume.restrict (scaledCube t c r hr.ne'))} (hf : HasSum f g) (x : Ambient n) :
    HasSum (fun i => extension volume ζ
      (zeroExtendL2 volume (scaledCube t c r hr.ne') (scaledCube_measurable t c r hr.ne') (f i)) x)
      (extension volume ζ
        (zeroExtendL2 volume (scaledCube t c r hr.ne') (scaledCube_measurable t c r hr.ne') g) x) := by
  letI := scaledCube_isFiniteMeasure t c r hr
  simpa only [extension_zeroExtendL2] using
    extension_hasSum_of_L2 (volume.restrict (scaledCube t c r hr.ne')) ζ hζ hf x

end N2Restriction
