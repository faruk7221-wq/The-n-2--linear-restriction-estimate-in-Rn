import N2Restriction.EuclideanCapSynthesis
open MeasureTheory
namespace N2Restriction
/-- Exact total energy after zero extension, including cancellation of all cap-volume factors. -/
theorem euclidean_cap_cutoff_total_energy {d : ℕ} (t : Fin d → ℝ) (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (χ : Ambient d → ℂ) (hχ : AEStronglyMeasurable χ (capProbability t c r hr.ne'))
    {C : ℝ} (hC : ∀ᵐ ξ ∂capProbability t c r hr.ne', ‖χ ξ‖ ≤ C)
    (f : Lp ℂ 2 (volume.restrict (scaledCube t c r hr.ne'))) :
    (∑' ν, ‖capFourierCoeff t c r hr.ne' (normalizedCapInput t c r hr f) ν •
      euclideanCapSynthesis t c r hr (cutoffOperator χ hχ hC (capFourierAtom t c r hr.ne' ν))‖ ^ 2) =
      (eLpNorm χ 2 (capProbability t c r hr.ne')).toReal ^ 2 * ‖f‖ ^ 2 := by
  simp_rw [← map_smul (euclideanCapSynthesis t c r hr), euclideanCapSynthesis_norm, mul_pow]
  rw [tsum_mul_left, cap_cutoff_total_energy, normalizedCapInput_norm, mul_pow]
  have hcancel : (r ^ ((d : ℝ) / 2)) ^ 2 * (r ^ (-(d : ℝ) / 2)) ^ 2 = 1 := by
    rw [← mul_pow, ← Real.rpow_add hr]
    rw [show (d : ℝ) / 2 + -(d : ℝ) / 2 = 0 by ring, Real.rpow_zero, one_pow]
  calc
    _ = ((r ^ ((d : ℝ) / 2)) ^ 2 * (r ^ (-(d : ℝ) / 2)) ^ 2) *
        ((eLpNorm χ 2 (capProbability t c r hr.ne')).toReal ^ 2 * ‖f‖ ^ 2) := by ring
    _ = _ := by rw [hcancel, one_mul]

/-- Selected synthesis is controlled by the actual cutoff-packet energies. -/
theorem cap_cutoff_almost_orthogonal {d : ℕ} (t : Fin d → ℝ) (c : Ambient d) (r : ℝ) (hr : r ≠ 0)
    (χ : Ambient d → ℂ) (hχ : AEStronglyMeasurable χ (capProbability t c r hr))
    {C : ℝ} (hC0 : 0 ≤ C) (hC : ∀ᵐ ξ ∂capProbability t c r hr, ‖χ ξ‖ ≤ C)
    (f : Lp ℂ 2 (capProbability t c r hr)) (S : Set (Fin d → ℤ)) :
    (eLpNorm χ 2 (capProbability t c r hr)).toReal ^ 2 *
      ‖∑' ν : S, capFourierCoeff t c r hr f ν •
        cutoffOperator χ hχ hC (capFourierAtom t c r hr ν)‖ ^ 2 ≤
    C ^ 2 * ∑' ν : S, ‖capFourierCoeff t c r hr f ν •
      cutoffOperator χ hχ hC (capFourierAtom t c r hr ν)‖ ^ 2 := by
  have h := cap_cutoff_selection t c r hr χ hχ hC hC0 f S
  have he : (∑' ν : S, ‖capFourierCoeff t c r hr f ν •
      cutoffOperator χ hχ hC (capFourierAtom t c r hr ν)‖ ^ 2) =
      (eLpNorm χ 2 (capProbability t c r hr)).toReal ^ 2 *
        ∑' ν : S, ‖capFourierCoeff t c r hr f ν‖ ^ 2 := by
    simp_rw [cap_cutoff_packet_norm, mul_pow]
    rw [tsum_mul_right, mul_comm]
  rw [he]
  have hmul := mul_le_mul_of_nonneg_left h
    (sq_nonneg (eLpNorm χ 2 (capProbability t c r hr)).toReal)
  nlinarith only [hmul]
end N2Restriction
