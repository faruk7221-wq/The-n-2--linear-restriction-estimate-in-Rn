import N2Restriction.BallEstimates
import N2Restriction.PowerRecurrence

namespace N2Restriction
open MeasureTheory
open scoped ENNReal NNReal BigOperators

/-- The L2-to-Linfinity estimate in the extended norm convention used by
`LocalRestriction`. It also covers zero inputs. -/
theorem enorm_extension_le_eLpNorm {n : ℕ} {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} {ζ : Ω → Ambient n} {f : Ω → ℂ}
    (hf : MemLp f 2 μ) (x : Ambient n) :
    ‖extension μ ζ f x‖ₑ ≤ eLpNorm f 2 μ * (μ Set.univ) ^ (1 / 2 : ℝ) := by
  have hk (ω : Ω) : ‖Complex.exp ((inner ℝ x (ζ ω) : ℂ) * Complex.I)‖ₑ = 1 := by
    change (‖Complex.exp ((inner ℝ x (ζ ω) : ℂ) * Complex.I)‖₊ : ℝ≥0∞) = 1
    have : ‖Complex.exp ((inner ℝ x (ζ ω) : ℂ) * Complex.I)‖₊ = 1 :=
      NNReal.eq (norm_extension_kernel x (ζ ω))
    rw [this, ENNReal.coe_one]
  have h₁ : ‖extension μ ζ f x‖ₑ ≤ eLpNorm f 1 μ := by
    unfold extension
    simpa only [eLpNorm_one_eq_lintegral_enorm, enorm_mul, hk, one_mul] using
      (enorm_integral_le_lintegral_enorm
        (fun ω => Complex.exp ((inner ℝ x (ζ ω) : ℂ) * Complex.I) * f ω) (μ := μ))
  have h₂ := eLpNorm_le_eLpNorm_mul_rpow_measure_univ
    (show (1 : ℝ≥0∞) ≤ 2 by norm_num) hf.aestronglyMeasurable
  norm_num at h₂
  exact h₁.trans h₂

section
variable {n k : ℕ} {Ω : Fin k → Type*} [∀ i, MeasurableSpace (Ω i)]
variable (μ : ∀ i, Measure (Ω i)) (ζ : ∀ i, Ω i → Ambient n)

/-- The product of square-root patch masses. -/
noncomputable def patchMassFactor : ℝ≥0∞ := ∏ i, (μ i Set.univ) ^ (1 / 2 : ℝ)

/-- A uniform finite-radius bound, obtained before any restriction argument. -/
noncomputable def trivialLocalBound (p R : ℝ) : ℝ≥0∞ :=
  patchMassFactor μ * (volume (Metric.ball (0 : Ambient n) R)) ^ (1 / p)

/-- Actual operator constant: supremum over all ball centers and all L2 data.
The quotient convention assigns zero to the zero-input case, treated separately
in `localConstant_spec`. -/
noncomputable def localConstant (p R : ℝ) : ℝ≥0∞ :=
  ⨆ (x : Ambient n) (f : ∀ i, Ω i → ℂ) (_ : ∀ i, MemLp (f i) 2 (μ i)),
    eLpNorm' (extensionProduct μ ζ f) p (volume.restrict (Metric.ball x R)) /
      inputNormProduct μ f

lemma inputNormProduct_ne_top {f : ∀ i, Ω i → ℂ} (hf : ∀ i, MemLp (f i) 2 (μ i)) :
    inputNormProduct μ f ≠ ⊤ := by
  exact ENNReal.prod_ne_top (fun i _ => (hf i).eLpNorm_ne_top)

lemma patchMassFactor_ne_top [∀ i, IsFiniteMeasure (μ i)] : patchMassFactor μ ≠ ⊤ := by
  apply ENNReal.prod_ne_top
  intro i _
  exact ENNReal.rpow_ne_top_of_nonneg (by norm_num) (measure_ne_top _ _)

lemma trivialLocalBound_ne_top [∀ i, IsFiniteMeasure (μ i)] {p R : ℝ} (hp : 0 < p) :
    trivialLocalBound (n := n) μ p R ≠ ⊤ := by
  exact ENNReal.mul_ne_top (patchMassFactor_ne_top μ)
    (ENNReal.rpow_ne_top_of_nonneg (by positivity) measure_ball_lt_top.ne)

/-- The product extension has the uniform pointwise bound from Lemma 3.1. -/
lemma extensionProduct_bound {f : ∀ i, Ω i → ℂ}
    (hf : ∀ i, MemLp (f i) 2 (μ i)) (x : Ambient n) :
    ‖extensionProduct μ ζ f x‖ₑ ≤ patchMassFactor μ * inputNormProduct μ f := by
  unfold extensionProduct
  simp only [enorm_eq_nnnorm, nnnorm_prod, ENNReal.coe_finset_prod]
  calc
    (∏ i, (‖extension (μ i) (ζ i) (f i) x‖₊ : ℝ≥0∞)) ≤
        ∏ i, eLpNorm (f i) 2 (μ i) * (μ i Set.univ) ^ (1 / 2 : ℝ) := by
      exact Finset.prod_le_prod' (fun i _ => enorm_extension_le_eLpNorm (hf i) x)
    _ = patchMassFactor μ * inputNormProduct μ f := by
      rw [Finset.prod_mul_distrib, mul_comm]
      rfl

/-- Uniform local operator bound, with no transversality or curvature needed. -/
theorem trivial_local_estimate {p R : ℝ} (hp : 0 < p) (x : Ambient n)
    {f : ∀ i, Ω i → ℂ} (hf : ∀ i, MemLp (f i) 2 (μ i)) :
    eLpNorm' (extensionProduct μ ζ f) p (volume.restrict (Metric.ball x R)) ≤
      trivialLocalBound (n := n) μ p R * inputNormProduct μ f := by
  have h := eLpNorm'_mono_enorm_ae (μ := volume.restrict (Metric.ball x R))
    (g := fun _ : Ambient n => patchMassFactor μ * inputNormProduct μ f) hp.le
    (Filter.Eventually.of_forall (fun y => extensionProduct_bound μ ζ hf y))
  rw [eLpNorm'_const _ hp, enorm_eq_self, Measure.restrict_apply_univ,
    Measure.addHaar_ball_center volume x R] at h
  simpa only [trivialLocalBound, mul_assoc, mul_comm, mul_left_comm] using h

lemma localConstant_le_trivial {p R : ℝ} (hp : 0 < p) :
    localConstant μ ζ p R ≤ trivialLocalBound (n := n) μ p R := by
  refine iSup_le (fun x => iSup_le (fun f => iSup_le (fun hf => ?_)))
  exact ENNReal.div_le_of_le_mul (trivial_local_estimate μ ζ hp x hf)

lemma localConstant_ne_top [∀ i, IsFiniteMeasure (μ i)] {p R : ℝ} (hp : 0 < p) :
    localConstant μ ζ p R ≠ ⊤ :=
  ne_top_of_le_ne_top (trivialLocalBound_ne_top μ hp) (localConstant_le_trivial μ ζ hp)

/-- The supremum constant controls every input, including zero inputs. -/
theorem localConstant_spec [∀ i, IsFiniteMeasure (μ i)] {p R : ℝ}
    (hp : 0 < p) (x : Ambient n) {f : ∀ i, Ω i → ℂ}
    (hf : ∀ i, MemLp (f i) 2 (μ i)) :
    eLpNorm' (extensionProduct μ ζ f) p (volume.restrict (Metric.ball x R)) ≤
      localConstant μ ζ p R * inputNormProduct μ f := by
  by_cases hzero : inputNormProduct μ f = 0
  · simpa [hzero] using trivial_local_estimate μ ζ hp x hf
  · apply (ENNReal.div_le_iff hzero (inputNormProduct_ne_top μ hf)).mp
    exact le_iSup_of_le x (le_iSup_of_le f (le_iSup_of_le hf le_rfl))

/-- Conversely any uniform bound controls the best constant. -/
lemma localConstant_le_of_bound {p R : ℝ} {B : ℝ≥0∞}
    (h : ∀ (x : Ambient n) (f : ∀ i, Ω i → ℂ), (∀ i, MemLp (f i) 2 (μ i)) →
      eLpNorm' (extensionProduct μ ζ f) p (volume.restrict (Metric.ball x R)) ≤
        B * inputNormProduct μ f) : localConstant μ ζ p R ≤ B := by
  refine iSup_le (fun x => iSup_le (fun f => iSup_le (fun hf => ?_)))
  exact ENNReal.div_le_of_le_mul (h x f hf)

/-- Monotonicity in radius follows from restriction of measures. -/
lemma localConstant_mono [∀ i, IsFiniteMeasure (μ i)] {p R S : ℝ}
    (hp : 0 < p) (hRS : R ≤ S) : localConstant μ ζ p R ≤ localConstant μ ζ p S := by
  apply localConstant_le_of_bound
  intro x f hf
  exact (eLpNorm'_mono_measure _ (Measure.restrict_mono (Metric.ball_subset_ball hRS) le_rfl)
    hp.le).trans (localConstant_spec μ ζ hp x hf)

/-- The real-valued pth power used in the induction recurrence. -/
noncomputable def localPowerConstant (p R : ℝ) : ℝ := (localConstant μ ζ p R).toReal ^ p

/-- The bounded-radius starting condition is a theorem for the actual operator
constant, rather than a hypothesis supplied to the scalar induction. -/
theorem localPowerConstant_locally_bounded [∀ i, IsFiniteMeasure (μ i)] {p : ℝ}
    (hp : 0 < p) : ∀ T : ℝ, 1 ≤ T → ∃ M : ℝ,
      ∀ R, 1 ≤ R → R ≤ T → localPowerConstant μ ζ p R ≤ M := by
  intro T _
  refine ⟨localPowerConstant μ ζ p T, fun R _ hRT => ?_⟩
  exact Real.rpow_le_rpow ENNReal.toReal_nonneg
    (ENNReal.toReal_mono (localConstant_ne_top μ ζ hp) (localConstant_mono μ ζ hp hRT)) hp.le

/-- A growth estimate for the actual best constant gives the local restriction
estimate, with the same center-independent constant and all zero inputs covered. -/
theorem localRestriction_of_constant_growth [∀ i, IsFiniteMeasure (μ i)] {p : ℝ}
    (hp : 0 < p)
    (h : ∀ ε : ℝ, 0 < ε → ∃ C : ℝ, 0 ≤ C ∧ ∀ R, 2 ≤ R →
      (localConstant μ ζ p R).toReal ≤ C * R ^ ε) : LocalRestriction μ ζ p := by
  intro ε hε
  obtain ⟨C, hC, hb⟩ := h ε hε
  refine ⟨⟨C, hC⟩, fun R hR x f hf => ?_⟩
  have he := ENNReal.ofReal_le_ofReal (hb R hR)
  rw [ENNReal.ofReal_toReal (localConstant_ne_top μ ζ hp), ENNReal.ofReal_mul hC] at he
  calc
    eLpNorm' (extensionProduct μ ζ f) p (volume.restrict (Metric.ball x R)) ≤
        localConstant μ ζ p R * inputNormProduct μ f := localConstant_spec μ ζ hp x hf
    _ ≤ (ENNReal.ofReal C * ENNReal.ofReal (R ^ ε)) * inputNormProduct μ f :=
      mul_le_mul_right' he _
    _ = _ := by rw [ENNReal.ofReal_eq_coe_nnreal hC]

/-- The analytic-to-scalar interface for Section 8. Only the geometric recurrence
remains an input: finiteness, bounded-radius initialization, root extraction,
all centers, and the conversion to `LocalRestriction` are proved. -/
theorem localRestriction_of_recurrences [∀ i, IsFiniteMeasure (μ i)] {p : ℝ}
    (hp : 0 < p)
    (hrec : ∀ ε : ℝ, 0 < ε → ∃ C D a τ : ℝ,
      0 < C ∧ 0 ≤ D ∧ a < ε * p ∧ 0 < τ ∧ τ < 1 / 2 ∧
      ∀ᶠ R : ℝ in Filter.atTop,
        localPowerConstant μ ζ p R ≤
          1 / 4 * localPowerConstant μ ζ p (R / 2) +
          C * localPowerConstant μ ζ p (R ^ (1 - τ)) +
          C * localPowerConstant μ ζ p (C * R ^ (1 / 2 + τ)) + D * R ^ a) :
    LocalRestriction μ ζ p := by
  apply localRestriction_of_constant_growth μ ζ hp
  intro ε hε
  obtain ⟨C, D, a, τ, hC, hD, ha, hτ, hτ', hr⟩ := hrec ε hε
  obtain ⟨K, hK, hb⟩ := power_recurrence_growth (localPowerConstant μ ζ p) C D (ε * p) a τ
    hC hD (mul_pos hε hp) ha hτ hτ' (localPowerConstant_locally_bounded μ ζ hp) hr
  refine ⟨K ^ (1 / p), Real.rpow_nonneg hK _, fun R hR => ?_⟩
  exact growth_from_power_bound (fun R => (localConstant μ ζ p R).toReal) hp hK
    (fun _ _ => ENNReal.toReal_nonneg) hb R (by linarith)

end
end N2Restriction
