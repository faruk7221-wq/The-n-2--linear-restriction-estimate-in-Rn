import N2Restriction.CoordinatePacketFamily

namespace N2Restriction
open MeasureTheory Set

/-- A single family of constructed partitions for all physical scales.
The choice and its count constant are independent of every decay order. -/
theorem exists_coordinate_packet_scales {d : ℕ} {K : Set (Ambient d)} (hK : IsCompact K) :
    ∃ A : ℝ, 0 ≤ A ∧ ∃ P : (R : ℝ) → 1 ≤ R → CoordinateCapFamily K (R ^ (-1 / 2 : ℝ)),
      ∀ (R : ℝ) (hR : 1 ≤ R), ((P R hR).centers.card : ℝ) ≤ A * R ^ ((d : ℝ) / 2) := by
  classical
  obtain ⟨A, hA, hfamilies⟩ := exists_coordinate_cap_families hK
  have hex (R : ℝ) (hR : 1 ≤ R) : ∃ P : CoordinateCapFamily K (R ^ (-1 / 2 : ℝ)),
      (P.centers.card : ℝ) ≤ A * R ^ ((d : ℝ) / 2) := by
    have hRp : 0 < R := by linarith
    obtain ⟨P, hP⟩ := hfamilies (R ^ (-1 / 2 : ℝ)) (Real.rpow_pos_of_pos hRp _)
      (Real.rpow_le_one_of_one_le_of_nonpos hR (by norm_num))
    refine ⟨P, ?_⟩
    rw [← Real.rpow_mul hRp.le] at hP
    simpa only [show (-1 / 2 : ℝ) * (-(d : ℝ)) = (d : ℝ) / 2 by ring] using hP
  exact ⟨A, hA, fun R hR => (hex R hR).choose, fun R hR => (hex R hR).choose_spec⟩

/-- Rapid selected tails for a coordinate cap family, with its actual original input.
Only the explicit count bound remains to be supplied by the constructed scale family. -/
theorem coordinate_family_rapid_tail {d : ℕ} {U : Set (Ambient d)} (hU : IsOpen U)
    {φ : Ambient d → ℝ} (hφ : ContDiffOn ℝ (⊤ : ℕ∞) φ U)
    (z : Ambient d) {a b : ℝ} (ha : 0 < a) (hab : a < b)
    (hball : Metric.closedBall z b ⊆ U) {K : Set (Ambient d)} (hK : IsCompact K)
    (hcenter : K ⊆ Metric.ball z (a / 2)) {τ : ℝ} (hτ : 0 < τ) :
    ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ N : ℝ, ∃ C : ℝ, 0 ≤ C ∧
      ∀ (R : ℝ), R₀ ≤ R → ∀ (P : CoordinateCapFamily K (R ^ (-1 / 2 : ℝ)))
      (hr : 0 < R ^ (-1 / 2 : ℝ)) (A : ℝ), 0 ≤ A →
      (P.centers.card : ℝ) ≤ A * R ^ ((d : ℝ) / 2) →
      ∀ (f : Lp ℂ 2 (volume : Measure (Ambient d))) (u : Ambient d) (t : ℝ), |t| ≤ R →
      ∀ S : P.centers → Set (Fin d → ℤ),
      (∀ j ν, ν ∈ S j → R ^ (1 / 2 + τ) / 10 ≤ Metric.infDist (graphPoint u t)
        (packetSegment (graphGradient φ (j : Ambient d))
          ((R ^ (-1 / 2 : ℝ))⁻¹ • latticeVector ν) R)) →
      (∑ j, ∑' ν : S j, ‖extension volume (fun ξ => graphPoint ξ (φ ξ))
        (P.packet hr f j ν) (graphPoint u t)‖) ≤ C * Real.sqrt A * R ^ (-N) * ‖f‖ := by
  obtain ⟨R₀, hR₀, htail⟩ := actual_finite_cap_rapid_tail hU hφ z ha hab hball hK hcenter hτ
  refine ⟨R₀, hR₀, fun N => ?_⟩
  obtain ⟨C, hC, hb⟩ := htail ((d : ℝ) / 2) N
  refine ⟨C, hC, ?_⟩
  intro R hR P hr A hA hcount f u t ht S hS
  have h := hb R hR (fun j : P.centers => (j : Ambient d)) (fun j => P.centers_mem j.property)
    hr (P.input hr f) u t ht A 1 ‖f‖ hA (by norm_num) (norm_nonneg _) (by simpa using hcount)
    (by simpa only [one_mul] using P.input_energy hr f) S hS
  simpa only [CoordinateCapFamily.packet, CoordinateCapFamily.input, partitionPacket,
    Real.sqrt_one, mul_one] using h

/-- The rapid-tail theorem with both the cap family and all count/energy budgets constructed.
The scale-family choice precedes R₀ and every decay order. -/
theorem exists_coordinate_packet_rapid_family {d : ℕ} {U : Set (Ambient d)} (hU : IsOpen U)
    {φ : Ambient d → ℝ} (hφ : ContDiffOn ℝ (⊤ : ℕ∞) φ U)
    (z : Ambient d) {a b : ℝ} (ha : 0 < a) (hab : a < b)
    (hball : Metric.closedBall z b ⊆ U) {K : Set (Ambient d)} (hK : IsCompact K)
    (hcenter : K ⊆ Metric.ball z (a / 2)) {τ : ℝ} (hτ : 0 < τ) :
    ∃ P : (R : ℝ) → 1 ≤ R → CoordinateCapFamily K (R ^ (-1 / 2 : ℝ)),
      ∃ R₀ : ℝ, ∃ hR₀ : 1 ≤ R₀, ∀ N : ℝ, ∃ C : ℝ, 0 ≤ C ∧
      ∀ (R : ℝ) (hR : R₀ ≤ R) (hr : 0 < R ^ (-1 / 2 : ℝ))
      (f : Lp ℂ 2 (volume : Measure (Ambient d))) (u : Ambient d) (t : ℝ), |t| ≤ R →
      ∀ S : (P R (hR₀.trans hR)).centers → Set (Fin d → ℤ),
      (∀ j ν, ν ∈ S j → R ^ (1 / 2 + τ) / 10 ≤ Metric.infDist (graphPoint u t)
        (packetSegment (graphGradient φ (j : Ambient d))
          ((R ^ (-1 / 2 : ℝ))⁻¹ • latticeVector ν) R)) →
      (∑ j, ∑' ν : S j, ‖extension volume (fun ξ => graphPoint ξ (φ ξ))
        ((P R (hR₀.trans hR)).packet hr f j ν) (graphPoint u t)‖) ≤ C * R ^ (-N) * ‖f‖ := by
  obtain ⟨A, hA, P, hcount⟩ := exists_coordinate_packet_scales hK
  obtain ⟨R₀, hR₀, htail⟩ := coordinate_family_rapid_tail hU hφ z ha hab hball hK hcenter hτ
  refine ⟨P, R₀, hR₀, fun N => ?_⟩
  obtain ⟨C, hC, hb⟩ := htail N
  refine ⟨C * Real.sqrt A, mul_nonneg hC (Real.sqrt_nonneg _), ?_⟩
  intro R hR hr f u t ht S hS
  exact hb R hR (P R (hR₀.trans hR)) hr A hA (hcount R (hR₀.trans hR)) f u t ht S hS

/-- Absolute convergence for every selected cap packet extension at all sufficiently
large physical scales. There is no tube-exclusion condition in this assertion. -/
theorem coordinate_family_absolute_convergence {d : ℕ} {U : Set (Ambient d)} (hU : IsOpen U)
    {φ : Ambient d → ℝ} (hφ : ContDiffOn ℝ (⊤ : ℕ∞) φ U)
    (z : Ambient d) {a b : ℝ} (ha : 0 < a) (hab : a < b)
    (hball : Metric.closedBall z b ⊆ U) {K : Set (Ambient d)} (hK : IsCompact K)
    (hcenter : K ⊆ Metric.ball z (a / 2)) :
    ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ (R : ℝ), R₀ ≤ R →
      ∀ (P : CoordinateCapFamily K (R ^ (-1 / 2 : ℝ))) (hr : 0 < R ^ (-1 / 2 : ℝ))
      (f : Lp ℂ 2 (volume : Measure (Ambient d))) (u : Ambient d) (t : ℝ), |t| ≤ R →
      ∀ (j : P.centers) (S : Set (Fin d → ℤ)),
      Summable (fun ν : S => ‖extension volume (fun ξ => graphPoint ξ (φ ξ))
        (P.packet hr f j ν) (graphPoint u t)‖) := by
  obtain ⟨r₀, hr₀, htail⟩ := actualPacketInput_selected_tail hU hφ z ha hab hball hK hcenter
  obtain ⟨R₀, hR₀, hsmall⟩ := exists_parabolic_radius_threshold hr₀
  obtain ⟨C, hC, hb⟩ := htail 0
  refine ⟨R₀, hR₀, ?_⟩
  intro R hR P hr f u t ht j S
  have hRp : 0 < R := by have := hR₀.trans hR; linarith
  exact (hb j.val (P.centers_mem j.property) (R ^ (-1 / 2 : ℝ)) hr (hsmall R hR)
    (P.input hr f j) u t 0 (parabolic_time_parameter hRp ht) (by norm_num) S
    (fun ν _ => norm_nonneg _)).1

end N2Restriction
