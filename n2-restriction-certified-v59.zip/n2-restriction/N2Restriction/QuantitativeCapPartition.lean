import N2Restriction.CapPartition
import N2Restriction.CapPacking

namespace N2Restriction
open MeasureTheory Metric Set

/-- The geometric packing count as the pointwise indicator bound needed by synthesis. -/
theorem separated_cap_indicator_overlap {d : ℕ} (t : Finset (Ambient d)) {r : ℝ} (hr : 0 < r)
    (hsep : (↑t : Set (Ambient d)).Pairwise (fun x y => r / 2 < dist x y)) (x : Ambient d) :
    (∑ j : t, (ball (j : Ambient d) (2 * r)).indicator (fun _ => (1 : ℝ)) x) ≤ 9 ^ d := by
  classical
  have he : (∑ j : t, (ball (j : Ambient d) (2 * r)).indicator (fun _ => (1 : ℝ)) x) =
      ((t.filter (fun c => x ∈ ball c (2 * r))).card : ℝ) := by
    simp only [Set.indicator_apply]
    change (∑ j ∈ t.attach, if x ∈ ball (j : Ambient d) (2 * r) then (1 : ℝ) else 0) = _
    rw [Finset.sum_attach t (fun c => if x ∈ ball c (2 * r) then (1 : ℝ) else 0)]
    simp
  rw [he]
  exact separated_cap_overlap t hr hsep x

/-- A quantitative smooth partition: centers in K, correct cap count, bounded
expanded overlap, smooth radius-r supports and a squared-weight budget of one. -/
theorem quantitative_cap_partition {d : ℕ} {K : Set (Ambient d)} (hK : IsCompact K)
    (z : Ambient d) {D r : ℝ} (hD : 0 ≤ D) (hKD : ∀ x ∈ K, dist x z ≤ D)
    (hr : 0 < r) (hr1 : r ≤ 1) :
    ∃ (t : Finset (Ambient d)) (ρ : PartitionOfUnity t (Ambient d) K),
      (↑t : Set (Ambient d)) ⊆ K ∧
      (t.card : ℝ) ≤ (4 * D + 1) ^ d * r ^ (-(d : ℝ)) ∧
      (∀ x, (∑ j : t, (ball (j : Ambient d) (2 * r)).indicator (fun _ => (1 : ℝ)) x) ≤ 9 ^ d) ∧
      (∀ j, ContDiff ℝ (⊤ : ℕ∞) (ρ j)) ∧
      (∀ j, Function.support (ρ j) ⊆ ball (j : Ambient d) r) ∧
      (∀ x, (∑ j, (ρ j x) ^ 2) ≤ 1) := by
  obtain ⟨t, ρ, htK, hsep, hsmooth, hsupp, henergy⟩ := exists_compact_cap_partition hK hr
  exact ⟨t, ρ, htK, separated_cap_count t z hr hr1 hD hsep (fun c hc => hKD c (htK hc)),
    separated_cap_indicator_overlap t hr hsep, hsmooth, hsupp, henergy⟩

/-- The cap count has the required R^(d/2) growth at packet scale r=R^(-1/2). -/
theorem packet_scale_cap_count {d : ℕ} {D R : ℝ} (hR : 1 ≤ R)
    (t : Finset (Ambient d))
    (ht : (t.card : ℝ) ≤ (4 * D + 1) ^ d * (R ^ (-1 / 2 : ℝ)) ^ (-(d : ℝ))) :
    (t.card : ℝ) ≤ (4 * D + 1) ^ d * R ^ ((d : ℝ) / 2) := by
  have hR0 : 0 ≤ R := by linarith
  rw [← Real.rpow_mul hR0] at ht
  simpa only [show (-1 / 2 : ℝ) * (-(d : ℝ)) = (d : ℝ) / 2 by ring] using ht

end N2Restriction
