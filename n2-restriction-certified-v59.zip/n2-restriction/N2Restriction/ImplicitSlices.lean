import N2Restriction.UniformImplicit
import Mathlib.Analysis.Normed.Operator.Prod

namespace N2Restriction
open Metric Filter

/-- Differentiable local left inverses force injectivity of the derivative. -/
theorem fderiv_injective_of_local_left_inverse {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    {f : E → F} {g : F → E} {x : E}
    (hf : DifferentiableAt ℝ f x) (hg : DifferentiableAt ℝ g (f x))
    (hleft : g ∘ f =ᶠ[nhds x] id) : Function.Injective (fderiv ℝ f x) := by
  have hcomp := hg.hasFDerivAt.comp x hf.hasFDerivAt
  have hid : HasFDerivAt (g ∘ f) (ContinuousLinearMap.id ℝ E) x :=
    (hasFDerivAt_id x).congr_of_eventuallyEq hleft
  have hD := hcomp.unique hid
  intro u v huv
  have hu := congrArg (fun L : E →L[ℝ] E => L u) hD
  have hv := congrArg (fun L : E →L[ℝ] E => L v) hD
  simp only [ContinuousLinearMap.comp_apply, ContinuousLinearMap.id_apply] at hu hv
  rw [huv] at hu
  exact hu.symm.trans hv

/-- A controlled chart for the augmented constraint gives an injective smooth
parametrization of the original level set, with the parameter fixed exactly.
All derivative bounds use the same radius. -/
theorem ControlledSubmersionChart.parameter_parametrization {P E F : Type*}
    [NormedAddCommGroup P] [NormedSpace ℝ P] [FiniteDimensional ℝ P]
    [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    {f : P × E → F} {U : Set (P × E)} {q : P × E} {r : ℝ} {B : ℕ → ℝ}
    (hUopen : IsOpen U) (hr : 0 < r)
    (h : ControlledSubmersionChart (fun q => (q.1, f q)) U q r B) :
    ∃ K : Submodule ℝ (P × E),
      Module.finrank ℝ K + Module.finrank ℝ F = Module.finrank ℝ E ∧
      (∀ v : K, (v : P × E).1 = 0) ∧
      ∃ φ : K → E, φ 0 = q.2 ∧
        Set.InjOn φ (closedBall 0 r) ∧
        (∀ t ∈ closedBall 0 r, (q.1, φ t) ∈ U ∧ f (q.1, φ t) = f q ∧
          ContDiffAt ℝ (⊤ : ℕ∞) φ t ∧ Function.Injective (fderiv ℝ φ t)) ∧
        (∀ m t, t ∈ closedBall 0 r → ‖iteratedFDeriv ℝ m φ t‖ ≤ B m) ∧
        ∀ᶠ y in nhds q.2, f (q.1, y) = f q →
          ∃ t ∈ ball 0 r, φ t = y := by
  obtain ⟨K, e, hd, hker, hq, _, he, hforward, ht, hU, hs, hB, _hF⟩ := h
  let a := e q
  let g : K →L[ℝ] (P × F) × K := ContinuousLinearMap.inr ℝ (P × F) K
  let ψ : K → P × E := fun t => e.symm (a + g t)
  let φ : K → E := fun t => (ψ t).2
  have hg : ‖g‖ ≤ 1 := by
    apply ContinuousLinearMap.opNorm_le_bound _ zero_le_one
    intro t
    simp [g, Prod.norm_def]
  have hslice : ∀ t ∈ closedBall (0 : K) r, a + g t ∈ closedBall a r := by
    intro t ht'
    simpa [Metric.mem_closedBall, dist_eq_norm, g, Prod.norm_def] using ht'
  have htarget : ∀ t ∈ closedBall (0 : K) r, a + g t ∈ e.target :=
    fun t ht' => ht (hslice t ht')
  have hpsi : ∀ t ∈ closedBall (0 : K) r,
      (ψ t).1 = q.1 ∧ f (ψ t) = f q := by
    intro t ht'
    have hfirst := congrArg Prod.fst (e.right_inv (htarget t ht'))
    rw [he] at hfirst
    have ha : (a + g t).1 = (q.1, f q) := by
      simpa [a, g] using he q
    rw [ha] at hfirst
    exact ⟨congrArg (fun w : P × F => w.1) hfirst,
      congrArg (fun w : P × F => w.2) hfirst⟩
  have hpair : ∀ t ∈ closedBall (0 : K) r, (q.1, φ t) = ψ t := by
    intro t ht'
    exact Prod.ext (hpsi t ht').1.symm rfl
  have hsm : ∀ t ∈ closedBall (0 : K) r, ContDiffAt ℝ (⊤ : ℕ∞) ψ t := by
    intro t ht'
    exact (hs _ (hslice t ht')).comp t (contDiffAt_const.add g.contDiff.contDiffAt)
  simp only [Module.finrank_prod] at hd
  have hvertical : ∀ v : K, (v : P × E).1 = 0 := by
    obtain ⟨z, hz, hK⟩ := hker
    have hfwd : ContDiffOn ℝ (⊤ : ℕ∞) (fun q => (q.1, f q)) U := by
      have hfst := hforward.fst
      exact hfst.congr (fun y _ => (he y).symm)
    have hdiff : DifferentiableAt ℝ (fun q => (q.1, f q)) z := by
      exact (hfwd.contDiffAt (hUopen.mem_nhds hz)).differentiableAt (by simp)
    intro v
    have hv : fderiv ℝ (fun q => (q.1, f q)) z v = 0 := by
      exact (hK ▸ v.property : (v : P × E) ∈ LinearMap.ker
        (fderiv ℝ (fun q => (q.1, f q)) z).toLinearMap)
    have hfst := hdiff.hasFDerivAt.fst
    have hfstEq := hfst.unique (hasFDerivAt_fst (𝕜 := ℝ) (p := z))
    have hvfst := congrArg (fun w : P × F => w.1) hv
    change ((ContinuousLinearMap.fst ℝ P F).comp
      (fderiv ℝ (fun q => (q.1, f q)) z)) v = 0 at hvfst
    rw [hfstEq] at hvfst
    exact hvfst
  refine ⟨K, by omega, hvertical, φ, ?_, ?_, ?_, ?_, ?_⟩
  · simp [φ, ψ, a, e.left_inv hq]
  · intro s hs' t ht' heq
    have hψ : ψ s = ψ t := by
      rw [← hpair s hs', ← hpair t ht', heq]
    have haa := congrArg e hψ
    change e (e.symm (a + g s)) = e (e.symm (a + g t)) at haa
    rw [e.right_inv (htarget s hs'), e.right_inv (htarget t ht')] at haa
    have hst := congrArg Prod.snd haa
    simpa [g] using hst
  · intro t ht'
    refine ⟨?_, ?_, (hsm t ht').snd, ?_⟩
    · rw [hpair t ht']
      exact hU (hslice t ht')
    · rw [hpair t ht']
      exact (hpsi t ht').2
    · let c : E → K := fun y => (e (q.1, y)).2 - a.2
      have hUt : (q.1, φ t) ∈ U := by
        rw [hpair t ht']
        exact hU (hslice t ht')
      have hc : ContDiffAt ℝ (⊤ : ℕ∞) c (φ t) :=
        (((hforward.contDiffAt (hUopen.mem_nhds hUt)).comp (φ t)
          (contDiffAt_const.prodMk contDiffAt_id)).snd).sub contDiffAt_const
      have hleft : c ∘ φ =ᶠ[nhds t] id := by
        have hn := (continuousAt_const.add g.continuous.continuousAt).preimage_mem_nhds
          (e.open_target.mem_nhds (htarget t ht'))
        filter_upwards [hn] with s hs'
        have hfirst := congrArg Prod.fst (e.right_inv hs')
        rw [he] at hfirst
        have ha : (a + g s).1 = (q.1, f q) := by simpa [a, g] using he q
        rw [ha] at hfirst
        have hp : (e.symm (a + g s)).1 = q.1 := congrArg (fun w : P × F => w.1) hfirst
        change (e (q.1, (e.symm (a + g s)).2)).2 - a.2 = s
        rw [← hp, e.right_inv hs']
        simp [g]
      exact fderiv_injective_of_local_left_inverse ((hsm t ht').snd.differentiableAt (by simp))
        (hc.differentiableAt (by simp)) hleft
  · intro m t ht'
    have hp := norm_iteratedFDeriv_contraction_comp (ContinuousLinearMap.snd ℝ P E)
      (ContinuousLinearMap.norm_snd_le ..) m (hsm t ht')
    have ha := norm_iteratedFDeriv_affine_slice g hg a m (hs _ (hslice t ht'))
    exact hp.trans (ha.trans (hB m _ (hslice t ht')))
  · have hnear : ∀ᶠ y in nhds q.2,
        (q.1, y) ∈ e.source ∧ e (q.1, y) ∈ ball a r := by
      have hp : ContinuousAt (fun y : E => (q.1, y)) q.2 :=
        continuousAt_const.prodMk continuousAt_id
      have hsrc := hp.preimage_mem_nhds (e.open_source.mem_nhds hq)
      have htar := ((e.continuousAt hq).comp hp).preimage_mem_nhds
        (ball_mem_nhds a hr)
      exact inter_mem hsrc htar
    filter_upwards [hnear] with y hy hfy
    let t : K := (e (q.1, y)).2 - a.2
    have htball : t ∈ ball (0 : K) r := by
      have hdist : dist (e (q.1, y)).2 a.2 ≤ dist (e (q.1, y)) a := by
        rw [Prod.dist_eq]
        exact le_max_right _ _
      have hyball : dist (e (q.1, y)) a < r := hy.2
      change dist t 0 < r
      simpa [t, dist_eq_norm] using hdist.trans_lt hyball
    have hcoords : a + g t = e (q.1, y) := by
      apply Prod.ext
      · simp [a, g, he, hfy]
      · simp [g, t]
    refine ⟨t, htball, ?_⟩
    change (e.symm (a + g t)).2 = y
    rw [hcoords, e.left_inv hy.1]

/-- The vertical kernel carries exactly the norm of its physical component. -/
def verticalSubmoduleIsometry {P E : Type*}
    [NormedAddCommGroup P] [NormedSpace ℝ P]
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    (K : Submodule ℝ (P × E)) (hK : ∀ v : K, (v : P × E).1 = 0) : K →ₗᵢ[ℝ] E where
  toLinearMap := (LinearMap.snd ℝ P E).comp K.subtype
  norm_map' v := by
    change ‖(v : P × E).2‖ = ‖(v : P × E)‖
    rw [Prod.norm_def, hK v, norm_zero, max_eq_right (norm_nonneg _)]

/-- The controlled slices can be written in ordinary Euclidean coordinates,
with the same radius and the same derivative bounds. No norm-equivalence
constants depending on the chart are introduced. -/
theorem ControlledSubmersionChart.parameter_euclidean_parametrization {P E F : Type*}
    [NormedAddCommGroup P] [NormedSpace ℝ P] [FiniteDimensional ℝ P]
    [NormedAddCommGroup E] [InnerProductSpace ℝ E] [FiniteDimensional ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    {f : P × E → F} {U : Set (P × E)} {q : P × E} {r : ℝ} {B : ℕ → ℝ}
    (hUopen : IsOpen U) (hr : 0 < r)
    (h : ControlledSubmersionChart (fun q => (q.1, f q)) U q r B) :
    ∃ φ : EuclideanSpace ℝ (Fin (Module.finrank ℝ E - Module.finrank ℝ F)) → E,
      φ 0 = q.2 ∧ Set.InjOn φ (closedBall 0 r) ∧
      (∀ t ∈ closedBall 0 r, (q.1, φ t) ∈ U ∧ f (q.1, φ t) = f q ∧
        ContDiffAt ℝ (⊤ : ℕ∞) φ t ∧ Function.Injective (fderiv ℝ φ t)) ∧
      (∀ m t, t ∈ closedBall 0 r → ‖iteratedFDeriv ℝ m φ t‖ ≤ B m) ∧
      ∀ᶠ y in nhds q.2, f (q.1, y) = f q → ∃ t ∈ ball 0 r, φ t = y := by
  obtain ⟨K, hd, hv, φ, hφ0, hinj, hφ, hb, hcover⟩ :=
    h.parameter_parametrization hUopen hr
  let j := verticalSubmoduleIsometry K hv
  let V := LinearMap.range j.toLinearMap
  let i : K ≃ₗᵢ[ℝ] V := j.equivRange
  have hdim : Module.finrank ℝ V = Module.finrank ℝ E - Module.finrank ℝ F := by
    have hi := i.toLinearEquiv.finrank_eq
    omega
  let A : EuclideanSpace ℝ (Fin (Module.finrank ℝ E - Module.finrank ℝ F)) ≃ₗᵢ[ℝ] K := by
    rw [← hdim]
    exact (stdOrthonormalBasis ℝ V).repr.symm.trans i.symm
  have hA : ∀ t, t ∈ closedBall 0 r → A t ∈ closedBall 0 r := by
    intro t ht
    simpa [Metric.mem_closedBall, dist_zero_right] using ht
  refine ⟨φ ∘ A, by simpa using hφ0, ?_, ?_, ?_, ?_⟩
  · intro s hs t ht hst
    exact A.injective (hinj (hA s hs) (hA t ht) hst)
  · intro t ht
    obtain ⟨hU, hf, hs, hi⟩ := hφ (A t) (hA t ht)
    refine ⟨hU, hf, hs.comp t A.contDiff.contDiffAt, ?_⟩
    rw [fderiv_comp t (hs.differentiableAt (by simp)) A.differentiableAt,
      A.fderiv]
    exact hi.comp A.injective
  · intro m t ht
    rw [A.norm_iteratedFDeriv_comp_right φ t m]
    exact hb m (A t) (hA t ht)
  · filter_upwards [hcover] with y hy hfy
    obtain ⟨t, ht, he⟩ := hy hfy
    refine ⟨A.symm t, ?_, ?_⟩
    · simpa [Metric.mem_ball, dist_zero_right] using ht
    · simpa using he

end N2Restriction
