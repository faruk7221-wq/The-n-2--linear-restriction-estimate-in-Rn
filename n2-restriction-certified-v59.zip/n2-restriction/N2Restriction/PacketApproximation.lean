import N2Restriction.PacketRegularity
import N2Restriction.CoordinateExtension

namespace N2Restriction
open MeasureTheory Set Filter
open scoped Topology
set_option maxHeartbeats 400000

/-- A cofinal increasing sequence of finite subsets of any countable index type. -/
noncomputable def countableExhaustion (ι : Type*) [Countable ι] (n : ℕ) : Finset ι := by
  letI := Encodable.ofCountable ι
  exact (Finset.range n).preimage Encodable.encode Encodable.encode_injective.injOn

theorem countableExhaustion_tendsto (ι : Type*) [Countable ι] :
    Tendsto (countableExhaustion ι) atTop atTop := by
  letI := Encodable.ofCountable ι
  exact (tendsto_finset_preimage_atTop_atTop Encodable.encode_injective).comp tendsto_finset_range

namespace CoordinateCapFamily
variable {d : ℕ} {K : Set (Ambient d)} {r : ℝ} (P : CoordinateCapFamily K r)

noncomputable def smoothApproximation (hr : 0 < r)
    (f : Lp ℂ 2 (volume : Measure (Ambient d))) (n : ℕ) (x : Ambient d) : ℂ :=
  ∑ p ∈ countableExhaustion (P.centers × (Fin d → ℤ)) n, P.smoothPacket hr f p.1 p.2 x

noncomputable def approximationL2 (hr : 0 < r)
    (f : Lp ℂ 2 (volume : Measure (Ambient d))) (n : ℕ) : Lp ℂ 2 (volume : Measure (Ambient d)) :=
  ∑ p ∈ countableExhaustion (P.centers × (Fin d → ℤ)) n, P.packet hr f p.1 p.2

theorem smoothApproximation_regular (hr : 0 < r)
    (f : Lp ℂ 2 (volume : Measure (Ambient d))) (n : ℕ) :
    ContDiff ℝ (⊤ : ℕ∞) (P.smoothApproximation hr f n) ∧
      HasCompactSupport (P.smoothApproximation hr f n) :=
  P.finite_packet_sum_smooth hr f _

theorem approximationL2_coe (hr : 0 < r)
    (f : Lp ℂ 2 (volume : Measure (Ambient d))) (n : ℕ) :
    P.approximationL2 hr f n =ᵐ[volume] P.smoothApproximation hr f n :=
  P.finite_packet_sum_coe hr f _

/-- The approximation is strong in L2, with no smoothness assumption on the original input. -/
theorem approximationL2_tendsto (hr : 0 < r)
    (f : Lp ℂ 2 (volume : Measure (Ambient d))) (hf : HasFrequencySupport volume id K f) :
    Tendsto (P.approximationL2 hr f) atTop (𝓝 f) :=
  (P.packet_hasSum_original hr f hf).comp (countableExhaustion_tendsto _)

/-- Smooth representative energy converges to the original L2 energy. -/
theorem smoothApproximation_energy_tendsto (hr : 0 < r)
    (f : Lp ℂ 2 (volume : Measure (Ambient d))) (hf : HasFrequencySupport volume id K f) :
    Tendsto (fun n => ∫ x, ‖P.smoothApproximation hr f n x‖ ^ 2) atTop (𝓝 (‖f‖ ^ 2)) := by
  have he (n : ℕ) : (∫ x, ‖P.smoothApproximation hr f n x‖ ^ 2) =
      ‖P.approximationL2 hr f n‖ ^ 2 := by
    rw [l2_norm_sq_eq_integral]
    exact integral_congr_ae ((P.approximationL2_coe hr f n).mono fun x hx => by dsimp only; rw [hx])
  simp_rw [he]
  exact (P.approximationL2_tendsto hr f hf).norm.pow 2

/-- Taking the extension commutes with these finite smooth approximants. -/
theorem smoothApproximation_extension {n : ℕ} (hr : 0 < r)
    (f : Lp ℂ 2 (volume : Measure (Ambient d))) (ζ : Ambient d → Ambient n)
    (hζ : Measurable ζ) (k : ℕ) (y : Ambient n) :
    extension volume ζ (P.smoothApproximation hr f k) y =
      ∑ p ∈ countableExhaustion (P.centers × (Fin d → ℤ)) k,
        extension volume ζ (P.packet hr f p.1 p.2) y := by
  have hI (p : P.centers × (Fin d → ℤ)) : Integrable (fun x =>
      Complex.exp ((inner ℝ y (ζ x) : ℂ) * Complex.I) * P.smoothPacket hr f p.1 p.2 x) := by
    have hsm := P.smoothPacket_smooth hr f p.1 p.2
    have hcp := P.smoothPacket_compact hr f p.1 p.2
    have hi : Integrable (P.smoothPacket hr f p.1 p.2) volume :=
      hsm.continuous.integrable_of_hasCompactSupport hcp
    exact integrable_extension_kernel hζ hi y
  unfold extension smoothApproximation
  simp_rw [Finset.mul_sum]
  rw [integral_finset_sum _ (fun p _ => hI p)]
  apply Finset.sum_congr rfl
  intro p _
  exact integral_congr_ae ((P.smoothPacket_coe hr f p.1 p.2).mono fun x hx => by dsimp only; rw [hx])

/-- The same approximants converge pointwise in physical space, uniformly before evaluation. -/
theorem smoothApproximation_extension_tendsto {n : ℕ} (hr : 0 < r) (hK : IsCompact K)
    (f : Lp ℂ 2 (volume : Measure (Ambient d))) (hf : HasFrequencySupport volume id K f)
    (ζ : Ambient d → Ambient n) (hζ : Measurable ζ) (y : Ambient n) :
    Tendsto (fun k => extension volume ζ (P.smoothApproximation hr f k) y)
      atTop (𝓝 (extension volume ζ f y)) := by
  simp_rw [P.smoothApproximation_extension hr f ζ hζ]
  rw [Metric.tendsto_nhds]
  intro ε hε
  exact (countableExhaustion_tendsto _).eventually
    ((P.packet_uniform_extension_reconstruction hK hr f hf ζ hζ ε hε).mono fun S hS => hS y)

end CoordinateCapFamily
end N2Restriction
