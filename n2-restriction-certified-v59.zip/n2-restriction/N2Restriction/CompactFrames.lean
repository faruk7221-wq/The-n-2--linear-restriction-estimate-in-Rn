import N2Restriction.FrameCurvatureCorrection
import N2Restriction.UniformTransversality
import Mathlib.Analysis.InnerProductSpace.Continuous
import Mathlib.Analysis.Normed.Operator.Prod
import Mathlib.Topology.MetricSpace.Bounded

/-! Compact coordinates for the two-dimensional planes used in the thin-support
argument. We retain all orthonormal frames, so there is no global choice of a
basis over a plane family. -/

namespace N2Restriction

/-- The concrete Stiefel space of ordered orthonormal pairs in the ambient
Euclidean space. -/
def orthonormalPairSet (n : ℕ) : Set (Ambient n × Ambient n) :=
  {p | ‖p.1‖ = 1 ∧ ‖p.2‖ = 1 ∧ inner ℝ p.1 p.2 = 0}

/-- The two-plane spanned by a pair of ambient vectors. -/
def pairPlane {n : ℕ} (p : Ambient n × Ambient n) : Submodule ℝ (Ambient n) :=
  Submodule.span ℝ ({p.1, p.2} : Set (Ambient n))

private def pairFrameVector {n : ℕ} (p : Ambient n × Ambient n) (i : Fin 2) : Ambient n :=
  if i = 0 then p.1 else p.2

theorem isClosed_orthonormalPairSet (n : ℕ) :
    IsClosed (orthonormalPairSet n) := by
  change IsClosed
    ({p : Ambient n × Ambient n | ‖p.1‖ = 1} ∩
      ({p | ‖p.2‖ = 1} ∩ {p | inner ℝ p.1 p.2 = 0}))
  refine (isClosed_eq (continuous_norm.comp continuous_fst) continuous_const).inter ?_
  refine (isClosed_eq (continuous_norm.comp continuous_snd) continuous_const).inter ?_
  exact isClosed_eq continuous_inner continuous_const

theorem isCompact_orthonormalPairSet (n : ℕ) :
    IsCompact (orthonormalPairSet n) := by
  rw [Metric.isCompact_iff_isClosed_bounded]
  refine ⟨isClosed_orthonormalPairSet n, ?_⟩
  rw [Metric.isBounded_iff_subset_closedBall (0 : Ambient n × Ambient n)]
  refine ⟨2, ?_⟩
  intro p hp
  change dist p 0 ≤ 2
  rw [dist_zero_right, Prod.norm_def]
  simp [orthonormalPairSet] at hp
  simp [hp.1, hp.2.1]

/-- Read an ambient vector in the two coordinates supplied by an orthonormal
pair. -/
noncomputable def pairFrameMap {n : ℕ} (p : Ambient n × Ambient n) :
    Ambient n →L[ℝ] (ℝ × ℝ) :=
  (innerSL ℝ p.1).prod (innerSL ℝ p.2)

/-- The rank-two orthogonal projection written in frame coordinates. -/
noncomputable def pairProjection {n : ℕ} (p : Ambient n × Ambient n) :
    Ambient n →L[ℝ] Ambient n :=
  (innerSL ℝ p.1).smulRight p.1 + (innerSL ℝ p.2).smulRight p.2

@[simp] theorem pairProjection_apply {n : ℕ} (p : Ambient n × Ambient n)
    (x : Ambient n) :
    pairProjection p x = inner ℝ p.1 x • p.1 + inner ℝ p.2 x • p.2 := by
  simp [pairProjection, innerSL_apply]

theorem continuous_pairProjection (n : ℕ) :
    Continuous (pairProjection (n := n)) := by
  change Continuous (fun p : Ambient n × Ambient n =>
    (innerSL ℝ p.1).smulRight p.1 + (innerSL ℝ p.2).smulRight p.2)
  have h₁ : Continuous (fun p : Ambient n × Ambient n =>
      (ContinuousLinearMap.smulRightL ℝ (Ambient n) (Ambient n))
        (innerSL ℝ p.1) p.1) := by
    exact (ContinuousLinearMap.continuous₂
      (ContinuousLinearMap.smulRightL ℝ (Ambient n) (Ambient n))).comp
        (((innerSL ℝ).continuous.comp continuous_fst).prodMk continuous_fst)
  have h₂ : Continuous (fun p : Ambient n × Ambient n =>
      (ContinuousLinearMap.smulRightL ℝ (Ambient n) (Ambient n))
        (innerSL ℝ p.2) p.2) := by
    exact (ContinuousLinearMap.continuous₂
      (ContinuousLinearMap.smulRightL ℝ (Ambient n) (Ambient n))).comp
        (((innerSL ℝ).continuous.comp continuous_snd).prodMk continuous_snd)
  simpa only [ContinuousLinearMap.smulRightL, ContinuousLinearMap.smulRight_apply] using h₁.add h₂

/-- For an orthonormal frame, the displayed rank-two operator is exactly the
orthogonal projection onto its spanned plane. -/
theorem pairProjection_eq_starProjection {n : ℕ} {p : Ambient n × Ambient n}
    (hp : p ∈ orthonormalPairSet n) (x : Ambient n) :
    (pairPlane p).starProjection x = pairProjection p x := by
  rcases hp with ⟨hu, hv, huv⟩
  have huu : inner ℝ p.1 p.1 = 1 := by
    rw [real_inner_self_eq_norm_sq, hu]
    norm_num
  have hvv : inner ℝ p.2 p.2 = 1 := by
    rw [real_inner_self_eq_norm_sq, hv]
    norm_num
  have hvu : inner ℝ p.2 p.1 = 0 := by rw [real_inner_comm, huv]
  have huResidual : inner ℝ (x - pairProjection p x) p.1 = 0 := by
    rw [inner_sub_left, pairProjection_apply, inner_add_left, inner_smul_left,
      inner_smul_left]
    simp [real_inner_comm, huu, hvu]
  have hvResidual : inner ℝ (x - pairProjection p x) p.2 = 0 := by
    rw [inner_sub_left, pairProjection_apply, inner_add_left, inner_smul_left,
      inner_smul_left]
    simp [real_inner_comm, huv, hvv]
  apply (pairPlane p).eq_starProjection_of_mem_of_inner_eq_zero ?_ ?_
  · rw [pairProjection_apply]
    exact Submodule.add_mem _
      (Submodule.smul_mem _ _ (Submodule.subset_span (Set.mem_insert _ _)))
      (Submodule.smul_mem _ _ (Submodule.subset_span (Set.mem_insert_of_mem _ (Set.mem_singleton _))))
  · intro w hw
    change w ∈ Submodule.span ℝ ({p.1, p.2} : Set (Ambient n)) at hw
    refine Submodule.span_induction ?_ ?_ ?_ ?_ hw
    · intro w hw
      simp only [Set.mem_insert_iff, Set.mem_singleton_iff] at hw
      rcases hw with hw | hw
      · rw [hw]
        exact huResidual
      · rw [hw]
        exact hvResidual
    · simp
    · intro u v hu hv huEq hvEq
      rw [inner_add_right, huEq, hvEq, add_zero]
    · intro a u hu huEq
      rw [inner_smul_right, huEq, mul_zero]

/-- Operator-valued version of the frame projection identity. -/
theorem pairProjection_eq_planeProjection {n : ℕ} {p : Ambient n × Ambient n}
    (hp : p ∈ orthonormalPairSet n) :
    pairProjection p = (pairPlane p).starProjection := by
  apply ContinuousLinearMap.ext
  intro x
  exact (pairProjection_eq_starProjection hp x).symm

/-- The frame coordinate map is unchanged by projecting onto its frame plane. -/
theorem pairFrameMap_comp_pairProjection {n : ℕ} {p : Ambient n × Ambient n}
    (hp : p ∈ orthonormalPairSet n) :
    (pairFrameMap p).comp (pairProjection p) = pairFrameMap p := by
  rcases hp with ⟨hu, hv, huv⟩
  have huu : inner ℝ p.1 p.1 = 1 := by
    rw [real_inner_self_eq_norm_sq, hu]
    norm_num
  have hvv : inner ℝ p.2 p.2 = 1 := by
    rw [real_inner_self_eq_norm_sq, hv]
    norm_num
  have hvu : inner ℝ p.2 p.1 = 0 := by rw [real_inner_comm, huv]
  apply ContinuousLinearMap.ext
  intro x
  change (inner ℝ p.1 (pairProjection p x), inner ℝ p.2 (pairProjection p x)) =
    (inner ℝ p.1 x, inner ℝ p.2 x)
  apply Prod.ext
  · change inner ℝ p.1 (pairProjection p x) = inner ℝ p.1 x
    rw [pairProjection_apply, inner_add_right, inner_smul_right, inner_smul_right, huu, huv]
    simp
  · change inner ℝ p.2 (pairProjection p x) = inner ℝ p.2 x
    rw [pairProjection_apply, inner_add_right, inner_smul_right, inner_smul_right, hvu, hvv]
    simp

/-- The frame-coordinate residual is bounded by the length of the projected
vector. The product norm on `ℝ × ℝ` is the maximum of its two coordinates. -/
theorem pairFrameMap_norm_le_projection {n : ℕ} {p : Ambient n × Ambient n}
    (hp : p ∈ orthonormalPairSet n) (x : Ambient n) :
    ‖pairFrameMap p x‖ ≤ ‖pairProjection p x‖ := by
  have hmap : pairFrameMap p (pairProjection p x) = pairFrameMap p x := by
    have h := congrArg (fun T : Ambient n →L[ℝ] (ℝ × ℝ) => T x)
      (pairFrameMap_comp_pairProjection hp)
    simpa only [ContinuousLinearMap.comp_apply] using h
  rw [Prod.norm_def, ← hmap]
  change max ‖inner ℝ p.1 (pairProjection p x)‖
      ‖inner ℝ p.2 (pairProjection p x)‖ ≤ ‖pairProjection p x‖
  rcases hp with ⟨hp₁, hp₂, _⟩
  refine max_le ?_ ?_
  · calc
      ‖inner ℝ p.1 (pairProjection p x)‖ ≤
          ‖p.1‖ * ‖pairProjection p x‖ := norm_inner_le_norm _ _
      _ = ‖pairProjection p x‖ := by rw [hp₁]; norm_num
  · calc
      ‖inner ℝ p.2 (pairProjection p x)‖ ≤
          ‖p.2‖ * ‖pairProjection p x‖ := norm_inner_le_norm _ _
      _ = ‖pairProjection p x‖ := by rw [hp₂]; norm_num

/-- The row coordinates separate points inside the plane spanned by their
orthonormal frame. -/
theorem pairFrameMap_injectiveOnPairPlane {n : ℕ} {p : Ambient n × Ambient n}
    (hp : p ∈ orthonormalPairSet n) {x y : Ambient n}
    (hx : x ∈ pairPlane p) (hy : y ∈ pairPlane p)
    (hxy : pairFrameMap p x = pairFrameMap p y) : x = y := by
  rcases hp with ⟨hu, hv, huv⟩
  have huu : inner ℝ p.1 p.1 = 1 := by
    rw [real_inner_self_eq_norm_sq, hu]
    norm_num
  have hvv : inner ℝ p.2 p.2 = 1 := by
    rw [real_inner_self_eq_norm_sq, hv]
    norm_num
  have hvu : inner ℝ p.2 p.1 = 0 := by rw [real_inner_comm, huv]
  have hzero : pairFrameMap p (x - y) = 0 := by
    rw [map_sub, hxy, sub_self]
  have hcoord₁ : inner ℝ p.1 (x - y) = 0 := by
    have h := congrArg Prod.fst hzero
    simpa [pairFrameMap, innerSL_apply] using h
  have hcoord₂ : inner ℝ p.2 (x - y) = 0 := by
    have h := congrArg Prod.snd hzero
    simpa [pairFrameMap, innerSL_apply] using h
  have hspan : x - y ∈ pairPlane p := Submodule.sub_mem _ hx hy
  change x - y ∈ Submodule.span ℝ ({p.1, p.2} : Set (Ambient n)) at hspan
  obtain ⟨a, b, hab⟩ := Submodule.mem_span_pair.mp hspan
  have ha : a = 0 := by
    rw [← hab, inner_add_right, inner_smul_right, inner_smul_right, huu, huv] at hcoord₁
    simpa using hcoord₁
  have hb : b = 0 := by
    rw [← hab, inner_add_right, inner_smul_right, inner_smul_right, hvu, hvv] at hcoord₂
    simpa using hcoord₂
  rw [← sub_eq_zero]
  rw [← hab, ha, hb]
  simp

/-- A two-plane's coordinate rows form a continuous linear equivalence when
restricted to that plane. -/
noncomputable def pairFrameEquiv {n : ℕ} (H : Submodule ℝ (Ambient n))
    (p : Ambient n × Ambient n) (hp : p ∈ orthonormalPairSet n)
    (hspan : pairPlane p = H) : H ≃L[ℝ] (ℝ × ℝ) := by
  let T : H →L[ℝ] (ℝ × ℝ) := (pairFrameMap p).comp H.subtypeL
  have hinj : Function.Injective T := by
    intro x y hxy
    apply Subtype.ext
    apply pairFrameMap_injectiveOnPairPlane hp
      (hspan.symm ▸ x.property) (hspan.symm ▸ y.property)
    change pairFrameMap p x = pairFrameMap p y
    exact hxy
  have hsurj : Function.Surjective T := by
    intro a
    have hp₁ : p.1 ∈ H := by
      rw [← hspan]
      exact Submodule.subset_span (Set.mem_insert _ _)
    have hp₂ : p.2 ∈ H := by
      rw [← hspan]
      exact Submodule.subset_span (Set.mem_insert_of_mem _ (Set.mem_singleton _))
    refine ⟨⟨a.1 • p.1 + a.2 • p.2, H.add_mem (H.smul_mem _ hp₁) (H.smul_mem _ hp₂)⟩, ?_⟩
    change pairFrameMap p (a.1 • p.1 + a.2 • p.2) = a
    rcases hp with ⟨hu, hv, huv⟩
    have huu : inner ℝ p.1 p.1 = 1 := by
      rw [real_inner_self_eq_norm_sq, hu]
      norm_num
    have hvv : inner ℝ p.2 p.2 = 1 := by
      rw [real_inner_self_eq_norm_sq, hv]
      norm_num
    have hvu : inner ℝ p.2 p.1 = 0 := by rw [real_inner_comm, huv]
    change (inner ℝ p.1 (a.1 • p.1 + a.2 • p.2),
      inner ℝ p.2 (a.1 • p.1 + a.2 • p.2)) = a
    apply Prod.ext
    · simp [inner_add_right, inner_smul_right, huu, huv]
    · simp [inner_add_right, inner_smul_right, hvu, hvv]
  exact ContinuousLinearEquiv.ofBijective T
    (LinearMap.ker_eq_bot.mpr hinj) (LinearMap.range_eq_top.mpr hsurj)

@[simp] theorem pairFrameEquiv_apply {n : ℕ}
    (H : Submodule ℝ (Ambient n)) (p : Ambient n × Ambient n)
    (hp : p ∈ orthonormalPairSet n) (hspan : pairPlane p = H) (x : H) :
    pairFrameEquiv H p hp hspan x = pairFrameMap p x := by
  simp [pairFrameEquiv]

/-- The frame equivalence followed by projection is the ambient frame map.
This is the bridge to `compact_frame_correction_of_curvature`. -/
theorem pairFrameEquiv_comp_projection {n : ℕ}
    (H : Submodule ℝ (Ambient n)) (p : Ambient n × Ambient n)
    (hp : p ∈ orthonormalPairSet n) (hspan : pairPlane p = H) :
    (pairFrameEquiv H p hp hspan).toContinuousLinearMap.comp H.orthogonalProjection =
      pairFrameMap p := by
  apply ContinuousLinearMap.ext
  intro x
  change pairFrameEquiv H p hp hspan (H.orthogonalProjection x) = pairFrameMap p x
  rw [pairFrameEquiv_apply]
  change pairFrameMap p (H.starProjection x) = pairFrameMap p x
  have hproj : H.starProjection = pairProjection p := by
    calc
      H.starProjection = (pairPlane p).starProjection := by rw [hspan]
      _ = pairProjection p := (pairProjection_eq_planeProjection hp).symm
  rw [hproj]
  simpa only [ContinuousLinearMap.comp_apply] using
    congrArg (fun T : Ambient n →L[ℝ] (ℝ × ℝ) => T x)
      (pairFrameMap_comp_pairProjection hp)

theorem continuous_pairFrameMap (n : ℕ) :
    Continuous (pairFrameMap (n := n)) := by
  change Continuous (fun p : Ambient n × Ambient n =>
    (innerSL ℝ p.1).prod (innerSL ℝ p.2))
  exact (ContinuousLinearMap.prodₗᵢ ℝ).continuous.comp
    (((innerSL ℝ).continuous.comp continuous_fst).prodMk
      ((innerSL ℝ).continuous.comp continuous_snd))

/-- The set of coordinate maps from all ordered orthonormal pairs is compact. -/
theorem isCompact_orthonormalPairFrameMaps (n : ℕ) :
    IsCompact (pairFrameMap (n := n) '' orthonormalPairSet n) := by
  exact (isCompact_orthonormalPairSet n).image (continuous_pairFrameMap n)

/-- Every orthonormal pair gives a surjective two-coordinate map. -/
theorem pairFrameMap_surjective {n : ℕ} {p : Ambient n × Ambient n}
    (hp : p ∈ orthonormalPairSet n) : Function.Surjective (pairFrameMap p) := by
  intro a
  refine ⟨a.1 • p.1 + a.2 • p.2, ?_⟩
  rcases hp with ⟨hu, hv, huv⟩
  have huu : inner ℝ p.1 p.1 = 1 := by
    rw [real_inner_self_eq_norm_sq, hu]
    norm_num
  have hvv : inner ℝ p.2 p.2 = 1 := by
    rw [real_inner_self_eq_norm_sq, hv]
    norm_num
  have hvu : inner ℝ p.2 p.1 = 0 := by
    rw [real_inner_comm, huv]
  change (inner ℝ p.1 (a.1 • p.1 + a.2 • p.2),
    inner ℝ p.2 (a.1 • p.1 + a.2 • p.2)) = a
  apply Prod.ext
  · simp [inner_add_right, inner_smul_right, huu, huv]
  · simp [inner_add_right, inner_smul_right, hvu, hvv]

/-- Every two-plane is represented by an orthonormal pair. The proof chooses an
orthonormal basis only for the individual plane; the compact Stiefel model
retains all such choices. -/
theorem exists_orthonormalPair_for_twoPlane {n : ℕ}
    (H : Submodule ℝ (Ambient n)) (hH : Module.finrank ℝ H = 2) :
    ∃ p ∈ orthonormalPairSet n, pairPlane p = H := by
  let b : OrthonormalBasis (Fin 2) ℝ H :=
    (stdOrthonormalBasis ℝ H).reindex (finCongr hH)
  let p : Ambient n × Ambient n := ((b 0 : H), (b 1 : H))
  have hp : p ∈ orthonormalPairSet n := by
    constructor
    · change ‖(b 0 : H)‖ = 1
      exact b.orthonormal.norm_eq_one (0 : Fin 2)
    constructor
    · change ‖(b 1 : H)‖ = 1
      exact b.orthonormal.norm_eq_one (1 : Fin 2)
    · change inner ℝ (b 0 : H) (b 1 : H) = 0
      exact b.orthonormal.inner_eq_zero (by decide : (0 : Fin 2) ≠ 1)
  refine ⟨p, hp, ?_⟩
  apply le_antisymm
  · apply Submodule.span_le.mpr
    intro x hx
    simp only [Set.mem_insert_iff, Set.mem_singleton_iff] at hx
    rcases hx with hx | hx
    · rw [hx]
      change (b 0 : Ambient n) ∈ H
      exact (b 0).property
    · rw [hx]
      change (b 1 : Ambient n) ∈ H
      exact (b 1).property
  · intro x hx
    let xH : H := ⟨x, hx⟩
    have hterm (i : Fin 2) : (b.repr xH i) • (b i : Ambient n) ∈ pairPlane p := by
      apply Submodule.smul_mem
      apply Submodule.subset_span
      fin_cases i
      · exact Set.mem_insert _ _
      · exact Set.mem_insert_of_mem _ (Set.mem_singleton _)
    have hsum : (∑ i : Fin 2, (b.repr xH i) • (b i : Ambient n)) ∈ pairPlane p := by
      simpa using (Submodule.sum_mem (p := pairPlane p) (t := Finset.univ)
        (fun i hi => hterm i))
    have hrepr : (∑ i : Fin 2, (b.repr xH i) • (b i : Ambient n)) = x := by
      have h := congrArg (fun y : H => (y : Ambient n)) (b.sum_repr xH)
      simpa using h
    rw [← hrepr]
    exact hsum

/-- Every orthonormal pair spans a two-dimensional subspace. -/
theorem pairPlane_finrank_two {n : ℕ} {p : Ambient n × Ambient n}
    (hp : p ∈ orthonormalPairSet n) : Module.finrank ℝ (pairPlane p) = 2 := by
  rcases hp with ⟨hu, hv, huv⟩
  have huu : inner ℝ p.1 p.1 = 1 := by
    rw [real_inner_self_eq_norm_sq, hu]
    norm_num
  have hvv : inner ℝ p.2 p.2 = 1 := by
    rw [real_inner_self_eq_norm_sq, hv]
    norm_num
  have hvu : inner ℝ p.2 p.1 = 0 := by rw [real_inner_comm, huv]
  have horth : Orthonormal ℝ (pairFrameVector p) := by
    rw [orthonormal_iff_ite]
    intro i j
    fin_cases i <;> fin_cases j <;>
      simp [pairFrameVector, huu, hvv, huv, hvu]
  have hspan : pairPlane p = Submodule.span ℝ (Set.range (pairFrameVector p)) := by
    apply congrArg (Submodule.span ℝ)
    ext x
    simp only [Set.mem_insert_iff, Set.mem_singleton_iff, Set.mem_range]
    constructor
    · rintro (rfl | rfl)
      · exact ⟨0, by simp [pairFrameVector]⟩
      · exact ⟨1, by simp [pairFrameVector]⟩
    · rintro ⟨i, rfl⟩
      fin_cases i
      · exact Or.inl rfl
      · exact Or.inr rfl
  rw [hspan, finrank_span_eq_card horth.linearIndependent]
  simp

/-- Compact base of two orthonormal frames and one frequency from the compact
support of a smooth patch. The first frame represents the tangent plane and
the second represents the nearby plane. -/
def frameSupportSet {n : ℕ} (S : SmoothPatch n) :
    Set ((Ambient n × Ambient n) × ((Ambient n × Ambient n) × Ambient n)) :=
  orthonormalPairSet n ×ˢ (orthonormalPairSet n ×ˢ S.support)

abbrev FrameSupportParameter {n : ℕ} (S : SmoothPatch n) :=
  {r : (Ambient n × Ambient n) × ((Ambient n × Ambient n) × Ambient n) //
    r ∈ frameSupportSet S}

theorem isCompact_frameSupportSet {n : ℕ} (S : SmoothPatch n) :
    IsCompact (frameSupportSet S) := by
  exact (isCompact_orthonormalPairSet n).prod
    ((isCompact_orthonormalPairSet n).prod S.compact_support)

/-- The explicit family inequalities used to select compact admissible frame
and frequency parameters. Curvature is stated on every vector in the first
frame plane via its two scalar coordinates. -/
def frameFrequencyAdmissible {n : ℕ} (S : SmoothPatch n) (κ : ℝ)
    (r : (Ambient n × Ambient n) × ((Ambient n × Ambient n) × Ambient n)) : Prop :=
  inner ℝ (S.normal r.2.2) r.1.1 = 0 ∧
  inner ℝ (S.normal r.2.2) r.1.2 = 0 ∧
  ‖pairProjection r.1 - pairProjection r.2.1‖ * ‖S.shape r.2.2‖ ≤ κ / 2 ∧
  ∀ c : ℝ × ℝ,
    κ * ‖c.1 • r.1.1 + c.2 • r.1.2‖ ≤
      ‖pairProjection r.1 (S.shape r.2.2 (c.1 • r.1.1 + c.2 • r.1.2))‖

theorem isClosed_frameFrequencyAdmissible {n : ℕ} (S : SmoothPatch n) (κ : ℝ) :
    IsClosed {r : FrameSupportParameter S | frameFrequencyAdmissible S κ r.1} := by
  let B := FrameSupportParameter S
  have hval : Continuous (fun r : B => r.1) := continuous_subtype_val
  have hw : Continuous (fun r : B => r.1.1) := continuous_fst.comp hval
  have hh : Continuous (fun r : B => r.1.2.1) :=
    continuous_fst.comp (continuous_snd.comp hval)
  have hz : Continuous (fun r : B => r.1.2.2) :=
    continuous_snd.comp (continuous_snd.comp hval)
  have hw₀ : Continuous (fun r : B => r.1.1.1) := continuous_fst.comp hw
  have hw₁ : Continuous (fun r : B => r.1.1.2) := continuous_snd.comp hw
  have hNOn : ContinuousOn S.normal S.support :=
    S.smooth_normal.continuousOn.mono (fun _ hz' => S.support_inside hz')
  have hN : Continuous (fun r : B => S.normal (r.1.2.2)) :=
    hNOn.comp_continuous hz (fun r => r.2.2.2)
  have hShapeOn : ContinuousOn (S.shape) S.support := by
    unfold SmoothPatch.shape
    exact (S.smooth_normal.continuousOn_fderiv_of_isOpen S.open_neighborhood
      (by simp)).neg.mono (fun _ hz' => S.support_inside hz')
  have hShape : Continuous (fun r : B => S.shape (r.1.2.2)) :=
    hShapeOn.comp_continuous hz (fun r => r.2.2.2)
  have hPW : Continuous (fun r : B => pairProjection (r.1.1)) :=
    (continuous_pairProjection n).comp hw
  have hPH : Continuous (fun r : B => pairProjection (r.1.2.1)) :=
    (continuous_pairProjection n).comp hh
  have hT₀ : Continuous (fun r : B => inner ℝ (S.normal (r.1.2.2)) (r.1.1.1)) :=
    hN.inner hw₀
  have hT₁ : Continuous (fun r : B => inner ℝ (S.normal (r.1.2.2)) (r.1.1.2)) :=
    hN.inner hw₁
  have hGap : Continuous (fun r : B =>
      ‖pairProjection (r.1.1) - pairProjection (r.1.2.1)‖ * ‖S.shape (r.1.2.2)‖) := by
    exact (hPW.sub hPH).norm.mul hShape.norm
  have hCurv : IsClosed {r : B | ∀ c : ℝ × ℝ,
      κ * ‖c.1 • r.1.1.1 + c.2 • r.1.1.2‖ ≤
        ‖pairProjection (r.1.1) (S.shape (r.1.2.2)
          (c.1 • r.1.1.1 + c.2 • r.1.1.2))‖} := by
    rw [show {r : B | ∀ c : ℝ × ℝ,
        κ * ‖c.1 • r.1.1.1 + c.2 • r.1.1.2‖ ≤
          ‖pairProjection (r.1.1) (S.shape (r.1.2.2)
            (c.1 • r.1.1.1 + c.2 • r.1.1.2))‖} =
      ⋂ c : ℝ × ℝ, {r : B | κ * ‖c.1 • r.1.1.1 + c.2 • r.1.1.2‖ ≤
        ‖pairProjection (r.1.1) (S.shape (r.1.2.2)
          (c.1 • r.1.1.1 + c.2 • r.1.1.2))‖} by
      ext r
      simp]
    apply isClosed_iInter
    intro c
    let v : B → Ambient n := fun r => c.1 • r.1.1.1 + c.2 • r.1.1.2
    have hv : Continuous v := (continuous_const.smul hw₀).add (continuous_const.smul hw₁)
    have hshapeV : Continuous (fun r : B => S.shape (r.1.2.2) (v r)) := hShape.clm_apply hv
    have hprojV : Continuous (fun r : B => pairProjection (r.1.1)
        (S.shape (r.1.2.2) (v r))) := hPW.clm_apply hshapeV
    simpa only [v] using isClosed_le (continuous_const.mul hv.norm) hprojV.norm
  change IsClosed
    ({r : B | inner ℝ (S.normal (r.1.2.2)) (r.1.1.1) = 0} ∩
      ({r | inner ℝ (S.normal (r.1.2.2)) (r.1.1.2) = 0} ∩
        ({r | ‖pairProjection (r.1.1) - pairProjection (r.1.2.1)‖ *
            ‖S.shape (r.1.2.2)‖ ≤ κ / 2} ∩
          {r | ∀ c : ℝ × ℝ,
            κ * ‖c.1 • r.1.1.1 + c.2 • r.1.1.2‖ ≤
              ‖pairProjection (r.1.1) (S.shape (r.1.2.2)
                (c.1 • r.1.1.1 + c.2 • r.1.1.2))‖})))
  exact (isClosed_eq hT₀ continuous_const).inter
    ((isClosed_eq hT₁ continuous_const).inter ((isClosed_le hGap continuous_const).inter hCurv))

theorem isCompact_frameFrequencyAdmissible {n : ℕ} (S : SmoothPatch n) (κ : ℝ) :
    IsCompact {r : FrameSupportParameter S | frameFrequencyAdmissible S κ r.1} := by
  letI : CompactSpace (FrameSupportParameter S) :=
    isCompact_iff_compactSpace.mp (isCompact_frameSupportSet S)
  exact (isClosed_frameFrequencyAdmissible S κ).isCompact

noncomputable def frameFrequencyParameterMap {n : ℕ} {S : SmoothPatch n}
    (r : FrameSupportParameter S) :
      ((Ambient n →L[ℝ] (ℝ × ℝ)) × Ambient n) :=
  (pairFrameMap r.1.2.1, r.1.2.2)

theorem continuous_frameFrequencyParameterMap {n : ℕ} (S : SmoothPatch n) :
    Continuous (frameFrequencyParameterMap (S := S)) := by
  change Continuous (fun r : FrameSupportParameter S =>
    (pairFrameMap r.1.2.1, r.1.2.2))
  exact ((continuous_pairFrameMap n).comp
      (continuous_fst.comp (continuous_snd.comp continuous_subtype_val))).prodMk
    (continuous_snd.comp (continuous_snd.comp continuous_subtype_val))

theorem isCompact_image_frameFrequencyAdmissible {n : ℕ}
    (S : SmoothPatch n) (κ : ℝ) :
    IsCompact (frameFrequencyParameterMap (S := S) ''
      {r : FrameSupportParameter S | frameFrequencyAdmissible S κ r.1}) :=
  (isCompact_frameFrequencyAdmissible S κ).image (continuous_frameFrequencyParameterMap S)

/-- The compact family of frequency and coordinate maps satisfying the frame
conditions. -/
def frameFrequencyAdmissibleImage {n : ℕ} (S : SmoothPatch n) (κ : ℝ) :
    Set ((Ambient n →L[ℝ] (ℝ × ℝ)) × Ambient n) :=
  frameFrequencyParameterMap (S := S) ''
    {r : FrameSupportParameter S | frameFrequencyAdmissible S κ r.1}

theorem isCompact_frameFrequencyAdmissibleImage {n : ℕ}
    (S : SmoothPatch n) (κ : ℝ) : IsCompact (frameFrequencyAdmissibleImage S κ) :=
  isCompact_image_frameFrequencyAdmissible S κ

/-- Recover the plane witnesses and curvature estimates from a point in the
compact image. This is the frame-to-plane bridge required by the uniform
distance-correction theorem. -/
theorem frameFrequencyAdmissibleImage_family {n : ℕ} (S : SmoothPatch n) {κ : ℝ}
    (q : (Ambient n →L[ℝ] (ℝ × ℝ)) × Ambient n)
    (hq : q ∈ frameFrequencyAdmissibleImage S κ)
    (hzero : q.1 (S.normal q.2) = 0) :
    ∃ W H : Submodule ℝ (Ambient n), ∃ e : H ≃L[ℝ] (ℝ × ℝ),
      q.1 = e.toContinuousLinearMap.comp H.orthogonalProjection ∧
      (∀ v : H, inner ℝ (S.normal q.2) (v : Ambient n) = 0) ∧
      Module.finrank ℝ W = Module.finrank ℝ H ∧
      (∀ v : W, inner ℝ (S.normal q.2) (v : Ambient n) = 0) ∧
      (∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (S.shape q.2 v)‖) ∧
      ‖W.starProjection - H.starProjection‖ * ‖S.shape q.2‖ ≤ κ / 2 := by
  rcases (Set.mem_image _ _ _).mp hq with ⟨r, hr, hqeq⟩
  change (pairFrameMap r.1.2.1, r.1.2.2) = q at hqeq
  have hzq : r.1.2.2 = q.2 := congrArg Prod.snd hqeq
  have hrow : pairFrameMap r.1.2.1 = q.1 := congrArg Prod.fst hqeq
  have hrowZero : pairFrameMap r.1.2.1 (S.normal r.1.2.2) = 0 := by
    calc
      pairFrameMap r.1.2.1 (S.normal r.1.2.2) = q.1 (S.normal r.1.2.2) := by rw [hrow]
      _ = q.1 (S.normal q.2) := by rw [hzq]
      _ = 0 := hzero
  have hH₀ : inner ℝ r.1.2.1.1 (S.normal r.1.2.2) = 0 := by
    have h := congrArg Prod.fst hrowZero
    change inner ℝ r.1.2.1.1 (S.normal r.1.2.2) = 0 at h
    exact h
  have hH₁ : inner ℝ r.1.2.1.2 (S.normal r.1.2.2) = 0 := by
    have h := congrArg Prod.snd hrowZero
    change inner ℝ r.1.2.1.2 (S.normal r.1.2.2) = 0 at h
    exact h
  rcases r.2 with ⟨hpW, hpH, _hsupp⟩
  rcases hr with ⟨ht₀, ht₁, hgap, hcurv⟩
  let W := pairPlane r.1.1
  let H := pairPlane r.1.2.1
  let e : H ≃L[ℝ] (ℝ × ℝ) := pairFrameEquiv H r.1.2.1 hpH rfl
  refine ⟨W, H, e, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · change q.1 = e.toContinuousLinearMap.comp H.orthogonalProjection
    calc
      q.1 = pairFrameMap r.1.2.1 := hrow.symm
      _ = e.toContinuousLinearMap.comp H.orthogonalProjection :=
        (pairFrameEquiv_comp_projection H r.1.2.1 hpH rfl).symm
  · intro v
    rw [← hzq]
    have hvProp : (v : Ambient n) ∈ pairPlane r.1.2.1 := v.property
    change (v : Ambient n) ∈ Submodule.span ℝ
      ({r.1.2.1.1, r.1.2.1.2} : Set (Ambient n)) at hvProp
    have htH₀ : inner ℝ (S.normal r.1.2.2) r.1.2.1.1 = 0 := by
      rw [real_inner_comm]
      exact hH₀
    have htH₁ : inner ℝ (S.normal r.1.2.2) r.1.2.1.2 = 0 := by
      rw [real_inner_comm]
      exact hH₁
    refine Submodule.span_induction ?_ ?_ ?_ ?_ hvProp
    · intro x hx
      simp only [Set.mem_insert_iff, Set.mem_singleton_iff] at hx
      rcases hx with hx | hx
      · rw [hx]
        exact htH₀
      · rw [hx]
        exact htH₁
    · simp
    · intro x y hx hy hx0 hy0
      rw [inner_add_right, hx0, hy0, add_zero]
    · intro a x hx hx0
      rw [inner_smul_right, hx0, mul_zero]
  · exact (pairPlane_finrank_two hpW).trans (pairPlane_finrank_two hpH).symm
  · intro v
    rw [← hzq]
    have hvProp : (v : Ambient n) ∈ pairPlane r.1.1 := v.property
    change (v : Ambient n) ∈ Submodule.span ℝ ({r.1.1.1, r.1.1.2} : Set (Ambient n)) at hvProp
    refine Submodule.span_induction ?_ ?_ ?_ ?_ hvProp
    · intro x hx
      simp only [Set.mem_insert_iff, Set.mem_singleton_iff] at hx
      rcases hx with hx | hx
      · rw [hx]
        exact ht₀
      · rw [hx]
        exact ht₁
    · simp
    · intro x y hx hy hx0 hy0
      rw [inner_add_right, hx0, hy0, add_zero]
    · intro a x hx hx0
      rw [inner_smul_right, hx0, mul_zero]
  · intro v
    rw [← hzq]
    have hv : (v : Ambient n) ∈ pairPlane r.1.1 := v.property
    change (v : Ambient n) ∈ Submodule.span ℝ ({r.1.1.1, r.1.1.2} : Set (Ambient n)) at hv
    obtain ⟨a, b, hab⟩ := Submodule.mem_span_pair.mp hv
    have h := hcurv (a, b)
    have hframe : κ * ‖(v : Ambient n)‖ ≤
        ‖pairProjection r.1.1 (S.shape r.1.2.2 (v : Ambient n))‖ := by
      simpa [hab] using h
    have hnorm : ‖pairProjection r.1.1 (S.shape r.1.2.2 (v : Ambient n))‖ =
        ‖W.orthogonalProjection (S.shape r.1.2.2 (v : Ambient n))‖ := by
      rw [pairProjection_eq_planeProjection hpW]
      rfl
    rw [hnorm] at hframe
    simpa using hframe
  · change ‖W.starProjection - H.starProjection‖ * ‖S.shape q.2‖ ≤ κ / 2
    rw [← hzq]
    rw [← pairProjection_eq_planeProjection hpW, ← pairProjection_eq_planeProjection hpH]
    exact hgap

/-- The article's uniform correction step applies to the compact admissible
frame-frequency image. Its compactness is constructed from orthonormal frames,
and every nearby plane is converted to an actual coordinate equivalence. -/
theorem compact_frameFrequencyAdmissible_thin_correction {n : ℕ}
    (S : SmoothPatch n) {κ : ℝ} (hκ : 0 < κ) :
    ∃ δ C : ℝ, 0 < δ ∧ 0 ≤ C ∧
      ∀ q ∈ frameFrequencyAdmissibleImage S κ, ‖q.1 (S.normal q.2)‖ < δ →
        ∃ y ∈ S.extendedSurface, q.1 (S.normal y) = 0 ∧
          dist q.2 y ≤ C * ‖q.1 (S.normal q.2)‖ := by
  apply compact_frame_correction_of_curvature S (isCompact_frameFrequencyAdmissibleImage S κ)
    ?_ hκ ?_
  · intro q hq
    rcases (Set.mem_image _ _ _).mp hq with ⟨r, hr, hqeq⟩
    change (pairFrameMap r.1.2.1, r.1.2.2) = q at hqeq
    have hzq : r.1.2.2 = q.2 := congrArg Prod.snd hqeq
    exact hzq ▸ (SmoothPatch.support_in_extendedSurface S (r.2.2.2))
  · intro q hq _
    obtain ⟨W, H, e, hP, _hHt, hdim, hW, hcurv, hgap⟩ :=
      frameFrequencyAdmissibleImage_family S q hq ‹q.1 (S.normal q.2) = 0›
    exact ⟨W, H, e, hP, hdim, hW, hcurv, hgap⟩

/-- Under the article's quantitative geometric hypotheses, the admissible
compact frame family contains a representative at every tuple of supported
frequencies: take both planes to be the common tangent plane. -/
theorem exists_frameFrequencyAdmissible_for_geometricTuple {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) {ν κ : ℝ}
    (hgeo : GeometricHypotheses S ν κ)
    (z : Fin k → Ambient (k + 2))
    (hz : ∀ i, z i ∈ (S i).support) :
    ∀ i, ∃ q ∈ frameFrequencyAdmissibleImage (S i) κ, q.2 = z i := by
  have hzExt : ∀ j, z j ∈ (S j).extendedSurface := fun j =>
    SmoothPatch.support_in_extendedSurface (S j) (hz j)
  let N : Fin k → Ambient (k + 2) := fun j => (S j).normal (z j)
  let W : Submodule ℝ (Ambient (k + 2)) := commonTangent N
  have hdim : Module.finrank ℝ W = 2 := geometric_commonTangent_two S hgeo z hzExt
  have hκ : 0 < κ := hgeo.2.1
  intro i
  obtain ⟨p, hp, hspan⟩ := exists_orthonormalPair_for_twoPlane W hdim
  have hp₁ : p.1 ∈ W := by
    rw [← hspan]
    exact Submodule.subset_span (Set.mem_insert _ _)
  have hp₂ : p.2 ∈ W := by
    rw [← hspan]
    exact Submodule.subset_span (Set.mem_insert_of_mem _ (Set.mem_singleton _))
  let r : FrameSupportParameter (S i) := ⟨(p, (p, z i)), ⟨hp, hp, hz i⟩⟩
  have hgood : frameFrequencyAdmissible (S i) κ r.1 := by
    refine ⟨?_, ?_, ?_, ?_⟩
    · exact commonTangent_orthogonal N ⟨p.1, hp₁⟩ i
    · exact commonTangent_orthogonal N ⟨p.2, hp₂⟩ i
    · change ‖pairProjection p - pairProjection p‖ * ‖(S i).shape (z i)‖ ≤ κ / 2
      simp only [sub_self, norm_zero, zero_mul]
      linarith [hκ]
    · intro c
      let v : W := ⟨c.1 • p.1 + c.2 • p.2,
        W.add_mem (W.smul_mem _ hp₁) (W.smul_mem _ hp₂)⟩
      have hcurv := (hgeo.2.2 z hzExt).2 i v
      have hproj : pairProjection p = W.starProjection := by
        rw [pairProjection_eq_planeProjection hp, hspan]
      have hnorm : ‖pairProjection p ((S i).shape (z i) v)‖ =
          ‖W.orthogonalProjection ((S i).shape (z i) v)‖ := by
        rw [hproj]
        change ‖((W.orthogonalProjection ((S i).shape (z i) v) : W) :
          Ambient (k + 2))‖ =
          ‖W.orthogonalProjection ((S i).shape (z i) v)‖
        rfl
      have hcurv' : κ * ‖v‖ ≤
          ‖W.orthogonalProjection ((S i).shape (z i) v)‖ := by
        simpa [W, N] using hcurv
      change κ * ‖v‖ ≤
        ‖pairProjection p ((S i).shape (z i) v)‖
      exact hcurv'.trans (le_of_eq hnorm.symm)
  let q := frameFrequencyParameterMap r
  refine ⟨q, ?_, ?_⟩
  · exact Set.mem_image_of_mem _ hgood
  · rfl

/-- Every admissible nearby two-plane at a supported geometric tuple has a
representative in the compact frame family, with its coordinate map factoring
through the actual plane projection. -/
theorem exists_frameFrequencyAdmissible_for_geometricTuple_and_plane {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) {ν κ : ℝ}
    (hgeo : GeometricHypotheses S ν κ)
    (z : Fin k → Ambient (k + 2))
    (hz : ∀ i, z i ∈ (S i).support) :
    ∀ i (H : Submodule ℝ (Ambient (k + 2))),
      Module.finrank ℝ H = 2 →
      ‖(commonTangent (fun j => (S j).normal (z j))).starProjection - H.starProjection‖ *
          ‖(S i).shape (z i)‖ ≤ κ / 2 →
      ∃ q ∈ frameFrequencyAdmissibleImage (S i) κ,
        q.2 = z i ∧
        ‖q.1 ((S i).normal (z i))‖ ≤
          ‖H.orthogonalProjection ((S i).normal (z i))‖ ∧
        ∃ e : H ≃L[ℝ] (ℝ × ℝ),
          q.1 = e.toContinuousLinearMap.comp H.orthogonalProjection := by
  have hzExt : ∀ j, z j ∈ (S j).extendedSurface := fun j =>
    SmoothPatch.support_in_extendedSurface (S j) (hz j)
  let N : Fin k → Ambient (k + 2) := fun j => (S j).normal (z j)
  let W : Submodule ℝ (Ambient (k + 2)) := commonTangent N
  have hWdim : Module.finrank ℝ W = 2 := geometric_commonTangent_two S hgeo z hzExt
  have hκ : 0 < κ := hgeo.2.1
  intro i H hHdim hgap
  obtain ⟨pW, hpW, hspanW⟩ := exists_orthonormalPair_for_twoPlane W hWdim
  obtain ⟨pH, hpH, hspanH⟩ := exists_orthonormalPair_for_twoPlane H hHdim
  have hpW₁ : pW.1 ∈ W := by
    rw [← hspanW]
    exact Submodule.subset_span (Set.mem_insert _ _)
  have hpW₂ : pW.2 ∈ W := by
    rw [← hspanW]
    exact Submodule.subset_span (Set.mem_insert_of_mem _ (Set.mem_singleton _))
  let r : FrameSupportParameter (S i) := ⟨(pW, (pH, z i)), ⟨hpW, hpH, hz i⟩⟩
  have hgood : frameFrequencyAdmissible (S i) κ r.1 := by
    refine ⟨?_, ?_, ?_, ?_⟩
    · exact commonTangent_orthogonal N ⟨pW.1, hpW₁⟩ i
    · exact commonTangent_orthogonal N ⟨pW.2, hpW₂⟩ i
    · change ‖pairProjection pW - pairProjection pH‖ * ‖(S i).shape (z i)‖ ≤ κ / 2
      rw [pairProjection_eq_planeProjection hpW, pairProjection_eq_planeProjection hpH,
        hspanW, hspanH]
      exact hgap
    · intro c
      let v : W := ⟨c.1 • pW.1 + c.2 • pW.2,
        W.add_mem (W.smul_mem _ hpW₁) (W.smul_mem _ hpW₂)⟩
      have hcurv := (hgeo.2.2 z hzExt).2 i v
      have hproj : pairProjection pW = W.starProjection := by
        rw [pairProjection_eq_planeProjection hpW, hspanW]
      have hnorm : ‖pairProjection pW ((S i).shape (z i) v)‖ =
          ‖W.orthogonalProjection ((S i).shape (z i) v)‖ := by
        rw [hproj]
        change ‖((W.orthogonalProjection ((S i).shape (z i) v) : W) :
          Ambient (k + 2))‖ =
          ‖W.orthogonalProjection ((S i).shape (z i) v)‖
        rfl
      have hcurv' : κ * ‖v‖ ≤
          ‖W.orthogonalProjection ((S i).shape (z i) v)‖ := by
        simpa [W, N] using hcurv
      change κ * ‖v‖ ≤ ‖pairProjection pW ((S i).shape (z i) v)‖
      exact hcurv'.trans (le_of_eq hnorm.symm)
  let q := frameFrequencyParameterMap r
  let e : H ≃L[ℝ] (ℝ × ℝ) := pairFrameEquiv H pH hpH hspanH
  have hqmap : q.1 = e.toContinuousLinearMap.comp H.orthogonalProjection := by
    change pairFrameMap pH = e.toContinuousLinearMap.comp H.orthogonalProjection
    exact (pairFrameEquiv_comp_projection H pH hpH hspanH).symm
  have hresbound : ‖q.1 ((S i).normal (z i))‖ ≤
      ‖H.orthogonalProjection ((S i).normal (z i))‖ := by
    calc
      ‖q.1 ((S i).normal (z i))‖ =
          ‖pairFrameMap pH ((S i).normal (z i))‖ := rfl
      _ ≤ ‖pairProjection pH ((S i).normal (z i))‖ :=
        pairFrameMap_norm_le_projection hpH _
      _ = ‖H.orthogonalProjection ((S i).normal (z i))‖ := by
        rw [pairProjection_eq_planeProjection hpH, hspanH]
        rfl
  refine ⟨q, ?_, rfl, hresbound, e, hqmap⟩
  exact Set.mem_image_of_mem _ hgood

/-- If the nearby plane in the preceding representation is tangent at the
base frequency, its represented residual vanishes there. -/
theorem exists_frameFrequencyAdmissible_for_geometricTuple_and_tangentPlane
    {k : ℕ} (S : Fin k → SmoothPatch (k + 2)) {ν κ : ℝ}
    (hgeo : GeometricHypotheses S ν κ)
    (z : Fin k → Ambient (k + 2))
    (hz : ∀ i, z i ∈ (S i).support) :
    ∀ i (H : Submodule ℝ (Ambient (k + 2))),
      Module.finrank ℝ H = 2 →
      (∀ v : H, inner ℝ ((S i).normal (z i)) (v : Ambient (k + 2)) = 0) →
      ‖(commonTangent (fun j => (S j).normal (z j))).starProjection - H.starProjection‖ *
          ‖(S i).shape (z i)‖ ≤ κ / 2 →
      ∃ q ∈ frameFrequencyAdmissibleImage (S i) κ,
        q.2 = z i ∧ q.1 ((S i).normal (z i)) = 0 ∧
        ∃ e : H ≃L[ℝ] (ℝ × ℝ),
          q.1 = e.toContinuousLinearMap.comp H.orthogonalProjection := by
  intro i H hHdim hHt hgap
  obtain ⟨q, hq, hqz, _hqres, e, hqmap⟩ :=
    exists_frameFrequencyAdmissible_for_geometricTuple_and_plane S hgeo z hz i H hHdim hgap
  have hHzero : H.orthogonalProjection ((S i).normal (z i)) = 0 := by
    apply Submodule.orthogonalProjection_eq_zero_iff.mpr
    rw [Submodule.mem_orthogonal]
    intro v hv
    exact (real_inner_comm _ _).trans (hHt ⟨v, hv⟩)
  have hqzero : q.1 ((S i).normal (z i)) = 0 := by
    rw [hqmap, ContinuousLinearMap.comp_apply, hHzero]
    simp
  exact ⟨q, hq, hqz, hqzero, e, hqmap⟩

/-- A finite collection of smooth patches admits one correction threshold and
one correction constant for all of their compact frame-frequency families. -/
theorem uniform_compact_frameFrequencyAdmissible_thin_correction {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) {κ : ℝ} (hκ : 0 < κ) :
    ∃ δ C : ℝ, 0 < δ ∧ 0 ≤ C ∧ ∀ i,
      ∀ q ∈ frameFrequencyAdmissibleImage (S i) κ,
        ‖q.1 ((S i).normal q.2)‖ < δ →
        ∃ y ∈ (S i).extendedSurface, q.1 ((S i).normal y) = 0 ∧
          dist q.2 y ≤ C * ‖q.1 ((S i).normal q.2)‖ := by
  classical
  by_cases hk : k = 0
  · subst k
    refine ⟨1, 1, by norm_num, by norm_num, ?_⟩
    intro i
    exact Fin.elim0 i
  · have hkpos : 0 < k := Nat.pos_of_ne_zero hk
    letI : Nonempty (Fin k) := ⟨⟨0, hkpos⟩⟩
    have hUniv : (Finset.univ : Finset (Fin k)).Nonempty := Finset.univ_nonempty
    have hLocal : ∀ i, ∃ δ C : ℝ, 0 < δ ∧ 0 ≤ C ∧
        ∀ q ∈ frameFrequencyAdmissibleImage (S i) κ,
          ‖q.1 ((S i).normal q.2)‖ < δ →
          ∃ y ∈ (S i).extendedSurface, q.1 ((S i).normal y) = 0 ∧
            dist q.2 y ≤ C * ‖q.1 ((S i).normal q.2)‖ :=
      fun i => compact_frameFrequencyAdmissible_thin_correction (S i) hκ
    choose δ₀ C₀ hδ₀ hC₀ hgood using hLocal
    let δ := (Finset.univ : Finset (Fin k)).inf' hUniv δ₀
    let C := (Finset.univ : Finset (Fin k)).sup' hUniv C₀
    have hδ : 0 < δ := by
      change 0 < (Finset.univ : Finset (Fin k)).inf' hUniv δ₀
      exact (Finset.lt_inf'_iff _).2 (fun i _ => hδ₀ i)
    have hC : 0 ≤ C := by
      let i₀ : Fin k := ⟨0, hkpos⟩
      have hi₀ : i₀ ∈ (Finset.univ : Finset (Fin k)) := Finset.mem_univ _
      have hle : C₀ i₀ ≤ C := by
        dsimp [C]
        exact Finset.le_sup' (f := C₀) hi₀
      exact (hC₀ i₀).trans hle
    refine ⟨δ, C, hδ, hC, ?_⟩
    intro i q hq hres
    have hδi : δ ≤ δ₀ i := by
      change (Finset.univ : Finset (Fin k)).inf' hUniv δ₀ ≤ δ₀ i
      exact Finset.inf'_le _ (Finset.mem_univ i)
    have hCi : C₀ i ≤ C := by
      change C₀ i ≤ (Finset.univ : Finset (Fin k)).sup' hUniv C₀
      exact Finset.le_sup' (f := C₀) (Finset.mem_univ i)
    obtain ⟨y, hy, hyzero, hdist⟩ := hgood i q hq (hres.trans_le hδi)
    refine ⟨y, hy, hyzero, ?_⟩
    calc
      dist q.2 y ≤ C₀ i * ‖q.1 ((S i).normal q.2)‖ := hdist
      _ ≤ C * ‖q.1 ((S i).normal q.2)‖ :=
        mul_le_mul_of_nonneg_right hCi (norm_nonneg _)

/-- Uniform version of the article's distance correction for all supported
geometric frequency tuples and all nearby two-planes. The frame coordinates
control the projected-normal residual, and the constants are independent of
the tuple, index, and plane. -/
theorem geometric_tuple_uniform_nearby_plane_correction {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) {ν κ : ℝ}
    (hgeo : GeometricHypotheses S ν κ) :
    ∃ δ C : ℝ, 0 < δ ∧ 0 ≤ C ∧
      ∀ z : Fin k → Ambient (k + 2),
        (∀ i, z i ∈ (S i).support) →
        ∀ i (H : Submodule ℝ (Ambient (k + 2))),
          Module.finrank ℝ H = 2 →
          ‖(commonTangent (fun j => (S j).normal (z j))).starProjection -
              H.starProjection‖ * ‖(S i).shape (z i)‖ ≤ κ / 2 →
          ‖H.orthogonalProjection ((S i).normal (z i))‖ < δ →
          ∃ q ∈ frameFrequencyAdmissibleImage (S i) κ,
            ∃ e : H ≃L[ℝ] (ℝ × ℝ),
              q.2 = z i ∧
              q.1 = e.toContinuousLinearMap.comp H.orthogonalProjection ∧
              ∃ y ∈ (S i).extendedSurface, q.1 ((S i).normal y) = 0 ∧
                H.orthogonalProjection ((S i).normal y) = 0 ∧
                dist (z i) y ≤ C *
                  ‖H.orthogonalProjection ((S i).normal (z i))‖ := by
  obtain ⟨δ, C, hδ, hC, huniform⟩ :=
    uniform_compact_frameFrequencyAdmissible_thin_correction S hgeo.2.1
  refine ⟨δ, C, hδ, hC, ?_⟩
  intro z hz i H hHdim hgap hsmall
  obtain ⟨q, hq, hqz, hqres, e, hqmap⟩ :=
    exists_frameFrequencyAdmissible_for_geometricTuple_and_plane
      S hgeo z hz i H hHdim hgap
  have hqsmall : ‖q.1 ((S i).normal q.2)‖ < δ := by
    rw [hqz]
    exact hqres.trans_lt hsmall
  obtain ⟨y, hy, hyzero, hdist⟩ := huniform i q hq hqsmall
  have hplanezero : H.orthogonalProjection ((S i).normal y) = 0 := by
    have hcoord : e.toContinuousLinearMap
        (H.orthogonalProjection ((S i).normal y)) = 0 := by
      calc
        e.toContinuousLinearMap (H.orthogonalProjection ((S i).normal y)) =
            q.1 ((S i).normal y) := by rw [hqmap]; rfl
        _ = 0 := hyzero
    exact e.injective (by simpa using hcoord)
  refine ⟨q, hq, e, hqz, hqmap, y, hy, hyzero, hplanezero, ?_⟩
  calc
    dist (z i) y = dist q.2 y := by rw [hqz]
    _ ≤ C * ‖q.1 ((S i).normal q.2)‖ := hdist
    _ = C * ‖q.1 ((S i).normal (z i))‖ := by rw [hqz]
    _ ≤ C * ‖H.orthogonalProjection ((S i).normal (z i))‖ :=
      mul_le_mul_of_nonneg_left hqres hC

/-- A common raw projection-gap threshold suffices on the compact supports.
The curvature-scaled gap in the previous theorem follows from a uniform bound
for the shape operators on those supports. -/
theorem geometric_tuple_uniform_nearby_plane_correction_of_gap {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) {ν κ : ℝ}
    (hgeo : GeometricHypotheses S ν κ) :
    ∃ δgap δres C : ℝ, 0 < δgap ∧ 0 < δres ∧ 0 ≤ C ∧
      ∀ z : Fin k → Ambient (k + 2),
        (∀ i, z i ∈ (S i).support) →
        ∀ i (H : Submodule ℝ (Ambient (k + 2))),
          Module.finrank ℝ H = 2 →
          ‖(commonTangent (fun j => (S j).normal (z j))).starProjection -
              H.starProjection‖ ≤ δgap →
          ‖H.orthogonalProjection ((S i).normal (z i))‖ < δres →
          ∃ q ∈ frameFrequencyAdmissibleImage (S i) κ,
            ∃ e : H ≃L[ℝ] (ℝ × ℝ),
              q.2 = z i ∧
              q.1 = e.toContinuousLinearMap.comp H.orthogonalProjection ∧
              ∃ y ∈ (S i).extendedSurface, q.1 ((S i).normal y) = 0 ∧
                H.orthogonalProjection ((S i).normal y) = 0 ∧
                dist (z i) y ≤ C *
                  ‖H.orthogonalProjection ((S i).normal (z i))‖ := by
  classical
  have hκ : 0 < κ := hgeo.2.1
  by_cases hk : k = 0
  · subst k
    refine ⟨1, 1, 0, by norm_num, by norm_num, by norm_num, ?_⟩
    intro z hz i
    exact Fin.elim0 i
  · have hkpos : 0 < k := Nat.pos_of_ne_zero hk
    letI : Nonempty (Fin k) := ⟨⟨0, hkpos⟩⟩
    have hUniv : (Finset.univ : Finset (Fin k)).Nonempty := Finset.univ_nonempty
    have hBounds : ∀ i, ∃ M : ℝ, 0 ≤ M ∧
        ∀ z ∈ (S i).support, ‖(S i).shape z‖ ≤ M := fun i =>
      SmoothPatch.shape_bound_on_compact (S i) (S i).compact_support
        (S i).support_inside
    choose M₀ hM₀ hMbound using hBounds
    let M := (Finset.univ : Finset (Fin k)).sup' hUniv M₀
    have hMnonneg : 0 ≤ M := by
      let i₀ : Fin k := ⟨0, hkpos⟩
      have hi₀ : i₀ ∈ (Finset.univ : Finset (Fin k)) := Finset.mem_univ _
      have hle : M₀ i₀ ≤ M := by
        dsimp [M]
        exact Finset.le_sup' (f := M₀) hi₀
      exact (hM₀ i₀).trans hle
    have hMi : ∀ i, M₀ i ≤ M := fun i => by
      change M₀ i ≤ (Finset.univ : Finset (Fin k)).sup' hUniv M₀
      exact Finset.le_sup' (f := M₀) (Finset.mem_univ i)
    let δgap := κ / (2 * (M + 1))
    have hδgap : 0 < δgap := by
      dsimp [δgap]
      positivity
    obtain ⟨δres, C, hδres, hC, hcorrect⟩ :=
      geometric_tuple_uniform_nearby_plane_correction S hgeo
    refine ⟨δgap, δres, C, hδgap, hδres, hC, ?_⟩
    intro z hz i H hHdim hgap hres
    have hshape : ‖(S i).shape (z i)‖ ≤ M := (hMbound i (z i) (hz i)).trans (hMi i)
    have hgapCurv :
        ‖(commonTangent (fun j => (S j).normal (z j))).starProjection - H.starProjection‖ *
            ‖(S i).shape (z i)‖ ≤ κ / 2 := by
      calc
        _ ≤ δgap * M := mul_le_mul hgap hshape (norm_nonneg _) hδgap.le
        _ ≤ δgap * (M + 1) :=
          mul_le_mul_of_nonneg_left (by linarith [hMnonneg]) hδgap.le
        _ = κ / 2 := by
          dsimp [δgap]
          field_simp [ne_of_gt (by linarith [hMnonneg] : 0 < M + 1)]
    exact hcorrect z hz i H hHdim hgapCurv hres

end N2Restriction
