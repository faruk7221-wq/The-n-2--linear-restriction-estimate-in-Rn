import N2Restriction.BoundedDensity
import N2Restriction.LocalHausdorff
import Mathlib.MeasureTheory.Measure.Comap

namespace N2Restriction
open MeasureTheory Set
open scoped ENNReal NNReal

local instance coordinateHausdorffHaar (d : ℕ) :
    Measure.IsAddHaarMeasure (Measure.hausdorffMeasure (d : ℝ) : Measure (Ambient d)) := by
  simpa only [Ambient, finrank_euclideanSpace, Fintype.card_fin] using
    (inferInstance : Measure.IsAddHaarMeasure
      (Measure.hausdorffMeasure (Module.finrank ℝ (Ambient d)) : Measure (Ambient d)))

/-- The normalization factor between Mathlib's d-dimensional Hausdorff measure
and Euclidean volume. Keeping it explicit avoids assuming a normalization convention. -/
noncomputable def coordinateHausdorffFactor (d : ℕ) : ℝ≥0 :=
  Measure.addHaarScalarFactor (Measure.hausdorffMeasure (d : ℝ) : Measure (Ambient d)) volume

theorem coordinateHausdorffFactor_pos (d : ℕ) : 0 < coordinateHausdorffFactor d := by
  letI : Measure.IsAddHaarMeasure (Measure.hausdorffMeasure (d : ℝ) : Measure (Ambient d)) := by
    simpa only [Ambient, finrank_euclideanSpace, Fintype.card_fin] using
      (inferInstance : Measure.IsAddHaarMeasure
        (Measure.hausdorffMeasure (Module.finrank ℝ (Ambient d)) : Measure (Ambient d)))
  exact Measure.addHaarScalarFactor_pos_of_isAddHaarMeasure (Measure.hausdorffMeasure (d : ℝ) : Measure (Ambient d)) volume

theorem coordinate_hausdorff_eq_volume (d : ℕ) :
    (Measure.hausdorffMeasure (d : ℝ) : Measure (Ambient d)) =
      (coordinateHausdorffFactor d : ℝ≥0∞) • volume := by
  letI : Measure.IsAddHaarMeasure (Measure.hausdorffMeasure (d : ℝ) : Measure (Ambient d)) := by
    simpa only [Ambient, finrank_euclideanSpace, Fintype.card_fin] using
      (inferInstance : Measure.IsAddHaarMeasure
        (Measure.hausdorffMeasure (Module.finrank ℝ (Ambient d)) : Measure (Ambient d)))
  exact Measure.isAddLeftInvariant_eq_smul (Measure.hausdorffMeasure (d : ℝ) : Measure (Ambient d)) volume

/-- Pulling surface measure back by a graph-like embedding gives a measure
between fixed multiples of Euclidean volume. -/
theorem graph_hausdorff_comparison {d n : ℕ} (F : Ambient d → Ambient n)
    {L : ℝ≥0} (hL : LipschitzWith L F) (hF : AntilipschitzWith 1 F) :
    (coordinateHausdorffFactor d : ℝ≥0∞) • volume ≤
        (Measure.hausdorffMeasure (d : ℝ)).comap F ∧
      (Measure.hausdorffMeasure (d : ℝ)).comap F ≤
        ((L ^ d * coordinateHausdorffFactor d : ℝ≥0) : ℝ≥0∞) • volume := by
  have he := (hF.isClosedEmbedding hL.uniformContinuous).measurableEmbedding
  constructor
  · rw [← coordinate_hausdorff_eq_volume]
    intro s
    rw [he.comap_apply]
    simpa using hF.le_hausdorffMeasure_image (Nat.cast_nonneg d) s
  · intro s
    rw [he.comap_apply]
    have h := hL.hausdorffMeasure_image_le (Nat.cast_nonneg d) s
    rw [coordinate_hausdorff_eq_volume] at h
    simpa only [Measure.smul_apply, smul_eq_mul, ENNReal.rpow_natCast,
      ENNReal.coe_mul, ENNReal.coe_pow, mul_assoc] using h

/-- A Lipschitz graph has a positive bounded measurable surface density.
This is obtained from measure comparison; no differentiable area formula is assumed. -/
theorem exists_graph_surface_density {d n : ℕ} (F : Ambient d → Ambient n)
    {L : ℝ≥0} (hL : LipschitzWith L F) (hF : AntilipschitzWith 1 F) :
    ∃ J : Ambient d → ℝ≥0, Measurable J ∧
      (∀ᵐ x ∂volume, coordinateHausdorffFactor d ≤ J x ∧
        J x ≤ L ^ d * coordinateHausdorffFactor d) ∧
      volume.withDensity (fun x => (J x : ℝ≥0∞)) =
        (Measure.hausdorffMeasure (d : ℝ)).comap F := by
  have h := graph_hausdorff_comparison F hL hF
  letI : SigmaFinite (((L ^ d * coordinateHausdorffFactor d : ℝ≥0) : ℝ≥0∞) • (volume : Measure (Ambient d))) :=
    inferInstanceAs (SigmaFinite ((L ^ d * coordinateHausdorffFactor d) • (volume : Measure (Ambient d))))
  letI : SigmaFinite ((Measure.hausdorffMeasure (d : ℝ)).comap F) :=
    Measure.sigmaFinite_of_le _ h.2
  exact exists_bounded_density volume _ _ _ h.1 h.2

/-- The coordinate density pushes forward to the Hausdorff measure of the graph. -/
theorem graph_density_map {d n : ℕ} (F : Ambient d → Ambient n)
    {L : ℝ≥0} (hL : LipschitzWith L F) (hF : AntilipschitzWith 1 F)
    (J : Ambient d → ℝ≥0)
    (hJ : volume.withDensity (fun x => (J x : ℝ≥0∞)) =
      (Measure.hausdorffMeasure (d : ℝ)).comap F) :
    (volume.withDensity (fun x => (J x : ℝ≥0∞))).map F =
      (Measure.hausdorffMeasure (d : ℝ)).restrict (range F) := by
  rw [hJ]
  exact (hF.isClosedEmbedding hL.uniformContinuous).measurableEmbedding.map_comap _

end N2Restriction
