import N2Restriction.NearbyPlanes
import Mathlib.Analysis.Calculus.InverseFunctionTheorem.ContDiff

namespace N2Restriction

/-- Smoothness of the full implicit inverse when both coordinate functions are smooth. -/
theorem implicit_inverse_contDiff {E F G : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [CompleteSpace F]
    [NormedAddCommGroup G] [NormedSpace ℝ G] [CompleteSpace G]
    (d : ImplicitFunctionData ℝ E F G)
    (hl : ContDiffAt ℝ (⊤ : ℕ∞) d.leftFun d.pt)
    (hr : ContDiffAt ℝ (⊤ : ℕ∞) d.rightFun d.pt) :
    ContDiffAt ℝ (⊤ : ℕ∞) (Function.uncurry d.implicitFunction) (d.prodFun d.pt) := by
  have hp : ContDiffAt ℝ (⊤ : ℕ∞) d.prodFun d.pt := hl.prodMk hr
  exact hp.to_localInverse d.hasStrictFDerivAt.hasFDerivAt (by simp)

/-- Smooth implicit parametrization of an arbitrary finite-dimensional submersion. -/
theorem exists_smooth_submersion_parametrization {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    {f : E → F} {L : E →L[ℝ] F} {z : E}
    (hf : ContDiffAt ℝ (⊤ : ℕ∞) f z) (hd : HasFDerivAt f L z)
    (hL : Function.Surjective L) :
    let K := LinearMap.ker L.toLinearMap
    ∃ φ : K → E, φ 0 = z ∧ ContDiffAt ℝ (⊤ : ℕ∞) φ 0 ∧
      HasStrictFDerivAt φ K.subtypeL 0 ∧
      ∀ᶠ t in nhds (0 : K), f (φ t) = f z := by
  letI := FiniteDimensional.complete ℝ F
  have hs := hf.hasStrictFDerivAt' hd (by simp)
  have hr : LinearMap.range L.toLinearMap = ⊤ := LinearMap.range_eq_top.mpr hL
  let hc := L.ker_closedComplemented_of_finiteDimensional_range
  let d := hs.implicitFunctionDataOfComplemented f L hr hc
  have hright : ContDiffAt ℝ (⊤ : ℕ∞) d.rightFun z :=
    (Classical.choose hc).contDiff.contDiffAt.comp z (contDiffAt_id.sub contDiffAt_const)
  have hi := implicit_inverse_contDiff d hf hright
  have hbase : d.prodFun d.pt = (f z, 0) := by
    simp [d, ImplicitFunctionData.prodFun, HasStrictFDerivAt.implicitFunctionDataOfComplemented]
  rw [hbase] at hi
  have hi' : ContDiffAt ℝ (⊤ : ℕ∞)
      (hs.implicitFunction f L hr (f z)) 0 := by
    convert hi.comp (0 : LinearMap.ker L.toLinearMap)
      (contDiffAt_const.prodMk contDiffAt_id) using 1
  refine ⟨hs.implicitFunction f L hr (f z), hs.implicitFunction_apply_image hr,
    hi', hs.to_implicitFunction hr, ?_⟩
  exact (tendsto_const_nhds.prodMk_nhds Filter.tendsto_id).eventually
    (hs.map_implicitFunction_eq hr)

/-- For nearby planes the thin level set admits a smooth parametrization with
the correct tangent inclusion. No uniform higher-derivative bounds are claimed. -/
theorem exists_smooth_nearby_thin_parametrization {n : ℕ} (S : SmoothPatch n)
    (W H : Submodule ℝ (Ambient n)) (hdim : Module.finrank ℝ W = Module.finrank ℝ H)
    {z : Ambient n} (hz : z ∈ S.neighborhood)
    (hW : ∀ v : W, inner ℝ (S.normal z) (v : Ambient n) = 0)
    {κ : ℝ} (hκ : 0 < κ)
    (hA : ∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (S.shape z v)‖)
    (hgap : ‖W.starProjection - H.starProjection‖ * ‖S.shape z‖ ≤ κ / 2) :
    let K := LinearMap.ker (thinDifferential S H z).toLinearMap
    ∃ φ : K → Ambient n, φ 0 = z ∧ ContDiffAt ℝ (⊤ : ℕ∞) φ 0 ∧
      HasStrictFDerivAt φ K.subtypeL 0 ∧
      ∀ᶠ t in nhds (0 : K), thinConstraint S H (φ t) = thinConstraint S H z := by
  have hds := S.smooth_defining.contDiffAt (S.open_neighborhood.mem_nhds hz)
  have hns := S.smooth_normal.contDiffAt (S.open_neighborhood.mem_nhds hz)
  exact exists_smooth_submersion_parametrization
    (hds.prodMk (H.orthogonalProjection.contDiff.contDiffAt.comp z hns))
    (hasFDerivAt_thinConstraint S H hz)
    (nearby_thinDifferential_surjective S W H hdim hz hW hκ hA hgap)

end N2Restriction
