import N2Restriction.CubeTorus
import Mathlib.MeasureTheory.Group.MeasurableEquiv

namespace N2Restriction
open MeasureTheory Set

/-- The actual affine coordinate map from a unit cube to a frequency cube. -/
noncomputable def capAffine {d : ℕ} (c : Ambient d) (r : ℝ) (hr : r ≠ 0) :
    (Fin d → ℝ) ≃ᵐ Ambient d :=
  (EuclideanSpace.measurableEquiv (Fin d)).symm |>.trans
    ((MeasurableEquiv.smul₀ r hr).trans (MeasurableEquiv.addLeft c))

theorem capAffine_apply {d : ℕ} (c : Ambient d) (r : ℝ) (hr : r ≠ 0)
    (x : Fin d → ℝ) : capAffine c r hr x = c + r • WithLp.toLp 2 x := rfl

def scaledCube {d : ℕ} (t : Fin d → ℝ) (c : Ambient d) (r : ℝ) (hr : r ≠ 0) :
    Set (Ambient d) := capAffine c r hr '' unitCube t

theorem scaledCube_measurable {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : r ≠ 0) : MeasurableSet (scaledCube t c r hr) :=
  (capAffine c r hr).measurableEmbedding.measurableSet_image.mpr (unitCube_measurable t)

/-- Exact affine Jacobian, with ordinary Euclidean Lebesgue measure. -/
theorem capAffine_map_volume {d : ℕ} (c : Ambient d) (r : ℝ) (hr : r ≠ 0) :
    Measure.map (capAffine c r hr) volume =
      ENNReal.ofReal (abs (r ^ d)⁻¹) • (volume : Measure (Ambient d)) := by
  change Measure.map ((fun y : Ambient d => c + y) ∘
    ((fun y : Ambient d => r • y) ∘ WithLp.toLp 2)) volume = _
  rw [← Measure.map_map (measurable_const_add c)
    ((measurable_const_smul r).comp (PiLp.volume_preserving_toLp (Fin d)).measurable),
    ← Measure.map_map (measurable_const_smul r) (PiLp.volume_preserving_toLp (Fin d)).measurable,
    (PiLp.volume_preserving_toLp (Fin d)).map_eq,
    Measure.map_addHaar_smul volume hr, Measure.map_smul,
    (measurePreserving_add_left volume c).map_eq]
  simp [Ambient]

/-- The normalized measure of a cap is the pushforward of unit-cube volume. -/
noncomputable def capProbability {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : r ≠ 0) : Measure (Ambient d) :=
  Measure.map (capAffine c r hr) (volume.restrict (unitCube t))

theorem capProbability_eq {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : r ≠ 0) : capProbability t c r hr =
      ENNReal.ofReal (abs (r ^ d)⁻¹) • volume.restrict (scaledCube t c r hr) := by
  have h := (capAffine c r hr).restrict_map volume (scaledCube t c r hr)
  rw [capAffine_map_volume, Measure.restrict_smul] at h
  simpa only [scaledCube, (capAffine c r hr).injective.preimage_image, capProbability] using h.symm

theorem capAffine_measurePreserving {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : r ≠ 0) : MeasurePreserving (capAffine c r hr)
      (volume.restrict (unitCube t)) (capProbability t c r hr) :=
  (capAffine c r hr).measurable.measurePreserving _

theorem capAffine_symm_measurePreserving {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : r ≠ 0) : MeasurePreserving (capAffine c r hr).symm
      (capProbability t c r hr) (volume.restrict (unitCube t)) :=
  (capAffine_measurePreserving t c r hr).symm

noncomputable def cubeToCap {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : r ≠ 0) : Lp ℂ 2 (volume.restrict (unitCube t)) →ₗᵢ[ℂ]
      Lp ℂ 2 (capProbability t c r hr) :=
  Lp.compMeasurePreservingₗᵢ ℂ (capAffine c r hr).symm
    (capAffine_symm_measurePreserving t c r hr)

noncomputable def capToCube {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : r ≠ 0) : Lp ℂ 2 (capProbability t c r hr) →ₗᵢ[ℂ]
      Lp ℂ 2 (volume.restrict (unitCube t)) :=
  Lp.compMeasurePreservingₗᵢ ℂ (capAffine c r hr) (capAffine_measurePreserving t c r hr)

theorem cubeToCap_capToCube {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : r ≠ 0) (f : Lp ℂ 2 (capProbability t c r hr)) :
    cubeToCap t c r hr (capToCube t c r hr f) = f := by
  apply Lp.ext
  filter_upwards [Lp.coeFn_compMeasurePreserving (capToCube t c r hr f)
      (capAffine_symm_measurePreserving t c r hr),
    (capAffine_symm_measurePreserving t c r hr).quasiMeasurePreserving.ae
      (Lp.coeFn_compMeasurePreserving f (capAffine_measurePreserving t c r hr))] with x hx hy
  change cubeToCap t c r hr (capToCube t c r hr f) x = _ at hx
  change capToCube t c r hr f ((capAffine c r hr).symm x) = _ at hy
  simp only [Function.comp_apply] at hx hy
  rw [hx, hy]
  simp

theorem capToCube_cubeToCap {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : r ≠ 0) (f : Lp ℂ 2 (volume.restrict (unitCube t))) :
    capToCube t c r hr (cubeToCap t c r hr f) = f := by
  apply Lp.ext
  filter_upwards [Lp.coeFn_compMeasurePreserving (cubeToCap t c r hr f)
      (capAffine_measurePreserving t c r hr),
    (capAffine_measurePreserving t c r hr).quasiMeasurePreserving.ae
      (Lp.coeFn_compMeasurePreserving f (capAffine_symm_measurePreserving t c r hr))] with x hx hy
  change capToCube t c r hr (cubeToCap t c r hr f) x = _ at hx
  change cubeToCap t c r hr f (capAffine c r hr x) = _ at hy
  simp only [Function.comp_apply] at hx hy
  rw [hx, hy]
  simp

noncomputable def cubeCapEquiv {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : r ≠ 0) : Lp ℂ 2 (volume.restrict (unitCube t)) ≃ₗᵢ[ℂ]
      Lp ℂ 2 (capProbability t c r hr) :=
  { cubeToCap t c r hr with
    invFun := capToCube t c r hr
    left_inv := capToCube_cubeToCap t c r hr
    right_inv := cubeToCap_capToCube t c r hr }

end N2Restriction
