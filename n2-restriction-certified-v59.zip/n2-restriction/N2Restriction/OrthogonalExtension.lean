import N2Restriction.GraphMeasureTransfer
import N2Restriction.ExtensionRegularity

namespace N2Restriction
open MeasureTheory Set

/-- rotating both physical and frequency coordinates leaves the extension unchanged. -/
theorem orthogonal_extension_covariance {n : ℕ} {Ω : Type*} [MeasurableSpace Ω]
    (A : Ambient n ≃ₗᵢ[ℝ] Ambient n) (μ : Measure Ω) (ζ : Ω → Ambient n)
    (f : Ω → ℂ) (x : Ambient n) :
    extension μ (fun ω => A (ζ ω)) f (A x) = extension μ ζ f x := by
  unfold extension
  simp only [A.inner_map_map]

/-- the ambient-ball energy is unchanged by an orthogonal coordinate change. -/
theorem orthogonal_extension_ball_energy {n : ℕ} {Ω : Type*} [MeasurableSpace Ω]
    (A : Ambient n ≃ₗᵢ[ℝ] Ambient n) (μ : Measure Ω) (ζ : Ω → Ambient n)
    (f : Ω → ℂ) (x₀ : Ambient n) (R : ℝ) :
    (∫ y in Metric.ball (A x₀) R, ‖extension μ (fun ω => A (ζ ω)) f y‖ ^ 2) =
      ∫ x in Metric.ball x₀ R, ‖extension μ ζ f x‖ ^ 2 := by
  have hm : MeasurableEmbedding (A : Ambient n → Ambient n) := A.toHomeomorph.measurableEmbedding
  have h := hm.setIntegral_map (μ := volume)
    (fun y => ‖extension μ (fun ω => A (ζ ω)) f y‖ ^ 2) (Metric.ball (A x₀) R)
  rw [A.measurePreserving.map_eq, A.isometry.preimage_ball] at h
  simpa only [orthogonal_extension_covariance] using h

/-- orthogonal images preserve actual restricted Hausdorff surface measure. -/
theorem orthogonal_surface_measure {n : ℕ} (A : Ambient n ≃ₗᵢ[ℝ] Ambient n)
    (d : ℝ) (K : Set (Ambient n)) :
    ((Measure.hausdorffMeasure d).restrict K).map A =
      (Measure.hausdorffMeasure d).restrict (A '' K) := by
  have hm : MeasurableEmbedding (A : Ambient n → Ambient n) := A.toHomeomorph.measurableEmbedding
  have h := hm.restrict_map (Measure.hausdorffMeasure d) (A '' K)
  rw [Set.preimage_image_eq _ A.injective] at h
  have hmap : (Measure.hausdorffMeasure d).map A = Measure.hausdorffMeasure d :=
    A.toIsometryEquiv.map_hausdorffMeasure d
  rw [hmap] at h
  exact h.symm

end N2Restriction
