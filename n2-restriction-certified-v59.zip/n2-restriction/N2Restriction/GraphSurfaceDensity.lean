import N2Restriction.HausdorffDensity
import N2Restriction.EuclideanTubes

namespace N2Restriction
open MeasureTheory
open scoped NNReal ENNReal

/-- Horizontal projection is a left inverse to graph coordinates. -/
def graphProjection {d : ℕ} (x : Ambient (d + 1)) : Ambient d :=
  WithLp.toLp 2 (fun j => x j.succ)

theorem graphProjection_graphPoint {d : ℕ} (u : Ambient d) (t : ℝ) :
    graphProjection (graphPoint u t) = u := by
  ext j
  simp [graphProjection, graphPoint]

theorem graphPoint_projection_height {d : ℕ} (x : Ambient (d + 1)) :
    graphPoint (graphProjection x) (x 0) = x := by
  ext j
  refine Fin.cases ?_ (fun k => ?_) j <;> simp [graphPoint, graphProjection]

theorem graphProjection_lipschitz {d : ℕ} : LipschitzWith 1 (@graphProjection d) := by
  apply LipschitzWith.of_dist_le_mul
  intro x y
  have h := graphPoint_dist_sq (graphProjection x) (graphProjection y) (x 0) (y 0)
  rw [graphPoint_projection_height, graphPoint_projection_height, ← dist_eq_norm] at h
  simp only [NNReal.coe_one, one_mul]
  have ha := dist_nonneg (x := graphProjection x) (y := graphProjection y)
  have hb := dist_nonneg (x := x) (y := y)
  nlinarith [sq_nonneg (x 0 - y 0)]

theorem graphMap_antilipschitz {d : ℕ} (φ : Ambient d → ℝ) :
    AntilipschitzWith 1 (fun x => graphPoint x (φ x)) := by
  apply AntilipschitzWith.of_le_mul_dist
  intro x y
  have h := graphPoint_dist_sq x y (φ x) (φ y)
  rw [← dist_eq_norm] at h
  simp only [NNReal.coe_one, one_mul]
  have ha := dist_nonneg (x := x) (y := y)
  have hb := dist_nonneg (x := graphPoint x (φ x)) (y := graphPoint y (φ y))
  nlinarith [sq_nonneg (φ x - φ y)]

/-- A height Lipschitz constant yields an explicit Lipschitz constant for the graph. -/
theorem graphMap_lipschitz {d : ℕ} {φ : Ambient d → ℝ} {L : ℝ≥0}
    (hφ : LipschitzWith L φ) : LipschitzWith (1 + L) (fun x => graphPoint x (φ x)) := by
  apply LipschitzWith.of_dist_le_mul
  intro x y
  have h := graphPoint_dist_sq x y (φ x) (φ y)
  rw [← dist_eq_norm] at h
  have hp := hφ.dist_le_mul x y
  rw [Real.dist_eq] at hp
  have hs : (φ x - φ y) ^ 2 ≤ ((L : ℝ) * dist x y) ^ 2 := by
    nlinarith [sq_abs (φ x - φ y), abs_nonneg (φ x - φ y),
      mul_nonneg L.coe_nonneg (dist_nonneg (x := x) (y := y))]
  simp only [NNReal.coe_add, NNReal.coe_one]
  have hnon : 0 ≤ (1 + (L : ℝ)) * dist x y := by positivity
  nlinarith [mul_nonneg L.coe_nonneg (sq_nonneg (dist x y)),
    dist_nonneg (x := graphPoint x (φ x)) (y := graphPoint y (φ y))]

/-- An actual graph in Euclidean space has a positive bounded Hausdorff density. -/
theorem exists_lipschitz_graph_density {d : ℕ} {φ : Ambient d → ℝ} {L : ℝ≥0}
    (hφ : LipschitzWith L φ) :
    ∃ J : Ambient d → ℝ≥0, Measurable J ∧
      (∀ᵐ x ∂volume, coordinateHausdorffFactor d ≤ J x ∧
        J x ≤ (1 + L) ^ d * coordinateHausdorffFactor d) ∧
      (volume.withDensity (fun x => (J x : ℝ≥0∞))).map (fun x => graphPoint x (φ x)) =
        (Measure.hausdorffMeasure (d : ℝ)).restrict (Set.range (fun x => graphPoint x (φ x))) := by
  obtain ⟨J, hJ, hb, he⟩ := exists_graph_surface_density _ (graphMap_lipschitz hφ)
    (graphMap_antilipschitz φ)
  exact ⟨J, hJ, hb, graph_density_map _ (graphMap_lipschitz hφ) (graphMap_antilipschitz φ) J he⟩

end N2Restriction
