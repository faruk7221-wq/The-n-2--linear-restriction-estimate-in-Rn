import N2Restriction.ActualFiniteCapPackets

open MeasureTheory
namespace N2Restriction

/-- essential support is retained by an unconditional L2 sum. -/
theorem HasFrequencySupport.tsum_L2 {Ω ι : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (K : Set Ω) (hK : MeasurableSet K) (f : ι → Lp ℂ 2 μ)
    (hs : Summable f) (hf : ∀ j, HasFrequencySupport μ id K (f j)) :
    HasFrequencySupport μ id K (∑' j, f j : Lp ℂ 2 μ) := by
  classical
  let χ : Ω → ℂ := K.indicator (fun _ => 1)
  have hχ : AEStronglyMeasurable χ μ := aestronglyMeasurable_const.indicator hK
  have hC : ∀ᵐ x ∂μ, ‖χ x‖ ≤ 1 := Filter.Eventually.of_forall (fun x => by
    by_cases hx : x ∈ K <;> simp [χ, hx])
  let T := cutoffOperator χ hχ hC
  have hTf (j : ι) : T (f j) = f j := by
    apply cutoffOperator_eq_self
    filter_upwards [hf j] with x hx hn
    have hh : x ∈ K := hx hn
    simp [χ, hh]
  have he : T (∑' j, f j) = ∑' j, f j := by
    have h := T.hasSum hs.hasSum
    simp only [hTf] at h
    exact h.unique hs.hasSum
  filter_upwards [cutoffOperator_support χ hχ hC (∑' j, f j)] with x hx hn
  by_contra h
  have hz : x ∉ K := by simpa only [id_eq] using h
  have hzero : χ x = 0 := by simp [χ, hz]
  have hh := hx hzero
  change T (∑' j, f j) x = 0 at hh
  rw [he] at hh
  exact hn hh


/-- finite overlap controls the energy of a sum of supported inputs. -/
theorem finite_overlap_L2_energy {Ω ι : Type*} [MeasurableSpace Ω] [Fintype ι] (μ : Measure Ω)
    (K : ι → Set Ω) (f : ι → Lp ℂ 2 μ)
    (hf : ∀ j, HasFrequencySupport μ id (K j) (f j))
    {M : ℝ} (hM : ∀ᵐ x ∂μ, (∑ j, (K j).indicator (fun _ : Ω => (1 : ℝ)) x) ≤ M) :
    ‖∑ j, f j‖ ^ 2 ≤ M * ∑ j, ‖f j‖ ^ 2 := by
  classical
  have hae (s : Finset ι) : (fun x => (∑ j ∈ s, f j : Lp ℂ 2 μ) x) =ᵐ[μ]
      fun x => ∑ j ∈ s, f j x := by
    induction s using Finset.induction_on with
    | empty => simpa using (Lp.coeFn_zero ℂ 2 μ)
    | @insert j s hj ih =>
      simp only [Finset.sum_insert hj]
      filter_upwards [Lp.coeFn_add (f j) (∑ k ∈ s, f k), ih] with x hx hi
      simpa only [Pi.add_apply, hi] using hx
  simp_rw [l2_norm_sq_eq_integral]
  rw [← integral_finset_sum _ (fun j _ => l2_integrable_norm_sq (f j)), ← integral_const_mul]
  apply integral_mono_ae
  · exact l2_integrable_norm_sq (∑ j, f j)
  · exact (integrable_finset_sum _ (fun j _ => l2_integrable_norm_sq (f j))).const_mul M
  · filter_upwards [hae Finset.univ, ae_all_iff.mpr hf, hM] with x hx hfx hMx
    rw [hx]
    let w : ι → ℝ := fun j => (K j).indicator (fun _ => 1) x
    have hw (j) : w j * ‖f j x‖ = ‖f j x‖ := by
      by_cases h : x ∈ K j
      · simp [w, h]
      · have hz : f j x = 0 := by
          by_contra hn
          exact h (hfx j hn)
        simp [hz]
    have hw2 (j) : w j ^ 2 = w j := by
      by_cases h : x ∈ K j <;> simp [w, h]
    have hcs := Finset.sum_mul_sq_le_sq_mul_sq Finset.univ w (fun j => ‖f j x‖)
    simp only [hw, hw2] at hcs
    have hn : ‖∑ j, f j x‖ ^ 2 ≤ (∑ j, ‖f j x‖) ^ 2 :=
      pow_le_pow_left₀ (norm_nonneg _) (norm_sum_le _ _) 2
    exact hn.trans (hcs.trans (mul_le_mul_of_nonneg_right hMx
      (Finset.sum_nonneg (fun j _ => sq_nonneg ‖f j x‖))))


/-- cross-cap almost orthogonality, conditional on actual overlap. -/
theorem actual_cross_cap_almost_orthogonal {d : ℕ} {ι : Type*} [Fintype ι]
    (c : ι → Ambient d) (r : ℝ) (hr : 0 < r)
    (f : (j : ι) → Lp ℂ 2 (volume.restrict (packetFrequencyCube (c j) r hr)))
    (S : ι → Set (Fin d → ℤ)) {M : ℝ} (hM0 : 0 ≤ M)
    (hM : ∀ᵐ x ∂(volume : Measure (Ambient d)),
      (∑ j, (Metric.ball (c j) (2 * r)).indicator (fun _ => (1 : ℝ)) x) ≤ M) :
    packetCutoffEnergy d * ‖∑ j, ∑' ν : S j, actualPacketInput (c j) r hr (f j) ν‖ ^ 2 ≤
      M * (2 * Real.pi) ^ d *
        ∑ j, ∑' ν : S j, ‖actualPacketInput (c j) r hr (f j) ν‖ ^ 2 := by
  let g : ι → Lp ℂ 2 (volume : Measure (Ambient d)) :=
    fun j => ∑' ν : S j, actualPacketInput (c j) r hr (f j) ν
  have hg (j) : HasFrequencySupport volume id (Metric.ball (c j) (2 * r)) (g j) :=
    HasFrequencySupport.tsum_L2 volume _ measurableSet_ball _
      (actualPacketInput_selected_summable (c j) r hr (f j) (S j))
      (fun ν => actualPacketInput_support (c j) r hr (f j) ν)
  have hsum := finite_overlap_L2_energy volume (fun j => Metric.ball (c j) (2 * r)) g hg hM
  have henergy := Finset.sum_le_sum (s := Finset.univ) (fun j _ =>
    actualPacketInput_almost_orthogonal (c j) r hr (f j) (S j))
  have hsum' := mul_le_mul_of_nonneg_left hsum (packetCutoffEnergy_pos d).le
  have henergy' := mul_le_mul_of_nonneg_left henergy hM0
  rw [← Finset.mul_sum, ← Finset.mul_sum] at henergy'
  change packetCutoffEnergy d * ‖∑ j, g j‖ ^ 2 ≤ _
  nlinarith only [hsum', henergy']


end N2Restriction
