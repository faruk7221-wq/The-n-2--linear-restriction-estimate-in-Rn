import N2Restriction.SurfaceMeasure

namespace N2Restriction
open MeasureTheory

/-- The nearby-plane differential still has the expected n-3-dimensional kernel. -/
theorem nearby_thin_kernel_dimension {n : ℕ} (S : SmoothPatch n)
    (W H : Submodule ℝ (Ambient n)) (hWdim : Module.finrank ℝ W = 2)
    (hHdim : Module.finrank ℝ H = 2)
    {z : Ambient n} (hz : z ∈ S.neighborhood)
    (hW : ∀ v : W, inner ℝ (S.normal z) (v : Ambient n) = 0)
    {κ : ℝ} (hκ : 0 < κ)
    (hA : ∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (S.shape z v)‖)
    (hgap : ‖W.starProjection - H.starProjection‖ * ‖S.shape z‖ ≤ κ / 2) :
    Module.finrank ℝ (LinearMap.ker (thinDifferential S H z).toLinearMap) = n - 3 := by
  let L := thinDifferential S H z
  have hrange : LinearMap.range L.toLinearMap = ⊤ :=
    LinearMap.range_eq_top.mpr
      (nearby_thinDifferential_surjective S W H (hWdim.trans hHdim.symm) hz hW hκ hA hgap)
  have hd := L.toLinearMap.finrank_range_add_finrank_ker
  rw [hrange] at hd
  simp only [finrank_top, Module.finrank_prod, Module.finrank_self, hHdim,
    Ambient, finrank_euclideanSpace, Fintype.card_fin] at hd
  change Module.finrank ℝ (LinearMap.ker L.toLinearMap) = n - 3
  have he : 3 + Module.finrank ℝ (LinearMap.ker L.toLinearMap) = n := hd
  omega

/-- A compact part of a nearby-plane thin-support zero set has finite
(n-3)-dimensional Hausdorff measure. Coercivity is required at every point. -/
theorem thin_support_finite_mass {n : ℕ} (hn : 3 ≤ n) (S : SmoothPatch n)
    (H : Submodule ℝ (Ambient n)) (hHdim : Module.finrank ℝ H = 2)
    {K : Set (Ambient n)} (hK : IsCompact K)
    (hlevel : ∀ z ∈ K, z ∈ S.extendedSurface ∧ H.orthogonalProjection (S.normal z) = 0)
    (hreg : ∀ z ∈ K, ∃ W : Submodule ℝ (Ambient n),
      Module.finrank ℝ W = 2 ∧
      (∀ v : W, inner ℝ (S.normal z) (v : Ambient n) = 0) ∧
      ∃ κ : ℝ, 0 < κ ∧
        (∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (S.shape z v)‖) ∧
        ‖W.starProjection - H.starProjection‖ * ‖S.shape z‖ ≤ κ / 2) :
    Measure.hausdorffMeasure ((n : ℝ) - 3) K < ⊤ := by
  have hzero : ∀ z ∈ K, thinConstraint S H z = 0 := by
    intro z hz
    apply Prod.ext
    · exact (hlevel z hz).1.2
    · exact (hlevel z hz).2
  have hr : ∀ z ∈ K, ∃ L : Ambient n →L[ℝ] (ℝ × H),
      HasStrictFDerivAt (thinConstraint S H) L z ∧ Function.Surjective L := by
    intro z hz
    obtain ⟨W, hWdim, hW, κ, hκ, hA, hgap⟩ := hreg z hz
    have hzn := (hlevel z hz).1.1
    have hds := S.smooth_defining.contDiffAt (S.open_neighborhood.mem_nhds hzn)
    have hns := S.smooth_normal.contDiffAt (S.open_neighborhood.mem_nhds hzn)
    have hs : ContDiffAt ℝ (⊤ : ℕ∞) (thinConstraint S H) z :=
      hds.prodMk (H.orthogonalProjection.contDiff.contDiffAt.comp z hns)
    exact ⟨thinDifferential S H z,
      hs.hasStrictFDerivAt' (hasFDerivAt_thinConstraint S H hzn) (by simp),
      nearby_thinDifferential_surjective S W H (hWdim.trans hHdim.symm) hzn hW hκ hA hgap⟩
  have h := compact_regular_level_finite hK hzero hr
  simpa only [Ambient, finrank_euclideanSpace, Fintype.card_fin,
    Module.finrank_prod, Module.finrank_self, hHdim, show 1 + 2 = 3 from rfl,
    Nat.cast_sub hn, Nat.cast_ofNat] using h

end N2Restriction
