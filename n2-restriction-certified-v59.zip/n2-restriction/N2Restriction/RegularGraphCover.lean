import N2Restriction.VerticalLevelGraph

namespace N2Restriction
open MeasureTheory Set Filter

/-- Some orthogonal coordinate permutation makes the defining derivative vertical-regular. -/
theorem SmoothPatch.exists_vertical_rotation {d : ℕ} (S : SmoothPatch (d + 1))
    {z : Ambient (d + 1)} (hz : z ∈ S.neighborhood) :
    ∃ A : Ambient (d + 1) ≃ₗᵢ[ℝ] Ambient (d + 1),
      fderiv ℝ (fun x => S.defining (A x)) (A.symm z) (graphPoint (0 : Ambient d) 1) ≠ 0 := by
  have hn : S.normal z ≠ 0 := by
    intro h
    have hunit := S.normal_unit z hz
    rw [h, norm_zero] at hunit
    norm_num at hunit
  have hj : ∃ j : Fin (d + 1), S.normal z j ≠ 0 := by
    by_contra h
    push_neg at h
    apply hn
    ext j
    exact h j
  obtain ⟨j, hj⟩ := hj
  let A : Ambient (d + 1) ≃ₗᵢ[ℝ] Ambient (d + 1) :=
    LinearIsometryEquiv.piLpCongrLeft 2 ℝ ℝ (Equiv.swap 0 j)
  have ha : A (graphPoint (0 : Ambient d) 1) = EuclideanSpace.single j 1 := by
    rw [graphPoint_vertical_single]
    change LinearIsometryEquiv.piLpCongrLeft 2 ℝ ℝ (Equiv.swap 0 j)
      (WithLp.toLp 2 (Pi.single 0 (1 : ℝ))) = WithLp.toLp 2 (Pi.single j (1 : ℝ))
    rw [LinearIsometryEquiv.piLpCongrLeft_single, Equiv.swap_apply_left]
  have hf := (S.smooth_defining.contDiffAt (S.open_neighborhood.mem_nhds hz)).differentiableAt (by simp)
  have hd0 : HasFDerivAt S.defining (fderiv ℝ S.defining z) (A (A.symm z)) := by
    simpa only [A.apply_symm_apply] using hf.hasFDerivAt
  have hd := hd0.comp (A.symm z) A.toContinuousLinearMap.hasFDerivAt
  refine ⟨A, ?_⟩
  change fderiv ℝ (S.defining ∘ (A : Ambient (d + 1) → Ambient (d + 1))) (A.symm z) _ ≠ 0
  rw [hd.fderiv]
  change fderiv ℝ S.defining z (A (graphPoint (0 : Ambient d) 1)) ≠ 0
  rw [ha, S.normal_differential z hz, EuclideanSpace.inner_single_right]
  simpa using mul_ne_zero (S.positive_normalScale z hz).ne' hj

/-- Every supported regular-level-set point has a neighborhood covered by one concrete graph patch. -/
theorem SmoothPatch.exists_local_graph_patch {d : ℕ} (S : SmoothPatch (d + 1))
    {z : Ambient (d + 1)} (hz : z ∈ S.support) :
    ∃ P : LocalGraphPatch d,
      (∀ u ∈ P.domain, P.rotation (graphPoint u (P.phase u)) ∈ S.extendedSurface) ∧
      P.carrier ⊆ S.extendedSurface ∧
      ∀ᶠ x in nhds z, S.defining x = 0 → x ∈ P.carrier := by
  obtain ⟨A, hA⟩ := S.exists_vertical_rotation (S.support_inside hz)
  let f : Ambient (d + 1) → ℝ := fun x => S.defining (A x)
  let U := A ⁻¹' S.neighborhood
  have hU : IsOpen U := S.open_neighborhood.preimage A.continuous
  have hf : ContDiffOn ℝ (⊤ : ℕ∞) f U :=
    S.smooth_defining.comp A.contDiff.contDiffOn (fun _ hx => hx)
  have hzU : A.symm z ∈ U := by simpa [U] using S.support_inside hz
  obtain ⟨W, φ, hW, hzW, hφ, hlevel, hinside, hgraph⟩ := exists_vertical_level_graph hU hf hzU hA
  obtain ⟨r, hr, hrW⟩ := Metric.mem_nhds_iff.mp (hW.mem_nhds hzW)
  let c := graphProjection (A.symm z)
  let P : LocalGraphPatch d := {
    rotation := A, domain := W, open_domain := hW, phase := φ, smooth_phase := hφ,
    center := c, innerRadius := r / 4, outerRadius := r / 2,
    positive_inner := by positivity, radii_lt := by linarith,
    ball_inside := by
      intro x hx
      apply hrW
      exact lt_of_le_of_lt (show dist x c ≤ r / 2 from hx) (by linarith),
    support := Metric.closedBall c (r / 4), compact_support := isCompact_closedBall _ _,
    support_inside := Subset.rfl }
  have hPinside : P.carrier ⊆ S.extendedSurface := by
    rintro y ⟨x, ⟨u, hu, rfl⟩, rfl⟩
    have huW : u ∈ W := hrW (lt_of_le_of_lt
      (show dist u c ≤ r / 4 from hu) (by linarith))
    refine ⟨hinside u huW, ?_⟩
    have h := hlevel u huW
    simpa only [f, A.apply_symm_apply, S.support_on_surface z hz] using h
  have hPdomain : ∀ u ∈ P.domain, P.rotation (graphPoint u (P.phase u)) ∈ S.extendedSurface := by
    intro u hu
    refine ⟨hinside u hu, ?_⟩
    have h := hlevel u hu
    simpa only [f, A.apply_symm_apply, S.support_on_surface z hz] using h
  refine ⟨P, hPdomain, hPinside, ?_⟩
  have hnear : ∀ᶠ x in nhds (A.symm z), graphProjection x ∈ Metric.ball c (r / 4) :=
    graphProjection_lipschitz.continuous.continuousAt.preimage_mem_nhds
      (Metric.ball_mem_nhds c (by positivity))
  have hall : ∀ᶠ x in nhds (A.symm z), f x = 0 → A x ∈ P.carrier := by
    filter_upwards [hgraph, hnear] with x hx hxc hzero
    have hbase : f (A.symm z) = 0 := by simpa [f] using S.support_on_surface z hz
    have he := hx (hzero.trans hbase.symm)
    refine ⟨x, ?_, rfl⟩
    exact ⟨graphProjection x, (show dist (graphProjection x) c < r / 4 from hxc).le, he.symm⟩
  have hp := A.symm.continuous.continuousAt.tendsto.eventually hall
  simpa only [f, A.apply_symm_apply] using hp

/-- Compactness turns the pointwise regular-level-set graph construction into a finite cover. -/
theorem SmoothPatch.exists_finite_graph_cover {d : ℕ} (S : SmoothPatch (d + 1)) :
    ∃ (m : ℕ) (P : Fin m → LocalGraphPatch d),
      (S.support ⊆ ⋃ j, (P j).carrier) ∧ (∀ j, (P j).carrier ⊆ S.extendedSurface) ∧
      ∀ j u, u ∈ (P j).domain → (P j).rotation (graphPoint u ((P j).phase u)) ∈ S.extendedSurface := by
  classical
  have hl (z : S.support) : ∃ (P : LocalGraphPatch d) (V : Set (Ambient (d + 1))),
      (∀ u ∈ P.domain, P.rotation (graphPoint u (P.phase u)) ∈ S.extendedSurface) ∧
      P.carrier ⊆ S.extendedSurface ∧ IsOpen V ∧ (z : Ambient (d + 1)) ∈ V ∧
      ∀ x ∈ V, S.defining x = 0 → x ∈ P.carrier := by
    obtain ⟨P, hPD, hPS, hP⟩ := S.exists_local_graph_patch z.property
    obtain ⟨V, hVsub, hVopen, hzV⟩ := _root_.mem_nhds_iff.mp hP
    exact ⟨P, V, hPD, hPS, hVopen, hzV, fun x hx => hVsub hx⟩
  choose P V hPD hPS hV hzV hprop using hl
  have hcover : S.support ⊆ ⋃ z : S.support, V z := by
    intro x hx
    exact mem_iUnion.mpr ⟨⟨x, hx⟩, hzV ⟨x, hx⟩⟩
  obtain ⟨t, ht⟩ := S.compact_support.elim_finite_subcover V hV hcover
  let e := Fintype.equivFin ↥t
  refine ⟨Fintype.card ↥t, fun j => P (e.symm j).val, ?_, fun j => hPS _, fun j => hPD _⟩
  intro x hx
  obtain ⟨z, hzt, hxV⟩ := mem_iUnion₂.mp (ht hx)
  refine mem_iUnion.mpr ⟨e ⟨z, hzt⟩, ?_⟩
  simpa only [Equiv.symm_apply_apply] using hprop z x hxV (S.support_on_surface x hx)

end N2Restriction
