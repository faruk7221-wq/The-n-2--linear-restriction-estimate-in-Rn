import N2Restriction.EuclideanTubes
import N2Restriction.CapPacketTails

namespace N2Restriction

/-- Single-packet decay in perpendicular Euclidean distance from the infinite
axis. No bound on the cap center is needed in this direction. -/
theorem paraboloid_packet_round_axis_decay (d M : ℕ) {χ : Ambient d → ℂ}
    (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hs : HasCompactSupport χ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (c : Ambient d) (r : ℝ), 0 < r →
      ∀ (v u : Ambient d) (t : ℝ), |t * r ^ 2| ≤ 1 →
      ‖graphPacket (fun ξ => inner ℝ ξ ξ / 2) χ c r v u t‖ ≤
        r ^ ((d : ℝ) / 2) * (C /
          (1 + r * Metric.infDist (graphPoint u t) (packetAxis c v)) ^ M) := by
  obtain ⟨C, hC, hb⟩ := paraboloid_packet_decay d M hχ hs
  refine ⟨C, hC, fun c r hr v u t ht => (hb c r hr v u t ht).trans ?_⟩
  have hd := packetAxis_dist_le_offset c v u t
  have hn := Metric.infDist_nonneg (x := graphPoint u t) (s := packetAxis c v)
  gcongr

/-- Actual finite-segment tube localization at the article's parabolic scale. -/
theorem paraboloid_packet_round_segment_decay (d M : ℕ) {χ : Ambient d → ℂ}
    (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hs : HasCompactSupport χ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (R : ℝ), 0 < R →
      ∀ (c v u : Ambient d) (t : ℝ), |t| ≤ R →
      ‖graphPacket (fun ξ => inner ℝ ξ ξ / 2) χ c (R ^ (-1 / 2 : ℝ)) v u t‖ ≤
        R ^ (-(d : ℝ) / 4) * (C /
          (1 + R ^ (-1 / 2 : ℝ) *
            Metric.infDist (graphPoint u t) (packetSegment c v R)) ^ M) := by
  obtain ⟨C, hC, hb⟩ := paraboloid_packet_decay_at_scale d M hχ hs
  refine ⟨C, hC, fun R hR c v u t ht => (hb R hR c v u t ht).trans ?_⟩
  have hd := packetSegment_dist_le_offset c v u ht
  have hn := Metric.infDist_nonneg (x := graphPoint u t) (s := packetSegment c v R)
  gcongr

/-- A Euclidean ball-exclusion condition for each finite tube gives rapid
absolute decay for any selected subcollection of actual paraboloid packets. -/
theorem paraboloid_round_segment_rapid_tail (d : ℕ) {χ : Ambient d → ℂ}
    (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hs : HasCompactSupport χ)
    {τ : ℝ} (hτ : 0 < τ) (b N : ℝ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (R : ℝ), 1 ≤ R →
      ∀ {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E],
      ∀ (e : HilbertBasis (Fin d → ℤ) ℂ E) (x : E) (c u : Ambient d) (t : ℝ),
      |t| ≤ R → ∀ S : Set (Fin d → ℤ),
      (∀ ν ∈ S, R ^ (1 / 2 + τ) / 10 ≤ Metric.infDist (graphPoint u t)
        (packetSegment c ((R ^ (-1 / 2 : ℝ))⁻¹ • latticeVector ν) R)) →
      R ^ b * (∑' ν : S, ‖e.repr x ν * graphPacket (fun ξ => inner ℝ ξ ξ / 2) χ c
        (R ^ (-1 / 2 : ℝ)) ((R ^ (-1 / 2 : ℝ))⁻¹ • latticeVector ν) u t‖) ≤
        C * R ^ (-N) * ‖x‖ := by
  obtain ⟨C, hC, hb⟩ := paraboloid_rapid_selected_packet_tail d hχ hs hτ b N
  refine ⟨C, hC, ?_⟩
  intro R hR E _ _ e x c u t ht S hS
  exact hb R hR e x c u t ht S (fun ν hν =>
    (hS ν hν).trans (packetSegment_dist_le_offset c _ u ht))

/-- The finite-cap rapid tail theorem with ordinary round finite tubes.
The cap-count and energy hypotheses remain explicit. -/
theorem paraboloid_round_finite_cap_rapid_tail (d : ℕ) {χ : Ambient d → ℂ}
    (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hs : HasCompactSupport χ)
    {τ : ℝ} (hτ : 0 < τ) (a N : ℝ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (R : ℝ), 1 ≤ R →
      ∀ {ι E : Type*} [Fintype ι] [NormedAddCommGroup E] [InnerProductSpace ℂ E],
      ∀ (b : HilbertBasis (Fin d → ℤ) ℂ E) (x : ι → E) (c : ι → Ambient d)
        (u : Ambient d) (t : ℝ), |t| ≤ R →
      ∀ (A B F : ℝ), 0 ≤ A → 0 ≤ B → 0 ≤ F →
      (Fintype.card ι : ℝ) ≤ A * R ^ a → (∑ j, ‖x j‖ ^ 2) ≤ B * F ^ 2 →
      ∀ S : ι → Set (Fin d → ℤ),
      (∀ j ν, ν ∈ S j → R ^ (1 / 2 + τ) / 10 ≤ Metric.infDist (graphPoint u t)
        (packetSegment (c j) ((R ^ (-1 / 2 : ℝ))⁻¹ • latticeVector ν) R)) →
      (∑ j, ∑' ν : S j, ‖b.repr (x j) ν * graphPacket (fun ξ => inner ℝ ξ ξ / 2)
        χ (c j) (R ^ (-1 / 2 : ℝ)) ((R ^ (-1 / 2 : ℝ))⁻¹ • latticeVector ν) u t‖) ≤
        C * Real.sqrt A * Real.sqrt B * R ^ (-N) * F := by
  obtain ⟨C, hC, hb⟩ := paraboloid_finite_cap_rapid_tail d hχ hs hτ a N
  refine ⟨C, hC, ?_⟩
  intro R hR ι E _ _ _ b x c u t ht A B F hA hB hF hcard henergy S hS
  exact hb R hR b x c u t ht A B F hA hB hF hcard henergy S (fun j ν hν =>
    (hS j ν hν).trans (packetSegment_dist_le_offset (c j) _ u ht))

end N2Restriction
