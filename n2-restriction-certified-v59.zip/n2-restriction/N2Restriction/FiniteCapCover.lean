import N2Restriction.CrossCapPackets

namespace N2Restriction
open Metric Set

/-- Greedy finite nets retain their centers in the original set. -/
theorem finite_separated_net {E : Type*} [PseudoMetricSpace E]
    (s : Finset E) {δ : ℝ} (hδ : 0 ≤ δ) :
    ∃ t : Finset E, t ⊆ s ∧
      (↑t : Set E).Pairwise (fun x y => δ < dist x y) ∧
      ∀ x ∈ s, ∃ y ∈ t, dist x y ≤ δ := by
  classical
  induction s using Finset.induction_on with
  | empty => exact ⟨∅, by simp, by simp, by simp⟩
  | @insert x s hx ih =>
    obtain ⟨t, hts, ht, hcover⟩ := ih
    by_cases h : ∃ y ∈ t, dist x y ≤ δ
    · refine ⟨t, hts.trans (Finset.subset_insert _ _), ht, ?_⟩
      intro z hz
      rcases Finset.mem_insert.mp hz with rfl | hz
      · exact h
      · exact hcover z hz
    · have hfar : ∀ y ∈ t, δ < dist x y := by
        intro y hy
        exact lt_of_not_ge (fun hle => h ⟨y, hy, hle⟩)
      refine ⟨insert x t, Finset.insert_subset_insert _ hts, ?_, ?_⟩
      · intro a ha b hb hab
        rcases Finset.mem_insert.mp ha with rfl | hta
        · rcases Finset.mem_insert.mp hb with rfl | htb
          · exact (hab rfl).elim
          · exact hfar b htb
        · rcases Finset.mem_insert.mp hb with rfl | htb
          · simpa only [dist_comm] using hfar a hta
          · exact ht hta htb hab
      · intro z hz
        rcases Finset.mem_insert.mp hz with rfl | hz
        · exact ⟨z, Finset.mem_insert_self _ _, by simpa using hδ⟩
        · obtain ⟨y, hy, hzy⟩ := hcover z hz
          exact ⟨y, Finset.mem_insert_of_mem hy, hzy⟩

/-- A compact coordinate support admits a finite separated family of cap centers.
The inner balls of radius 3r/4 cover it; centers remain in the original support. -/
theorem compact_separated_cap_cover {d : ℕ} {K : Set (Ambient d)} (hK : IsCompact K)
    {r : ℝ} (hr : 0 < r) :
    ∃ t : Finset (Ambient d), (↑t : Set (Ambient d)) ⊆ K ∧
      (↑t : Set (Ambient d)).Pairwise (fun x y => r / 2 < dist x y) ∧
      ∀ x ∈ K, ∃ c ∈ t, dist x c < 3 * r / 4 := by
  classical
  obtain ⟨s, hsK, hs, hcover⟩ := hK.finite_cover_balls (show 0 < r / 4 by positivity)
  obtain ⟨t, hts, ht, hnet⟩ := finite_separated_net hs.toFinset (show 0 ≤ r / 2 by positivity)
  refine ⟨t, fun x hx => hsK (hs.mem_toFinset.mp (hts hx)), ht, ?_⟩
  intro x hx
  obtain ⟨y, hy, hxy⟩ := Set.mem_iUnion₂.mp (hcover hx)
  obtain ⟨c, hc, hyc⟩ := hnet y (hs.mem_toFinset.mpr hy)
  refine ⟨c, hc, ?_⟩
  have hxy' : dist x y < r / 4 := hxy
  have := dist_triangle x y c
  linarith

end N2Restriction
