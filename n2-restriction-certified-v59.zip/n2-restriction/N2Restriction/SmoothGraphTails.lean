import N2Restriction.SmoothGraphPackets

namespace N2Restriction

/-- Absolute convergence and uniform selected tails for globally smooth
graphs, derived from the constructed Taylor family. -/
theorem smooth_graph_selected_packet_tail {d : ℕ} {φ : Ambient d → ℝ}
    (hφ : ContDiff ℝ (⊤ : ℕ∞) φ) {Q : Set (Ambient d)} (hQ : IsCompact Q)
    {χ : Ambient d → ℂ} (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hs : HasCompactSupport χ)
    (M : ℕ) :
    ∃ C : ℝ, 0 ≤ C ∧
      ∀ {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E],
      ∀ (b : HilbertBasis (Fin d → ℤ) ℂ E) (x : E) (c : Ambient d), c ∈ Q →
      ∀ (u : Ambient d) (r : ℝ), 0 < r → r ≤ 1 →
      ∀ (t L : ℝ), |t * r ^ 2| ≤ 1 → 0 ≤ L →
      ∀ S : Set (Fin d → ℤ),
      (∀ ν ∈ S, L ≤ ‖latticeVector ν - (-(r • (u + t • graphGradient φ c)))‖) →
      Summable (fun ν : S => b.repr x ν * graphPacket φ χ c r (r⁻¹ • latticeVector ν) u t) ∧
      (∑' ν : S, ‖b.repr x ν * graphPacket φ χ c r (r⁻¹ • latticeVector ν) u t‖) ≤
        r ^ ((d : ℝ) / 2) * (C / (1 + L) ^ M) * ‖x‖ := by
  obtain ⟨C, hC, hb⟩ := smooth_graph_packet_decay hφ hQ hχ hs 1 (d + M)
  refine ⟨C * (2 ^ d * ‖latticeWeight d‖), by positivity, ?_⟩
  intro E _ _ b x c hc u r hr hr1 t L ht hL S hS
  let a : Ambient d := -(r • (u + t • graphGradient φ c))
  let packet : (Fin d → ℤ) → ℂ := fun ν => b.repr x ν *
    graphPacket φ χ c r (r⁻¹ • latticeVector ν) u t
  have hC' : 0 ≤ r ^ ((d : ℝ) / 2) * C := by positivity
  have hp (ν : Fin d → ℤ) : ‖packet ν‖ ≤
      (r ^ ((d : ℝ) / 2) * C) * ‖b.repr x ν‖ /
        (1 + ‖latticeVector ν - a‖) ^ (d + M) := by
    have hd := hb c hc r hr hr1 (r⁻¹ • latticeVector ν) u t ht
    have he : r * ‖u + r⁻¹ • latticeVector ν + t • graphGradient φ c‖ =
        ‖latticeVector ν - a‖ := by
      have hh := congrArg norm (rescaled_packet_axis u (graphGradient φ c) t hr.ne' ν)
      simpa only [norm_smul, Real.norm_eq_abs, abs_of_pos hr, a] using hh
    rw [he] at hd
    change ‖b.repr x ν * _‖ ≤ _
    rw [norm_mul]
    exact (mul_le_mul_of_nonneg_left hd (norm_nonneg _)).trans_eq (by ring)
  have hsum := (radial_packet_norm_summable b x a packet hC' M hp).subtype S
  refine ⟨hsum.of_norm, ?_⟩
  exact (radial_packet_absolute_tail b x a packet hC' hL M hp S hS).trans_eq (by ring)

/-- Every prescribed rapid-decay order holds for selected packets outside
the enlarged physical axis-offset tubes of a general smooth graph. -/
theorem smooth_graph_rapid_selected_tail {d : ℕ} {φ : Ambient d → ℝ}
    (hφ : ContDiff ℝ (⊤ : ℕ∞) φ) {Q : Set (Ambient d)} (hQ : IsCompact Q)
    {χ : Ambient d → ℂ} (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hs : HasCompactSupport χ)
    {τ : ℝ} (hτ : 0 < τ) (b N : ℝ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (R : ℝ), 1 ≤ R →
      ∀ {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E],
      ∀ (e : HilbertBasis (Fin d → ℤ) ℂ E) (x : E) (c : Ambient d), c ∈ Q →
      ∀ (u : Ambient d) (t : ℝ), |t| ≤ R → ∀ S : Set (Fin d → ℤ),
      (∀ ν ∈ S, R ^ (1 / 2 + τ) / 10 ≤
        ‖u + (R ^ (-1 / 2 : ℝ))⁻¹ • latticeVector ν + t • graphGradient φ c‖) →
      R ^ b * (∑' ν : S, ‖e.repr x ν * graphPacket φ χ c
        (R ^ (-1 / 2 : ℝ)) ((R ^ (-1 / 2 : ℝ))⁻¹ • latticeVector ν) u t‖) ≤
        C * R ^ (-N) * ‖x‖ := by
  obtain ⟨M, hM⟩ := exists_packet_tail_order hτ (b - d / 4) N
  obtain ⟨C, hC, hb⟩ := smooth_graph_selected_packet_tail hφ hQ hχ hs M
  refine ⟨C * 10 ^ M, by positivity, ?_⟩
  intro R hR E _ _ e x c hc u t ht S hS
  have hRp : 0 < R := by linarith
  have hr := Real.rpow_pos_of_pos hRp (-1 / 2 : ℝ)
  have hr1 : R ^ (-1 / 2 : ℝ) ≤ 1 := Real.rpow_le_one_of_one_le_of_nonpos hR (by norm_num)
  have htail := (hb e x c hc u (R ^ (-1 / 2 : ℝ)) hr hr1 t (R ^ τ / 10)
    (parabolic_time_parameter hRp ht) (by positivity) S
    (fun ν hν => physical_to_rescaled_tube_exclusion hRp u (graphGradient φ c) t ν (hS ν hν))).2
  have hscale : R ^ b * (R ^ (-1 / 2 : ℝ)) ^ ((d : ℝ) / 2) = R ^ (b - d / 4) := by
    rw [← Real.rpow_mul hRp.le, ← Real.rpow_add hRp]
    congr 1
    ring
  calc
    _ ≤ R ^ b * ((R ^ (-1 / 2 : ℝ)) ^ ((d : ℝ) / 2) *
        (C / (1 + R ^ τ / 10) ^ M) * ‖x‖) :=
      mul_le_mul_of_nonneg_left htail (Real.rpow_nonneg hRp.le _)
    _ = C * ‖x‖ * (R ^ (b - d / 4) / (1 + R ^ τ / 10) ^ M) := by
      rw [← hscale]
      ring
    _ ≤ C * ‖x‖ * (10 ^ M * R ^ (-N)) :=
      mul_le_mul_of_nonneg_left (hM R hR) (mul_nonneg hC (norm_nonneg _))
    _ = _ := by ring

/-- Rapid selected tails for ordinary round finite tubes, for general smooth
graphs with centers in a fixed compact set. -/
theorem smooth_graph_round_segment_rapid_tail {d : ℕ} {φ : Ambient d → ℝ}
    (hφ : ContDiff ℝ (⊤ : ℕ∞) φ) {Q : Set (Ambient d)} (hQ : IsCompact Q)
    {χ : Ambient d → ℂ} (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hs : HasCompactSupport χ)
    {τ : ℝ} (hτ : 0 < τ) (b N : ℝ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (R : ℝ), 1 ≤ R →
      ∀ {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E],
      ∀ (e : HilbertBasis (Fin d → ℤ) ℂ E) (x : E) (c : Ambient d), c ∈ Q →
      ∀ (u : Ambient d) (t : ℝ), |t| ≤ R → ∀ S : Set (Fin d → ℤ),
      (∀ ν ∈ S, R ^ (1 / 2 + τ) / 10 ≤ Metric.infDist (graphPoint u t)
        (packetSegment (graphGradient φ c) ((R ^ (-1 / 2 : ℝ))⁻¹ • latticeVector ν) R)) →
      R ^ b * (∑' ν : S, ‖e.repr x ν * graphPacket φ χ c
        (R ^ (-1 / 2 : ℝ)) ((R ^ (-1 / 2 : ℝ))⁻¹ • latticeVector ν) u t‖) ≤
        C * R ^ (-N) * ‖x‖ := by
  obtain ⟨C, hC, hb⟩ := smooth_graph_rapid_selected_tail hφ hQ hχ hs hτ b N
  refine ⟨C, hC, ?_⟩
  intro R hR E _ _ e x c hc u t ht S hS
  exact hb R hR e x c hc u t ht S (fun ν hν =>
    (hS ν hν).trans (packetSegment_dist_le_offset (graphGradient φ c) _ u ht))

end N2Restriction
