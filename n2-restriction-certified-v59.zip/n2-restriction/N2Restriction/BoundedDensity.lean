import N2Restriction.DensityL2
import Mathlib.MeasureTheory.Measure.Decomposition.RadonNikodym

namespace N2Restriction
open MeasureTheory
open scoped ENNReal NNReal

/-- Upper measure domination gives an almost-everywhere upper density bound. -/
theorem rnDeriv_le_constant {Ω : Type*} [MeasurableSpace Ω] (μ ν : Measure Ω)
    [SigmaFinite μ] (C : ℝ≥0) (hC : ν ≤ (C : ℝ≥0∞) • μ) :
    ∀ᵐ x ∂μ, ν.rnDeriv μ x ≤ (C : ℝ≥0∞) := by
  apply ae_le_of_forall_setLIntegral_le_of_sigmaFinite (Measure.measurable_rnDeriv ν μ)
  intro s hs _
  calc
    ∫⁻ x in s, ν.rnDeriv μ x ∂μ ≤ ν s := Measure.setLIntegral_rnDeriv_le s
    _ ≤ (C : ℝ≥0∞) * μ s := hC s
    _ = ∫⁻ _ in s, (C : ℝ≥0∞) ∂μ := by simp

/-- Lower measure domination gives an almost-everywhere positive density bound. -/
theorem constant_le_rnDeriv {Ω : Type*} [MeasurableSpace Ω] (μ ν : Measure Ω)
    [SigmaFinite μ] [SigmaFinite ν] (c : ℝ≥0) (hν : ν ≪ μ)
    (hc : (c : ℝ≥0∞) • μ ≤ ν) :
    ∀ᵐ x ∂μ, (c : ℝ≥0∞) ≤ ν.rnDeriv μ x := by
  apply ae_le_of_forall_setLIntegral_le_of_sigmaFinite measurable_const
  intro s hs _
  calc
    ∫⁻ _ in s, (c : ℝ≥0∞) ∂μ = (c : ℝ≥0∞) * μ s := by simp
    _ ≤ ν s := hc s
    _ = ∫⁻ x in s, ν.rnDeriv μ x ∂μ := (Measure.setLIntegral_rnDeriv' hν hs).symm

/-- Comparable sigma-finite measures admit a measurable, finite, bounded density.
The bounds are only required almost everywhere, as appropriate for L2 inputs. -/
theorem exists_bounded_density {Ω : Type*} [MeasurableSpace Ω] (μ ν : Measure Ω)
    [SigmaFinite μ] [SigmaFinite ν] (c C : ℝ≥0)
    (hc : (c : ℝ≥0∞) • μ ≤ ν) (hC : ν ≤ (C : ℝ≥0∞) • μ) :
    ∃ J : Ω → ℝ≥0, Measurable J ∧
      (∀ᵐ x ∂μ, c ≤ J x ∧ J x ≤ C) ∧
      μ.withDensity (fun x => (J x : ℝ≥0∞)) = ν := by
  have hν : ν ≪ μ := Measure.absolutelyContinuous_of_le_smul hC
  let J : Ω → ℝ≥0 := fun x => (ν.rnDeriv μ x).toNNReal
  have hJ : Measurable J := (Measure.measurable_rnDeriv ν μ).ennreal_toNNReal
  have ht : ∀ᵐ x ∂μ, ν.rnDeriv μ x ≠ ⊤ := Measure.rnDeriv_ne_top ν μ
  have he : (fun x => (J x : ℝ≥0∞)) =ᵐ[μ] ν.rnDeriv μ := by
    filter_upwards [ht] with x hx
    exact ENNReal.coe_toNNReal hx
  refine ⟨J, hJ, ?_, ?_⟩
  · filter_upwards [constant_le_rnDeriv μ ν c hν hc, rnDeriv_le_constant μ ν C hC, he]
      with x h1 h2 h3
    constructor
    · exact_mod_cast h1.trans_eq h3.symm
    · exact_mod_cast h3.trans_le h2
  · rw [withDensity_congr_ae he, Measure.withDensity_rnDeriv_eq ν μ hν]

end N2Restriction
