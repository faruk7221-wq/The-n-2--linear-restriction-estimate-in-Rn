import Mathlib.Analysis.InnerProductSpace.GramMatrix
import Mathlib.Topology.Instances.Matrix
import Mathlib.Topology.Order.Compact

/-! A compact-family version of the elementary fact that independent vectors
have positive Gram determinant. This is the abstract uniform wedge bound used
when the vectors depend continuously on geometric parameters. -/

namespace N2Restriction

/-- A continuous compact family of linearly independent vectors has a Gram
determinant bounded below by one positive constant. The determinant is the
square of the corresponding Euclidean wedge volume. -/
theorem compact_uniform_gram_det_lower_bound
    {P E ι : Type*} [TopologicalSpace P] [NormedAddCommGroup E]
    [InnerProductSpace ℝ E] [Fintype ι] [DecidableEq ι]
    {K : Set P} (hK : IsCompact K)
    (v : P → ι → E) (hv : Continuous v)
    (hli : ∀ p ∈ K, LinearIndependent ℝ (v p)) :
    ∃ c : ℝ, 0 < c ∧ ∀ p ∈ K,
      c ≤ Matrix.det (Matrix.gram ℝ (v p)) := by
  let G : P → Matrix ι ι ℝ := fun p => Matrix.gram ℝ (v p)
  have hG : Continuous G := by
    refine continuous_pi fun i => continuous_pi fun j => ?_
    exact ((continuous_apply i).comp hv).inner ((continuous_apply j).comp hv)
  have hdet : Continuous fun p => (G p).det := hG.matrix_det
  have hpos : ∀ p ∈ K, 0 < (G p).det := by
    intro p hp
    exact Matrix.PosDef.det_pos
      ((Matrix.posDef_gram_iff_linearIndependent).2 (hli p hp))
  exact hK.exists_forall_le' hdet.continuousOn (a := 0) hpos

end N2Restriction
