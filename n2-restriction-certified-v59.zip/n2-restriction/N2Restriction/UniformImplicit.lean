import N2Restriction.SmoothImplicit

namespace N2Restriction
open Filter Metric

/-- A smooth map with an invertible derivative has one open neighborhood on
which its local inverse is smooth to every finite order. The neighborhood is
chosen once, independently of the derivative order. -/
theorem smooth_inverse_neighborhood {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    (e : OpenPartialHomeomorph E F) {U : Set E} (hU : IsOpen U)
    (hf : ContDiffOn ℝ (⊤ : ℕ∞) (e : E → F) U)
    {x : E} (hx : x ∈ e.source) (hxU : x ∈ U)
    (A : E ≃L[ℝ] F) (hA : HasFDerivAt e (A : E →L[ℝ] F) x) :
    ∃ V : Set F, IsOpen V ∧ e x ∈ V ∧ V ⊆ e.target ∧
      Set.MapsTo e.symm V U ∧ ContDiffOn ℝ (⊤ : ℕ∞) (e.symm : F → E) V := by
  have hdf := hf.continuousOn_fderiv_of_isOpen hU (by norm_cast)
  have hnear : {y : E | ∃ B : E ≃L[ℝ] F,
      (B : E →L[ℝ] F) = fderiv ℝ e y} ∈ nhds x := by
    have hc := (hdf x hxU).continuousAt (hU.mem_nhds hxU)
    have hAn := A.nhds
    rw [← hA.fderiv] at hAn
    exact hc.preimage_mem_nhds hAn
  obtain ⟨W, hWsub, hWopen, hxW⟩ := _root_.mem_nhds_iff.mp
    (inter_mem (hU.mem_nhds hxU) hnear)
  let V := e.target ∩ e.symm ⁻¹' W
  refine ⟨V, e.isOpen_inter_preimage_symm hWopen,
    ⟨e.map_source hx, by simpa [e.left_inv hx] using hxW⟩,
    fun _ hy => hy.1, fun y hy => (hWsub hy.2).1, ?_⟩
  intro y hy
  obtain ⟨B, hB⟩ := (hWsub hy.2).2
  have hs := hf.contDiffAt (hU.mem_nhds (hWsub hy.2).1)
  have hd : HasFDerivAt e (B : E →L[ℝ] F) (e.symm y) := by
    rw [hB]
    exact (hs.differentiableAt (by simp)).hasFDerivAt
  exact (e.contDiffAt_symm hy.1 hd hs).contDiffWithinAt

/-- All derivative orders are bounded on one compact subset of an open smooth
domain. Each order has its own bound; the domain does not shrink with order. -/
theorem smooth_compact_all_derivative_bounds {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    {f : E → F} {U K : Set E} (hU : IsOpen U)
    (hf : ContDiffOn ℝ (⊤ : ℕ∞) f U) (hK : IsCompact K) (hKU : K ⊆ U) :
    ∃ B : ℕ → ℝ, (∀ m, 0 ≤ B m) ∧
      ∀ m y, y ∈ K → ‖iteratedFDeriv ℝ m f y‖ ≤ B m := by
  have hb : ∀ m : ℕ, ∃ C : ℝ, 0 ≤ C ∧
      ∀ y ∈ K, ‖iteratedFDeriv ℝ m f y‖ ≤ C := by
    intro m
    have hw := hf.continuousOn_iteratedFDerivWithin
      (show (m : WithTop ℕ∞) ≤ (⊤ : ℕ∞) by
        exact_mod_cast (le_top : (m : ℕ∞) ≤ ⊤)) hU.uniqueDiffOn
    have hc : ContinuousOn (iteratedFDeriv ℝ m f) K :=
      (hw.mono hKU).congr fun y hy =>
        (iteratedFDerivWithin_of_isOpen m hU (hKU hy)).symm
    obtain ⟨C, hC⟩ := hK.exists_bound_of_continuousOn hc
    exact ⟨max C 0, le_max_right _ _, fun y hy =>
      (hC y hy).trans (le_max_left _ _)⟩
  choose B hB hb using hb
  exact ⟨B, hB, hb⟩

/-- A submersion chart with a specified source radius, target radius, and
all-order inverse derivative bounds. The free space has the expected dimension.
The chart's first coordinate is the actual constraint, everywhere. -/
def ControlledSubmersionChart {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    (f : E → F) (U : Set E) (x : E) (r : ℝ) (B : ℕ → ℝ) : Prop :=
  ∃ K : Submodule ℝ E, ∃ e : OpenPartialHomeomorph E (F × K),
    Module.finrank ℝ K + Module.finrank ℝ F = Module.finrank ℝ E ∧
    (∃ z ∈ U, K = LinearMap.ker (fderiv ℝ f z).toLinearMap) ∧
    x ∈ e.source ∧ ball x r ⊆ e.source ∧
    (∀ y, (e y).1 = f y) ∧ ContDiffOn ℝ (⊤ : ℕ∞) (e : E → F × K) U ∧
    closedBall (e x) r ⊆ e.target ∧
    Set.MapsTo e.symm (closedBall (e x) r) U ∧
    (∀ y ∈ closedBall (e x) r, ContDiffAt ℝ (⊤ : ℕ∞) (e.symm : F × K → E) y) ∧
    (∀ m y, y ∈ closedBall (e x) r → ‖iteratedFDeriv ℝ m (e.symm : F × K → E) y‖ ≤ B m) ∧
    (∀ m y, y ∈ closedBall (e x) r →
      ‖iteratedFDeriv ℝ m (e : E → F × K) (e.symm y)‖ ≤ B m)

/-- A chart remains controlled after reducing its radius and increasing its bounds. -/
theorem ControlledSubmersionChart.mono {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    {f : E → F} {U : Set E} {x : E} {r s : ℝ} {B C : ℕ → ℝ}
    (h : ControlledSubmersionChart f U x r B) (hs : s ≤ r) (hBC : ∀ m, B m ≤ C m) :
    ControlledSubmersionChart f U x s C := by
  obtain ⟨K, e, hd, hker, hx, hb, he, hf, ht, hU, hc, hB, hF⟩ := h
  have hsub := closedBall_subset_closedBall (x := e x) hs
  exact ⟨K, e, hd, hker, hx, (ball_subset_ball hs).trans hb, he, hf,
    hsub.trans ht, fun y hy => hU (hsub hy), fun y hy => hc y (hsub hy),
    fun m y hy => (hB m y (hsub hy)).trans (hBC m),
    fun m y hy => (hF m y (hsub hy)).trans (hBC m)⟩

/-- Near a regular point, one implicit chart, one positive radius, and one
sequence of derivative bounds work at every nearby base point. -/
theorem local_controlled_submersion_charts {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    {f : E → F} {U : Set E} (hU : IsOpen U)
    (hf : ContDiffOn ℝ (⊤ : ℕ∞) f U) {z : E} (hz : z ∈ U)
    (hreg : Function.Surjective (fderiv ℝ f z)) :
    ∃ r : ℝ, 0 < r ∧ ∃ B : ℕ → ℝ, (∀ m, 0 ≤ B m) ∧
      ∀ᶠ x in nhds z, ControlledSubmersionChart f U x r B := by
  letI := FiniteDimensional.complete ℝ E
  letI := FiniteDimensional.complete ℝ F
  let L := fderiv ℝ f z
  have hs := (hf.contDiffAt (hU.mem_nhds hz)).hasStrictFDerivAt (by simp)
  have hr : LinearMap.range L.toLinearMap = ⊤ := LinearMap.range_eq_top.mpr hreg
  let hc := L.ker_closedComplemented_of_finiteDimensional_range
  let d := hs.implicitFunctionDataOfComplemented f L hr hc
  let e := d.toOpenPartialHomeomorph
  have hez : z ∈ e.source := d.pt_mem_toOpenPartialHomeomorph_source
  have he : ∀ y, (e y).1 = f y := fun _ => rfl
  have hright : ContDiff ℝ (⊤ : ℕ∞) d.rightFun :=
    (Classical.choose hc).contDiff.comp (contDiff_id.sub contDiff_const)
  have hprod : ContDiffOn ℝ (⊤ : ℕ∞) (e : E → F × LinearMap.ker L.toLinearMap) U :=
    hf.prodMk hright.contDiffOn
  let A := d.leftDeriv.equivProdOfSurjectiveOfIsCompl d.rightDeriv
    d.left_range d.right_range d.isCompl_ker
  obtain ⟨V, hV, heV, hVt, hVU, hVs⟩ := smooth_inverse_neighborhood e hU hprod
    hez hz A d.hasStrictFDerivAt.hasFDerivAt
  obtain ⟨δ, hδ, hδV⟩ := Metric.mem_nhds_iff.mp (hV.mem_nhds heV)
  have hhalf : closedBall (e z) (δ / 2) ⊆ V :=
    (closedBall_subset_ball (by linarith : δ / 2 < δ)).trans hδV
  obtain ⟨B, hB, hbound⟩ := smooth_compact_all_derivative_bounds hV hVs
    (isCompact_closedBall (e z) (δ / 2)) hhalf
  have himage : IsCompact (e.symm '' closedBall (e z) (δ / 2)) :=
    (isCompact_closedBall (e z) (δ / 2)).image_of_continuousOn
      (e.symm.continuousOn.mono (hhalf.trans hVt))
  have himageU : e.symm '' closedBall (e z) (δ / 2) ⊆ U := by
    rintro y ⟨v, hv, rfl⟩
    exact hVU (hhalf hv)
  obtain ⟨D, hD, hforward⟩ := smooth_compact_all_derivative_bounds hU hprod himage himageU
  obtain ⟨a, ha, has⟩ := Metric.mem_nhds_iff.mp (e.open_source.mem_nhds hez)
  let r := min (a / 2) (δ / 4)
  have hrpos : 0 < r := lt_min (by positivity) (by positivity)
  have hxnear := (e.continuousAt hez).preimage_mem_nhds (ball_mem_nhds (e z) (by positivity : 0 < δ / 4))
  refine ⟨r, hrpos, (fun m => max (B m) (D m)),
    (fun m => (hB m).trans (le_max_left _ _)), ?_⟩
  filter_upwards [ball_mem_nhds z (by positivity : 0 < a / 2), hxnear] with x hx hxe
  have hxs : x ∈ e.source := has (ball_subset_ball (by linarith : a / 2 ≤ a) hx)
  have hbs : ball x r ⊆ e.source := by
    apply Set.Subset.trans _ has
    apply ball_subset_ball'
    have hx' : dist x z < a / 2 := hx
    have hr' : r ≤ a / 2 := min_le_left _ _
    linarith
  have hbt : closedBall (e x) r ⊆ closedBall (e z) (δ / 2) := by
    apply closedBall_subset_closedBall'
    have hx' : dist (e x) (e z) < δ / 4 := hxe
    have hr' : r ≤ δ / 4 := min_le_right _ _
    linarith
  have hdim := L.toLinearMap.finrank_range_add_finrank_ker
  rw [hr, finrank_top] at hdim
  refine ⟨LinearMap.ker L.toLinearMap, e, by omega, ⟨z, hz, rfl⟩, hxs, hbs, he, hprod,
    hbt.trans (hhalf.trans hVt), fun y hy => hVU (hhalf (hbt hy)), ?_, ?_, ?_⟩
  · exact fun y hy => hVs.contDiffAt (hV.mem_nhds (hhalf (hbt hy)))
  · exact fun m y hy => (hbound m y (hbt hy)).trans (le_max_left _ _)
  · exact fun m y hy => (hforward m (e.symm y) ⟨y, hbt hy, rfl⟩).trans (le_max_right _ _)

/-- Compact regular submersion families have common chart radii and all-order
inverse derivative bounds. The radius is independent of derivative order. -/
theorem compact_controlled_submersion_charts {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    {f : E → F} {U K : Set E} (hU : IsOpen U)
    (hf : ContDiffOn ℝ (⊤ : ℕ∞) f U) (hK : IsCompact K) (hKU : K ⊆ U)
    (hreg : ∀ z ∈ K, Function.Surjective (fderiv ℝ f z)) :
    ∃ r : ℝ, 0 < r ∧ ∃ B : ℕ → ℝ, (∀ m, 0 ≤ B m) ∧
      ∀ x ∈ K, ControlledSubmersionChart f U x r B := by
  let P : Set E → Prop := fun T => ∃ r : ℝ, 0 < r ∧ ∃ B : ℕ → ℝ,
    (∀ m, 0 ≤ B m) ∧ ∀ x ∈ T, ControlledSubmersionChart f U x r B
  change P K
  refine IsCompact.induction_on hK (p := P) ?_ ?_ ?_ ?_
  · exact ⟨1, by norm_num, fun _ => 0, fun _ => le_rfl, by simp⟩
  · rintro s t hst ⟨r, hr, B, hB, hb⟩
    exact ⟨r, hr, B, hB, fun x hx => hb x (hst hx)⟩
  · rintro s t ⟨r, hr, B, hB, hb⟩ ⟨r', hr', B', hB', hb'⟩
    refine ⟨min r r', lt_min hr hr', fun m => max (B m) (B' m),
      fun m => (hB m).trans (le_max_left _ _), fun x hx => ?_⟩
    rcases hx with hx | hx
    · exact (hb x hx).mono (min_le_left _ _) (fun _ => le_max_left _ _)
    · exact (hb' x hx).mono (min_le_right _ _) (fun _ => le_max_right _ _)
  · intro z hz
    obtain ⟨r, hr, B, hB, hb⟩ := local_controlled_submersion_charts hU hf (hKU hz) (hreg z hz)
    exact ⟨{x | ControlledSubmersionChart f U x r B}, mem_nhdsWithin_of_mem_nhds hb,
      r, hr, B, hB, fun _ hx => hx⟩

/-- The local version of the higher chain rule for a linear change of input.
Only smoothness near the point is needed. -/
theorem iteratedFDeriv_comp_linear_at {E F G : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    [NormedAddCommGroup G] [NormedSpace ℝ G]
    (g : G →L[ℝ] E) {f : E → F} {x : G} (m : ℕ)
    (hf : ContDiffAt ℝ (⊤ : ℕ∞) f (g x)) :
    iteratedFDeriv ℝ m (f ∘ g) x =
      (iteratedFDeriv ℝ m f (g x)).compContinuousLinearMap (fun _ => g) := by
  obtain ⟨U, hU, hx, hfU⟩ := (hf.contDiffWithinAt (s := Set.univ)).contDiffOn'
    (show (m : WithTop ℕ∞) ≤ (⊤ : ℕ∞) by
      exact_mod_cast (le_top : (m : ℕ∞) ≤ ⊤)) (by simp)
  have hfs : ContDiffOn ℝ m f U := by simpa using hfU
  have hpre : IsOpen (g ⁻¹' U) := hU.preimage g.continuous
  have he := g.iteratedFDerivWithin_comp_right hfs hU.uniqueDiffOn hpre.uniqueDiffOn hx le_rfl
  rw [iteratedFDerivWithin_of_isOpen m hpre hx,
    iteratedFDerivWithin_of_isOpen m hU hx] at he
  exact he

/-- Restricting a smooth map to an affine slice whose linear part has norm at
most one does not increase any derivative norm. -/
theorem norm_iteratedFDeriv_affine_slice {E F G : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    [NormedAddCommGroup G] [NormedSpace ℝ G]
    (g : G →L[ℝ] E) (hg : ‖g‖ ≤ 1) (a : E) {f : E → F} {x : G} (m : ℕ)
    (hf : ContDiffAt ℝ (⊤ : ℕ∞) f (a + g x)) :
    ‖iteratedFDeriv ℝ m (fun t => f (a + g t)) x‖ ≤
      ‖iteratedFDeriv ℝ m f (a + g x)‖ := by
  have hs : ContDiffAt ℝ (⊤ : ℕ∞) (fun y => f (a + y)) (g x) :=
    hf.comp _ (contDiffAt_const.add contDiffAt_id)
  have he := iteratedFDeriv_comp_linear_at g m hs
  change iteratedFDeriv ℝ m (fun t => f (a + g t)) x = _ at he
  rw [he, iteratedFDeriv_comp_add_left]
  calc
    _ ≤ ‖iteratedFDeriv ℝ m f (a + g x)‖ * ∏ _ : Fin m, ‖g‖ :=
      ContinuousMultilinearMap.norm_compContinuousLinearMap_le _ _
    _ ≤ ‖iteratedFDeriv ℝ m f (a + g x)‖ * 1 := by
      apply mul_le_mul_of_nonneg_left _ (norm_nonneg _)
      simpa using pow_le_pow_left₀ (norm_nonneg g) hg m
    _ = _ := mul_one _

/-- Projecting the output by a contraction also preserves the derivative bound. -/
theorem norm_iteratedFDeriv_contraction_comp {E F G : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    [NormedAddCommGroup G] [NormedSpace ℝ G]
    (g : F →L[ℝ] G) (hg : ‖g‖ ≤ 1) {f : E → F} {x : E} (m : ℕ)
    (hf : ContDiffAt ℝ (⊤ : ℕ∞) f x) :
    ‖iteratedFDeriv ℝ m (g ∘ f) x‖ ≤ ‖iteratedFDeriv ℝ m f x‖ := by
  rw [g.iteratedFDeriv_comp_left hf (show (m : WithTop ℕ∞) ≤ (⊤ : ℕ∞) by
    exact_mod_cast (le_top : (m : ℕ∞) ≤ ⊤))]
  exact (g.norm_compContinuousMultilinearMap_le _).trans
    (by simpa using mul_le_mul_of_nonneg_right hg (norm_nonneg (iteratedFDeriv ℝ m f x)))

end N2Restriction
