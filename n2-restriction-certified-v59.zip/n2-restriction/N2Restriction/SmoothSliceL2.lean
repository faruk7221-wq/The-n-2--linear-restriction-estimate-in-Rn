import N2Restriction.GraphSlicePlancherel
import N2Restriction.CapEnergy
import N2Restriction.ExtensionRegularity

namespace N2Restriction
open MeasureTheory
open scoped FourierTransform ENNReal

/-- The smooth-input Plancherel identity is an identity of finite energy integrals. -/
theorem smooth_compact_flat_energy_integrable {d : ℕ} {f : Ambient d → ℂ}
    (hc : ContDiff ℝ (⊤ : ℕ∞) f) (hs : HasCompactSupport f) :
    Integrable (fun y => ‖extension volume id f y‖ ^ 2) := by
  let F := hs.toSchwartzMap hc
  have hF := (SchwartzMap.fourierTransformCLM ℂ F).memLp 2
  have hi := (memLp_two_iff_integrable_sq_norm hF.aestronglyMeasurable).mp hF
  have hi' : Integrable (fun y => ‖Real.fourierIntegral f y‖ ^ 2) := hi
  have hn := hi'.comp_smul (by norm_num : (-1 : ℝ) ≠ 0)
  have hscl := hn.comp_smul (by positivity : (2 * Real.pi)⁻¹ ≠ 0)
  simpa only [neg_one_smul, flat_extension_eq_inverse_fourier,
    Real.fourierIntegralInv_eq_fourierIntegral_neg] using hscl

/-- A smooth compact graph input has an L2 extension on each horizontal slice. -/
theorem smooth_graph_slice_memLp {d : ℕ} {φ : Ambient d → ℝ}
    (hφ : ContDiff ℝ (⊤ : ℕ∞) φ) {f : Ambient d → ℂ}
    (hf : ContDiff ℝ (⊤ : ℕ∞) f) (hs : HasCompactSupport f) (t : ℝ) :
    MemLp (fun u => extension volume (fun x => graphPoint x (φ x)) f (graphPoint u t)) 2 := by
  let g : Ambient d → ℂ := fun x => Complex.exp (((t * φ x : ℝ) : ℂ) * Complex.I) * f x
  have hg : ContDiff ℝ (⊤ : ℕ∞) g := by
    have hreal : ContDiff ℝ (⊤ : ℕ∞) (fun x => ((t * φ x : ℝ) : ℂ)) :=
      Complex.ofRealCLM.contDiff.comp (contDiff_const.mul hφ)
    dsimp [g]
    fun_prop
  have hgs : HasCompactSupport g := hs.mul_left
  have hc : Continuous (extension volume id g) :=
    continuous_extension measurable_id (hg.continuous.integrable_of_hasCompactSupport hgs)
  simp_rw [graph_extension_slice]
  exact (memLp_two_iff_integrable_sq_norm hc.aestronglyMeasurable).mpr
    (smooth_compact_flat_energy_integrable hg hgs)

/-- The slice seminorm formula is expressed in ENNReal for use with Fatou's lemma. -/
theorem smooth_graph_slice_eLpNorm {d : ℕ} {φ : Ambient d → ℝ}
    (hφ : ContDiff ℝ (⊤ : ℕ∞) φ) {f : Ambient d → ℂ}
    (hf : ContDiff ℝ (⊤ : ℕ∞) f) (hs : HasCompactSupport f) (t : ℝ) :
    eLpNorm (fun u => extension volume (fun x => graphPoint x (φ x)) f (graphPoint u t)) 2 =
      ENNReal.ofReal (((2 * Real.pi) ^ d * ∫ x, ‖f x‖ ^ 2) ^ (1 / 2 : ℝ)) := by
  rw [(smooth_graph_slice_memLp hφ hf hs t).eLpNorm_eq_integral_rpow_norm (by norm_num) (by norm_num)]
  norm_num only [ENNReal.toReal_ofNat, Real.rpow_two, invOf_eq_inv]
  rw [smooth_graph_slice_plancherel hφ hf hs]

end N2Restriction
