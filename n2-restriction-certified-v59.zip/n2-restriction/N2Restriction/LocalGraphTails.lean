import N2Restriction.LocalGraphPackets
import N2Restriction.SmoothGraphTails

namespace N2Restriction

/-- Absolute convergence and selected tails for a locally smooth graph, with
one common cap-radius threshold valid for every decay order. -/
theorem local_smooth_graph_selected_packet_tail {d : ℕ} {U : Set (Ambient d)} (hU : IsOpen U)
    {φ : Ambient d → ℝ} (hφ : ContDiffOn ℝ (⊤ : ℕ∞) φ U)
    (z : Ambient d) {a b : ℝ} (ha : 0 < a) (hab : a < b)
    (hball : Metric.closedBall z b ⊆ U) {Q : Set (Ambient d)} (hQ : IsCompact Q)
    (hcenter : Q ⊆ Metric.ball z (a / 2))
    {χ : Ambient d → ℂ} (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hs : HasCompactSupport χ) :
    ∃ r₀ : ℝ, 0 < r₀ ∧ ∀ M : ℕ, ∃ C : ℝ, 0 ≤ C ∧
      ∀ {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E],
      ∀ (b : HilbertBasis (Fin d → ℤ) ℂ E) (x : E) (c : Ambient d), c ∈ Q →
      ∀ (u : Ambient d) (r : ℝ), 0 < r → r ≤ r₀ →
      ∀ (t L : ℝ), |t * r ^ 2| ≤ 1 → 0 ≤ L →
      ∀ S : Set (Fin d → ℤ),
      (∀ ν ∈ S, L ≤ ‖latticeVector ν - (-(r • (u + t • graphGradient φ c)))‖) →
      Summable (fun ν : S => b.repr x ν * graphPacket φ χ c r (r⁻¹ • latticeVector ν) u t) ∧
      (∑' ν : S, ‖b.repr x ν * graphPacket φ χ c r (r⁻¹ • latticeVector ν) u t‖) ≤
        r ^ ((d : ℝ) / 2) * (C / (1 + L) ^ M) * ‖x‖ := by
  obtain ⟨r₀, hr₀, hdecay⟩ := local_smooth_graph_packet_decay hU hφ z ha hab hball hQ hcenter hχ hs
  refine ⟨r₀, hr₀, fun M => ?_⟩
  obtain ⟨C, hC, hb⟩ := hdecay (d + M)
  refine ⟨C * (2 ^ d * ‖latticeWeight d‖), by positivity, ?_⟩
  intro E _ _ b x c hc u r hr hr1 t L ht hL S hS
  let a : Ambient d := -(r • (u + t • graphGradient φ c))
  let packet : (Fin d → ℤ) → ℂ := fun ν => b.repr x ν *
    graphPacket φ χ c r (r⁻¹ • latticeVector ν) u t
  have hC' : 0 ≤ r ^ ((d : ℝ) / 2) * C := by positivity
  have hp (ν : Fin d → ℤ) : ‖packet ν‖ ≤
      (r ^ ((d : ℝ) / 2) * C) * ‖b.repr x ν‖ /
        (1 + ‖latticeVector ν - a‖) ^ (d + M) := by
    have hd := hb c hc r hr hr1 (r⁻¹ • latticeVector ν) u t ht
    have he : r * ‖u + r⁻¹ • latticeVector ν + t • graphGradient φ c‖ =
        ‖latticeVector ν - a‖ := by
      have hh := congrArg norm (rescaled_packet_axis u (graphGradient φ c) t hr.ne' ν)
      simpa only [norm_smul, Real.norm_eq_abs, abs_of_pos hr, a] using hh
    rw [he] at hd
    change ‖b.repr x ν * _‖ ≤ _
    rw [norm_mul]
    exact (mul_le_mul_of_nonneg_left hd (norm_nonneg _)).trans_eq (by ring)
  have hsum := (radial_packet_norm_summable b x a packet hC' M hp).subtype S
  refine ⟨hsum.of_norm, ?_⟩
  exact (radial_packet_absolute_tail b x a packet hC' hL M hp S hS).trans_eq (by ring)

/-- A positive cap-radius threshold becomes a fixed lower physical scale. -/
theorem exists_parabolic_radius_threshold {r₀ : ℝ} (hr₀ : 0 < r₀) :
    ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ R : ℝ, R₀ ≤ R → R ^ (-1 / 2 : ℝ) ≤ r₀ := by
  refine ⟨max 1 (r₀ ^ (-2 : ℝ)), le_max_left _ _, fun R hR => ?_⟩
  have h := Real.rpow_le_rpow_of_exponent_nonpos (Real.rpow_pos_of_pos hr₀ (-2 : ℝ))
    ((le_max_right _ _).trans hR) (by norm_num : (-1 / 2 : ℝ) ≤ 0)
  rw [← Real.rpow_mul hr₀.le] at h
  norm_num at h
  simpa only [neg_div] using h

/-- One common scale threshold gives every rapid-decay order for arbitrary
selected packets outside round finite tubes of a locally smooth graph. -/
theorem local_smooth_graph_rapid_tail {d : ℕ} {U : Set (Ambient d)} (hU : IsOpen U)
    {φ : Ambient d → ℝ} (hφ : ContDiffOn ℝ (⊤ : ℕ∞) φ U)
    (z : Ambient d) {a b₀ : ℝ} (ha : 0 < a) (hab : a < b₀)
    (hball : Metric.closedBall z b₀ ⊆ U) {Q : Set (Ambient d)} (hQ : IsCompact Q)
    (hcenter : Q ⊆ Metric.ball z (a / 2))
    {χ : Ambient d → ℂ} (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hs : HasCompactSupport χ)
    {τ : ℝ} (hτ : 0 < τ) :
    ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ b N : ℝ, ∃ C : ℝ, 0 ≤ C ∧ ∀ (R : ℝ), R₀ ≤ R →
      ∀ {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E],
      ∀ (e : HilbertBasis (Fin d → ℤ) ℂ E) (x : E) (c : Ambient d), c ∈ Q →
      ∀ (u : Ambient d) (t : ℝ), |t| ≤ R → ∀ S : Set (Fin d → ℤ),
      (∀ ν ∈ S, R ^ (1 / 2 + τ) / 10 ≤
        Metric.infDist (graphPoint u t) (packetSegment (graphGradient φ c)
          ((R ^ (-1 / 2 : ℝ))⁻¹ • latticeVector ν) R)) →
      R ^ b * (∑' ν : S, ‖e.repr x ν * graphPacket φ χ c
        (R ^ (-1 / 2 : ℝ)) ((R ^ (-1 / 2 : ℝ))⁻¹ • latticeVector ν) u t‖) ≤
        C * R ^ (-N) * ‖x‖ := by
  obtain ⟨r₀, hr₀, htailFamily⟩ :=
    local_smooth_graph_selected_packet_tail hU hφ z ha hab hball hQ hcenter hχ hs
  obtain ⟨R₀, hR₀, hsmall⟩ := exists_parabolic_radius_threshold hr₀
  refine ⟨R₀, hR₀, fun b N => ?_⟩
  obtain ⟨M, hM⟩ := exists_packet_tail_order hτ (b - d / 4) N
  obtain ⟨C, hC, hb⟩ := htailFamily M
  refine ⟨C * 10 ^ M, by positivity, ?_⟩
  intro R hRR E _ _ e x c hc u t ht S hS
  have hR : 1 ≤ R := hR₀.trans hRR
  have hRp : 0 < R := by linarith
  have hr := Real.rpow_pos_of_pos hRp (-1 / 2 : ℝ)
  have hr1 : R ^ (-1 / 2 : ℝ) ≤ r₀ := hsmall R hRR
  have htail := (hb e x c hc u (R ^ (-1 / 2 : ℝ)) hr hr1 t (R ^ τ / 10)
    (parabolic_time_parameter hRp ht) (by positivity) S
    (fun ν hν => physical_to_rescaled_tube_exclusion hRp u (graphGradient φ c) t ν
      ((hS ν hν).trans (packetSegment_dist_le_offset (graphGradient φ c) _ u ht)))).2
  have hscale : R ^ b * (R ^ (-1 / 2 : ℝ)) ^ ((d : ℝ) / 2) = R ^ (b - d / 4) := by
    rw [← Real.rpow_mul hRp.le, ← Real.rpow_add hRp]
    congr 1
    ring
  calc
    _ ≤ R ^ b * ((R ^ (-1 / 2 : ℝ)) ^ ((d : ℝ) / 2) *
        (C / (1 + R ^ τ / 10) ^ M) * ‖x‖) :=
      mul_le_mul_of_nonneg_left htail (Real.rpow_nonneg hRp.le _)
    _ = C * ‖x‖ * (R ^ (b - d / 4) / (1 + R ^ τ / 10) ^ M) := by
      rw [← hscale]
      ring
    _ ≤ C * ‖x‖ * (10 ^ M * R ^ (-N)) :=
      mul_le_mul_of_nonneg_left (hM R hR) (mul_nonneg hC (norm_nonneg _))
    _ = _ := by ring

/-- Finite-cap rapid decay for locally smooth graph packets outside round
finite tubes, with one scale threshold for all requested decay orders.
The polynomial cap count and input-energy budget remain explicit hypotheses. -/
theorem local_smooth_graph_finite_cap_rapid_tail {d : ℕ} {U : Set (Ambient d)} (hU : IsOpen U)
    {φ : Ambient d → ℝ} (hφ : ContDiffOn ℝ (⊤ : ℕ∞) φ U)
    (z : Ambient d) {α β : ℝ} (hα : 0 < α) (hαβ : α < β)
    (hball : Metric.closedBall z β ⊆ U) {Q : Set (Ambient d)} (hQ : IsCompact Q)
    (hcenter : Q ⊆ Metric.ball z (α / 2)) {χ : Ambient d → ℂ}
    (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hs : HasCompactSupport χ)
    {τ : ℝ} (hτ : 0 < τ) :
    ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ a N : ℝ, ∃ C : ℝ, 0 ≤ C ∧ ∀ (R : ℝ), R₀ ≤ R →
      ∀ {ι E : Type*} [Fintype ι] [NormedAddCommGroup E] [InnerProductSpace ℂ E],
      ∀ (b : HilbertBasis (Fin d → ℤ) ℂ E) (x : ι → E) (c : ι → Ambient d), (∀ j, c j ∈ Q) →
      ∀ (u : Ambient d) (t : ℝ), |t| ≤ R →
      ∀ (A B F : ℝ), 0 ≤ A → 0 ≤ B → 0 ≤ F →
      (Fintype.card ι : ℝ) ≤ A * R ^ a → (∑ j, ‖x j‖ ^ 2) ≤ B * F ^ 2 →
      ∀ S : ι → Set (Fin d → ℤ),
      (∀ j ν, ν ∈ S j → R ^ (1 / 2 + τ) / 10 ≤
        Metric.infDist (graphPoint u t) (packetSegment (graphGradient φ (c j))
          ((R ^ (-1 / 2 : ℝ))⁻¹ • latticeVector ν) R)) →
      (∑ j, ∑' ν : S j, ‖b.repr (x j) ν * graphPacket φ
        χ (c j) (R ^ (-1 / 2 : ℝ)) ((R ^ (-1 / 2 : ℝ))⁻¹ • latticeVector ν) u t‖) ≤
        C * Real.sqrt A * Real.sqrt B * R ^ (-N) * F := by
  obtain ⟨R₀, hR₀, hfamily⟩ := local_smooth_graph_rapid_tail hU hφ z hα hαβ hball hQ hcenter hχ hs hτ
  refine ⟨R₀, hR₀, fun a N => ?_⟩
  obtain ⟨C, hC, hb⟩ := hfamily 0 (N + a / 2)
  refine ⟨C, hC, ?_⟩
  intro R hRR ι E _ _ _ b x c hc u t ht A B F hA hB hF hcard henergy S hS
  have hR : 1 ≤ R := hR₀.trans hRR
  have hRp : 0 < R := by linarith
  have htail := finite_cap_absolute_tail x
    (fun j => ∑' ν : S j, ‖b.repr (x j) ν * graphPacket φ
      χ (c j) (R ^ (-1 / 2 : ℝ)) ((R ^ (-1 / 2 : ℝ))⁻¹ • latticeVector ν) u t‖)
    (δ := C * R ^ (-(N + a / 2))) (by positivity) (fun j => by
      simpa only [Real.rpow_zero, one_mul] using hb R hRR b (x j) (c j) (hc j) u t ht (S j) (hS j))
  have hpower : Real.sqrt (R ^ a) = R ^ (a / 2) := by
    rw [Real.sqrt_eq_rpow, ← Real.rpow_mul hRp.le]
    congr 1
    ring
  have hc := Real.sqrt_le_sqrt hcard
  rw [Real.sqrt_mul hA, hpower] at hc
  have he := Real.sqrt_le_sqrt henergy
  rw [Real.sqrt_mul hB, Real.sqrt_sq hF] at he
  have hcancel : R ^ (-(N + a / 2)) * R ^ (a / 2) = R ^ (-N) := by
    rw [← Real.rpow_add hRp]
    congr 1
    ring
  apply htail.trans
  calc
    _ ≤ (C * R ^ (-(N + a / 2))) * (Real.sqrt A * R ^ (a / 2)) *
        (Real.sqrt B * F) := by gcongr
    _ = (C * Real.sqrt A * Real.sqrt B * F) *
        (R ^ (-(N + a / 2)) * R ^ (a / 2)) := by ring
    _ = _ := by rw [hcancel]; ring

end N2Restriction
