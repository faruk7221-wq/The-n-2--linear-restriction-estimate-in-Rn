import N2Restriction.PartitionInputs

namespace N2Restriction
open MeasureTheory Set

/-- Actual packets of a single original Euclidean input, using the constructed cap pieces. -/
noncomputable def partitionPacket {d : ℕ} {ι : Type*} [Fintype ι] {K : Set (Ambient d)}
    (ρ : PartitionOfUnity ι (Ambient d) K) (c : ι → Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume : Measure (Ambient d))) (j : ι) (ν : Fin d → ℤ) :
    Lp ℂ 2 (volume : Measure (Ambient d)) :=
  actualPacketInput (c j) r hr (partitionCapInput ρ c r hr f j) ν

/-- Each cap packet expansion reconstructs its actual partition piece. -/
theorem partitionPacket_hasSum {d : ℕ} {ι : Type*} [Fintype ι] {K : Set (Ambient d)}
    (ρ : PartitionOfUnity ι (Ambient d) K) (c : ι → Ambient d) (r : ℝ) (hr : 0 < r)
    (hs : ∀ j, Function.support (ρ j) ⊆ Metric.ball (c j) r)
    (f : Lp ℂ 2 (volume : Measure (Ambient d))) (j : ι) :
    HasSum (partitionPacket ρ c r hr f j) (partitionL2Piece ρ f j) := by
  have h := actualPacketInput_reconstruction (c j) r hr (partitionCapInput ρ c r hr f j)
    (partitionCapInput_inner_support ρ c r hr hs f j)
  rwa [partitionCapInput_zeroExtension ρ c r hr hs] at h

/-- The finite-cap/infinite-mode decomposition reconstructs the original L2 input. -/
theorem partitionPacket_reconstruction {d : ℕ} {ι : Type*} [Fintype ι] {K : Set (Ambient d)}
    (ρ : PartitionOfUnity ι (Ambient d) K) (c : ι → Ambient d) (r : ℝ) (hr : 0 < r)
    (hs : ∀ j, Function.support (ρ j) ⊆ Metric.ball (c j) r)
    (f : Lp ℂ 2 (volume : Measure (Ambient d))) (hf : HasFrequencySupport volume id K f) :
    (∑ j, ∑' ν, partitionPacket ρ c r hr f j ν) = f := by
  simp_rw [(partitionPacket_hasSum ρ c r hr hs f _).tsum_eq]
  exact partitionL2Piece_reconstruction ρ f hf

/-- Original-energy accounting for all packets of the original input. -/
theorem partitionPacket_total_energy {d : ℕ} {ι : Type*} [Fintype ι] {K : Set (Ambient d)}
    (ρ : PartitionOfUnity ι (Ambient d) K) (c : ι → Ambient d) (r : ℝ) (hr : 0 < r)
    (hs : ∀ j, Function.support (ρ j) ⊆ Metric.ball (c j) r)
    (f : Lp ℂ 2 (volume : Measure (Ambient d))) :
    (∑ j, ∑' ν, ‖partitionPacket ρ c r hr f j ν‖ ^ 2) ≤
      packetCutoffEnergy d * (2 * Real.pi) ^ (-(d : ℝ)) * ‖f‖ ^ 2 := by
  have h := actual_finite_cap_packet_budget c r hr (partitionCapInput ρ c r hr f)
    (B := 1) (F := ‖f‖) (by simpa only [one_mul] using partitionCapInput_energy ρ c r hr hs f)
  simpa only [partitionPacket, mul_one] using h

/-- Arbitrary selected packets obey the cross-cap original-energy bound. -/
theorem partitionPacket_selected_energy {d : ℕ} {ι : Type*} [Fintype ι] {K : Set (Ambient d)}
    (ρ : PartitionOfUnity ι (Ambient d) K) (c : ι → Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume : Measure (Ambient d))) (S : ι → Set (Fin d → ℤ))
    {M : ℝ} (hM0 : 0 ≤ M)
    (hM : ∀ᵐ x ∂(volume : Measure (Ambient d)),
      (∑ j, (Metric.ball (c j) (2 * r)).indicator (fun _ => (1 : ℝ)) x) ≤ M) :
    packetCutoffEnergy d * ‖∑ j, ∑' ν : S j, partitionPacket ρ c r hr f j ν‖ ^ 2 ≤
      M * (2 * Real.pi) ^ d * ∑ j, ∑' ν : S j, ‖partitionPacket ρ c r hr f j ν‖ ^ 2 :=
  actual_cross_cap_almost_orthogonal c r hr (partitionCapInput ρ c r hr f) S hM0 hM

/-- Frequency localization of every packet in the constructed decomposition. -/
theorem partitionPacket_support {d : ℕ} {ι : Type*} [Fintype ι] {K : Set (Ambient d)}
    (ρ : PartitionOfUnity ι (Ambient d) K) (c : ι → Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume : Measure (Ambient d))) (j : ι) (ν : Fin d → ℤ) :
    HasFrequencySupport volume id (Metric.ball (c j) (2 * r)) (partitionPacket ρ c r hr f j ν) :=
  actualPacketInput_support (c j) r hr (partitionCapInput ρ c r hr f j) ν

end N2Restriction
