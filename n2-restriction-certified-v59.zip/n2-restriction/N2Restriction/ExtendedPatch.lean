import N2Restriction.Targets
import Mathlib.Topology.MetricSpace.Thickening

namespace N2Restriction

/-- Replace only the compact support, retaining the same defining function,
normal, and fixed extended surface. -/
def SmoothPatch.withSupport {n : ℕ} (S : SmoothPatch n)
    (K : Set (Ambient n)) (hK : IsCompact K) (hKS : K ⊆ S.extendedSurface) : SmoothPatch n :=
  { S with
    support := K
    compact_support := hK
    support_inside := fun _ hz => (hKS hz).1
    support_on_surface := fun _ hz => (hKS hz).2 }

theorem SmoothPatch.withSupport_extendedSurface {n : ℕ} (S : SmoothPatch n)
    (K : Set (Ambient n)) (hK : IsCompact K) (hKS : K ⊆ S.extendedSurface) :
    (S.withSupport K hK hKS).extendedSurface = S.extendedSurface := rfl

/-- The geometric hypotheses are unchanged when supports are replaced inside
the same extended surfaces. They are assumed on those whole extensions. -/
theorem geometricHypotheses_withSupport_iff {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2))
    (K : Fin k → Set (Ambient (k + 2))) (hK : ∀ i, IsCompact (K i))
    (hKS : ∀ i, K i ⊆ (S i).extendedSurface) (ν κ : ℝ) :
    GeometricHypotheses (fun i => (S i).withSupport (K i) (hK i) (hKS i)) ν κ ↔
      GeometricHypotheses S ν κ := Iff.rfl

/-- A compact smooth support has a positive surface buffer inside its fixed
extension. This provides actual larger compact supports for small corrections
and support-margin constructions. -/
theorem SmoothPatch.exists_compact_surface_buffer {n : ℕ} (S : SmoothPatch n) :
    ∃ δ : ℝ, 0 < δ ∧ ∃ K : Set (Ambient n), IsCompact K ∧
      S.support ⊆ K ∧ K ⊆ S.extendedSurface ∧
      ∀ x ∈ S.support, ∀ y ∈ S.extendedSurface, dist y x ≤ δ → y ∈ K := by
  obtain ⟨δ, hδ, hsub⟩ := S.compact_support.exists_cthickening_subset_open
    S.open_neighborhood S.support_inside
  let T := Metric.cthickening δ S.support
  have hT : IsCompact T := S.compact_support.cthickening
  let K := T ∩ S.defining ⁻¹' ({0} : Set ℝ)
  have hcont : ContinuousOn S.defining T := S.smooth_defining.continuousOn.mono hsub
  have hclosed : IsClosed K := hcont.preimage_isClosed_of_isClosed hT.isClosed isClosed_singleton
  have hK : IsCompact K := hT.of_isClosed_subset hclosed Set.inter_subset_left
  refine ⟨δ, hδ, K, hK, ?_, ?_, ?_⟩
  · intro x hx
    exact ⟨Metric.self_subset_cthickening S.support hx, S.support_on_surface x hx⟩
  · intro y hy
    exact ⟨hsub hy.1, hy.2⟩
  · intro x hx y hy hd
    exact ⟨Metric.mem_cthickening_of_dist_le y x δ S.support hx hd, hy.2⟩

/-- A finite collection of compact patches admits one buffer width, while
all defining functions, normals, and geometric assumptions stay fixed. -/
theorem uniform_compact_surface_buffers {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) :
    ∃ δ : ℝ, 0 < δ ∧ ∃ K : Fin k → Set (Ambient (k + 2)),
      (∀ i, IsCompact (K i)) ∧ (∀ i, (S i).support ⊆ K i) ∧
      (∀ i, K i ⊆ (S i).extendedSurface) ∧
      ∀ i, ∀ x ∈ (S i).support, ∀ y ∈ (S i).extendedSurface,
        dist y x ≤ δ → y ∈ K i := by
  classical
  by_cases hk : k = 0
  · subst k
    exact ⟨1, by norm_num, fun i => Fin.elim0 i, fun i => Fin.elim0 i,
      fun i => Fin.elim0 i, fun i => Fin.elim0 i, fun i => Fin.elim0 i⟩
  have hkpos : 0 < k := Nat.pos_of_ne_zero hk
  letI : Nonempty (Fin k) := ⟨⟨0, hkpos⟩⟩
  have hne : (Finset.univ : Finset (Fin k)).Nonempty := Finset.univ_nonempty
  choose δ hδ K hK hsub hin hbuffer using fun i => (S i).exists_compact_surface_buffer
  refine ⟨Finset.univ.inf' hne δ, (Finset.lt_inf'_iff _).2 (fun i _ => hδ i),
    K, hK, hsub, hin, fun i x hx y hy hd => ?_⟩
  exact hbuffer i x hx y hy (hd.trans (Finset.inf'_le _ (Finset.mem_univ i)))

/-- Larger compact patches with a common positive surface buffer can be
constructed without changing any of the geometric hypotheses. -/
theorem exists_buffered_geometric_family {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) {ν κ : ℝ}
    (hgeo : GeometricHypotheses S ν κ) :
    ∃ δ : ℝ, 0 < δ ∧ ∃ T : Fin k → SmoothPatch (k + 2),
      GeometricHypotheses T ν κ ∧
      (∀ i, (T i).extendedSurface = (S i).extendedSurface ∧
        (T i).defining = (S i).defining ∧ (T i).normal = (S i).normal ∧
        (T i).shape = (S i).shape ∧ (S i).support ⊆ (T i).support) ∧
      ∀ i, ∀ x ∈ (S i).support, ∀ y ∈ (S i).extendedSurface,
        dist y x ≤ δ → y ∈ (T i).support := by
  obtain ⟨δ, hδ, K, hK, hsub, hin, hbuffer⟩ := uniform_compact_surface_buffers S
  let T := fun i => (S i).withSupport (K i) (hK i) (hin i)
  refine ⟨δ, hδ, T, ?_, ?_, hbuffer⟩
  · exact (geometricHypotheses_withSupport_iff S K hK hin ν κ).mpr hgeo
  · exact fun i => ⟨rfl, rfl, rfl, rfl, hsub i⟩

end N2Restriction
