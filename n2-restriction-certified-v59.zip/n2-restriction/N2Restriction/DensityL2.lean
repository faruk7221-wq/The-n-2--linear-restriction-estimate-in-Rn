import N2Restriction.DensityTransfer
import N2Restriction.SupportMargins

namespace N2Restriction
open MeasureTheory
open scoped ENNReal NNReal

/-- Division by a positive density, as an actual map between L2 spaces. -/
noncomputable def divideDensityL2 {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (J : Ω → ℝ≥0) (hJ : Measurable J) {m : ℝ} (hm : 0 < m)
    (hmJ : ∀ᵐ x ∂μ, m ≤ (J x : ℝ)) (f : Lp ℂ 2 μ) :
    Lp ℂ 2 (μ.withDensity (fun x => (J x : ℝ≥0∞))) :=
  (memLp_div_density μ J hJ hm hmJ f (Lp.memLp f)).toLp (fun x => f x / (J x : ℂ))

theorem divideDensityL2_coe {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (J : Ω → ℝ≥0) (hJ : Measurable J) {m : ℝ} (hm : 0 < m)
    (hmJ : ∀ᵐ x ∂μ, m ≤ (J x : ℝ)) (f : Lp ℂ 2 μ) :
    divideDensityL2 μ J hJ hm hmJ f =ᵐ[μ.withDensity (fun x => (J x : ℝ≥0∞))]
      fun x => f x / (J x : ℂ) := MemLp.coeFn_toLp _

/-- The transferred energy is bounded by the reciprocal lower density bound. -/
theorem divideDensityL2_energy {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (J : Ω → ℝ≥0) (hJ : Measurable J) {m : ℝ} (hm : 0 < m)
    (hmJ : ∀ᵐ x ∂μ, m ≤ (J x : ℝ)) (f : Lp ℂ 2 μ) :
    ‖divideDensityL2 μ J hJ hm hmJ f‖ ^ 2 ≤ (1 / m) * ‖f‖ ^ 2 := by
  rw [complex_L2_norm_sq, complex_L2_norm_sq]
  have hz : ∀ᵐ x ∂μ, J x ≠ 0 := by
    filter_upwards [hmJ] with x hx
    exact_mod_cast (ne_of_gt (hm.trans_le hx))
  calc
    _ = ∫ x, ‖f x / (J x : ℂ)‖ ^ 2 ∂μ.withDensity (fun x => (J x : ℝ≥0∞)) := by
      apply integral_congr_ae
      filter_upwards [divideDensityL2_coe μ J hJ hm hmJ f] with x hx
      rw [hx]
    _ = ∫ x, ‖f x‖ ^ 2 / (J x : ℝ) ∂μ := integral_sq_div_density μ J hJ hz f
    _ ≤ _ := (integrable_div_density_energy μ J hJ hm hmJ f (Lp.memLp f)).2

theorem divideDensityL2_norm_le {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (J : Ω → ℝ≥0) (hJ : Measurable J) {m : ℝ} (hm : 0 < m)
    (hmJ : ∀ᵐ x ∂μ, m ≤ (J x : ℝ)) (f : Lp ℂ 2 μ) :
    ‖divideDensityL2 μ J hJ hm hmJ f‖ ≤ Real.sqrt (1 / m) * ‖f‖ := by
  have h := divideDensityL2_energy μ J hJ hm hmJ f
  have hs := Real.sq_sqrt (le_of_lt (one_div_pos.mpr hm))
  have hn := mul_nonneg (Real.sqrt_nonneg (1 / m)) (norm_nonneg f)
  nlinarith [sq_nonneg (‖divideDensityL2 μ J hJ hm hmJ f‖ - Real.sqrt (1 / m) * ‖f‖)]

/-- The inverse-density transfer is continuous and complex linear. -/
noncomputable def divideDensityOperator {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (J : Ω → ℝ≥0) (hJ : Measurable J) {m : ℝ} (hm : 0 < m)
    (hmJ : ∀ᵐ x ∂μ, m ≤ (J x : ℝ)) :
    Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 (μ.withDensity (fun x => (J x : ℝ≥0∞))) :=
  LinearMap.mkContinuous
    { toFun := divideDensityL2 μ J hJ hm hmJ
      map_add' := by
        intro f g
        apply Lp.ext
        filter_upwards [divideDensityL2_coe μ J hJ hm hmJ (f + g),
          divideDensityL2_coe μ J hJ hm hmJ f, divideDensityL2_coe μ J hJ hm hmJ g,
          (withDensity_absolutelyContinuous μ _).ae_le (Lp.coeFn_add f g),
          Lp.coeFn_add (divideDensityL2 μ J hJ hm hmJ f) (divideDensityL2 μ J hJ hm hmJ g)]
          with x h1 h2 h3 h4 h5
        simp only [h1, h2, h3, h4, h5, Pi.add_apply, add_div]
      map_smul' := by
        intro z f
        apply Lp.ext
        filter_upwards [divideDensityL2_coe μ J hJ hm hmJ (z • f),
          divideDensityL2_coe μ J hJ hm hmJ f,
          (withDensity_absolutelyContinuous μ _).ae_le (Lp.coeFn_smul z f),
          Lp.coeFn_smul z (divideDensityL2 μ J hJ hm hmJ f)] with x h1 h2 h3 h4
        simp only [RingHom.id_apply, h1, h2, h3, h4, Pi.smul_apply, smul_eq_mul, mul_div_assoc] }
    (Real.sqrt (1 / m)) (divideDensityL2_norm_le μ J hJ hm hmJ)

theorem divideDensityOperator_apply {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (J : Ω → ℝ≥0) (hJ : Measurable J) {m : ℝ} (hm : 0 < m)
    (hmJ : ∀ᵐ x ∂μ, m ≤ (J x : ℝ)) (f : Lp ℂ 2 μ) :
    divideDensityOperator μ J hJ hm hmJ f = divideDensityL2 μ J hJ hm hmJ f := rfl

/-- Changing measure and dividing by the density preserves the actual extension integral. -/
theorem extension_divideDensityL2 {Ω : Type*} [MeasurableSpace Ω] {n : ℕ} (μ : Measure Ω)
    (J : Ω → ℝ≥0) (hJ : Measurable J) {m : ℝ} (hm : 0 < m)
    (hmJ : ∀ᵐ x ∂μ, m ≤ (J x : ℝ)) (f : Lp ℂ 2 μ)
    (ζ : Ω → Ambient n) (y : Ambient n) :
    extension (μ.withDensity (fun x => (J x : ℝ≥0∞))) ζ
      (divideDensityL2 μ J hJ hm hmJ f) y = extension μ ζ f y := by
  have hz : ∀ᵐ x ∂μ, J x ≠ 0 := by
    filter_upwards [hmJ] with x hx
    exact_mod_cast (ne_of_gt (hm.trans_le hx))
  rw [← extension_div_density μ J hJ hz ζ f y]
  apply integral_congr_ae
  filter_upwards [divideDensityL2_coe μ J hJ hm hmJ f] with x hx
  rw [hx]

end N2Restriction
