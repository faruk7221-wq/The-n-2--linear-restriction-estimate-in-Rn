import N2Restriction.RegularGraphCover
import N2Restriction.AtlasInputs

namespace N2Restriction
open MeasureTheory Set Filter

/-- A constructed atlas of the original surface gives actual Hausdorff chart inputs,
with total energy control, original frequency support and exact extension recovery. -/
theorem SmoothPatch.graph_atlas_input_decomposition {d : ℕ} (S : SmoothPatch (d + 1)) :
    ∃ (m : ℕ) (P : Fin m → LocalGraphPatch d),
      (S.support ⊆ ⋃ j, (P j).carrier) ∧ (∀ j, (P j).carrier ⊆ S.extendedSurface) ∧
      ∀ g : Lp ℂ 2 S.surfaceMeasure,
        ∃ f : (j : Fin m) → Lp ℂ 2 ((Measure.hausdorffMeasure (d : ℝ)).restrict (P j).carrier),
          (∑ j, ‖f j‖ ^ 2) ≤ ‖g‖ ^ 2 ∧
          (∀ j, HasFrequencySupport ((Measure.hausdorffMeasure (d : ℝ)).restrict (P j).carrier)
            id S.support (f j)) ∧
          ∀ x : Ambient (d + 1),
            (∑ j, extension ((Measure.hausdorffMeasure (d : ℝ)).restrict (P j).carrier) id (f j) x) =
              extension S.surfaceMeasure id g x := by
  obtain ⟨m, P, hcover, hinside, _⟩ := S.exists_finite_graph_cover
  have hdim : ((d + 1 : ℕ) : ℝ) - 1 = (d : ℝ) := by push_cast; ring
  have hμ : S.surfaceMeasure = (Measure.hausdorffMeasure (d : ℝ)).restrict S.support := by
    rw [SmoothPatch.surfaceMeasure, hdim]
  haveI : IsFiniteMeasure S.surfaceMeasure := S.isFiniteMeasure_surfaceMeasure (by omega)
  refine ⟨m, P, hcover, hinside, ?_⟩
  rw [hμ] at *
  intro g
  let K := fun j => (P j).carrier
  have hK (j) : MeasurableSet (K j) := (P j).compact_carrier.measurableSet
  exact ⟨atlasPatchInput _ S.support S.compact_support.measurableSet K hK g,
    atlasPatchInput_energy _ S.support S.compact_support.measurableSet K hK g,
    atlasPatchInput_original_support _ S.support S.compact_support.measurableSet K hK g,
    atlasPatchInput_reconstruction _ S.support S.compact_support.measurableSet K hK hcover g⟩

end N2Restriction
