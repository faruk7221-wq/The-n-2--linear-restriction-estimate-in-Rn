import N2Restriction.NearbyPlanes

namespace N2Restriction
open Filter

/-- A local quantitative level-set correction supplied by the inverse function
theorem. The correction stays in any prescribed neighborhood of the base point.
The constant and neighborhood are local, not uniform in parameters. -/
theorem implicit_level_correction {E F G : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [CompleteSpace F]
    [NormedAddCommGroup G] [NormedSpace ℝ G] [CompleteSpace G]
    (d : ImplicitFunctionData ℝ E F G) {U : Set E} (hU : U ∈ nhds d.pt) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ x in nhds d.pt,
      ∃ y ∈ U, d.leftFun y = d.leftFun d.pt ∧
        dist x y ≤ C * dist (d.leftFun x) (d.leftFun d.pt) := by
  let A := d.leftDeriv.equivProdOfSurjectiveOfIsCompl d.rightDeriv
    d.left_range d.right_range d.isCompl_ker
  let inv := d.hasStrictFDerivAt.localInverse d.prodFun A d.pt
  have hinv := d.hasStrictFDerivAt.to_localInverse
  obtain ⟨K, V, hV, hLip⟩ := hinv.exists_lipschitzOnWith
  have hg : Tendsto d.prodFun (nhds d.pt) (nhds (d.prodFun d.pt)) :=
    d.hasStrictFDerivAt.continuousAt
  have hr : Tendsto (fun x => (d.leftFun d.pt, d.rightFun x))
      (nhds d.pt) (nhds (d.prodFun d.pt)) :=
    tendsto_const_nhds.prodMk_nhds d.right_has_deriv.continuousAt
  have hy : Tendsto (fun x => inv (d.leftFun d.pt, d.rightFun x))
      (nhds d.pt) (nhds d.pt) := d.hasStrictFDerivAt.localInverse_tendsto.comp hr
  refine ⟨K, K.property, ?_⟩
  filter_upwards [hg.eventually hV, hr.eventually hV,
    d.hasStrictFDerivAt.eventually_left_inverse,
    hr.eventually d.hasStrictFDerivAt.eventually_right_inverse, hy.eventually hU]
    with x hxV hrV hleft hright hyU
  refine ⟨inv (d.leftFun d.pt, d.rightFun x), hyU, ?_, ?_⟩
  · exact congrArg Prod.fst hright
  · have hdist := hLip.dist_le_mul _ hxV _ hrV
    change dist (inv (d.prodFun x)) (inv (d.leftFun d.pt, d.rightFun x)) ≤
      (K : ℝ) * dist (d.prodFun x) (d.leftFun d.pt, d.rightFun x) at hdist
    change inv (d.prodFun x) = x at hleft
    rw [hleft] at hdist
    simpa [ImplicitFunctionData.prodFun, Prod.dist_eq] using hdist

/-- A finite-dimensional submersion has the local distance-to-level-set bound,
with explicit existence of a point on the same level. -/
theorem submersion_level_correction {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    {f : E → F} {L : E →L[ℝ] F} {z : E}
    (hf : HasStrictFDerivAt f L z) (hL : Function.Surjective L)
    {U : Set E} (hU : U ∈ nhds z) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ x in nhds z,
      ∃ y ∈ U, f y = f z ∧ dist x y ≤ C * dist (f x) (f z) := by
  letI := FiniteDimensional.complete ℝ F
  exact implicit_level_correction
    (hf.implicitFunctionDataOfComplemented f L (LinearMap.range_eq_top.mpr hL)
      L.ker_closedComplemented_of_finiteDimensional_range) hU

/-- Local version of (4.1), on the actual hypersurface and for nearby planes.
The base point lies in the projected-normal zero set. Uniformity over all
frequency points and plane parameters is not asserted. -/
theorem nearby_thin_support_correction {n : ℕ} (S : SmoothPatch n)
    (W H : Submodule ℝ (Ambient n)) (hdim : Module.finrank ℝ W = Module.finrank ℝ H)
    {z : Ambient n} (hz : z ∈ S.extendedSurface)
    (hzero : H.orthogonalProjection (S.normal z) = 0)
    (hW : ∀ v : W, inner ℝ (S.normal z) (v : Ambient n) = 0)
    {κ : ℝ} (hκ : 0 < κ)
    (hA : ∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (S.shape z v)‖)
    (hgap : ‖W.starProjection - H.starProjection‖ * ‖S.shape z‖ ≤ κ / 2) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ x in nhds z, S.defining x = 0 →
      ∃ y ∈ S.extendedSurface, H.orthogonalProjection (S.normal y) = 0 ∧
        dist x y ≤ C * ‖H.orthogonalProjection (S.normal x)‖ := by
  have hds := S.smooth_defining.contDiffAt (S.open_neighborhood.mem_nhds hz.1)
  have hns := S.smooth_normal.contDiffAt (S.open_neighborhood.mem_nhds hz.1)
  have hs : ContDiffAt ℝ (⊤ : ℕ∞) (thinConstraint S H) z :=
    hds.prodMk (H.orthogonalProjection.contDiff.contDiffAt.comp z hns)
  have hd := hs.hasStrictFDerivAt' (hasFDerivAt_thinConstraint S H hz.1) (by simp)
  obtain ⟨C, hC, hc⟩ := submersion_level_correction hd
    (nearby_thinDifferential_surjective S W H hdim hz.1 hW hκ hA hgap)
    (S.open_neighborhood.mem_nhds hz.1)
  refine ⟨C, hC, ?_⟩
  filter_upwards [hc] with x hx
  intro hfx
  obtain ⟨y, hy, heq, hdist⟩ := hx
  have hfy : S.defining y = 0 := (congrArg Prod.fst heq).trans hz.2
  have hny : H.orthogonalProjection (S.normal y) = 0 := (congrArg Prod.snd heq).trans hzero
  refine ⟨y, ⟨hy, hfy⟩, hny, ?_⟩
  simpa [thinConstraint, Prod.dist_eq, hfx, hz.2, hzero] using hdist

end N2Restriction
