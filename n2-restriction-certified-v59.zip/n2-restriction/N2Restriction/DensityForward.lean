import N2Restriction.DensityL2

namespace N2Restriction
open MeasureTheory
open scoped ENNReal NNReal

/-- Multiplication by a bounded density sends weighted L2 inputs to coordinate L2. -/
theorem memLp_mul_density {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (J : Ω → ℝ≥0) (hJ : Measurable J) (hJ0 : ∀ᵐ x ∂μ, J x ≠ 0)
    {M : ℝ} (_hM : 0 ≤ M) (hJM : ∀ᵐ x ∂μ, (J x : ℝ) ≤ M)
    (g : Ω → ℂ) (hg : MemLp g 2 (μ.withDensity (fun x => (J x : ℝ≥0∞)))) :
    MemLp (fun x => (J x : ℂ) * g x) 2 μ := by
  have hac : μ ≪ μ.withDensity (fun x => (J x : ℝ≥0∞)) :=
    withDensity_absolutelyContinuous' hJ.coe_nnreal_ennreal.aemeasurable
      (hJ0.mono fun x hx => by exact_mod_cast hx)
  have hmeas : AEStronglyMeasurable (fun x => (J x : ℂ) * g x) μ :=
    (show Measurable (fun x => (J x : ℂ)) by fun_prop).aestronglyMeasurable.mul
      (hg.aestronglyMeasurable.mono_ac hac)
  apply (memLp_two_iff_integrable_sq_norm hmeas).mpr
  have hi := (integrable_withDensity_iff_integrable_smul hJ).mp
    ((memLp_two_iff_integrable_sq_norm hg.aestronglyMeasurable).mp hg)
  change Integrable (fun x => (J x : ℝ) * ‖g x‖ ^ 2) μ at hi
  apply (hi.const_mul M).mono' (hmeas.norm.pow 2)
  filter_upwards [hJM] with x hx
  change ‖‖(J x : ℂ) * g x‖ ^ 2‖ ≤ M * ((J x : ℝ) * ‖g x‖ ^ 2)
  rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg _), norm_mul]
  have hn : ‖(J x : ℂ)‖ = (J x : ℝ) := by simp
  rw [hn]
  nlinarith [mul_nonneg (J x).coe_nonneg (sq_nonneg ‖g x‖),
    mul_nonneg (sub_nonneg.mpr hx) (mul_nonneg (J x).coe_nonneg (sq_nonneg ‖g x‖))]

noncomputable def multiplyDensityL2 {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (J : Ω → ℝ≥0) (hJ : Measurable J) (hJ0 : ∀ᵐ x ∂μ, J x ≠ 0)
    {M : ℝ} (hM : 0 ≤ M) (hJM : ∀ᵐ x ∂μ, (J x : ℝ) ≤ M)
    (g : Lp ℂ 2 (μ.withDensity (fun x => (J x : ℝ≥0∞)))) : Lp ℂ 2 μ :=
  (memLp_mul_density μ J hJ hJ0 hM hJM g (Lp.memLp g)).toLp (fun x => (J x : ℂ) * g x)

theorem multiplyDensityL2_coe {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (J : Ω → ℝ≥0) (hJ : Measurable J) (hJ0 : ∀ᵐ x ∂μ, J x ≠ 0)
    {M : ℝ} (hM : 0 ≤ M) (hJM : ∀ᵐ x ∂μ, (J x : ℝ) ≤ M)
    (g : Lp ℂ 2 (μ.withDensity (fun x => (J x : ℝ≥0∞)))) :
    multiplyDensityL2 μ J hJ hJ0 hM hJM g =ᵐ[μ] fun x => (J x : ℂ) * g x :=
  MemLp.coeFn_toLp _

theorem multiplyDensityL2_energy {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (J : Ω → ℝ≥0) (hJ : Measurable J) (hJ0 : ∀ᵐ x ∂μ, J x ≠ 0)
    {M : ℝ} (hM : 0 ≤ M) (hJM : ∀ᵐ x ∂μ, (J x : ℝ) ≤ M)
    (g : Lp ℂ 2 (μ.withDensity (fun x => (J x : ℝ≥0∞)))) :
    ‖multiplyDensityL2 μ J hJ hJ0 hM hJM g‖ ^ 2 ≤ M * ‖g‖ ^ 2 := by
  rw [complex_L2_norm_sq, complex_L2_norm_sq, integral_withDensity_eq_integral_smul hJ,
    ← integral_const_mul]
  have hi := (integrable_withDensity_iff_integrable_smul hJ).mp
    ((memLp_two_iff_integrable_sq_norm (Lp.memLp g).aestronglyMeasurable).mp (Lp.memLp g))
  apply integral_mono_ae
    ((memLp_two_iff_integrable_sq_norm (Lp.memLp _).aestronglyMeasurable).mp (Lp.memLp _))
    (hi.const_mul M)
  filter_upwards [multiplyDensityL2_coe μ J hJ hJ0 hM hJM g, hJM] with x he hx
  rw [he, norm_mul]
  have hn : ‖(J x : ℂ)‖ = (J x : ℝ) := by simp
  rw [hn]
  change ((J x : ℝ) * ‖g x‖) ^ 2 ≤ M * ((J x : ℝ) * ‖g x‖ ^ 2)
  nlinarith [mul_nonneg (sub_nonneg.mpr hx) (mul_nonneg (J x).coe_nonneg (sq_nonneg ‖g x‖))]

/-- The two actual L2 transfers cancel, recovering the original weighted input. -/
theorem divide_multiply_density {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (J : Ω → ℝ≥0) (hJ : Measurable J) {m M : ℝ} (hm : 0 < m) (hM : 0 ≤ M)
    (hmJ : ∀ᵐ x ∂μ, m ≤ (J x : ℝ)) (hJM : ∀ᵐ x ∂μ, (J x : ℝ) ≤ M)
    (hJ0 : ∀ᵐ x ∂μ, J x ≠ 0)
    (g : Lp ℂ 2 (μ.withDensity (fun x => (J x : ℝ≥0∞)))) :
    divideDensityL2 μ J hJ hm hmJ (multiplyDensityL2 μ J hJ hJ0 hM hJM g) = g := by
  apply Lp.ext
  filter_upwards [divideDensityL2_coe μ J hJ hm hmJ _,
    (withDensity_absolutelyContinuous μ _).ae_le (multiplyDensityL2_coe μ J hJ hJ0 hM hJM g),
    (withDensity_absolutelyContinuous μ _).ae_le hJ0] with x h1 h2 h0
  rw [h1, h2]
  have hz : (J x : ℂ) ≠ 0 := by exact_mod_cast h0
  field_simp

end N2Restriction
