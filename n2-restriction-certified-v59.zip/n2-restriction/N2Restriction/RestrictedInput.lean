import N2Restriction.CrossCapPackets

namespace N2Restriction
open MeasureTheory Set

/-- Restrict an existing L2 input to a measurable cap domain. -/
noncomputable def restrictInputL2 {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (s : Set Ω) (f : Lp ℂ 2 μ) : Lp ℂ 2 (μ.restrict s) :=
  ((Lp.memLp f).restrict s).toLp f

theorem restrictInputL2_coe {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (s : Set Ω) (f : Lp ℂ 2 μ) : restrictInputL2 μ s f =ᵐ[μ.restrict s] f :=
  MemLp.coeFn_toLp _

/-- Restriction followed by zero extension recovers a supported input exactly. -/
theorem zeroExtend_restrictInput {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (s : Set Ω) (hs : MeasurableSet s) (f : Lp ℂ 2 μ)
    (hf : HasFrequencySupport μ id s f) :
    zeroExtendL2 μ s hs (restrictInputL2 μ s f) = f := by
  apply Lp.ext
  have he := (ae_restrict_iff' hs).mp (restrictInputL2_coe μ s f)
  filter_upwards [zeroExtendL2_coe μ s hs (restrictInputL2 μ s f), he, hf] with x hx he hf
  rw [hx]
  by_cases hxs : x ∈ s
  · rw [indicator_of_mem hxs, he hxs]
  · rw [indicator_of_notMem hxs]
    symm
    by_contra hn
    exact hxs (hf hn)

theorem restrictInputL2_norm_of_support {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (s : Set Ω) (hs : MeasurableSet s) (f : Lp ℂ 2 μ)
    (hf : HasFrequencySupport μ id s f) : ‖restrictInputL2 μ s f‖ = ‖f‖ := by
  rw [← zeroExtendL2_norm μ s hs, zeroExtend_restrictInput μ s hs f hf]

/-- Finite sums of L2 inputs agree almost everywhere with finite pointwise sums. -/
theorem L2_coe_finset_sum {Ω ι : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (f : ι → Lp ℂ 2 μ) (s : Finset ι) :
    (fun x => (∑ j ∈ s, f j : Lp ℂ 2 μ) x) =ᵐ[μ] fun x => ∑ j ∈ s, f j x := by
  classical
  induction s using Finset.induction_on with
  | empty => simpa using (Lp.coeFn_zero ℂ 2 μ)
  | @insert j s hj ih =>
    simp only [Finset.sum_insert hj]
    filter_upwards [Lp.coeFn_add (f j) (∑ k ∈ s, f k), ih] with x hx hi
    simpa only [Pi.add_apply, hi] using hx

end N2Restriction
