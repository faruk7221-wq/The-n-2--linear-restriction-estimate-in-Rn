import N2Restriction.AtlasInputs
import N2Restriction.FinitePacketIndexing
import N2Restriction.SupportedExtensionSynthesis

namespace N2Restriction
open MeasureTheory Set Filter

/-- Unconditional chart series combine into an unconditional series for the original surface input. -/
theorem atlasPatchInput_series_reconstruction {n m : ℕ} {ν : Type*} (μ : Measure (Ambient n))
    (S : Set (Ambient n)) (hS : MeasurableSet S)
    (K : Fin m → Set (Ambient n)) (hK : ∀ j, MeasurableSet (K j))
    (hcover : S ⊆ ⋃ j, K j) (g : Lp ℂ 2 (μ.restrict S))
    (f : (j : Fin m) → ν → Lp ℂ 2 (μ.restrict (K j)))
    (hf : ∀ j, HasSum (f j) (atlasPatchInput μ S hS K hK g j)) :
    HasSum (fun p : Fin m × ν => zeroExtendL2 μ (K p.1) (hK p.1) (f p.1 p.2))
      (zeroExtendL2 μ S hS g) := by
  have h := finite_fiber_hasSum
    (fun j v => zeroExtendL2 μ (K j) (hK j) (f j v))
    (fun j => zeroExtendL2 μ (K j) (hK j) (atlasPatchInput μ S hS K hK g j))
    (fun j => (zeroExtendIsometry μ (K j) (hK j)).toContinuousLinearMap.hasSum (hf j))
  rwa [atlasPatchInput_L2_reconstruction μ S hS K hK hcover g] at h

/-- The combined chart series reconstructs the original extension uniformly over physical space.
Only finite measure of the common chart union is needed, not finite ambient measure. -/
theorem atlasPatchInput_series_uniform_extension {n m : ℕ} {ν : Type*} (μ : Measure (Ambient n))
    (S : Set (Ambient n)) (hS : MeasurableSet S)
    (K : Fin m → Set (Ambient n)) (hK : ∀ j, MeasurableSet (K j))
    [IsFiniteMeasure (μ.restrict (⋃ j, K j))]
    (hcover : S ⊆ ⋃ j, K j) (g : Lp ℂ 2 (μ.restrict S))
    (f : (j : Fin m) → ν → Lp ℂ 2 (μ.restrict (K j)))
    (hf : ∀ j, HasSum (f j) (atlasPatchInput μ S hS K hK g j)) :
    ∀ ε : ℝ, 0 < ε → ∀ᶠ F : Finset (Fin m × ν) in Filter.atTop, ∀ x : Ambient n,
      dist (∑ p ∈ F, extension (μ.restrict (K p.1)) id (f p.1 p.2) x)
        (extension (μ.restrict S) id g x) < ε := by
  have hs (p : Fin m × ν) : HasFrequencySupport μ id (⋃ j, K j)
      (zeroExtendL2 μ (K p.1) (hK p.1) (f p.1 p.2)) := by
    filter_upwards [zeroExtendL2_vanishes μ (K p.1) (hK p.1) (f p.1 p.2)] with x hx hn
    have hmem : x ∈ K p.1 := by by_contra h; exact hn (hx h)
    exact mem_iUnion.mpr ⟨p.1, hmem⟩
  have hg : HasFrequencySupport μ id (⋃ j, K j) (zeroExtendL2 μ S hS g) := by
    filter_upwards [zeroExtendL2_vanishes μ S hS g] with x hx hn
    apply hcover
    by_contra h
    exact hn (hx h)
  have h := supported_extension_uniform μ (⋃ j, K j) (MeasurableSet.iUnion hK) id measurable_id
    _ _ hs hg (atlasPatchInput_series_reconstruction μ S hS K hK hcover g f hf)
  simpa only [zeroExtendL2_extension] using h

end N2Restriction
