import N2Restriction.NearbyNormalTransversality

namespace N2Restriction

/-- The actual shape operators have a uniform operator-norm bound on compact subsets. -/
theorem SmoothPatch.shape_bound_on_compact {n : ℕ} (S : SmoothPatch n)
    {K : Set (Ambient n)} (hK : IsCompact K) (hKS : K ⊆ S.neighborhood) :
    ∃ M : ℝ, 0 ≤ M ∧ ∀ z ∈ K, ‖S.shape z‖ ≤ M := by
  have hc : ContinuousOn S.shape S.neighborhood :=
    (S.smooth_normal.continuousOn_fderiv_of_isOpen S.open_neighborhood (by norm_cast)).neg
  obtain ⟨M, hM⟩ := hK.exists_bound_of_continuousOn (hc.mono hKS)
  exact ⟨max M 0, le_max_right _ _, fun z hz => (hM z hz).trans (le_max_left _ _)⟩

/-- Every fixed finite order derivative of the smooth unit normal is uniformly
bounded on a compact subset of the extension neighborhood. -/
theorem SmoothPatch.iterated_normal_derivative_bound_on_compact {n order : ℕ}
    (S : SmoothPatch n) {K : Set (Ambient n)} (hK : IsCompact K)
    (hKS : K ⊆ S.neighborhood) :
    ∃ M : ℝ, 0 ≤ M ∧ ∀ z ∈ K,
      ‖iteratedFDeriv ℝ order S.normal z‖ ≤ M := by
  have hwithin :
      ContinuousOn (iteratedFDerivWithin ℝ order S.normal S.neighborhood)
        S.neighborhood :=
    S.smooth_normal.continuousOn_iteratedFDerivWithin
      (show (order : WithTop ℕ∞) ≤ (⊤ : ℕ∞) by
        exact_mod_cast (le_top : (order : ℕ∞) ≤ (⊤ : ℕ∞)))
      S.open_neighborhood.uniqueDiffOn
  have hcont : ContinuousOn (iteratedFDeriv ℝ order S.normal) K :=
    (hwithin.mono hKS).congr fun z hz =>
      (iteratedFDerivWithin_of_isOpen order S.open_neighborhood (hKS hz)).symm
  obtain ⟨M, hM⟩ := hK.exists_bound_of_continuousOn hcont
  exact ⟨max M 0, le_max_right _ _, fun z hz =>
    (hM z hz).trans (le_max_left _ _)⟩

/-- Every fixed finite order derivative of the defining function is uniformly
bounded on a compact subset of its extension neighborhood. -/
theorem SmoothPatch.iterated_defining_derivative_bound_on_compact {n order : ℕ}
    (S : SmoothPatch n) {K : Set (Ambient n)} (hK : IsCompact K)
    (hKS : K ⊆ S.neighborhood) :
    ∃ M : ℝ, 0 ≤ M ∧ ∀ z ∈ K,
      ‖iteratedFDeriv ℝ order S.defining z‖ ≤ M := by
  have hwithin :
      ContinuousOn (iteratedFDerivWithin ℝ order S.defining S.neighborhood)
        S.neighborhood :=
    S.smooth_defining.continuousOn_iteratedFDerivWithin
      (show (order : WithTop ℕ∞) ≤ (⊤ : ℕ∞) by
        exact_mod_cast (le_top : (order : ℕ∞) ≤ ⊤))
      S.open_neighborhood.uniqueDiffOn
  have hcont : ContinuousOn (iteratedFDeriv ℝ order S.defining) K :=
    (hwithin.mono hKS).congr fun z hz =>
      (iteratedFDerivWithin_of_isOpen order S.open_neighborhood (hKS hz)).symm
  obtain ⟨M, hM⟩ := hK.exists_bound_of_continuousOn hcont
  exact ⟨max M 0, le_max_right _ _, fun z hz =>
    (hM z hz).trans (le_max_left _ _)⟩

/-- As a continuous linear map, the defining differential is the normal inner
product functional scaled by the positive normal factor. -/
theorem SmoothPatch.fderiv_defining_eq_normalScale_smul_inner {n : ℕ}
    (S : SmoothPatch n) {z : Ambient n} (hz : z ∈ S.neighborhood) :
    fderiv ℝ S.defining z = S.normalScale z • innerSL ℝ (S.normal z) := by
  ext v
  simp only [ContinuousLinearMap.smul_apply, innerSL_apply]
  exact S.normal_differential z hz v

/-- The operator norm of the defining differential equals its positive normal
scale, since the chosen normal is a unit vector. -/
theorem SmoothPatch.norm_fderiv_defining_eq_normalScale {n : ℕ}
    (S : SmoothPatch n) {z : Ambient n} (hz : z ∈ S.neighborhood) :
    ‖fderiv ℝ S.defining z‖ = S.normalScale z := by
  rw [S.fderiv_defining_eq_normalScale_smul_inner hz, norm_smul,
    Real.norm_eq_abs, abs_of_pos (S.positive_normalScale z hz),
    innerSL_apply_norm, S.normal_unit z hz]
  norm_num

/-- Quantitative separation of the two summands, stronger than disjointness alone. -/
theorem nearby_normal_sum_bound {n : ℕ} (S : SmoothPatch n)
    (W H : Submodule ℝ (Ambient n)) (hdim : Module.finrank ℝ W = Module.finrank ℝ H)
    {z : Ambient n} (hz : z ∈ S.neighborhood)
    (hzero : H.orthogonalProjection (S.normal z) = 0)
    (hW : ∀ v : W, inner ℝ (S.normal z) (v : Ambient n) = 0)
    {κ : ℝ} (hκ : 0 < κ)
    (hA : ∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (S.shape z v)‖)
    (hgap : ‖W.starProjection - H.starProjection‖ * ‖S.shape z‖ ≤ κ / 2)
    (v : Wᗮ) (h : H) :
    ‖v‖ + ‖h‖ ≤ (1 + (1 + ‖S.shape z‖) * (2 / κ)) * ‖(v : Ambient n) + S.shape z h‖ := by
  let x : Ambient n := (v : Ambient n) + S.shape z h
  have hp : W.orthogonalProjection x = W.orthogonalProjection (S.shape z h) := by
    dsimp only [x]
    rw [map_add, Submodule.orthogonalProjection_eq_zero_iff.mpr v.property, zero_add]
  have hc : (κ / 2) * ‖h‖ ≤ ‖x‖ :=
    (nearby_reverse_shape_coercive S W H hdim hz hzero hW hκ hA hgap h).trans
      (by rw [← hp]; exact W.norm_orthogonalProjection_apply_le x)
  have hh : ‖h‖ ≤ (2 / κ) * ‖x‖ := by
    have hh' : ‖h‖ ≤ ‖x‖ / (κ / 2) :=
      (le_div_iff₀ (by positivity : 0 < κ / 2)).mpr (by nlinarith [hc])
    convert hh' using 1
    field_simp
  have hv : ‖v‖ ≤ ‖x‖ + ‖S.shape z‖ * ‖h‖ := by
    have he : (v : Ambient n) = x - S.shape z h := by simp [x]
    change ‖(v : Ambient n)‖ ≤ _
    rw [he]
    exact (norm_sub_le _ _).trans (add_le_add_left ((S.shape z).le_opNorm h) _)
  have hm := mul_le_mul_of_nonneg_left hh (by positivity : 0 ≤ 1 + ‖S.shape z‖)
  change ‖v‖ + ‖h‖ ≤ (1 + (1 + ‖S.shape z‖) * (2 / κ)) * ‖x‖
  nlinarith

/-- Uniform nearby-plane transversality on a compact frequency set: one gap
threshold and one inverse bound work for all points and all admissible planes.
Uniform implicit charts and restriction estimates are separate obligations. -/
theorem uniform_nearby_normal_sum_bound {n : ℕ} (S : SmoothPatch n)
    {K : Set (Ambient n)} (hK : IsCompact K) (hKS : K ⊆ S.neighborhood)
    {κ : ℝ} (hκ : 0 < κ) :
    ∃ δ C : ℝ, 0 < δ ∧ 0 < C ∧ ∀ z ∈ K,
      ∀ (W H : Submodule ℝ (Ambient n)),
      Module.finrank ℝ W = Module.finrank ℝ H →
      H.orthogonalProjection (S.normal z) = 0 →
      (∀ v : W, inner ℝ (S.normal z) (v : Ambient n) = 0) →
      (∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (S.shape z v)‖) →
      ‖W.starProjection - H.starProjection‖ ≤ δ →
      ∀ (v : Wᗮ) (h : H), ‖v‖ + ‖h‖ ≤ C * ‖(v : Ambient n) + S.shape z h‖ := by
  obtain ⟨M, hM, hb⟩ := S.shape_bound_on_compact hK hKS
  let δ := κ / (2 * (M + 1))
  let C := 1 + (1 + M) * (2 / κ)
  have hδ : 0 < δ := by dsimp [δ]; positivity
  have hC : 0 < C := by dsimp [C]; positivity
  refine ⟨δ, C, hδ, hC, fun z hz W H hdim hzero hW hA hgap v h => ?_⟩
  have hg : ‖W.starProjection - H.starProjection‖ * ‖S.shape z‖ ≤ κ / 2 := by
    calc
      _ ≤ δ * M := mul_le_mul hgap (hb z hz) (norm_nonneg _) hδ.le
      _ ≤ δ * (M + 1) := mul_le_mul_of_nonneg_left (by linarith) hδ.le
      _ = κ / 2 := by
        dsimp [δ]
        field_simp [ne_of_gt (by linarith : 0 < M + 1)]
  have hbound := nearby_normal_sum_bound S W H hdim (hKS hz) hzero hW hκ hA hg v h
  apply hbound.trans
  apply mul_le_mul_of_nonneg_right _ (norm_nonneg _)
  dsimp [C]
  exact add_le_add_left (mul_le_mul_of_nonneg_right (add_le_add_left (hb z hz) 1) (by positivity)) 1

end N2Restriction
