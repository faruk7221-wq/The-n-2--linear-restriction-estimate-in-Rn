import N2Restriction.CommonTangent
import Mathlib.Analysis.Calculus.ContDiff.Basic
import Mathlib.MeasureTheory.Measure.Hausdorff
import Mathlib.LinearAlgebra.Matrix.NonsingularInverse

/-! Explicit targets for continuing the formalization. No theorem in this
file asserts either target. In particular, a defined proposition is not a proof.

A hypersurface is presented locally as a regular level set. Its chosen smooth
unit normal is required to be a positive multiple of the differential of the
level-set function, so `shape` below is the actual derivative of that normal.
The compact frequency support is measured with (n-1)-dimensional Hausdorff
measure, not an arbitrary placeholder measure. Mathlib's Hausdorff measure
normalization only changes the harmless constants in the restriction bounds. -/

namespace N2Restriction
open MeasureTheory

/-- A compact frequency support inside a fixed extended smooth hypersurface. -/
structure SmoothPatch (n : ℕ) where
  support : Set (Ambient n)
  compact_support : IsCompact support
  neighborhood : Set (Ambient n)
  open_neighborhood : IsOpen neighborhood
  support_inside : support ⊆ neighborhood
  defining : Ambient n → ℝ
  smooth_defining : ContDiffOn ℝ (⊤ : ℕ∞) defining neighborhood
  support_on_surface : ∀ z ∈ support, defining z = 0
  normal : Ambient n → Ambient n
  smooth_normal : ContDiffOn ℝ (⊤ : ℕ∞) normal neighborhood
  normal_unit : ∀ z ∈ neighborhood, ‖normal z‖ = 1
  normalScale : Ambient n → ℝ
  positive_normalScale : ∀ z ∈ neighborhood, 0 < normalScale z
  normal_differential : ∀ z ∈ neighborhood, ∀ v : Ambient n,
    fderiv ℝ defining z v = normalScale z * inner ℝ (normal z) v

namespace SmoothPatch

/-- The whole regular level set on which geometry is assumed, including room
outside the original compact support. -/
def extendedSurface {n : ℕ} (S : SmoothPatch n) : Set (Ambient n) :=
  {z | z ∈ S.neighborhood ∧ S.defining z = 0}

noncomputable def surfaceMeasure {n : ℕ} (S : SmoothPatch n) : Measure (Ambient n) :=
  (Measure.hausdorffMeasure ((n : ℝ) - 1)).restrict S.support

/-- Ambient extension of the shape operator. Its restriction to the tangent
space is -dN, exactly as in the article. -/
noncomputable def shape {n : ℕ} (S : SmoothPatch n) (z : Ambient n) :
    Ambient n →L[ℝ] Ambient n := -fderiv ℝ S.normal z

lemma support_in_extendedSurface {n : ℕ} (S : SmoothPatch n) :
    S.support ⊆ S.extendedSurface := by
  intro z hz
  exact ⟨S.support_inside hz, S.support_on_surface z hz⟩

/-- Regularity of the defining level set follows from the specified normal.
This excludes a zero differential at every point of the extension. -/
lemma differential_ne_zero {n : ℕ} (S : SmoothPatch n) (z : Ambient n)
    (hz : z ∈ S.neighborhood) : fderiv ℝ S.defining z ≠ 0 := by
  intro hzero
  have h := S.normal_differential z hz (S.normal z)
  rw [hzero, ContinuousLinearMap.zero_apply, real_inner_self_eq_norm_sq,
    S.normal_unit z hz] at h
  have hp := S.positive_normalScale z hz
  norm_num at h
  linarith

end SmoothPatch

/-- Quantitative versions of (1.4) and (1.6) on every extended frequency tuple.
The Gram determinant is the square of the normal wedge volume. -/
def GeometricHypotheses {k : ℕ} (S : Fin k → SmoothPatch (k + 2))
    (ν κ : ℝ) : Prop :=
  0 < ν ∧ 0 < κ ∧
  ∀ z : Fin k → Ambient (k + 2), (∀ i, z i ∈ (S i).extendedSurface) →
    let N : Fin k → Ambient (k + 2) := fun i => (S i).normal (z i)
    ν ^ 2 ≤ Matrix.det (fun i j => inner ℝ (N i) (N j)) ∧
    ∀ i, ∀ v : commonTangent N,
      κ * ‖v‖ ≤ ‖(commonTangent N).orthogonalProjection ((S i).shape (z i) v)‖

/-- A nonzero Gram determinant forces linear independence of the normals. -/
lemma normals_independent_of_gram {k n : ℕ} (N : Fin k → Ambient n)
    (hdet : Matrix.det (fun i j => inner ℝ (N i) (N j)) ≠ 0) :
    LinearIndependent ℝ N := by
  let M : Matrix (Fin k) (Fin k) ℝ := fun i j => inner ℝ (N i) (N j)
  have hM : IsUnit M := (Matrix.isUnit_iff_isUnit_det M).mpr (isUnit_iff_ne_zero.mpr hdet)
  have hinj : Function.Injective M.mulVec := Matrix.mulVec_injective_iff_isUnit.mpr hM
  rw [Fintype.linearIndependent_iff]
  intro a ha
  have hz : M.mulVec a = 0 := by
    funext i
    change (∑ j, inner ℝ (N i) (N j) * a j) = 0
    simp_rw [mul_comm _ (a _), ← inner_smul_right, ← inner_sum, ha, inner_zero_right]
  have heq : a = 0 := hinj (hz.trans (Matrix.mulVec_zero M).symm)
  intro i
  exact congrFun heq i

/-- The full quantitative geometric hypotheses give the claimed two-plane
for every tuple, on the actual extended surfaces. -/
theorem geometric_commonTangent_two {k : ℕ} (S : Fin k → SmoothPatch (k + 2))
    {ν κ : ℝ} (h : GeometricHypotheses S ν κ)
    (z : Fin k → Ambient (k + 2)) (hz : ∀ i, z i ∈ (S i).extendedSurface) :
    Module.finrank ℝ (commonTangent (fun i => (S i).normal (z i))) = 2 := by
  apply commonTangent_two
  apply normals_independent_of_gram
  have hdet := (h.2.2 z hz).1
  have hν : 0 < ν ^ 2 := sq_pos_of_pos h.1
  exact ne_of_gt (lt_of_lt_of_le hν hdet)

/-- The precise outstanding local theorem target for the smooth level-set
presentation. This is deliberately a proposition definition, not a theorem. -/
def MainLocalGoal : Prop :=
  ∀ k : ℕ, 3 ≤ k → ∀ S : Fin k → SmoothPatch (k + 2),
    ∀ ν κ : ℝ, GeometricHypotheses S ν κ →
      LocalRestriction (fun i => (S i).surfaceMeasure) (fun _ => id) (critical k)

/-- The precise outstanding strict global theorem target. -/
def MainGlobalGoal : Prop :=
  ∀ k : ℕ, 3 ≤ k → ∀ S : Fin k → SmoothPatch (k + 2),
    ∀ ν κ : ℝ, GeometricHypotheses S ν κ →
      ∀ p : ℝ, critical k < p →
        GlobalRestriction (fun i => (S i).surfaceMeasure) (fun _ => id) p

end N2Restriction
