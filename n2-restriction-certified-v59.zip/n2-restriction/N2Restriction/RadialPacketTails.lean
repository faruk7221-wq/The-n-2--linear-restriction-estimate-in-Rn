import N2Restriction.OscillatoryDecay
import N2Restriction.TranslatedLatticeWeights

namespace N2Restriction
open scoped BigOperators

/-- The integer Fourier index as a Euclidean vector. -/
def latticeVector {d : ℕ} (ν : Fin d → ℤ) : Ambient d :=
  WithLp.toLp 2 (fun j => (ν j : ℝ))

/-- Radial decay of order d is dominated by the product lattice weight already
proved to be square summable, uniformly in the real center. -/
theorem radial_decay_le_centeredLatticeDecay {d : ℕ} (a : Ambient d) (ν : Fin d → ℤ) :
    ((1 + ‖latticeVector ν - a‖) ^ d)⁻¹ ≤ centeredLatticeDecay a ν := by
  have hcoord (j : Fin d) : |(ν j : ℝ) - a j| ≤ ‖latticeVector ν - a‖ := by
    exact PiLp.norm_apply_le (latticeVector ν - a) j
  have ht : (∏ _ : Fin d, (1 + ‖latticeVector ν - a‖)⁻¹) ≤
      ∏ j : Fin d, (1 + |(ν j : ℝ) - a j|)⁻¹ := by
    apply Finset.prod_le_prod
    · intro j _; positivity
    · intro j _
      exact inv_anti₀ (by positivity) (by linarith [hcoord j])
  simpa only [Finset.prod_const, Finset.card_univ, Fintype.card_fin, inv_pow] using ht

/-- Extra radial powers give an explicit tail factor outside any chosen radius. -/
theorem radial_decay_tail_factor {d : ℕ} (a : Ambient d) (ν : Fin d → ℤ)
    {L : ℝ} (hL : 0 ≤ L) (hν : L ≤ ‖latticeVector ν - a‖) (M : ℕ) :
    ((1 + ‖latticeVector ν - a‖) ^ (d + M))⁻¹ ≤
      ((1 + L) ^ M)⁻¹ * centeredLatticeDecay a ν := by
  rw [pow_add, mul_inv_rev]
  apply mul_le_mul
  · apply inv_anti₀ (by positivity)
    exact pow_le_pow_left₀ (by positivity) (by linarith) M
  · exact radial_decay_le_centeredLatticeDecay a ν
  · positivity
  · positivity

/-- Pointwise radial packet bounds imply an absolute estimate for every
possibly infinite selection outside the chosen radius. -/
theorem radial_packet_absolute_tail {d : ℕ} {E F : Type*}
    [NormedAddCommGroup E] [InnerProductSpace ℂ E] [NormedAddCommGroup F]
    (b : HilbertBasis (Fin d → ℤ) ℂ E) (x : E) (a : Ambient d)
    (r : (Fin d → ℤ) → F) {C L : ℝ} (hC : 0 ≤ C) (hL : 0 ≤ L) (M : ℕ)
    (hr : ∀ ν, ‖r ν‖ ≤ C * ‖b.repr x ν‖ / (1 + ‖latticeVector ν - a‖) ^ (d + M))
    (S : Set (Fin d → ℤ)) (hS : ∀ ν ∈ S, L ≤ ‖latticeVector ν - a‖) :
    (∑' ν : S, ‖r ν‖) ≤ C / (1 + L) ^ M * ‖x‖ * (2 ^ d * ‖latticeWeight d‖) := by
  classical
  let r' : (Fin d → ℤ) → F := fun ν => if ν ∈ S then r ν else 0
  have hδ : 0 ≤ C / (1 + L) ^ M := by positivity
  have hb (ν : Fin d → ℤ) : ‖r' ν‖ ≤
      C / (1 + L) ^ M * (‖b.repr x ν‖ * centeredLatticeDecay a ν) := by
    by_cases hν : ν ∈ S
    · simp only [r', if_pos hν]
      calc
        _ ≤ _ := hr ν
        _ ≤ (C * ‖b.repr x ν‖) *
            (((1 + L) ^ M)⁻¹ * centeredLatticeDecay a ν) := by
          rw [div_eq_mul_inv]
          exact mul_le_mul_of_nonneg_left (radial_decay_tail_factor a ν hL (hS ν hν) M)
            (mul_nonneg hC (norm_nonneg _))
        _ = _ := by rw [div_eq_mul_inv]; ring
    · simp only [r', if_neg hν, norm_zero]
      exact mul_nonneg hδ (mul_nonneg (norm_nonneg _) (centeredLatticeDecay_nonneg _ _))
  have ht := centered_lattice_packet_tail b x a r' hδ hb S
  simpa only [r', Subtype.coe_prop, if_true] using ht

/-- Radial domination also establishes absolute convergence, so selected
series in the tail estimate are genuine convergent series. -/
theorem radial_packet_norm_summable {d : ℕ} {E F : Type*}
    [NormedAddCommGroup E] [InnerProductSpace ℂ E] [NormedAddCommGroup F]
    (b : HilbertBasis (Fin d → ℤ) ℂ E) (x : E) (a : Ambient d)
    (r : (Fin d → ℤ) → F) {C : ℝ} (hC : 0 ≤ C) (M : ℕ)
    (hr : ∀ ν, ‖r ν‖ ≤ C * ‖b.repr x ν‖ / (1 + ‖latticeVector ν - a‖) ^ (d + M)) :
    Summable (fun ν => ‖r ν‖) := by
  apply packet_error_norm_summable b x (centeredLatticeWeight a) r
  intro ν
  have ht := radial_decay_tail_factor a ν (le_refl (0 : ℝ)) (norm_nonneg _) M
  simp only [add_zero, one_pow, inv_one, one_mul] at ht
  change ‖r ν‖ ≤ C * (‖b.repr x ν‖ * ‖(centeredLatticeDecay a ν : ℂ)‖)
  rw [Complex.norm_real, Real.norm_eq_abs,
    abs_of_nonneg (centeredLatticeDecay_nonneg _ _)]
  calc
    _ ≤ _ := hr ν
    _ ≤ (C * ‖b.repr x ν‖) * centeredLatticeDecay a ν := by
      rw [div_eq_mul_inv]
      exact mul_le_mul_of_nonneg_left ht (mul_nonneg hC (norm_nonneg _))
    _ = _ := mul_assoc _ _ _

/-- The norm of the actual selected packet series has the same tail budget. -/
theorem radial_packet_synthesis {d : ℕ} {E F : Type*}
    [NormedAddCommGroup E] [InnerProductSpace ℂ E] [NormedAddCommGroup F] [CompleteSpace F]
    (b : HilbertBasis (Fin d → ℤ) ℂ E) (x : E) (a : Ambient d)
    (r : (Fin d → ℤ) → F) {C L : ℝ} (hC : 0 ≤ C) (hL : 0 ≤ L) (M : ℕ)
    (hr : ∀ ν, ‖r ν‖ ≤ C * ‖b.repr x ν‖ / (1 + ‖latticeVector ν - a‖) ^ (d + M))
    (S : Set (Fin d → ℤ)) (hS : ∀ ν ∈ S, L ≤ ‖latticeVector ν - a‖) :
    Summable (fun ν : S => r ν) ∧
      ‖∑' ν : S, r ν‖ ≤ C / (1 + L) ^ M * ‖x‖ * (2 ^ d * ‖latticeWeight d‖) := by
  have hs := (radial_packet_norm_summable b x a r hC M hr).subtype S
  exact ⟨hs.of_norm, (norm_tsum_le_tsum_norm hs).trans
    (radial_packet_absolute_tail b x a r hC hL M hr S hS)⟩

/-- The compact-family integration-by-parts theorem supplies the pointwise
bound in the preceding theorem for actual coefficient-weighted integrals. -/
theorem compact_family_oscillatory_packet_tail {P : Type*}
    [NormedAddCommGroup P] [NormedSpace ℝ P] {d : ℕ}
    {amp : P × Ambient d → ℂ} {ψ : P × Ambient d → ℝ}
    (ha : ContDiff ℝ (⊤ : ℕ∞) amp) (hψ : ContDiff ℝ (⊤ : ℕ∞) ψ)
    {Q : Set P} (hQ : IsCompact Q) {K : Set (Ambient d)} (hK : IsCompact K)
    (hs : ∀ p ∈ Q, tsupport (fun y => amp (p, y)) ⊆ K) (M : ℕ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (p : P), p ∈ Q →
      ∀ {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E],
      ∀ (b : HilbertBasis (Fin d → ℤ) ℂ E) (x : E) (a : Ambient d)
        (L : ℝ), 0 ≤ L → ∀ S : Set (Fin d → ℤ),
      (∀ ν ∈ S, L ≤ ‖latticeVector ν - a‖) →
      (∑' ν : S, ‖b.repr x ν * oscillatoryIntegral
        (fun y => ψ (p, y)) (fun y => amp (p, y)) (latticeVector ν - a)‖) ≤
        C / (1 + L) ^ M * ‖x‖ * (2 ^ d * ‖latticeWeight d‖) := by
  obtain ⟨C, hC, hb⟩ := compact_family_oscillatory_decay ha hψ hQ hK hs (d + M)
  refine ⟨C, hC, fun p hp E _ _ b x a L hL S hS => ?_⟩
  apply radial_packet_absolute_tail b x a
    (fun ν => b.repr x ν * oscillatoryIntegral (fun y => ψ (p, y))
      (fun y => amp (p, y)) (latticeVector ν - a)) hC hL M _ S hS
  intro ν
  rw [norm_mul]
  calc
    _ ≤ ‖b.repr x ν‖ * (C / (1 + ‖latticeVector ν - a‖) ^ (d + M)) :=
      mul_le_mul_of_nonneg_left (hb p hp _) (norm_nonneg _)
    _ = _ := by ring

end N2Restriction
