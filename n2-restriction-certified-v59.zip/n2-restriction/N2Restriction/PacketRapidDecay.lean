import N2Restriction.RadialPacketTails
import N2Restriction.GraphPackets
import N2Restriction.Scales

namespace N2Restriction

/-- An explicit finite integration-by-parts order absorbs any polynomial loss
outside the enlarged tube scale R^τ/10. -/
theorem polynomial_tail_scale_bound {R τ b N : ℝ} (hR : 1 ≤ R) (M : ℕ)
    (hM : N + b ≤ τ * M) :
    R ^ b / (1 + R ^ τ / 10) ^ M ≤ (10 : ℝ) ^ M * R ^ (-N) := by
  have hRp : 0 < R := by linarith
  have hrt : 0 < R ^ τ := Real.rpow_pos_of_pos hRp _
  have hden : (R ^ τ / 10) ^ M ≤ (1 + R ^ τ / 10) ^ M :=
    pow_le_pow_left₀ (by positivity) (by linarith) M
  calc
    _ ≤ R ^ b / (R ^ τ / 10) ^ M :=
      div_le_div_of_nonneg_left (Real.rpow_nonneg hRp.le _) (by positivity) hden
    _ = (10 : ℝ) ^ M * R ^ (b - τ * M) := by
      rw [div_pow, div_div_eq_mul_div, mul_comm (R ^ b), mul_div_assoc,
        ← Real.rpow_natCast (R ^ τ) M, ← Real.rpow_mul hRp.le, ← Real.rpow_sub hRp]
    _ ≤ _ := mul_le_mul_of_nonneg_left
      (Real.rpow_le_rpow_of_exponent_le hR (by linarith)) (by positivity)

/-- The required derivative order exists for every requested rapid-decay power. -/
theorem exists_packet_tail_order {τ : ℝ} (hτ : 0 < τ) (b N : ℝ) :
    ∃ M : ℕ, ∀ R : ℝ, 1 ≤ R →
      R ^ b / (1 + R ^ τ / 10) ^ M ≤ (10 : ℝ) ^ M * R ^ (-N) := by
  obtain ⟨M, hM⟩ := exists_nat_gt ((N + b) / τ)
  refine ⟨M, fun R hR => polynomial_tail_scale_bound hR M ?_⟩
  have := (div_lt_iff₀ hτ).mp hM
  nlinarith

/-- Uniform rapid decrease of absolute selected lattice tails, even after an
arbitrary polynomial scale loss. This is an estimate of actual integrals. -/
theorem compact_family_oscillatory_rapid_tail {P : Type*}
    [NormedAddCommGroup P] [NormedSpace ℝ P] {d : ℕ}
    {amp : P × Ambient d → ℂ} {ψ : P × Ambient d → ℝ}
    (ha : ContDiff ℝ (⊤ : ℕ∞) amp) (hψ : ContDiff ℝ (⊤ : ℕ∞) ψ)
    {Q : Set P} (hQ : IsCompact Q) {K : Set (Ambient d)} (hK : IsCompact K)
    (hs : ∀ p ∈ Q, tsupport (fun y => amp (p, y)) ⊆ K)
    {τ : ℝ} (hτ : 0 < τ) (b N : ℝ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (R : ℝ), 1 ≤ R → ∀ (p : P), p ∈ Q →
      ∀ {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E],
      ∀ (e : HilbertBasis (Fin d → ℤ) ℂ E) (x : E) (a : Ambient d)
        (S : Set (Fin d → ℤ)),
      (∀ ν ∈ S, R ^ τ / 10 ≤ ‖latticeVector ν - a‖) →
      R ^ b * (∑' ν : S, ‖e.repr x ν * oscillatoryIntegral
        (fun y => ψ (p, y)) (fun y => amp (p, y)) (latticeVector ν - a)‖) ≤
        C * R ^ (-N) * ‖x‖ := by
  obtain ⟨M, hM⟩ := exists_packet_tail_order hτ b N
  obtain ⟨C, hC, hb⟩ := compact_family_oscillatory_packet_tail ha hψ hQ hK hs M
  refine ⟨C * 10 ^ M * (2 ^ d * ‖latticeWeight d‖), by positivity,
    fun R hR p hp E _ _ e x a S hS => ?_⟩
  have hRp : 0 < R := by linarith
  have ht := hb p hp e x a (R ^ τ / 10) (by positivity) S hS
  calc
    _ ≤ R ^ b * (C / (1 + R ^ τ / 10) ^ M * ‖x‖ *
        (2 ^ d * ‖latticeWeight d‖)) :=
      mul_le_mul_of_nonneg_left ht (Real.rpow_nonneg hRp.le _)
    _ = (C * ‖x‖ * (2 ^ d * ‖latticeWeight d‖)) *
        (R ^ b / (1 + R ^ τ / 10) ^ M) := by ring
    _ ≤ (C * ‖x‖ * (2 ^ d * ‖latticeWeight d‖)) * (10 ^ M * R ^ (-N)) :=
      mul_le_mul_of_nonneg_left (hM R hR) (by positivity)
    _ = _ := by ring

/-- The parabolic choice of cap scale makes the nonlinear time parameter
uniformly bounded on the full physical ball's height range. -/
theorem parabolic_time_parameter {R t : ℝ} (hR : 0 < R) (ht : |t| ≤ R) :
    |t * (R ^ (-1 / 2 : ℝ)) ^ 2| ≤ 1 := by
  have hs : (R ^ (-1 / 2 : ℝ)) ^ 2 = R⁻¹ := by
    rw [← Real.rpow_natCast, ← Real.rpow_mul hR.le]
    norm_num [Real.rpow_neg_one]
  rw [hs, abs_mul, abs_of_pos (inv_pos.mpr hR)]
  calc
    |t| * R⁻¹ ≤ R * R⁻¹ := mul_le_mul_of_nonneg_right ht (inv_nonneg.mpr hR.le)
    _ = 1 := mul_inv_cancel₀ hR.ne'

/-- The displayed single-packet decay estimate of Lemma 3.2, proved here for
paraboloid graph packets with an arbitrary fixed smooth compact cutoff. -/
theorem paraboloid_packet_decay_at_scale (d M : ℕ) {χ : Ambient d → ℂ}
    (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hs : HasCompactSupport χ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (R : ℝ), 0 < R → ∀ (c v u : Ambient d) (t : ℝ),
      |t| ≤ R →
      ‖graphPacket (fun ξ => inner ℝ ξ ξ / 2) χ c (R ^ (-1 / 2 : ℝ)) v u t‖ ≤
        R ^ (-(d : ℝ) / 4) *
          (C / (1 + R ^ (-1 / 2 : ℝ) * ‖u + v + t • c‖) ^ M) := by
  obtain ⟨C, hC, hb⟩ := paraboloid_packet_decay d M hχ hs
  refine ⟨C, hC, fun R hR c v u t ht => ?_⟩
  have hd := hb c (R ^ (-1 / 2 : ℝ)) (Real.rpow_pos_of_pos hR _) v u t
    (parabolic_time_parameter hR ht)
  rw [← Real.rpow_mul hR.le] at hd
  convert hd using 2
  congr 2
  ring

end N2Restriction
