import N2Restriction.GraphMeasureTransfer

namespace N2Restriction
open MeasureTheory Set
open scoped NNReal ENNReal

/-- A chart with an actual density for Hausdorff measure on its graph. -/
structure SurfaceGraphChart (d : ℕ) where
  phase : Ambient d → ℝ
  lipConstant : ℝ≥0
  lipschitz : LipschitzWith lipConstant phase
  density : PositiveBoundedDensity (volume : Measure (Ambient d))
  surface_eq : density.measure.map (fun x => graphPoint x (phase x)) =
    (Measure.hausdorffMeasure (d : ℝ)).restrict (range (fun x => graphPoint x (phase x)))

/-- The graph chart is constructed from a Lipschitz height function. -/
theorem exists_surfaceGraphChart {d : ℕ} {φ : Ambient d → ℝ} {L : ℝ≥0}
    (hφ : LipschitzWith L φ) : ∃ G : SurfaceGraphChart d, G.phase = φ := by
  obtain ⟨J, hJ, hb, he⟩ := exists_lipschitz_graph_density hφ
  let D : PositiveBoundedDensity (volume : Measure (Ambient d)) :=
    { weight := J
      measurable := hJ
      lower := coordinateHausdorffFactor d
      upper := ((1 + L) ^ d * coordinateHausdorffFactor d : ℝ≥0)
      lower_pos := by exact_mod_cast coordinateHausdorffFactor_pos d
      upper_nonneg := NNReal.coe_nonneg _
      lower_le := hb.mono fun x hx => by exact_mod_cast hx.1
      le_upper := hb.mono fun x hx => by exact_mod_cast hx.2 }
  exact ⟨⟨φ, L, hφ, D, he⟩, rfl⟩

namespace SurfaceGraphChart
variable {d : ℕ} (G : SurfaceGraphChart d)

def parametrization (x : Ambient d) : Ambient (d + 1) := graphPoint x (G.phase x)

theorem measurableEmbedding_parametrization : MeasurableEmbedding G.parametrization :=
  ((graphMap_antilipschitz G.phase).isClosedEmbedding (graphMap_lipschitz G.lipschitz).uniformContinuous).measurableEmbedding

/-- This measure is proved equal to actual Hausdorff measure restricted to the graph. -/
noncomputable def surfaceMeasure : Measure (Ambient (d + 1)) := G.density.measure.map G.parametrization

theorem surfaceMeasure_eq : G.surfaceMeasure =
    (Measure.hausdorffMeasure (d : ℝ)).restrict (range G.parametrization) := G.surface_eq

noncomputable def liftInput : Lp ℂ 2 G.density.measure →ₗᵢ[ℂ] Lp ℂ 2 G.surfaceMeasure :=
  imageInput G.density.measure G.parametrization graphProjection
    G.measurableEmbedding_parametrization.measurable graphProjection_lipschitz.continuous.measurable
    (fun x => graphProjection_graphPoint x (G.phase x))

noncomputable def pullInput : Lp ℂ 2 G.surfaceMeasure →ₗᵢ[ℂ] Lp ℂ 2 G.density.measure :=
  Lp.compMeasurePreservingₗᵢ ℂ G.parametrization ⟨G.measurableEmbedding_parametrization.measurable, rfl⟩

theorem lift_pull (g : Lp ℂ 2 G.surfaceMeasure) : G.liftInput (G.pullInput g) = g :=
  imageInput_pullback G.density.measure G.parametrization graphProjection
    G.measurableEmbedding_parametrization graphProjection_lipschitz.continuous.measurable
    (fun x => graphProjection_graphPoint x (G.phase x)) g

theorem lift_extension (f : Lp ℂ 2 G.density.measure) (y : Ambient (d + 1)) :
    extension G.surfaceMeasure id (G.liftInput f) y = extension G.density.measure G.parametrization f y :=
  imageInput_extension G.density.measure G.parametrization graphProjection
    G.measurableEmbedding_parametrization graphProjection_lipschitz.continuous.measurable
    (fun x => graphProjection_graphPoint x (G.phase x)) f y

theorem pull_support (g : Lp ℂ 2 G.surfaceMeasure) (K : Set (Ambient d))
    (hg : HasFrequencySupport G.surfaceMeasure id (G.parametrization '' K) g) :
    HasFrequencySupport G.density.measure id K (G.pullInput g) := by
  have hp := Lp.coeFn_compMeasurePreserving g
    (show MeasurePreserving G.parametrization G.density.measure G.surfaceMeasure from
      ⟨G.measurableEmbedding_parametrization.measurable, rfl⟩)
  have hh := ae_of_ae_map G.measurableEmbedding_parametrization.measurable.aemeasurable hg
  filter_upwards [hp, hh] with x hx hs hn
  have he : (G.pullInput g) x = g (G.parametrization x) := hx
  obtain ⟨z, hz, hez⟩ := hs (by simpa only [he] using hn)
  exact G.measurableEmbedding_parametrization.injective hez ▸ hz

/-- Actual surface packets, built from the original surface input. -/
noncomputable def packet {K : Set (Ambient d)} {r : ℝ} (P : CoordinateCapFamily K r)
    (hr : 0 < r) (g : Lp ℂ 2 G.surfaceMeasure) (j : P.centers) (ν : Fin d → ℤ) :
    Lp ℂ 2 G.surfaceMeasure :=
  G.liftInput (P.densityPacket hr G.density (G.pullInput g) j ν)

theorem packet_hasSum {K : Set (Ambient d)} {r : ℝ} (P : CoordinateCapFamily K r)
    (hr : 0 < r) (g : Lp ℂ 2 G.surfaceMeasure)
    (hg : HasFrequencySupport G.surfaceMeasure id (G.parametrization '' K) g) :
    HasSum (fun p : P.centers × (Fin d → ℤ) => G.packet P hr g p.1 p.2) g := by
  have h := G.liftInput.toContinuousLinearMap.hasSum
    (P.densityPacket_hasSum hr G.density (G.pullInput g) (G.pull_support g K hg))
  simpa only [LinearIsometry.coe_toContinuousLinearMap, packet, G.lift_pull] using h

theorem packet_subcollection_summable {K : Set (Ambient d)} {r : ℝ} (P : CoordinateCapFamily K r)
    (hr : 0 < r) (g : Lp ℂ 2 G.surfaceMeasure) (S : Set (P.centers × (Fin d → ℤ))) :
    Summable (fun p : S => G.packet P hr g p.val.1 p.val.2) :=
  (G.liftInput.toContinuousLinearMap.hasSum
    (P.densityPacket_subcollection_summable hr G.density (G.pullInput g) S).hasSum).summable

theorem packet_total_energy {K : Set (Ambient d)} {r : ℝ} (P : CoordinateCapFamily K r)
    (hr : 0 < r) (g : Lp ℂ 2 G.surfaceMeasure) :
    (∑ j, ∑' ν, ‖G.packet P hr g j ν‖ ^ 2) ≤
      (G.density.upper / G.density.lower) *
        (packetCutoffEnergy d * (2 * Real.pi) ^ (-(d : ℝ))) * ‖g‖ ^ 2 := by
  simpa only [packet, LinearIsometry.norm_map] using
    P.densityPacket_total_energy hr G.density (G.pullInput g)

theorem packet_extension {K : Set (Ambient d)} {r : ℝ} (P : CoordinateCapFamily K r)
    (hr : 0 < r) (g : Lp ℂ 2 G.surfaceMeasure) (j : P.centers) (ν : Fin d → ℤ)
    (y : Ambient (d + 1)) :
    extension G.surfaceMeasure id (G.packet P hr g j ν) y =
      extension volume G.parametrization (P.packet hr (G.density.toCoordinate (G.pullInput g)) j ν) y := by
  rw [packet, G.lift_extension, P.densityPacket_extension]

theorem packet_support {K : Set (Ambient d)} {r : ℝ} (P : CoordinateCapFamily K r)
    (hr : 0 < r) (g : Lp ℂ 2 G.surfaceMeasure) (j : P.centers) (ν : Fin d → ℤ) :
    HasFrequencySupport G.surfaceMeasure id
      (G.parametrization '' Metric.ball (j : Ambient d) (2 * r)) (G.packet P hr g j ν) :=
  imageInput_support G.density.measure G.parametrization graphProjection
    G.measurableEmbedding_parametrization graphProjection_lipschitz.continuous.measurable
    (fun x => graphProjection_graphPoint x (G.phase x)) _ _
    (P.densityPacket_support hr G.density (G.pullInput g) j ν)

theorem packet_uniform_extension {K : Set (Ambient d)} {r : ℝ} (P : CoordinateCapFamily K r)
    (hK : IsCompact K) (hr : 0 < r) (g : Lp ℂ 2 G.surfaceMeasure)
    (hg : HasFrequencySupport G.surfaceMeasure id (G.parametrization '' K) g) :
    ∀ ε : ℝ, 0 < ε → ∀ᶠ S : Finset (P.centers × (Fin d → ℤ)) in Filter.atTop,
      ∀ y : Ambient (d + 1), dist (∑ p ∈ S, extension G.surfaceMeasure id (G.packet P hr g p.1 p.2) y)
        (extension G.surfaceMeasure id g y) < ε := by
  have he : ∀ y, extension G.surfaceMeasure id g y =
      extension G.density.measure G.parametrization (G.pullInput g) y := by
    intro y
    simpa only [G.lift_pull] using G.lift_extension (G.pullInput g) y
  simpa only [packet, G.lift_extension, he] using
    P.densityPacket_uniform_extension hr hK G.density (G.pullInput g) (G.pull_support g K hg)
      G.parametrization G.measurableEmbedding_parametrization.measurable

/-- Coordinate cap support gives a genuine ambient Euclidean cap on the surface. -/
theorem packet_ambient_support {K : Set (Ambient d)} {r : ℝ} (P : CoordinateCapFamily K r)
    (hr : 0 < r) (g : Lp ℂ 2 G.surfaceMeasure) (j : P.centers) (ν : Fin d → ℤ) :
    HasFrequencySupport G.surfaceMeasure id
      (Metric.ball (G.parametrization j) ((1 + (G.lipConstant : ℝ)) * (2 * r)))
      (G.packet P hr g j ν) := by
  apply (G.packet_support P hr g j ν).mono
  rintro y ⟨x, hx, rfl⟩
  exact (graphMap_lipschitz G.lipschitz).dist_le_mul x j |>.trans_lt
    (mul_lt_mul_of_pos_left hx (by positivity))

end SurfaceGraphChart
end N2Restriction
