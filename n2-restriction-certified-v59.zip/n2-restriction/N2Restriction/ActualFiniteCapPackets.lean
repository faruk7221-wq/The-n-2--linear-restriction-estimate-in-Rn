import N2Restriction.ActualPacketExtension

namespace N2Restriction
open MeasureTheory UnitAddTorus
noncomputable local instance actualFiniteCircleMeasure : MeasureSpace UnitAddCircle := ⟨AddCircle.haarAddCircle⟩

/-- Exact packet-energy accounting across any supplied finite family of caps. -/
theorem actual_finite_cap_packet_energy {d : ℕ} {ι : Type*} [Fintype ι]
    (c : ι → Ambient d) (r : ℝ) (hr : 0 < r)
    (f : (j : ι) → Lp ℂ 2 (volume.restrict (packetFrequencyCube (c j) r hr))) :
    (∑ j, ∑' ν, ‖actualPacketInput (c j) r hr (f j) ν‖ ^ 2) =
      (packetCutoffEnergy d * (2 * Real.pi) ^ (-(d : ℝ))) * ∑ j, ‖f j‖ ^ 2 := by
  simp_rw [actualPacketInput_total_energy]
  rw [Finset.mul_sum]

/-- Finite-cap energy budgets retain the original input energies. -/
theorem actual_finite_cap_packet_budget {d : ℕ} {ι : Type*} [Fintype ι]
    (c : ι → Ambient d) (r : ℝ) (hr : 0 < r)
    (f : (j : ι) → Lp ℂ 2 (volume.restrict (packetFrequencyCube (c j) r hr)))
    {B F : ℝ} (he : (∑ j, ‖f j‖ ^ 2) ≤ B * F ^ 2) :
    (∑ j, ∑' ν, ‖actualPacketInput (c j) r hr (f j) ν‖ ^ 2) ≤
      (packetCutoffEnergy d * (2 * Real.pi) ^ (-(d : ℝ))) * B * F ^ 2 := by
  rw [actual_finite_cap_packet_energy]
  exact (mul_le_mul_of_nonneg_left he
    (mul_nonneg (packetCutoffEnergy_pos d).le (Real.rpow_nonneg (by positivity) _))).trans_eq (by ring)

/-- The rapid finite-cap tail theorem now uses the actual coordinate inputs and
the actual extensions, with no supplied abstract Hilbert coefficient family.
The polynomial cap count and summed original input energy remain explicit. -/
theorem actual_finite_cap_rapid_tail {d : ℕ} {U : Set (Ambient d)} (hU : IsOpen U)
    {φ : Ambient d → ℝ} (hφ : ContDiffOn ℝ (⊤ : ℕ∞) φ U)
    (z : Ambient d) {α β : ℝ} (hα : 0 < α) (hαβ : α < β)
    (hball : Metric.closedBall z β ⊆ U) {Q : Set (Ambient d)} (hQ : IsCompact Q)
    (hcenter : Q ⊆ Metric.ball z (α / 2)) {τ : ℝ} (hτ : 0 < τ) :
    ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ a N : ℝ, ∃ C : ℝ, 0 ≤ C ∧ ∀ (R : ℝ), R₀ ≤ R →
      ∀ {ι : Type*} [Fintype ι] (c : ι → Ambient d), (∀ j, c j ∈ Q) →
      ∀ (hr : 0 < R ^ (-1 / 2 : ℝ))
      (f : (j : ι) → Lp ℂ 2 (volume.restrict (packetFrequencyCube (c j) (R ^ (-1 / 2 : ℝ)) hr)))
      (u : Ambient d) (t : ℝ), |t| ≤ R →
      ∀ (A B F : ℝ), 0 ≤ A → 0 ≤ B → 0 ≤ F →
      (Fintype.card ι : ℝ) ≤ A * R ^ a → (∑ j, ‖f j‖ ^ 2) ≤ B * F ^ 2 →
      ∀ S : ι → Set (Fin d → ℤ),
      (∀ j ν, ν ∈ S j → R ^ (1 / 2 + τ) / 10 ≤
        Metric.infDist (graphPoint u t) (packetSegment (graphGradient φ (c j))
          ((R ^ (-1 / 2 : ℝ))⁻¹ • latticeVector ν) R)) →
      (∑ j, ∑' ν : S j, ‖extension volume (fun ξ => graphPoint ξ (φ ξ))
        (actualPacketInput (c j) (R ^ (-1 / 2 : ℝ)) hr (f j) ν) (graphPoint u t)‖) ≤
        C * Real.sqrt A * Real.sqrt B * R ^ (-N) * F := by
  obtain ⟨R₀, hR₀, htail⟩ := local_smooth_graph_finite_cap_rapid_tail hU hφ z hα hαβ hball
    hQ hcenter (packetCutoff_smooth d) (packetCutoff_compact d) hτ
  refine ⟨R₀, hR₀, fun a N => ?_⟩
  obtain ⟨C, hC, hb⟩ := htail a N
  let K := (2 * Real.pi) ^ (-(d : ℝ) / 2)
  have hK : 0 ≤ K := by dsimp [K]; positivity
  refine ⟨C * K, mul_nonneg hC hK, ?_⟩
  intro R hR ι _ c hc hr f u t ht A B F hA hB hF hcard henergy S hS
  have he : (∑ j, ‖packetTorusInput (c j) (R ^ (-1 / 2 : ℝ)) hr (f j)‖ ^ 2) ≤ B * (K * F) ^ 2 := by
    simp_rw [packetTorusInput_norm, mul_pow]
    rw [← Finset.mul_sum]
    exact (mul_le_mul_of_nonneg_left henergy (sq_nonneg K)).trans_eq (by ring)
  have h := hb R hR mFourierBasis
    (fun j => packetTorusInput (c j) (R ^ (-1 / 2 : ℝ)) hr (f j)) c hc u t ht
    A B (K * F) hA hB (mul_nonneg hK hF) hcard he S hS
  simp_rw [actualPacketInput_extension_norm]
  exact h.trans_eq (by ring)

end N2Restriction
