import N2Restriction.SupportMargins
import N2Restriction.LocalConstant

namespace N2Restriction
open MeasureTheory
open scoped ENNReal NNReal
section
variable {n k : ℕ} {Ω : Fin k → Type*} [∀ i, MeasurableSpace (Ω i)]
variable (μ : ∀ i, Measure (Ω i)) (ζ : ∀ i, Ω i → Ambient n)
variable (U : Fin k → Set (Ambient n)) (m : ℝ)

/-- Best constant with exactly the radius-dependent margin class, all centers,
and all L2 inputs. Unlike localConstant, no radius monotonicity is asserted. -/
noncomputable def marginLocalConstant (p R : ℝ) : ℝ≥0∞ :=
  ⨆ (x : Ambient n) (f : ∀ i, Ω i → ℂ) (_ : ∀ i, MemLp (f i) 2 (μ i))
    (_ : MarginAdmissible μ ζ U m R f),
    eLpNorm' (extensionProduct μ ζ f) p (volume.restrict (Metric.ball x R)) /
      inputNormProduct μ f

theorem marginLocalConstant_le_local (p R : ℝ) :
    marginLocalConstant μ ζ U m p R ≤ localConstant μ ζ p R := by
  refine iSup_le (fun x => iSup_le (fun f => iSup_le (fun hf => iSup_le (fun _ => ?_))))
  exact le_iSup_of_le x (le_iSup_of_le f (le_iSup_of_le hf le_rfl))

theorem marginLocalConstant_ne_top [∀ i, IsFiniteMeasure (μ i)] {p R : ℝ} (hp : 0 < p) :
    marginLocalConstant μ ζ U m p R ≠ ⊤ :=
  ne_top_of_le_ne_top (localConstant_ne_top μ ζ hp) (marginLocalConstant_le_local μ ζ U m p R)

/-- The margin best constant controls each admissible input, including zero data. -/
theorem marginLocalConstant_spec [∀ i, IsFiniteMeasure (μ i)] {p R : ℝ}
    (hp : 0 < p) (x : Ambient n) {f : ∀ i, Ω i → ℂ}
    (hf : ∀ i, MemLp (f i) 2 (μ i)) (hadm : MarginAdmissible μ ζ U m R f) :
    eLpNorm' (extensionProduct μ ζ f) p (volume.restrict (Metric.ball x R)) ≤
      marginLocalConstant μ ζ U m p R * inputNormProduct μ f := by
  by_cases hzero : inputNormProduct μ f = 0
  · simpa [hzero] using trivial_local_estimate μ ζ hp x hf
  · apply (ENNReal.div_le_iff hzero (inputNormProduct_ne_top μ hf)).mp
    exact le_iSup_of_le x (le_iSup_of_le f (le_iSup_of_le hf (le_iSup_of_le hadm le_rfl)))

theorem marginLocalConstant_le_of_bound {p R : ℝ} {B : ℝ≥0∞}
    (h : ∀ (x : Ambient n) (f : ∀ i, Ω i → ℂ), (∀ i, MemLp (f i) 2 (μ i)) →
      MarginAdmissible μ ζ U m R f →
      eLpNorm' (extensionProduct μ ζ f) p (volume.restrict (Metric.ball x R)) ≤
        B * inputNormProduct μ f) : marginLocalConstant μ ζ U m p R ≤ B := by
  refine iSup_le (fun x => iSup_le (fun f => iSup_le (fun hf => iSup_le (fun hadm => ?_))))
  exact ENNReal.div_le_of_le_mul (h x f hf hadm)

noncomputable def marginPowerConstant (p R : ℝ) : ℝ :=
  (marginLocalConstant μ ζ U m p R).toReal ^ p

/-- Bounded-scale initialization uses a fixed-patch majorant and needs no
monotonicity of the changing admissibility class. -/
theorem marginPowerConstant_locally_bounded [∀ i, IsFiniteMeasure (μ i)] {p : ℝ}
    (hp : 0 < p) : ∀ T : ℝ, 1 ≤ T → ∃ M : ℝ,
      ∀ R, 1 ≤ R → R ≤ T → marginPowerConstant μ ζ U m p R ≤ M := by
  intro T _
  refine ⟨localPowerConstant μ ζ p T, fun R _ hRT => ?_⟩
  apply Real.rpow_le_rpow ENNReal.toReal_nonneg _ hp.le
  exact ENNReal.toReal_mono (localConstant_ne_top μ ζ hp)
    ((marginLocalConstant_le_local μ ζ U m p R).trans (localConstant_mono μ ζ hp hRT))

/-- Proposition 8.1's recurrence obligation for the radius-dependent class.
It is a definition of a proposition, not an assumed axiom or a proved recurrence. -/
def MarginRecurrences (p : ℝ) : Prop :=
  ∀ ε : ℝ, 0 < ε → ∃ C D a τ : ℝ,
    0 < C ∧ 0 ≤ D ∧ a < ε * p ∧ 0 < τ ∧ τ < 1 / 2 ∧
    ∀ᶠ R : ℝ in Filter.atTop,
      marginPowerConstant μ ζ U m p R ≤
        1 / 4 * marginPowerConstant μ ζ U m p (R / 2) +
        C * marginPowerConstant μ ζ U m p (R ^ (1 - τ)) +
        C * marginPowerConstant μ ζ U m p (C * R ^ (1 / 2 + τ)) + D * R ^ a

/-- Scalar induction now applies directly to the article's margin constants. -/
theorem margin_constant_growth_of_recurrences [∀ i, IsFiniteMeasure (μ i)] {p : ℝ}
    (hp : 0 < p) (hrec : MarginRecurrences μ ζ U m p) :
    ∀ ε : ℝ, 0 < ε → ∃ C : ℝ, 0 ≤ C ∧ ∀ R, 1 ≤ R →
      (marginLocalConstant μ ζ U m p R).toReal ≤ C * R ^ ε := by
  intro ε hε
  obtain ⟨C, D, a, τ, hC, hD, ha, hτ, hτ', hr⟩ := hrec ε hε
  obtain ⟨K, hK, hb⟩ := power_recurrence_growth (marginPowerConstant μ ζ U m p) C D (ε * p) a τ
    hC hD (mul_pos hε hp) ha hτ hτ' (marginPowerConstant_locally_bounded μ ζ U m hp) hr
  exact ⟨K ^ (1 / p), Real.rpow_nonneg hK _,
    growth_from_power_bound (fun R => (marginLocalConstant μ ζ U m p R).toReal) hp hK
      (fun _ _ => ENNReal.toReal_nonneg) hb⟩

/-- The resulting local estimate for every radius-admissible input. -/
theorem margin_estimate_of_recurrences [∀ i, IsFiniteMeasure (μ i)] {p : ℝ}
    (hp : 0 < p) (hrec : MarginRecurrences μ ζ U m p) :
    ∀ ε : ℝ, 0 < ε → ∃ C : ℝ≥0, ∀ R, 2 ≤ R → ∀ (x : Ambient n)
      (f : ∀ i, Ω i → ℂ), (∀ i, MemLp (f i) 2 (μ i)) →
      MarginAdmissible μ ζ U m R f →
      eLpNorm' (extensionProduct μ ζ f) p (volume.restrict (Metric.ball x R)) ≤
        (C : ℝ≥0∞) * ENNReal.ofReal (R ^ ε) * inputNormProduct μ f := by
  intro ε hε
  obtain ⟨C, hC, hb⟩ := margin_constant_growth_of_recurrences μ ζ U m hp hrec ε hε
  refine ⟨⟨C, hC⟩, fun R hR x f hf hadm => ?_⟩
  have he := ENNReal.ofReal_le_ofReal (hb R (by linarith))
  rw [ENNReal.ofReal_toReal (marginLocalConstant_ne_top μ ζ U m hp),
    ENNReal.ofReal_mul hC, ENNReal.ofReal_eq_coe_nnreal hC] at he
  exact (marginLocalConstant_spec μ ζ U m hp x hf hadm).trans (mul_le_mul_right' he _)

/-- In particular, the original supports with margin m obey the local estimate. -/
theorem original_margin_estimate_of_recurrences [∀ i, IsFiniteMeasure (μ i)] {p : ℝ}
    (hp : 0 < p) (hrec : MarginRecurrences μ ζ U m p) :
    ∀ ε : ℝ, 0 < ε → ∃ C : ℝ≥0, ∀ R, 2 ≤ R → ∀ (x : Ambient n)
      (f : ∀ i, Ω i → ℂ), (∀ i, MemLp (f i) 2 (μ i)) →
      (∀ i, HasFrequencySupport (μ i) (ζ i) (marginRegion (U i) m) (f i)) →
      eLpNorm' (extensionProduct μ ζ f) p (volume.restrict (Metric.ball x R)) ≤
        (C : ℝ≥0∞) * ENNReal.ofReal (R ^ ε) * inputNormProduct μ f := by
  intro ε hε
  obtain ⟨C, hC⟩ := margin_estimate_of_recurrences μ ζ U m hp hrec ε hε
  exact ⟨C, fun R hR x f hf hmargin => hC R hR x f hf
    (original_margin_admissible μ ζ U m (by linarith) hmargin)⟩

end
end N2Restriction
