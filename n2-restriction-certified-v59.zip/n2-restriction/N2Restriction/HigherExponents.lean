import N2Restriction.LocalConstant

namespace N2Restriction
open MeasureTheory
open scoped ENNReal NNReal BigOperators

/-- Interpolation between a finite positive exponent (possibly below one)
and a pointwise bound, in the same norm convention as the main estimates. -/
theorem norm_interpolate_infinity {X : Type*} [MeasurableSpace X]
    {μ : Measure X} {F : X → ℂ} (hF : AEStronglyMeasurable F μ)
    {q p : ℝ} (hq : 0 < q) (hqp : q < p) {M : ℝ≥0∞}
    (hM : ∀ x, ‖F x‖ₑ ≤ M) :
    eLpNorm' F p μ ≤ M ^ (1 - q / p) * (eLpNorm' F q μ) ^ (q / p) := by
  have hp : 0 < p := hq.trans hqp
  have h := ENNReal.rpow_le_rpow
    (raise_exponent μ (fun x => ‖F x‖ₑ) hF.enorm hq.le hqp hM)
    (show 0 ≤ 1 / p by positivity)
  rw [ENNReal.mul_rpow_of_nonneg _ _ (by positivity), ← ENNReal.rpow_mul] at h
  have h₁ : (p - q) * (1 / p) = 1 - q / p := by field_simp
  have h₂ : (1 / q) * (q / p) = 1 / p := by field_simp
  rw [h₁] at h
  simpa only [eLpNorm'_eq_lintegral_enorm, ← ENNReal.rpow_mul, h₂] using h

/-- The data-norm factor has exponent exactly one after interpolation. -/
lemma interpolate_common_factor {A B P : ℝ≥0∞} {a b : ℝ}
    (ha : 0 ≤ a) (hb : 0 ≤ b) (hab : a + b = 1) :
    (A * P) ^ a * (B * P) ^ b = (A ^ a * B ^ b) * P := by
  rw [ENNReal.mul_rpow_of_nonneg _ _ ha, ENNReal.mul_rpow_of_nonneg _ _ hb]
  calc
    A ^ a * P ^ a * (B ^ b * P ^ b) = (A ^ a * B ^ b) * (P ^ a * P ^ b) := by ring
    _ = _ := by rw [← ENNReal.rpow_add_of_nonneg _ _ ha hb, hab, ENNReal.rpow_one]

section
variable {n k : ℕ} {Ω : Fin k → Type*} [∀ i, MeasurableSpace (Ω i)]
variable {μ : ∀ i, Measure (Ω i)} [∀ i, IsFiniteMeasure (μ i)]
variable {ζ : ∀ i, Ω i → Ambient n} (hζ : ∀ i, Measurable (ζ i))
include hζ

/-- Increasing the exponent preserves the actual local restriction estimate.
This proves the raising-exponent step using the L2-to-Linfinity bound, without
assuming that the input norm product is nonzero. -/
theorem LocalRestriction.mono_exponent {q p : ℝ} (hq : 0 < q) (hqp : q ≤ p)
    (h : LocalRestriction μ ζ q) : LocalRestriction μ ζ p := by
  rcases hqp.eq_or_lt with rfl | hqp
  · exact h
  have hp : 0 < p := hq.trans hqp
  let a := 1 - q / p
  let b := q / p
  have ha : 0 ≤ a := by dsimp [a]; exact sub_nonneg.mpr ((div_le_one hp).mpr hqp.le)
  have hb : 0 ≤ b := by dsimp [b]; positivity
  have hab : a + b = 1 := by dsimp [a, b]; ring
  intro ε hε
  obtain ⟨C, hC⟩ := h ε hε
  let K : ℝ≥0∞ := patchMassFactor μ ^ a * (C : ℝ≥0∞) ^ b
  have hK : K ≠ ⊤ := ENNReal.mul_ne_top
    (ENNReal.rpow_ne_top_of_nonneg ha (patchMassFactor_ne_top μ))
    (ENNReal.rpow_ne_top_of_nonneg hb ENNReal.coe_ne_top)
  refine ⟨K.toNNReal, fun R hR x f hf => ?_⟩
  have hRp : 0 < R := by linarith
  have hF := (continuous_extensionProduct hζ hf).aestronglyMeasurable
    (μ := volume.restrict (Metric.ball x R))
  calc
    eLpNorm' (extensionProduct μ ζ f) p (volume.restrict (Metric.ball x R)) ≤
        (patchMassFactor μ * inputNormProduct μ f) ^ a *
          (eLpNorm' (extensionProduct μ ζ f) q (volume.restrict (Metric.ball x R))) ^ b :=
      norm_interpolate_infinity hF hq hqp (extensionProduct_bound μ ζ hf)
    _ ≤ (patchMassFactor μ * inputNormProduct μ f) ^ a *
          ((C : ℝ≥0∞) * ENNReal.ofReal (R ^ ε) * inputNormProduct μ f) ^ b := by
      apply mul_le_mul_left'
      exact ENNReal.rpow_le_rpow (hC R hR x f hf) hb
    _ = K * ENNReal.ofReal (R ^ (ε * b)) * inputNormProduct μ f := by
      rw [interpolate_common_factor ha hb hab,
        ENNReal.mul_rpow_of_nonneg _ _ hb,
        ENNReal.ofReal_rpow_of_pos (Real.rpow_pos_of_pos hRp _), ← Real.rpow_mul hRp.le]
      dsimp [K]
      ring
    _ ≤ (K.toNNReal : ℝ≥0∞) * ENNReal.ofReal (R ^ ε) * inputNormProduct μ f := by
      rw [ENNReal.coe_toNNReal hK]
      apply mul_le_mul_right'
      apply mul_le_mul_left'
      apply ENNReal.ofReal_le_ofReal
      apply Real.rpow_le_rpow_of_exponent_le (by linarith)
      have hb1 : b ≤ 1 := by dsimp [b]; exact (div_le_one hp).mpr hqp.le
      nlinarith

/-- The same interpolation raises a global exponent once a global estimate
has been established. This does not supply epsilon removal. -/
theorem GlobalRestriction.mono_exponent {q p : ℝ} (hq : 0 < q) (hqp : q ≤ p)
    (h : GlobalRestriction μ ζ q) : GlobalRestriction μ ζ p := by
  rcases hqp.eq_or_lt with rfl | hqp
  · exact h
  have hp : 0 < p := hq.trans hqp
  let a := 1 - q / p
  let b := q / p
  have ha : 0 ≤ a := by dsimp [a]; exact sub_nonneg.mpr ((div_le_one hp).mpr hqp.le)
  have hb : 0 ≤ b := by dsimp [b]; positivity
  have hab : a + b = 1 := by dsimp [a, b]; ring
  obtain ⟨C, hC⟩ := h
  let K : ℝ≥0∞ := patchMassFactor μ ^ a * (C : ℝ≥0∞) ^ b
  have hK : K ≠ ⊤ := ENNReal.mul_ne_top
    (ENNReal.rpow_ne_top_of_nonneg ha (patchMassFactor_ne_top μ))
    (ENNReal.rpow_ne_top_of_nonneg hb ENNReal.coe_ne_top)
  refine ⟨K.toNNReal, fun f hf => ?_⟩
  rw [ENNReal.coe_toNNReal hK]
  calc
    eLpNorm' (extensionProduct μ ζ f) p volume ≤
        (patchMassFactor μ * inputNormProduct μ f) ^ a *
          (eLpNorm' (extensionProduct μ ζ f) q volume) ^ b :=
      norm_interpolate_infinity (continuous_extensionProduct hζ hf).aestronglyMeasurable
        hq hqp (extensionProduct_bound μ ζ hf)
    _ ≤ (patchMassFactor μ * inputNormProduct μ f) ^ a *
          ((C : ℝ≥0∞) * inputNormProduct μ f) ^ b :=
      mul_le_mul_left' (ENNReal.rpow_le_rpow (hC f hf) hb) _
    _ = K * inputNormProduct μ f := interpolate_common_factor ha hb hab

end
end N2Restriction
