import N2Restriction.ActualPacketEnergy
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap

namespace N2Restriction
open MeasureTheory
open scoped ENNReal NNReal

/-- divide a coordinate packet by a positive density to preserve its extension. -/
theorem extension_div_density {Ω : Type*} [MeasurableSpace Ω] {n : ℕ} (μ : Measure Ω)
    (J : Ω → ℝ≥0) (hJ : Measurable J) (hJ0 : ∀ᵐ x ∂μ, J x ≠ 0)
    (ζ : Ω → Ambient n) (g : Ω → ℂ) (y : Ambient n) :
    extension (μ.withDensity (fun x => (J x : ℝ≥0∞))) ζ (fun x => g x / (J x : ℂ)) y =
      extension μ ζ g y := by
  unfold extension
  rw [integral_withDensity_eq_integral_smul hJ]
  apply integral_congr_ae
  filter_upwards [hJ0] with x hx
  change (J x : ℂ) * (Complex.exp ((inner ℝ y (ζ x) : ℂ) * Complex.I) * (g x / (J x : ℂ))) = _
  have hz : (J x : ℂ) ≠ 0 := by exact_mod_cast hx
  field_simp

/-- exact inverse-density energy identity before transferring L2 classes. -/
theorem integral_sq_div_density {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (J : Ω → ℝ≥0) (hJ : Measurable J) (hJ0 : ∀ᵐ x ∂μ, J x ≠ 0) (g : Ω → ℂ) :
    (∫ x, ‖g x / (J x : ℂ)‖ ^ 2 ∂μ.withDensity (fun x => (J x : ℝ≥0∞))) =
      ∫ x, ‖g x‖ ^ 2 / (J x : ℝ) ∂μ := by
  rw [integral_withDensity_eq_integral_smul hJ]
  apply integral_congr_ae
  filter_upwards [hJ0] with x hx
  change (J x : ℝ) * ‖g x / (J x : ℂ)‖ ^ 2 = _
  rw [norm_div]
  have hn : ‖(J x : ℂ)‖ = (J x : ℝ) := by simp
  rw [hn]
  have hz : (J x : ℝ) ≠ 0 := by exact_mod_cast hx
  field_simp

/-- a positive lower density bound controls the inverse-density energy. -/
theorem integrable_div_density_energy {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (J : Ω → ℝ≥0) (hJ : Measurable J) {m : ℝ} (hm : 0 < m)
    (hmJ : ∀ᵐ x ∂μ, m ≤ (J x : ℝ)) (g : Ω → ℂ) (hg : MemLp g 2 μ) :
    Integrable (fun x => ‖g x‖ ^ 2 / (J x : ℝ)) μ ∧
      (∫ x, ‖g x‖ ^ 2 / (J x : ℝ) ∂μ) ≤ (1 / m) * ∫ x, ‖g x‖ ^ 2 ∂μ := by
  have hJr : Measurable (fun x => (J x : ℝ)) := by fun_prop
  have hi := (memLp_two_iff_integrable_sq_norm hg.aestronglyMeasurable).mp hg
  have hmeas : AEStronglyMeasurable (fun x => ‖g x‖ ^ 2 / (J x : ℝ)) μ :=
    ((hg.aestronglyMeasurable.norm.pow 2).aemeasurable.div hJr.aemeasurable).aestronglyMeasurable
  have hdom : ∀ᵐ x ∂μ, ‖‖g x‖ ^ 2 / (J x : ℝ)‖ ≤ (1 / m) * ‖g x‖ ^ 2 := by
    filter_upwards [hmJ] with x hx
    rw [Real.norm_eq_abs, abs_of_nonneg (div_nonneg (sq_nonneg _) (J x).coe_nonneg)]
    exact (div_le_div_of_nonneg_left (sq_nonneg ‖g x‖) hm hx).trans_eq (by ring)
  have hInt := (hi.const_mul (1 / m)).mono' hmeas hdom
  refine ⟨hInt, ?_⟩
  rw [← integral_const_mul]
  apply integral_mono_ae hInt (hi.const_mul (1 / m))
  filter_upwards [hdom] with x hx
  exact (le_abs_self _).trans (by simpa only [Real.norm_eq_abs] using hx)

/-- inverse-density packets actually belong to the weighted L2 space. -/
theorem memLp_div_density {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (J : Ω → ℝ≥0) (hJ : Measurable J) {m : ℝ} (hm : 0 < m)
    (hmJ : ∀ᵐ x ∂μ, m ≤ (J x : ℝ)) (g : Ω → ℂ) (hg : MemLp g 2 μ) :
    MemLp (fun x => g x / (J x : ℂ)) 2 (μ.withDensity (fun x => (J x : ℝ≥0∞))) := by
  have hBudget := integrable_div_density_energy μ J hJ hm hmJ g hg
  have hJc : Measurable (fun x => (J x : ℂ)) := by fun_prop
  have hmeas : AEStronglyMeasurable (fun x => g x / (J x : ℂ)) μ :=
    (hg.aestronglyMeasurable.aemeasurable.div hJc.aemeasurable).aestronglyMeasurable
  have hmeas' := hmeas.mono_ac (withDensity_absolutelyContinuous μ (fun x => (J x : ℝ≥0∞)))
  apply (memLp_two_iff_integrable_sq_norm hmeas').mpr
  rw [integrable_withDensity_iff_integrable_smul hJ]
  apply hBudget.1.congr
  filter_upwards [hmJ] with x hx
  change ‖g x‖ ^ 2 / (J x : ℝ) = (J x : ℝ) * ‖g x / (J x : ℂ)‖ ^ 2
  rw [norm_div]
  have hn : ‖(J x : ℂ)‖ = (J x : ℝ) := by simp
  rw [hn]
  have hz : (J x : ℝ) ≠ 0 := ne_of_gt (hm.trans_le hx)
  field_simp

end N2Restriction
