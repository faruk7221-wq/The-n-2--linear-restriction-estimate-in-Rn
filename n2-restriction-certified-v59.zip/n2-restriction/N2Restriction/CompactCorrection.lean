import N2Restriction.LocalCorrection

namespace N2Restriction
open Filter

/-- Compactness upgrades local residual-to-distance estimates to one uniform
constant and one residual threshold, including points away from the zero set. -/
theorem compact_uniform_correction_rel {E : Type*} [PseudoMetricSpace E]
    {K Z : Set E} {Rel : E → E → Prop} (hK : IsCompact K) {ρ : E → ℝ} (hρ : ContinuousOn ρ K)
    (hnonneg : ∀ x, 0 ≤ ρ x)
    (hlocal : ∀ z ∈ K, ρ z = 0 → ∃ C : ℝ, 0 ≤ C ∧
      ∀ᶠ x in nhdsWithin z K, ∃ y ∈ Z, Rel x y ∧ dist x y ≤ C * ρ x) :
    ∃ δ C : ℝ, 0 < δ ∧ 0 ≤ C ∧
      ∀ x ∈ K, ρ x < δ → ∃ y ∈ Z, Rel x y ∧ dist x y ≤ C * ρ x := by
  let P : Set E → Prop := fun T => ∃ δ C : ℝ, 0 < δ ∧ 0 ≤ C ∧
    ∀ x ∈ T, ρ x < δ → ∃ y ∈ Z, Rel x y ∧ dist x y ≤ C * ρ x
  change P K
  refine IsCompact.induction_on hK (p := P) ?_ ?_ ?_ ?_
  · exact ⟨1, 0, by norm_num, le_rfl, by simp⟩
  · intro s t hst ht
    obtain ⟨δ, C, hδ, hC, hb⟩ := ht
    exact ⟨δ, C, hδ, hC, fun x hx => hb x (hst hx)⟩
  · intro s t hs ht
    obtain ⟨δ₁, C₁, hδ₁, hC₁, hb₁⟩ := hs
    obtain ⟨δ₂, C₂, hδ₂, hC₂, hb₂⟩ := ht
    refine ⟨min δ₁ δ₂, max C₁ C₂, lt_min hδ₁ hδ₂, hC₁.trans (le_max_left _ _), ?_⟩
    intro x hx hsmall
    rcases hx with hx | hx
    · obtain ⟨y, hy, hrel, hd⟩ := hb₁ x hx (hsmall.trans_le (min_le_left _ _))
      exact ⟨y, hy, hrel, hd.trans (mul_le_mul_of_nonneg_right (le_max_left _ _) (hnonneg x))⟩
    · obtain ⟨y, hy, hrel, hd⟩ := hb₂ x hx (hsmall.trans_le (min_le_right _ _))
      exact ⟨y, hy, hrel, hd.trans (mul_le_mul_of_nonneg_right (le_max_right _ _) (hnonneg x))⟩
  · intro z hz
    by_cases hzero : ρ z = 0
    · obtain ⟨C, hC, hc⟩ := hlocal z hz hzero
      refine ⟨{x | ∃ y ∈ Z, Rel x y ∧ dist x y ≤ C * ρ x}, hc, 1, C, by norm_num, hC, ?_⟩
      exact fun _ hx _ => hx
    · have hp : 0 < ρ z := lt_of_le_of_ne (hnonneg z) (Ne.symm hzero)
      have hn : {x | ρ z / 2 < ρ x} ∈ nhdsWithin z K :=
        (hρ z hz).eventually (lt_mem_nhds (by linarith : ρ z / 2 < ρ z))
      refine ⟨_, hn, ρ z / 2, 0, by positivity, le_rfl, ?_⟩
      intro x hx hsmall
      exact False.elim (not_lt_of_ge hx.le hsmall)

/-- The compact correction theorem when no additional witness relation is needed. -/
theorem compact_uniform_correction {E : Type*} [PseudoMetricSpace E]
    {K Z : Set E} (hK : IsCompact K) {ρ : E → ℝ} (hρ : ContinuousOn ρ K)
    (hnonneg : ∀ x, 0 ≤ ρ x)
    (hlocal : ∀ z ∈ K, ρ z = 0 → ∃ C : ℝ, 0 ≤ C ∧
      ∀ᶠ x in nhdsWithin z K, ∃ y ∈ Z, dist x y ≤ C * ρ x) :
    ∃ δ C : ℝ, 0 < δ ∧ 0 ≤ C ∧
      ∀ x ∈ K, ρ x < δ → ∃ y ∈ Z, dist x y ≤ C * ρ x := by
  simpa only [true_and] using compact_uniform_correction_rel (Rel := fun _ _ => True)
    hK hρ hnonneg (by simpa only [true_and] using hlocal)

/-- Uniform version of (4.1) on a compact surface subset for a fixed plane H.
Regularity is needed only at zeros. The conclusion also handles points that
are not themselves near a preselected zero. Uniformity as H varies remains separate. -/
theorem compact_thin_support_correction {n : ℕ} (S : SmoothPatch n)
    (H : Submodule ℝ (Ambient n)) {K : Set (Ambient n)} (hK : IsCompact K)
    (hKS : K ⊆ S.extendedSurface)
    (hreg : ∀ z ∈ K, H.orthogonalProjection (S.normal z) = 0 →
      Function.Surjective (thinDifferential S H z)) :
    ∃ δ C : ℝ, 0 < δ ∧ 0 ≤ C ∧ ∀ x ∈ K,
      ‖H.orthogonalProjection (S.normal x)‖ < δ →
      ∃ y ∈ S.extendedSurface, H.orthogonalProjection (S.normal y) = 0 ∧
        dist x y ≤ C * ‖H.orthogonalProjection (S.normal x)‖ := by
  have hc : ContinuousOn (fun x => ‖H.orthogonalProjection (S.normal x)‖) K :=
    (H.orthogonalProjection.continuous.comp_continuousOn
      (S.smooth_normal.continuousOn.mono (fun _ hx => (hKS hx).1))).norm
  have hu := compact_uniform_correction (Z :=
    {y | y ∈ S.extendedSurface ∧ H.orthogonalProjection (S.normal y) = 0})
    hK hc (fun _ => norm_nonneg _) ?_
  · obtain ⟨δ, C, hδ, hC, hb⟩ := hu
    refine ⟨δ, C, hδ, hC, fun x hx hsmall => ?_⟩
    obtain ⟨y, ⟨hy, hzero⟩, hd⟩ := hb x hx hsmall
    exact ⟨y, hy, hzero, hd⟩
  · intro z hz hzero
    have hzero' := norm_eq_zero.mp hzero
    have hds := S.smooth_defining.contDiffAt (S.open_neighborhood.mem_nhds (hKS hz).1)
    have hns := S.smooth_normal.contDiffAt (S.open_neighborhood.mem_nhds (hKS hz).1)
    have hs : ContDiffAt ℝ (⊤ : ℕ∞) (thinConstraint S H) z :=
      hds.prodMk (H.orthogonalProjection.contDiff.contDiffAt.comp z hns)
    have hd := hs.hasStrictFDerivAt' (hasFDerivAt_thinConstraint S H (hKS hz).1) (by simp)
    obtain ⟨C, hC, hb⟩ := submersion_level_correction hd (hreg z hz hzero')
      (S.open_neighborhood.mem_nhds (hKS hz).1)
    refine ⟨C, hC, ?_⟩
    filter_upwards [mem_nhdsWithin_of_mem_nhds hb, self_mem_nhdsWithin] with x hx hxK
    obtain ⟨y, hy, heq, hdist⟩ := hx
    have hfy : S.defining y = 0 := (congrArg Prod.fst heq).trans (hKS hz).2
    have hny : H.orthogonalProjection (S.normal y) = 0 := (congrArg Prod.snd heq).trans hzero'
    refine ⟨y, ⟨⟨hy, hfy⟩, hny⟩, ?_⟩
    simpa [thinConstraint, Prod.dist_eq, (hKS hxK).2, (hKS hz).2, hzero'] using hdist

end N2Restriction
