import N2Restriction.ActualGraphPackets

namespace N2Restriction
open MeasureTheory

/-- Ordinary complex L2 norm expressed as a real integral. -/
theorem complex_L2_norm_sq {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω) (f : Lp ℂ 2 μ) :
    ‖f‖ ^ 2 = ∫ x, ‖f x‖ ^ 2 ∂μ := by
  have h := inner_self_eq_norm_sq_to_K (𝕜 := ℂ) f
  rw [L2.inner_def] at h
  simp only [inner_self_eq_norm_sq_to_K] at h
  exact_mod_cast h.symm

/-- The fixed energy of the concrete reference cutoff. -/
noncomputable def packetCutoffEnergy (d : ℕ) : ℝ := ∫ η, ‖packetCutoff d η‖ ^ 2

theorem packetCutoffEnergy_pos (d : ℕ) : 0 < packetCutoffEnergy d := by
  apply ((packetCutoff_smooth d).continuous.norm.pow 2).integral_pos_of_hasCompactSupport_nonneg_nonzero (x := 0)
  · simpa only [pow_two] using (packetCutoff_compact d).norm.mul_right (f' := fun η => ‖packetCutoff d η‖)
  · intro η
    exact sq_nonneg _
  · have hz : referenceBump d (0 : Ambient d) = 1 :=
      (referenceBump d).one_of_mem_closedBall (by simp [referenceBump])
    simp [packetCutoff, hz]

/-- Every normalized graph atom has exactly the same positive L2 energy. -/
theorem graphAtomL2_energy {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r) (ν : Fin d → ℤ) :
    ‖graphAtomL2 c r hr ν‖ ^ 2 = packetCutoffEnergy d := by
  rw [complex_L2_norm_sq]
  calc
    _ = ∫ ξ, ‖graphAtom (packetCutoff d) c r (r⁻¹ • latticeVector ν) ξ‖ ^ 2 := by
      apply integral_congr_ae
      filter_upwards [graphAtomL2_coe c r hr ν] with ξ hξ
      rw [hξ]
    _ = _ := graphAtom_L2_mass (packetCutoff d) c hr _

/-- Each actual packet energy is precisely the original coefficient energy
multiplied by a fixed positive cutoff energy. -/
theorem actualPacketInput_energy {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume.restrict (packetFrequencyCube c r hr))) (ν : Fin d → ℤ) :
    ‖actualPacketInput c r hr f ν‖ ^ 2 = packetCutoffEnergy d * ‖actualPacketCoeff c r hr f ν‖ ^ 2 := by
  rw [actualPacketInput, norm_smul, mul_pow, graphAtomL2_energy, mul_comm]

/-- Exact per-cap total packet energy in terms of the actual original input. -/
theorem actualPacketInput_total_energy {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume.restrict (packetFrequencyCube c r hr))) :
    (∑' ν, ‖actualPacketInput c r hr f ν‖ ^ 2) =
      packetCutoffEnergy d * (2 * Real.pi) ^ (-(d : ℝ)) * ‖f‖ ^ 2 := by
  simp_rw [actualPacketInput_energy]
  rw [tsum_mul_left, actualPacketCoeff_energy, mul_assoc]

/-- Packet energy summability is proved, not inferred from a totalized infinite sum. -/
theorem actualPacketInput_energy_summable {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume.restrict (packetFrequencyCube c r hr))) :
    Summable (fun ν => ‖actualPacketInput c r hr f ν‖ ^ 2) := by
  simpa only [actualPacketInput_energy] using
    (actualPacketCoeff_summable c r hr f).mul_left (packetCutoffEnergy d)

/-- Compact frequency support of the actual packet is the cap of radius 2r. -/
theorem actualPacketInput_support {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume.restrict (packetFrequencyCube c r hr))) (ν : Fin d → ℤ) :
    HasFrequencySupport volume id (Metric.ball c (2 * r)) (actualPacketInput c r hr f ν) := by
  filter_upwards [actualPacketInput_coe c r hr f ν] with ξ hξ hn
  change dist ξ c < 2 * r
  by_contra h
  apply hn
  rw [hξ]
  simp only [graphAtom, packetCutoff]
  rw [← frequencyBump_rescale c hr, (frequencyBump c r hr).zero_of_le_dist (le_of_not_gt h)]
  simp

end N2Restriction
