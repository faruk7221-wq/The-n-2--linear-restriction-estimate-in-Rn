import N2Restriction.RegularGraphCover
import N2Restriction.SurfaceGraphMargins

namespace N2Restriction
open MeasureTheory Set Filter

/-- A compact subset of an open frequency domain has a positive ambient margin. -/
theorem compact_subset_positive_margin {n : ℕ} {K U : Set (Ambient n)}
    (hK : IsCompact K) (hU : IsOpen U) (hKU : K ⊆ U) :
    ∃ δ : ℝ, 0 < δ ∧ K ⊆ marginRegion U δ := by
  obtain ⟨δ, hδ, hsub⟩ := hK.exists_cthickening_subset_open hU hKU
  refine ⟨δ, hδ, ?_⟩
  intro x hx y hy
  apply le_of_not_gt
  intro hdist
  apply hy
  apply hsub
  apply Metric.mem_cthickening_of_dist_le y x δ K hx
  simpa only [dist_comm] using hdist.le

/-- The constructed finite graph cover has one positive ambient margin inside the fixed extension. -/
theorem SmoothPatch.exists_buffered_graph_cover {d : ℕ} (S : SmoothPatch (d + 1)) :
    ∃ (m : ℕ) (P : Fin m → LocalGraphPatch d) (δ : ℝ), 0 < δ ∧
      (S.support ⊆ ⋃ j, (P j).carrier) ∧
      ∀ j, (P j).carrier ⊆ S.extendedSurface ∩ marginRegion S.neighborhood δ := by
  obtain ⟨m, P, hcover, hinside, _⟩ := S.exists_finite_graph_cover
  have hc : IsCompact (⋃ j, (P j).carrier) := isCompact_iUnion (fun j => (P j).compact_carrier)
  have hU : (⋃ j, (P j).carrier) ⊆ S.neighborhood := by
    intro x hx
    obtain ⟨j, hj⟩ := mem_iUnion.mp hx
    exact (hinside j hj).1
  obtain ⟨δ, hδ, hm⟩ := compact_subset_positive_margin hc S.open_neighborhood hU
  exact ⟨m, P, δ, hδ, hcover, fun j x hx => ⟨hinside j hx, hm (mem_iUnion.mpr ⟨j, hx⟩)⟩⟩

end N2Restriction
