import N2Restriction.ThinNormalSpace

namespace N2Restriction

set_option maxHeartbeats 800000

/-- The reverse compression H to W is coercive as well. Symmetry transfers
the W-to-H inverse bound to this map, as required after (4.2). -/
theorem nearby_reverse_shape_coercive {n : ℕ} (S : SmoothPatch n)
    (W H : Submodule ℝ (Ambient n)) (hdim : Module.finrank ℝ W = Module.finrank ℝ H)
    {z : Ambient n} (hz : z ∈ S.neighborhood)
    (hzero : H.orthogonalProjection (S.normal z) = 0)
    (hW : ∀ v : W, inner ℝ (S.normal z) (v : Ambient n) = 0)
    {κ : ℝ} (hκ : 0 < κ)
    (hA : ∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (S.shape z v)‖)
    (hgap : ‖W.starProjection - H.starProjection‖ * ‖S.shape z‖ ≤ κ / 2) :
    ∀ h : H, (κ / 2) * ‖h‖ ≤ ‖W.orthogonalProjection (S.shape z h)‖ := by
  obtain ⟨J, hJ, _, hnorm⟩ := nearby_projected_shape_inverse W H hdim (S.shape z) hκ hA hgap
  have hsolve (h : H) : H.orthogonalProjection (S.shape z (J h)) = h :=
    congrArg (fun L : H →L[ℝ] H => L h) hJ
  intro h
  have hi : inner ℝ (W.orthogonalProjection (S.shape z h)) (J h) = ‖h‖ ^ 2 := by
    rw [W.inner_orthogonalProjection_eq_of_mem_right]
    rw [S.shape_symmetric_tangent hz h (J h)
      (plane_tangent_of_projected_normal_zero S H hzero h) (hW (J h))]
    rw [← H.inner_orthogonalProjection_eq_of_mem_left, hsolve, real_inner_self_eq_norm_sq]
  have hb : ‖J h‖ ≤ (2 / κ) * ‖h‖ :=
    (J.le_opNorm h).trans (mul_le_mul_of_nonneg_right hnorm (norm_nonneg _))
  have hc : ‖h‖ ^ 2 ≤ ‖W.orthogonalProjection (S.shape z h)‖ * ((2 / κ) * ‖h‖) := by
    calc
      ‖h‖ ^ 2 = inner ℝ (W.orthogonalProjection (S.shape z h)) (J h) := hi.symm
      _ ≤ ‖W.orthogonalProjection (S.shape z h)‖ * ‖J h‖ := real_inner_le_norm _ _
      _ ≤ _ := mul_le_mul_of_nonneg_left hb (norm_nonneg _)
  by_cases hh : h = 0
  · simp [hh]
  have hhpos : 0 < ‖h‖ := norm_pos_iff.mpr hh
  have hh' : ‖h‖ ≤ ‖W.orthogonalProjection (S.shape z h)‖ * (2 / κ) := by
    nlinarith
  have hm := mul_le_mul_of_nonneg_right hh' hκ.le
  field_simp [hκ.ne'] at hm
  nlinarith

/-- A quantitative inverse for the reverse projected shape map H to W. -/
theorem nearby_reverse_shape_inverse {n : ℕ} (S : SmoothPatch n)
    (W H : Submodule ℝ (Ambient n)) (hdim : Module.finrank ℝ W = Module.finrank ℝ H)
    {z : Ambient n} (hz : z ∈ S.neighborhood)
    (hzero : H.orthogonalProjection (S.normal z) = 0)
    (hW : ∀ v : W, inner ℝ (S.normal z) (v : Ambient n) = 0)
    {κ : ℝ} (hκ : 0 < κ)
    (hA : ∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (S.shape z v)‖)
    (hgap : ‖W.starProjection - H.starProjection‖ * ‖S.shape z‖ ≤ κ / 2) :
    ∃ B : W →L[ℝ] H,
      (W.orthogonalProjection.comp ((S.shape z).comp H.subtypeL)).comp B = ContinuousLinearMap.id ℝ W ∧
      B.comp (W.orthogonalProjection.comp ((S.shape z).comp H.subtypeL)) = ContinuousLinearMap.id ℝ H ∧
      ‖B‖ ≤ 2 / κ := by
  obtain ⟨B, h₁, h₂, hB⟩ := inverse_between_equal_dimensions
    (W.orthogonalProjection.comp ((S.shape z).comp H.subtypeL)) hdim.symm
    (by positivity : 0 < κ / 2)
    (nearby_reverse_shape_coercive S W H hdim hz hzero hW hκ hA hgap)
  exact ⟨B, h₁, h₂, by simpa [div_eq_mul_inv, mul_comm] using hB⟩

/-- Quantitative decomposition using the actual perturbed shape image A(H). -/
theorem nearby_shape_decomposition {n : ℕ} (S : SmoothPatch n)
    (W H : Submodule ℝ (Ambient n)) (hdim : Module.finrank ℝ W = Module.finrank ℝ H)
    {z : Ambient n} (hz : z ∈ S.neighborhood)
    (hzero : H.orthogonalProjection (S.normal z) = 0)
    (hW : ∀ v : W, inner ℝ (S.normal z) (v : Ambient n) = 0)
    {κ : ℝ} (hκ : 0 < κ)
    (hA : ∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (S.shape z v)‖)
    (hgap : ‖W.starProjection - H.starProjection‖ * ‖S.shape z‖ ≤ κ / 2)
    (x : Ambient n) :
    ∃ h : H, x - S.shape z h ∈ Wᗮ ∧ ‖h‖ ≤ (2 / κ) * ‖x‖ := by
  obtain ⟨B, hright, _, hB⟩ := nearby_reverse_shape_inverse S W H hdim hz hzero hW hκ hA hgap
  let h := B (W.orthogonalProjection x)
  have hproj : W.orthogonalProjection (S.shape z h) = W.orthogonalProjection x :=
    congrArg (fun L : W →L[ℝ] W => L (W.orthogonalProjection x)) hright
  refine ⟨h, ?_, ?_⟩
  · apply Submodule.orthogonalProjection_eq_zero_iff.mp
    rw [map_sub, hproj, sub_self]
  · calc
      ‖h‖ ≤ ‖B‖ * ‖W.orthogonalProjection x‖ := B.le_opNorm _
      _ ≤ (2 / κ) * ‖x‖ := mul_le_mul hB (W.norm_orthogonalProjection_apply_le x)
        (norm_nonneg _) (by positivity)

/-- The shape image of a nearby tangent plane complements the original normal span. -/
theorem nearby_shape_transversality {n : ℕ} (S : SmoothPatch n)
    (W H : Submodule ℝ (Ambient n)) (hdim : Module.finrank ℝ W = Module.finrank ℝ H)
    {z : Ambient n} (hz : z ∈ S.neighborhood)
    (hzero : H.orthogonalProjection (S.normal z) = 0)
    (hW : ∀ v : W, inner ℝ (S.normal z) (v : Ambient n) = 0)
    {κ : ℝ} (hκ : 0 < κ)
    (hA : ∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (S.shape z v)‖)
    (hgap : ‖W.starProjection - H.starProjection‖ * ‖S.shape z‖ ≤ κ / 2) :
    Disjoint Wᗮ (H.map (S.shape z).toLinearMap) ∧
      Wᗮ ⊔ H.map (S.shape z).toLinearMap = ⊤ := by
  constructor
  · rw [Submodule.disjoint_def]
    intro x hx hxA
    obtain ⟨h, hh, hAh⟩ := Submodule.mem_map.mp hxA
    change S.shape z h = x at hAh
    have hzero' : W.orthogonalProjection (S.shape z h) = 0 := by
      rw [hAh]
      exact Submodule.orthogonalProjection_eq_zero_iff.mpr hx
    have hc := nearby_reverse_shape_coercive S W H hdim hz hzero hW hκ hA hgap ⟨h, hh⟩
    change (κ / 2) * ‖h‖ ≤ ‖W.orthogonalProjection (S.shape z h)‖ at hc
    rw [hzero', norm_zero] at hc
    have hh0 : h = 0 := norm_eq_zero.mp (by nlinarith [norm_nonneg h])
    simpa [hh0] using hAh.symm
  · apply top_unique
    intro x _
    obtain ⟨h, hh, _⟩ := nearby_shape_decomposition S W H hdim hz hzero hW hκ hA hgap x
    exact Submodule.mem_sup.mpr ⟨x - S.shape z h, hh, S.shape z h,
      Submodule.mem_map.mpr ⟨h, h.property, rfl⟩, sub_add_cancel _ _⟩

/-- Nearby-plane transversality under the article's actual curvature hypotheses. -/
theorem geometric_nearby_normal_transversality {k : ℕ} (S : Fin k → SmoothPatch (k + 2))
    {ν κ : ℝ} (hgeo : GeometricHypotheses S ν κ)
    (z : Fin k → Ambient (k + 2)) (hz : ∀ i, z i ∈ (S i).extendedSurface) (i : Fin k)
    (H : Submodule ℝ (Ambient (k + 2)))
    (hdim : Module.finrank ℝ (commonTangent (fun j => (S j).normal (z j))) = Module.finrank ℝ H)
    (hzero : H.orthogonalProjection ((S i).normal (z i)) = 0)
    (hgap : ‖(commonTangent (fun j => (S j).normal (z j))).starProjection - H.starProjection‖ *
      ‖(S i).shape (z i)‖ ≤ κ / 2) :
    let V := Submodule.span ℝ (Set.range (fun j => (S j).normal (z j)))
    Disjoint V (H.map ((S i).shape (z i)).toLinearMap) ∧
      V ⊔ H.map ((S i).shape (z i)).toLinearMap = ⊤ := by
  simpa [commonTangent] using nearby_shape_transversality (S i)
    (commonTangent (fun j => (S j).normal (z j))) H hdim (hz i).1 hzero
    (fun v => commonTangent_orthogonal _ v i) hgeo.2.1 ((hgeo.2.2 z hz).2 i) hgap

end N2Restriction
