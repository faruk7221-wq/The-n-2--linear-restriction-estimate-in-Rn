import N2Restriction.HilbertPackets

namespace N2Restriction
open scoped ENNReal
variable {ι E F : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E]
  [NormedAddCommGroup F] [NormedSpace ℂ F] [CompleteSpace F]

/-- Cauchy-Schwarz for coefficient-weight products gives absolute summability.
The spatial decay analysis must provide the square-summable weight. -/
theorem packet_weight_summable (b : HilbertBasis ι ℂ E) (x : E)
    (w : lp (fun _ : ι => ℂ) 2) :
    Summable (fun i => ‖b.repr x i‖ * ‖w i‖) := by
  exact lp.summable_mul (by simpa using Real.HolderConjugate.two_two : (2 : ENNReal).toReal.HolderConjugate
    (2 : ENNReal).toReal) (b.repr x) w

/-- Uniform absolute tail budget for every selected coefficient set. -/
theorem packet_weight_selection (b : HilbertBasis ι ℂ E) (x : E)
    (w : lp (fun _ : ι => ℂ) 2) (S : Set ι) :
    (∑' i : S, ‖b.repr x i‖ * ‖w i‖) ≤ ‖x‖ * ‖w‖ := by
  have h := lp.tsum_mul_le_mul_norm
    (by simpa using Real.HolderConjugate.two_two : (2 : ENNReal).toReal.HolderConjugate (2 : ENNReal).toReal) (b.repr x) w
  exact (Summable.tsum_subtype_le _ S
    (fun _ => mul_nonneg (norm_nonneg _) (norm_nonneg _)) h.1).trans (by simpa using h.2)

omit [NormedSpace ℂ F] [CompleteSpace F] in
/-- A pointwise packet error dominated by coefficient times an l2 weight has
an absolutely summable norm family. This is valid before selecting packets. -/
theorem packet_error_norm_summable (b : HilbertBasis ι ℂ E) (x : E)
    (w : lp (fun _ : ι => ℂ) 2) (r : ι → F) {δ : ℝ} 
    (hr : ∀ i, ‖r i‖ ≤ δ * (‖b.repr x i‖ * ‖w i‖)) :
    Summable (fun i => ‖r i‖) :=
  Summable.of_nonneg_of_le (fun _ => norm_nonneg _) hr
    ((packet_weight_summable b x w).mul_left δ)

omit [NormedSpace ℂ F] [CompleteSpace F] in
/-- Absolute selected tails are bounded uniformly in the selection, including
infinite selections. A rapid-decay factor can be substituted for δ. -/
theorem packet_error_absolute_tail (b : HilbertBasis ι ℂ E) (x : E)
    (w : lp (fun _ : ι => ℂ) 2) (r : ι → F) {δ : ℝ} (hδ : 0 ≤ δ)
    (hr : ∀ i, ‖r i‖ ≤ δ * (‖b.repr x i‖ * ‖w i‖)) (S : Set ι) :
    (∑' i : S, ‖r i‖) ≤ δ * ‖x‖ * ‖w‖ := by
  have hs := (packet_error_norm_summable b x w r hr).subtype S
  have hw := (packet_weight_summable b x w).subtype S
  calc
    (∑' i : S, ‖r i‖) ≤ ∑' i : S, δ * (‖b.repr x i‖ * ‖w i‖) :=
      hs.tsum_le_tsum (fun i => hr i) (hw.mul_left δ)
    _ = δ * ∑' i : S, ‖b.repr x i‖ * ‖w i‖ := hw.tsum_mul_left δ
    _ ≤ δ * (‖x‖ * ‖w‖) := mul_le_mul_of_nonneg_left (packet_weight_selection b x w S) hδ
    _ = δ * ‖x‖ * ‖w‖ := (mul_assoc _ _ _).symm

omit [NormedSpace ℂ F] in
/-- The norm of the selected error series is bounded by the absolute tail. -/
theorem packet_error_synthesis (b : HilbertBasis ι ℂ E) (x : E)
    (w : lp (fun _ : ι => ℂ) 2) (r : ι → F) {δ : ℝ} (hδ : 0 ≤ δ)
    (hr : ∀ i, ‖r i‖ ≤ δ * (‖b.repr x i‖ * ‖w i‖)) (S : Set ι) :
    Summable (fun i : S => r i) ∧ ‖∑' i : S, r i‖ ≤ δ * ‖x‖ * ‖w‖ := by
  have hs := (packet_error_norm_summable b x w r hr).subtype S
  exact ⟨hs.of_norm, (norm_tsum_le_tsum_norm hs).trans
    (packet_error_absolute_tail b x w r hδ hr S)⟩

end N2Restriction
