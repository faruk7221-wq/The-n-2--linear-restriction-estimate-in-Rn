import N2Restriction.FourierPackets

/-! Actual multiplication by a bounded measurable cutoff on L2. The equalities
are almost-everywhere statements, so they do not depend on representatives. -/
namespace N2Restriction
open MeasureTheory
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω}

theorem cutoff_memLp (χ : Ω → ℂ) (hχ : AEStronglyMeasurable χ μ)
    {C : ℝ} (hC : ∀ᵐ x ∂μ, ‖χ x‖ ≤ C) (f : Lp ℂ 2 μ) :
    MemLp (fun x => χ x * f x) 2 μ := by
  apply (Lp.memLp f).of_le_mul (c := C) (hχ.mul (Lp.memLp f).aestronglyMeasurable)
  filter_upwards [hC] with x hx
  simpa only [Pi.mul_apply, norm_mul] using mul_le_mul_of_nonneg_right hx (norm_nonneg (f x))

noncomputable def cutoffL2 (χ : Ω → ℂ) (hχ : AEStronglyMeasurable χ μ)
    {C : ℝ} (hC : ∀ᵐ x ∂μ, ‖χ x‖ ≤ C) (f : Lp ℂ 2 μ) : Lp ℂ 2 μ :=
  (cutoff_memLp χ hχ hC f).toLp (fun x => χ x * f x)

theorem cutoffL2_coe (χ : Ω → ℂ) (hχ : AEStronglyMeasurable χ μ)
    {C : ℝ} (hC : ∀ᵐ x ∂μ, ‖χ x‖ ≤ C) (f : Lp ℂ 2 μ) :
    cutoffL2 χ hχ hC f =ᵐ[μ] fun x => χ x * f x :=
  MemLp.coeFn_toLp _

theorem cutoffL2_add (χ : Ω → ℂ) (hχ : AEStronglyMeasurable χ μ)
    {C : ℝ} (hC : ∀ᵐ x ∂μ, ‖χ x‖ ≤ C) (f g : Lp ℂ 2 μ) :
    cutoffL2 χ hχ hC (f + g) = cutoffL2 χ hχ hC f + cutoffL2 χ hχ hC g := by
  apply Lp.ext
  filter_upwards [cutoffL2_coe χ hχ hC (f + g), cutoffL2_coe χ hχ hC f,
    cutoffL2_coe χ hχ hC g, Lp.coeFn_add f g,
    Lp.coeFn_add (cutoffL2 χ hχ hC f) (cutoffL2 χ hχ hC g)] with x h₁ h₂ h₃ h₄ h₅
  simp only [h₁, h₂, h₃, h₄, h₅, Pi.add_apply, mul_add]

theorem cutoffL2_smul (χ : Ω → ℂ) (hχ : AEStronglyMeasurable χ μ)
    {C : ℝ} (hC : ∀ᵐ x ∂μ, ‖χ x‖ ≤ C) (c : ℂ) (f : Lp ℂ 2 μ) :
    cutoffL2 χ hχ hC (c • f) = c • cutoffL2 χ hχ hC f := by
  apply Lp.ext
  filter_upwards [cutoffL2_coe χ hχ hC (c • f), cutoffL2_coe χ hχ hC f,
    Lp.coeFn_smul c f, Lp.coeFn_smul c (cutoffL2 χ hχ hC f)] with x h₁ h₂ h₃ h₄
  simp only [h₁, h₂, h₃, h₄, Pi.smul_apply, smul_eq_mul]
  ring

theorem cutoffL2_norm_le (χ : Ω → ℂ) (hχ : AEStronglyMeasurable χ μ)
    {C : ℝ} (hC : ∀ᵐ x ∂μ, ‖χ x‖ ≤ C) (f : Lp ℂ 2 μ) :
    ‖cutoffL2 χ hχ hC f‖ ≤ C * ‖f‖ := by
  apply Lp.norm_le_mul_norm_of_ae_le_mul
  filter_upwards [cutoffL2_coe χ hχ hC f, hC] with x hx hcx
  rw [hx, norm_mul]
  exact mul_le_mul_of_nonneg_right hcx (norm_nonneg _)

/-- The concrete bounded synthesis operator used for cutoff Fourier atoms. -/
noncomputable def cutoffOperator (χ : Ω → ℂ) (hχ : AEStronglyMeasurable χ μ)
    {C : ℝ} (hC : ∀ᵐ x ∂μ, ‖χ x‖ ≤ C) : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ :=
  LinearMap.mkContinuous
    { toFun := cutoffL2 χ hχ hC
      map_add' := cutoffL2_add χ hχ hC
      map_smul' := cutoffL2_smul χ hχ hC }
    C (cutoffL2_norm_le χ hχ hC)

theorem cutoffOperator_norm_le (χ : Ω → ℂ) (hχ : AEStronglyMeasurable χ μ)
    {C : ℝ} (hC0 : 0 ≤ C) (hC : ∀ᵐ x ∂μ, ‖χ x‖ ≤ C) :
    ‖cutoffOperator χ hχ hC‖ ≤ C :=
  LinearMap.mkContinuous_norm_le _ hC0 _

/-- A cutoff equal to one wherever f is nonzero preserves f exactly in L2. -/
theorem cutoffOperator_eq_self (χ : Ω → ℂ) (hχ : AEStronglyMeasurable χ μ)
    {C : ℝ} (hC : ∀ᵐ x ∂μ, ‖χ x‖ ≤ C) (f : Lp ℂ 2 μ)
    (hf : ∀ᵐ x ∂μ, f x ≠ 0 → χ x = 1) : cutoffOperator χ hχ hC f = f := by
  apply Lp.ext
  filter_upwards [cutoffL2_coe χ hχ hC f, hf] with x hx hfx
  change cutoffL2 χ hχ hC f x = f x
  rw [hx]
  by_cases h : f x = 0
  · simp [h]
  · rw [hfx h, one_mul]

/-- Every cutoff atom vanishes almost everywhere outside the cutoff support. -/
theorem cutoffOperator_support (χ : Ω → ℂ) (hχ : AEStronglyMeasurable χ μ)
    {C : ℝ} (hC : ∀ᵐ x ∂μ, ‖χ x‖ ≤ C) (f : Lp ℂ 2 μ) :
    ∀ᵐ x ∂μ, χ x = 0 → cutoffOperator χ hχ hC f x = 0 := by
  filter_upwards [cutoffL2_coe χ hχ hC f] with x hx hzero
  change cutoffL2 χ hχ hC f x = 0
  rw [hx, hzero, zero_mul]

end N2Restriction
