import N2Restriction.Geometry
import N2Restriction.Targets
import Mathlib.Analysis.InnerProductSpace.Calculus

namespace N2Restriction

/-- In finite dimension a quantitative lower bound produces an actual
continuous inverse, with its operator norm bounded by the reciprocal constant. -/
theorem exists_inverse_of_coercive {E : Type*} [NormedAddCommGroup E]
    [NormedSpace ℝ E] [FiniteDimensional ℝ E] (A : E →L[ℝ] E)
    {κ : ℝ} (hκ : 0 < κ) (hA : ∀ v, κ * ‖v‖ ≤ ‖A v‖) :
    ∃ B : E →L[ℝ] E, A.comp B = ContinuousLinearMap.id ℝ E ∧
      B.comp A = ContinuousLinearMap.id ℝ E ∧ ‖B‖ ≤ κ⁻¹ := by
  let e : E ≃L[ℝ] E :=
    (LinearEquiv.ofInjectiveEndo A.toLinearMap (injective_of_coercive A hκ hA)).toContinuousLinearEquiv
  have he (v : E) : e v = A v := rfl
  refine ⟨e.symm.toContinuousLinearMap, ?_, ?_, ?_⟩
  · ext v
    exact (he (e.symm v)).symm.trans (e.apply_symm_apply v)
  · ext v
    exact congrArg e.symm (he v).symm |>.trans (e.symm_apply_apply v)
  · apply ContinuousLinearMap.opNorm_le_bound _ (inv_nonneg.mpr hκ.le)
    intro v
    have h := hA (e.symm v)
    rw [← he, e.apply_symm_apply] at h
    rw [← div_eq_inv_mul, le_div_iff₀ hκ]
    simpa [mul_comm] using h

/-- Stability gives a quantitative inverse after a perturbation of at most
half the lower bound. -/
theorem inverse_after_perturbation {E : Type*} [NormedAddCommGroup E]
    [NormedSpace ℝ E] [FiniteDimensional ℝ E] (A B : E →L[ℝ] E)
    {κ : ℝ} (hκ : 0 < κ) (hA : ∀ v, κ * ‖v‖ ≤ ‖A v‖)
    (hAB : ‖A - B‖ ≤ κ / 2) :
    ∃ J : E →L[ℝ] E, B.comp J = ContinuousLinearMap.id ℝ E ∧
      J.comp B = ContinuousLinearMap.id ℝ E ∧ ‖J‖ ≤ 2 / κ := by
  have hdiff (v : E) : ‖A v - B v‖ ≤ (κ / 2) * ‖v‖ := by
    exact ((A - B).le_opNorm v).trans (mul_le_mul_of_nonneg_right hAB (norm_nonneg v))
  have hB : ∀ v, (κ / 2) * ‖v‖ ≤ ‖B v‖ := by
    simpa only [show κ - κ / 2 = κ / 2 by ring] using
      coercivity_under_perturbation A B hA hdiff
  obtain ⟨J, h₁, h₂, hJ⟩ := exists_inverse_of_coercive B (by positivity : 0 < κ / 2) hB
  refine ⟨J, h₁, h₂, ?_⟩
  simpa [div_eq_mul_inv, mul_comm] using hJ

/-- The inverse needed in the initial curvature step acts on the actual
common tangent subspace, via the actual orthogonal projection. -/
theorem projected_shape_inverse {E : Type*} [NormedAddCommGroup E]
    [InnerProductSpace ℝ E] [FiniteDimensional ℝ E] (W : Submodule ℝ E)
    (A : E →L[ℝ] E) {κ : ℝ} (hκ : 0 < κ)
    (hA : ∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (A v)‖) :
    ∃ B : W →L[ℝ] W,
      (W.orthogonalProjection.comp (A.comp W.subtypeL)).comp B = ContinuousLinearMap.id ℝ W ∧
      B.comp (W.orthogonalProjection.comp (A.comp W.subtypeL)) = ContinuousLinearMap.id ℝ W ∧
      ‖B‖ ≤ κ⁻¹ :=
  exists_inverse_of_coercive _ hκ hA

namespace SmoothPatch

/-- The differential kernel is exactly the hyperplane orthogonal to the
specified unit normal. -/
lemma differential_eq_zero_iff {n : ℕ} (S : SmoothPatch n) {z : Ambient n}
    (hz : z ∈ S.neighborhood) (v : Ambient n) :
    fderiv ℝ S.defining z v = 0 ↔ inner ℝ (S.normal z) v = 0 := by
  rw [S.normal_differential z hz v, mul_eq_zero]
  exact or_iff_right (ne_of_gt (S.positive_normalScale z hz))

/-- Differentiating the unit-normal identity shows that the actual shape
operator takes values in the tangent hyperplane. -/
lemma shape_orthogonal_normal {n : ℕ} (S : SmoothPatch n) {z : Ambient n}
    (hz : z ∈ S.neighborhood) (v : Ambient n) :
    inner ℝ (S.normal z) (S.shape z v) = 0 := by
  have hd : DifferentiableAt ℝ S.normal z :=
    (S.smooth_normal.differentiableOn (by simp)).differentiableAt (S.open_neighborhood.mem_nhds hz)
  have he : (fun y => inner ℝ (S.normal y) (S.normal y)) =ᶠ[nhds z] (fun _ => (1 : ℝ)) := by
    filter_upwards [S.open_neighborhood.mem_nhds hz] with y hy
    rw [real_inner_self_eq_norm_sq, S.normal_unit y hy, one_pow]
  have hder := (hd.hasFDerivAt.inner ℝ hd.hasFDerivAt).unique
    ((hasFDerivAt_const (1 : ℝ) z).congr_of_eventuallyEq he)
  have hv := congrArg (fun L : Ambient n →L[ℝ] ℝ => L v) hder
  change inner ℝ (S.normal z) (fderiv ℝ S.normal z v) +
    inner ℝ (fderiv ℝ S.normal z v) (S.normal z) = 0 at hv
  rw [real_inner_comm (fderiv ℝ S.normal z v) (S.normal z)] at hv
  have hzero : inner ℝ (S.normal z) (fderiv ℝ S.normal z v) = 0 := by
    rw [real_inner_comm]
    linarith
  simpa [shape] using hzero

end SmoothPatch
end N2Restriction
