import N2Restriction.EuclideanPacketEnergy
open MeasureTheory Set
namespace N2Restriction
/-- Exact full-space identification of the zero-extended cutoff Fourier mode. -/
theorem euclidean_cutoff_mode_eq_graphAtom {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r) (ν : Fin d → ℤ) :
    let t : Fin d → ℝ := fun _ => -(1 / 2 : ℝ)
    let ℓ := 2 * Real.pi * r
    let hℓ : 0 < ℓ := by dsimp [ℓ]; positivity
    let μ := capProbability t c ℓ hℓ.ne'
    ∀ᵐ ξ ∂(volume : Measure (Ambient d)),
      (ℓ ^ (-(d : ℝ) / 2) : ℝ) * euclideanCapSynthesis t c ℓ hℓ
        (frequencyCutoffOperator μ c r hr (capFourierAtom t c ℓ hℓ.ne' ν)) ξ =
      ((2 * Real.pi) ^ (-(d : ℝ) / 2) : ℝ) *
        Complex.exp (-((inner ℝ (r⁻¹ • latticeVector ν) c : ℂ) * Complex.I)) *
          graphAtom (fun η => (referenceBump d η : ℂ)) c r (r⁻¹ • latticeVector ν) ξ := by
  intro t ℓ hℓ μ
  have hcut := cutoffL2_coe (fun ξ => (frequencyBump c r hr ξ : ℂ))
    (frequencyBump_aestronglyMeasurable μ c hr)
    (Filter.Eventually.of_forall (frequencyBump_norm_le_one c hr)) (capFourierAtom t c ℓ hℓ.ne' ν)
  have hmode := cap_cutoff_mode_eq_graphAtom t (fun η => (referenceBump d η : ℂ)) c r hr ν
  have hcut' := hcut.filter_mono (capProbability_ae_eq t c ℓ hℓ).symm.le
  have hmode' := hmode.filter_mono (capProbability_ae_eq t c ℓ hℓ).symm.le
  have hc := (ae_restrict_iff' (scaledCube_measurable t c ℓ hℓ.ne')).mp hcut'
  have hm := (ae_restrict_iff' (scaledCube_measurable t c ℓ hℓ.ne')).mp hmode'
  filter_upwards [euclideanCapSynthesis_coe t c ℓ hℓ
    (frequencyCutoffOperator μ c r hr (capFourierAtom t c ℓ hℓ.ne' ν)), hc, hm] with ξ hξ hcξ hmξ
  rw [hξ]
  by_cases hx : ξ ∈ scaledCube t c ℓ hℓ.ne'
  · rw [indicator_of_mem hx]
    have hcξ' := hcξ hx
    change frequencyCutoffOperator μ c r hr (capFourierAtom t c ℓ hℓ.ne' ν) ξ = _ at hcξ'
    rw [hcξ', frequencyBump_rescale c hr]
    convert hmξ hx using 1
    ring
  · rw [indicator_of_notMem hx, mul_zero,
      reference_graphAtom_zero_outside_packetCube c r hr (r⁻¹ • latticeVector ν) hx, mul_zero]
end N2Restriction
