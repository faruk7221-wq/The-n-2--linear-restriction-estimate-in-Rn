import N2Restriction.CompactGraphPlancherel
import N2Restriction.SurfaceSlicePlancherel

namespace N2Restriction
open MeasureTheory Set
namespace SurfaceGraphChart
variable {d : ℕ} (G : SurfaceGraphChart d)

/-- Rough inputs supported on a compact part of a smooth graph have L2 physical slices. -/
theorem compact_slice_memLp (hφ : ContDiff ℝ (⊤ : ℕ∞) G.phase)
    {K : Set (Ambient d)} (hK : IsCompact K) (g : Lp ℂ 2 G.surfaceMeasure)
    (hg : HasFrequencySupport G.surfaceMeasure id (G.parametrization '' K) g) (t : ℝ) :
    MemLp (fun u => extension G.surfaceMeasure id g (graphPoint u t)) 2 := by
  simp_rw [G.coordinate_extension]
  exact compact_graph_slice_memLp hφ hK _
    (G.density.toCoordinate_support _ id K (G.pull_support g K hg)) t

/-- Local Plancherel on actual Hausdorff graph measure, for arbitrary supported L2 inputs. -/
theorem compact_slice_energy (hφ : ContDiff ℝ (⊤ : ℕ∞) G.phase)
    {K : Set (Ambient d)} (hK : IsCompact K) (g : Lp ℂ 2 G.surfaceMeasure)
    (hg : HasFrequencySupport G.surfaceMeasure id (G.parametrization '' K) g) (t : ℝ) :
    (∫ u, ‖extension G.surfaceMeasure id g (graphPoint u t)‖ ^ 2) ≤
      ((2 * Real.pi) ^ d * G.density.upper) * ‖g‖ ^ 2 := by
  simp_rw [G.coordinate_extension]
  have h := compact_graph_slice_energy hφ hK _
    (G.density.toCoordinate_support _ id K (G.pull_support g K hg)) t
  exact h.trans ((mul_le_mul_of_nonneg_left (G.coordinate_energy g) (by positivity)).trans_eq (by ring))

/-- The same local Plancherel bound is stated directly for the original compact patch input. -/
theorem patch_slice_energy (hφ : ContDiff ℝ (⊤ : ℕ∞) G.phase)
    {K : Set (Ambient d)} (hK : IsCompact K)
    (himage : MeasurableSet (G.parametrization '' K))
    (g : Lp ℂ 2 (G.surfaceMeasure.restrict (G.parametrization '' K))) (t : ℝ) :
    (∫ u, ‖extension (G.surfaceMeasure.restrict (G.parametrization '' K)) id g (graphPoint u t)‖ ^ 2) ≤
      ((2 * Real.pi) ^ d * G.density.upper) * ‖g‖ ^ 2 := by
  have h := G.compact_slice_energy hφ hK (G.patchInput himage g) (G.patchInput_support himage g) t
  simp_rw [G.patchInput_extension] at h
  simpa only [patchInput, zeroExtendL2_norm] using h

/-- Integrating the slice bound over any finite height interval costs its length. -/
theorem compact_slab_energy (hφ : ContDiff ℝ (⊤ : ℕ∞) G.phase)
    {K : Set (Ambient d)} (hK : IsCompact K) (g : Lp ℂ 2 G.surfaceMeasure)
    (hg : HasFrequencySupport G.surfaceMeasure id (G.parametrization '' K) g) (a b : ℝ) :
    (∫ t in Icc a b, ∫ u, ‖extension G.surfaceMeasure id g (graphPoint u t)‖ ^ 2) ≤
      max (b - a) 0 * (((2 * Real.pi) ^ d * G.density.upper) * ‖g‖ ^ 2) := by
  have h := integral_mono_of_nonneg (μ := volume.restrict (Icc a b))
    (ae_of_all _ fun t => integral_nonneg (fun u => sq_nonneg _))
    (integrable_const (((2 * Real.pi) ^ d * G.density.upper) * ‖g‖ ^ 2))
    (ae_of_all _ fun t => G.compact_slice_energy hφ hK g hg t)
  simpa [Real.volume_Icc, Measure.real, ENNReal.toReal_ofReal', smul_eq_mul] using h

end SurfaceGraphChart
end N2Restriction
