import N2Restriction.ActualPacketTails

namespace N2Restriction
open MeasureTheory UnitAddTorus
noncomputable local instance actualSynthesisCircleMeasure : MeasureSpace UnitAddCircle := ⟨AddCircle.haarAddCircle⟩

/-- A bounded operator whose images of Fourier modes are the actual graph atoms
with their unit center phases. -/
noncomputable def actualPacketSynthesis {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r) :
    Lp ℂ 2 (volume : Measure (UnitAddTorus (Fin d))) →L[ℂ] Lp ℂ 2 (volume : Measure (Ambient d)) :=
  let t : Fin d → ℝ := fun _ => -(1 / 2 : ℝ)
  let ℓ := 2 * Real.pi * r
  let hℓ : 0 < ℓ := by dsimp [ℓ]; positivity
  ((r ^ (-(d : ℝ) / 2) : ℝ) : ℂ) •
    (euclideanCapSynthesis t c ℓ hℓ).comp
      ((frequencyCutoffOperator (capProbability t c ℓ hℓ.ne') c r hr).comp
        (torusCapEquiv t c ℓ hℓ.ne').toContinuousLinearEquiv.toContinuousLinearMap)

theorem actualPacketSynthesis_norm_le {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r) :
    ‖actualPacketSynthesis c r hr‖ ≤ (2 * Real.pi) ^ ((d : ℝ) / 2) := by
  apply ContinuousLinearMap.opNorm_le_bound _ (by positivity)
  intro f
  simp only [actualPacketSynthesis, ContinuousLinearMap.smul_apply, ContinuousLinearMap.comp_apply,
    norm_smul, Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (Real.rpow_nonneg hr.le _),
    euclideanCapSynthesis_norm]
  have hb := (frequencyCutoffOperator _ c r hr).le_opNorm
    ((torusCapEquiv (fun _ => -(1 / 2 : ℝ)) c (2 * Real.pi * r) (by positivity)) f)
  have hn := frequencyCutoffOperator_norm_le
    (capProbability (fun _ => -(1 / 2 : ℝ)) c (2 * Real.pi * r) (by positivity)) c hr
  have hcut : ‖frequencyCutoffOperator _ c r hr
      ((torusCapEquiv (fun _ => -(1 / 2 : ℝ)) c (2 * Real.pi * r) (by positivity)) f)‖ ≤ ‖f‖ := by
    simpa only [LinearIsometryEquiv.norm_map, one_mul] using
      hb.trans (mul_le_mul_of_nonneg_right hn (norm_nonneg _))
  have hc : r ^ (-(d : ℝ) / 2) * (2 * Real.pi * r) ^ ((d : ℝ) / 2) =
      (2 * Real.pi) ^ ((d : ℝ) / 2) := by
    rw [Real.mul_rpow (by positivity : 0 ≤ 2 * Real.pi) hr.le]
    calc
      _ = (2 * Real.pi) ^ ((d : ℝ) / 2) *
          (r ^ (-(d : ℝ) / 2) * r ^ ((d : ℝ) / 2)) := by ring
      _ = _ := by
        rw [← Real.rpow_add hr, show -(d : ℝ) / 2 + (d : ℝ) / 2 = 0 by ring,
          Real.rpow_zero, mul_one]
  calc
    _ ≤ r ^ (-(d : ℝ) / 2) * ((2 * Real.pi * r) ^ ((d : ℝ) / 2) * ‖f‖) := by
      gcongr
      exact hcut
    _ = _ := by rw [← mul_assoc, hc]

theorem actualPacketSynthesis_fourier {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (ν : Fin d → ℤ) : actualPacketSynthesis c r hr (mFourierLp 2 ν) =
      ((r ^ (-(d : ℝ) / 2) : ℝ) : ℂ) • actualPacketMode c r hr ν := rfl

/-- The bounded synthesis uses the original Fourier coefficients of the actual input. -/
theorem actualPacketInput_eq_synthesis {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume.restrict (packetFrequencyCube c r hr))) (ν : Fin d → ℤ) :
    actualPacketInput c r hr f ν = actualPacketSynthesis c r hr
      (mFourierCoeff (packetTorusInput c r hr f) ν • mFourierLp 2 ν) := by
  rw [actualPacketInput_eq_mode, map_smul, actualPacketSynthesis_fourier, smul_smul,
    packetTorusInput_coefficient,
    mul_right_comm (((r ^ ((d : ℝ) / 2) : ℝ) : ℂ)) _ (((r ^ (-(d : ℝ) / 2) : ℝ) : ℂ)),
    ← Complex.ofReal_mul]
  have hc : (r ^ ((d : ℝ) / 2) : ℝ) * r ^ (-(d : ℝ) / 2) = 1 := by
    rw [← Real.rpow_add hr, show (d : ℝ) / 2 + -(d : ℝ) / 2 = 0 by ring, Real.rpow_zero]
  rw [hc, Complex.ofReal_one, one_mul]

/-- All selected actual packet families converge unconditionally in Euclidean L2. -/
theorem actualPacketInput_selected_summable {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume.restrict (packetFrequencyCube c r hr))) (S : Set (Fin d → ℤ)) :
    Summable (fun ν : S => actualPacketInput c r hr f ν) := by
  have h := (mFourierBasis.hasSum_repr (packetTorusInput c r hr f)).summable.subtype S
  have hh := (actualPacketSynthesis c r hr).hasSum h.hasSum
  simpa only [actualPacketInput_eq_synthesis, mFourierBasis_repr, coe_mFourierBasis] using hh.summable

/-- Almost orthogonality in the original packet energies, with an explicit
positive dimensional constant and no supplied lower cutoff-energy hypothesis. -/
theorem actualPacketInput_almost_orthogonal {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume.restrict (packetFrequencyCube c r hr))) (S : Set (Fin d → ℤ)) :
    packetCutoffEnergy d * ‖∑' ν : S, actualPacketInput c r hr f ν‖ ^ 2 ≤
      (2 * Real.pi) ^ d * ∑' ν : S, ‖actualPacketInput c r hr f ν‖ ^ 2 := by
  have h := fourier_packet_selection (actualPacketSynthesis c r hr) (packetTorusInput c r hr f) S
  have hn := pow_le_pow_left₀ (norm_nonneg _) (actualPacketSynthesis_norm_le c r hr) 2
  have hp : ((2 * Real.pi) ^ ((d : ℝ) / 2)) ^ 2 = (2 * Real.pi) ^ d := by
    rw [← Real.rpow_natCast, ← Real.rpow_mul (by positivity : 0 ≤ 2 * Real.pi)]
    norm_num
  rw [hp] at hn
  have he : 0 ≤ ∑' ν : S, ‖mFourierCoeff (packetTorusInput c r hr f) ν‖ ^ 2 :=
    tsum_nonneg (fun _ => sq_nonneg _)
  have hbound := h.trans (mul_le_mul_of_nonneg_right hn he)
  have hmul := mul_le_mul_of_nonneg_left hbound (packetCutoffEnergy_pos d).le
  simp_rw [← actualPacketInput_eq_synthesis] at hmul
  simp_rw [actualPacketInput_energy, actualPacketCoeff_norm]
  rw [tsum_mul_left]
  nlinarith only [hmul]

end N2Restriction
