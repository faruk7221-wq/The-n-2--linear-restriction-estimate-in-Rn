import N2Restriction.CutoffOperator
import N2Restriction.Targets
import N2Restriction.SupportMargins
import Mathlib.Analysis.Calculus.BumpFunction.InnerProduct

namespace N2Restriction
open MeasureTheory

/-- Fixed reference cutoff; its inner and outer radii are one and two. -/
def referenceBump (d : ℕ) : ContDiffBump (0 : Ambient d) :=
  ⟨1, 2, by norm_num, by norm_num⟩

/-- A concrete smooth cutoff of radius r about c. -/
def frequencyBump {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r) : ContDiffBump c :=
  ⟨r, 2 * r, hr, by linarith⟩

theorem frequencyBump_rescale {d : ℕ} (c : Ambient d) {r : ℝ} (hr : 0 < r) (x : Ambient d) :
    frequencyBump c r hr x = referenceBump d (r⁻¹ • (x - c)) := by
  simp [ContDiffBump.apply, frequencyBump, referenceBump, hr.ne']

theorem frequencyBump_contDiff {d : ℕ} (c : Ambient d) {r : ℝ} (hr : 0 < r) :
    ContDiff ℝ (⊤ : ℕ∞) (frequencyBump c r hr) :=
  (frequencyBump c r hr).contDiff

theorem frequencyBump_one {d : ℕ} (c : Ambient d) {r : ℝ} (hr : 0 < r)
    {x : Ambient d} (hx : dist x c ≤ r) : frequencyBump c r hr x = 1 :=
  (frequencyBump c r hr).one_of_mem_closedBall hx

theorem frequencyBump_support {d : ℕ} (c : Ambient d) {r : ℝ} (hr : 0 < r) :
    Function.support (frequencyBump c r hr) = Metric.ball c (2 * r) :=
  (frequencyBump c r hr).support_eq

/-- Every derivative of the fixed reference cutoff is globally bounded. -/
theorem referenceBump_derivative_bound (d q : ℕ) :
    ∃ B : ℝ, 0 ≤ B ∧ ∀ x, ‖iteratedFDeriv ℝ q (referenceBump d) x‖ ≤ B := by
  have hc : ContDiff ℝ q (referenceBump d) := (referenceBump d).contDiff
  obtain ⟨B, hB⟩ := ((referenceBump d).hasCompactSupport.iteratedFDeriv (𝕜 := ℝ) q).exists_bound_of_continuous
    hc.continuous_iteratedFDeriv'
  exact ⟨max B 0, le_max_right _ _, fun x => (hB x).trans (le_max_left _ _)⟩

/-- Uniform derivative bounds with the correct r^(-q) scaling, for every order.
The constant depends only on dimension and derivative order, not center or radius. -/
theorem frequencyBump_derivative_bound (d q : ℕ) :
    ∃ B : ℝ, 0 ≤ B ∧ ∀ (c : Ambient d) (r : ℝ) (hr : 0 < r) (x : Ambient d),
      ‖iteratedFDeriv ℝ q (frequencyBump c r hr) x‖ ≤ B * (r⁻¹) ^ q := by
  obtain ⟨B, hB, hb⟩ := referenceBump_derivative_bound d q
  refine ⟨B, hB, fun c r hr x => ?_⟩
  let g : Ambient d →L[ℝ] Ambient d := r⁻¹ • ContinuousLinearMap.id ℝ (Ambient d)
  have he : (frequencyBump c r hr : Ambient d → ℝ) =
      fun y => ((referenceBump d : Ambient d → ℝ) ∘ g) (y - c) := by
    funext y
    exact frequencyBump_rescale c hr y
  rw [he, iteratedFDeriv_comp_sub]
  rw [g.iteratedFDeriv_comp_right (show ContDiff ℝ q (referenceBump d) from
    (referenceBump d).contDiff) (x - c) le_rfl]
  have hg : ‖g‖ ≤ r⁻¹ := by
    calc
      ‖g‖ = |r⁻¹| * ‖ContinuousLinearMap.id ℝ (Ambient d)‖ := by
        dsimp only [g]
        rw [norm_smul, Real.norm_eq_abs]
      _ ≤ |r⁻¹| * 1 := mul_le_mul_of_nonneg_left ContinuousLinearMap.norm_id_le (abs_nonneg _)
      _ = r⁻¹ := by rw [abs_of_nonneg (inv_nonneg.mpr hr.le), mul_one]
  calc
    _ ≤ ‖iteratedFDeriv ℝ q (referenceBump d) (g (x - c))‖ * ∏ _ : Fin q, ‖g‖ :=
      ContinuousMultilinearMap.norm_compContinuousLinearMap_le _ _
    _ = ‖iteratedFDeriv ℝ q (referenceBump d) (g (x - c))‖ * ‖g‖ ^ q := by simp
    _ ≤ B * (r⁻¹) ^ q := mul_le_mul (hb _) (pow_le_pow_left₀ (norm_nonneg _) hg _)
      (by positivity) hB

/-- The complex-valued cutoff is measurable for any frequency measure. -/
theorem frequencyBump_aestronglyMeasurable {d : ℕ} (μ : Measure (Ambient d))
    (c : Ambient d) {r : ℝ} (hr : 0 < r) :
    AEStronglyMeasurable (fun x => (frequencyBump c r hr x : ℂ)) μ :=
  (Complex.continuous_ofReal.comp (frequencyBump c r hr).continuous).aestronglyMeasurable

theorem frequencyBump_norm_le_one {d : ℕ} (c : Ambient d) {r : ℝ} (hr : 0 < r) (x : Ambient d) :
    ‖(frequencyBump c r hr x : ℂ)‖ ≤ 1 := by
  rw [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (frequencyBump c r hr).nonneg]
  exact (frequencyBump c r hr).le_one

/-- A concrete contraction on frequency L2 at every cap scale. -/
noncomputable def frequencyCutoffOperator {d : ℕ} (μ : Measure (Ambient d))
    (c : Ambient d) (r : ℝ) (hr : 0 < r) : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ :=
  cutoffOperator (fun x => (frequencyBump c r hr x : ℂ))
    (frequencyBump_aestronglyMeasurable μ c hr)
    (Filter.Eventually.of_forall (frequencyBump_norm_le_one c hr))

theorem frequencyCutoffOperator_norm_le {d : ℕ} (μ : Measure (Ambient d))
    (c : Ambient d) {r : ℝ} (hr : 0 < r) : ‖frequencyCutoffOperator μ c r hr‖ ≤ 1 :=
  cutoffOperator_norm_le _ _ zero_le_one _

/-- The constructed cutoff preserves data in the inner cap exactly. -/
theorem frequencyCutoffOperator_eq_self {d : ℕ} (μ : Measure (Ambient d))
    (c : Ambient d) {r : ℝ} (hr : 0 < r) (f : Lp ℂ 2 μ)
    (hf : HasFrequencySupport μ id (Metric.closedBall c r) f) :
    frequencyCutoffOperator μ c r hr f = f := by
  apply cutoffOperator_eq_self
  filter_upwards [hf] with x hx hne
  change (frequencyBump c r hr x : ℂ) = 1
  have hxc : dist x c ≤ r := hx hne
  rw [frequencyBump_one c hr hxc, Complex.ofReal_one]

/-- Every atom formed by this cutoff has essential support in the outer cap. -/
theorem frequencyCutoffOperator_support {d : ℕ} (μ : Measure (Ambient d))
    (c : Ambient d) {r : ℝ} (hr : 0 < r) (f : Lp ℂ 2 μ) :
    HasFrequencySupport μ id (Metric.ball c (2 * r)) (frequencyCutoffOperator μ c r hr f) := by
  have hc := cutoffOperator_support (fun x => (frequencyBump c r hr x : ℂ))
    (frequencyBump_aestronglyMeasurable μ c hr)
    (Filter.Eventually.of_forall (frequencyBump_norm_le_one c hr)) f
  filter_upwards [hc] with x hx hne
  change dist x c < 2 * r
  by_contra h
  apply hne
  apply hx
  simp only [(frequencyBump c r hr).zero_of_le_dist (le_of_not_gt h), Complex.ofReal_zero]

/-- An original-support anchor controls the frequency enlargement of every
cutoff atom, hence of every packet synthesized with that cutoff. -/
theorem frequencyCutoff_margin_transfer {d : ℕ} (μ : Measure (Ambient d))
    (U : Set (Ambient d)) (c z : Ambient d) {r a b : ℝ} (hr : 0 < r)
    (hz : z ∈ marginRegion U a) (hzc : dist z c ≤ r) (hab : b + 3 * r ≤ a)
    (f : Lp ℂ 2 μ) :
    HasFrequencySupport μ id (marginRegion U b) (frequencyCutoffOperator μ c r hr f) := by
  apply (frequencyCutoffOperator_support μ c hr f).mono
  intro x hx
  apply marginRegion_enlargement U hab hz
  have ht := dist_triangle x c z
  rw [dist_comm c z] at ht
  have hx' : dist x c < 2 * r := hx
  linarith

/-- The concrete R^(-1/2) cutoff atoms are admissible at every child L in
[1,R/2], provided their cap has an anchor in the original admissible support. -/
theorem eventually_frequencyCutoff_children {d : ℕ} (μ : Measure (Ambient d))
    (U : Set (Ambient d)) (m : ℝ) :
    ∀ᶠ R : ℝ in Filter.atTop, ∃ hR : 0 < R, ∀ L : ℝ, 1 ≤ L → L ≤ R / 2 →
      ∀ c z : Ambient d,
      z ∈ marginRegion U (m - R ^ (-1 / 4 : ℝ)) →
      dist z c ≤ R ^ (-1 / 2 : ℝ) → ∀ f : Lp ℂ 2 μ,
      HasFrequencySupport μ id (marginRegion U (m - L ^ (-1 / 4 : ℝ)))
        (frequencyCutoffOperator μ c (R ^ (-1 / 2 : ℝ)) (Real.rpow_pos_of_pos hR _) f) := by
  filter_upwards [eventually_support_margin 3, Filter.eventually_gt_atTop (0 : ℝ)] with R hm hR
  refine ⟨hR, fun L hL hLR c z hz hzc f => ?_⟩
  exact frequencyCutoff_margin_transfer μ U c z (Real.rpow_pos_of_pos hR _) hz hzc
    (by linarith [hm L hL hLR]) f

end N2Restriction
