import N2Restriction.ThinSupportDifferential
import Mathlib.Analysis.Calculus.Implicit
import Mathlib.Analysis.Calculus.ContDiff.RCLike

namespace N2Restriction

/-- Qualitative local coordinates for the unperturbed thin-support constraints.
The first chart coordinate is exactly (defining function, projected normal).
This supplies a genuine local chart, but not the paper's uniform chart radii,
nearby-plane family, derivative bounds or quantitative distance estimate. -/
theorem exists_thin_chart {n : ℕ} (S : SmoothPatch n)
    (W : Submodule ℝ (Ambient n)) {z : Ambient n} (hz : z ∈ S.neighborhood)
    (hW : ∀ v : W, inner ℝ (S.normal z) (v : Ambient n) = 0)
    {κ : ℝ} (hκ : 0 < κ)
    (hA : ∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (S.shape z v)‖) :
    ∃ e : OpenPartialHomeomorph (Ambient n)
      ((ℝ × W) × LinearMap.ker (thinDifferential S W z).toLinearMap),
      z ∈ e.source ∧ e z = (thinConstraint S W z, 0) ∧
      ∀ y : Ambient n, (e y).1 = thinConstraint S W y := by
  have hds := S.smooth_defining.contDiffAt (S.open_neighborhood.mem_nhds hz)
  have hns := S.smooth_normal.contDiffAt (S.open_neighborhood.mem_nhds hz)
  have hs : ContDiffAt ℝ (⊤ : ℕ∞) (thinConstraint S W) z :=
    hds.prodMk (W.orthogonalProjection.contDiff.contDiffAt.comp z hns)
  have hd := hs.hasStrictFDerivAt' (hasFDerivAt_thinConstraint S W hz) (by simp)
  have hr : LinearMap.range (thinDifferential S W z).toLinearMap = ⊤ :=
    LinearMap.range_eq_top.mpr (thinDifferential_surjective S W hz hW hκ hA)
  refine ⟨hd.implicitToOpenPartialHomeomorph _ _ hr,
    hd.mem_implicitToOpenPartialHomeomorph_source hr,
    hd.implicitToOpenPartialHomeomorph_self hr, ?_⟩
  exact fun y => hd.implicitToOpenPartialHomeomorph_fst hr y

/-- At an admissible frequency tuple the local chart sends the thin-support
zero set to the zero slice, and the free coordinate space has dimension n-3.
This is a qualitative, unperturbed version of the level-set assertion. -/
theorem geometric_thin_chart {k : ℕ} (S : Fin k → SmoothPatch (k + 2))
    {ν κ : ℝ} (hgeo : GeometricHypotheses S ν κ)
    (z : Fin k → Ambient (k + 2)) (hz : ∀ i, z i ∈ (S i).extendedSurface) (i : Fin k) :
    let W := commonTangent (fun j => (S j).normal (z j))
    let K := LinearMap.ker (thinDifferential (S i) W (z i)).toLinearMap
    ∃ e : OpenPartialHomeomorph (Ambient (k + 2)) ((ℝ × W) × K),
      z i ∈ e.source ∧ e (z i) = (0, 0) ∧ Module.finrank ℝ K = k - 1 ∧
      ∀ y, (e y).1 = 0 ↔ (S i).defining y = 0 ∧ W.orthogonalProjection ((S i).normal y) = 0 := by
  dsimp only
  let W := commonTangent (fun j => (S j).normal (z j))
  obtain ⟨e, he, hez, hef⟩ := exists_thin_chart (S i) W (hz i).1
    (fun v => commonTangent_orthogonal (fun j => (S j).normal (z j)) v i)
    hgeo.2.1 ((hgeo.2.2 z hz).2 i)
  have hc : thinConstraint (S i) W (z i) = 0 := by
    apply Prod.ext
    · exact (hz i).2
    · change W.orthogonalProjection ((S i).normal (z i)) = 0
      apply Submodule.orthogonalProjection_eq_zero_iff.mpr
      rw [Submodule.mem_orthogonal]
      intro v hv
      exact (real_inner_comm _ _).trans
        (commonTangent_orthogonal (fun j => (S j).normal (z j)) ⟨v, hv⟩ i)
  refine ⟨e, he, ?_, thinDifferential_kernel_dimension S hgeo z hz i, ?_⟩
  · rw [hez, hc]
  · intro y
    rw [hef]
    simp [thinConstraint, Prod.ext_iff, W]

/-- The implicit parametrization is strictly differentiable at the base point,
with derivative the kernel inclusion, and remains in the same constraint level
near that point. Uniform neighborhood and higher-derivative estimates remain
separate obligations. -/
theorem exists_thin_parametrization {n : ℕ} (S : SmoothPatch n)
    (W : Submodule ℝ (Ambient n)) {z : Ambient n} (hz : z ∈ S.neighborhood)
    (hW : ∀ v : W, inner ℝ (S.normal z) (v : Ambient n) = 0)
    {κ : ℝ} (hκ : 0 < κ)
    (hA : ∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (S.shape z v)‖) :
    let K := LinearMap.ker (thinDifferential S W z).toLinearMap
    ∃ φ : K → Ambient n, φ 0 = z ∧ HasStrictFDerivAt φ K.subtypeL 0 ∧
      ∀ᶠ t in nhds (0 : K), thinConstraint S W (φ t) = thinConstraint S W z := by
  dsimp only
  have hds := S.smooth_defining.contDiffAt (S.open_neighborhood.mem_nhds hz)
  have hns := S.smooth_normal.contDiffAt (S.open_neighborhood.mem_nhds hz)
  have hs : ContDiffAt ℝ (⊤ : ℕ∞) (thinConstraint S W) z :=
    hds.prodMk (W.orthogonalProjection.contDiff.contDiffAt.comp z hns)
  have hd := hs.hasStrictFDerivAt' (hasFDerivAt_thinConstraint S W hz) (by simp)
  have hr : LinearMap.range (thinDifferential S W z).toLinearMap = ⊤ :=
    LinearMap.range_eq_top.mpr (thinDifferential_surjective S W hz hW hκ hA)
  refine ⟨hd.implicitFunction _ _ hr (thinConstraint S W z),
    hd.implicitFunction_apply_image hr, hd.to_implicitFunction hr, ?_⟩
  exact (tendsto_const_nhds.prodMk_nhds Filter.tendsto_id).eventually
    (hd.map_implicitFunction_eq hr)

end N2Restriction
