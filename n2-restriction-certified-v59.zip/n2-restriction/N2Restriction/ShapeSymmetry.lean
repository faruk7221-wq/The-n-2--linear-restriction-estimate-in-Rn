import N2Restriction.CurvatureInverse
import Mathlib.Analysis.Calculus.FDeriv.Symmetric

namespace N2Restriction.SmoothPatch

/-- The normal scale is determined by the defining function and unit normal. -/
theorem normalScale_eq_differential_normal {n : ℕ} (S : SmoothPatch n)
    {z : Ambient n} (hz : z ∈ S.neighborhood) :
    S.normalScale z = fderiv ℝ S.defining z (S.normal z) := by
  rw [S.normal_differential z hz, real_inner_self_eq_norm_sq, S.normal_unit z hz]
  simp

/-- Differentiability of the normal scale follows from the patch axioms;
it need not be imposed as an extra hypothesis. -/
theorem differentiableAt_normalScale {n : ℕ} (S : SmoothPatch n)
    {z : Ambient n} (hz : z ∈ S.neighborhood) : DifferentiableAt ℝ S.normalScale z := by
  have hds := S.smooth_defining.contDiffAt (S.open_neighborhood.mem_nhds hz)
  have hns := S.smooth_normal.contDiffAt (S.open_neighborhood.mem_nhds hz)
  have hd : DifferentiableAt ℝ (fderiv ℝ S.defining) z :=
    (hds.fderiv_right (m := 1) (by norm_cast)).differentiableAt (by simp)
  have hn : DifferentiableAt ℝ S.normal z := hns.differentiableAt (by simp)
  have he : S.normalScale =ᶠ[nhds z]
      (fun y => fderiv ℝ S.defining y (S.normal y)) := by
    filter_upwards [S.open_neighborhood.mem_nhds hz] with y hy
    exact S.normalScale_eq_differential_normal hy
  exact (hd.clm_apply hn).congr_of_eventuallyEq he

/-- The Hessian in a tangent second argument is normal-scale times the
normal differential. The derivative of the scale vanishes from this identity. -/
theorem hessian_on_tangent {n : ℕ} (S : SmoothPatch n)
    {z : Ambient n} (hz : z ∈ S.neighborhood) (u v : Ambient n)
    (hv : inner ℝ (S.normal z) v = 0) :
    fderiv ℝ (fderiv ℝ S.defining) z u v =
      S.normalScale z * inner ℝ (fderiv ℝ S.normal z u) v := by
  have hds := S.smooth_defining.contDiffAt (S.open_neighborhood.mem_nhds hz)
  have hns := S.smooth_normal.contDiffAt (S.open_neighborhood.mem_nhds hz)
  have hd : DifferentiableAt ℝ (fderiv ℝ S.defining) z :=
    (hds.fderiv_right (m := 1) (by norm_cast)).differentiableAt (by simp)
  have hn : DifferentiableAt ℝ S.normal z := hns.differentiableAt (by simp)
  have hleft := hd.hasFDerivAt.clm_apply (hasFDerivAt_const v z)
  have hright := (S.differentiableAt_normalScale hz).hasFDerivAt.mul
    (hn.hasFDerivAt.inner ℝ (hasFDerivAt_const v z))
  have he : (fun y => fderiv ℝ S.defining y v) =ᶠ[nhds z]
      (fun y => S.normalScale y * inner ℝ (S.normal y) v) := by
    filter_upwards [S.open_neighborhood.mem_nhds hz] with y hy
    exact S.normal_differential y hy v
  have h := hleft.unique (hright.congr_of_eventuallyEq he)
  have hu := congrArg (fun L : Ambient n →L[ℝ] ℝ => L u) h
  simpa [hv] using hu

/-- Symmetry of the actual shape operator on tangent vectors, derived from
symmetry of the Hessian rather than assumed as additional geometric data. -/
theorem shape_symmetric_tangent {n : ℕ} (S : SmoothPatch n)
    {z : Ambient n} (hz : z ∈ S.neighborhood) (u v : Ambient n)
    (hu : inner ℝ (S.normal z) u = 0) (hv : inner ℝ (S.normal z) v = 0) :
    inner ℝ (S.shape z u) v = inner ℝ u (S.shape z v) := by
  have hd := S.smooth_defining.contDiffAt (S.open_neighborhood.mem_nhds hz)
  have hsym := (hd.isSymmSndFDerivAt (by norm_num; exact WithTop.coe_le_coe.mpr (le_top : (2 : ℕ∞) ≤ ⊤))).eq u v
  rw [S.hessian_on_tangent hz u v hv, S.hessian_on_tangent hz v u hu] at hsym
  have h := mul_left_cancel₀ (S.positive_normalScale z hz).ne' hsym
  simpa [shape, real_inner_comm u] using congrArg Neg.neg h

end N2Restriction.SmoothPatch
