import N2Restriction.Basic
import Mathlib.Analysis.InnerProductSpace.Projection.FiniteDimensional

/-! Elementary operator estimates used in the curvature discussion.
These do not yet construct the thin-support submanifolds of Lemma 4.1. -/

namespace N2Restriction

/-- Uniform lower bounds survive a controlled perturbation. This is the
operator estimate preceding the quantitative implicit function argument. -/
theorem coercivity_under_perturbation {E F : Type*}
    [NormedAddCommGroup E] [NormedAddCommGroup F]
    (A B : E → F) {κ δ : ℝ}
    (hA : ∀ v, κ * ‖v‖ ≤ ‖A v‖)
    (hAB : ∀ v, ‖A v - B v‖ ≤ δ * ‖v‖) :
    ∀ v, (κ - δ) * ‖v‖ ≤ ‖B v‖ := by
  intro v
  have ht : ‖A v‖ ≤ ‖A v - B v‖ + ‖B v‖ := by
    simpa using norm_add_le (A v - B v) (B v)
  have ha := hA v
  have hb := hAB v
  nlinarith

/-- The elliptic sufficient condition immediately after Theorem 1.1.
A is an ambient extension of the shape operator; W is the common tangent
subspace. The assertion uses the actual orthogonal projection onto W. -/
theorem elliptic_compression {E : Type*} [NormedAddCommGroup E]
    [InnerProductSpace ℝ E] (W : Submodule ℝ E) [W.HasOrthogonalProjection]
    (A : E →L[ℝ] E) (κ : ℝ)
    (hell : ∀ v : W, κ * ‖v‖ ^ 2 ≤ inner ℝ (A v) (v : E)) :
    ∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (A v)‖ := by
  intro v
  by_cases hv : ‖v‖ = 0
  · simp [hv]
  have hvp : 0 < ‖v‖ := lt_of_le_of_ne (norm_nonneg _) (Ne.symm hv)
  have hinner : inner ℝ (W.orthogonalProjection (A v)) v = inner ℝ (A v) (v : E) :=
    W.inner_orthogonalProjection_eq_of_mem_right v (A v)
  have hcs := real_inner_le_norm (W.orthogonalProjection (A v)) v
  rw [hinner] at hcs
  have h := (hell v).trans hcs
  nlinarith

/-- A positive coercivity bound implies injectivity of a linear map. -/
theorem injective_of_coercive {E F : Type*} [NormedAddCommGroup E]
    [NormedAddCommGroup F] [NormedSpace ℝ E] [NormedSpace ℝ F]
    (A : E →L[ℝ] F) {κ : ℝ} (hκ : 0 < κ)
    (hA : ∀ v, κ * ‖v‖ ≤ ‖A v‖) : Function.Injective A := by
  intro v w hvw
  have hz : A (v - w) = 0 := by rw [map_sub, hvw, sub_self]
  have h := hA (v - w)
  rw [hz, norm_zero] at h
  have hn : ‖v - w‖ = 0 := by nlinarith [norm_nonneg (v - w)]
  exact sub_eq_zero.mp (norm_eq_zero.mp hn)

end N2Restriction
