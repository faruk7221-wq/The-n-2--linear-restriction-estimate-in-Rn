import Mathlib.Topology.Algebra.InfiniteSum.ENNReal
import N2Restriction.Basic

/-! Infinite positive-energy bookkeeping. ENNReal sums allow arbitrary index
sets and do not require a hidden summability hypothesis. -/
namespace N2Restriction
open scoped ENNReal
noncomputable section
variable {C T : Type*}

/-- Original energy retained by a selection. -/
def selectedEnergy (S : Set T) (e : T → ℝ≥0∞) : ℝ≥0∞ :=
  ∑' t, S.indicator e t

/-- Summing selected original energies counts each original packet once per incidence. -/
theorem infinite_energy_counting (S : C → Set T) (e : T → ℝ≥0∞) :
    (∑' c, selectedEnergy (S c) e) =
      ∑' t, (∑' c, (S c).indicator (fun _ => (1 : ℝ≥0∞)) t) * e t := by
  classical
  unfold selectedEnergy
  rw [ENNReal.tsum_comm]
  congr 1
  ext t
  rw [← ENNReal.tsum_mul_right]
  congr 1
  ext c
  by_cases h : t ∈ S c <;> simp [Set.indicator, h]

/-- The multiplicity estimate remains valid for infinite packet and cell sets. -/
theorem infinite_energy_multiplicity (S : C → Set T) (e : T → ℝ≥0∞)
    (M : ℝ≥0∞)
    (hM : ∀ t, (∑' c, (S c).indicator (fun _ => (1 : ℝ≥0∞)) t) ≤ M) :
    (∑' c, selectedEnergy (S c) e) ≤ M * ∑' t, e t := by
  rw [infinite_energy_counting, ← ENNReal.tsum_mul_left]
  exact ENNReal.tsum_le_tsum fun t => mul_le_mul_right' (hM t) _

/-- Inclusion of selections preserves the original positive energy ordering. -/
theorem selectedEnergy_mono {S U : Set T} (hSU : S ⊆ U) (e : T → ℝ≥0∞) :
    selectedEnergy S e ≤ selectedEnergy U e := by
  classical
  apply ENNReal.tsum_le_tsum
  intro t
  by_cases h : t ∈ S
  · simp [Set.indicator_of_mem h, Set.indicator_of_mem (hSU h)]
  · simp [Set.indicator_of_notMem h]

/-- A union budget counts overlapping energy at most twice. -/
theorem selectedEnergy_union_le (S U : Set T) (e : T → ℝ≥0∞) :
    selectedEnergy (S ∪ U) e ≤ selectedEnergy S e + selectedEnergy U e := by
  classical
  rw [selectedEnergy, selectedEnergy, selectedEnergy, ← ENNReal.tsum_add]
  apply ENNReal.tsum_le_tsum
  intro t
  by_cases hS : t ∈ S <;> by_cases hU : t ∈ U <;> simp [Set.indicator, hS, hU]

/-- Disjoint selections split the original energy exactly. -/
theorem selectedEnergy_disjoint_union (S U : Set T) (hSU : Disjoint S U)
    (e : T → ℝ≥0∞) :
    selectedEnergy (S ∪ U) e = selectedEnergy S e + selectedEnergy U e := by
  classical
  rw [selectedEnergy, selectedEnergy, selectedEnergy, ← ENNReal.tsum_add]
  congr 1
  ext t
  have h := Set.disjoint_left.mp hSU
  by_cases hS : t ∈ S <;> by_cases hU : t ∈ U
  · exact False.elim (h hS hU)
  all_goals simp [Set.indicator, hS, hU]

/-- A partition with multiplicity one conserves energy, including infinite energies. -/
theorem infinite_energy_partition (S : C → Set T) (e : T → ℝ≥0∞)
    (hS : ∀ t, (∑' c, (S c).indicator (fun _ => (1 : ℝ≥0∞)) t) = 1) :
    (∑' c, selectedEnergy (S c) e) = ∑' t, e t := by
  rw [infinite_energy_counting]
  simp [hS]

/-- Any supplied synthesis bounds combine with infinite incidence counting. -/
theorem infinite_selected_norm_budget (S : C → Set T) (e : T → ℝ≥0∞)
    (a : C → ℝ≥0∞) (K M : ℝ≥0∞)
    (ha : ∀ c, a c ≤ K * selectedEnergy (S c) e)
    (hM : ∀ t, (∑' c, (S c).indicator (fun _ => (1 : ℝ≥0∞)) t) ≤ M) :
    (∑' c, a c) ≤ K * M * ∑' t, e t := by
  calc
    (∑' c, a c) ≤ ∑' c, K * selectedEnergy (S c) e := ENNReal.tsum_le_tsum ha
    _ = K * ∑' c, selectedEnergy (S c) e := ENNReal.tsum_mul_left
    _ ≤ K * (M * ∑' t, e t) := mul_le_mul_left' (infinite_energy_multiplicity S e M hM) K
    _ = K * M * ∑' t, e t := (mul_assoc _ _ _).symm

/-- A nested restriction cannot increase the incidence multiplicity. -/
theorem infinite_energy_reselection (S U : C → Set T) (hUS : ∀ c, U c ⊆ S c)
    (e : T → ℝ≥0∞) (M : ℝ≥0∞)
    (hM : ∀ t, (∑' c, (S c).indicator (fun _ => (1 : ℝ≥0∞)) t) ≤ M) :
    (∑' c, selectedEnergy (U c) e) ≤ M * ∑' t, e t :=
  (ENNReal.tsum_le_tsum fun c => selectedEnergy_mono (hUS c) e).trans
    (infinite_energy_multiplicity S e M hM)

end
end N2Restriction
