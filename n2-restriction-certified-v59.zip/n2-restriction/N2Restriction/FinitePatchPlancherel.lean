import N2Restriction.RotatedPatchPlancherel
import N2Restriction.SupportedExtensionSynthesis

namespace N2Restriction
open MeasureTheory Set

/-- The local Plancherel ball bound, retaining the measure and the original input norm. -/
def HasBallEnergyBound {n : ℕ} (μ : Measure (Ambient n)) (C : ℝ) : Prop :=
  ∀ (g : Lp ℂ 2 μ) (x₀ : Ambient n) (R : ℝ), 0 ≤ R →
    (∫ y in Metric.ball x₀ R, ‖extension μ id g y‖ ^ 2) ≤ C * R * ‖g‖ ^ 2

/-- Zero extension preserves the actual oscillatory integral for any measure. -/
theorem zeroExtendL2_extension {Ω : Type*} [MeasurableSpace Ω] {n : ℕ}
    (μ : Measure Ω) (s : Set Ω) (hs : MeasurableSet s)
    (g : Lp ℂ 2 (μ.restrict s)) (ζ : Ω → Ambient n) (y : Ambient n) :
    extension μ ζ (zeroExtendL2 μ s hs g) y = extension (μ.restrict s) ζ g y := by
  unfold extension
  rw [← integral_indicator hs]
  apply integral_congr_ae
  filter_upwards [zeroExtendL2_coe μ s hs g] with x hx
  rw [hx]
  by_cases hxs : x ∈ s <;> simp [hxs]

/-- A ball bound passes to a measurable subpatch without changing its constant. -/
theorem HasBallEnergyBound.restrict {n : ℕ} {μ : Measure (Ambient n)} {C : ℝ}
    (h : HasBallEnergyBound μ C) (s : Set (Ambient n)) (hs : MeasurableSet s) :
    HasBallEnergyBound (μ.restrict s) C := by
  intro g x₀ R hR
  have hb := h (zeroExtendL2 μ s hs g) x₀ R hR
  simpa only [zeroExtendL2_extension, zeroExtendL2_norm] using hb

/-- Finite physical sums lose only their number of summands in the squared energy. -/
theorem finite_sum_ball_energy {n : ℕ} {ι : Type*} [Fintype ι]
    (F : ι → Ambient n → ℂ) (hF : ∀ j, Continuous (F j)) (x₀ : Ambient n) (R : ℝ) :
    (∫ y in Metric.ball x₀ R, ‖∑ j, F j y‖ ^ 2) ≤
      (Fintype.card ι : ℝ) * ∑ j, ∫ y in Metric.ball x₀ R, ‖F j y‖ ^ 2 := by
  have hi (j) : IntegrableOn (fun y => ‖F j y‖ ^ 2) (Metric.ball x₀ R) volume :=
    (((hF j).norm.pow 2).continuousOn.integrableOn_compact (isCompact_closedBall x₀ R)).mono_set
      Metric.ball_subset_closedBall
  rw [← integral_finset_sum _ (fun j _ => hi j), ← integral_const_mul]
  apply integral_mono_of_nonneg
  · exact ae_of_all _ (fun y => sq_nonneg _)
  · exact (integrable_finset_sum _ (fun j _ => hi j)).const_mul _
  · apply ae_of_all
    intro y
    have hn := pow_le_pow_left₀ (norm_nonneg (∑ j, F j y)) (norm_sum_le _ _) 2
    have hc := Finset.sum_mul_sq_le_sq_mul_sq Finset.univ (fun _ : ι => (1 : ℝ))
      (fun j => ‖F j y‖)
    simp only [one_mul, one_pow, Finset.sum_const, Finset.card_univ, nsmul_eq_mul, mul_one] at hc
    exact hn.trans hc

/-- Supported pieces with a total input-energy budget give a single ball estimate. -/
theorem ball_energy_of_finite_pieces {n : ℕ} {ι : Type*} [Fintype ι]
    (μ : Measure (Ambient n)) [IsFiniteMeasure μ]
    (K : ι → Set (Ambient n)) (hK : ∀ j, MeasurableSet (K j))
    {C : ℝ} (hC : 0 ≤ C) (hb : ∀ j, HasBallEnergyBound (μ.restrict (K j)) C)
    (g : Lp ℂ 2 μ) (f : ι → Lp ℂ 2 μ)
    (hs : ∀ j, HasFrequencySupport μ id (K j) (f j))
    (he : ∑ j, f j = g) (henergy : (∑ j, ‖f j‖ ^ 2) ≤ ‖g‖ ^ 2)
    (x₀ : Ambient n) {R : ℝ} (hR : 0 ≤ R) :
    (∫ y in Metric.ball x₀ R, ‖extension μ id g y‖ ^ 2) ≤
      (Fintype.card ι : ℝ) * C * R * ‖g‖ ^ 2 := by
  have hsum (y : Ambient n) : extension μ id g y = ∑ j, extension μ id (f j) y := by
    rw [← he, ← extensionEvaluation_eq μ id measurable_id, map_sum]
    simp only [extensionEvaluation_eq]
  simp_rw [hsum]
  have hcont (j) : Continuous (extension μ id (f j)) :=
    continuous_extension measurable_id ((Lp.memLp (f j)).integrable (by norm_num))
  apply (finite_sum_ball_energy _ hcont x₀ R).trans
  have hlocal (j) : (∫ y in Metric.ball x₀ R, ‖extension μ id (f j) y‖ ^ 2) ≤
      C * R * ‖f j‖ ^ 2 := by
    have h := hb j (restrictInputL2 μ (K j) (f j)) x₀ R hR
    simpa only [extension_restrictInput μ (K j) (hK j) (f j) (hs j),
      restrictInputL2_norm_of_support μ (K j) (hK j) (f j) (hs j)] using h
  calc
    _ ≤ (Fintype.card ι : ℝ) * ∑ j, C * R * ‖f j‖ ^ 2 :=
      mul_le_mul_of_nonneg_left (Finset.sum_le_sum (fun j _ => hlocal j)) (by positivity)
    _ = (Fintype.card ι : ℝ) * C * R * ∑ j, ‖f j‖ ^ 2 := by rw [← Finset.mul_sum]; ring
    _ ≤ _ := mul_le_mul_of_nonneg_left henergy (by positivity)

end N2Restriction
