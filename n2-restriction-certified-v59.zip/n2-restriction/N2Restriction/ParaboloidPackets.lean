import N2Restriction.PacketRapidDecay
import N2Restriction.GraphAtomEnergy

namespace N2Restriction

/-- The rescaled packet axis is precisely a translated unit lattice. -/
theorem rescaled_packet_axis {d : ℕ} (u c : Ambient d) (t : ℝ)
    {r : ℝ} (hr : r ≠ 0) (ν : Fin d → ℤ) :
    r • (u + r⁻¹ • latticeVector ν + t • c) =
      latticeVector ν - (-(r • (u + t • c))) := by
  simp only [smul_add, smul_smul, mul_inv_cancel₀ hr, one_smul, sub_neg_eq_add]
  abel

/-- All selected paraboloid packets have an absolutely convergent series and
the expected common tail bound. The statement uses the actual graph integral. -/
theorem paraboloid_selected_packet_tail (d M : ℕ) {χ : Ambient d → ℂ}
    (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hs : HasCompactSupport χ) :
    ∃ C : ℝ, 0 ≤ C ∧
      ∀ {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E],
      ∀ (b : HilbertBasis (Fin d → ℤ) ℂ E) (x : E) (c u : Ambient d)
        (r : ℝ), 0 < r → ∀ (t L : ℝ), |t * r ^ 2| ≤ 1 → 0 ≤ L →
      ∀ S : Set (Fin d → ℤ),
      (∀ ν ∈ S, L ≤ ‖latticeVector ν - (-(r • (u + t • c)))‖) →
      Summable (fun ν : S => b.repr x ν *
        graphPacket (fun ξ => inner ℝ ξ ξ / 2) χ c r (r⁻¹ • latticeVector ν) u t) ∧
      (∑' ν : S, ‖b.repr x ν *
        graphPacket (fun ξ => inner ℝ ξ ξ / 2) χ c r (r⁻¹ • latticeVector ν) u t‖) ≤
        r ^ ((d : ℝ) / 2) * (C / (1 + L) ^ M) * ‖x‖ := by
  obtain ⟨C, hC, hb⟩ := paraboloid_packet_decay d (d + M) hχ hs
  refine ⟨C * (2 ^ d * ‖latticeWeight d‖), by positivity, ?_⟩
  intro E _ _ b x c u r hr t L ht hL S hS
  let a : Ambient d := -(r • (u + t • c))
  let packet : (Fin d → ℤ) → ℂ := fun ν => b.repr x ν *
    graphPacket (fun ξ => inner ℝ ξ ξ / 2) χ c r (r⁻¹ • latticeVector ν) u t
  have hC' : 0 ≤ r ^ ((d : ℝ) / 2) * C := by positivity
  have hp (ν : Fin d → ℤ) : ‖packet ν‖ ≤
      (r ^ ((d : ℝ) / 2) * C) * ‖b.repr x ν‖ /
        (1 + ‖latticeVector ν - a‖) ^ (d + M) := by
    have hd := hb c r hr (r⁻¹ • latticeVector ν) u t ht
    have he : r * ‖u + r⁻¹ • latticeVector ν + t • c‖ = ‖latticeVector ν - a‖ := by
      have hh := congrArg norm (rescaled_packet_axis u c t hr.ne' ν)
      simpa only [norm_smul, Real.norm_eq_abs, abs_of_pos hr, a] using hh
    rw [he] at hd
    change ‖b.repr x ν * _‖ ≤ _
    rw [norm_mul]
    exact (mul_le_mul_of_nonneg_left hd (norm_nonneg _)).trans_eq (by ring)
  have hsum := (radial_packet_norm_summable b x a packet hC' M hp).subtype S
  refine ⟨hsum.of_norm, ?_⟩
  have htail := radial_packet_absolute_tail b x a packet hC' hL M hp S hS
  exact htail.trans_eq (by ring)

/-- The article's physical tube radius R^(1/2+τ)/10 becomes R^τ/10 after
rescaling. This implication handles the center and every lattice index. -/
theorem physical_to_rescaled_tube_exclusion {d : ℕ} {R τ : ℝ} (hR : 0 < R)
    (u c : Ambient d) (t : ℝ) (ν : Fin d → ℤ)
    (hν : R ^ (1 / 2 + τ) / 10 ≤
      ‖u + (R ^ (-1 / 2 : ℝ))⁻¹ • latticeVector ν + t • c‖) :
    R ^ τ / 10 ≤
      ‖latticeVector ν - (-((R ^ (-1 / 2 : ℝ)) • (u + t • c)))‖ := by
  have hr : 0 < R ^ (-1 / 2 : ℝ) := Real.rpow_pos_of_pos hR _
  have he : R ^ (-1 / 2 : ℝ) * (R ^ (1 / 2 + τ) / 10) = R ^ τ / 10 := by
    rw [← mul_div_assoc, ← Real.rpow_add hR]
    congr 2
    ring
  have hb := mul_le_mul_of_nonneg_left hν hr.le
  rw [he] at hb
  have hn := congrArg norm (rescaled_packet_axis u c t hr.ne' ν)
  rw [norm_smul, Real.norm_eq_abs, abs_of_pos hr] at hn
  exact hb.trans_eq hn

/-- Rapid decrease, uniform over all packet subcollections outside the actual
enlarged tubes, for one paraboloid cap. Any prescribed polynomial prefactor
is allowed. Assembly over caps and general surface measures is still separate. -/
theorem paraboloid_rapid_selected_packet_tail (d : ℕ) {χ : Ambient d → ℂ}
    (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hs : HasCompactSupport χ)
    {τ : ℝ} (hτ : 0 < τ) (b N : ℝ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (R : ℝ), 1 ≤ R →
      ∀ {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E],
      ∀ (e : HilbertBasis (Fin d → ℤ) ℂ E) (x : E) (c u : Ambient d) (t : ℝ),
      |t| ≤ R → ∀ S : Set (Fin d → ℤ),
      (∀ ν ∈ S, R ^ (1 / 2 + τ) / 10 ≤
        ‖u + (R ^ (-1 / 2 : ℝ))⁻¹ • latticeVector ν + t • c‖) →
      R ^ b * (∑' ν : S, ‖e.repr x ν * graphPacket (fun ξ => inner ℝ ξ ξ / 2) χ c
        (R ^ (-1 / 2 : ℝ)) ((R ^ (-1 / 2 : ℝ))⁻¹ • latticeVector ν) u t‖) ≤
        C * R ^ (-N) * ‖x‖ := by
  obtain ⟨M, hM⟩ := exists_packet_tail_order hτ (b - d / 4) N
  obtain ⟨C, hC, hb⟩ := paraboloid_selected_packet_tail d M hχ hs
  refine ⟨C * 10 ^ M, by positivity, fun R hR E _ _ e x c u t ht S hS => ?_⟩
  have hRp : 0 < R := by linarith
  have hr := Real.rpow_pos_of_pos hRp (-1 / 2 : ℝ)
  have htail := (hb e x c u (R ^ (-1 / 2 : ℝ)) hr t (R ^ τ / 10)
    (parabolic_time_parameter hRp ht) (by positivity) S
    (fun ν hν => physical_to_rescaled_tube_exclusion hRp u c t ν (hS ν hν))).2
  have hscale : R ^ b * (R ^ (-1 / 2 : ℝ)) ^ ((d : ℝ) / 2) = R ^ (b - d / 4) := by
    rw [← Real.rpow_mul hRp.le, ← Real.rpow_add hRp]
    congr 1
    ring
  calc
    _ ≤ R ^ b * ((R ^ (-1 / 2 : ℝ)) ^ ((d : ℝ) / 2) *
        (C / (1 + R ^ τ / 10) ^ M) * ‖x‖) :=
      mul_le_mul_of_nonneg_left htail (Real.rpow_nonneg hRp.le _)
    _ = C * ‖x‖ * (R ^ (b - d / 4) / (1 + R ^ τ / 10) ^ M) := by
      rw [← hscale]
      ring
    _ ≤ C * ‖x‖ * (10 ^ M * R ^ (-N)) :=
      mul_le_mul_of_nonneg_left (hM R hR) (mul_nonneg hC (norm_nonneg _))
    _ = _ := by ring

end N2Restriction
