import N2Restriction.ExtensionRegularity
import N2Restriction.Endpoint
import Mathlib.MeasureTheory.Measure.Lebesgue.EqHaar

namespace N2Restriction
open MeasureTheory
open scoped ENNReal NNReal BigOperators

/-- Exact scaling of the finite-volume factor in Hölder on Euclidean balls. -/
lemma ball_volume_rpow {n : ℕ} (x : Ambient n) {R a : ℝ}
    (hR : 0 < R) (ha : 0 ≤ a) :
    ((volume.restrict (Metric.ball x R)) Set.univ) ^ a =
      (volume (Metric.ball (0 : Ambient n) 1)) ^ a * ENNReal.ofReal (R ^ ((n : ℝ) * a)) := by
  rw [Measure.restrict_apply_univ, Measure.addHaar_ball_of_pos volume x hR]
  simp only [Ambient, finrank_euclideanSpace, Fintype.card_fin]
  rw [ENNReal.mul_rpow_of_nonneg _ _ ha, ENNReal.ofReal_rpow_of_pos (pow_pos hR n)]
  rw [← Real.rpow_natCast, ← Real.rpow_mul hR.le, mul_comm]

/-- The Hölder comparison on a ball, including its center-independent
geometric constant and the exact power of its radius. -/
theorem ball_norm_comparison {n : ℕ} {F : Ambient n → ℂ}
    {x : Ambient n} {R q p : ℝ} (hR : 0 < R) (hq : 0 < q) (hqp : q ≤ p)
    (hF : AEStronglyMeasurable F (volume.restrict (Metric.ball x R))) :
    eLpNorm' F q (volume.restrict (Metric.ball x R)) ≤
      eLpNorm' F p (volume.restrict (Metric.ball x R)) *
      (volume (Metric.ball (0 : Ambient n) 1)) ^ (1 / q - 1 / p) *
      ENNReal.ofReal (R ^ ((n : ℝ) * (1 / q - 1 / p))) := by
  have hgap : 0 ≤ 1 / q - 1 / p := sub_nonneg.mpr (one_div_le_one_div_of_le hq hqp)
  have h := finite_volume_comparison (volume.restrict (Metric.ball x R)) F hF hq hqp
  rw [ball_volume_rpow x hR hgap, ← mul_assoc] at h
  exact h

/-- Concrete endpoint passage for the Fourier extension operator. Finite
surface mass and a measurable parametrization suffice for the regularity;
the strict-range restriction estimates are the sole analytic input. -/
theorem localRestriction_endpoint {n k : ℕ} {Ω : Fin k → Type*}
    [∀ i, MeasurableSpace (Ω i)] {μ : ∀ i, Measure (Ω i)}
    [∀ i, IsFiniteMeasure (μ i)] {ζ : ∀ i, Ω i → Ambient n}
    (hζ : ∀ i, Measurable (ζ i)) {q q₀ : ℝ}
    (hn : 0 < n) (hq : 0 < q) (hqq : q < q₀)
    (hstrict : ∀ p : ℝ, q < p → p < q₀ → LocalRestriction μ ζ p) :
    LocalRestriction μ ζ q := by
  intro ε hε
  obtain ⟨p, hqp, hpq₀, hgap⟩ :=
    exists_strict_exponent hq hqq hε (Nat.cast_pos.mpr hn)
  obtain ⟨C, hC⟩ := hstrict p hqp hpq₀ (ε / 2) (by positivity)
  let V : ℝ≥0∞ := (volume (Metric.ball (0 : Ambient n) 1)) ^ (1 / q - 1 / p)
  have hg : 0 ≤ 1 / q - 1 / p := sub_nonneg.mpr (one_div_le_one_div_of_le hq hqp.le)
  have hV : V ≠ ⊤ := ENNReal.rpow_ne_top_of_nonneg hg measure_ball_lt_top.ne
  refine ⟨C * V.toNNReal, fun R hR x f hf => ?_⟩
  have hRp : 0 < R := by linarith
  have hF := (continuous_extensionProduct hζ hf).aestronglyMeasurable
    (μ := volume.restrict (Metric.ball x R))
  calc
    eLpNorm' (extensionProduct μ ζ f) q (volume.restrict (Metric.ball x R)) ≤
        eLpNorm' (extensionProduct μ ζ f) p (volume.restrict (Metric.ball x R)) * V *
          ENNReal.ofReal (R ^ ((n : ℝ) * (1 / q - 1 / p))) :=
      ball_norm_comparison hRp hq hqp.le hF
    _ ≤ ((C : ℝ≥0∞) * ENNReal.ofReal (R ^ (ε / 2)) * inputNormProduct μ f) * V *
          ENNReal.ofReal (R ^ ((n : ℝ) * (1 / q - 1 / p))) := by
      gcongr
      exact hC R hR x f hf
    _ = ((C * V.toNNReal : ℝ≥0) : ℝ≥0∞) *
          ENNReal.ofReal (R ^ (ε / 2 + (n : ℝ) * (1 / q - 1 / p))) * inputNormProduct μ f := by
      rw [ENNReal.coe_mul, ENNReal.coe_toNNReal hV, Real.rpow_add hRp,
        ENNReal.ofReal_mul (Real.rpow_nonneg hRp.le _)]
      ring
    _ ≤ ((C * V.toNNReal : ℝ≥0) : ℝ≥0∞) * ENNReal.ofReal (R ^ ε) * inputNormProduct μ f := by
      apply mul_le_mul_right'
      apply mul_le_mul_left'
      apply ENNReal.ofReal_le_ofReal
      exact Real.rpow_le_rpow_of_exponent_le (by linarith) (by linarith)

end N2Restriction
