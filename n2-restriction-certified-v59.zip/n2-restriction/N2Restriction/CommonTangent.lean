import N2Restriction.Extension
import N2Restriction.Geometry

namespace N2Restriction

noncomputable def commonTangent {n k : ℕ} (N : Fin k → Ambient n) :
    Submodule ℝ (Ambient n) := (Submodule.span ℝ (Set.range N))ᗮ

/-- The dimension assertion in (1.5), deduced from independent normals. -/
theorem commonTangent_finrank {n k : ℕ} (N : Fin k → Ambient n)
    (hN : LinearIndependent ℝ N) :
    Module.finrank ℝ (commonTangent N) + k = n := by
  have h := (Submodule.span ℝ (Set.range N)).finrank_add_finrank_orthogonal
  rw [finrank_span_eq_card hN] at h
  simpa [commonTangent, add_comm] using h

/-- For n=k+2 the common tangent is precisely a two-plane. -/
theorem commonTangent_two {k : ℕ} (N : Fin k → Ambient (k + 2))
    (hN : LinearIndependent ℝ N) :
    Module.finrank ℝ (commonTangent N) = 2 := by
  have h := commonTangent_finrank N hN
  omega

/-- Every common tangent vector is orthogonal to every given normal. -/
theorem commonTangent_orthogonal {n k : ℕ} (N : Fin k → Ambient n)
    (v : commonTangent N) (i : Fin k) : inner ℝ (N i) (v : Ambient n) = 0 := by
  exact (Submodule.mem_orthogonal _ _).mp v.property (N i)
    (Submodule.subset_span ⟨i, rfl⟩)

/-- A vector orthogonal to every input normal belongs to their common tangent.
This is the converse coordinate criterion to `commonTangent_orthogonal`. -/
theorem mem_commonTangent_of_normal_orthogonality {n k : ℕ}
    (N : Fin k → Ambient n) (v : Ambient n)
    (h : ∀ i, inner ℝ (N i) v = 0) : v ∈ commonTangent N := by
  rw [commonTangent, Submodule.mem_orthogonal]
  intro x hx
  change x ∈ Submodule.span ℝ (Set.range N) at hx
  refine Submodule.span_induction ?_ ?_ ?_ ?_ hx
  · rintro x ⟨i, rfl⟩
    exact h i
  · simp
  · intro x y hx hy hx0 hy0
    rw [inner_add_left, hx0, hy0, add_zero]
  · intro a x hx hx0
    simp [inner_smul_left, hx0]

end N2Restriction
