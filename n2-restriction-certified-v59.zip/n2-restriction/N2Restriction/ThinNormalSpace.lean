import N2Restriction.ShapeSymmetry
import N2Restriction.NearbyPlanes

namespace N2Restriction

/-- At a projected-normal zero, every vector in H is tangent to the surface. -/
theorem plane_tangent_of_projected_normal_zero {n : ℕ} (S : SmoothPatch n)
    (H : Submodule ℝ (Ambient n)) {z : Ambient n}
    (hzero : H.orthogonalProjection (S.normal z) = 0) (h : H) :
    inner ℝ (S.normal z) (h : Ambient n) = 0 :=
  Submodule.inner_left_of_mem_orthogonal h.property
    (Submodule.orthogonalProjection_eq_zero_iff.mp hzero)

/-- Tangent vectors to the thin zero set are orthogonal to N and to every
shape image of H. This derives the tangent characterization in Lemma 4.1. -/
theorem thin_tangent_iff {n : ℕ} (S : SmoothPatch n)
    (H : Submodule ℝ (Ambient n)) {z : Ambient n} (hz : z ∈ S.neighborhood)
    (hzero : H.orthogonalProjection (S.normal z) = 0) (v : Ambient n) :
    thinDifferential S H z v = 0 ↔
      inner ℝ (S.normal z) v = 0 ∧ ∀ h : H, inner ℝ (S.shape z h) v = 0 := by
  have hbase : thinDifferential S H z v = 0 ↔
      inner ℝ (S.normal z) v = 0 ∧ H.orthogonalProjection (S.shape z v) = 0 := by
    simp only [thinDifferential, ContinuousLinearMap.prod_apply,
      ContinuousLinearMap.comp_apply, Prod.mk_eq_zero, S.differential_eq_zero_iff hz]
    simp [SmoothPatch.shape]
  rw [hbase]
  constructor
  · rintro ⟨hv, hp⟩
    refine ⟨hv, fun h => ?_⟩
    rw [S.shape_symmetric_tangent hz h v
      (plane_tangent_of_projected_normal_zero S H hzero h) hv]
    exact Submodule.inner_right_of_mem_orthogonal h.property
      (Submodule.orthogonalProjection_eq_zero_iff.mp hp)
  · rintro ⟨hv, hh⟩
    refine ⟨hv, Submodule.orthogonalProjection_eq_zero_iff.mpr ?_⟩
    rw [Submodule.mem_orthogonal]
    intro h hH
    rw [← S.shape_symmetric_tangent hz h v
      (plane_tangent_of_projected_normal_zero S H hzero ⟨h, hH⟩) hv]
    exact hh ⟨h, hH⟩

/-- Equation (4.2): the normal space of the thin level set is exactly the
span of the original normal and the shape images of the plane H. -/
theorem thin_normal_space {n : ℕ} (S : SmoothPatch n)
    (H : Submodule ℝ (Ambient n)) {z : Ambient n} (hz : z ∈ S.neighborhood)
    (hzero : H.orthogonalProjection (S.normal z) = 0) :
    (LinearMap.ker (thinDifferential S H z).toLinearMap)ᗮ =
      Submodule.span ℝ {S.normal z} ⊔ H.map (S.shape z).toLinearMap := by
  have he : LinearMap.ker (thinDifferential S H z).toLinearMap =
      (Submodule.span ℝ {S.normal z} ⊔ H.map (S.shape z).toLinearMap)ᗮ := by
    ext v
    rw [LinearMap.mem_ker]
    change thinDifferential S H z v = 0 ↔ _
    rw [thin_tangent_iff S H hz hzero]
    rw [← Submodule.inf_orthogonal, Submodule.mem_inf,
      Submodule.mem_orthogonal_singleton_iff_inner_right, Submodule.mem_orthogonal]
    constructor
    · rintro ⟨hv, hh⟩
      refine ⟨hv, ?_⟩
      rintro y ⟨h, hH, rfl⟩
      exact hh ⟨h, hH⟩
    · rintro ⟨hv, hh⟩
      exact ⟨hv, fun h => hh (S.shape z h) (Submodule.mem_map.mpr ⟨h, h.property, rfl⟩)⟩
  rw [he, Submodule.orthogonal_orthogonal]

end N2Restriction
