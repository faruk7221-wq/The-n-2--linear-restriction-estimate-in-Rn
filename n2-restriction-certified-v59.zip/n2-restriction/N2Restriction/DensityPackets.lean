import N2Restriction.DensitySynthesis

namespace N2Restriction
open MeasureTheory
open scoped NNReal ENNReal

/-- Data for an actual positive bounded density; the measure-existence theorem
constructs these bounds for graph surface measures. -/
structure PositiveBoundedDensity {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω) where
  weight : Ω → ℝ≥0
  measurable : Measurable weight
  lower : ℝ
  upper : ℝ
  lower_pos : 0 < lower
  upper_nonneg : 0 ≤ upper
  lower_le : ∀ᵐ x ∂μ, lower ≤ (weight x : ℝ)
  le_upper : ∀ᵐ x ∂μ, (weight x : ℝ) ≤ upper

namespace PositiveBoundedDensity
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω}

noncomputable def measure (D : PositiveBoundedDensity μ) : Measure Ω :=
  μ.withDensity (fun x => (D.weight x : ℝ≥0∞))

theorem weight_ne_zero (D : PositiveBoundedDensity μ) : ∀ᵐ x ∂μ, D.weight x ≠ 0 := by
  filter_upwards [D.lower_le] with x hx
  exact_mod_cast (ne_of_gt (D.lower_pos.trans_le hx))

noncomputable def toCoordinate (D : PositiveBoundedDensity μ) (g : Lp ℂ 2 D.measure) : Lp ℂ 2 μ :=
  multiplyDensityL2 μ D.weight D.measurable D.weight_ne_zero D.upper_nonneg D.le_upper g

noncomputable def fromCoordinate (D : PositiveBoundedDensity μ) : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 D.measure :=
  divideDensityOperator μ D.weight D.measurable D.lower_pos D.lower_le

theorem from_to (D : PositiveBoundedDensity μ) (g : Lp ℂ 2 D.measure) :
    D.fromCoordinate (D.toCoordinate g) = g :=
  divide_multiply_density μ D.weight D.measurable D.lower_pos D.upper_nonneg
    D.lower_le D.le_upper D.weight_ne_zero g

theorem to_from (D : PositiveBoundedDensity μ) (f : Lp ℂ 2 μ) :
    D.toCoordinate (D.fromCoordinate f) = f := by
  have hac : μ ≪ D.measure := withDensity_absolutelyContinuous'
    D.measurable.coe_nnreal_ennreal.aemeasurable
    (D.weight_ne_zero.mono fun x hx => by exact_mod_cast hx)
  apply Lp.ext
  filter_upwards [multiplyDensityL2_coe μ D.weight D.measurable D.weight_ne_zero
    D.upper_nonneg D.le_upper (D.fromCoordinate f),
    hac.ae_le (divideDensityL2_coe μ D.weight D.measurable D.lower_pos D.lower_le f),
    D.weight_ne_zero] with x h1 h2 h0
  change (multiplyDensityL2 μ D.weight D.measurable D.weight_ne_zero D.upper_nonneg D.le_upper (D.fromCoordinate f)) x = f x
  rw [h1]
  change (D.weight x : ℂ) * (D.fromCoordinate f) x = f x
  rw [show (D.fromCoordinate f) x = f x / (D.weight x : ℂ) from h2]
  have hz : (D.weight x : ℂ) ≠ 0 := by exact_mod_cast h0
  field_simp

theorem toCoordinate_energy (D : PositiveBoundedDensity μ) (g : Lp ℂ 2 D.measure) :
    ‖D.toCoordinate g‖ ^ 2 ≤ D.upper * ‖g‖ ^ 2 :=
  multiplyDensityL2_energy μ D.weight D.measurable D.weight_ne_zero D.upper_nonneg D.le_upper g

theorem toCoordinate_norm_le (D : PositiveBoundedDensity μ) (g : Lp ℂ 2 D.measure) :
    ‖D.toCoordinate g‖ ≤ Real.sqrt D.upper * ‖g‖ := by
  have he := D.toCoordinate_energy g
  have hs := Real.sq_sqrt D.upper_nonneg
  have hn := mul_nonneg (Real.sqrt_nonneg D.upper) (norm_nonneg g)
  nlinarith [sq_nonneg (‖D.toCoordinate g‖ - Real.sqrt D.upper * ‖g‖)]

theorem fromCoordinate_energy (D : PositiveBoundedDensity μ) (f : Lp ℂ 2 μ) :
    ‖D.fromCoordinate f‖ ^ 2 ≤ (1 / D.lower) * ‖f‖ ^ 2 :=
  divideDensityL2_energy μ D.weight D.measurable D.lower_pos D.lower_le f

theorem toCoordinate_support {E : Type*} (D : PositiveBoundedDensity μ)
    (g : Lp ℂ 2 D.measure) (ζ : Ω → E) (K : Set E)
    (hg : HasFrequencySupport D.measure ζ K g) :
    HasFrequencySupport μ ζ K (D.toCoordinate g) :=
  multiplyDensityL2_support μ D.weight D.measurable D.weight_ne_zero D.upper_nonneg D.le_upper g ζ K hg

theorem fromCoordinate_extension {n : ℕ} (D : PositiveBoundedDensity μ)
    (f : Lp ℂ 2 μ) (ζ : Ω → Ambient n) (y : Ambient n) :
    extension D.measure ζ (D.fromCoordinate f) y = extension μ ζ f y :=
  extension_divideDensityL2 μ D.weight D.measurable D.lower_pos D.lower_le f ζ y

end PositiveBoundedDensity

namespace CoordinateCapFamily
variable {d : ℕ} {K : Set (Ambient d)} {r : ℝ}

noncomputable def densityPacket (P : CoordinateCapFamily K r) (hr : 0 < r)
    (D : PositiveBoundedDensity (volume : Measure (Ambient d))) (g : Lp ℂ 2 D.measure)
    (j : P.centers) (ν : Fin d → ℤ) : Lp ℂ 2 D.measure :=
  D.fromCoordinate (P.packet hr (D.toCoordinate g) j ν)

/-- Reconstruction of the original weighted input, not an assumed coordinate input. -/
theorem densityPacket_hasSum (P : CoordinateCapFamily K r) (hr : 0 < r)
    (D : PositiveBoundedDensity (volume : Measure (Ambient d))) (g : Lp ℂ 2 D.measure)
    (hg : HasFrequencySupport D.measure id K g) :
    HasSum (fun p : P.centers × (Fin d → ℤ) => P.densityPacket hr D g p.1 p.2) g := by
  have h := D.fromCoordinate.hasSum
    (P.packet_hasSum_original hr (D.toCoordinate g) (D.toCoordinate_support g id K hg))
  simpa only [densityPacket, D.from_to] using h

theorem densityPacket_subcollection_summable (P : CoordinateCapFamily K r) (hr : 0 < r)
    (D : PositiveBoundedDensity (volume : Measure (Ambient d))) (g : Lp ℂ 2 D.measure)
    (S : Set (P.centers × (Fin d → ℤ))) :
    Summable (fun p : S => P.densityPacket hr D g p.val.1 p.val.2) :=
  (D.fromCoordinate.hasSum (P.packet_subcollection_summable hr (D.toCoordinate g) S).hasSum).summable

theorem densityPacket_extension {n : ℕ} (P : CoordinateCapFamily K r) (hr : 0 < r)
    (D : PositiveBoundedDensity (volume : Measure (Ambient d))) (g : Lp ℂ 2 D.measure)
    (j : P.centers) (ν : Fin d → ℤ) (ζ : Ambient d → Ambient n) (y : Ambient n) :
    extension D.measure ζ (P.densityPacket hr D g j ν) y =
      extension volume ζ (P.packet hr (D.toCoordinate g) j ν) y :=
  D.fromCoordinate_extension _ ζ y

theorem densityPacket_support (P : CoordinateCapFamily K r) (hr : 0 < r)
    (D : PositiveBoundedDensity (volume : Measure (Ambient d))) (g : Lp ℂ 2 D.measure)
    (j : P.centers) (ν : Fin d → ℤ) :
    HasFrequencySupport D.measure id (Metric.ball (j : Ambient d) (2 * r))
      (P.densityPacket hr D g j ν) :=
  divideDensityL2_support volume D.weight D.measurable D.lower_pos D.lower_le _ id _
    (P.packet_frequency_support hr (D.toCoordinate g) j ν)

/-- Uniform reconstruction survives the density transfer because every extension term is unchanged. -/
theorem densityPacket_uniform_extension {n : ℕ} (P : CoordinateCapFamily K r) (hr : 0 < r)
    (hK : IsCompact K) (D : PositiveBoundedDensity (volume : Measure (Ambient d)))
    (g : Lp ℂ 2 D.measure) (hg : HasFrequencySupport D.measure id K g)
    (ζ : Ambient d → Ambient n) (hζ : Measurable ζ) : ∀ ε : ℝ, 0 < ε →
      ∀ᶠ S : Finset (P.centers × (Fin d → ℤ)) in Filter.atTop, ∀ y : Ambient n,
        dist (∑ p ∈ S, extension D.measure ζ (P.densityPacket hr D g p.1 p.2) y)
          (extension D.measure ζ g y) < ε := by
  have he : ∀ y, extension D.measure ζ g y = extension volume ζ (D.toCoordinate g) y := by
    intro y
    simpa only [D.from_to] using D.fromCoordinate_extension (D.toCoordinate g) ζ y
  simpa only [densityPacket_extension, he] using
    P.packet_uniform_extension_reconstruction hK hr (D.toCoordinate g)
      (D.toCoordinate_support g id K hg) ζ hζ

/-- The packet energy budget depends only on the density ratio and the original weighted input. -/
theorem densityPacket_total_energy (P : CoordinateCapFamily K r) (hr : 0 < r)
    (D : PositiveBoundedDensity (volume : Measure (Ambient d))) (g : Lp ℂ 2 D.measure) :
    (∑ j, ∑' ν, ‖P.densityPacket hr D g j ν‖ ^ 2) ≤
      (D.upper / D.lower) * (packetCutoffEnergy d * (2 * Real.pi) ^ (-(d : ℝ))) * ‖g‖ ^ 2 := by
  have hl : 0 ≤ 1 / D.lower := (one_div_pos.mpr D.lower_pos).le
  have hk : 0 ≤ packetCutoffEnergy d * (2 * Real.pi) ^ (-(d : ℝ)) :=
    mul_nonneg (packetCutoffEnergy_pos d).le (Real.rpow_nonneg (by positivity) _)
  have he (j : P.centers) := divideDensityL2_tsum_energy volume D.weight D.measurable
    D.lower_pos D.lower_le (P.packet hr (D.toCoordinate g) j)
    (actualPacketInput_energy_summable (j : Ambient d) r hr (P.input hr (D.toCoordinate g) j))
  calc
    _ ≤ ∑ j, (1 / D.lower) * ∑' ν, ‖P.packet hr (D.toCoordinate g) j ν‖ ^ 2 :=
      Finset.sum_le_sum (fun j _ => (he j).2)
    _ = (1 / D.lower) * ∑ j, ∑' ν, ‖P.packet hr (D.toCoordinate g) j ν‖ ^ 2 := by rw [Finset.mul_sum]
    _ ≤ (1 / D.lower) * (packetCutoffEnergy d * (2 * Real.pi) ^ (-(d : ℝ)) * ‖D.toCoordinate g‖ ^ 2) :=
      mul_le_mul_of_nonneg_left (P.packet_total_energy hr _) hl
    _ ≤ (1 / D.lower) * (packetCutoffEnergy d * (2 * Real.pi) ^ (-(d : ℝ)) * (D.upper * ‖g‖ ^ 2)) := by
      exact mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left (D.toCoordinate_energy g) hk) hl
    _ = _ := by ring

end CoordinateCapFamily
end N2Restriction
