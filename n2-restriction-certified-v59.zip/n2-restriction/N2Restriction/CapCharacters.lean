import N2Restriction.CapNormalization
import N2Restriction.GraphAtomEnergy
open MeasureTheory UnitAddTorus
namespace N2Restriction
theorem capAffine_symm_apply {d : ℕ} (c : Ambient d) (r : ℝ) (hr : r ≠ 0) (ξ : Ambient d) :
    (capAffine c r hr).symm ξ = WithLp.ofLp (r⁻¹ • (ξ - c)) := by
  change WithLp.ofLp (r⁻¹ • (-c + ξ)) = _
  rw [sub_eq_add_neg, add_comm ξ (-c)]

/-- Exact character convention for lattice modulation at spatial spacing r inverse. -/
theorem scaled_fourier_character {d : ℕ} (ν : Fin d → ℤ) (η : Ambient d) (r : ℝ) :
    mFourier ν (fun j => ((η j / (2 * Real.pi * r) : ℝ) : UnitAddCircle)) =
      Complex.exp ((inner ℝ (r⁻¹ • latticeVector ν) η : ℂ) * Complex.I) := by
  simp only [mFourier, ContinuousMap.coe_mk, fourier_coe_apply]
  rw [← Complex.exp_sum]
  congr 1
  simp only [PiLp.inner_apply, latticeVector, PiLp.toLp_apply, PiLp.smul_apply,
    smul_eq_mul, RCLike.inner_apply, RCLike.conj_to_real, Complex.ofReal_sum, Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro j _
  push_cast
  field_simp

/-- The Fourier modes of a cube of side 2πr have exactly the packet lattice frequency. -/
theorem cap_fourier_atom_character {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : 0 < r) (ν : Fin d → ℤ) :
    ∀ᵐ ξ ∂capProbability t c (2 * Real.pi * r) (by positivity),
      capFourierAtom t c (2 * Real.pi * r) (by positivity) ν ξ =
        Complex.exp ((inner ℝ (r⁻¹ • latticeVector ν) (ξ - c) : ℂ) * Complex.I) := by
  filter_upwards [cap_fourier_atom_coe t c (2 * Real.pi * r) (by positivity) ν] with ξ hξ
  rw [hξ, capAffine_symm_apply]
  convert scaled_fourier_character ν (ξ - c) r using 1
  congr 1
  funext j
  simp [cubeQuotient, PiLp.smul_apply, smul_eq_mul, div_eq_mul_inv, mul_comm]

/-- Translation of the cap center contributes only a constant phase. -/
theorem packet_character_translation {d : ℕ} (v c ξ : Ambient d) :
    Complex.exp ((inner ℝ v (ξ - c) : ℂ) * Complex.I) =
      Complex.exp (-((inner ℝ v c : ℂ) * Complex.I)) *
        Complex.exp ((inner ℝ v ξ : ℂ) * Complex.I) := by
  rw [inner_sub_right, Complex.ofReal_sub, sub_mul, Complex.exp_sub,
    Complex.exp_neg, div_eq_mul_inv, mul_comm]

/-- The fixed 2π factor relating an orthonormal cube mode to the graph-atom convention. -/
theorem cap_packet_normalization {d : ℕ} (r : ℝ) (hr : 0 < r) :
    (2 * Real.pi * r) ^ (-(d : ℝ) / 2) =
      (2 * Real.pi) ^ (-(d : ℝ) / 2) * r ^ (-(d : ℝ) / 2) := by
  exact Real.mul_rpow (by positivity) hr.le

/-- The cutoff Fourier mode is exactly the previously constructed graph atom,
up to a fixed normalization and a unit-modulus phase depending on the cap center. -/
theorem cap_cutoff_mode_eq_graphAtom {d : ℕ} (t : Fin d → ℝ) (χ : Ambient d → ℂ)
    (c : Ambient d) (r : ℝ) (hr : 0 < r) (ν : Fin d → ℤ) :
    ∀ᵐ ξ ∂capProbability t c (2 * Real.pi * r) (by positivity),
      ((2 * Real.pi * r) ^ (-(d : ℝ) / 2) : ℝ) *
        capFourierAtom t c (2 * Real.pi * r) (by positivity) ν ξ * χ (r⁻¹ • (ξ - c)) =
      ((2 * Real.pi) ^ (-(d : ℝ) / 2) : ℝ) *
        Complex.exp (-((inner ℝ (r⁻¹ • latticeVector ν) c : ℂ) * Complex.I)) *
          graphAtom χ c r (r⁻¹ • latticeVector ν) ξ := by
  filter_upwards [cap_fourier_atom_character t c r hr ν] with ξ hξ
  rw [hξ, packet_character_translation, cap_packet_normalization r hr]
  simp only [graphAtom, Complex.ofReal_mul]
  ring

end N2Restriction
