import N2Restriction.ZeroExtension
import N2Restriction.CapSupport

namespace N2Restriction
open MeasureTheory Set

/-- Convert normalized cap L2 to ordinary Euclidean L2 by exact measure conversion
and zero extension. -/
noncomputable def euclideanCapSynthesis {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : 0 < r) : Lp ℂ 2 (capProbability t c r hr.ne') →L[ℂ]
      Lp ℂ 2 (volume : Measure (Ambient d)) :=
  (zeroExtendIsometry volume (scaledCube t c r hr.ne')
    (scaledCube_measurable t c r hr.ne')).toContinuousLinearMap.comp (capLebesgueOperator t c r hr)

theorem euclideanCapSynthesis_norm {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : 0 < r) (f : Lp ℂ 2 (capProbability t c r hr.ne')) :
    ‖euclideanCapSynthesis t c r hr f‖ = r ^ ((d : ℝ) / 2) * ‖f‖ := by
  change ‖zeroExtendIsometry volume (scaledCube t c r hr.ne')
    (scaledCube_measurable t c r hr.ne') (capLebesgueOperator t c r hr f)‖ = _
  rw [LinearIsometry.norm_map]
  exact capLebesgueL2_norm t c r hr f

/-- The synthesized function equals the original cap function inside and zero outside. -/
theorem euclideanCapSynthesis_coe {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : 0 < r) (f : Lp ℂ 2 (capProbability t c r hr.ne')) :
    euclideanCapSynthesis t c r hr f =ᵐ[volume] (scaledCube t c r hr.ne').indicator f := by
  have h := (ae_restrict_iff' (scaledCube_measurable t c r hr.ne')).mp (capLebesgueL2_coe t c r hr f)
  filter_upwards [zeroExtendL2_coe volume (scaledCube t c r hr.ne')
    (scaledCube_measurable t c r hr.ne') (capLebesgueOperator t c r hr f), h] with ξ hξ hf
  change euclideanCapSynthesis t c r hr f ξ = _ at hξ
  rw [hξ]
  by_cases hm : ξ ∈ scaledCube t c r hr.ne'
  · simp only [indicator_of_mem hm]
    exact hf hm
  · simp only [indicator_of_notMem hm]

/-- Fourier reconstruction of every ordinary cap L2 input after zero extension. -/
theorem euclidean_cap_reconstruction {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : 0 < r) (f : Lp ℂ 2 (volume.restrict (scaledCube t c r hr.ne'))) :
    HasSum (fun ν => capFourierCoeff t c r hr.ne' (normalizedCapInput t c r hr f) ν •
      euclideanCapSynthesis t c r hr (capFourierAtom t c r hr.ne' ν))
      (zeroExtendL2 volume (scaledCube t c r hr.ne') (scaledCube_measurable t c r hr.ne') f) := by
  have h := cap_fourier_synthesis t c r hr.ne' (euclideanCapSynthesis t c r hr)
    (normalizedCapInput t c r hr f)
  simpa only [euclideanCapSynthesis, ContinuousLinearMap.comp_apply,
    capLebesgue_normalizedInput] using h

/-- Actual cutoff Fourier decomposition, now in ordinary Euclidean L2. The cutoff
hypothesis is only that it equals one wherever the original input is nonzero. -/
theorem euclidean_cap_cutoff_reconstruction {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : 0 < r) (χ : Ambient d → ℂ)
    (hχ : AEStronglyMeasurable χ (capProbability t c r hr.ne'))
    {C : ℝ} (hC : ∀ᵐ ξ ∂capProbability t c r hr.ne', ‖χ ξ‖ ≤ C)
    (f : Lp ℂ 2 (volume.restrict (scaledCube t c r hr.ne')))
    (hf : ∀ᵐ ξ ∂volume.restrict (scaledCube t c r hr.ne'), f ξ ≠ 0 → χ ξ = 1) :
    HasSum (fun ν => capFourierCoeff t c r hr.ne' (normalizedCapInput t c r hr f) ν •
      euclideanCapSynthesis t c r hr (cutoffOperator χ hχ hC (capFourierAtom t c r hr.ne' ν)))
      (zeroExtendL2 volume (scaledCube t c r hr.ne') (scaledCube_measurable t c r hr.ne') f) := by
  have hf' : ∀ᵐ ξ ∂capProbability t c r hr.ne', normalizedCapInput t c r hr f ξ ≠ 0 → χ ξ = 1 := by
    rw [← capProbability_ae_eq t c r hr] at hf
    filter_upwards [normalizedCapInput_coe t c r hr f, hf] with ξ hξ hχξ
    simpa only [hξ] using hχξ
  have h := (euclideanCapSynthesis t c r hr).hasSum
    (cap_cutoff_reconstruction t c r hr.ne' χ hχ hC (normalizedCapInput t c r hr f) hf')
  simpa only [map_smul, euclideanCapSynthesis, ContinuousLinearMap.comp_apply,
    capLebesgue_normalizedInput] using h

end N2Restriction
