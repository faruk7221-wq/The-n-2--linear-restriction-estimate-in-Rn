import N2Restriction.FiniteCapCover
import Mathlib.Topology.PartitionOfUnity

namespace N2Restriction
open MeasureTheory

/-- Inner radius 3r/4 leaves room before the radius-r input cap boundary. -/
noncomputable def capPartitionBump {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r) : ContDiffBump c :=
  ⟨3 * r / 4, r, by positivity, by linarith⟩

/-- A finite inner-ball cover gives concrete smooth bump data. -/
noncomputable def capBumpCover {d : ℕ} {ι : Type*} [Fintype ι]
    (K : Set (Ambient d)) (c : ι → Ambient d) (r : ℝ) (hr : 0 < r)
    (hc : ∀ x ∈ K, ∃ j, dist x (c j) < 3 * r / 4) : BumpCovering ι (Ambient d) K where
  toFun j := ⟨capPartitionBump (c j) r hr, (capPartitionBump (c j) r hr).continuous⟩
  locallyFinite' := locallyFinite_of_finite _
  nonneg' j x := (capPartitionBump (c j) r hr).nonneg
  le_one' j x := (capPartitionBump (c j) r hr).le_one
  eventuallyEq_one' x hx := by
    obtain ⟨j, hj⟩ := hc x hx
    exact ⟨j, (capPartitionBump (c j) r hr).eventuallyEq_one_of_mem_ball hj⟩

noncomputable def capPartition {d : ℕ} {ι : Type*} [Fintype ι]
    (K : Set (Ambient d)) (c : ι → Ambient d) (r : ℝ) (hr : 0 < r)
    (hc : ∀ x ∈ K, ∃ j, dist x (c j) < 3 * r / 4) : PartitionOfUnity ι (Ambient d) K :=
  (capBumpCover K c r hr hc).toPartitionOfUnity

/-- Smoothness is proved using the finite product formula for the partition. -/
theorem capPartition_smooth {d : ℕ} {ι : Type*} [Fintype ι]
    (K : Set (Ambient d)) (c : ι → Ambient d) (r : ℝ) (hr : 0 < r)
    (hc : ∀ x ∈ K, ∃ j, dist x (c j) < 3 * r / 4) (j : ι) :
    ContDiff ℝ (⊤ : ℕ∞) (capPartition K c r hr hc j) := by
  classical
  have he : (capPartition K c r hr hc j : Ambient d → ℝ) = fun x =>
      capPartitionBump (c j) r hr x * ∏ k ∈ Finset.univ.filter (fun k => WellOrderingRel k j),
        (1 - capPartitionBump (c k) r hr x) := by
    funext x
    exact (capBumpCover K c r hr hc).toPartitionOfUnity_eq_mul_prod j x Finset.univ (by simp)
  rw [he]
  exact (capPartitionBump (c j) r hr).contDiff.mul
    (contDiff_prod (fun k _ => contDiff_const.sub (capPartitionBump (c k) r hr).contDiff))

theorem capPartition_support {d : ℕ} {ι : Type*} [Fintype ι]
    (K : Set (Ambient d)) (c : ι → Ambient d) (r : ℝ) (hr : 0 < r)
    (hc : ∀ x ∈ K, ∃ j, dist x (c j) < 3 * r / 4) (j : ι) :
    Function.support (capPartition K c r hr hc j) ⊆ Metric.ball (c j) r := by
  have h := (capBumpCover K c r hr hc).support_toPartitionOfUnity_subset j
  apply h.trans
  change Function.support (capPartitionBump (c j) r hr) ⊆ _
  rw [ContDiffBump.support_eq]
  exact Set.Subset.rfl

theorem capPartition_sum {d : ℕ} {ι : Type*} [Fintype ι]
    (K : Set (Ambient d)) (c : ι → Ambient d) (r : ℝ) (hr : 0 < r)
    (hc : ∀ x ∈ K, ∃ j, dist x (c j) < 3 * r / 4) {x : Ambient d} (hx : x ∈ K) :
    ∑ j, capPartition K c r hr hc j x = 1 := by
  simpa only [finsum_eq_sum_of_fintype] using (capPartition K c r hr hc).sum_eq_one hx

/-- The partition has pointwise squared-weight budget one, even off the input support. -/
theorem capPartition_square_sum_le {d : ℕ} {ι : Type*} [Fintype ι]
    (K : Set (Ambient d)) (c : ι → Ambient d) (r : ℝ) (hr : 0 < r)
    (hc : ∀ x ∈ K, ∃ j, dist x (c j) < 3 * r / 4) (x : Ambient d) :
    (∑ j, (capPartition K c r hr hc j x) ^ 2) ≤ 1 := by
  have h (j) : (capPartition K c r hr hc j x) ^ 2 ≤ capPartition K c r hr hc j x := by
    have h0 := (capPartition K c r hr hc).nonneg j x
    have h1 := (capPartition K c r hr hc).le_one j x
    nlinarith
  exact (Finset.sum_le_sum (fun j _ => h j)).trans (by
    simpa only [finsum_eq_sum_of_fintype] using (capPartition K c r hr hc).sum_le_one x)

/-- The cap partition is constructed for every compact coordinate support. -/
theorem exists_compact_cap_partition {d : ℕ} {K : Set (Ambient d)} (hK : IsCompact K)
    {r : ℝ} (hr : 0 < r) :
    ∃ (t : Finset (Ambient d)) (ρ : PartitionOfUnity t (Ambient d) K),
      (↑t : Set (Ambient d)) ⊆ K ∧
      (↑t : Set (Ambient d)).Pairwise (fun x y => r / 2 < dist x y) ∧
      (∀ j, ContDiff ℝ (⊤ : ℕ∞) (ρ j)) ∧
      (∀ j, Function.support (ρ j) ⊆ Metric.ball (j : Ambient d) r) ∧
      (∀ x, (∑ j, (ρ j x) ^ 2) ≤ 1) := by
  obtain ⟨t, htK, htsep, htcover⟩ := compact_separated_cap_cover hK hr
  have hc : ∀ x ∈ K, ∃ j : t, dist x (j : Ambient d) < 3 * r / 4 := by
    intro x hx
    obtain ⟨j, hj, hdist⟩ := htcover x hx
    exact ⟨⟨j, hj⟩, hdist⟩
  exact ⟨t, capPartition K (fun j : t => j.val) r hr hc, htK, htsep,
    capPartition_smooth K _ r hr hc, capPartition_support K _ r hr hc,
    capPartition_square_sum_le K _ r hr hc⟩

end N2Restriction
