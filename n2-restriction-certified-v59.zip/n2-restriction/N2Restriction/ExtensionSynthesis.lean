import N2Restriction.ExtensionRegularity
import N2Restriction.HilbertPackets
import Mathlib.MeasureTheory.Function.L2Space

namespace N2Restriction
open MeasureTheory
open scoped ComplexConjugate ENNReal
noncomputable section
variable {n : ℕ} {Ω ι : Type*} [MeasurableSpace Ω]
variable (μ : Measure Ω) [IsFiniteMeasure μ] (ζ : Ω → Ambient n) (hζ : Measurable ζ)

/-- The conjugate phase is an actual L2 vector on the frequency patch. -/
def extensionPhase (x : Ambient n) : Lp ℂ 2 μ :=
  (show MemLp (fun ω => conj (Complex.exp ((inner ℝ x (ζ ω) : ℂ) * Complex.I))) 2 μ from by
    apply (memLp_const (1 : ℂ)).of_le
    · have hk : Measurable (fun ω => conj (Complex.exp ((inner ℝ x (ζ ω) : ℂ) * Complex.I))) := by
        fun_prop
      exact hk.aestronglyMeasurable
    · exact Filter.Eventually.of_forall (fun ω => by simp)).toLp _

/-- Fourier evaluation is a bounded linear functional on the actual L2 space. -/
def extensionEvaluation (x : Ambient n) : Lp ℂ 2 μ →L[ℂ] ℂ :=
  innerSL ℂ (extensionPhase μ ζ hζ x)

/-- The bounded functional agrees with the article's oscillatory integral. -/
theorem extensionEvaluation_eq (x : Ambient n) (f : Lp ℂ 2 μ) :
    extensionEvaluation μ ζ hζ x f = extension μ ζ f x := by
  change inner ℂ (extensionPhase μ ζ hζ x) f = _
  rw [L2.inner_def]
  apply integral_congr_ae
  have hp : (extensionPhase μ ζ hζ x : Ω → ℂ) =ᵐ[μ]
      (fun ω => conj (Complex.exp ((inner ℝ x (ζ ω) : ℂ) * Complex.I))) :=
    MemLp.coeFn_toLp _
  filter_upwards [hp] with ω hω
  simp [hω, RCLike.inner_apply, mul_comm]

include hζ

/-- An unconditional L2 expansion gives an unconditional expansion of the
actual extension at every physical point. -/
theorem extension_hasSum_of_L2 {f : ι → Lp ℂ 2 μ} {g : Lp ℂ 2 μ}
    (hf : HasSum f g) (x : Ambient n) :
    HasSum (fun i => extension μ ζ (f i) x) (extension μ ζ g x) := by
  simpa only [extensionEvaluation_eq] using (extensionEvaluation μ ζ hζ x).hasSum hf

/-- The actual Fourier extension therefore reconstructs from any Hilbert
basis expansion of the original L2 input. -/
theorem extension_hilbert_reconstruction (b : HilbertBasis ι ℂ (Lp ℂ 2 μ))
    (f : Lp ℂ 2 μ) (x : Ambient n) :
    HasSum (fun i => extension μ ζ (b.repr f i • b i : Lp ℂ 2 μ) x) (extension μ ζ f x) :=
  extension_hasSum_of_L2 μ ζ hζ (b.hasSum_repr f) x

/-- Selection budgets apply to the actual extension evaluation functional. -/
theorem extension_selected_synthesis (b : HilbertBasis ι ℂ (Lp ℂ 2 μ))
    (f : Lp ℂ 2 μ) (x : Ambient n) (S : Set ι) :
    ‖∑' i : S, extension μ ζ (b.repr f i • b i : Lp ℂ 2 μ) x‖ ^ 2 ≤
      ‖extensionEvaluation μ ζ hζ x‖ ^ 2 * ∑' i : S, ‖b.repr f i‖ ^ 2 := by
  simpa only [extensionEvaluation_eq] using
    bounded_packet_selection b (extensionEvaluation μ ζ hζ x) f S

/-- The evaluation operator norm is independent of the physical point. -/
theorem extensionEvaluation_norm (x : Ambient n) :
    ‖extensionEvaluation μ ζ hζ x‖ = (eLpNorm (fun _ : Ω => (1 : ℂ)) 2 μ).toReal := by
  rw [extensionEvaluation, innerSL_apply_norm, Lp.norm_def]
  congr 1
  apply eLpNorm_congr_norm_ae
  have hp : (extensionPhase μ ζ hζ x : Ω → ℂ) =ᵐ[μ]
      (fun ω => conj (Complex.exp ((inner ℝ x (ζ ω) : ℂ) * Complex.I))) :=
    MemLp.coeFn_toLp _
  filter_upwards [hp] with ω hω
  simp [hω]

/-- An unconditional L2 expansion of frequency data yields uniform convergence
of its Fourier extension over the entire physical space. -/
theorem extension_uniform_synthesis {f : ι → Lp ℂ 2 μ} {g : Lp ℂ 2 μ}
    (hf : HasSum f g) : ∀ ε : ℝ, 0 < ε →
    ∀ᶠ s : Finset ι in Filter.atTop, ∀ x : Ambient n,
      dist (∑ i ∈ s, extension μ ζ (f i) x) (extension μ ζ g x) < ε := by
  intro ε hε
  let C := (eLpNorm (fun _ : Ω => (1 : ℂ)) 2 μ).toReal
  have hC : 0 ≤ C := ENNReal.toReal_nonneg
  have hδ : 0 < ε / (C + 1) := div_pos hε (by linarith)
  have hh : ∀ᶠ s : Finset ι in Filter.atTop,
      dist (∑ i ∈ s, f i) g < ε / (C + 1) :=
    hf.eventually (Metric.ball_mem_nhds g hδ)
  filter_upwards [hh] with s hs
  intro x
  let T := extensionEvaluation μ ζ hζ x
  have he : dist (∑ i ∈ s, extension μ ζ (f i) x) (extension μ ζ g x) =
      ‖T ((∑ i ∈ s, f i) - g)‖ := by
    rw [map_sub, map_sum]
    simp only [T, extensionEvaluation_eq, dist_eq_norm]
  rw [he]
  have hnorm : ‖T‖ = C := extensionEvaluation_norm μ ζ hζ x
  calc
    ‖T ((∑ i ∈ s, f i) - g)‖ ≤ C * dist (∑ i ∈ s, f i) g := by
      simpa only [hnorm, dist_eq_norm] using T.le_opNorm ((∑ i ∈ s, f i) - g)
    _ ≤ (C + 1) * dist (∑ i ∈ s, f i) g :=
      mul_le_mul_of_nonneg_right (by linarith) dist_nonneg
    _ < (C + 1) * (ε / (C + 1)) :=
      mul_lt_mul_of_pos_left hs (by linarith)
    _ = ε := by field_simp

end
end N2Restriction
