import N2Restriction.Basic

/-! Radius induction without monotonicity. This is the induction mechanism in
Section 8. The analytic estimate yielding the recurrence is a separate obligation.
The theorem works for arbitrary positive weights and a finite number of children. -/

namespace N2Restriction
open scoped BigOperators

/-- Close a normalized contracting recurrence on the entire real radius axis.
The hypotheses allow arbitrary nonmonotone A and nonmonotone child maps.
The constant is chosen explicitly before induction. -/
theorem close_radius_recurrence {I : Type*} [Fintype I]
    (A W : ℝ → ℝ) (child coeff : I → ℝ → ℝ) (F : ℝ → ℝ)
    (R₀ q B C₀ : ℝ) (hR₀ : 1 ≤ R₀) (hq : q < 1)
    (hW : ∀ R, 1 ≤ R → 0 < W R)
    (hc : ∀ i R, R₀ < R → 0 ≤ coeff i R)
    (hchild : ∀ i R, R₀ < R → 1 ≤ child i R ∧ child i R ≤ R / 2)
    (hbase : ∀ R, 1 ≤ R → R ≤ R₀ → A R ≤ C₀ * W R)
    (hrec : ∀ R, R₀ < R → A R ≤ (∑ i, coeff i R * A (child i R)) + F R)
    (hbudget : ∀ R, R₀ < R → (∑ i, coeff i R * W (child i R)) ≤ q * W R)
    (hforce : ∀ R, R₀ < R → F R ≤ B * W R) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ R, 1 ≤ R → A R ≤ C * W R := by
  let C := max 0 (max C₀ (B / (1 - q)))
  have hC : 0 ≤ C := le_max_left _ _
  have hC₀ : C₀ ≤ C := (le_max_left _ _).trans (le_max_right _ _)
  have hCB : B / (1 - q) ≤ C := (le_max_right _ _).trans (le_max_right _ _)
  have hqpos : 0 < 1 - q := by linarith
  have hB : B ≤ C * (1 - q) := (div_le_iff₀ hqpos).mp hCB
  have hdyadic : ∀ n : ℕ, ∀ R : ℝ, 1 ≤ R → R ≤ 2 ^ n * R₀ → A R ≤ C * W R := by
    intro n
    induction n with
    | zero =>
        intro R hR hbound
        simp only [pow_zero, one_mul] at hbound
        exact (hbase R hR hbound).trans
          (mul_le_mul_of_nonneg_right hC₀ (hW R hR).le)
    | succ n ih =>
        intro R hR hbound
        by_cases hsmall : R ≤ R₀
        · exact (hbase R hR hsmall).trans
            (mul_le_mul_of_nonneg_right hC₀ (hW R hR).le)
        have hlarge : R₀ < R := lt_of_not_ge hsmall
        have hsub : ∀ i, A (child i R) ≤ C * W (child i R) := by
          intro i
          obtain ⟨hlo, hhi⟩ := hchild i R hlarge
          apply ih _ hlo
          rw [pow_succ] at hbound
          nlinarith
        calc
          A R ≤ (∑ i, coeff i R * A (child i R)) + F R := hrec R hlarge
          _ ≤ (∑ i, coeff i R * (C * W (child i R))) + B * W R := by
            apply add_le_add
            · exact Finset.sum_le_sum fun i _ =>
                mul_le_mul_of_nonneg_left (hsub i) (hc i R hlarge)
            · exact hforce R hlarge
          _ = C * (∑ i, coeff i R * W (child i R)) + B * W R := by
            rw [Finset.mul_sum]
            congr 1
            apply Finset.sum_congr rfl
            intro i _
            ring
          _ ≤ C * (q * W R) + B * W R := by
            exact add_le_add_right (mul_le_mul_of_nonneg_left (hbudget R hlarge) hC) _
          _ ≤ C * W R := by nlinarith [mul_le_mul_of_nonneg_right hB (hW R hR).le]
  refine ⟨C, hC, ?_⟩
  intro R hR
  obtain ⟨n, hn⟩ := pow_unbounded_of_one_lt (R / R₀) (by norm_num : (1 : ℝ) < 2)
  apply hdyadic n R hR
  have hR₀pos : 0 < R₀ := by linarith
  exact ((div_lt_iff₀ hR₀pos).mp hn).le

end N2Restriction
