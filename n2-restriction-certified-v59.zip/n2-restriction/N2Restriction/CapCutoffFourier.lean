import N2Restriction.CapCharacters

namespace N2Restriction
open MeasureTheory UnitAddTorus
noncomputable local instance capCutoffCircleMeasure : MeasureSpace UnitAddCircle := ⟨AddCircle.haarAddCircle⟩
variable {d : ℕ} (t : Fin d → ℝ) (c : Ambient d) (r : ℝ) (hr : r ≠ 0)
variable (χ : Ambient d → ℂ) (hχ : AEStronglyMeasurable χ (capProbability t c r hr))
  {C : ℝ} (hC : ∀ᵐ ξ ∂capProbability t c r hr, ‖χ ξ‖ ≤ C)

/-- Concrete cutoff synthesis from torus Fourier coefficients to the actual cap. -/
noncomputable def capCutoffSynthesis :
    Lp ℂ 2 (volume : Measure (UnitAddTorus (Fin d))) →L[ℂ]
      Lp ℂ 2 (capProbability t c r hr) :=
  (cutoffOperator χ hχ hC).comp (torusCapEquiv t c r hr).toContinuousLinearEquiv.toContinuousLinearMap

theorem capCutoffSynthesis_norm_le (hC0 : 0 ≤ C) :
    ‖capCutoffSynthesis t c r hr χ hχ hC‖ ≤ C := by
  apply ContinuousLinearMap.opNorm_le_bound _ hC0
  intro f
  exact (cutoffL2_norm_le χ hχ hC _).trans_eq
    (congrArg (fun z : ℝ => C * z) ((torusCapEquiv t c r hr).norm_map f))

/-- The cutoff modes reconstruct every cap input on whose support the cutoff is one. -/
theorem cap_cutoff_reconstruction (f : Lp ℂ 2 (capProbability t c r hr))
    (hf : ∀ᵐ ξ ∂capProbability t c r hr, f ξ ≠ 0 → χ ξ = 1) :
    HasSum (fun ν => capFourierCoeff t c r hr f ν •
      cutoffOperator χ hχ hC (capFourierAtom t c r hr ν)) f := by
  simpa only [cutoffOperator_eq_self χ hχ hC f hf] using
    cap_fourier_synthesis t c r hr (cutoffOperator χ hχ hC) f

/-- Exact common cutoff-mode norm on the actual cap. -/
theorem cap_cutoff_atom_norm (ν : Fin d → ℤ) :
    ‖cutoffOperator χ hχ hC (capFourierAtom t c r hr ν)‖ =
      (eLpNorm χ 2 (capProbability t c r hr)).toReal := by
  rw [Lp.norm_def]
  congr 1
  apply eLpNorm_congr_norm_ae
  filter_upwards [cutoffL2_coe χ hχ hC (capFourierAtom t c r hr ν),
    cap_fourier_atom_coe t c r hr ν] with ξ hx hν
  change ‖cutoffL2 χ hχ hC (capFourierAtom t c r hr ν) ξ‖ = _
  rw [hx, norm_mul, hν, norm_mFourier_apply, mul_one]

theorem cap_cutoff_packet_norm (f : Lp ℂ 2 (capProbability t c r hr)) (ν : Fin d → ℤ) :
    ‖capFourierCoeff t c r hr f ν • cutoffOperator χ hχ hC (capFourierAtom t c r hr ν)‖ =
      ‖capFourierCoeff t c r hr f ν‖ * (eLpNorm χ 2 (capProbability t c r hr)).toReal := by
  rw [norm_smul, cap_cutoff_atom_norm]

/-- Exact total packet energy, derived from the cap input. -/
theorem cap_cutoff_total_energy (f : Lp ℂ 2 (capProbability t c r hr)) :
    (∑' ν, ‖capFourierCoeff t c r hr f ν •
      cutoffOperator χ hχ hC (capFourierAtom t c r hr ν)‖ ^ 2) =
      (eLpNorm χ 2 (capProbability t c r hr)).toReal ^ 2 * ‖f‖ ^ 2 := by
  simp_rw [cap_cutoff_packet_norm, mul_pow]
  rw [tsum_mul_right, cap_fourier_energy, mul_comm]

/-- Arbitrary packet subcollections are bounded by their original Fourier energy. -/
theorem cap_cutoff_selection (hC0 : 0 ≤ C)
    (f : Lp ℂ 2 (capProbability t c r hr)) (S : Set (Fin d → ℤ)) :
    ‖∑' ν : S, capFourierCoeff t c r hr f ν •
      cutoffOperator χ hχ hC (capFourierAtom t c r hr ν)‖ ^ 2 ≤
      C ^ 2 * ∑' ν : S, ‖capFourierCoeff t c r hr f ν‖ ^ 2 := by
  have h := fourier_packet_selection (capCutoffSynthesis t c r hr χ hχ hC)
    ((torusCapEquiv t c r hr).symm f) S
  have hn := pow_le_pow_left₀ (norm_nonneg (capCutoffSynthesis t c r hr χ hχ hC))
    (capCutoffSynthesis_norm_le t c r hr χ hχ hC hC0) 2
  have he : 0 ≤ ∑' ν : S, ‖capFourierCoeff t c r hr f ν‖ ^ 2 := tsum_nonneg (fun _ => sq_nonneg _)
  apply le_trans ?_ (mul_le_mul_of_nonneg_right hn he)
  simpa only [capCutoffSynthesis, ContinuousLinearMap.comp_apply, map_smul,
    ContinuousLinearEquiv.coe_coe, LinearIsometryEquiv.coe_toContinuousLinearEquiv,
    capFourierCoeff, capFourierAtom] using h

end N2Restriction
