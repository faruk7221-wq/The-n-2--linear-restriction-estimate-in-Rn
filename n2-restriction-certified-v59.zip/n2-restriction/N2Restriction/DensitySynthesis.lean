import N2Restriction.DensityForward
import N2Restriction.CoordinateExtension

namespace N2Restriction
open MeasureTheory
open scoped ENNReal NNReal

/-- Division by density preserves essential frequency support. -/
theorem divideDensityL2_support {Ω E : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (J : Ω → ℝ≥0) (hJ : Measurable J) {m : ℝ} (hm : 0 < m)
    (hmJ : ∀ᵐ x ∂μ, m ≤ (J x : ℝ)) (f : Lp ℂ 2 μ) (ζ : Ω → E) (K : Set E)
    (hf : HasFrequencySupport μ ζ K f) :
    HasFrequencySupport (μ.withDensity (fun x => (J x : ℝ≥0∞))) ζ K
      (divideDensityL2 μ J hJ hm hmJ f) := by
  filter_upwards [divideDensityL2_coe μ J hJ hm hmJ f,
    (withDensity_absolutelyContinuous μ _).ae_le hf] with x he hx hn
  apply hx
  intro hz
  exact hn (by rw [he, hz, zero_div])

theorem multiplyDensityL2_support {Ω E : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (J : Ω → ℝ≥0) (hJ : Measurable J) (hJ0 : ∀ᵐ x ∂μ, J x ≠ 0)
    {M : ℝ} (hM : 0 ≤ M) (hJM : ∀ᵐ x ∂μ, (J x : ℝ) ≤ M)
    (g : Lp ℂ 2 (μ.withDensity (fun x => (J x : ℝ≥0∞))))
    (ζ : Ω → E) (K : Set E)
    (hg : HasFrequencySupport (μ.withDensity (fun x => (J x : ℝ≥0∞))) ζ K g) :
    HasFrequencySupport μ ζ K (multiplyDensityL2 μ J hJ hJ0 hM hJM g) := by
  have hac : μ ≪ μ.withDensity (fun x => (J x : ℝ≥0∞)) :=
    withDensity_absolutelyContinuous' hJ.coe_nnreal_ennreal.aemeasurable
      (hJ0.mono fun x hx => by exact_mod_cast hx)
  filter_upwards [multiplyDensityL2_coe μ J hJ hJ0 hM hJM g, hac.ae_le hg] with x he hx hn
  apply hx
  intro hz
  exact hn (by rw [he, hz, mul_zero])

/-- Unconditional L2 synthesis survives inverse-density transfer. -/
theorem divideDensityL2_hasSum {Ω ι : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (J : Ω → ℝ≥0) (hJ : Measurable J) {m : ℝ} (hm : 0 < m)
    (hmJ : ∀ᵐ x ∂μ, m ≤ (J x : ℝ)) (f : ι → Lp ℂ 2 μ) (g : Lp ℂ 2 μ)
    (hf : HasSum f g) :
    HasSum (fun j => divideDensityL2 μ J hJ hm hmJ (f j))
      (divideDensityL2 μ J hJ hm hmJ g) :=
  (divideDensityOperator μ J hJ hm hmJ).hasSum hf

/-- Square-summable packet energy passes through the bounded transfer. -/
theorem divideDensityL2_tsum_energy {Ω ι : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (J : Ω → ℝ≥0) (hJ : Measurable J) {m : ℝ} (hm : 0 < m)
    (hmJ : ∀ᵐ x ∂μ, m ≤ (J x : ℝ)) (f : ι → Lp ℂ 2 μ)
    (hf : Summable (fun j => ‖f j‖ ^ 2)) :
    Summable (fun j => ‖divideDensityL2 μ J hJ hm hmJ (f j)‖ ^ 2) ∧
      (∑' j, ‖divideDensityL2 μ J hJ hm hmJ (f j)‖ ^ 2) ≤
        (1 / m) * ∑' j, ‖f j‖ ^ 2 := by
  have hb := fun j => divideDensityL2_energy μ J hJ hm hmJ (f j)
  have hs := Summable.of_nonneg_of_le (fun j => sq_nonneg _) hb (hf.mul_left (1 / m))
  refine ⟨hs, ?_⟩
  rw [← tsum_mul_left]
  exact hs.tsum_le_tsum hb (hf.mul_left (1 / m))

/-- Selected unconditional sums have the same operator energy bound. -/
theorem divideDensityL2_selected_energy {Ω ι : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (J : Ω → ℝ≥0) (hJ : Measurable J) {m : ℝ} (hm : 0 < m)
    (hmJ : ∀ᵐ x ∂μ, m ≤ (J x : ℝ)) (f : ι → Lp ℂ 2 μ) (hf : Summable f) :
    ‖∑' j, divideDensityL2 μ J hJ hm hmJ (f j)‖ ^ 2 ≤ (1 / m) * ‖∑' j, f j‖ ^ 2 := by
  rw [(divideDensityL2_hasSum μ J hJ hm hmJ f _ hf.hasSum).tsum_eq]
  exact divideDensityL2_energy μ J hJ hm hmJ _

end N2Restriction
