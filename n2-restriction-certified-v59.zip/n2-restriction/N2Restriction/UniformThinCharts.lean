import N2Restriction.FrameImplicit
import N2Restriction.ImplicitSlices
import N2Restriction.ExtendedPatch

namespace N2Restriction
open Metric Filter

/-- A genuine Euclidean chart for a thin-support zero set, including local
coverage, injectivity, smoothness, and all-order bounds on a fixed radius. -/
def ThinChartAt {n : ℕ} {F : Type*} [NormedAddCommGroup F] [NormedSpace ℝ F]
    (S : SmoothPatch n) (Q : Ambient n →L[ℝ] F) (z : Ambient n) (r : ℝ) (B : ℕ → ℝ) : Prop :=
  ∃ φ : Ambient (n - 3) → Ambient n, φ 0 = z ∧ Set.InjOn φ (closedBall 0 r) ∧
    (∀ t ∈ closedBall 0 r, φ t ∈ S.extendedSurface ∧ Q (S.normal (φ t)) = 0 ∧
      ContDiffAt ℝ (⊤ : ℕ∞) φ t ∧ Function.Injective (fderiv ℝ φ t)) ∧
    (∀ m t, t ∈ closedBall 0 r → ‖iteratedFDeriv ℝ m φ t‖ ≤ B m) ∧
    ∀ᶠ y in nhds z, y ∈ S.extendedSurface → Q (S.normal y) = 0 →
      ∃ t ∈ ball 0 r, φ t = y

/-- Changing the output coordinates by an equivalence does not change the
thin zero set or any of its chart bounds. -/
theorem thinChartAt_equiv_constraint {n : ℕ} {F G : Type*}
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    [NormedAddCommGroup G] [NormedSpace ℝ G]
    (S : SmoothPatch n) (Q : Ambient n →L[ℝ] F) (e : F ≃L[ℝ] G)
    (z : Ambient n) (r : ℝ) (B : ℕ → ℝ) :
    ThinChartAt S (e.toContinuousLinearMap.comp Q) z r B ↔ ThinChartAt S Q z r B := by
  have he0 : ∀ x : F, e x = 0 ↔ x = 0 := by
    intro x
    rw [← e.map_zero, e.injective.eq_iff]
  simp only [ThinChartAt, ContinuousLinearMap.comp_apply, ContinuousLinearEquiv.coe_coe, he0]

/-- The compact family of zero sets has ordinary (n-3)-dimensional Euclidean
charts with one radius and one sequence of derivative bounds, uniformly over
every surface index, frequency, and admissible frame. -/
theorem controlled_frame_zero_thin_chart {n : ℕ} (S : SmoothPatch n)
    {q : (Ambient n →L[ℝ] (ℝ × ℝ)) × Ambient n} {r : ℝ} {B : ℕ → ℝ}
    (hr : 0 < r) (hzero : frameConstraint S q = 0)
    (h : ControlledSubmersionChart (fun q => (q.1, frameConstraint S q))
      (Set.univ ×ˢ S.neighborhood) q r B) : ThinChartAt S q.1 q.2 r B := by
  have hdim : Module.finrank ℝ (Ambient n) -
      Module.finrank ℝ (ℝ × (ℝ × ℝ)) = n - 3 := by
    simp [Ambient, Module.finrank_prod, Module.finrank_self]
  have hparam := h.parameter_euclidean_parametrization
    (isOpen_univ.prod S.open_neighborhood) hr
  rw [hdim] at hparam
  obtain ⟨φ, hφ0, hinj, hφ, hbound, hcover⟩ := hparam
  refine ⟨φ, hφ0, hinj, ?_, hbound, ?_⟩
  · intro t ht
    obtain ⟨hU, hf, hs, hi⟩ := hφ t ht
    rw [hzero] at hf
    exact ⟨⟨hU.2, congrArg Prod.fst hf⟩, congrArg Prod.snd hf, hs, hi⟩
  · filter_upwards [hcover] with y hy hyS hyQ
    apply hy
    rw [hzero]
    exact Prod.ext hyS.2 hyQ

/-- One radius and one derivative-bound sequence for all supported zero
frequencies in the full admissible frame family. -/
theorem uniform_frameFrequencyAdmissible_thin_charts {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) {κ : ℝ} (hκ : 0 < κ) :
    ∃ r : ℝ, 0 < r ∧ ∃ B : ℕ → ℝ, (∀ m, 0 ≤ B m) ∧ ∀ i,
      ∀ q ∈ frameFrequencyAdmissibleImage (S i) κ,
        q.1 ((S i).normal q.2) = 0 → ThinChartAt (S i) q.1 q.2 r B := by
  obtain ⟨r, hr, B, hB, hb⟩ := uniform_frameFrequencyAdmissible_charts S hκ
  refine ⟨r, hr, B, hB, fun i q hq hz => ?_⟩
  have hzs : q.2 ∈ (S i).extendedSurface := by
    rcases hq with ⟨w, hw, rfl⟩
    exact SmoothPatch.support_in_extendedSurface (S i) w.2.2.2
  have hzero : frameConstraint (S i) q = 0 := Prod.ext hzs.2 hz
  exact controlled_frame_zero_thin_chart (S i) hr hzero (hb i q hq)

/-- The actual nearby-plane thin zero sets in Lemma 4.1 have common Euclidean
chart radii and derivative bounds at all supported zero frequencies. -/
theorem geometric_uniform_thin_charts {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) {ν κ : ℝ}
    (hgeo : GeometricHypotheses S ν κ) :
    ∃ r : ℝ, 0 < r ∧ ∃ B : ℕ → ℝ, (∀ m, 0 ≤ B m) ∧
      ∀ (z : Fin k → Ambient (k + 2)), (∀ j, z j ∈ (S j).support) →
      ∀ i (H : Submodule ℝ (Ambient (k + 2))), Module.finrank ℝ H = 2 →
      H.orthogonalProjection ((S i).normal (z i)) = 0 →
      ‖(commonTangent (fun j => (S j).normal (z j))).starProjection - H.starProjection‖ *
          ‖(S i).shape (z i)‖ ≤ κ / 2 →
      ThinChartAt (S i) H.orthogonalProjection (z i) r B := by
  obtain ⟨r, hr, B, hB, hb⟩ := uniform_frameFrequencyAdmissible_thin_charts S hgeo.2.1
  refine ⟨r, hr, B, hB, fun z hz i H hdim hzero hgap => ?_⟩
  obtain ⟨q, hq, hqz, _, e, he⟩ :=
    exists_frameFrequencyAdmissible_for_geometricTuple_and_plane S hgeo z hz i H hdim hgap
  have hq0 : q.1 ((S i).normal q.2) = 0 := by
    rw [he, hqz, ContinuousLinearMap.comp_apply, hzero, map_zero]
  have hc := hb i q hq hq0
  rw [he, hqz] at hc
  exact (thinChartAt_equiv_constraint (S i) H.orthogonalProjection e (z i) r B).mp hc

/-- Uniform distance correction retains uniform thin-set charts even when
the corrected zero lies outside the original support, in the fixed extension. -/
theorem uniform_frame_correction_and_thin_charts {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) {κ : ℝ} (hκ : 0 < κ) :
    ∃ δ r C : ℝ, 0 < δ ∧ 0 < r ∧ 0 ≤ C ∧ ∃ B : ℕ → ℝ,
      (∀ m, 0 ≤ B m) ∧ ∀ i, ∀ q ∈ frameFrequencyAdmissibleImage (S i) κ,
      ‖q.1 ((S i).normal q.2)‖ < δ →
      ∃ y ∈ (S i).extendedSurface, q.1 ((S i).normal y) = 0 ∧
        dist q.2 y ≤ C * ‖q.1 ((S i).normal q.2)‖ ∧ ThinChartAt (S i) q.1 y r B := by
  obtain ⟨r, hr, B, hB, hb⟩ := uniform_frameFrequencyAdmissible_charts S hκ
  have hB1 := hB 1
  refine ⟨r / (4 * (B 1 + 1)), r / 2, B 1, by positivity, by positivity, hB 1,
    B, hB, fun i q hq hsmall => ?_⟩
  have hzs : q.2 ∈ (S i).extendedSurface := by
    rcases hq with ⟨w, hw, rfl⟩
    exact SmoothPatch.support_in_extendedSurface (S i) w.2.2.2
  have hnorm : ‖frameConstraint (S i) q‖ = ‖q.1 ((S i).normal q.2)‖ := by
    simp [frameConstraint, Prod.norm_def, hzs.2]
  have ht : dist (q.1, (0 : ℝ × (ℝ × ℝ))) (q.1, frameConstraint (S i) q) <
      r / (4 * (B 1 + 1)) := by
    rw [Prod.dist_eq, dist_self, dist_zero_left, max_eq_right (norm_nonneg _), hnorm]
    exact hsmall
  obtain ⟨y, hy, heq, hd, hchart⟩ := (hb i q hq).correct_and_recenter hr (hB 1) ht
  have hp : y.1 = q.1 := congrArg
    (fun w : (Ambient (k + 2) →L[ℝ] (ℝ × ℝ)) × (ℝ × (ℝ × ℝ)) => w.1) heq
  have hf : frameConstraint (S i) y = 0 := congrArg
    (fun w : (Ambient (k + 2) →L[ℝ] (ℝ × ℝ)) × (ℝ × (ℝ × ℝ)) => w.2) heq
  have hfy : (S i).defining y.2 = 0 := congrArg Prod.fst hf
  have hny : q.1 ((S i).normal y.2) = 0 := by
    have hn := congrArg Prod.snd hf
    change y.1 ((S i).normal y.2) = 0 at hn
    rwa [hp] at hn
  have hthin := controlled_frame_zero_thin_chart (S i) (by positivity : 0 < r / 2) hf hchart
  rw [hp] at hthin
  refine ⟨y.2, ⟨hy.2, hfy⟩, hny, ?_, hthin⟩
  have hdistq : dist q y = dist q.2 y.2 := by
    rw [Prod.dist_eq, hp, dist_self, max_eq_right dist_nonneg]
  have hdistf : dist (q.1, frameConstraint (S i) q) (q.1, (0 : ℝ × (ℝ × ℝ))) =
      ‖q.1 ((S i).normal q.2)‖ := by
    rw [Prod.dist_eq, dist_self, dist_zero_right, max_eq_right (norm_nonneg _), hnorm]
  rw [hdistq, hdistf] at hd
  exact hd

/-- Combined uniform (4.1) and Euclidean chart bounds for the article's actual
nearby planes. The corrected point is allowed in the fixed smooth extension. -/
theorem geometric_uniform_correction_and_thin_charts {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) {ν κ : ℝ}
    (hgeo : GeometricHypotheses S ν κ) :
    ∃ δ r C : ℝ, 0 < δ ∧ 0 < r ∧ 0 ≤ C ∧ ∃ B : ℕ → ℝ,
      (∀ m, 0 ≤ B m) ∧
      ∀ (z : Fin k → Ambient (k + 2)), (∀ j, z j ∈ (S j).support) →
      ∀ i (H : Submodule ℝ (Ambient (k + 2))), Module.finrank ℝ H = 2 →
      ‖(commonTangent (fun j => (S j).normal (z j))).starProjection - H.starProjection‖ *
          ‖(S i).shape (z i)‖ ≤ κ / 2 →
      ‖H.orthogonalProjection ((S i).normal (z i))‖ < δ →
      ∃ y ∈ (S i).extendedSurface, H.orthogonalProjection ((S i).normal y) = 0 ∧
        dist (z i) y ≤ C * ‖H.orthogonalProjection ((S i).normal (z i))‖ ∧
        ThinChartAt (S i) H.orthogonalProjection y r B := by
  obtain ⟨δ, r, C, hδ, hr, hC, B, hB, hb⟩ :=
    uniform_frame_correction_and_thin_charts S hgeo.2.1
  refine ⟨δ, r, C, hδ, hr, hC, B, hB, fun z hz i H hdim hgap hsmall => ?_⟩
  obtain ⟨q, hq, hqz, hres, e, he⟩ :=
    exists_frameFrequencyAdmissible_for_geometricTuple_and_plane S hgeo z hz i H hdim hgap
  have hqs : ‖q.1 ((S i).normal q.2)‖ < δ := by
    rw [hqz]
    exact hres.trans_lt hsmall
  obtain ⟨y, hy, hzero, hd, hc⟩ := hb i q hq hqs
  have hHzero : H.orthogonalProjection ((S i).normal y) = 0 := by
    rw [he, ContinuousLinearMap.comp_apply] at hzero
    apply e.injective
    simpa using hzero
  rw [hqz] at hd
  rw [he] at hc
  exact ⟨y, hy, hHzero,
    hd.trans (mul_le_mul_of_nonneg_left hres hC),
    (thinChartAt_equiv_constraint (S i) H.orthogonalProjection e y r B).mp hc⟩

/-- Uniform thin-set charts hold throughout one fixed surface neighborhood of
the original supports. Every nearby extended tuple is included, with common
buffer width, chart radius, and all-order derivative bounds. -/
theorem geometric_uniform_thin_charts_on_surface_buffer {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) {ν κ : ℝ}
    (hgeo : GeometricHypotheses S ν κ) :
    ∃ η r : ℝ, 0 < η ∧ 0 < r ∧ ∃ B : ℕ → ℝ, (∀ m, 0 ≤ B m) ∧
      ∀ (z : Fin k → Ambient (k + 2)), (∀ j, z j ∈ (S j).support) →
      ∀ (y : Fin k → Ambient (k + 2)),
      (∀ j, y j ∈ (S j).extendedSurface ∧ dist (y j) (z j) ≤ η) →
      ∀ i (H : Submodule ℝ (Ambient (k + 2))), Module.finrank ℝ H = 2 →
      H.orthogonalProjection ((S i).normal (y i)) = 0 →
      ‖(commonTangent (fun j => (S j).normal (y j))).starProjection - H.starProjection‖ *
          ‖(S i).shape (y i)‖ ≤ κ / 2 →
      ThinChartAt (S i) H.orthogonalProjection (y i) r B := by
  obtain ⟨η, hη, K, hK, _, hin, hbuffer⟩ := uniform_compact_surface_buffers S
  let T := fun i => (S i).withSupport (K i) (hK i) (hin i)
  have hT : GeometricHypotheses T ν κ :=
    (geometricHypotheses_withSupport_iff S K hK hin ν κ).mpr hgeo
  obtain ⟨r, hr, B, hB, hb⟩ := geometric_uniform_thin_charts T hT
  refine ⟨η, r, hη, hr, B, hB, fun z hz y hy i H hdim hzero hgap => ?_⟩
  have hyT : ∀ j, y j ∈ (T j).support :=
    fun j => hbuffer j (z j) (hz j) (y j) (hy j).1 (hy j).2
  exact hb y hyT i H hdim hzero hgap

end N2Restriction
