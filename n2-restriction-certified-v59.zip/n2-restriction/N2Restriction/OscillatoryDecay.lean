import N2Restriction.UniformImplicit
import N2Restriction.Extension
import Mathlib.Analysis.Fourier.FourierTransformDeriv
import Mathlib.Analysis.Normed.Operator.Prod

/-! Uniform integration-by-parts estimates for compact smooth amplitude families.
These are estimates for actual Euclidean Fourier integrals. The rescaled graph
phase still has to be placed in such a family for general surfaces. -/

namespace N2Restriction
open MeasureTheory Set
open scoped FourierTransform BigOperators

variable {P V : Type*}
  [NormedAddCommGroup P] [NormedSpace ℝ P]
  [NormedAddCommGroup V] [InnerProductSpace ℝ V] [FiniteDimensional ℝ V]
  [MeasurableSpace V] [BorelSpace V]

omit [FiniteDimensional ℝ V] [MeasurableSpace V] [BorelSpace V] in
/-- Taking derivatives in the frequency variable alone costs no operator norm. -/
theorem norm_parameter_slice_derivative {f : P × V → ℂ}
    (hf : ContDiff ℝ (⊤ : ℕ∞) f) (m : ℕ) (p : P) (x : V) :
    ‖iteratedFDeriv ℝ m (fun y => f (p, y)) x‖ ≤
      ‖iteratedFDeriv ℝ m f (p, x)‖ := by
  have hg : ‖ContinuousLinearMap.inr ℝ P V‖ ≤ 1 := by
    apply (ContinuousLinearMap.inr ℝ P V).opNorm_le_bound (by norm_num)
    intro y
    change ‖((0 : P), y)‖ ≤ 1 * ‖y‖
    simp
  have he : ∀ y : V, (p, (0 : V)) + ContinuousLinearMap.inr ℝ P V y = (p, y) := by
    intro y
    ext <;> simp
  have ht := norm_iteratedFDeriv_affine_slice (f := f) (x := x)
    (ContinuousLinearMap.inr ℝ P V) hg (p, (0 : V)) m
    (by simpa only [he] using hf.contDiffAt (x := (p, x)))
  simpa only [he] using ht

/-- All frequency derivatives of a smooth slice have compact support. -/
theorem compact_family_derivative_integrable {f : P × V → ℂ}
    (hf : ContDiff ℝ (⊤ : ℕ∞) f) {K : Set V} (hK : IsCompact K)
    (p : P) (hs : tsupport (fun x => f (p, x)) ⊆ K) (m : ℕ) :
    Integrable (iteratedFDeriv ℝ m (fun x => f (p, x))) := by
  have hslice : ContDiff ℝ (⊤ : ℕ∞) (fun x => f (p, x)) :=
    hf.comp (contDiff_const.prodMk contDiff_id)
  have hc : HasCompactSupport (fun x => f (p, x)) :=
    hK.of_isClosed_subset isClosed_closure hs
  exact (hslice.continuous_iteratedFDeriv (m := m) (by
    exact_mod_cast (le_top : (m : ℕ∞) ≤ ⊤))).integrable_of_hasCompactSupport
    (hc.iteratedFDeriv m)

/-- A fixed compact frequency support and compact parameter set give a common
L1 bound for each derivative order, without supplying derivative bounds. -/
theorem compact_family_derivative_L1_bound {f : P × V → ℂ}
    (hf : ContDiff ℝ (⊤ : ℕ∞) f) {Q : Set P} (hQ : IsCompact Q)
    {K : Set V} (hK : IsCompact K)
    (hs : ∀ p ∈ Q, tsupport (fun x => f (p, x)) ⊆ K) (m : ℕ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ p ∈ Q,
      (∫ x, ‖iteratedFDeriv ℝ m (fun y => f (p, y)) x‖) ≤ C := by
  obtain ⟨B, hB⟩ := (hQ.prod hK).exists_bound_of_continuousOn
    (hf.continuous_iteratedFDeriv (m := m) (by
      exact_mod_cast (le_top : (m : ℕ∞) ≤ ⊤))).continuousOn
  refine ⟨max B 0 * volume.real K, by positivity, fun p hp => ?_⟩
  have hsupport : Function.support (fun x => ‖iteratedFDeriv ℝ m
      (fun y => f (p, y)) x‖) ⊆ K := by
    intro x hx
    apply hs p hp
    apply support_iteratedFDeriv_subset (𝕜 := ℝ) m
    simpa only [Function.mem_support, norm_ne_zero_iff] using hx
  have he : (∫ x in K, ‖iteratedFDeriv ℝ m (fun y => f (p, y)) x‖) =
      ∫ x, ‖iteratedFDeriv ℝ m (fun y => f (p, y)) x‖ := by
    apply setIntegral_eq_integral_of_forall_compl_eq_zero
    intro x hx
    exact Function.notMem_support.mp (fun h => hx (hsupport h))
  rw [← he]
  have hbnd : ∀ᵐ x ∂volume.restrict K,
      ‖‖iteratedFDeriv ℝ m (fun y => f (p, y)) x‖‖ ≤ max B 0 := by
    filter_upwards [ae_restrict_mem hK.measurableSet] with x hx
    rw [norm_norm]
    exact (norm_parameter_slice_derivative hf m p x).trans
      ((hB (p, x) ⟨hp, hx⟩).trans (le_max_left _ _))
  exact (le_abs_self _).trans
    (norm_setIntegral_le_of_norm_le_const_ae hK.measure_lt_top hbnd)

/-- Repeated integration by parts gives a uniform polynomial Fourier bound
for every order on a compact smooth family with fixed compact support. -/
theorem compact_family_fourier_decay {f : P × V → ℂ}
    (hf : ContDiff ℝ (⊤ : ℕ∞) f) {Q : Set P} (hQ : IsCompact Q)
    {K : Set V} (hK : IsCompact K)
    (hs : ∀ p ∈ Q, tsupport (fun x => f (p, x)) ⊆ K) (m : ℕ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ p ∈ Q, ∀ w : V,
      (1 + ‖w‖) ^ m * ‖𝓕 (fun x => f (p, x)) w‖ ≤ C := by
  choose B hB hb using fun j => compact_family_derivative_L1_bound hf hQ hK hs j
  let D : ℕ → ℝ := fun j => 2 ^ j * ∑ l ∈ Finset.range (j + 1), B l
  have hD (j : ℕ) : 0 ≤ D j := by
    exact mul_nonneg (by positivity) (Finset.sum_nonneg (fun l _ => hB l))
  have hd (j : ℕ) (p : P) (hp : p ∈ Q) (w : V) :
      ‖w‖ ^ j * ‖𝓕 (fun x => f (p, x)) w‖ ≤ D j := by
    have hslice : ContDiff ℝ (⊤ : ℕ∞) (fun x => f (p, x)) :=
      hf.comp (contDiff_const.prodMk contDiff_id)
    have hi : ∀ (k n : ℕ), (k : ℕ∞) ≤ 0 → (n : ℕ∞) ≤ ⊤ →
        Integrable (fun x => ‖x‖ ^ k * ‖iteratedFDeriv ℝ n (fun y => f (p, y)) x‖) := by
      intro k n hk _
      have hk0 : k = 0 := by
        have : k ≤ 0 := by exact_mod_cast hk
        omega
      subst k
      simpa using (compact_family_derivative_integrable hf hK p (hs p hp) n).norm
    have ht := Real.pow_mul_norm_iteratedFDeriv_fourierIntegral_le hslice hi
      (k := 0) (n := j) (by simp) (by simp) w
    simp only [norm_iteratedFDeriv_zero, pow_zero, one_mul, Nat.cast_zero,
      mul_zero, zero_add, Finset.range_one, Finset.singleton_product,
      Finset.sum_map, Function.Embedding.coeFn_mk] at ht
    apply ht.trans
    dsimp [D]
    gcongr
    exact hb _ p hp
  refine ⟨2 ^ (m - 1) * (D 0 + D m),
    mul_nonneg (by positivity) (add_nonneg (hD 0) (hD m)), fun p hp w => ?_⟩
  have h0 := hd 0 p hp w
  simp only [pow_zero, one_mul] at h0
  calc
    _ ≤ (2 ^ (m - 1) * (1 + ‖w‖ ^ m)) * ‖𝓕 (fun x => f (p, x)) w‖ := by
      gcongr
      simpa using add_pow_le (show (0 : ℝ) ≤ 1 by norm_num) (norm_nonneg w) m
    _ = 2 ^ (m - 1) * (‖𝓕 (fun x => f (p, x)) w‖ +
        ‖w‖ ^ m * ‖𝓕 (fun x => f (p, x)) w‖) := by ring
    _ ≤ _ := mul_le_mul_of_nonneg_left (add_le_add h0 (hd m p hp w)) (by positivity)

/-- Division yields the usual inverse-polynomial form, including zero frequency. -/
theorem compact_family_fourier_decay_div {f : P × V → ℂ}
    (hf : ContDiff ℝ (⊤ : ℕ∞) f) {Q : Set P} (hQ : IsCompact Q)
    {K : Set V} (hK : IsCompact K)
    (hs : ∀ p ∈ Q, tsupport (fun x => f (p, x)) ⊆ K) (m : ℕ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ p ∈ Q, ∀ w : V,
      ‖𝓕 (fun x => f (p, x)) w‖ ≤ C / (1 + ‖w‖) ^ m := by
  obtain ⟨C, hC, hb⟩ := compact_family_fourier_decay hf hQ hK hs m
  refine ⟨C, hC, fun p hp w => (le_div_iff₀ (by positivity)).mpr ?_⟩
  simpa only [mul_comm] using hb p hp w

/-- The unnormalized oscillatory integral used in the packet phase calculation. -/
noncomputable def oscillatoryIntegral (ψ : V → ℝ) (a : V → ℂ) (u : V) : ℂ :=
  ∫ x, Complex.exp (((inner ℝ u x + ψ x : ℝ) : ℂ) * Complex.I) * a x

/-- Exact conversion to Mathlib's Fourier normalization; no asymptotic identity. -/
theorem oscillatoryIntegral_eq_fourier (ψ : V → ℝ) (a : V → ℂ) (u : V) :
    oscillatoryIntegral ψ a u =
      𝓕 (fun x => Complex.exp ((ψ x : ℂ) * Complex.I) * a x)
        (-((2 * Real.pi)⁻¹) • u) := by
  rw [Real.fourierIntegral_eq']
  apply integral_congr_ae
  filter_upwards with x
  have he : -2 * Real.pi * inner ℝ x (-((2 * Real.pi)⁻¹) • u) = inner ℝ u x := by
    rw [inner_smul_right, real_inner_comm x u]
    field_simp
  rw [he]
  simp only [Complex.ofReal_add, add_mul, Complex.exp_add, smul_eq_mul, mul_assoc]

/-- Uniform rapid decay for a genuinely nonlinear phase in a smooth compact
parameter family. Both amplitude and phase may vary with the parameter. -/
theorem compact_family_oscillatory_decay {a : P × V → ℂ} {ψ : P × V → ℝ}
    (ha : ContDiff ℝ (⊤ : ℕ∞) a) (hψ : ContDiff ℝ (⊤ : ℕ∞) ψ)
    {Q : Set P} (hQ : IsCompact Q) {K : Set V} (hK : IsCompact K)
    (hs : ∀ p ∈ Q, tsupport (fun x => a (p, x)) ⊆ K) (m : ℕ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ p ∈ Q, ∀ u : V,
      ‖oscillatoryIntegral (fun x => ψ (p, x)) (fun x => a (p, x)) u‖ ≤
        C / (1 + ‖u‖) ^ m := by
  let f : P × V → ℂ := fun q => Complex.exp ((ψ q : ℂ) * Complex.I) * a q
  have hf : ContDiff ℝ (⊤ : ℕ∞) f := by
    dsimp [f]
    exact (Complex.contDiff_exp.comp
      ((Complex.ofRealCLM.contDiff.comp hψ).mul contDiff_const)).mul ha
  have hfs : ∀ p ∈ Q, tsupport (fun x => f (p, x)) ⊆ K := by
    intro p hp
    exact tsupport_mul_subset_right.trans (hs p hp)
  obtain ⟨C, hC, hb⟩ := compact_family_fourier_decay hf hQ hK hfs m
  refine ⟨(1 + 2 * Real.pi) ^ m * C, by positivity, fun p hp u => ?_⟩
  rw [oscillatoryIntegral_eq_fourier]
  apply (le_div_iff₀ (by positivity)).mpr
  let w : V := -((2 * Real.pi)⁻¹) • u
  have hw : ‖u‖ = (2 * Real.pi) * ‖w‖ := by
    dsimp [w]
    rw [norm_smul, Real.norm_eq_abs, abs_neg,
      abs_of_pos (inv_pos.mpr (mul_pos (by norm_num) Real.pi_pos))]
    field_simp
  have hsize : 1 + ‖u‖ ≤ (1 + 2 * Real.pi) * (1 + ‖w‖) := by
    rw [hw]
    nlinarith [Real.pi_pos, norm_nonneg w]
  calc
    _ ≤ ‖𝓕 (fun x => f (p, x)) w‖ *
        ((1 + 2 * Real.pi) * (1 + ‖w‖)) ^ m := by
      exact mul_le_mul_of_nonneg_left
        (pow_le_pow_left₀ (by positivity) hsize m) (norm_nonneg _)
    _ = (1 + 2 * Real.pi) ^ m *
        ((1 + ‖w‖) ^ m * ‖𝓕 (fun x => f (p, x)) w‖) := by rw [mul_pow]; ring
    _ ≤ _ := mul_le_mul_of_nonneg_left (hb p hp w) (by positivity)

end N2Restriction
