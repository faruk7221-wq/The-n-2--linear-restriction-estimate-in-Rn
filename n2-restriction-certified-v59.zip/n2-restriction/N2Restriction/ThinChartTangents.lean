import N2Restriction.UniformThinCharts
import N2Restriction.ThinNormalSpace

namespace N2Restriction
open Filter Metric

/-- A smooth immersed parametrization of the expected dimension has derivative
range equal to the constraint kernel, once it stays on that level locally. -/
theorem parametrized_level_tangent_range {d n : ℕ} {F : Type*}
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    {f : Ambient n → F} {L : Ambient n →L[ℝ] F} {z : Ambient n}
    {φ : Ambient d → Ambient n} (hφ0 : φ 0 = z)
    (hf : HasFDerivAt f L z) (hφ : DifferentiableAt ℝ φ 0)
    (hinj : Function.Injective (fderiv ℝ φ 0))
    (hlevel : ∀ᶠ t in nhds (0 : Ambient d), f (φ t) = f z)
    (hdim : Module.finrank ℝ (LinearMap.ker L.toLinearMap) = d) :
    LinearMap.range (fderiv ℝ φ 0).toLinearMap = LinearMap.ker L.toLinearMap := by
  have hcomp : HasFDerivAt (f ∘ φ) (L.comp (fderiv ℝ φ 0)) 0 := by
    have hf' : HasFDerivAt f L (φ 0) := hφ0 ▸ hf
    exact hf'.comp 0 hφ.hasFDerivAt
  have hzero : HasFDerivAt (f ∘ φ) 0 0 :=
    (hasFDerivAt_const (𝕜 := ℝ) (f z) (0 : Ambient d)).congr_of_eventuallyEq hlevel
  have hD := hcomp.unique hzero
  have hle : LinearMap.range (fderiv ℝ φ 0).toLinearMap ≤ LinearMap.ker L.toLinearMap := by
    rintro v ⟨t, rfl⟩
    have h := congrArg (fun A : Ambient d →L[ℝ] F => A t) hD
    exact h
  apply Submodule.eq_of_le_of_finrank_eq hle
  rw [LinearMap.finrank_range_of_inj hinj, hdim]
  simp [Ambient]

/-- The tangent space of an actual thin chart is the kernel already used by
the shape-operator geometry; injectivity gives the necessary rank equality. -/
theorem ThinChartAt.exists_parametrization_tangent_space {n : ℕ}
    {S : SmoothPatch n} {H : Submodule ℝ (Ambient n)} {z : Ambient n}
    {r : ℝ} {B : ℕ → ℝ} (h : ThinChartAt S H.orthogonalProjection z r B)
    (hr : 0 < r) (hz : z ∈ S.neighborhood)
    (hdim : Module.finrank ℝ (LinearMap.ker (thinDifferential S H z).toLinearMap) = n - 3) :
    ∃ φ : Ambient (n - 3) → Ambient n, φ 0 = z ∧
      ContDiffAt ℝ (⊤ : ℕ∞) φ 0 ∧ Function.Injective (fderiv ℝ φ 0) ∧
      LinearMap.range (fderiv ℝ φ 0).toLinearMap =
        LinearMap.ker (thinDifferential S H z).toLinearMap := by
  obtain ⟨φ, hφ0, _, hφ, _, _⟩ := h
  have h0 := hφ 0 (mem_closedBall_self hr.le)
  have hzero : thinConstraint S H z = 0 := by
    rw [← hφ0]
    exact Prod.ext h0.1.2 h0.2.1
  have hlevel : ∀ᶠ t in nhds (0 : Ambient (n - 3)),
      thinConstraint S H (φ t) = thinConstraint S H z := by
    filter_upwards [closedBall_mem_nhds (0 : Ambient (n - 3)) hr] with t ht
    rw [hzero]
    exact Prod.ext (hφ t ht).1.2 (hφ t ht).2.1
  exact ⟨φ, hφ0, h0.2.2.1, h0.2.2.2,
    parametrized_level_tangent_range hφ0 (hasFDerivAt_thinConstraint S H hz)
      (h0.2.2.1.differentiableAt (by simp)) h0.2.2.2 hlevel hdim⟩

/-- Equation (4.2) now describes the normal space of the actual smooth chart
derivative, rather than only an abstract constraint kernel. -/
theorem ThinChartAt.exists_parametrization_normal_space {n : ℕ}
    {S : SmoothPatch n} {H : Submodule ℝ (Ambient n)} {z : Ambient n}
    {r : ℝ} {B : ℕ → ℝ} (h : ThinChartAt S H.orthogonalProjection z r B)
    (hr : 0 < r) (hz : z ∈ S.neighborhood)
    (hzero : H.orthogonalProjection (S.normal z) = 0)
    (hdim : Module.finrank ℝ (LinearMap.ker (thinDifferential S H z).toLinearMap) = n - 3) :
    ∃ φ : Ambient (n - 3) → Ambient n, φ 0 = z ∧
      ContDiffAt ℝ (⊤ : ℕ∞) φ 0 ∧ Function.Injective (fderiv ℝ φ 0) ∧
      (LinearMap.range (fderiv ℝ φ 0).toLinearMap)ᗮ =
        Submodule.span ℝ {S.normal z} ⊔ H.map (S.shape z).toLinearMap := by
  obtain ⟨φ, hφ0, hs, hi, ht⟩ := h.exists_parametrization_tangent_space hr hz hdim
  exact ⟨φ, hφ0, hs, hi, by rw [ht, thin_normal_space S H hz hzero]⟩

end N2Restriction
