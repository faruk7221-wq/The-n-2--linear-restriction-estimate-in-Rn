import N2Restriction.SmoothGraphPackets
import Mathlib.Analysis.Calculus.BumpFunction.InnerProduct

namespace N2Restriction
open MeasureTheory Set Metric

/-- A smooth cutoff supported inside the smoothness domain extends a local
phase to a globally smooth phase by multiplication. -/
theorem smooth_local_cutoff_product {d : ℕ} {U : Set (Ambient d)} (hU : IsOpen U)
    {φ β : Ambient d → ℝ} (hφ : ContDiffOn ℝ (⊤ : ℕ∞) φ U)
    (hβ : ContDiff ℝ (⊤ : ℕ∞) β) (hs : tsupport β ⊆ U) :
    ContDiff ℝ (⊤ : ℕ∞) (fun x => β x * φ x) := by
  rw [contDiff_iff_contDiffAt]
  intro x
  by_cases hx : x ∈ U
  · exact hβ.contDiffAt.mul (hφ.contDiffAt (hU.mem_nhds hx))
  · have hn : x ∉ tsupport β := fun h => hx (hs h)
    have he : (fun y => β y * φ y) =ᶠ[nhds x] (fun _ => (0 : ℝ)) := by
      filter_upwards [notMem_tsupport_iff_eventuallyEq.mp hn] with y hy
      simp [hy]
    exact contDiffAt_const.congr_of_eventuallyEq he

/-- A local graph phase has a global smooth extension on every strictly
smaller ball whose outer closed ball lies in its smoothness domain. -/
theorem exists_smooth_graph_extension {d : ℕ} {U : Set (Ambient d)} (hU : IsOpen U)
    {φ : Ambient d → ℝ} (hφ : ContDiffOn ℝ (⊤ : ℕ∞) φ U)
    (z : Ambient d) {a b : ℝ} (ha : 0 < a) (hab : a < b)
    (hball : closedBall z b ⊆ U) :
    ∃ Φ : Ambient d → ℝ, ContDiff ℝ (⊤ : ℕ∞) Φ ∧
      EqOn Φ φ (closedBall z a) := by
  let β : ContDiffBump z := ⟨a, b, ha, hab⟩
  refine ⟨fun x => β x * φ x, smooth_local_cutoff_product hU hφ β.contDiff ?_, ?_⟩
  · simpa only [β.tsupport_eq] using hball
  · intro x hx
    change β x * φ x = φ x
    rw [β.one_of_mem_closedBall hx, one_mul]

/-- The graph integral depends only on the phase on the actual scaled cap. -/
theorem graphPacket_congr_on_cap {d : ℕ} {φ Φ : Ambient d → ℝ}
    (χ : Ambient d → ℂ) (c : Ambient d) {r : ℝ} (hr : r ≠ 0)
    (hφ : ∀ η, χ η ≠ 0 → φ (c + r • η) = Φ (c + r • η))
    (v u : Ambient d) (t : ℝ) : graphPacket φ χ c r v u t = graphPacket Φ χ c r v u t := by
  unfold graphPacket oscillatoryIntegral
  congr 1
  apply integral_congr_ae
  filter_upwards with ξ
  by_cases hχ : χ (r⁻¹ • (ξ - c)) = 0
  · simp [hχ]
  · have he := hφ (r⁻¹ • (ξ - c)) hχ
    simp only [smul_inv_smul₀ hr, add_sub_cancel] at he
    rw [he]

/-- Uniform packet decay for a phase smooth only on a neighborhood. The
global extension and a positive common cap-radius threshold are constructed.
The fixed cutoff may have any compact support. -/
theorem local_smooth_graph_packet_decay {d : ℕ} {U : Set (Ambient d)} (hU : IsOpen U)
    {φ : Ambient d → ℝ} (hφ : ContDiffOn ℝ (⊤ : ℕ∞) φ U)
    (z : Ambient d) {a b : ℝ} (ha : 0 < a) (hab : a < b)
    (hball : closedBall z b ⊆ U) {Q : Set (Ambient d)} (hQ : IsCompact Q)
    (hcenter : Q ⊆ ball z (a / 2)) {χ : Ambient d → ℂ}
    (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hs : HasCompactSupport χ) :
    ∃ r₀ : ℝ, 0 < r₀ ∧ ∀ M : ℕ, ∃ C : ℝ, 0 ≤ C ∧
      ∀ c ∈ Q, ∀ r : ℝ, 0 < r → r ≤ r₀ →
      ∀ (v u : Ambient d) (t : ℝ), |t * r ^ 2| ≤ 1 →
      ‖graphPacket φ χ c r v u t‖ ≤ r ^ ((d : ℝ) / 2) *
        (C / (1 + r * ‖u + v + t • graphGradient φ c‖) ^ M) := by
  obtain ⟨Φ, hΦ, heq⟩ := exists_smooth_graph_extension hU hφ z ha hab hball
  obtain ⟨L, hL, hbχ⟩ := hs.isBounded.exists_pos_norm_le
  let r₀ : ℝ := a / (2 * L)
  have hr₀ : 0 < r₀ := by dsimp [r₀]; positivity
  refine ⟨r₀, hr₀, fun M => ?_⟩
  obtain ⟨C, hC, hb⟩ := smooth_graph_packet_decay hΦ hQ hχ hs r₀ M
  refine ⟨C, hC, ?_⟩
  intro c hc r hr hrr v u t ht
  have hcg : graphGradient Φ c = graphGradient φ c := by
    have hca : c ∈ ball z a := by
      have h := hcenter hc
      rw [mem_ball] at h ⊢
      linarith
    have he : Φ =ᶠ[nhds c] φ := Filter.Eventually.mono (isOpen_ball.mem_nhds hca)
      (fun x hx => heq (ball_subset_closedBall hx))
    exact congrArg (fun D => (InnerProductSpace.toDual ℝ (Ambient d)).symm D) he.fderiv_eq
  have hp : graphPacket φ χ c r v u t = graphPacket Φ χ c r v u t := by
    apply graphPacket_congr_on_cap χ c hr.ne'
    intro η hη
    apply (heq ?_).symm
    rw [mem_closedBall, dist_eq_norm]
    have hcn : ‖c - z‖ ≤ a / 2 := by
      exact (mem_ball.mp (hcenter hc)).le
    have hηn : ‖η‖ ≤ L := hbχ η (subset_tsupport χ (Function.mem_support.mpr hη))
    have hrL : r * L ≤ a / 2 := by
      have h := (le_div_iff₀ (show 0 < 2 * L by positivity)).mp hrr
      dsimp [r₀] at hrr
      nlinarith
    calc
      ‖c + r • η - z‖ = ‖(c - z) + r • η‖ := by congr 1; abel
      _ ≤ ‖c - z‖ + ‖r • η‖ := norm_add_le _ _
      _ = ‖c - z‖ + r * ‖η‖ := by rw [norm_smul, Real.norm_eq_abs, abs_of_pos hr]
      _ ≤ a / 2 + r * L := add_le_add hcn (mul_le_mul_of_nonneg_left hηn hr.le)
      _ ≤ a := by linarith
  rw [hp, ← hcg]
  exact hb c hc r hr hrr v u t ht

/-- One physical-scale threshold works for every requested decay order on a
local graph patch, and the bound uses round finite Euclidean tubes. -/
theorem local_smooth_graph_round_decay_at_scale {d : ℕ} {U : Set (Ambient d)} (hU : IsOpen U)
    {φ : Ambient d → ℝ} (hφ : ContDiffOn ℝ (⊤ : ℕ∞) φ U)
    (z : Ambient d) {a b : ℝ} (ha : 0 < a) (hab : a < b)
    (hball : closedBall z b ⊆ U) {Q : Set (Ambient d)} (hQ : IsCompact Q)
    (hcenter : Q ⊆ ball z (a / 2)) {χ : Ambient d → ℂ}
    (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hs : HasCompactSupport χ) :
    ∃ R₀ : ℝ, 1 ≤ R₀ ∧ ∀ M : ℕ, ∃ C : ℝ, 0 ≤ C ∧
      ∀ R : ℝ, R₀ ≤ R → ∀ c ∈ Q, ∀ (v u : Ambient d) (t : ℝ), |t| ≤ R →
      ‖graphPacket φ χ c (R ^ (-1 / 2 : ℝ)) v u t‖ ≤ R ^ (-(d : ℝ) / 4) *
        (C / (1 + R ^ (-1 / 2 : ℝ) * Metric.infDist (graphPoint u t)
          (packetSegment (graphGradient φ c) v R)) ^ M) := by
  obtain ⟨r₀, hr₀, hb⟩ := local_smooth_graph_packet_decay hU hφ z ha hab hball hQ hcenter hχ hs
  refine ⟨max 1 (r₀ ^ (-2 : ℝ)), le_max_left _ _, fun M => ?_⟩
  obtain ⟨C, hC, hCbound⟩ := hb M
  refine ⟨C, hC, fun R hR c hc v u t ht => ?_⟩
  have hR1 : 1 ≤ R := (le_max_left _ _).trans hR
  have hRp : 0 < R := by linarith
  have hr := Real.rpow_pos_of_pos hRp (-1 / 2 : ℝ)
  have hrsmall : R ^ (-1 / 2 : ℝ) ≤ r₀ := by
    have h := Real.rpow_le_rpow_of_exponent_nonpos (Real.rpow_pos_of_pos hr₀ (-2 : ℝ))
      ((le_max_right _ _).trans hR) (by norm_num : (-1 / 2 : ℝ) ≤ 0)
    rw [← Real.rpow_mul hr₀.le] at h
    norm_num at h
    simpa only [neg_div] using h
  have h := hCbound c hc _ hr hrsmall v u t (parabolic_time_parameter hRp ht)
  have he : (R ^ (-1 / 2 : ℝ)) ^ ((d : ℝ) / 2) = R ^ (-(d : ℝ) / 4) := by
    rw [← Real.rpow_mul hRp.le]
    congr 1
    ring
  rw [he] at h
  apply h.trans
  have hd := packetSegment_dist_le_offset (graphGradient φ c) v u ht
  have hn := Metric.infDist_nonneg (x := graphPoint u t)
    (s := packetSegment (graphGradient φ c) v R)
  gcongr

end N2Restriction
