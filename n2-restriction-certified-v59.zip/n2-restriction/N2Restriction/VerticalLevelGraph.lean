import N2Restriction.LocalGraphCover
import N2Restriction.UniformImplicit

namespace N2Restriction
open MeasureTheory Set Filter

/-- Horizontal projection as a bounded linear map. -/
noncomputable def graphProjectionCLM {d : ℕ} : Ambient (d + 1) →L[ℝ] Ambient d :=
  (show Ambient (d + 1) →ₗ[ℝ] Ambient d from
    { toFun := graphProjection
      map_add' := by intro x y; ext j; simp [graphProjection]
      map_smul' := by intro c x; ext j; simp [graphProjection] }).toContinuousLinearMap

theorem graphPoint_horizontal_vertical {d : ℕ} (x : Ambient (d + 1)) :
    x = graphPoint (graphProjection x) 0 + (x 0) • graphPoint (0 : Ambient d) 1 := by
  ext j
  refine Fin.cases ?_ (fun k => ?_) j <;> simp [graphPoint, graphProjection]

/-- A nonzero vertical derivative makes defining-function/horizontal coordinates invertible. -/
theorem vertical_coordinates_bijective {d : ℕ} (L : Ambient (d + 1) →L[ℝ] ℝ)
    (hL : L (graphPoint (0 : Ambient d) 1) ≠ 0) :
    Function.Bijective (L.prod graphProjectionCLM) := by
  have he (x : Ambient (d + 1)) :
      L x = L (graphPoint (graphProjection x) 0) + x 0 * L (graphPoint (0 : Ambient d) 1) := by
    conv_lhs => rw [graphPoint_horizontal_vertical x]
    rw [map_add, map_smul]
    rfl
  constructor
  · intro x y hxy
    have h1 : L x = L y := congrArg Prod.fst hxy
    have h2 : graphProjection x = graphProjection y := congrArg Prod.snd hxy
    have hh : x 0 = y 0 := by
      apply mul_right_cancel₀ hL
      have hx := he x
      have hy := he y
      rw [h2] at hx
      linarith
    rw [← graphPoint_projection_height x, ← graphPoint_projection_height y, h2, hh]
  · intro p
    refine ⟨graphPoint p.2 ((p.1 - L (graphPoint p.2 0)) / L (graphPoint (0 : Ambient d) 1)), ?_⟩
    apply Prod.ext
    · change L _ = _
      rw [he, graphProjection_graphPoint]
      change L (graphPoint p.2 0) +
        ((p.1 - L (graphPoint p.2 0)) / L (graphPoint (0 : Ambient d) 1)) *
          L (graphPoint (0 : Ambient d) 1) = p.1
      rw [div_mul_cancel₀ _ hL]
      ring
    · exact graphProjection_graphPoint p.2 ((p.1 - L (graphPoint p.2 0)) / L (graphPoint (0 : Ambient d) 1))

noncomputable def verticalCoordinateEquiv {d : ℕ} (L : Ambient (d + 1) →L[ℝ] ℝ)
    (hL : L (graphPoint (0 : Ambient d) 1) ≠ 0) :
    Ambient (d + 1) ≃L[ℝ] ℝ × Ambient d :=
  (LinearEquiv.ofBijective (L.prod graphProjectionCLM).toLinearMap
    (vertical_coordinates_bijective L hL)).toContinuousLinearEquiv

/-- A regular vertical derivative gives one smooth graph domain and local level-set identity. -/
theorem exists_vertical_level_graph {d : ℕ} {f : Ambient (d + 1) → ℝ}
    {U : Set (Ambient (d + 1))} (hU : IsOpen U)
    (hf : ContDiffOn ℝ (⊤ : ℕ∞) f U) {z : Ambient (d + 1)} (hz : z ∈ U)
    (hvert : fderiv ℝ f z (graphPoint (0 : Ambient d) 1) ≠ 0) :
    ∃ (W : Set (Ambient d)) (φ : Ambient d → ℝ), IsOpen W ∧ graphProjection z ∈ W ∧
      ContDiffOn ℝ (⊤ : ℕ∞) φ W ∧
      (∀ u ∈ W, f (graphPoint u (φ u)) = f z) ∧
      (∀ u ∈ W, graphPoint u (φ u) ∈ U) ∧
      ∀ᶠ x in nhds z, f x = f z → x = graphPoint (graphProjection x) (φ (graphProjection x)) := by
  let q : Ambient (d + 1) → ℝ × Ambient d := fun x => (f x, graphProjection x)
  let A := verticalCoordinateEquiv (fderiv ℝ f z) hvert
  have hq : ContDiffOn ℝ (⊤ : ℕ∞) q U :=
    hf.prodMk graphProjectionCLM.contDiff.contDiffOn
  have hqa := hq.contDiffAt (hU.mem_nhds hz)
  have hd : HasFDerivAt q (A : Ambient (d + 1) →L[ℝ] ℝ × Ambient d) z :=
    ((hf.contDiffAt (hU.mem_nhds hz)).differentiableAt (by simp)).hasFDerivAt.prodMk
      graphProjectionCLM.hasFDerivAt
  let e := hqa.toOpenPartialHomeomorph q hd (by simp)
  have hez : z ∈ e.source := hqa.mem_toOpenPartialHomeomorph_source hd (by simp)
  obtain ⟨V, hV, hzV, hVt, hVU, hVs⟩ := smooth_inverse_neighborhood e hU hq hez hz A hd
  let W := (fun u : Ambient d => (f z, u)) ⁻¹' V
  let φ : Ambient d → ℝ := fun u => (e.symm (f z, u)) 0
  have hW : IsOpen W := hV.preimage (continuous_const.prodMk continuous_id)
  have hzW : graphProjection z ∈ W := hzV
  have hi : ContDiffOn ℝ (⊤ : ℕ∞) (fun u : Ambient d => e.symm (f z, u)) W :=
    hVs.comp (contDiff_const.prodMk contDiff_id).contDiffOn (fun _ hu => hu)
  have hφ : ContDiffOn ℝ (⊤ : ℕ∞) φ W := by
    exact (EuclideanSpace.proj (0 : Fin (d + 1))).contDiff.comp_contDiffOn hi
  have hegraph (u : Ambient d) (hu : u ∈ W) :
      graphPoint u (φ u) = e.symm (f z, u) := by
    have hp : graphProjection (e.symm (f z, u)) = u := congrArg Prod.snd (e.right_inv (hVt hu))
    calc
      graphPoint u (φ u) = graphPoint (graphProjection (e.symm (f z, u))) ((e.symm (f z, u)) 0) := by
        rw [hp]
      _ = _ := graphPoint_projection_height _
  refine ⟨W, φ, hW, hzW, hφ, ?_, ?_, ?_⟩
  · intro u hu
    rw [hegraph u hu]
    exact congrArg Prod.fst (e.right_inv (hVt hu))
  · intro u hu
    rw [hegraph u hu]
    exact hVU hu
  · have hproj : ∀ᶠ x in nhds z, graphProjection x ∈ W :=
      graphProjection_lipschitz.continuous.continuousAt.preimage_mem_nhds (hW.mem_nhds hzW)
    filter_upwards [e.eventually_left_inverse hez, hproj] with x hx hpx hlevel
    rw [hegraph _ hpx]
    have hqeq : (f z, graphProjection x) = e x := by change (f z, _) = (f x, _); rw [hlevel]
    rw [hqeq]
    exact hx.symm

/-- The vertical unit vector is the first Euclidean coordinate vector. -/
theorem graphPoint_vertical_single {d : ℕ} :
    graphPoint (0 : Ambient d) 1 = EuclideanSpace.single (0 : Fin (d + 1)) 1 := by
  ext j
  refine Fin.cases ?_ (fun k => ?_) j <;> simp [graphPoint, EuclideanSpace.single_apply]

end N2Restriction
