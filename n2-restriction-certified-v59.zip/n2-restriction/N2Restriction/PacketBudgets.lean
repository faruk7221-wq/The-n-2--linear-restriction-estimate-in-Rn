import N2Restriction.HilbertPackets
import N2Restriction.InfiniteEnergy

namespace N2Restriction
open scoped ENNReal
variable {ι C E F : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E]
  [CompleteSpace E] [NormedAddCommGroup F] [NormedSpace ℂ F]

omit [CompleteSpace E] in
/-- Convert a selected coefficient energy into the nonnegative infinite-sum interface. -/
theorem selected_coefficient_energy (b : HilbertBasis ι ℂ E) (x : E) (S : Set ι) :
    selectedEnergy S (fun i => ENNReal.ofReal (‖b.repr x i‖ ^ 2)) =
      ENNReal.ofReal (∑' i : S, ‖b.repr x i‖ ^ 2) := by
  rw [selectedEnergy, ← tsum_subtype]
  exact (ENNReal.ofReal_tsum_of_nonneg (fun _ => sq_nonneg _)
    ((hilbert_coefficient_energy b x).summable.subtype S)).symm

/-- Infinite-cell norm budget for actual bounded synthesis of a Hilbert expansion.
Only the geometric incidence bound is supplied. -/
theorem hilbert_packet_incidence_budget (b : HilbertBasis ι ℂ E)
    (T : E →L[ℂ] F) (x : E) (S : C → Set ι) (M : ℝ≥0∞)
    (hM : ∀ i, (∑' c, (S c).indicator (fun _ => (1 : ℝ≥0∞)) i) ≤ M) :
    (∑' c, ENNReal.ofReal (‖∑' i : S c, T (b.repr x i • b i)‖ ^ 2)) ≤
      ENNReal.ofReal (‖T‖ ^ 2) * M * ENNReal.ofReal (‖x‖ ^ 2) := by
  have hb := infinite_selected_norm_budget S
    (fun i => ENNReal.ofReal (‖b.repr x i‖ ^ 2))
    (fun c => ENNReal.ofReal (‖∑' i : S c, T (b.repr x i • b i)‖ ^ 2))
    (ENNReal.ofReal (‖T‖ ^ 2)) M ?_ hM
  · have he := ENNReal.ofReal_tsum_of_nonneg (fun i => sq_nonneg ‖b.repr x i‖)
      (hilbert_coefficient_energy b x).summable
    rw [(hilbert_coefficient_energy b x).tsum_eq] at he
    simpa only [← he] using hb
  · intro c
    rw [selected_coefficient_energy, ← ENNReal.ofReal_mul (sq_nonneg _)]
    exact ENNReal.ofReal_le_ofReal (bounded_packet_selection b T x (S c))

end N2Restriction
