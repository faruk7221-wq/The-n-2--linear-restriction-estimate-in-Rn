import N2Restriction.CapExtensionSynthesis

namespace N2Restriction
open MeasureTheory

/-- The same actual packet regarded as a function on its finite frequency cube. -/
noncomputable def actualCapPacketInput {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume.restrict (packetFrequencyCube c r hr))) (ν : Fin d → ℤ) :
    Lp ℂ 2 (volume.restrict (packetFrequencyCube c r hr)) :=
  let t : Fin d → ℝ := fun _ => -(1 / 2 : ℝ)
  let ℓ := 2 * Real.pi * r
  let hℓ : 0 < ℓ := by dsimp [ℓ]; positivity
  capFourierCoeff t c ℓ hℓ.ne' (normalizedCapInput t c ℓ hℓ f) ν •
    capLebesgueOperator t c ℓ hℓ
      (frequencyCutoffOperator (capProbability t c ℓ hℓ.ne') c r hr (capFourierAtom t c ℓ hℓ.ne' ν))

theorem actualCapPacketInput_zeroExtension {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume.restrict (packetFrequencyCube c r hr))) (ν : Fin d → ℤ) :
    zeroExtendL2 volume (packetFrequencyCube c r hr)
      (scaledCube_measurable (fun _ => -(1 / 2 : ℝ)) c (2 * Real.pi * r) (by positivity))
      (actualCapPacketInput c r hr f ν) = actualPacketInput c r hr f ν := by
  rw [actualPacketInput_eq_mode]
  exact (zeroExtendIsometry volume (packetFrequencyCube c r hr)
    (scaledCube_measurable (fun _ => -(1 / 2 : ℝ)) c (2 * Real.pi * r) (by positivity))).map_smul _ _

theorem actualCapPacketInput_reconstruction {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume.restrict (packetFrequencyCube c r hr)))
    (hf : ∀ᵐ ξ ∂volume.restrict (packetFrequencyCube c r hr), f ξ ≠ 0 → dist ξ c ≤ r) :
    HasSum (actualCapPacketInput c r hr f) f := by
  let t : Fin d → ℝ := fun _ => -(1 / 2 : ℝ)
  let ℓ := 2 * Real.pi * r
  have hℓ : 0 < ℓ := by dsimp [ℓ]; positivity
  have hcut : ∀ᵐ ξ ∂capProbability t c ℓ hℓ.ne',
      normalizedCapInput t c ℓ hℓ f ξ ≠ 0 → (frequencyBump c r hr ξ : ℂ) = 1 := by
    have hf' := hf.filter_mono (capProbability_ae_eq t c ℓ hℓ).le
    filter_upwards [normalizedCapInput_coe t c ℓ hℓ f, hf'] with ξ hξ hh hn
    rw [frequencyBump_one c hr (hh (by simpa only [hξ] using hn)), Complex.ofReal_one]
  have h := (capLebesgueOperator t c ℓ hℓ).hasSum
    (cap_cutoff_reconstruction t c ℓ hℓ.ne' (fun ξ => (frequencyBump c r hr ξ : ℂ))
      (frequencyBump_aestronglyMeasurable _ c hr)
      (Filter.Eventually.of_forall (frequencyBump_norm_le_one c hr))
      (normalizedCapInput t c ℓ hℓ f) hcut)
  simpa only [map_smul, capLebesgue_normalizedInput, actualCapPacketInput, frequencyCutoffOperator] using h

/-- Full-space packet extension and restricted-cap extension are exactly equal. -/
theorem actualCapPacketInput_extension {d n : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume.restrict (packetFrequencyCube c r hr))) (ν : Fin d → ℤ)
    (ζ : Ambient d → Ambient n) (x : Ambient n) :
    extension (volume.restrict (packetFrequencyCube c r hr)) ζ (actualCapPacketInput c r hr f ν) x =
      extension volume ζ (actualPacketInput c r hr f ν) x := by
  rw [← extension_zeroExtendL2 (packetFrequencyCube c r hr)
    (scaledCube_measurable (fun _ => -(1 / 2 : ℝ)) c (2 * Real.pi * r) (by positivity)),
    actualCapPacketInput_zeroExtension]

/-- The constructed packets reconstruct the original extension at every physical point. -/
theorem actualPacketInput_extension_hasSum {d n : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume.restrict (packetFrequencyCube c r hr)))
    (hf : ∀ᵐ ξ ∂volume.restrict (packetFrequencyCube c r hr), f ξ ≠ 0 → dist ξ c ≤ r)
    (ζ : Ambient d → Ambient n) (hζ : Measurable ζ) (x : Ambient n) :
    HasSum (fun ν => extension volume ζ (actualPacketInput c r hr f ν) x)
      (extension (volume.restrict (packetFrequencyCube c r hr)) ζ f x) := by
  letI : IsFiniteMeasure (volume.restrict (packetFrequencyCube c r hr)) := scaledCube_isFiniteMeasure (fun _ => -(1 / 2 : ℝ)) c (2 * Real.pi * r) (by positivity)
  simpa only [actualCapPacketInput_extension] using
    extension_hasSum_of_L2 (volume.restrict (packetFrequencyCube c r hr)) ζ hζ
      (actualCapPacketInput_reconstruction c r hr f hf) x

/-- The extension reconstruction is uniform over all physical space. -/
theorem actualPacketInput_extension_uniform {d n : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume.restrict (packetFrequencyCube c r hr)))
    (hf : ∀ᵐ ξ ∂volume.restrict (packetFrequencyCube c r hr), f ξ ≠ 0 → dist ξ c ≤ r)
    (ζ : Ambient d → Ambient n) (hζ : Measurable ζ) :
    ∀ ε : ℝ, 0 < ε → ∀ᶠ s : Finset (Fin d → ℤ) in Filter.atTop, ∀ x : Ambient n,
      dist (∑ ν ∈ s, extension volume ζ (actualPacketInput c r hr f ν) x)
        (extension (volume.restrict (packetFrequencyCube c r hr)) ζ f x) < ε := by
  letI : IsFiniteMeasure (volume.restrict (packetFrequencyCube c r hr)) := scaledCube_isFiniteMeasure (fun _ => -(1 / 2 : ℝ)) c (2 * Real.pi * r) (by positivity)
  simpa only [actualCapPacketInput_extension] using
    extension_uniform_synthesis (volume.restrict (packetFrequencyCube c r hr)) ζ hζ
      (actualCapPacketInput_reconstruction c r hr f hf)

end N2Restriction
