import N2Restriction.ActualPacketCoefficients

namespace N2Restriction
open MeasureTheory

/-- A cutoff Fourier mode in ordinary full-space L2. -/
noncomputable def actualPacketMode {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (ν : Fin d → ℤ) : Lp ℂ 2 (volume : Measure (Ambient d)) :=
  let t : Fin d → ℝ := fun _ => -(1 / 2 : ℝ)
  let ℓ := 2 * Real.pi * r
  let hℓ : 0 < ℓ := by dsimp [ℓ]; positivity
  euclideanCapSynthesis t c ℓ hℓ
    (frequencyCutoffOperator (capProbability t c ℓ hℓ.ne') c r hr (capFourierAtom t c ℓ hℓ.ne' ν))

/-- Remove the cube normalization to identify the concrete mode with a graph atom. -/
theorem actualPacketMode_coe {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r) (ν : Fin d → ℤ) :
    ∀ᵐ ξ ∂(volume : Measure (Ambient d)), actualPacketMode c r hr ν ξ =
      (r ^ ((d : ℝ) / 2) : ℝ) * packetCenterPhase c r ν *
        graphAtom (packetCutoff d) c r (r⁻¹ • latticeVector ν) ξ := by
  have hc : (2 * Real.pi * r) ^ (-(d : ℝ) / 2) * r ^ ((d : ℝ) / 2) =
      (2 * Real.pi) ^ (-(d : ℝ) / 2) := by
    rw [cap_packet_normalization r hr, mul_assoc, ← Real.rpow_add hr,
      show -(d : ℝ) / 2 + (d : ℝ) / 2 = 0 by ring, Real.rpow_zero, mul_one]
  have hn : (((2 * Real.pi * r) ^ (-(d : ℝ) / 2) : ℝ) : ℂ) ≠ 0 := by
    exact_mod_cast (Real.rpow_pos_of_pos (by positivity : 0 < 2 * Real.pi * r) _).ne'
  filter_upwards [euclidean_cutoff_mode_eq_graphAtom c r hr ν] with ξ hξ
  apply mul_left_cancel₀ hn
  change (((2 * Real.pi * r) ^ (-(d : ℝ) / 2) : ℝ) : ℂ) * actualPacketMode c r hr ν ξ = _ at hξ
  rw [hξ]
  have hc' := congrArg (fun x : ℝ => (x : ℂ)) hc
  push_cast at hc'
  change _ = _ * ((_ * packetCenterPhase c r ν) * _)
  rw [← mul_assoc, ← mul_assoc, hc']
  rfl

/-- A legitimate L2 graph atom before multiplying by the input coefficient. -/
noncomputable def graphAtomL2 {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (ν : Fin d → ℤ) : Lp ℂ 2 (volume : Measure (Ambient d)) :=
  (graphAtom_memLp (packetCutoff_smooth d).continuous (packetCutoff_compact d) c hr
    (r⁻¹ • latticeVector ν)).toLp _

theorem graphAtomL2_coe {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r) (ν : Fin d → ℤ) :
    graphAtomL2 c r hr ν =ᵐ[volume] graphAtom (packetCutoff d) c r (r⁻¹ • latticeVector ν) :=
  MemLp.coeFn_toLp _

/-- The actual packet input associated with the original cap input f. -/
noncomputable def actualPacketInput {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume.restrict (packetFrequencyCube c r hr))) (ν : Fin d → ℤ) :
    Lp ℂ 2 (volume : Measure (Ambient d)) :=
  actualPacketCoeff c r hr f ν • graphAtomL2 c r hr ν

theorem actualPacketInput_coe {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume.restrict (packetFrequencyCube c r hr))) (ν : Fin d → ℤ) :
    actualPacketInput c r hr f ν =ᵐ[volume] fun ξ => actualPacketCoeff c r hr f ν *
      graphAtom (packetCutoff d) c r (r⁻¹ • latticeVector ν) ξ := by
  filter_upwards [Lp.coeFn_smul (actualPacketCoeff c r hr f ν) (graphAtomL2 c r hr ν),
    graphAtomL2_coe c r hr ν] with ξ hξ hg
  change actualPacketInput c r hr f ν ξ = _ at hξ
  simpa only [Pi.smul_apply, smul_eq_mul, hg] using hξ

/-- Exact identification of the reconstructed Fourier packet with the graph packet input. -/
theorem actualPacketInput_eq_mode {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume.restrict (packetFrequencyCube c r hr))) (ν : Fin d → ℤ) :
    actualPacketInput c r hr f ν =
      capFourierCoeff (fun _ => -(1 / 2 : ℝ)) c (2 * Real.pi * r) (by positivity)
        (normalizedCapInput (fun _ => -(1 / 2 : ℝ)) c (2 * Real.pi * r) (by positivity) f) ν •
      actualPacketMode c r hr ν := by
  apply Lp.ext
  filter_upwards [actualPacketInput_coe c r hr f ν, actualPacketMode_coe c r hr ν,
    Lp.coeFn_smul (capFourierCoeff (fun _ => -(1 / 2 : ℝ)) c (2 * Real.pi * r) (by positivity)
      (normalizedCapInput (fun _ => -(1 / 2 : ℝ)) c (2 * Real.pi * r) (by positivity) f) ν)
      (actualPacketMode c r hr ν)] with ξ hi hm hsm
  rw [hi, hsm, Pi.smul_apply, smul_eq_mul, hm, actualPacketCoeff, packetTorusInput_coefficient]
  ring

/-- The original cap input, supported in the inner ball, is the unconditional
sum of the actual graph-packet inputs in ordinary Euclidean L2. -/
theorem actualPacketInput_reconstruction {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume.restrict (packetFrequencyCube c r hr)))
    (hf : ∀ᵐ ξ ∂volume.restrict (packetFrequencyCube c r hr), f ξ ≠ 0 → dist ξ c ≤ r) :
    HasSum (actualPacketInput c r hr f)
      (zeroExtendL2 volume (packetFrequencyCube c r hr)
        (scaledCube_measurable (fun _ => -(1 / 2 : ℝ)) c (2 * Real.pi * r) (by positivity)) f) := by
  have hcut : ∀ᵐ ξ ∂volume.restrict (packetFrequencyCube c r hr),
      f ξ ≠ 0 → (frequencyBump c r hr ξ : ℂ) = 1 := by
    filter_upwards [hf] with ξ hξ hn
    rw [frequencyBump_one c hr (hξ hn), Complex.ofReal_one]
  have h := euclidean_cap_cutoff_reconstruction (fun _ => -(1 / 2 : ℝ)) c
    (2 * Real.pi * r) (by positivity) (fun ξ => (frequencyBump c r hr ξ : ℂ))
    (frequencyBump_aestronglyMeasurable _ c hr)
    (Filter.Eventually.of_forall (frequencyBump_norm_le_one c hr)) f hcut
  convert h using 1
  funext ν
  exact actualPacketInput_eq_mode c r hr f ν

/-- The actual extension of each constructed packet is the analyzed graph integral. -/
theorem actualPacketInput_extension {d : ℕ} (φ : Ambient d → ℝ)
    (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume.restrict (packetFrequencyCube c r hr))) (ν : Fin d → ℤ)
    (u : Ambient d) (t : ℝ) :
    extension volume (fun ξ => graphPoint ξ (φ ξ)) (actualPacketInput c r hr f ν) (graphPoint u t) =
      actualPacketCoeff c r hr f ν * graphPacket φ (packetCutoff d) c r (r⁻¹ • latticeVector ν) u t := by
  rw [← extension_graphAtom]
  unfold extension
  rw [← integral_const_mul]
  apply integral_congr_ae
  filter_upwards [actualPacketInput_coe c r hr f ν] with ξ hξ
  rw [hξ]
  ring

end N2Restriction
