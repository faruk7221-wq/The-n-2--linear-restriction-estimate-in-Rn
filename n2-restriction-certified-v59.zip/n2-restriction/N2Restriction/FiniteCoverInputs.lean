import N2Restriction.FinitePatchPlancherel

namespace N2Restriction
open MeasureTheory Set

/-- A finite disjoint measurable partition reconstructs the indicator of its union. -/
theorem sum_disjoint_indicators {Ω ι M : Type*} [Fintype ι] [AddCommMonoid M]
    (D : ι → Set Ω) (hd : Pairwise (fun i j => Disjoint (D i) (D j))) (f : Ω → M) (x : Ω) :
    (∑ j, (D j).indicator f x) = (⋃ j, D j).indicator f x := by
  classical
  by_cases hx : x ∈ ⋃ j, D j
  · obtain ⟨j, hj⟩ := mem_iUnion.mp hx
    rw [indicator_of_mem hx, Finset.sum_eq_single j, indicator_of_mem hj]
    · intro i _ hij
      apply indicator_of_notMem
      intro hi
      exact Set.disjoint_left.mp (hd hij) hi hj
    · simp
  · rw [indicator_of_notMem hx]
    apply Finset.sum_eq_zero
    intro j _
    apply indicator_of_notMem
    exact fun hj => hx (mem_iUnion.mpr ⟨j, hj⟩)

/-- Finite covers have a canonical measurable, disjoint refinement. -/
theorem measurableSet_disjointed_fin {Ω : Type*} [MeasurableSpace Ω] {m : ℕ}
    (K : Fin m → Set Ω) (hK : ∀ j, MeasurableSet (K j)) (j : Fin m) :
    MeasurableSet (disjointed K j) :=
  disjointedRec (fun _ _ ht => MeasurableSet.diff ht (hK _)) (hK j)

/-- The input assigned to one chart is the indicator of its disjoint refinement. -/
noncomputable def finiteCoverInput {Ω : Type*} [MeasurableSpace Ω] {m : ℕ}
    (μ : Measure Ω) (K : Fin m → Set Ω) (hK : ∀ j, MeasurableSet (K j))
    (g : Lp ℂ 2 μ) (j : Fin m) : Lp ℂ 2 μ :=
  ((Lp.memLp g).indicator (measurableSet_disjointed_fin K hK j)).toLp
    ((disjointed K j).indicator g)

theorem finiteCoverInput_coe {Ω : Type*} [MeasurableSpace Ω] {m : ℕ}
    (μ : Measure Ω) (K : Fin m → Set Ω) (hK : ∀ j, MeasurableSet (K j))
    (g : Lp ℂ 2 μ) (j : Fin m) :
    finiteCoverInput μ K hK g j =ᵐ[μ] (disjointed K j).indicator g :=
  MemLp.coeFn_toLp _

theorem finiteCoverInput_support {Ω : Type*} [MeasurableSpace Ω] {m : ℕ}
    (μ : Measure Ω) (K : Fin m → Set Ω) (hK : ∀ j, MeasurableSet (K j))
    (g : Lp ℂ 2 μ) (j : Fin m) :
    HasFrequencySupport μ id (K j) (finiteCoverInput μ K hK g j) := by
  filter_upwards [finiteCoverInput_coe μ K hK g j] with x hx hn
  apply disjointed_subset K j
  by_contra h
  exact hn (hx.trans (indicator_of_notMem h _))

/-- Disjoint chart assignment spends at most the original input energy. -/
theorem finiteCoverInput_energy {Ω : Type*} [MeasurableSpace Ω] {m : ℕ}
    (μ : Measure Ω) (K : Fin m → Set Ω) (hK : ∀ j, MeasurableSet (K j))
    (g : Lp ℂ 2 μ) : (∑ j, ‖finiteCoverInput μ K hK g j‖ ^ 2) ≤ ‖g‖ ^ 2 := by
  have h := indicator_cap_energy (μ := μ) (disjointed K)
    (measurableSet_disjointed_fin K hK) (M := 1) ?_ g
  · simpa only [finiteCoverInput, one_mul] using h
  · apply ae_of_all
    intro x
    rw [sum_disjoint_indicators _ (disjoint_disjointed K)]
    exact indicator_le_self' (fun _ _ => zero_le_one) x

/-- Every input supported on the finite cover is recovered exactly. -/
theorem finiteCoverInput_reconstruction {Ω : Type*} [MeasurableSpace Ω] {m : ℕ}
    (μ : Measure Ω) (K : Fin m → Set Ω) (hK : ∀ j, MeasurableSet (K j))
    (g : Lp ℂ 2 μ) (hg : HasFrequencySupport μ id (⋃ j, K j) g) :
    (∑ j, finiteCoverInput μ K hK g j) = g := by
  apply Lp.ext
  filter_upwards [L2_coe_finset_sum μ (finiteCoverInput μ K hK g) Finset.univ,
    ae_all_iff.mpr (finiteCoverInput_coe μ K hK g), hg] with x hsum hp hs
  rw [hsum]
  simp_rw [hp]
  rw [sum_disjoint_indicators _ (disjoint_disjointed K), iUnion_disjointed]
  by_cases hz : g x = 0
  · simp [hz]
  · exact indicator_of_mem (hs hz) _

/-- Constructed chart assignment combines all local bounds for a finite cover. -/
theorem ball_energy_of_finite_cover {n m : ℕ}
    (μ : Measure (Ambient n)) [IsFiniteMeasure μ]
    (K : Fin m → Set (Ambient n)) (hK : ∀ j, MeasurableSet (K j))
    {C : ℝ} (hC : 0 ≤ C) (hb : ∀ j, HasBallEnergyBound (μ.restrict (K j)) C)
    (g : Lp ℂ 2 μ) (hg : HasFrequencySupport μ id (⋃ j, K j) g)
    (x₀ : Ambient n) {R : ℝ} (hR : 0 ≤ R) :
    (∫ y in Metric.ball x₀ R, ‖extension μ id g y‖ ^ 2) ≤ (m : ℝ) * C * R * ‖g‖ ^ 2 := by
  simpa only [Fintype.card_fin] using ball_energy_of_finite_pieces μ K hK hC hb g
    (finiteCoverInput μ K hK g) (finiteCoverInput_support μ K hK g)
    (finiteCoverInput_reconstruction μ K hK g hg) (finiteCoverInput_energy μ K hK g) x₀ hR

end N2Restriction
