import N2Restriction.PacketApproximation
import N2Restriction.SmoothSliceL2

namespace N2Restriction
open MeasureTheory Filter Set
open scoped Topology ENNReal

/-- A graph map is continuous as soon as its height function is continuous. -/
theorem continuous_graphMap {d : ℕ} {φ : Ambient d → ℝ} (hφ : Continuous φ) :
    Continuous (fun x => graphPoint x (φ x)) := by
  apply (PiLp.continuous_toLp 2 (fun _ : Fin (d + 1) => ℝ)).comp
  apply continuous_pi
  intro i
  refine Fin.cases ?_ (fun j => ?_) i
  · exact hφ
  · exact (EuclideanSpace.proj j).continuous

/-- Compact essential support makes an arbitrary coordinate L2 input integrable. -/
theorem integrable_of_compact_frequency_support {d : ℕ} {K : Set (Ambient d)}
    (hK : IsCompact K) (f : Lp ℂ 2 (volume : Measure (Ambient d)))
    (hf : HasFrequencySupport volume id K f) : Integrable f volume := by
  letI : IsFiniteMeasure (volume.restrict K) := ⟨by
    rw [Measure.restrict_apply_univ]
    exact hK.measure_lt_top⟩
  have hi : Integrable f (volume.restrict K) := ((Lp.memLp f).restrict K).integrable (by norm_num)
  have hind := (integrable_indicator_iff hK.measurableSet).mpr hi
  apply hind.congr
  filter_upwards [hf] with x hx
  by_cases h : x ∈ K
  · exact indicator_of_mem h _
  · rw [indicator_of_notMem h]
    symm
    by_contra hn
    exact h (hx hn)

/-- Fatou's lemma closes slice Plancherel for arbitrary compactly supported coordinate L2 data.
The smooth approximants are constructed from the packet expansion. -/
theorem compact_graph_slice_eLpNorm {d : ℕ} {φ : Ambient d → ℝ}
    (hφ : ContDiff ℝ (⊤ : ℕ∞) φ) {K : Set (Ambient d)} (hK : IsCompact K)
    (f : Lp ℂ 2 (volume : Measure (Ambient d))) (hf : HasFrequencySupport volume id K f)
    (t : ℝ) :
    eLpNorm (fun u => extension volume (fun x => graphPoint x (φ x)) f (graphPoint u t)) 2 ≤
      ENNReal.ofReal (((2 * Real.pi) ^ d * ‖f‖ ^ 2) ^ (1 / 2 : ℝ)) := by
  obtain ⟨_, _, hP⟩ := exists_coordinate_cap_families hK
  obtain ⟨P, _⟩ := hP 1 (by norm_num) le_rfl
  let a := P.smoothApproximation (by norm_num : (0 : ℝ) < 1) f
  have ha (n : ℕ) := P.smoothApproximation_regular (by norm_num : (0 : ℝ) < 1) f n
  have hζ : Measurable (fun x => graphPoint x (φ x)) :=
    (continuous_graphMap hφ.continuous).measurable
  have hconv : ∀ᵐ u : Ambient d ∂volume,
      Tendsto (fun n => extension volume (fun x => graphPoint x (φ x)) (a n) (graphPoint u t))
        atTop (𝓝 (extension volume (fun x => graphPoint x (φ x)) f (graphPoint u t))) :=
    ae_of_all _ fun u => P.smoothApproximation_extension_tendsto (by norm_num) hK f hf _ hζ _
  have hfatou := Lp.eLpNorm_lim_le_liminf_eLpNorm
    (p := (2 : ℝ≥0∞))
    (fun n => (smooth_graph_slice_memLp hφ (ha n).1 (ha n).2 t).aestronglyMeasurable)
    _ hconv
  have hener := P.smoothApproximation_energy_tendsto (by norm_num : (0 : ℝ) < 1) f hf
  have hlim : Tendsto
      (fun n => ENNReal.ofReal (((2 * Real.pi) ^ d * ∫ x, ‖a n x‖ ^ 2) ^ (1 / 2 : ℝ)))
      atTop (𝓝 (ENNReal.ofReal (((2 * Real.pi) ^ d * ‖f‖ ^ 2) ^ (1 / 2 : ℝ)))) := by
    exact ENNReal.continuous_ofReal.continuousAt.tendsto.comp
      ((Real.continuous_rpow_const (by norm_num : (0 : ℝ) ≤ 1 / 2)).continuousAt.tendsto.comp
        (tendsto_const_nhds.mul hener))
  simp_rw [smooth_graph_slice_eLpNorm hφ (ha _).1 (ha _).2 t] at hfatou
  exact hfatou.trans_eq hlim.liminf_eq

/-- Arbitrary compactly supported coordinate L2 inputs have square-integrable graph slices. -/
theorem compact_graph_slice_memLp {d : ℕ} {φ : Ambient d → ℝ}
    (hφ : ContDiff ℝ (⊤ : ℕ∞) φ) {K : Set (Ambient d)} (hK : IsCompact K)
    (f : Lp ℂ 2 (volume : Measure (Ambient d))) (hf : HasFrequencySupport volume id K f)
    (t : ℝ) :
    MemLp (fun u => extension volume (fun x => graphPoint x (φ x)) f (graphPoint u t)) 2 := by
  have hc := continuous_extension (continuous_graphMap hφ.continuous).measurable
    (integrable_of_compact_frequency_support hK f hf)
  have hp : Continuous (fun u : Ambient d => graphPoint u t) := continuous_graphMap continuous_const
  exact ⟨(hc.comp hp).aestronglyMeasurable,
    (compact_graph_slice_eLpNorm hφ hK f hf t).trans_lt ENNReal.ofReal_lt_top⟩

/-- The real-valued local Plancherel energy bound for rough compact coordinate inputs. -/
theorem compact_graph_slice_energy {d : ℕ} {φ : Ambient d → ℝ}
    (hφ : ContDiff ℝ (⊤ : ℕ∞) φ) {K : Set (Ambient d)} (hK : IsCompact K)
    (f : Lp ℂ 2 (volume : Measure (Ambient d))) (hf : HasFrequencySupport volume id K f)
    (t : ℝ) :
    (∫ u, ‖extension volume (fun x => graphPoint x (φ x)) f (graphPoint u t)‖ ^ 2) ≤
      (2 * Real.pi) ^ d * ‖f‖ ^ 2 := by
  have h := compact_graph_slice_eLpNorm hφ hK f hf t
  rw [(compact_graph_slice_memLp hφ hK f hf t).eLpNorm_eq_integral_rpow_norm
    (by norm_num) (by norm_num)] at h
  norm_num only [ENNReal.toReal_ofNat, Real.rpow_two] at h
  rw [← Real.sqrt_eq_rpow, ← Real.sqrt_eq_rpow] at h
  have hh := (ENNReal.ofReal_le_ofReal_iff (Real.sqrt_nonneg _)).mp h
  exact (Real.sqrt_le_sqrt_iff (by positivity)).mp hh

end N2Restriction
