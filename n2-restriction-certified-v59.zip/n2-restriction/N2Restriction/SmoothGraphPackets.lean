import N2Restriction.SmoothGraphRemainder
import N2Restriction.RoundTubePackets
import Mathlib.Analysis.InnerProductSpace.Dual

namespace N2Restriction

/-- The actual Euclidean gradient, represented from the Fréchet derivative. -/
noncomputable def graphGradient {d : ℕ} (φ : Ambient d → ℝ) (c : Ambient d) : Ambient d :=
  (InnerProductSpace.toDual ℝ (Ambient d)).symm (fderiv ℝ φ c)

theorem graphGradient_inner {d : ℕ} (φ : Ambient d → ℝ) (c η : Ambient d) :
    inner ℝ (graphGradient φ c) η = fderiv ℝ φ c η :=
  InnerProductSpace.toDual_symm_apply

theorem smooth_graphGradient {d : ℕ} {φ : Ambient d → ℝ}
    (hφ : ContDiff ℝ (⊤ : ℕ∞) φ) : ContDiff ℝ (⊤ : ℕ∞) (graphGradient φ) := by
  exact (InnerProductSpace.toDual ℝ (Ambient d)).symm.toContinuousLinearEquiv.contDiff.comp
    (contDiff_infty_iff_fderiv.mp hφ).2

/-- General smooth graph packets, uniformly over compact cap centers and all
positive scales at most r₀. The Taylor family is constructed, not assumed. -/
theorem smooth_graph_packet_decay {d : ℕ} {φ : Ambient d → ℝ}
    (hφ : ContDiff ℝ (⊤ : ℕ∞) φ) {Q : Set (Ambient d)} (hQ : IsCompact Q)
    {χ : Ambient d → ℂ} (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hs : HasCompactSupport χ)
    (r₀ : ℝ) (M : ℕ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ c ∈ Q, ∀ r : ℝ, 0 < r → r ≤ r₀ →
      ∀ (v u : Ambient d) (t : ℝ), |t * r ^ 2| ≤ 1 →
      ‖graphPacket φ χ c r v u t‖ ≤ r ^ ((d : ℝ) / 2) *
        (C / (1 + r * ‖u + v + t • graphGradient φ c‖) ^ M) := by
  obtain ⟨C, hC, hb⟩ := graph_packet_decay_of_compact_remainders
    (smooth_graphTaylorRemainder hφ) (hQ.prod (isCompact_Icc : IsCompact (Set.Icc 0 r₀)))
    hχ hs M
  refine ⟨C, hC, fun c hc r hr hrr v u t ht => ?_⟩
  apply hb φ c r hr (graphGradient φ c) (c, r) ⟨hc, hr.le, hrr⟩ _ v u t ht
  intro η
  rw [graphGradient_inner]
  exact graphTaylorRemainder_identity hφ c η r

/-- The actual gradient is uniformly bounded on a compact center family. -/
theorem compact_graphGradient_bound {d : ℕ} {φ : Ambient d → ℝ}
    (hφ : ContDiff ℝ (⊤ : ℕ∞) φ) {Q : Set (Ambient d)} (hQ : IsCompact Q) :
    ∃ K : ℝ, 0 < K ∧ ∀ c ∈ Q, ‖graphGradient φ c‖ ≤ K := by
  obtain ⟨K, hK, hb⟩ := (hQ.image (smooth_graphGradient hφ).continuous).isBounded.exists_pos_norm_le
  exact ⟨K, hK, fun c hc => hb _ ⟨c, hc, rfl⟩⟩

/-- Parabolic rescaling for a general globally smooth graph. -/
theorem smooth_graph_packet_decay_at_scale {d : ℕ} {φ : Ambient d → ℝ}
    (hφ : ContDiff ℝ (⊤ : ℕ∞) φ) {Q : Set (Ambient d)} (hQ : IsCompact Q)
    {χ : Ambient d → ℂ} (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hs : HasCompactSupport χ)
    (M : ℕ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (R : ℝ), 1 ≤ R →
      ∀ c ∈ Q, ∀ (v u : Ambient d) (t : ℝ), |t| ≤ R →
      ‖graphPacket φ χ c (R ^ (-1 / 2 : ℝ)) v u t‖ ≤ R ^ (-(d : ℝ) / 4) *
        (C / (1 + R ^ (-1 / 2 : ℝ) * ‖u + v + t • graphGradient φ c‖) ^ M) := by
  obtain ⟨C, hC, hb⟩ := smooth_graph_packet_decay hφ hQ hχ hs 1 M
  refine ⟨C, hC, fun R hR c hc v u t ht => ?_⟩
  have hRp : 0 < R := by linarith
  have hr := Real.rpow_pos_of_pos hRp (-1 / 2 : ℝ)
  have hr1 : R ^ (-1 / 2 : ℝ) ≤ 1 := Real.rpow_le_one_of_one_le_of_nonpos hR (by norm_num)
  have h := hb c hc _ hr hr1 v u t (parabolic_time_parameter hRp ht)
  have he : (R ^ (-1 / 2 : ℝ)) ^ ((d : ℝ) / 2) = R ^ (-(d : ℝ) / 4) := by
    rw [← Real.rpow_mul hRp.le]
    congr 1
    ring
  simpa only [he] using h

/-- General smooth-graph localization in round finite tubes. -/
theorem smooth_graph_packet_round_segment_decay {d : ℕ} {φ : Ambient d → ℝ}
    (hφ : ContDiff ℝ (⊤ : ℕ∞) φ) {Q : Set (Ambient d)} (hQ : IsCompact Q)
    {χ : Ambient d → ℂ} (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hs : HasCompactSupport χ)
    (M : ℕ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (R : ℝ), 1 ≤ R →
      ∀ c ∈ Q, ∀ (v u : Ambient d) (t : ℝ), |t| ≤ R →
      ‖graphPacket φ χ c (R ^ (-1 / 2 : ℝ)) v u t‖ ≤ R ^ (-(d : ℝ) / 4) *
        (C / (1 + R ^ (-1 / 2 : ℝ) * Metric.infDist (graphPoint u t)
          (packetSegment (graphGradient φ c) v R)) ^ M) := by
  obtain ⟨C, hC, hb⟩ := smooth_graph_packet_decay_at_scale hφ hQ hχ hs M
  refine ⟨C, hC, fun R hR c hc v u t ht => (hb R hR c hc v u t ht).trans ?_⟩
  have hRp : 0 < R := by linarith
  have hd := packetSegment_dist_le_offset (graphGradient φ c) v u ht
  have hn := Metric.infDist_nonneg (x := graphPoint u t)
    (s := packetSegment (graphGradient φ c) v R)
  gcongr

/-- Uniform finite Euclidean axis lengths follow from the actual gradient,
with no separate slope bound assumed. -/
theorem smooth_graph_tube_length_bound {d : ℕ} {φ : Ambient d → ℝ}
    (hφ : ContDiff ℝ (⊤ : ℕ∞) φ) {Q : Set (Ambient d)} (hQ : IsCompact Q) :
    ∃ K : ℝ, 0 < K ∧ ∀ c ∈ Q, ∀ (v : Ambient d) (R : ℝ),
      ∀ x ∈ packetSegment (graphGradient φ c) v R,
      ∀ y ∈ packetSegment (graphGradient φ c) v R, dist x y ≤ K * R := by
  obtain ⟨B, hB, hb⟩ := compact_graphGradient_bound hφ hQ
  refine ⟨2 * Real.sqrt (1 + B ^ 2), by positivity, ?_⟩
  intro c hc v R x hx y hy
  exact (packetSegment_pairwise_distance hB.le _ v (hb c hc) hx hy).trans_eq (by ring)

end N2Restriction
