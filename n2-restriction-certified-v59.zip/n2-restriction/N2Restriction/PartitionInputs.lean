import N2Restriction.QuantitativeCapPartition
import N2Restriction.RestrictedInput

namespace N2Restriction
open MeasureTheory Set

/-- A partition multiplier, applied to the actual ordinary Euclidean L2 input. -/
noncomputable def partitionL2Piece {d : ℕ} {ι : Type*} [Fintype ι] {K : Set (Ambient d)}
    (ρ : PartitionOfUnity ι (Ambient d) K) (f : Lp ℂ 2 (volume : Measure (Ambient d))) (j : ι) :
    Lp ℂ 2 (volume : Measure (Ambient d)) :=
  cutoffOperator (fun x => (ρ j x : ℂ))
    (Complex.continuous_ofReal.comp (ρ j).continuous).aestronglyMeasurable
    (Filter.Eventually.of_forall (fun x => by
      simpa only [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (ρ.nonneg j x)] using ρ.le_one j x)) f

theorem partitionL2Piece_coe {d : ℕ} {ι : Type*} [Fintype ι] {K : Set (Ambient d)}
    (ρ : PartitionOfUnity ι (Ambient d) K) (f : Lp ℂ 2 (volume : Measure (Ambient d))) (j : ι) :
    partitionL2Piece ρ f j =ᵐ[volume] fun x => (ρ j x : ℂ) * f x := by
  exact cutoffL2_coe (fun x => (ρ j x : ℂ))
    (Complex.continuous_ofReal.comp (ρ j).continuous).aestronglyMeasurable
    (C := 1) (Filter.Eventually.of_forall (fun x => by
      simpa only [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (ρ.nonneg j x)] using ρ.le_one j x)) f

theorem partitionL2Piece_support {d : ℕ} {ι : Type*} [Fintype ι] {K : Set (Ambient d)}
    (ρ : PartitionOfUnity ι (Ambient d) K) (f : Lp ℂ 2 (volume : Measure (Ambient d)))
    (c : ι → Ambient d) {r : ℝ} (hs : ∀ j, Function.support (ρ j) ⊆ Metric.ball (c j) r) (j : ι) :
    HasFrequencySupport volume id (Metric.ball (c j) r) (partitionL2Piece ρ f j) := by
  filter_upwards [partitionL2Piece_coe ρ f j] with x hx hn
  apply hs j
  intro hz
  change ρ j x = 0 at hz
  exact hn (by rw [hx, hz, Complex.ofReal_zero, zero_mul])

/-- The constructed partition pieces have total input energy at most the original energy. -/
theorem partitionL2Piece_energy {d : ℕ} {ι : Type*} [Fintype ι] {K : Set (Ambient d)}
    (ρ : PartitionOfUnity ι (Ambient d) K) (f : Lp ℂ 2 (volume : Measure (Ambient d))) :
    (∑ j, ‖partitionL2Piece ρ f j‖ ^ 2) ≤ ‖f‖ ^ 2 := by
  have hweight : ∀ᵐ x ∂(volume : Measure (Ambient d)), (∑ j, ‖(ρ j x : ℂ)‖ ^ 2) ≤ 1 := by
    apply Filter.Eventually.of_forall
    intro x
    simp only [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (ρ.nonneg _ x)]
    have hsq (j) : (ρ j x) ^ 2 ≤ ρ j x := by
      have h0 := ρ.nonneg j x
      have h1 := ρ.le_one j x
      nlinarith
    exact (Finset.sum_le_sum (fun j _ => hsq j)).trans (by
      simpa only [finsum_eq_sum_of_fintype] using ρ.sum_le_one x)
  have h := cutoff_cap_energy (fun j x => (ρ j x : ℂ))
    (fun j => (Complex.continuous_ofReal.comp (ρ j).continuous).aestronglyMeasurable)
    (C := 1) (fun j => Filter.Eventually.of_forall (fun x => by
      simpa only [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (ρ.nonneg j x)] using ρ.le_one j x))
    hweight f
  simpa only [partitionL2Piece, one_mul] using h

/-- The cap pieces reconstruct every input essentially supported on the partition domain. -/
theorem partitionL2Piece_reconstruction {d : ℕ} {ι : Type*} [Fintype ι] {K : Set (Ambient d)}
    (ρ : PartitionOfUnity ι (Ambient d) K) (f : Lp ℂ 2 (volume : Measure (Ambient d)))
    (hf : HasFrequencySupport volume id K f) : (∑ j, partitionL2Piece ρ f j) = f := by
  apply Lp.ext
  filter_upwards [L2_coe_finset_sum volume (partitionL2Piece ρ f) Finset.univ,
    ae_all_iff.mpr (partitionL2Piece_coe ρ f), hf] with x hsum hpieces hfx
  rw [hsum]
  simp_rw [hpieces]
  rw [← Finset.sum_mul, ← Complex.ofReal_sum]
  by_cases hz : f x = 0
  · simp [hz]
  · have hρ : ∑ j, ρ j x = 1 := by
      simpa only [finsum_eq_sum_of_fintype] using ρ.sum_eq_one (hfx hz)
    rw [hρ, Complex.ofReal_one, one_mul]

/-- Each partition piece is put in the ordinary finite-cube space expected by the packets. -/
noncomputable def partitionCapInput {d : ℕ} {ι : Type*} [Fintype ι] {K : Set (Ambient d)}
    (ρ : PartitionOfUnity ι (Ambient d) K) (c : ι → Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume : Measure (Ambient d))) (j : ι) :
    Lp ℂ 2 (volume.restrict (packetFrequencyCube (c j) r hr)) :=
  restrictInputL2 volume (packetFrequencyCube (c j) r hr) (partitionL2Piece ρ f j)

theorem partitionL2Piece_cube_support {d : ℕ} {ι : Type*} [Fintype ι] {K : Set (Ambient d)}
    (ρ : PartitionOfUnity ι (Ambient d) K) (c : ι → Ambient d) (r : ℝ) (hr : 0 < r)
    (hs : ∀ j, Function.support (ρ j) ⊆ Metric.ball (c j) r)
    (f : Lp ℂ 2 (volume : Measure (Ambient d))) (j : ι) :
    HasFrequencySupport volume id (packetFrequencyCube (c j) r hr) (partitionL2Piece ρ f j) := by
  apply (partitionL2Piece_support ρ f c hs j).mono
  intro x hx
  apply closedBall_subset_packetFrequencyCube (c j) r hr
  have hh : dist x (c j) < r := hx
  change dist x (c j) ≤ 2 * r
  linarith

theorem partitionCapInput_zeroExtension {d : ℕ} {ι : Type*} [Fintype ι] {K : Set (Ambient d)}
    (ρ : PartitionOfUnity ι (Ambient d) K) (c : ι → Ambient d) (r : ℝ) (hr : 0 < r)
    (hs : ∀ j, Function.support (ρ j) ⊆ Metric.ball (c j) r)
    (f : Lp ℂ 2 (volume : Measure (Ambient d))) (j : ι) :
    zeroExtendL2 volume (packetFrequencyCube (c j) r hr)
      (scaledCube_measurable (fun _ => -(1 / 2 : ℝ)) (c j) (2 * Real.pi * r) (by positivity))
      (partitionCapInput ρ c r hr f j) = partitionL2Piece ρ f j :=
  zeroExtend_restrictInput volume _ _ _ (partitionL2Piece_cube_support ρ c r hr hs f j)

theorem partitionCapInput_norm {d : ℕ} {ι : Type*} [Fintype ι] {K : Set (Ambient d)}
    (ρ : PartitionOfUnity ι (Ambient d) K) (c : ι → Ambient d) (r : ℝ) (hr : 0 < r)
    (hs : ∀ j, Function.support (ρ j) ⊆ Metric.ball (c j) r)
    (f : Lp ℂ 2 (volume : Measure (Ambient d))) (j : ι) :
    ‖partitionCapInput ρ c r hr f j‖ = ‖partitionL2Piece ρ f j‖ :=
  restrictInputL2_norm_of_support volume _
    (scaledCube_measurable (fun _ => -(1 / 2 : ℝ)) (c j) (2 * Real.pi * r) (by positivity)) _
    (partitionL2Piece_cube_support ρ c r hr hs f j)

theorem partitionCapInput_energy {d : ℕ} {ι : Type*} [Fintype ι] {K : Set (Ambient d)}
    (ρ : PartitionOfUnity ι (Ambient d) K) (c : ι → Ambient d) (r : ℝ) (hr : 0 < r)
    (hs : ∀ j, Function.support (ρ j) ⊆ Metric.ball (c j) r)
    (f : Lp ℂ 2 (volume : Measure (Ambient d))) :
    (∑ j, ‖partitionCapInput ρ c r hr f j‖ ^ 2) ≤ ‖f‖ ^ 2 := by
  simp_rw [partitionCapInput_norm ρ c r hr hs]
  exact partitionL2Piece_energy ρ f

theorem partitionCapInput_inner_support {d : ℕ} {ι : Type*} [Fintype ι] {K : Set (Ambient d)}
    (ρ : PartitionOfUnity ι (Ambient d) K) (c : ι → Ambient d) (r : ℝ) (hr : 0 < r)
    (hs : ∀ j, Function.support (ρ j) ⊆ Metric.ball (c j) r)
    (f : Lp ℂ 2 (volume : Measure (Ambient d))) (j : ι) :
    ∀ᵐ x ∂volume.restrict (packetFrequencyCube (c j) r hr),
      partitionCapInput ρ c r hr f j x ≠ 0 → dist x (c j) ≤ r := by
  have h : ∀ᵐ x ∂volume.restrict (packetFrequencyCube (c j) r hr),
      partitionL2Piece ρ f j x ≠ 0 → x ∈ Metric.ball (c j) r :=
    (partitionL2Piece_support ρ f c hs j).filter_mono (ae_mono Measure.restrict_le_self)
  filter_upwards [restrictInputL2_coe volume (packetFrequencyCube (c j) r hr) (partitionL2Piece ρ f j), h]
    with x hx hh hn
  exact (hh (by simpa only [partitionCapInput, hx] using hn)).le

end N2Restriction
