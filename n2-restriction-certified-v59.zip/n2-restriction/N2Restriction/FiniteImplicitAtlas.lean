import N2Restriction.UniformImplicit
import Mathlib.Analysis.Calculus.MeanValue

namespace N2Restriction
open Metric Filter

/-- A chart model packages its free subspace together with the coordinate map. -/
structure SubmersionChartModel (E F : Type*)
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] where
  free : Submodule ℝ E
  chart : OpenPartialHomeomorph E (F × free)

/-- Control for a specified chart model, retaining its identity when the base
point moves. This makes a finite atlas expressible as a finite set of models. -/
def SubmersionChartModel.Controls {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    (c : SubmersionChartModel E F) (f : E → F) (U : Set E)
    (x : E) (r : ℝ) (B : ℕ → ℝ) : Prop :=
  Module.finrank ℝ c.free + Module.finrank ℝ F = Module.finrank ℝ E ∧
    (∃ z ∈ U, c.free = LinearMap.ker (fderiv ℝ f z).toLinearMap) ∧
    x ∈ c.chart.source ∧ ball x r ⊆ c.chart.source ∧
    (∀ y, (c.chart y).1 = f y) ∧
    ContDiffOn ℝ (⊤ : ℕ∞) (c.chart : E → F × c.free) U ∧
    closedBall (c.chart x) r ⊆ c.chart.target ∧
    Set.MapsTo c.chart.symm (closedBall (c.chart x) r) U ∧
    (∀ y ∈ closedBall (c.chart x) r,
      ContDiffAt ℝ (⊤ : ℕ∞) (c.chart.symm : F × c.free → E) y) ∧
    (∀ m y, y ∈ closedBall (c.chart x) r →
      ‖iteratedFDeriv ℝ m (c.chart.symm : F × c.free → E) y‖ ≤ B m) ∧
    (∀ m y, y ∈ closedBall (c.chart x) r →
      ‖iteratedFDeriv ℝ m (c.chart : E → F × c.free) (c.chart.symm y)‖ ≤ B m)

theorem SubmersionChartModel.Controls.to_controlled {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    {c : SubmersionChartModel E F} {f : E → F} {U : Set E}
    {x : E} {r : ℝ} {B : ℕ → ℝ} (h : c.Controls f U x r B) :
    ControlledSubmersionChart f U x r B := ⟨c.free, c.chart, h⟩

theorem SubmersionChartModel.Controls.mono {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    {c : SubmersionChartModel E F} {f : E → F} {U : Set E}
    {x : E} {r s : ℝ} {B C : ℕ → ℝ} (h : c.Controls f U x r B)
    (hs : s ≤ r) (hBC : ∀ m, B m ≤ C m) : c.Controls f U x s C := by
  obtain ⟨hd, hker, hx, hb, he, hf, ht, hU, hc, hB, hF⟩ := h
  have hsub := closedBall_subset_closedBall (x := c.chart x) hs
  exact ⟨hd, hker, hx, (ball_subset_ball hs).trans hb, he, hf,
    hsub.trans ht, fun y hy => hU (hsub hy), fun y hy => hc y (hsub hy),
    fun m y hy => (hB m y (hsub hy)).trans (hBC m),
    fun m y hy => (hF m y (hsub hy)).trans (hBC m)⟩

/-- One fixed chart model controls all sufficiently nearby base points after
halving its radius. Its entire sequence of derivative bounds is unchanged. -/
theorem SubmersionChartModel.Controls.nearby {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    {c : SubmersionChartModel E F} {f : E → F} {U : Set E}
    {z : E} {r : ℝ} {B : ℕ → ℝ} (h : c.Controls f U z r B) (hr : 0 < r) :
    ∀ᶠ x in nhds z, c.Controls f U x (r / 2) B := by
  obtain ⟨hd, hker, hz, hball, he, hf, ht, hU, hc, hB, hF⟩ := h
  have hnear := (c.chart.continuousAt hz).preimage_mem_nhds
    (ball_mem_nhds (c.chart z) (by positivity : 0 < r / 2))
  filter_upwards [ball_mem_nhds z (by positivity : 0 < r / 2), hnear] with x hx hxe
  have hxs := hball ((ball_subset_ball (by linarith : r / 2 ≤ r)) hx)
  have hbs : ball x (r / 2) ⊆ ball z r := by
    apply ball_subset_ball'
    have hx' : dist x z < r / 2 := hx
    linarith
  have hbt : closedBall (c.chart x) (r / 2) ⊆ closedBall (c.chart z) r := by
    apply closedBall_subset_closedBall'
    have hx' : dist (c.chart x) (c.chart z) < r / 2 := hxe
    linarith
  exact ⟨hd, hker, hxs, hbs.trans hball, he, hf, hbt.trans ht,
    fun y hy => hU (hbt hy), fun y hy => hc y (hbt hy),
    fun m y hy => hB m y (hbt hy), fun m y hy => hF m y (hbt hy)⟩

/-- Compactness produces an explicit finite atlas with common radii and
all-order derivative bounds. Chart identity is retained in the conclusion. -/
theorem compact_finite_controlled_atlas {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    {f : E → F} {U K : Set E} (hK : IsCompact K)
    (hcharts : ∀ z ∈ K, ∃ r : ℝ, 0 < r ∧ ∃ B : ℕ → ℝ,
      (∀ m, 0 ≤ B m) ∧ ControlledSubmersionChart f U z r B) :
    ∃ r : ℝ, 0 < r ∧ ∃ B : ℕ → ℝ, (∀ m, 0 ≤ B m) ∧
      ∃ A : Finset (SubmersionChartModel E F),
        ∀ x ∈ K, ∃ c ∈ A, c.Controls f U x r B := by
  classical
  let P : Set E → Prop := fun T => ∃ r : ℝ, 0 < r ∧ ∃ B : ℕ → ℝ,
    (∀ m, 0 ≤ B m) ∧ ∃ A : Finset (SubmersionChartModel E F),
      ∀ x ∈ T, ∃ c ∈ A, c.Controls f U x r B
  change P K
  refine IsCompact.induction_on hK (p := P) ?_ ?_ ?_ ?_
  · exact ⟨1, by norm_num, fun _ => 0, fun _ => le_rfl, ∅, by simp⟩
  · rintro s t hst ⟨r, hr, B, hB, A, ha⟩
    exact ⟨r, hr, B, hB, A, fun x hx => ha x (hst hx)⟩
  · rintro s t ⟨r, hr, B, hB, A, ha⟩ ⟨r', hr', B', hB', A', ha'⟩
    refine ⟨min r r', lt_min hr hr', fun m => max (B m) (B' m),
      fun m => (hB m).trans (le_max_left _ _), A ∪ A', fun x hx => ?_⟩
    rcases hx with hx | hx
    · obtain ⟨c, hc, hctrl⟩ := ha x hx
      exact ⟨c, Finset.mem_union_left _ hc,
        hctrl.mono (min_le_left _ _) (fun _ => le_max_left _ _)⟩
    · obtain ⟨c, hc, hctrl⟩ := ha' x hx
      exact ⟨c, Finset.mem_union_right _ hc,
        hctrl.mono (min_le_right _ _) (fun _ => le_max_right _ _)⟩
  · intro z hz
    obtain ⟨r, hr, B, hB, V, e, hctrl⟩ := hcharts z hz
    let c : SubmersionChartModel E F := ⟨V, e⟩
    have hc : c.Controls f U z r B := hctrl
    refine ⟨{x | c.Controls f U x (r / 2) B},
      mem_nhdsWithin_of_mem_nhds (hc.nearby hr), r / 2, by positivity,
      B, hB, {c}, fun x hx => ?_⟩
    exact ⟨c, Finset.mem_singleton_self _, hx⟩

private theorem norm_first_iterated_derivative {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] (f : E → F) (x : E) :
    ‖iteratedFDeriv ℝ 1 f x‖ = ‖fderiv ℝ f x‖ := by
  simpa only [iteratedFDerivWithin_univ, fderivWithin_univ] using
    (norm_iteratedFDerivWithin_one (𝕜 := ℝ) (s := Set.univ) (x := x) f uniqueDiffWithinAt_univ)

/-- Both sides of the inverse differential have common quantitative bounds.
This supplies a uniform lower bound against degenerating coordinate Jacobians. -/
theorem SubmersionChartModel.Controls.inverse_derivative_bounds {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    {c : SubmersionChartModel E F} {f : E → F} {U : Set E}
    {x : E} {r : ℝ} {B : ℕ → ℝ} (h : c.Controls f U x r B) (hUopen : IsOpen U)
    {y : F × c.free} (hy : y ∈ closedBall (c.chart x) r) (v : F × c.free) :
    ‖fderiv ℝ (c.chart.symm : F × c.free → E) y v‖ ≤ B 1 * ‖v‖ ∧
    ‖v‖ ≤ B 1 * ‖fderiv ℝ (c.chart.symm : F × c.free → E) y v‖ := by
  obtain ⟨_, _, _, _, _, hf, ht, hU, hs, hB, hF⟩ := h
  have hi := (hs y hy).differentiableAt (by simp)
  have hd := (hf.contDiffAt (hUopen.mem_nhds (hU hy))).differentiableAt (by simp)
  have hiB : ‖fderiv ℝ (c.chart.symm : F × c.free → E) y‖ ≤ B 1 := by
    simpa only [norm_first_iterated_derivative] using hB 1 y hy
  have hdB : ‖fderiv ℝ (c.chart : E → F × c.free) (c.chart.symm y)‖ ≤ B 1 := by
    simpa only [norm_first_iterated_derivative] using hF 1 y hy
  have hinv : (c.chart : E → F × c.free) ∘ c.chart.symm =ᶠ[nhds y] id := by
    filter_upwards [c.chart.open_target.mem_nhds (ht hy)] with z hz
    exact c.chart.right_inv hz
  have hcomp := hd.hasFDerivAt.comp y hi.hasFDerivAt
  have heq := hcomp.unique ((hasFDerivAt_id y).congr_of_eventuallyEq hinv)
  have heval := congrArg (fun L : (F × c.free) →L[ℝ] (F × c.free) => L v) heq
  simp only [ContinuousLinearMap.comp_apply, ContinuousLinearMap.id_apply] at heval
  refine ⟨((fderiv ℝ (c.chart.symm : F × c.free → E) y).le_opNorm v).trans
    (mul_le_mul_of_nonneg_right hiB (norm_nonneg _)), ?_⟩
  calc
    ‖v‖ = ‖fderiv ℝ (c.chart : E → F × c.free) (c.chart.symm y)
        (fderiv ℝ (c.chart.symm : F × c.free → E) y v)‖ := congrArg norm heval.symm
    _ ≤ _ := ((fderiv ℝ (c.chart : E → F × c.free) (c.chart.symm y)).le_opNorm _).trans
      (mul_le_mul_of_nonneg_right hdB (norm_nonneg _))

/-- Uniform Lipschitz control of the inverse on its entire closed coordinate ball. -/
theorem SubmersionChartModel.Controls.inverse_lipschitz_bound {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    {c : SubmersionChartModel E F} {f : E → F} {U : Set E}
    {x : E} {r : ℝ} {B : ℕ → ℝ} (h : c.Controls f U x r B)
    {y z : F × c.free} (hy : y ∈ closedBall (c.chart x) r)
    (hz : z ∈ closedBall (c.chart x) r) :
    dist (c.chart.symm y) (c.chart.symm z) ≤ B 1 * dist y z := by
  obtain ⟨_, _, _, _, _, _, _, _, hs, hB, _⟩ := h
  have hd : ∀ w ∈ closedBall (c.chart x) r,
      DifferentiableAt ℝ (c.chart.symm : F × c.free → E) w :=
    fun w hw => (hs w hw).differentiableAt (by simp)
  have hb : ∀ w ∈ closedBall (c.chart x) r,
      ‖fderiv ℝ (c.chart.symm : F × c.free → E) w‖ ≤ B 1 := by
    intro w hw
    simpa only [norm_first_iterated_derivative] using hB 1 w hw
  simpa only [dist_eq_norm] using
    (convex_closedBall (c.chart x) r).norm_image_sub_le_of_norm_fderiv_le hd hb hz hy

/-- The controlled charts themselves give a residual-to-distance estimate for
every nearby target level, with the same first-derivative constant. -/
theorem ControlledSubmersionChart.nearby_level {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    {f : E → F} {U : Set E} {x : E} {r : ℝ} {B : ℕ → ℝ}
    (h : ControlledSubmersionChart f U x r B) (hr : 0 ≤ r)
    {t : F} (ht : dist t (f x) ≤ r) :
    ∃ y ∈ U, f y = t ∧ dist x y ≤ B 1 * dist (f x) t := by
  obtain ⟨K, e, hd, hker, hx, hb, he, hf, htarget, hU, hs, hB, hF⟩ := h
  let c : SubmersionChartModel E F := ⟨K, e⟩
  have hc : c.Controls f U x r B := ⟨hd, hker, hx, hb, he, hf, htarget, hU, hs, hB, hF⟩
  let v : F × K := (t, (e x).2)
  have hv : v ∈ closedBall (e x) r := by
    simpa [v, Metric.mem_closedBall, Prod.dist_eq, he] using ht
  refine ⟨e.symm v, hU hv, ?_, ?_⟩
  · have hp := congrArg Prod.fst (e.right_inv (htarget hv))
    rw [he] at hp
    exact hp
  · have hdist := hc.inverse_lipschitz_bound (mem_closedBall_self hr) hv
    simpa [c, e.left_inv hx, v, Prod.dist_eq, he] using hdist

/-- A specified chart can be recentered with half its radius if both centers
and both coordinate centers are within a quarter of the old radius. -/
theorem SubmersionChartModel.Controls.recenter {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    {c : SubmersionChartModel E F} {f : E → F} {U : Set E}
    {x y : E} {r : ℝ} {B : ℕ → ℝ} (h : c.Controls f U x r B) (hr : 0 < r)
    (hxy : dist y x ≤ r / 4) (hcoord : dist (c.chart y) (c.chart x) ≤ r / 4) :
    c.Controls f U y (r / 2) B := by
  obtain ⟨hd, hker, _, hball, he, hf, ht, hU, hc, hB, hF⟩ := h
  have hy : y ∈ c.chart.source := hball (by change dist y x < r; linarith)
  have hbs : ball y (r / 2) ⊆ ball x r :=
    ball_subset_ball' (by linarith)
  have hbt : closedBall (c.chart y) (r / 2) ⊆ closedBall (c.chart x) r :=
    closedBall_subset_closedBall' (by linarith)
  exact ⟨hd, hker, hy, hbs.trans hball, he, hf, hbt.trans ht,
    fun z hz => hU (hbt hz), fun z hz => hc z (hbt hz),
    fun m z hz => hB m z (hbt hz), fun m z hz => hF m z (hbt hz)⟩

/-- A sufficiently small change of constraint level admits a correction that
retains controlled charts. The threshold depends only on the old common radius
and its first-derivative bound, so it is uniform throughout a compact atlas. -/
theorem ControlledSubmersionChart.correct_and_recenter {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    {f : E → F} {U : Set E} {x : E} {r : ℝ} {B : ℕ → ℝ}
    (h : ControlledSubmersionChart f U x r B) (hr : 0 < r) (hB1 : 0 ≤ B 1)
    {t : F} (ht : dist t (f x) < r / (4 * (B 1 + 1))) :
    ∃ y ∈ U, f y = t ∧ dist x y ≤ B 1 * dist (f x) t ∧
      ControlledSubmersionChart f U y (r / 2) B := by
  obtain ⟨K, e, hd, hker, hx, hb, he, hf, htarget, hU, hs, hB, hF⟩ := h
  let c : SubmersionChartModel E F := ⟨K, e⟩
  have hc : c.Controls f U x r B := ⟨hd, hker, hx, hb, he, hf, htarget, hU, hs, hB, hF⟩
  let δ := r / (4 * (B 1 + 1))
  have hδ : 0 < δ := by dsimp [δ]; positivity
  have hδr : δ ≤ r / 4 := by
    dsimp [δ]
    apply (div_le_iff₀ (by positivity : 0 < 4 * (B 1 + 1))).mpr
    nlinarith
  have hBδ : B 1 * δ ≤ r / 4 := by
    calc
      _ ≤ (B 1 + 1) * δ := mul_le_mul_of_nonneg_right (by linarith) hδ.le
      _ = r / 4 := by dsimp [δ]; field_simp
  have htδ : dist t (f x) < δ := ht
  let v : F × K := (t, (e x).2)
  have hv : v ∈ closedBall (e x) r := by
    have ht' : dist t (f x) ≤ r := by linarith
    simpa [v, Metric.mem_closedBall, Prod.dist_eq, he] using ht'
  let y := e.symm v
  have hey : e y = v := e.right_inv (htarget hv)
  have hfy : f y = t := by
    have hp := congrArg Prod.fst hey
    rw [he] at hp
    exact hp
  have hdist : dist x y ≤ B 1 * dist (f x) t := by
    have hlip := hc.inverse_lipschitz_bound (mem_closedBall_self hr.le) hv
    simpa [c, y, v, e.left_inv hx, Prod.dist_eq, he] using hlip
  have hdist' : dist y x ≤ r / 4 := by
    rw [dist_comm]
    apply hdist.trans
    apply le_trans _ hBδ
    apply mul_le_mul_of_nonneg_left _ hB1
    simpa only [dist_comm] using htδ.le
  have hcoord : dist (c.chart y) (c.chart x) ≤ r / 4 := by
    change dist (e y) (e x) ≤ r / 4
    rw [hey]
    have ht' : dist t (f x) ≤ r / 4 := htδ.le.trans hδr
    simpa [v, Prod.dist_eq, he] using ht'
  exact ⟨y, hU hv, hfy, hdist, (hc.recenter hr hdist' hcoord).to_controlled⟩

end N2Restriction
