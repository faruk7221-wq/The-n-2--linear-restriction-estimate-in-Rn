import N2Restriction.LocalHausdorff

namespace N2Restriction
open MeasureTheory

/-- The defining differential is onto, with an explicit preimage in the normal direction. -/
theorem SmoothPatch.differential_surjective {n : ℕ} (S : SmoothPatch n)
    {z : Ambient n} (hz : z ∈ S.neighborhood) :
    Function.Surjective (fderiv ℝ S.defining z) := by
  intro a
  refine ⟨(a / S.normalScale z) • S.normal z, ?_⟩
  rw [S.normal_differential z hz, inner_smul_right, real_inner_self_eq_norm_sq,
    S.normal_unit z hz]
  have h := (S.positive_normalScale z hz).ne'
  simp [h, mul_div_cancel₀]

/-- The compact support has finite codimension-one Hausdorff measure.
This proves the surface-mass hypothesis used by the analytic interfaces. -/
theorem SmoothPatch.finite_surface_mass {n : ℕ} (hn : 1 ≤ n) (S : SmoothPatch n) :
    Measure.hausdorffMeasure ((n : ℝ) - 1) S.support < ⊤ := by
  have h := compact_regular_level_finite S.compact_support S.support_on_surface
    (fun z hz => ⟨fderiv ℝ S.defining z,
      (S.smooth_defining.contDiffAt
        (S.open_neighborhood.mem_nhds (S.support_inside hz))).hasStrictFDerivAt (by simp),
      S.differential_surjective (S.support_inside hz)⟩)
  simpa only [Ambient, finrank_euclideanSpace, Fintype.card_fin,
    Module.finrank_self, Nat.cast_sub hn, Nat.cast_one] using h

/-- The measure specified in the target theorem is genuinely a finite measure. -/
theorem SmoothPatch.isFiniteMeasure_surfaceMeasure {n : ℕ} (hn : 1 ≤ n)
    (S : SmoothPatch n) : IsFiniteMeasure S.surfaceMeasure := by
  constructor
  simpa [SmoothPatch.surfaceMeasure] using S.finite_surface_mass hn

end N2Restriction
