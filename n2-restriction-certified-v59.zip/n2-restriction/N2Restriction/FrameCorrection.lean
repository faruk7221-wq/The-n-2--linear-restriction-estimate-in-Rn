import N2Restriction.ParameterCorrection

namespace N2Restriction
variable {n : ℕ} {F : Type*} [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]

/-- A normal constraint in fixed output coordinates, allowing its frame to vary. -/
noncomputable def frameConstraint (S : SmoothPatch n) (q : (Ambient n →L[ℝ] F) × Ambient n) : ℝ × F :=
  (S.defining q.2, q.1 (S.normal q.2))

noncomputable def frameDifferential (S : SmoothPatch n) (q : (Ambient n →L[ℝ] F) × Ambient n) :
    ((Ambient n →L[ℝ] F) × Ambient n) →L[ℝ] ℝ × F :=
  ((fderiv ℝ S.defining q.2).comp (ContinuousLinearMap.snd ℝ _ _)).prod
    (q.1.comp ((fderiv ℝ S.normal q.2).comp (ContinuousLinearMap.snd ℝ _ _)) +
      (ContinuousLinearMap.fst ℝ (Ambient n →L[ℝ] F) (Ambient n)).flip (S.normal q.2))

omit [FiniteDimensional ℝ F] in
/-- Joint differentiation in the frame and frequency variables. -/
theorem hasStrictFDerivAt_frameConstraint (S : SmoothPatch n)
    {q : (Ambient n →L[ℝ] F) × Ambient n} (hq : q.2 ∈ S.neighborhood) :
    HasStrictFDerivAt (frameConstraint S) (frameDifferential S q) q := by
  have hd := (S.smooth_defining.contDiffAt (S.open_neighborhood.mem_nhds hq)).hasStrictFDerivAt (by simp)
  have hn := (S.smooth_normal.contDiffAt (S.open_neighborhood.mem_nhds hq)).hasStrictFDerivAt (by simp)
  exact (hd.comp q hasStrictFDerivAt_snd).prodMk
    (hasStrictFDerivAt_fst.clm_apply (hn.comp q hasStrictFDerivAt_snd))

omit [FiniteDimensional ℝ F] in
/-- Curvature supplies vertical regularity for a frame with surjective shape compression. -/
theorem frameDifferential_vertical_surjective (S : SmoothPatch n)
    {q : (Ambient n →L[ℝ] F) × Ambient n} (hq : q.2 ∈ S.neighborhood)
    (W : Submodule ℝ (Ambient n))
    (hW : ∀ v : W, inner ℝ (S.normal q.2) (v : Ambient n) = 0)
    (hA : Function.Surjective (q.1.comp ((S.shape q.2).comp W.subtypeL))) :
    Function.Surjective (fun x : Ambient n => frameDifferential S q (0, x)) := by
  intro t
  let u : Ambient n := (t.1 / S.normalScale q.2) • S.normal q.2
  obtain ⟨v, hv⟩ := hA (q.1 (fderiv ℝ S.normal q.2 u) - t.2)
  change q.1 (S.shape q.2 v) = q.1 (fderiv ℝ S.normal q.2 u) - t.2 at hv
  have hn : q.1 (fderiv ℝ S.normal q.2 v) = -(q.1 (fderiv ℝ S.normal q.2 u) - t.2) := by
    change q.1 (-(fderiv ℝ S.normal q.2 v)) = _ at hv
    rw [map_neg] at hv
    exact neg_eq_iff_eq_neg.mp hv
  refine ⟨u + v, ?_⟩
  apply Prod.ext
  · change fderiv ℝ S.defining q.2 (u + v) = t.1
    rw [map_add, S.normal_differential q.2 hq (v : Ambient n), hW, mul_zero, add_zero,
      S.normal_differential q.2 hq u]
    dsimp [u]
    rw [inner_smul_right, real_inner_self_eq_norm_sq, S.normal_unit q.2 hq]
    field_simp [ne_of_gt (S.positive_normalScale q.2 hq)]
  · change q.1 (fderiv ℝ S.normal q.2 (u + v)) + (0 : Ambient n →L[ℝ] F) (S.normal q.2) = t.2
    rw [ContinuousLinearMap.zero_apply, add_zero, map_add, map_add, hn]
    abel

/-- Uniform distance correction for the actual normal constraints over a
compact family of frames and frequencies. The frame is preserved exactly. -/
theorem compact_frame_thin_correction (S : SmoothPatch n)
    {K : Set ((Ambient n →L[ℝ] F) × Ambient n)} (hK : IsCompact K)
    (hKS : ∀ q ∈ K, q.2 ∈ S.extendedSurface)
    (hreg : ∀ q ∈ K, q.1 (S.normal q.2) = 0 → ∃ W : Submodule ℝ (Ambient n),
      (∀ v : W, inner ℝ (S.normal q.2) (v : Ambient n) = 0) ∧
      Function.Surjective (q.1.comp ((S.shape q.2).comp W.subtypeL))) :
    ∃ δ C : ℝ, 0 < δ ∧ 0 ≤ C ∧ ∀ q ∈ K, ‖q.1 (S.normal q.2)‖ < δ →
      ∃ y ∈ S.extendedSurface, q.1 (S.normal y) = 0 ∧ dist q.2 y ≤ C * ‖q.1 (S.normal q.2)‖ := by
  let U : Set ((Ambient n →L[ℝ] F) × Ambient n) := Set.univ ×ˢ S.neighborhood
  have hU : IsOpen U := isOpen_univ.prod S.open_neighborhood
  have hKU : K ⊆ U := fun q hq => ⟨Set.mem_univ _, (hKS q hq).1⟩
  have hc : ContinuousOn (frameConstraint S) K := fun q hq =>
    (hasStrictFDerivAt_frameConstraint S (hKS q hq).1).continuousAt.continuousWithinAt
  have hb := compact_parameter_correction hK hU hKU hc ?_
  · obtain ⟨δ, C, hδ, hC, hb⟩ := hb
    refine ⟨δ, C, hδ, hC, fun q hq hsmall => ?_⟩
    have he : ‖frameConstraint S q‖ = ‖q.1 (S.normal q.2)‖ := by
      simp [frameConstraint, Prod.norm_def, (hKS q hq).2]
    obtain ⟨y, hy, hfy, hd⟩ := hb q hq (he.symm ▸ hsmall)
    have hf : S.defining y = 0 := congrArg Prod.fst hfy
    have hn : q.1 (S.normal y) = 0 := congrArg Prod.snd hfy
    exact ⟨y, ⟨hy.2, hf⟩, hn, he ▸ hd⟩
  · intro q hq hzero
    have hn : q.1 (S.normal q.2) = 0 := congrArg Prod.snd hzero
    obtain ⟨W, hW, hA⟩ := hreg q hq hn
    exact ⟨frameDifferential S q, hasStrictFDerivAt_frameConstraint S (hKS q hq).1,
      frameDifferential_vertical_surjective S (hKS q hq).1 W hW hA⟩

end N2Restriction
