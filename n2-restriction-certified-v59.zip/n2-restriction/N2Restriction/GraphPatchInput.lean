import N2Restriction.SurfaceGraphMargins
import N2Restriction.RestrictedInput
import N2Restriction.ExtensionRegularity

namespace N2Restriction
open MeasureTheory Set

/-- inputs measured only on a compact graph patch feed the full graph packets. -/
theorem SurfaceGraphChart.patch_packet_reconstruction_energy {d : ℕ} (G : SurfaceGraphChart d) {K : Set (Ambient d)} {r : ℝ}
    (P : CoordinateCapFamily K r) (hr : 0 < r)
    (hK : MeasurableSet (G.parametrization '' K))
    (g : Lp ℂ 2 (G.surfaceMeasure.restrict (G.parametrization '' K))) :
    let f := zeroExtendL2 G.surfaceMeasure (G.parametrization '' K) hK g
    HasSum (fun p : P.centers × (Fin d → ℤ) => G.packet P hr f p.1 p.2) f ∧
      (∑ j, ∑' ν, ‖G.packet P hr f j ν‖ ^ 2) ≤
        (G.density.upper / G.density.lower) *
          (packetCutoffEnergy d * (2 * Real.pi) ^ (-(d : ℝ))) * ‖g‖ ^ 2 := by
  dsimp only
  have hs : HasFrequencySupport G.surfaceMeasure id (G.parametrization '' K)
      (zeroExtendL2 G.surfaceMeasure (G.parametrization '' K) hK g) := by
    filter_upwards [zeroExtendL2_vanishes G.surfaceMeasure _ hK g] with x hx hn
    by_contra h
    exact hn (hx h)
  refine ⟨G.packet_hasSum P hr _ hs, ?_⟩
  simpa only [zeroExtendL2_norm] using
    G.packet_total_energy P hr (zeroExtendL2 G.surfaceMeasure (G.parametrization '' K) hK g)

/-- uniform packet reconstruction equals the extension of the original patch input. -/
theorem SurfaceGraphChart.patch_packet_uniform_extension {d : ℕ} (G : SurfaceGraphChart d) {K : Set (Ambient d)} {r : ℝ}
    (P : CoordinateCapFamily K r) (hr : 0 < r) (hK : IsCompact K)
    (himage : MeasurableSet (G.parametrization '' K))
    (g : Lp ℂ 2 (G.surfaceMeasure.restrict (G.parametrization '' K))) :
    let f := zeroExtendL2 G.surfaceMeasure (G.parametrization '' K) himage g
    ∀ ε : ℝ, 0 < ε → ∀ᶠ S : Finset (P.centers × (Fin d → ℤ)) in Filter.atTop,
      ∀ y : Ambient (d + 1), dist (∑ p ∈ S, extension G.surfaceMeasure id (G.packet P hr f p.1 p.2) y)
        (extension (G.surfaceMeasure.restrict (G.parametrization '' K)) id g y) < ε := by
  let f := zeroExtendL2 G.surfaceMeasure (G.parametrization '' K) himage g
  have hs : HasFrequencySupport G.surfaceMeasure id (G.parametrization '' K) f := by
    filter_upwards [zeroExtendL2_vanishes G.surfaceMeasure _ himage g] with x hx hn
    by_contra h
    exact hn (hx h)
  have he (y : Ambient (d + 1)) : extension G.surfaceMeasure id f y =
      extension (G.surfaceMeasure.restrict (G.parametrization '' K)) id g y := by
    unfold extension
    rw [← integral_indicator himage]
    apply integral_congr_ae
    filter_upwards [zeroExtendL2_coe G.surfaceMeasure _ himage g] with x hx
    change Complex.exp ((inner ℝ y x : ℂ) * Complex.I) * f x = _
    rw [show f x = (G.parametrization '' K).indicator g x from hx]
    by_cases h : x ∈ G.parametrization '' K
    · simp only [indicator_of_mem h, id_eq]
    · simp only [indicator_of_notMem h, mul_zero]
  simpa only [he] using G.packet_uniform_extension P hK hr f hs

namespace SurfaceGraphChart
variable {d : ℕ} (G : SurfaceGraphChart d)

/-- Extend a patch input by zero to the full graph, without changing its L2 norm. -/
noncomputable def patchInput {K : Set (Ambient d)}
    (hK : MeasurableSet (G.parametrization '' K)) :
    Lp ℂ 2 (G.surfaceMeasure.restrict (G.parametrization '' K)) →
      Lp ℂ 2 G.surfaceMeasure :=
  zeroExtendL2 G.surfaceMeasure (G.parametrization '' K) hK

theorem patchInput_support {K : Set (Ambient d)}
    (hK : MeasurableSet (G.parametrization '' K))
    (g : Lp ℂ 2 (G.surfaceMeasure.restrict (G.parametrization '' K))) :
    HasFrequencySupport G.surfaceMeasure id (G.parametrization '' K) (G.patchInput hK g) := by
  filter_upwards [zeroExtendL2_vanishes G.surfaceMeasure _ hK g] with x hx hn
  by_contra h
  exact hn (hx h)

theorem patchInput_extension {K : Set (Ambient d)}
    (hK : MeasurableSet (G.parametrization '' K))
    (g : Lp ℂ 2 (G.surfaceMeasure.restrict (G.parametrization '' K)))
    (y : Ambient (d + 1)) :
    extension G.surfaceMeasure id (G.patchInput hK g) y =
      extension (G.surfaceMeasure.restrict (G.parametrization '' K)) id g y := by
  unfold extension
  rw [← integral_indicator hK]
  apply integral_congr_ae
  filter_upwards [zeroExtendL2_coe G.surfaceMeasure _ hK g] with x hx
  change Complex.exp ((inner ℝ y x : ℂ) * Complex.I) * (G.patchInput hK g) x = _
  rw [show (G.patchInput hK g) x = (G.parametrization '' K).indicator g x from hx]
  by_cases h : x ∈ G.parametrization '' K
  · simp only [indicator_of_mem h, id_eq]
  · simp only [indicator_of_notMem h, mul_zero]

/-- Compact graph patches automatically give integrable original L2 inputs. -/
theorem patchInput_integrable {K : Set (Ambient d)} (hK : IsCompact K)
    (g : Lp ℂ 2 (G.surfaceMeasure.restrict (G.parametrization '' K))) :
    Integrable g (G.surfaceMeasure.restrict (G.parametrization '' K)) := by
  letI := G.finite_patch_measure hK
  exact (Lp.memLp g).integrable (by norm_num)

/-- Continuity here concerns the original Hausdorff-measured patch extension. -/
theorem continuous_patch_extension {K : Set (Ambient d)} (hK : IsCompact K)
    (g : Lp ℂ 2 (G.surfaceMeasure.restrict (G.parametrization '' K))) :
    Continuous (extension (G.surfaceMeasure.restrict (G.parametrization '' K)) id g) :=
  continuous_extension measurable_id (G.patchInput_integrable hK g)

/-- Every compact patch input has an unconditional scalar extension decomposition. -/
theorem patch_packet_extension_hasSum {K : Set (Ambient d)} {r : ℝ}
    (P : CoordinateCapFamily K r) (hr : 0 < r) (hK : IsCompact K)
    (himage : MeasurableSet (G.parametrization '' K))
    (g : Lp ℂ 2 (G.surfaceMeasure.restrict (G.parametrization '' K)))
    (y : Ambient (d + 1)) :
    HasSum (fun p : P.centers × (Fin d → ℤ) =>
      extension G.surfaceMeasure id (G.packet P hr (G.patchInput himage g) p.1 p.2) y)
      (extension (G.surfaceMeasure.restrict (G.parametrization '' K)) id g y) := by
  change Filter.Tendsto _ _ _
  rw [Metric.tendsto_nhds]
  intro ε hε
  exact (G.patch_packet_uniform_extension P hr hK himage g ε hε).mono fun S hS => hS y

end SurfaceGraphChart

end N2Restriction
