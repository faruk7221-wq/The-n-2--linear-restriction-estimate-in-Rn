import N2Restriction.FrameCorrection

namespace N2Restriction
variable {n : ℕ} {F : Type*} [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]

omit [FiniteDimensional ℝ F] in
/-- Passing to fixed frame coordinates preserves the nearby-plane surjectivity
already supplied by curvature. -/
theorem nearby_frame_shape_surjective (S : SmoothPatch n) (z : Ambient n)
    (W H : Submodule ℝ (Ambient n)) (hdim : Module.finrank ℝ W = Module.finrank ℝ H)
    (e : H ≃L[ℝ] F) {κ : ℝ} (hκ : 0 < κ)
    (hA : ∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (S.shape z v)‖)
    (hgap : ‖W.starProjection - H.starProjection‖ * ‖S.shape z‖ ≤ κ / 2) :
    Function.Surjective ((e.toContinuousLinearMap.comp H.orthogonalProjection).comp
      ((S.shape z).comp W.subtypeL)) := by
  obtain ⟨J, hJ, _, _⟩ := nearby_projected_shape_inverse W H hdim (S.shape z) hκ hA hgap
  intro t
  refine ⟨J (e.symm t), ?_⟩
  have hs : H.orthogonalProjection (S.shape z (J (e.symm t))) = e.symm t :=
    congrArg (fun L : H →L[ℝ] H => L (e.symm t)) hJ
  change e (H.orthogonalProjection (S.shape z (J (e.symm t)))) = t
  rw [hs, e.apply_symm_apply]

/-- Uniform thin-support correction for a compact frame-frequency family,
derived from the article's curvature and nearby-plane conditions. No distance
correction or uniform inverse constants are assumed. -/
theorem compact_frame_correction_of_curvature (S : SmoothPatch n)
    {K : Set ((Ambient n →L[ℝ] F) × Ambient n)} (hK : IsCompact K)
    (hKS : ∀ q ∈ K, q.2 ∈ S.extendedSurface) {κ : ℝ} (hκ : 0 < κ)
    (hfamily : ∀ q ∈ K, q.1 (S.normal q.2) = 0 →
      ∃ W H : Submodule ℝ (Ambient n), ∃ e : H ≃L[ℝ] F,
      q.1 = e.toContinuousLinearMap.comp H.orthogonalProjection ∧
      Module.finrank ℝ W = Module.finrank ℝ H ∧
      (∀ v : W, inner ℝ (S.normal q.2) (v : Ambient n) = 0) ∧
      (∀ v : W, κ * ‖v‖ ≤ ‖W.orthogonalProjection (S.shape q.2 v)‖) ∧
      ‖W.starProjection - H.starProjection‖ * ‖S.shape q.2‖ ≤ κ / 2) :
    ∃ δ C : ℝ, 0 < δ ∧ 0 ≤ C ∧ ∀ q ∈ K, ‖q.1 (S.normal q.2)‖ < δ →
      ∃ y ∈ S.extendedSurface, q.1 (S.normal y) = 0 ∧ dist q.2 y ≤ C * ‖q.1 (S.normal q.2)‖ := by
  apply compact_frame_thin_correction S hK hKS
  intro q hq hzero
  obtain ⟨W, H, e, he, hdim, hW, hA, hgap⟩ := hfamily q hq hzero
  refine ⟨W, hW, ?_⟩
  rw [he]
  exact nearby_frame_shape_surjective S q.2 W H hdim e hκ hA hgap

end N2Restriction
