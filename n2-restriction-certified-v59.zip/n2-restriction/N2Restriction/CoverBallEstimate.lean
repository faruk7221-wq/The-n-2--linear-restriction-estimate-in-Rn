import N2Restriction.FiniteCoverInputs

namespace N2Restriction
open MeasureTheory Set

theorem HasBallEnergyBound.mono {n : ℕ} {μ : Measure (Ambient n)} {C D : ℝ}
    (h : HasBallEnergyBound μ C) (hCD : C ≤ D) : HasBallEnergyBound μ D := by
  intro g x₀ R hR
  exact (h g x₀ R hR).trans (mul_le_mul_of_nonneg_right
    (mul_le_mul_of_nonneg_right hCD hR) (sq_nonneg _))

/-- A finite measurable chart cover transfers the chart estimates to a restricted surface. -/
theorem HasBallEnergyBound.of_finite_cover {n m : ℕ} (μ : Measure (Ambient n))
    (S : Set (Ambient n)) (hS : MeasurableSet S) [IsFiniteMeasure (μ.restrict S)]
    (K : Fin m → Set (Ambient n)) (hK : ∀ j, MeasurableSet (K j))
    (hcover : S ⊆ ⋃ j, K j) {C : ℝ} (hC : 0 ≤ C)
    (hb : ∀ j, HasBallEnergyBound (μ.restrict (K j)) C) :
    HasBallEnergyBound (μ.restrict S) ((m : ℝ) * C) := by
  intro g x₀ R hR
  have hlocal (j) : HasBallEnergyBound ((μ.restrict S).restrict (K j)) C := by
    have h := (hb j).restrict S hS
    simpa only [Measure.restrict_restrict (hK j), Measure.restrict_restrict hS,
      inter_comm] using h
  have hs : HasFrequencySupport (μ.restrict S) id (⋃ j, K j) g := by
    filter_upwards [ae_restrict_mem hS] with x hx _
    exact hcover hx
  exact ball_energy_of_finite_cover (μ.restrict S) K hK hC hlocal g hs x₀ hR

/-- Finitely many separately obtained chart constants give one common surface constant. -/
theorem exists_ball_bound_of_finite_cover {n m : ℕ} (μ : Measure (Ambient n))
    (S : Set (Ambient n)) (hS : MeasurableSet S) [IsFiniteMeasure (μ.restrict S)]
    (K : Fin m → Set (Ambient n)) (hK : ∀ j, MeasurableSet (K j))
    (hcover : S ⊆ ⋃ j, K j)
    (hb : ∀ j, ∃ C : ℝ, 0 ≤ C ∧ HasBallEnergyBound (μ.restrict (K j)) C) :
    ∃ C : ℝ, 0 ≤ C ∧ HasBallEnergyBound (μ.restrict S) C := by
  classical
  choose C hC hb using hb
  have hsum : 0 ≤ ∑ j, C j := Finset.sum_nonneg (fun j _ => hC j)
  refine ⟨(m : ℝ) * ∑ j, C j, mul_nonneg (Nat.cast_nonneg _) hsum, ?_⟩
  apply HasBallEnergyBound.of_finite_cover μ S hS K hK hcover hsum
  intro j
  exact (hb j).mono (Finset.single_le_sum (fun i _ => hC i) (Finset.mem_univ j))

end N2Restriction
