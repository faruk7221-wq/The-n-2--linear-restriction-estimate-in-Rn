import N2Restriction.HigherExponents

namespace N2Restriction
open MeasureTheory

section
variable {k : ℕ} {Ω : Fin k → Type*} [∀ i, MeasurableSpace (Ω i)]
variable {μ : ∀ i, Measure (Ω i)} [∀ i, IsFiniteMeasure (μ i)]
variable {ζ : ∀ i, Ω i → Ambient (k + 2)}

/-- A named statement of the remaining recurrence obligation, for the actual
best constants. It is a proposition definition, not an axiom or an asserted
estimate. Frequency margins and uniform geometric constants must be handled
when proving this proposition from the geometric hypotheses. -/
def RestrictionRecurrences (μ : ∀ i, Measure (Ω i))
    (ζ : ∀ i, Ω i → Ambient (k + 2)) (p : ℝ) : Prop :=
  ∀ ε : ℝ, 0 < ε → ∃ C D a τ : ℝ,
    0 < C ∧ 0 ≤ D ∧ a < ε * p ∧ 0 < τ ∧ τ < 1 / 2 ∧
    ∀ᶠ R : ℝ in Filter.atTop,
      localPowerConstant μ ζ p R ≤
        1 / 4 * localPowerConstant μ ζ p (R / 2) +
        C * localPowerConstant μ ζ p (R ^ (1 - τ)) +
        C * localPowerConstant μ ζ p (C * R ^ (1 / 2 + τ)) + D * R ^ a

/-- The complete local analytic conclusion, conditional on precisely the
strict-range recurrence obligation. This assembles the actual operator bounds,
radius induction, endpoint passage, and raising of exponents. It does not
establish `RestrictionRecurrences` from curvature. -/
theorem local_range_of_recurrences (hk : 3 ≤ k)
    (hζ : ∀ i, Measurable (ζ i))
    (hrec : ∀ p : ℝ, critical k < p → p < baseline k → RestrictionRecurrences μ ζ p) :
    ∀ p : ℝ, critical k ≤ p → LocalRestriction μ ζ p := by
  have hkR : (3 : ℝ) ≤ k := by exact_mod_cast hk
  have hcrit : 0 < critical k := critical_pos (by linarith)
  have hbase : critical k < baseline k := critical_lt_baseline (by linarith)
  have hend : LocalRestriction μ ζ (critical k) :=
    localRestriction_endpoint hζ (by omega : 0 < k + 2) hcrit hbase
      (fun p hp hpb => localRestriction_of_recurrences μ ζ (hcrit.trans hp) (hrec p hp hpb))
  intro p hp
  exact LocalRestriction.mono_exponent hζ hcrit hp hend

end
end N2Restriction
