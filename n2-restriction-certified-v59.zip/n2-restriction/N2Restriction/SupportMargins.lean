import N2Restriction.Scales
import N2Restriction.Translation

namespace N2Restriction
open MeasureTheory

/-- Points at least a distance a from the complement of a frequency domain.
The universal formulation also works when the complement is empty. -/
def marginRegion {E : Type*} [PseudoMetricSpace E] (U : Set E) (a : ℝ) : Set E :=
  {x | ∀ y, y ∉ U → a ≤ dist x y}

lemma marginRegion_antitone {E : Type*} [PseudoMetricSpace E] (U : Set E)
    {a b : ℝ} (hab : a ≤ b) : marginRegion U b ⊆ marginRegion U a :=
  fun _ hx y hy => hab.trans (hx y hy)

lemma marginRegion_subset {E : Type*} [PseudoMetricSpace E] (U : Set E)
    {a : ℝ} (ha : 0 < a) : marginRegion U a ⊆ U := by
  intro x hx
  by_contra h
  have := hx x h
  simp only [dist_self] at this
  linarith

lemma isClosed_marginRegion {E : Type*} [PseudoMetricSpace E] (U : Set E) (a : ℝ) :
    IsClosed (marginRegion U a) := by
  change IsClosed {x | ∀ y, ∀ (_ : y ∉ U), a ≤ dist x y}
  simp only [Set.setOf_forall]
  exact isClosed_iInter (fun y => isClosed_iInter (fun _ =>
    isClosed_le continuous_const (continuous_id.dist continuous_const)))

/-- Enlarging a frequency support by delta spends at most delta of its margin. -/
theorem marginRegion_enlargement {E : Type*} [PseudoMetricSpace E] (U : Set E)
    {a b δ : ℝ} (hab : b + δ ≤ a) {x z : E}
    (hz : z ∈ marginRegion U a) (hxz : dist x z ≤ δ) : x ∈ marginRegion U b := by
  intro y hy
  have hzy := hz y hy
  have ht := dist_triangle z x y
  rw [dist_comm z x] at ht
  linarith

/-- The actual support-margin transfer in (8.1), simultaneously at every child radius. -/
theorem eventually_marginRegion_children {E : Type*} [PseudoMetricSpace E]
    (U : Set E) (m C : ℝ) :
    ∀ᶠ R : ℝ in Filter.atTop, ∀ L : ℝ, 1 ≤ L → L ≤ R / 2 →
      ∀ x z : E, z ∈ marginRegion U (m - R ^ (-1 / 4 : ℝ)) →
        dist x z ≤ C * R ^ (-1 / 2 : ℝ) →
          x ∈ marginRegion U (m - L ^ (-1 / 4 : ℝ)) := by
  filter_upwards [eventually_support_margin C] with R hR
  intro L hL hLR x z hz hxz
  exact marginRegion_enlargement U (by linarith [hR L hL hLR]) hz hxz

/-- Essential frequency support: invariant under changes on null sets. -/
def HasFrequencySupport {Ω E : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (ζ : Ω → E) (K : Set E) (f : Ω → ℂ) : Prop :=
  ∀ᵐ ω ∂μ, f ω ≠ 0 → ζ ω ∈ K

theorem HasFrequencySupport.congr {Ω E : Type*} [MeasurableSpace Ω] {μ : Measure Ω}
    {ζ : Ω → E} {K : Set E} {f g : Ω → ℂ} (hf : HasFrequencySupport μ ζ K f)
    (hfg : f =ᵐ[μ] g) : HasFrequencySupport μ ζ K g := by
  filter_upwards [hf, hfg] with ω hω heq
  simpa only [← heq] using hω

theorem HasFrequencySupport.mono {Ω E : Type*} [MeasurableSpace Ω] {μ : Measure Ω}
    {ζ : Ω → E} {K L : Set E} {f : Ω → ℂ} (hf : HasFrequencySupport μ ζ K f)
    (hKL : K ⊆ L) : HasFrequencySupport μ ζ L f := by
  filter_upwards [hf] with ω hω hne
  exact hKL (hω hne)

theorem HasFrequencySupport.mul {Ω E : Type*} [MeasurableSpace Ω] {μ : Measure Ω}
    {ζ : Ω → E} {K : Set E} {f : Ω → ℂ} (hf : HasFrequencySupport μ ζ K f)
    (g : Ω → ℂ) : HasFrequencySupport μ ζ K (fun ω => g ω * f ω) := by
  filter_upwards [hf] with ω hω hne
  exact hω (fun hf0 => hne (by simp [hf0]))

theorem HasFrequencySupport.add {Ω E : Type*} [MeasurableSpace Ω] {μ : Measure Ω}
    {ζ : Ω → E} {K : Set E} {f g : Ω → ℂ}
    (hf : HasFrequencySupport μ ζ K f) (hg : HasFrequencySupport μ ζ K g) :
    HasFrequencySupport μ ζ K (f + g) := by
  filter_upwards [hf, hg] with ω hωf hωg hne
  by_cases h : f ω = 0
  · apply hωg
    intro hg0
    exact hne (by simp [h, hg0])
  · exact hωf h

/-- The radius-dependent admissibility class used in the article's best constant. -/
def MarginAdmissible {n k : ℕ} {Ω : Fin k → Type*} [∀ i, MeasurableSpace (Ω i)]
    (μ : ∀ i, Measure (Ω i)) (ζ : ∀ i, Ω i → Ambient n)
    (U : Fin k → Set (Ambient n)) (m R : ℝ) (f : ∀ i, Ω i → ℂ) : Prop :=
  ∀ i, HasFrequencySupport (μ i) (ζ i) (marginRegion (U i) (m - R ^ (-1 / 4 : ℝ))) (f i)

/-- Original supports with margin m are admissible at every positive radius. -/
theorem original_margin_admissible {n k : ℕ} {Ω : Fin k → Type*} [∀ i, MeasurableSpace (Ω i)]
    (μ : ∀ i, Measure (Ω i)) (ζ : ∀ i, Ω i → Ambient n)
    (U : Fin k → Set (Ambient n)) (m : ℝ) {R : ℝ} (hR : 0 ≤ R)
    {f : ∀ i, Ω i → ℂ}
    (hf : ∀ i, HasFrequencySupport (μ i) (ζ i) (marginRegion (U i) m) (f i)) :
    MarginAdmissible μ ζ U m R f := by
  intro i
  exact (hf i).mono (marginRegion_antitone _ (by linarith [Real.rpow_nonneg hR (-1 / 4 : ℝ)]))

/-- Multiplication by a phase or by a selection cutoff preserves admissibility. -/
theorem MarginAdmissible.mul {n k : ℕ} {Ω : Fin k → Type*} [∀ i, MeasurableSpace (Ω i)]
    {μ : ∀ i, Measure (Ω i)} {ζ : ∀ i, Ω i → Ambient n}
    {U : Fin k → Set (Ambient n)} {m R : ℝ} {f : ∀ i, Ω i → ℂ}
    (hf : MarginAdmissible μ ζ U m R f) (g : ∀ i, Ω i → ℂ) :
    MarginAdmissible μ ζ U m R (fun i ω => g i ω * f i ω) :=
  fun i => (hf i).mul (g i)

end N2Restriction
