import N2Restriction.CutoffOperator

namespace N2Restriction
open MeasureTheory UnitAddTorus
noncomputable local instance : MeasureSpace UnitAddCircle := ⟨AddCircle.haarAddCircle⟩
variable {d : Type*} [Fintype d]
local notation "TorusL2" => Lp ℂ 2 (volume : Measure (UnitAddTorus d))
variable (χ : UnitAddTorus d → ℂ) (hχ : AEStronglyMeasurable χ volume)
  {C : ℝ} (hC : ∀ᵐ x ∂volume, ‖χ x‖ ≤ C)

/-- A unit Fourier monomial has pointwise absolute value one. -/
lemma norm_mFourier_apply (i : d → ℤ) (x : UnitAddTorus d) : ‖mFourier i x‖ = 1 := by
  simp only [mFourier, ContinuousMap.coe_mk, norm_prod, fourier_apply,
    Circle.norm_coe, Finset.prod_const_one]

/-- Every cutoff Fourier atom has exactly the same unweighted L2 norm. -/
theorem cutoff_fourier_atom_norm (i : d → ℤ) :
    ‖cutoffOperator χ hχ hC (mFourierLp 2 i)‖ = (eLpNorm χ 2 volume).toReal := by
  rw [Lp.norm_def]
  congr 1
  apply eLpNorm_congr_norm_ae
  filter_upwards [cutoffL2_coe χ hχ hC (mFourierLp 2 i), coeFn_mFourierLp 2 i] with x hx hi
  change ‖cutoffL2 χ hχ hC (mFourierLp 2 i) x‖ = ‖χ x‖
  rw [hx, norm_mul, hi, norm_mFourier_apply, mul_one]

/-- Exact coefficient-to-packet energy conversion for the concrete cutoff atoms. -/
theorem cutoff_fourier_packet_norm (f : TorusL2) (i : d → ℤ) :
    ‖cutoffOperator χ hχ hC (mFourierCoeff f i • mFourierLp 2 i)‖ =
      ‖mFourierCoeff f i‖ * (eLpNorm χ 2 volume).toReal := by
  rw [map_smul, norm_smul, cutoff_fourier_atom_norm]

/-- The cutoff expansion reconstructs f whenever the cutoff equals one on its support. -/
theorem cutoff_fourier_reconstruction (f : TorusL2)
    (hf : ∀ᵐ x ∂volume, f x ≠ 0 → χ x = 1) :
    HasSum (fun i => cutoffOperator χ hχ hC (mFourierCoeff f i • mFourierLp 2 i)) f := by
  simpa only [cutoffOperator_eq_self χ hχ hC f hf] using
    fourier_packet_reconstruction (cutoffOperator χ hχ hC) f

/-- Exact energy of every subcollection of cutoff packets. -/
theorem cutoff_fourier_selected_energy (f : TorusL2) (S : Set (d → ℤ)) :
    (∑' i : S, ‖cutoffOperator χ hχ hC (mFourierCoeff f i • mFourierLp 2 i)‖ ^ 2) =
      (eLpNorm χ 2 volume).toReal ^ 2 * ∑' i : S, ‖mFourierCoeff f i‖ ^ 2 := by
  simp_rw [cutoff_fourier_packet_norm, mul_pow]
  rw [tsum_mul_right, mul_comm]

/-- Almost orthogonality stated using the actual norms of the cutoff packets.
For nonzero cutoff energy this yields the usual ratio C^2 / ||chi||_2^2. -/
theorem cutoff_fourier_almost_orthogonal (hC0 : 0 ≤ C) (f : TorusL2) (S : Set (d → ℤ)) :
    (eLpNorm χ 2 volume).toReal ^ 2 *
      ‖∑' i : S, cutoffOperator χ hχ hC (mFourierCoeff f i • mFourierLp 2 i)‖ ^ 2 ≤
    C ^ 2 * ∑' i : S, ‖cutoffOperator χ hχ hC (mFourierCoeff f i • mFourierLp 2 i)‖ ^ 2 := by
  have h := fourier_packet_selection (cutoffOperator χ hχ hC) f S
  have hn : ‖cutoffOperator χ hχ hC‖ ^ 2 ≤ C ^ 2 :=
    pow_le_pow_left₀ (norm_nonneg _) (cutoffOperator_norm_le χ hχ hC0 hC) 2
  have he : 0 ≤ ∑' i : S, ‖mFourierCoeff f i‖ ^ 2 := tsum_nonneg (fun _ => sq_nonneg _)
  have hb := h.trans (mul_le_mul_of_nonneg_right hn he)
  rw [cutoff_fourier_selected_energy]
  nlinarith [mul_le_mul_of_nonneg_left hb (sq_nonneg (eLpNorm χ 2 volume).toReal)]

/-- Parseval gives the total energy of the actual cutoff packet family. -/
theorem cutoff_fourier_total_energy (f : TorusL2) :
    (∑' i, ‖cutoffOperator χ hχ hC (mFourierCoeff f i • mFourierLp 2 i)‖ ^ 2) =
      (eLpNorm χ 2 volume).toReal ^ 2 * ‖f‖ ^ 2 := by
  have he := (hilbert_coefficient_energy mFourierBasis f).tsum_eq
  simp only [mFourierBasis_repr] at he
  simp_rw [cutoff_fourier_packet_norm, mul_pow]
  rw [tsum_mul_right, he, mul_comm]

end N2Restriction
