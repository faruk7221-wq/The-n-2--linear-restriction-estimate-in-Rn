import N2Restriction.CutoffOperator

namespace N2Restriction
set_option maxHeartbeats 800000
open MeasureTheory
open scoped BigOperators
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω}

theorem l2_integrable_norm_sq (f : Lp ℂ 2 μ) : Integrable (fun ω => ‖f ω‖ ^ 2) μ :=
  (memLp_two_iff_integrable_sq_norm (Lp.aestronglyMeasurable f)).mp (Lp.memLp f)

/-- The real energy integral for the concrete L2 norm. -/
theorem l2_norm_sq_eq_integral (f : Lp ℂ 2 μ) : ‖f‖ ^ 2 = ∫ ω, ‖f ω‖ ^ 2 ∂μ := by
  rw [norm_sq_eq_re_inner (𝕜 := ℂ), L2.inner_def, ← integral_re (L2.integrable_inner f f)]
  simp only [inner_self_eq_norm_sq_to_K, ← RCLike.ofReal_pow, RCLike.ofReal_re]

/-- Bounded overlap of the actual cutoff functions gives the frequency-cap
energy budget. This requires no orthogonality between the cutoffs. -/
theorem cutoff_cap_energy {ι : Type*} [Fintype ι]
    (χ : ι → Ω → ℂ) (hχ : ∀ j, AEStronglyMeasurable (χ j) μ)
    {C : ℝ} (hC : ∀ j, ∀ᵐ ω ∂μ, ‖χ j ω‖ ≤ C)
    {M : ℝ} (hM : ∀ᵐ ω ∂μ, (∑ j, ‖χ j ω‖ ^ 2) ≤ M) (f : Lp ℂ 2 μ) :
    (∑ j, ‖cutoffOperator (χ j) (hχ j) (hC j) f‖ ^ 2) ≤ M * ‖f‖ ^ 2 := by
  simp_rw [l2_norm_sq_eq_integral]
  rw [← integral_finset_sum _ (fun j _ => l2_integrable_norm_sq _)]
  calc
    _ ≤ ∫ ω, M * ‖f ω‖ ^ 2 ∂μ := by
      apply integral_mono_ae
      · exact integrable_finset_sum _ (fun _ _ => l2_integrable_norm_sq _)
      · exact (l2_integrable_norm_sq f).const_mul M
      · filter_upwards [ae_all_iff.mpr (fun j => cutoffL2_coe (χ j) (hχ j) (hC j) f), hM]
          with ω hω hMω
        change (∑ j, ‖cutoffL2 (χ j) (hχ j) (hC j) f ω‖ ^ 2) ≤ _
        simp_rw [hω, norm_mul, mul_pow]
        rw [← Finset.sum_mul]
        exact mul_le_mul_of_nonneg_right hMω (sq_nonneg _)
    _ = _ := integral_const_mul _ _

/-- Indicator cutoffs give a concrete instance from a cap multiplicity bound. -/
theorem indicator_cap_energy {ι : Type*} [Fintype ι]
    (K : ι → Set Ω) (hK : ∀ j, MeasurableSet (K j))
    {M : ℝ} (hM : ∀ᵐ ω ∂μ, (∑ j, (K j).indicator (fun _ : Ω => (1 : ℝ)) ω) ≤ M)
    (f : Lp ℂ 2 μ) :
    (∑ j, ‖((Lp.memLp f).indicator (hK j)).toLp ((K j).indicator f)‖ ^ 2) ≤ M * ‖f‖ ^ 2 := by
  classical
  let χ : ι → Ω → ℂ := fun j => (K j).indicator (fun _ => 1)
  have hχ (j) : AEStronglyMeasurable (χ j) μ := aestronglyMeasurable_const.indicator (hK j)
  have hC (j) : ∀ᵐ ω ∂μ, ‖χ j ω‖ ≤ 1 := Filter.Eventually.of_forall (fun ω => by
    by_cases h : ω ∈ K j <;> simp [χ, h])
  have he (j) : cutoffOperator (χ j) (hχ j) (hC j) f =
      ((Lp.memLp f).indicator (hK j)).toLp ((K j).indicator f) := by
    change (cutoff_memLp (χ j) (hχ j) (hC j) f).toLp (fun ω => χ j ω * f ω) = _
    apply MemLp.toLp_congr
    apply Filter.Eventually.of_forall
    intro ω
    by_cases h : ω ∈ K j <;> simp [χ, h]
  have hb := cutoff_cap_energy χ hχ hC (M := M) (f := f) ?_
  · simpa only [he] using hb
  · filter_upwards [hM] with ω hω
    have hvalue (j : ι) : ‖χ j ω‖ ^ 2 = (K j).indicator (fun _ : Ω => (1 : ℝ)) ω := by
      by_cases h : ω ∈ K j <;> simp [χ, h]
    simpa only [hvalue] using hω

end N2Restriction
