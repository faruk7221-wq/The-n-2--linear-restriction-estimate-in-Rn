import N2Restriction.MarginLocalConstant
import N2Restriction.LocalAssembly
import N2Restriction.SurfaceMeasure
import Mathlib.MeasureTheory.Integral.Bochner.Set

namespace N2Restriction
open MeasureTheory
open scoped ENNReal NNReal

/-- Extension on a restricted patch is extension of the zero-extended datum. -/
theorem extension_restrict_eq_indicator {n : ℕ} {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) (ζ : Ω → Ambient n) (K : Set Ω) (hK : MeasurableSet K)
    (f : Ω → ℂ) (x : Ambient n) :
    extension (μ.restrict K) ζ f x = extension μ ζ (K.indicator f) x := by
  classical
  unfold extension
  rw [← integral_indicator hK]
  apply integral_congr_ae
  exact Filter.Eventually.of_forall (fun ω => by
    by_cases h : ω ∈ K <;> simp [Set.indicator_of_mem, Set.indicator_of_notMem, h])

section
variable {n k : ℕ} {Ω : Fin k → Type*} [∀ i, MeasurableSpace (Ω i)]
variable (μ : ∀ i, Measure (Ω i)) [∀ i, IsFiniteMeasure (μ i)]
variable (ζ : ∀ i, Ω i → Ambient n) (U : Fin k → Set (Ambient n)) (m : ℝ)

/-- Transfer the margin recurrence on larger patches to the original patches.
Zero extension preserves the L2 norms and the actual extension integrals. -/
theorem localRestriction_restrict_of_margin_recurrences
    (K : ∀ i, Set (Ω i)) (hK : ∀ i, MeasurableSet (K i))
    (hmargin : ∀ i, ∀ ω ∈ K i, ζ i ω ∈ marginRegion (U i) m)
    {p : ℝ} (hp : 0 < p) (hrec : MarginRecurrences μ ζ U m p) :
    LocalRestriction (fun i => (μ i).restrict (K i)) ζ p := by
  classical
  intro ε hε
  obtain ⟨C, hC⟩ := original_margin_estimate_of_recurrences μ ζ U m hp hrec ε hε
  refine ⟨C, fun R hR x f hf => ?_⟩
  let g : ∀ i, Ω i → ℂ := fun i => (K i).indicator (f i)
  have hg : ∀ i, MemLp (g i) 2 (μ i) := fun i =>
    (memLp_indicator_iff_restrict (hK i)).mpr (hf i)
  have hgm : ∀ i, HasFrequencySupport (μ i) (ζ i) (marginRegion (U i) m) (g i) := by
    intro i
    apply Filter.Eventually.of_forall
    intro ω hne
    apply hmargin i ω
    by_contra hω
    exact hne (Set.indicator_of_notMem hω _)
  have he : extensionProduct μ ζ g = extensionProduct (fun i => (μ i).restrict (K i)) ζ f := by
    funext y
    unfold extensionProduct
    apply Finset.prod_congr rfl
    intro i _
    exact (extension_restrict_eq_indicator (μ i) (ζ i) (K i) (hK i) (f i) y).symm
  have hn : inputNormProduct μ g = inputNormProduct (fun i => (μ i).restrict (K i)) f := by
    unfold inputNormProduct
    apply Finset.prod_congr rfl
    intro i _
    exact eLpNorm_indicator_eq_eLpNorm_restrict (hK i)
  simpa only [he, hn] using hC R hR x g hg hgm

end

/-- Endpoint passage and raising exponents on the original restricted patches,
from strict-range recurrences for the enlarged admissible patches. -/
theorem local_range_restrict_of_margin_recurrences {k : ℕ} (hk : 3 ≤ k)
    {Ω : Fin k → Type*} [∀ i, MeasurableSpace (Ω i)]
    (μ : ∀ i, Measure (Ω i)) [∀ i, IsFiniteMeasure (μ i)]
    (ζ : ∀ i, Ω i → Ambient (k + 2)) (hζ : ∀ i, Measurable (ζ i))
    (U : Fin k → Set (Ambient (k + 2))) (m : ℝ)
    (K : ∀ i, Set (Ω i)) (hK : ∀ i, MeasurableSet (K i))
    (hmargin : ∀ i, ∀ ω ∈ K i, ζ i ω ∈ marginRegion (U i) m)
    (hrec : ∀ p : ℝ, critical k < p → p < baseline k → MarginRecurrences μ ζ U m p) :
    ∀ p : ℝ, critical k ≤ p →
      LocalRestriction (fun i => (μ i).restrict (K i)) ζ p := by
  have hkR : (0 : ℝ) < k := by exact_mod_cast (by omega : 0 < k)
  have hcrit := critical_pos hkR
  have hbase := critical_lt_baseline (show (1 : ℝ) < k by exact_mod_cast (by omega : 1 < k))
  have hend : LocalRestriction (fun i => (μ i).restrict (K i)) ζ (critical k) :=
    localRestriction_endpoint hζ (by omega : 0 < k + 2) hcrit hbase
      (fun p hp hpb => localRestriction_restrict_of_margin_recurrences μ ζ U m K hK hmargin
        (hcrit.trans hp) (hrec p hp hpb))
  exact fun p hp => LocalRestriction.mono_exponent hζ hcrit hp hend

/-- Restricting a larger Hausdorff patch to an original compact support
recovers exactly the original surface measure. -/
theorem SmoothPatch.surfaceMeasure_restrict {n : ℕ} (S T : SmoothPatch n)
    (hST : S.support ⊆ T.support) : T.surfaceMeasure.restrict S.support = S.surfaceMeasure := by
  unfold SmoothPatch.surfaceMeasure
  rw [Measure.restrict_restrict S.compact_support.measurableSet, Set.inter_eq_left.mpr hST]

/-- The margin recurrence interface now reaches the actual original Hausdorff
surface measures, with all endpoint and bounded-radius steps proved. -/
theorem surface_local_range_of_margin_recurrences {k : ℕ} (hk : 3 ≤ k)
    (S T : Fin k → SmoothPatch (k + 2))
    (hST : ∀ i, (S i).support ⊆ (T i).support)
    (U : Fin k → Set (Ambient (k + 2))) (m : ℝ)
    (hmargin : ∀ i, (S i).support ⊆ marginRegion (U i) m)
    (hrec : ∀ p : ℝ, critical k < p → p < baseline k →
      MarginRecurrences (fun i => (T i).surfaceMeasure) (fun _ => id) U m p) :
    ∀ p : ℝ, critical k ≤ p →
      LocalRestriction (fun i => (S i).surfaceMeasure) (fun _ => id) p := by
  letI (i : Fin k) := (T i).isFiniteMeasure_surfaceMeasure (by omega : 1 ≤ k + 2)
  have h := local_range_restrict_of_margin_recurrences hk
    (fun i => (T i).surfaceMeasure) (fun _ => id) (fun _ => measurable_id) U m
    (fun i => (S i).support) (fun i => (S i).compact_support.measurableSet) hmargin hrec
  simpa only [SmoothPatch.surfaceMeasure_restrict _ _ (hST _)] using h

end N2Restriction
