import N2Restriction.GraphBallPlancherel
import N2Restriction.OrthogonalExtension

namespace N2Restriction
open MeasureTheory Set

/-- Orthogonal change of frequency coordinates on the original L2 input. -/
noncomputable def rotatedInput {n : ℕ} (A : Ambient n ≃ₗᵢ[ℝ] Ambient n)
    (μ : Measure (Ambient n)) : Lp ℂ 2 μ →ₗᵢ[ℂ] Lp ℂ 2 (μ.map A) :=
  imageInput μ A A.symm A.continuous.measurable A.symm.continuous.measurable
    A.symm_apply_apply

theorem rotatedInput_norm {n : ℕ} (A : Ambient n ≃ₗᵢ[ℝ] Ambient n)
    (μ : Measure (Ambient n)) (f : Lp ℂ 2 μ) : ‖rotatedInput A μ f‖ = ‖f‖ :=
  (rotatedInput A μ).norm_map f

/-- Every input on the rotated measure comes from an input of exactly the same norm. -/
theorem rotatedInput_surjective {n : ℕ} (A : Ambient n ≃ₗᵢ[ℝ] Ambient n)
    (μ : Measure (Ambient n)) : Function.Surjective (rotatedInput A μ) := by
  intro g
  refine ⟨Lp.compMeasurePreserving A ⟨A.continuous.measurable, rfl⟩ g, ?_⟩
  exact imageInput_pullback μ A A.symm A.toHomeomorph.measurableEmbedding
    A.symm.continuous.measurable A.symm_apply_apply g

theorem rotatedInput_extension {n : ℕ} (A : Ambient n ≃ₗᵢ[ℝ] Ambient n)
    (μ : Measure (Ambient n)) (f : Lp ℂ 2 μ) (x : Ambient n) :
    extension (μ.map A) id (rotatedInput A μ f) (A x) = extension μ id f x := by
  rw [show extension (μ.map A) id (rotatedInput A μ f) (A x) =
      extension μ A f (A x) from
    imageInput_extension μ A A.symm A.toHomeomorph.measurableEmbedding
      A.symm.continuous.measurable A.symm_apply_apply f (A x)]
  exact orthogonal_extension_covariance A μ id f x

theorem rotatedInput_ball_energy {n : ℕ} (A : Ambient n ≃ₗᵢ[ℝ] Ambient n)
    (μ : Measure (Ambient n)) (f : Lp ℂ 2 μ) (x₀ : Ambient n) (R : ℝ) :
    (∫ y in Metric.ball (A x₀) R, ‖extension (μ.map A) id (rotatedInput A μ f) y‖ ^ 2) =
      ∫ x in Metric.ball x₀ R, ‖extension μ id f x‖ ^ 2 := by
  have he (y : Ambient n) : extension (μ.map A) id (rotatedInput A μ f) y =
      extension μ A f y :=
    imageInput_extension μ A A.symm A.toHomeomorph.measurableEmbedding
      A.symm.continuous.measurable A.symm_apply_apply f y
  simp_rw [he]
  exact orthogonal_extension_ball_energy A μ id f x₀ R

/-- A local ball estimate transfers to all inputs on an orthogonal image, with no loss. -/
theorem ball_estimate_orthogonal_image {n : ℕ} (A : Ambient n ≃ₗᵢ[ℝ] Ambient n)
    (μ : Measure (Ambient n)) (C : ℝ)
    (h : ∀ (f : Lp ℂ 2 μ) (x₀ : Ambient n) (R : ℝ), 0 ≤ R →
      (∫ y in Metric.ball x₀ R, ‖extension μ id f y‖ ^ 2) ≤ C * R * ‖f‖ ^ 2) :
    ∀ (g : Lp ℂ 2 (μ.map A)) (x₀ : Ambient n) (R : ℝ), 0 ≤ R →
      (∫ y in Metric.ball x₀ R, ‖extension (μ.map A) id g y‖ ^ 2) ≤ C * R * ‖g‖ ^ 2 := by
  intro g x₀ R hR
  obtain ⟨f, rfl⟩ := rotatedInput_surjective A μ g
  rw [rotatedInput_norm, ← A.apply_symm_apply x₀, rotatedInput_ball_energy]
  exact h f (A.symm x₀) R hR

/-- Orthogonal images of genuine local graph patches satisfy Lemma 3.1's L2 ball bound. -/
theorem rotated_local_graph_patch_ball_estimate {d : ℕ}
    (A : Ambient (d + 1) ≃ₗᵢ[ℝ] Ambient (d + 1))
    {U : Set (Ambient d)} (hU : IsOpen U)
    {φ : Ambient d → ℝ} (hφ : ContDiffOn ℝ (⊤ : ℕ∞) φ U)
    (z : Ambient d) {a b : ℝ} (ha : 0 < a) (hab : a < b)
    (hball : Metric.closedBall z b ⊆ U) {K : Set (Ambient d)} (hK : IsCompact K)
    (hsub : K ⊆ Metric.closedBall z a) :
    ∃ C : ℝ, 0 ≤ C ∧
      ∀ (g : Lp ℂ 2 ((Measure.hausdorffMeasure (d : ℝ)).restrict
        (A '' ((fun x => graphPoint x (φ x)) '' K)))) (x₀ : Ambient (d + 1)) (R : ℝ), 0 ≤ R →
      (∫ y in Metric.ball x₀ R,
        ‖extension ((Measure.hausdorffMeasure (d : ℝ)).restrict
          (A '' ((fun x => graphPoint x (φ x)) '' K))) id g y‖ ^ 2) ≤ C * R * ‖g‖ ^ 2 := by
  obtain ⟨C, hC, h⟩ := local_graph_patch_ball_estimate hU hφ z ha hab hball hK hsub
  refine ⟨C, hC, ?_⟩
  rw [← orthogonal_surface_measure A (d : ℝ)]
  exact ball_estimate_orthogonal_image A _ C h

end N2Restriction
