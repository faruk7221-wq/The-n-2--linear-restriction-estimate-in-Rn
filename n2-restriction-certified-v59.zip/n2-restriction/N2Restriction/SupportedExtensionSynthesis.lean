import N2Restriction.FinitePacketIndexing

namespace N2Restriction
open MeasureTheory Set

/-- Restricting ordinary L2 data is contractive. -/
theorem restrictInputL2_norm_le {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (s : Set Ω) (f : Lp ℂ 2 μ) : ‖restrictInputL2 μ s f‖ ≤ ‖f‖ := by
  rw [Lp.norm_def, eLpNorm_congr_ae (restrictInputL2_coe μ s f), Lp.norm_def]
  exact ENNReal.toReal_mono (Lp.memLp f).eLpNorm_ne_top (eLpNorm_mono_measure _ Measure.restrict_le_self)

/-- The restriction map is a bounded linear operator. -/
noncomputable def restrictInputOperator {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (s : Set Ω) : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 (μ.restrict s) :=
  LinearMap.mkContinuous
    { toFun := restrictInputL2 μ s
      map_add' := by
        intro f g
        apply Lp.ext
        filter_upwards [restrictInputL2_coe μ s (f + g), restrictInputL2_coe μ s f,
          restrictInputL2_coe μ s g, (Lp.coeFn_add f g).filter_mono (ae_mono Measure.restrict_le_self),
          Lp.coeFn_add (restrictInputL2 μ s f) (restrictInputL2 μ s g)] with x h1 h2 h3 h4 h5
        simp only [h1, h2, h3, h4, h5, Pi.add_apply]
      map_smul' := by
        intro z f
        apply Lp.ext
        filter_upwards [restrictInputL2_coe μ s (z • f), restrictInputL2_coe μ s f,
          (Lp.coeFn_smul z f).filter_mono (ae_mono Measure.restrict_le_self),
          Lp.coeFn_smul z (restrictInputL2 μ s f)] with x h1 h2 h3 h4
        simp only [RingHom.id_apply, h1, h2, h3, h4, Pi.smul_apply] }
    1 (fun f => by simpa only [one_mul] using restrictInputL2_norm_le μ s f)

theorem restrictInputOperator_apply {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (s : Set Ω) (f : Lp ℂ 2 μ) : restrictInputOperator μ s f = restrictInputL2 μ s f := rfl

/-- Extension of a supported input can be evaluated on its finite frequency domain. -/
theorem extension_restrictInput {Ω : Type*} [MeasurableSpace Ω] {n : ℕ}
    (μ : Measure Ω) (s : Set Ω) (hs : MeasurableSet s) (f : Lp ℂ 2 μ)
    (hf : HasFrequencySupport μ id s f) (ζ : Ω → Ambient n) (x : Ambient n) :
    extension (μ.restrict s) ζ (restrictInputL2 μ s f) x = extension μ ζ f x := by
  unfold extension
  rw [← integral_indicator hs]
  apply integral_congr_ae
  have he := (ae_restrict_iff' hs).mp (restrictInputL2_coe μ s f)
  filter_upwards [he, hf] with y hy hfy
  by_cases hys : y ∈ s
  · simp only [indicator_of_mem hys, hy hys]
  · have hz : f y = 0 := by
      by_contra hn
      exact hys (hfy hn)
    simp only [indicator_of_notMem hys, hz, mul_zero]

/-- Unconditional reconstruction passes to actual extensions when every input
has common finite-measure frequency support, even if the ambient measure is infinite. -/
theorem supported_extension_hasSum {Ω ι : Type*} [MeasurableSpace Ω] {n : ℕ}
    (μ : Measure Ω) (s : Set Ω) (hs : MeasurableSet s) [IsFiniteMeasure (μ.restrict s)]
    (ζ : Ω → Ambient n) (hζ : Measurable ζ) (f : ι → Lp ℂ 2 μ) (g : Lp ℂ 2 μ)
    (hf : ∀ j, HasFrequencySupport μ id s (f j)) (hg : HasFrequencySupport μ id s g)
    (hsum : HasSum f g) (x : Ambient n) :
    HasSum (fun j => extension μ ζ (f j) x) (extension μ ζ g x) := by
  have h := extension_hasSum_of_L2 (μ.restrict s) ζ hζ
    ((restrictInputOperator μ s).hasSum hsum) x
  simpa only [restrictInputOperator_apply,
    extension_restrictInput μ s hs _ (hf _), extension_restrictInput μ s hs g hg] using h

/-- Uniform extension reconstruction over all physical space, from supported L2 synthesis. -/
theorem supported_extension_uniform {Ω ι : Type*} [MeasurableSpace Ω] {n : ℕ}
    (μ : Measure Ω) (s : Set Ω) (hs : MeasurableSet s) [IsFiniteMeasure (μ.restrict s)]
    (ζ : Ω → Ambient n) (hζ : Measurable ζ) (f : ι → Lp ℂ 2 μ) (g : Lp ℂ 2 μ)
    (hf : ∀ j, HasFrequencySupport μ id s (f j)) (hg : HasFrequencySupport μ id s g)
    (hsum : HasSum f g) : ∀ ε : ℝ, 0 < ε →
      ∀ᶠ F : Finset ι in Filter.atTop, ∀ x : Ambient n,
        dist (∑ j ∈ F, extension μ ζ (f j) x) (extension μ ζ g x) < ε := by
  have h := extension_uniform_synthesis (μ.restrict s) ζ hζ ((restrictInputOperator μ s).hasSum hsum)
  simpa only [restrictInputOperator_apply,
    extension_restrictInput μ s hs _ (hf _), extension_restrictInput μ s hs g hg] using h

end N2Restriction
