import N2Restriction.LocalCorrection
import Mathlib.MeasureTheory.Measure.Hausdorff

namespace N2Restriction
open Filter MeasureTheory

/-- A Lipschitz image of a compact set in a d-dimensional space has finite
d-dimensional Hausdorff measure. -/
theorem finite_hausdorff_lipschitz_image {G E : Type*}
    [NormedAddCommGroup G] [NormedSpace ℝ G] [FiniteDimensional ℝ G]
    [MeasurableSpace G] [BorelSpace G]
    [MetricSpace E] [MeasurableSpace E] [BorelSpace E]
    {K : NNReal} {f : G → E} {s : Set G} (hs : IsCompact s)
    (hf : LipschitzOnWith K f s) :
    Measure.hausdorffMeasure (Module.finrank ℝ G) (f '' s) < ⊤ := by
  apply lt_of_le_of_lt (hf.hausdorffMeasure_image_le (Nat.cast_nonneg _))
  exact ENNReal.mul_lt_top (ENNReal.rpow_lt_top_of_nonneg (Nat.cast_nonneg _) ENNReal.coe_ne_top)
    hs.measure_lt_top

/-- The level set of implicit-function data has locally finite measure in the
free-coordinate dimension. The proof uses the actual inverse chart. -/
theorem implicit_level_locally_finite {E F G : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]
    [MeasurableSpace E] [BorelSpace E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [CompleteSpace F]
    [NormedAddCommGroup G] [NormedSpace ℝ G] [FiniteDimensional ℝ G]
    [MeasurableSpace G] [BorelSpace G]
    (d : ImplicitFunctionData ℝ E F G) :
    ∃ U ∈ nhds d.pt,
      Measure.hausdorffMeasure (Module.finrank ℝ G)
        ({x | d.leftFun x = d.leftFun d.pt} ∩ U) < ⊤ := by
  letI := FiniteDimensional.complete ℝ G
  let A := d.leftDeriv.equivProdOfSurjectiveOfIsCompl d.rightDeriv
    d.left_range d.right_range d.isCompl_ker
  let inv := d.hasStrictFDerivAt.localInverse d.prodFun A d.pt
  obtain ⟨K, V, hV, hLip⟩ := d.hasStrictFDerivAt.to_localInverse.exists_lipschitzOnWith
  obtain ⟨r, hr, hrV⟩ := Metric.mem_nhds_iff.mp hV
  let φ : G → E := fun t => inv (d.leftFun d.pt, t)
  have hslice : ∀ t ∈ Metric.closedBall (d.rightFun d.pt) (r / 2),
      (d.leftFun d.pt, t) ∈ V := by
    intro t ht
    apply hrV
    simpa [ImplicitFunctionData.prodFun, Prod.dist_eq] using
      lt_of_le_of_lt ht (by linarith : r / 2 < r)
  have hφ : LipschitzOnWith K φ (Metric.closedBall (d.rightFun d.pt) (r / 2)) := by
    apply LipschitzOnWith.of_dist_le_mul
    intro t ht u hu
    simpa [φ, Prod.dist_eq] using hLip.dist_le_mul _ (hslice t ht) _ (hslice u hu)
  have hfinite := finite_hausdorff_lipschitz_image (isCompact_closedBall _ _) hφ
  let U := {x | inv (d.prodFun x) = x ∧ dist (d.rightFun x) (d.rightFun d.pt) < r / 2}
  have hU : U ∈ nhds d.pt := by
    have hright : ∀ᶠ x in nhds d.pt,
        dist (d.rightFun x) (d.rightFun d.pt) < r / 2 :=
      d.right_has_deriv.continuousAt.eventually (Metric.ball_mem_nhds _ (by linarith))
    exact d.hasStrictFDerivAt.eventually_left_inverse.and hright
  refine ⟨U, hU, lt_of_le_of_lt (measure_mono ?_) hfinite⟩
  rintro x ⟨hlevel, hleft, hdist⟩
  refine ⟨d.rightFun x, hdist.le, ?_⟩
  change inv (d.leftFun d.pt, d.rightFun x) = x
  rw [← hlevel]
  exact hleft

/-- Local finiteness for a regular level set in the expected codimension. -/
theorem submersion_level_locally_finite {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
    [MeasurableSpace E] [BorelSpace E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    {f : E → F} {L : E →L[ℝ] F} {z : E}
    (hf : HasStrictFDerivAt f L z) (hL : Function.Surjective L) :
    ∃ U ∈ nhds z,
      Measure.hausdorffMeasure ((Module.finrank ℝ E - Module.finrank ℝ F : ℕ) : ℝ)
        ({x | f x = f z} ∩ U) < ⊤ := by
  letI := FiniteDimensional.complete ℝ E
  letI := FiniteDimensional.complete ℝ F
  have hr : LinearMap.range L.toLinearMap = ⊤ := LinearMap.range_eq_top.mpr hL
  have hd := L.toLinearMap.finrank_range_add_finrank_ker
  rw [hr, finrank_top] at hd
  have hk : Module.finrank ℝ (LinearMap.ker L.toLinearMap) = Module.finrank ℝ E - Module.finrank ℝ F := by omega
  have h := implicit_level_locally_finite
    (hf.implicitFunctionDataOfComplemented f L hr
      L.ker_closedComplemented_of_finiteDimensional_range)
  change ∃ U ∈ nhds z, Measure.hausdorffMeasure
    (Module.finrank ℝ (LinearMap.ker L.toLinearMap)) ({x | f x = f z} ∩ U) < ⊤ at h
  simpa only [hk] using h

/-- Compact subsets of a regular level set have finite Hausdorff measure in
the codimension predicted by the surjective differential. -/
theorem compact_regular_level_finite {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
    [MeasurableSpace E] [BorelSpace E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    {f : E → F} {s : Set E} (hs : IsCompact s) {c : F}
    (hlevel : ∀ z ∈ s, f z = c)
    (hreg : ∀ z ∈ s, ∃ L : E →L[ℝ] F,
      HasStrictFDerivAt f L z ∧ Function.Surjective L) :
    Measure.hausdorffMeasure ((Module.finrank ℝ E - Module.finrank ℝ F : ℕ) : ℝ) s < ⊤ := by
  apply hs.measure_lt_top_of_nhdsWithin
  intro z hz
  obtain ⟨L, hf, hL⟩ := hreg z hz
  obtain ⟨U, hU, hfin⟩ := submersion_level_locally_finite hf hL
  refine ⟨s ∩ U, inter_mem (self_mem_nhdsWithin) (mem_nhdsWithin_of_mem_nhds hU), ?_⟩
  apply lt_of_le_of_lt (measure_mono ?_) hfin
  intro x hx
  exact ⟨(hlevel x hx.1).trans (hlevel z hz).symm, hx.2⟩

end N2Restriction
