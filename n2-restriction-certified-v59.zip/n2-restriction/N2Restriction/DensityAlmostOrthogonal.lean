import N2Restriction.SurfaceGraphPackets

set_option maxHeartbeats 400000

namespace N2Restriction
open MeasureTheory

namespace PositiveBoundedDensity
theorem fromCoordinate_energy_lower {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω}
    (D : PositiveBoundedDensity μ) (f : Lp ℂ 2 μ) :
    ‖f‖ ^ 2 ≤ D.upper * ‖D.fromCoordinate f‖ ^ 2 := by
  simpa only [D.to_from] using D.toCoordinate_energy (D.fromCoordinate f)
end PositiveBoundedDensity

namespace CoordinateCapFamily
variable {d : ℕ} {K : Set (Ambient d)} {r : ℝ}

theorem densityPacket_selected_summable (P : CoordinateCapFamily K r) (hr : 0 < r)
    (D : PositiveBoundedDensity (volume : Measure (Ambient d))) (g : Lp ℂ 2 D.measure)
    (j : P.centers) (S : Set (Fin d → ℤ)) :
    Summable (fun ν : S => P.densityPacket hr D g j ν) := by
  have h := P.densityPacket_subcollection_summable hr D g Set.univ
  have hi : Function.Injective (fun ν : S =>
      (⟨(j, ν.val), Set.mem_univ _⟩ : (Set.univ : Set (P.centers × (Fin d → ℤ))))) := by
    intro a b hab
    apply Subtype.ext
    exact (Prod.mk.inj (Subtype.mk.inj hab)).2
  have hh := h.comp_injective hi
  simpa only [Function.comp_apply] using hh

/-- Cross-cap almost orthogonality survives the density change, with the explicit density ratio. -/
theorem densityPacket_selected_energy (P : CoordinateCapFamily K r) (hr : 0 < r)
    (D : PositiveBoundedDensity (volume : Measure (Ambient d))) (g : Lp ℂ 2 D.measure)
    (S : P.centers → Set (Fin d → ℤ)) :
    packetCutoffEnergy d * ‖∑ j, ∑' ν : S j, P.densityPacket hr D g j ν‖ ^ 2 ≤
      (D.upper / D.lower) * (9 ^ d * (2 * Real.pi) ^ d) *
        ∑ j, ∑' ν : S j, ‖P.densityPacket hr D g j ν‖ ^ 2 := by
  have hs (j : P.centers) : Summable (fun ν : S j => P.packet hr (D.toCoordinate g) j ν) :=
    (P.packet_hasSum hr (D.toCoordinate g) j).summable.subtype (S j)
  have he (j : P.centers) : Summable (fun ν : S j => ‖P.packet hr (D.toCoordinate g) j ν‖ ^ 2) :=
    by
      have h0 := actualPacketInput_energy_summable (j : Ambient d) r hr (P.input hr (D.toCoordinate g) j)
      have h1 := h0.subtype (S j)
      exact h1
  have hw (j : P.centers) := (divideDensityL2_tsum_energy volume D.weight D.measurable
    D.lower_pos D.lower_le (fun ν : S j => P.packet hr (D.toCoordinate g) j ν) (he j)).1
  have hmap : (∑ j, ∑' ν : S j, P.densityPacket hr D g j ν) =
      D.fromCoordinate (∑ j, ∑' ν : S j, P.packet hr (D.toCoordinate g) j ν) := by
    rw [map_sum]
    apply Finset.sum_congr rfl
    intro j _
    exact (D.fromCoordinate.map_tsum (hs j)).symm
  have hener : (∑ j, ∑' ν : S j, ‖P.packet hr (D.toCoordinate g) j ν‖ ^ 2) ≤
      D.upper * ∑ j, ∑' ν : S j, ‖P.densityPacket hr D g j ν‖ ^ 2 := by
    rw [Finset.mul_sum]
    apply Finset.sum_le_sum
    intro j _
    rw [← tsum_mul_left]
    exact (he j).tsum_le_tsum (fun ν => D.fromCoordinate_energy_lower _) ((hw j).mul_left D.upper)
  have hm : 0 ≤ 1 / D.lower := (one_div_pos.mpr D.lower_pos).le
  have hB : 0 ≤ 9 ^ d * (2 * Real.pi) ^ d := by positivity
  rw [hmap]
  calc
    _ ≤ packetCutoffEnergy d * ((1 / D.lower) *
        ‖∑ j, ∑' ν : S j, P.packet hr (D.toCoordinate g) j ν‖ ^ 2) :=
      mul_le_mul_of_nonneg_left (D.fromCoordinate_energy _) (packetCutoffEnergy_pos d).le
    _ = (1 / D.lower) * (packetCutoffEnergy d *
        ‖∑ j, ∑' ν : S j, P.packet hr (D.toCoordinate g) j ν‖ ^ 2) := by ring
    _ ≤ (1 / D.lower) * ((9 ^ d * (2 * Real.pi) ^ d) *
        ∑ j, ∑' ν : S j, ‖P.packet hr (D.toCoordinate g) j ν‖ ^ 2) :=
      mul_le_mul_of_nonneg_left (P.packet_selected_energy hr (D.toCoordinate g) S) hm
    _ ≤ (1 / D.lower) * ((9 ^ d * (2 * Real.pi) ^ d) *
        (D.upper * ∑ j, ∑' ν : S j, ‖P.densityPacket hr D g j ν‖ ^ 2)) :=
      mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left hener hB) hm
    _ = _ := by ring

end CoordinateCapFamily

namespace SurfaceGraphChart
variable {d : ℕ} (G : SurfaceGraphChart d)

theorem packet_selected_energy {K : Set (Ambient d)} {r : ℝ} (P : CoordinateCapFamily K r)
    (hr : 0 < r) (g : Lp ℂ 2 G.surfaceMeasure) (S : P.centers → Set (Fin d → ℤ)) :
    packetCutoffEnergy d * ‖∑ j, ∑' ν : S j, G.packet P hr g j ν‖ ^ 2 ≤
      (G.density.upper / G.density.lower) * (9 ^ d * (2 * Real.pi) ^ d) *
        ∑ j, ∑' ν : S j, ‖G.packet P hr g j ν‖ ^ 2 := by
  have hmap : (∑ j, ∑' ν : S j, G.packet P hr g j ν) =
      G.liftInput (∑ j, ∑' ν : S j, P.densityPacket hr G.density (G.pullInput g) j ν) := by
    rw [map_sum]
    apply Finset.sum_congr rfl
    intro j _
    exact (G.liftInput.toContinuousLinearMap.map_tsum
      (P.densityPacket_selected_summable hr G.density (G.pullInput g) j (S j))).symm
  rw [hmap, LinearIsometry.norm_map]
  simpa only [packet, LinearIsometry.norm_map] using
    P.densityPacket_selected_energy hr G.density (G.pullInput g) S

end SurfaceGraphChart
end N2Restriction
