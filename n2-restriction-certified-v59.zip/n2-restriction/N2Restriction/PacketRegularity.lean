import N2Restriction.CoordinatePacketTails
import N2Restriction.GraphSlicePlancherel

namespace N2Restriction
open MeasureTheory Set
set_option maxHeartbeats 400000

/-- The concrete packet input has a smooth compactly supported representative. -/
theorem graphAtom_smooth {d : ℕ} {χ : Ambient d → ℂ}
    (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (c : Ambient d) (r : ℝ) (v : Ambient d) :
    ContDiff ℝ (⊤ : ℕ∞) (graphAtom χ c r v) := by
  have hi : ContDiff ℝ (⊤ : ℕ∞) (fun ξ => ((inner ℝ v ξ : ℝ) : ℂ)) :=
    Complex.ofRealCLM.contDiff.comp (contDiff_const.inner ℝ contDiff_id)
  unfold graphAtom
  fun_prop

namespace CoordinateCapFamily
variable {d : ℕ} {K : Set (Ambient d)} {r : ℝ} (P : CoordinateCapFamily K r)

/-- A pointwise smooth representative, separated from the quotient-valued L2 packet. -/
noncomputable def smoothPacket (hr : 0 < r) (f : Lp ℂ 2 (volume : Measure (Ambient d)))
    (j : P.centers) (ν : Fin d → ℤ) (x : Ambient d) : ℂ :=
  actualPacketCoeff (j : Ambient d) r hr (P.input hr f j) ν *
    graphAtom (packetCutoff d) j r (r⁻¹ • latticeVector ν) x

theorem smoothPacket_coe (hr : 0 < r) (f : Lp ℂ 2 (volume : Measure (Ambient d)))
    (j : P.centers) (ν : Fin d → ℤ) :
    P.packet hr f j ν =ᵐ[volume] P.smoothPacket hr f j ν := by
  have h := actualPacketInput_coe (j : Ambient d) r hr (P.input hr f j) ν
  exact h

theorem smoothPacket_smooth (hr : 0 < r) (f : Lp ℂ 2 (volume : Measure (Ambient d)))
    (j : P.centers) (ν : Fin d → ℤ) :
    ContDiff ℝ (⊤ : ℕ∞) (P.smoothPacket hr f j ν) :=
  contDiff_const.mul (graphAtom_smooth (packetCutoff_smooth d) j r _)

theorem smoothPacket_compact (hr : 0 < r) (f : Lp ℂ 2 (volume : Measure (Ambient d)))
    (j : P.centers) (ν : Fin d → ℤ) :
    HasCompactSupport (P.smoothPacket hr f j ν) :=
  (graphAtom_hasCompactSupport (packetCutoff_compact d) j hr _).mul_left

/-- Every finite packet sum represents smooth compact frequency data. -/
theorem finite_packet_sum_smooth (hr : 0 < r) (f : Lp ℂ 2 (volume : Measure (Ambient d)))
    (S : Finset (P.centers × (Fin d → ℤ))) :
    ContDiff ℝ (⊤ : ℕ∞) (fun x => ∑ p ∈ S, P.smoothPacket hr f p.1 p.2 x) ∧
      HasCompactSupport (fun x => ∑ p ∈ S, P.smoothPacket hr f p.1 p.2 x) := by
  constructor
  · exact ContDiff.sum fun p _ => P.smoothPacket_smooth hr f p.1 p.2
  · classical
    induction S using Finset.induction_on with
    | empty => simpa using (HasCompactSupport.zero : HasCompactSupport (0 : Ambient d → ℂ))
    | @insert p S hp ih =>
      simpa only [Finset.sum_insert hp] using (P.smoothPacket_compact hr f p.1 p.2).add ih

/-- The finite smooth representative agrees almost everywhere with the L2 sum. -/
theorem finite_packet_sum_coe (hr : 0 < r) (f : Lp ℂ 2 (volume : Measure (Ambient d)))
    (S : Finset (P.centers × (Fin d → ℤ))) :
    (fun x => (∑ p ∈ S, P.packet hr f p.1 p.2 : Lp ℂ 2 (volume : Measure (Ambient d))) x)
      =ᵐ[volume] fun x => ∑ p ∈ S, P.smoothPacket hr f p.1 p.2 x := by
  apply (L2_coe_finset_sum volume (fun p => P.packet hr f p.1 p.2) S).trans
  filter_upwards [ae_all_iff.mpr (fun p : P.centers × (Fin d → ℤ) =>
    P.smoothPacket_coe hr f p.1 p.2)] with x hx
  exact Finset.sum_congr rfl (fun p _ => hx p)

end CoordinateCapFamily
end N2Restriction
