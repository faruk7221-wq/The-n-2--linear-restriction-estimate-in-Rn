import N2Restriction.LocalGraphCover

namespace N2Restriction
open MeasureTheory Set Filter

/-- Zero extension preserves frequency support measured on the original surface patch. -/
theorem zeroExtendL2_frequency_support {Ω : Type*} [MeasurableSpace Ω] {n : ℕ}
    (μ : Measure Ω) (S : Set Ω) (hS : MeasurableSet S) (ζ : Ω → Ambient n)
    (K : Set (Ambient n)) (g : Lp ℂ 2 (μ.restrict S))
    (hg : HasFrequencySupport (μ.restrict S) ζ K g) :
    HasFrequencySupport μ ζ K (zeroExtendL2 μ S hS g) := by
  have hs := (ae_restrict_iff' hS).mp hg
  filter_upwards [zeroExtendL2_coe μ S hS g, hs] with x hx hfreq hn
  by_cases hxs : x ∈ S
  · exact hfreq hxs (by simpa only [hx, indicator_of_mem hxs] using hn)
  · exact False.elim (hn (hx.trans (indicator_of_notMem hxs _)))

/-- Chart input on the chart's own restricted measure, from the original surface input. -/
noncomputable def atlasPatchInput {n m : ℕ} (μ : Measure (Ambient n))
    (S : Set (Ambient n)) (hS : MeasurableSet S)
    (K : Fin m → Set (Ambient n)) (hK : ∀ j, MeasurableSet (K j))
    (g : Lp ℂ 2 (μ.restrict S)) (j : Fin m) : Lp ℂ 2 (μ.restrict (K j)) :=
  restrictInputL2 μ (K j) (zeroExtendL2 μ S hS (finiteCoverInput (μ.restrict S) K hK g j))

/-- Transferring a disjoint chart piece between the actual restricted measures is isometric. -/
theorem atlasPatchInput_norm {n m : ℕ} (μ : Measure (Ambient n))
    (S : Set (Ambient n)) (hS : MeasurableSet S)
    (K : Fin m → Set (Ambient n)) (hK : ∀ j, MeasurableSet (K j))
    (g : Lp ℂ 2 (μ.restrict S)) (j : Fin m) :
    ‖atlasPatchInput μ S hS K hK g j‖ = ‖finiteCoverInput (μ.restrict S) K hK g j‖ := by
  have hs := zeroExtendL2_frequency_support μ S hS id (K j) _
    (finiteCoverInput_support (μ.restrict S) K hK g j)
  rw [atlasPatchInput, restrictInputL2_norm_of_support μ (K j) (hK j) _ hs, zeroExtendL2_norm]

/-- The chart-measure inputs retain the complete original input-energy budget. -/
theorem atlasPatchInput_energy {n m : ℕ} (μ : Measure (Ambient n))
    (S : Set (Ambient n)) (hS : MeasurableSet S)
    (K : Fin m → Set (Ambient n)) (hK : ∀ j, MeasurableSet (K j))
    (g : Lp ℂ 2 (μ.restrict S)) :
    (∑ j, ‖atlasPatchInput μ S hS K hK g j‖ ^ 2) ≤ ‖g‖ ^ 2 := by
  simp_rw [atlasPatchInput_norm]
  exact finiteCoverInput_energy (μ.restrict S) K hK g

/-- Each chart-measure extension equals the assigned piece of the original surface extension. -/
theorem atlasPatchInput_extension {n m : ℕ} (μ : Measure (Ambient n))
    (S : Set (Ambient n)) (hS : MeasurableSet S)
    (K : Fin m → Set (Ambient n)) (hK : ∀ j, MeasurableSet (K j))
    (g : Lp ℂ 2 (μ.restrict S)) (j : Fin m) (x : Ambient n) :
    extension (μ.restrict (K j)) id (atlasPatchInput μ S hS K hK g j) x =
      extension (μ.restrict S) id (finiteCoverInput (μ.restrict S) K hK g j) x := by
  have hs := zeroExtendL2_frequency_support μ S hS id (K j) _
    (finiteCoverInput_support (μ.restrict S) K hK g j)
  rw [atlasPatchInput, extension_restrictInput μ (K j) (hK j) _ hs, zeroExtendL2_extension]

/-- Exact extension reconstruction on the original surface from actual chart-measure inputs. -/
theorem atlasPatchInput_reconstruction {n m : ℕ} (μ : Measure (Ambient n))
    (S : Set (Ambient n)) (hS : MeasurableSet S) [IsFiniteMeasure (μ.restrict S)]
    (K : Fin m → Set (Ambient n)) (hK : ∀ j, MeasurableSet (K j))
    (hcover : S ⊆ ⋃ j, K j) (g : Lp ℂ 2 (μ.restrict S)) (x : Ambient n) :
    (∑ j, extension (μ.restrict (K j)) id (atlasPatchInput μ S hS K hK g j) x) =
      extension (μ.restrict S) id g x := by
  have hs : HasFrequencySupport (μ.restrict S) id (⋃ j, K j) g := by
    filter_upwards [ae_restrict_mem hS] with y hy _
    exact hcover hy
  have he := congrArg (extensionEvaluation (μ.restrict S) id measurable_id x)
    (finiteCoverInput_reconstruction (μ.restrict S) K hK g hs)
  rw [map_sum] at he
  simpa only [extensionEvaluation_eq, atlasPatchInput_extension] using he





/-- Atlas inputs stay supported on the original surface, despite using each larger chart measure. -/
theorem atlasPatchInput_original_support {n m : ℕ} (μ : Measure (Ambient n))
    (S : Set (Ambient n)) (hS : MeasurableSet S)
    (K : Fin m → Set (Ambient n)) (hK : ∀ j, MeasurableSet (K j))
    (g : Lp ℂ 2 (μ.restrict S)) (j : Fin m) :
    HasFrequencySupport (μ.restrict (K j)) id S (atlasPatchInput μ S hS K hK g j) := by
  have hz := (zeroExtendL2_vanishes μ S hS (finiteCoverInput (μ.restrict S) K hK g j)).filter_mono
    (ae_mono (Measure.restrict_le_self (μ := μ) (s := K j)))
  filter_upwards [restrictInputL2_coe μ (K j)
    (zeroExtendL2 μ S hS (finiteCoverInput (μ.restrict S) K hK g j)), hz] with x hx hzero hn
  by_contra h
  exact hn (hx.trans (hzero h))
/-- Chart-measure pieces recover the original input in L2 after canonical zero extension.
This is the identity needed to assemble the individual chart packet expansions. -/
theorem atlasPatchInput_L2_reconstruction {n m : ℕ} (μ : Measure (Ambient n))
    (S : Set (Ambient n)) (hS : MeasurableSet S)
    (K : Fin m → Set (Ambient n)) (hK : ∀ j, MeasurableSet (K j))
    (hcover : S ⊆ ⋃ j, K j) (g : Lp ℂ 2 (μ.restrict S)) :
    (∑ j, zeroExtendL2 μ (K j) (hK j) (atlasPatchInput μ S hS K hK g j)) =
      zeroExtendL2 μ S hS g := by
  have hs : HasFrequencySupport (μ.restrict S) id (⋃ j, K j) g := by
    filter_upwards [ae_restrict_mem hS] with y hy _
    exact hcover hy
  have he (j) : zeroExtendL2 μ (K j) (hK j) (atlasPatchInput μ S hS K hK g j) =
      zeroExtendL2 μ S hS (finiteCoverInput (μ.restrict S) K hK g j) := by
    exact zeroExtend_restrictInput μ (K j) (hK j) _
      (zeroExtendL2_frequency_support μ S hS id (K j) _
        (finiteCoverInput_support (μ.restrict S) K hK g j))
  simp_rw [he]
  have h := congrArg (zeroExtendIsometry μ S hS)
    (finiteCoverInput_reconstruction (μ.restrict S) K hK g hs)
  rw [map_sum] at h
  exact h

end N2Restriction
