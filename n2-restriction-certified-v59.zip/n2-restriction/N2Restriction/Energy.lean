import N2Restriction.Basic

/-! Positive finite packet energies. The analytic construction of packets is
not assumed in these lemmas: the results apply to every nonnegative energy
array and every incidence relation satisfying the stated multiplicity bound. -/

namespace N2Restriction
open scoped BigOperators

/-- Summing the same original energy over selections of multiplicity at most M.
This is the counting mechanism in (6.8), (7.5), and (7.15). -/
theorem energy_sum_of_multiplicity {C T : Type*} [Fintype C] [Fintype T]
    (select : C → T → Prop) [∀ c t, Decidable (select c t)]
    (e : T → ℝ) (he : ∀ t, 0 ≤ e t) (M : ℝ)
    (hm : ∀ t, ((Finset.univ.filter (fun c => select c t)).card : ℝ) ≤ M) :
    (∑ c, ∑ t ∈ Finset.univ.filter (select c), e t) ≤ M * ∑ t, e t := by
  simp only [Finset.sum_filter]
  rw [Finset.sum_comm]
  calc
    (∑ t, ∑ c, if select c t then e t else 0) =
        ∑ t, ((Finset.univ.filter (fun c => select c t)).card : ℝ) * e t := by
      congr 1
      ext t
      rw [← Finset.sum_filter]
      simp
    _ ≤ ∑ t, M * e t := by
      apply Finset.sum_le_sum
      intro t _
      exact mul_le_mul_of_nonneg_right (hm t) (he t)
    _ = M * ∑ t, e t := by rw [Finset.mul_sum]

/-- A subset keeps at most the total original energy. -/
lemma selected_energy_le_total {T : Type*} [Fintype T] (A : Finset T)
    (e : T → ℝ) (he : ∀ t, 0 ≤ e t) : ∑ t ∈ A, e t ≤ ∑ t, e t := by
  exact Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ A) (fun t _ _ => he t)

/-- A simultaneous good-cell selection from a strict total budget.
Apply to normalized energies of the substantial-mass cells. -/
theorem exists_simultaneous_good_cell {C I : Type*} [Fintype C] [Fintype I]
    (E : I → C → ℝ) (hE : ∀ i c, 0 ≤ E i c)
    (hbudget : (∑ c, ∑ i, E i c) < Fintype.card C) :
    ∃ c, ∀ i, E i c < 1 := by
  by_contra h
  push_neg at h
  have hcell : ∀ c, (1 : ℝ) ≤ ∑ i, E i c := by
    intro c
    obtain ⟨i, hi⟩ := h c
    exact hi.trans (Finset.single_le_sum (fun j _ => hE j c) (Finset.mem_univ i))
  have hsum := Finset.sum_le_sum (s := Finset.univ) (fun c _ => hcell c)
  simp only [Finset.sum_const, Finset.card_univ, nsmul_eq_mul, mul_one] at hsum
  linarith

/-- A bound for the norm of each selected sum, together with a multiplicity
bound, implies a summed norm budget. The synthesis bound is explicit. -/
theorem selected_norm_budget {C T : Type*} [Fintype C] [Fintype T]
    (select : C → T → Prop) [∀ c t, Decidable (select c t)]
    (e : T → ℝ) (he : ∀ t, 0 ≤ e t) (a : C → ℝ) (K M : ℝ)
    (hK : 0 ≤ K)
    (hsynthesis : ∀ c, a c ^ 2 ≤ K * ∑ t ∈ Finset.univ.filter (select c), e t)
    (hm : ∀ t, ((Finset.univ.filter (fun c => select c t)).card : ℝ) ≤ M) :
    (∑ c, a c ^ 2) ≤ K * M * ∑ t, e t := by
  calc
    (∑ c, a c ^ 2) ≤ ∑ c, K * ∑ t ∈ Finset.univ.filter (select c), e t :=
      Finset.sum_le_sum fun c _ => hsynthesis c
    _ = K * ∑ c, ∑ t ∈ Finset.univ.filter (select c), e t := by rw [Finset.mul_sum]
    _ ≤ K * (M * ∑ t, e t) :=
      mul_le_mul_of_nonneg_left (energy_sum_of_multiplicity select e he M hm) hK
    _ = K * M * ∑ t, e t := by ring

/-- An arbitrary subset of nonnegative energies inherits a total-energy bound. -/
lemma selection_preserves_budget {T : Type*} [Fintype T] (A : Finset T)
    (e : T → ℝ) (he : ∀ t, 0 ≤ e t) {B : ℝ} (hB : ∑ t, e t ≤ B) :
    ∑ t ∈ A, e t ≤ B := (selected_energy_le_total A e he).trans hB

/-- Quantitative simultaneous Markov selection for (6.9).
Every budget is positive; vanishing families are handled separately in applications.
The factor card(I)+1 makes the union of bad cells strictly smaller than all cells. -/
theorem simultaneous_markov_selection {C I : Type*} [Fintype C] [Nonempty C] [Fintype I]
    (E : I → C → ℝ) (hE : ∀ i c, 0 ≤ E i c)
    (B : I → ℝ) (hB : ∀ i, 0 < B i) (hbudget : ∀ i, ∑ c, E i c ≤ B i) :
    ∃ c, ∀ i, E i c < ((Fintype.card I : ℝ) + 1) / Fintype.card C * B i := by
  let N : ℝ := Fintype.card C
  let m : ℝ := Fintype.card I
  let scale : ℝ := (m + 1) / N
  have hN : 0 < N := by
    dsimp [N]
    exact_mod_cast (Fintype.card_pos : 0 < Fintype.card C)
  have hm : 0 ≤ m := Nat.cast_nonneg _
  have hscale : 0 < scale := by dsimp [scale]; positivity
  let F : I → C → ℝ := fun i c => E i c / (scale * B i)
  have hF : ∀ i c, 0 ≤ F i c := fun i c => div_nonneg (hE i c) (mul_pos hscale (hB i)).le
  have hsum : (∑ c, ∑ i, F i c) < N := by
    rw [Finset.sum_comm]
    calc
      (∑ i, ∑ c, F i c) ≤ ∑ _i : I, 1 / scale := by
        apply Finset.sum_le_sum
        intro i _
        dsimp [F]
        rw [← Finset.sum_div]
        calc
          (∑ c, E i c) / (scale * B i) ≤ B i / (scale * B i) :=
            div_le_div_of_nonneg_right (hbudget i) (mul_pos hscale (hB i)).le
          _ = 1 / scale := by field_simp [ne_of_gt (hB i)]
      _ = m / scale := by simp [m, div_eq_mul_inv]
      _ < N := by
        rw [div_lt_iff₀ hscale]
        dsimp [scale]
        field_simp
        linarith
  obtain ⟨c, hc⟩ := exists_simultaneous_good_cell F hF hsum
  refine ⟨c, fun i => ?_⟩
  exact (div_lt_one (mul_pos hscale (hB i))).mp (hc i)

end N2Restriction
