import N2Restriction.GraphPackets
import Mathlib.Analysis.Distribution.FourierSchwartz

namespace N2Restriction
open MeasureTheory Complex
open scoped FourierTransform ComplexConjugate

/-- Conjugation exchanges the two signs in the Euclidean Fourier kernel. -/
theorem fourier_conj_eq_conj_inverse {d : ℕ} (f : Ambient d → ℂ) (y : Ambient d) :
    𝓕 (fun x => conj (f x)) y = conj (𝓕⁻ f y) := by
  rw [Real.fourierIntegral_eq', Real.fourierIntegralInv_eq', ← integral_conj]
  apply integral_congr_ae
  filter_upwards with x
  simp only [smul_eq_mul, map_mul, ← Complex.exp_conj, map_mul, Complex.conj_ofReal,
    Complex.conj_I]
  congr 2
  push_cast
  ring

/-- Parseval's pairing identity for an integrable input with integrable Fourier transform. -/
theorem fourier_parseval_pairing {d : ℕ} (f : Ambient d → ℂ)
    (hf : Integrable f) (hF : Integrable (𝓕 f)) (hc : Continuous f) :
    (∫ y, 𝓕 f y * conj (𝓕 f y)) = ∫ x, f x * conj (f x) := by
  have hconj : Integrable (fun y => conj (𝓕 f y)) := by
    exact hF.norm.mono' (Complex.continuous_conj.comp_aestronglyMeasurable hF.aestronglyMeasurable)
      (Filter.Eventually.of_forall fun y => by simp)
  have h := VectorFourier.integral_fourierIntegral_smul_eq_flip
    (L := innerₗ (Ambient d)) Real.continuous_fourierChar continuous_inner hf hconj
  have hi : ∀ x, 𝓕 (fun y => conj (𝓕 f y)) x = conj (f x) := by
    intro x
    rw [fourier_conj_eq_conj_inverse, hc.fourier_inversion hf hF]
  simp only [smul_eq_mul, flip_innerₗ] at h
  change (∫ y, 𝓕 f y * conj (𝓕 f y)) = ∫ x, f x * 𝓕 (fun y => conj (𝓕 f y)) x at h
  simpa only [hi] using h

/-- Euclidean Plancherel with Mathlib's `2π` normalization, under Fourier integrability. -/
theorem fourier_plancherel_integrable {d : ℕ} (f : Ambient d → ℂ)
    (hf : Integrable f) (hF : Integrable (𝓕 f)) (hc : Continuous f) :
    (∫ y, ‖𝓕 f y‖ ^ 2) = ∫ x, ‖f x‖ ^ 2 := by
  have h := fourier_parseval_pairing f hf hF hc
  simp only [Complex.mul_conj, Complex.normSq_eq_norm_sq] at h
  simp only [integral_complex_ofReal] at h
  exact Complex.ofReal_injective h

/-- Plancherel for every Schwartz input on finite-dimensional Euclidean space. -/
theorem schwartz_fourier_plancherel {d : ℕ} (f : SchwartzMap (Ambient d) ℂ) :
    (∫ y, ‖𝓕 f y‖ ^ 2) = ∫ x, ‖f x‖ ^ 2 :=
  fourier_plancherel_integrable f f.integrable
    (SchwartzMap.fourierTransformCLM ℂ f).integrable f.continuous

/-- The inverse Fourier transform has the same Parseval normalization. -/
theorem inverse_fourier_plancherel_integrable {d : ℕ} (f : Ambient d → ℂ)
    (hf : Integrable f) (hF : Integrable (𝓕 f)) (hc : Continuous f) :
    (∫ y, ‖𝓕⁻ f y‖ ^ 2) = ∫ x, ‖f x‖ ^ 2 := by
  simp_rw [Real.fourierIntegralInv_eq_fourierIntegral_neg]
  rw [integral_neg_eq_self (fun y => ‖𝓕 f y‖ ^ 2)]
  exact fourier_plancherel_integrable f hf hF hc

/-- The article's positive-sign kernel has no `2π` in its exponent. -/
theorem flat_extension_eq_inverse_fourier {d : ℕ} (f : Ambient d → ℂ) (y : Ambient d) :
    extension volume id f y = 𝓕⁻ f ((2 * Real.pi)⁻¹ • y) := by
  rw [Real.fourierIntegralInv_eq']
  unfold extension
  apply integral_congr_ae
  filter_upwards with x
  simp only [id_eq, inner_smul_right, smul_eq_mul]
  rw [real_inner_comm x y]
  congr 2
  congr 1
  field_simp

/-- Plancherel for the precise unnormalized kernel used in the article. -/
theorem flat_extension_plancherel {d : ℕ} (f : Ambient d → ℂ)
    (hf : Integrable f) (hF : Integrable (𝓕 f)) (hc : Continuous f) :
    (∫ y, ‖extension volume id f y‖ ^ 2) =
      (2 * Real.pi) ^ d * ∫ x, ‖f x‖ ^ 2 := by
  simp_rw [flat_extension_eq_inverse_fourier]
  rw [Measure.integral_comp_inv_smul_of_nonneg volume (fun y => ‖𝓕⁻ f y‖ ^ 2) (by positivity : 0 ≤ 2 * Real.pi)]
  simp only [Ambient, finrank_euclideanSpace, Fintype.card_fin, smul_eq_mul]
  rw [inverse_fourier_plancherel_integrable f hf hF hc]

/-- Smooth compactly supported inputs satisfy unnormalized Plancherel. -/
theorem smooth_compact_flat_plancherel {d : ℕ} {f : Ambient d → ℂ}
    (hc : ContDiff ℝ (⊤ : ℕ∞) f) (hs : HasCompactSupport f) :
    (∫ y, ‖extension volume id f y‖ ^ 2) =
      (2 * Real.pi) ^ d * ∫ x, ‖f x‖ ^ 2 := by
  let F := hs.toSchwartzMap hc
  exact flat_extension_plancherel F F.integrable
    (SchwartzMap.fourierTransformCLM ℂ F).integrable F.continuous

end N2Restriction
