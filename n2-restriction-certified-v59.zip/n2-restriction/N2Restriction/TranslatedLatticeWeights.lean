import N2Restriction.LatticeWeights

namespace N2Restriction
open scoped BigOperators ENNReal

/-- Move a real center to its integer floor at a uniformly bounded loss. -/
theorem integer_weight_translate_le (n : ℤ) (a : ℝ) :
    (1 + |(n : ℝ) - a|)⁻¹ ≤ 2 * (1 + |((n - ⌊a⌋ : ℤ) : ℝ)|)⁻¹ := by
  have ht : |(n : ℝ) - (⌊a⌋ : ℝ)| ≤ |(n : ℝ) - a| + 1 := by
    calc
      |(n : ℝ) - (⌊a⌋ : ℝ)| = |((n : ℝ) - a) + (a - (⌊a⌋ : ℝ))| := by congr 1; ring
      _ ≤ |(n : ℝ) - a| + |a - (⌊a⌋ : ℝ)| := abs_add_le _ _
      _ ≤ _ := by
        rw [abs_of_nonneg (sub_nonneg.mpr (Int.floor_le a))]
        linarith [Int.lt_floor_add_one a]
  rw [Int.cast_sub, ← one_div, ← div_eq_mul_inv]
  apply (div_le_div_iff₀ (by positivity) (by positivity)).mpr
  nlinarith [abs_nonneg ((n : ℝ) - a)]

noncomputable def centeredLatticeDecay {d : ℕ} (a : Fin d → ℝ) (ν : Fin d → ℤ) : ℝ :=
  ∏ j, (1 + |(ν j : ℝ) - a j|)⁻¹

lemma centeredLatticeDecay_nonneg {d : ℕ} (a : Fin d → ℝ) (ν : Fin d → ℤ) :
    0 ≤ centeredLatticeDecay a ν :=
  Finset.prod_nonneg (fun _ _ => by positivity)

/-- Uniform comparison with a translate of the fixed lattice weight. -/
theorem centeredLatticeDecay_le {d : ℕ} (a : Fin d → ℝ) (ν : Fin d → ℤ) :
    centeredLatticeDecay a ν ≤ 2 ^ d * latticeDecay (ν - fun j => ⌊a j⌋) := by
  unfold centeredLatticeDecay latticeDecay
  calc
    _ ≤ ∏ j : Fin d, 2 * (1 + |((ν j - ⌊a j⌋ : ℤ) : ℝ)|)⁻¹ := by
      apply Finset.prod_le_prod
      · intro j _; positivity
      · intro j _; exact integer_weight_translate_le (ν j) (a j)
    _ = _ := by simp only [Finset.prod_mul_distrib, Finset.prod_const, Finset.card_univ,
      Fintype.card_fin, Pi.sub_apply]

/-- Integer translations preserve the full squared lattice mass exactly. -/
theorem latticeDecay_shift_mass (d : ℕ) (z : Fin d → ℤ) :
    (∑' ν : Fin d → ℤ, latticeDecay (ν - z) ^ 2) = ∑' ν : Fin d → ℤ, latticeDecay ν ^ 2 :=
  (Equiv.subRight z).tsum_eq (fun ν => latticeDecay ν ^ 2)

theorem centeredLatticeDecay_square_summable {d : ℕ} (a : Fin d → ℝ) :
    Summable (fun ν : Fin d → ℤ => centeredLatticeDecay a ν ^ 2) := by
  have hs := (latticeDecay_square_summable d).comp_injective
    (Equiv.subRight (fun j => ⌊a j⌋)).injective
  apply Summable.of_nonneg_of_le (fun _ => sq_nonneg _)
    (fun ν => ?_) (hs.mul_left (((2 : ℝ) ^ d) ^ 2))
  simpa only [mul_pow] using pow_le_pow_left₀ (centeredLatticeDecay_nonneg a ν)
    (centeredLatticeDecay_le a ν) 2

/-- The square-sum bound is independent of the real translation parameter. -/
theorem centeredLatticeDecay_mass_le {d : ℕ} (a : Fin d → ℝ) :
    (∑' ν : Fin d → ℤ, centeredLatticeDecay a ν ^ 2) ≤
      ((2 : ℝ) ^ d) ^ 2 * ∑' ν : Fin d → ℤ, latticeDecay ν ^ 2 := by
  have hs := (latticeDecay_square_summable d).comp_injective
    (Equiv.subRight (fun j => ⌊a j⌋)).injective
  calc
    _ ≤ ∑' ν : Fin d → ℤ, ((2 : ℝ) ^ d) ^ 2 * latticeDecay (ν - fun j => ⌊a j⌋) ^ 2 := by
      apply (centeredLatticeDecay_square_summable a).tsum_le_tsum _ (hs.mul_left _)
      intro ν
      simpa only [mul_pow] using pow_le_pow_left₀ (centeredLatticeDecay_nonneg a ν)
        (centeredLatticeDecay_le a ν) 2
    _ = _ := by rw [tsum_mul_left, latticeDecay_shift_mass]

noncomputable def centeredLatticeWeight {d : ℕ} (a : Fin d → ℝ) :
    lp (fun _ : Fin d → ℤ => ℂ) 2 :=
  ⟨fun ν => (centeredLatticeDecay a ν : ℂ), memℓp_gen (by
    simpa only [ENNReal.toReal_ofNat, Real.rpow_two, Complex.norm_real,
      Real.norm_eq_abs, abs_of_nonneg (centeredLatticeDecay_nonneg _ _)] using
      centeredLatticeDecay_square_summable a)⟩

/-- Uniform l2 norm of polynomial lattice weights at arbitrary real centers. -/
theorem centeredLatticeWeight_norm_le {d : ℕ} (a : Fin d → ℝ) :
    ‖centeredLatticeWeight a‖ ≤ 2 ^ d * ‖latticeWeight d‖ := by
  apply lp.norm_le_of_tsum_le (by norm_num : 0 < (2 : ENNReal).toReal) (by positivity)
  have hw := lp.norm_rpow_eq_tsum (by norm_num : 0 < (2 : ENNReal).toReal) (latticeWeight d)
  change ‖latticeWeight d‖ ^ (2 : ENNReal).toReal = ∑' ν, ‖(latticeDecay ν : ℂ)‖ ^ (2 : ENNReal).toReal at hw
  simp only [ENNReal.toReal_ofNat, Real.rpow_two, Complex.norm_real,
    Real.norm_eq_abs, abs_of_nonneg (latticeDecay_nonneg _)] at hw
  change (∑' ν, ‖(centeredLatticeDecay a ν : ℂ)‖ ^ (2 : ENNReal).toReal) ≤ _
  simpa only [ENNReal.toReal_ofNat, Real.rpow_two, Complex.norm_real,
    Real.norm_eq_abs, abs_of_nonneg (centeredLatticeDecay_nonneg _ _), mul_pow, hw] using
      centeredLatticeDecay_mass_le a

/-- Uniform absolute packet tails for every physical center and every selection.
The integration-by-parts domination remains an explicit analytic hypothesis. -/
theorem centered_lattice_packet_tail {d : ℕ} {E F : Type*}
    [NormedAddCommGroup E] [InnerProductSpace ℂ E] [NormedAddCommGroup F]
    (b : HilbertBasis (Fin d → ℤ) ℂ E) (x : E) (a : Fin d → ℝ)
    (r : (Fin d → ℤ) → F) {δ : ℝ} (hδ : 0 ≤ δ)
    (hr : ∀ ν, ‖r ν‖ ≤ δ * (‖b.repr x ν‖ * centeredLatticeDecay a ν))
    (S : Set (Fin d → ℤ)) :
    (∑' ν : S, ‖r ν‖) ≤ δ * ‖x‖ * (2 ^ d * ‖latticeWeight d‖) := by
  have ht := packet_error_absolute_tail b x (centeredLatticeWeight a) r hδ ?_ S
  · exact ht.trans (mul_le_mul_of_nonneg_left (centeredLatticeWeight_norm_le a)
      (mul_nonneg hδ (norm_nonneg _)))
  · intro ν
    change ‖r ν‖ ≤ δ * (‖b.repr x ν‖ * ‖(centeredLatticeDecay a ν : ℂ)‖)
    simpa only [Complex.norm_real, Real.norm_eq_abs,
      abs_of_nonneg (centeredLatticeDecay_nonneg _ _)] using hr ν

end N2Restriction
