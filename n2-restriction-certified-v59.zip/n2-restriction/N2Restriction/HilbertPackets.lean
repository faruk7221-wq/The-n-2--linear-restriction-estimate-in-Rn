import Mathlib.Analysis.InnerProductSpace.l2Space

/-! Unconditional coefficient synthesis and arbitrary packet selections.
These results establish the Hilbert-space part of packet synthesis. Spatial
localization and frequency support are separate obligations. -/
namespace N2Restriction
open scoped BigOperators
open Filter
variable {ι E F : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E]
  [CompleteSpace E] [NormedAddCommGroup F] [NormedSpace ℂ F] [CompleteSpace F]

omit [CompleteSpace E] in
/-- Exact energy identity for finite orthonormal synthesis. -/
theorem orthonormal_finite_energy {v : ι → E} (hv : Orthonormal ℂ v)
    (a : ι → ℂ) (s : Finset ι) :
    ‖∑ i ∈ s, a i • v i‖ ^ 2 = ∑ i ∈ s, ‖a i‖ ^ 2 := by
  simpa only [LinearIsometry.toSpanSingleton_apply] using hv.orthogonalFamily.norm_sum a s

/-- Square summability is exactly unconditional summability of orthogonal packets. -/
theorem orthonormal_summable_iff {v : ι → E} (hv : Orthonormal ℂ v) (a : ι → ℂ) :
    Summable (fun i => a i • v i) ↔ Summable (fun i => ‖a i‖ ^ 2) := by
  simpa only [LinearIsometry.toSpanSingleton_apply] using
    hv.orthogonalFamily.summable_iff_norm_sq_summable a

/-- Parseval for an arbitrary square-summable coefficient family. -/
theorem orthonormal_infinite_energy {v : ι → E} (hv : Orthonormal ℂ v)
    (a : ι → ℂ) (ha : Summable (fun i => ‖a i‖ ^ 2)) :
    ‖∑' i, a i • v i‖ ^ 2 = ∑' i, ‖a i‖ ^ 2 := by
  classical
  have ht := ((orthonormal_summable_iff hv a).mpr ha).hasSum.norm.pow 2
  have he : (fun s : Finset ι => ‖∑ i ∈ s, a i • v i‖ ^ 2) =
      (fun s : Finset ι => ∑ i ∈ s, ‖a i‖ ^ 2) :=
    funext (orthonormal_finite_energy hv a)
  rw [he] at ht
  exact tendsto_nhds_unique ht ha.hasSum

/-- Every subcollection has unconditional synthesis with its own original energy. -/
theorem orthonormal_selected_energy {v : ι → E} (hv : Orthonormal ℂ v)
    (a : ι → ℂ) (ha : Summable (fun i => ‖a i‖ ^ 2)) (S : Set ι) :
    ‖∑' i : S, a i • v i‖ ^ 2 = ∑' i : S, ‖a i‖ ^ 2 :=
  orthonormal_infinite_energy (hv.comp Subtype.val Subtype.coe_injective)
    (fun i : S => a i) (ha.subtype S)

omit [CompleteSpace E] [CompleteSpace F] in
/-- A bounded cutoff or synthesis operator preserves unconditional convergence. -/
theorem bounded_packet_hasSum (b : HilbertBasis ι ℂ E) (T : E →L[ℂ] F) (x : E) :
    HasSum (fun i => T (b.repr x i • b i)) (T x) :=
  T.hasSum (b.hasSum_repr x)

omit [CompleteSpace E] in
/-- The original coefficients satisfy an exact total energy identity. -/
theorem hilbert_coefficient_energy (b : HilbertBasis ι ℂ E) (x : E) :
    HasSum (fun i => ‖b.repr x i‖ ^ 2) (‖x‖ ^ 2) := by
  simpa using lp.hasSum_norm (p := (2 : ENNReal)) (by norm_num) (b.repr x)

omit [CompleteSpace F] in
/-- The selected bounded packets have the same coefficient energy bound for
all subcollections, without requiring absolute summability of vector norms. -/
theorem bounded_packet_selection (b : HilbertBasis ι ℂ E) (T : E →L[ℂ] F)
    (x : E) (S : Set ι) :
    ‖∑' i : S, T (b.repr x i • b i)‖ ^ 2 ≤
      ‖T‖ ^ 2 * ∑' i : S, ‖b.repr x i‖ ^ 2 := by
  have ha := (hilbert_coefficient_energy b x).summable
  have hs := (orthonormal_summable_iff
    (b.orthonormal.comp Subtype.val Subtype.coe_injective)
    (fun i : S => b.repr x i)).mpr (ha.subtype S)
  change Summable (fun i : S => b.repr x i • b i) at hs
  rw [← T.map_tsum hs]
  calc
    ‖T (∑' i : S, b.repr x i • b i)‖ ^ 2 ≤
        (‖T‖ * ‖∑' i : S, b.repr x i • b i‖) ^ 2 :=
      pow_le_pow_left₀ (norm_nonneg _) (T.le_opNorm _) 2
    _ = ‖T‖ ^ 2 * ∑' i : S, ‖b.repr x i‖ ^ 2 := by
      rw [mul_pow, orthonormal_selected_energy b.orthonormal _ ha S]

omit [CompleteSpace E] in
/-- Every selected coefficient energy is bounded by the original input energy. -/
theorem hilbert_selected_energy_le (b : HilbertBasis ι ℂ E) (x : E) (S : Set ι) :
    (∑' i : S, ‖b.repr x i‖ ^ 2) ≤ ‖x‖ ^ 2 := by
  have h := hilbert_coefficient_energy b x
  rw [← h.tsum_eq]
  exact Summable.tsum_subtype_le _ S (fun _ => sq_nonneg _) h.summable

omit [CompleteSpace F] in
/-- All selections obey one operator norm bound, uniformly in the selection. -/
theorem bounded_packet_uniform_budget (b : HilbertBasis ι ℂ E) (T : E →L[ℂ] F)
    (x : E) (S : Set ι) :
    ‖∑' i : S, T (b.repr x i • b i)‖ ^ 2 ≤ ‖T‖ ^ 2 * ‖x‖ ^ 2 :=
  (bounded_packet_selection b T x S).trans
    (mul_le_mul_of_nonneg_left (hilbert_selected_energy_le b x S) (sq_nonneg _))

/-- Splitting any coefficient set from its complement reconstructs the input. -/
theorem hilbert_selection_complement (b : HilbertBasis ι ℂ E) (x : E) (S : Set ι) :
    (∑' i : S, b.repr x i • b i) + (∑' i : (Sᶜ : Set ι), b.repr x i • b i) = x := by
  rw [Summable.tsum_subtype_add_tsum_subtype_compl (b.hasSum_repr x).summable S,
    (b.hasSum_repr x).tsum_eq]

/-- The residual after a finite truncation has precisely the omitted energy. -/
theorem hilbert_truncation_error (b : HilbertBasis ι ℂ E) (x : E) (s : Finset ι) :
    ‖x - ∑ i ∈ s, b.repr x i • b i‖ ^ 2 =
      ∑' i : {i // i ∉ s}, ‖b.repr x i‖ ^ 2 := by
  have h := (b.hasSum_repr x).summable.sum_add_tsum_subtype_compl s
  rw [(b.hasSum_repr x).tsum_eq] at h
  have he : x - ∑ i ∈ s, b.repr x i • b i =
      ∑' i : {i // i ∉ s}, b.repr x i • b i := by
    exact sub_eq_iff_eq_add.mpr (by simpa [add_comm] using h.symm)
  rw [he]
  exact orthonormal_selected_energy b.orthonormal _
    (hilbert_coefficient_energy b x).summable {i | i ∉ s}

end N2Restriction
