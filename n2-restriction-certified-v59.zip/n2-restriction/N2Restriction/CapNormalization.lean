import N2Restriction.CapFourier
open MeasureTheory
namespace N2Restriction
/-- Exact L2 norm conversion from normalized cap measure to ordinary Lebesgue measure. -/
theorem capProbability_eLpNorm {d : ℕ} (t : Fin d → ℝ) (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Ambient d → ℂ) :
    (eLpNorm f 2 (capProbability t c r hr.ne')).toReal =
      r ^ (-(d : ℝ) / 2) * (eLpNorm f 2 (volume.restrict (scaledCube t c r hr.ne'))).toReal := by
  rw [capProbability_eq, eLpNorm_smul_measure_of_ne_top (by norm_num)]
  simp only [smul_eq_mul, ENNReal.toReal_mul, ← ENNReal.toReal_rpow,
    ENNReal.toReal_ofReal (abs_nonneg _)]
  norm_num only [ENNReal.toReal_div, ENNReal.toReal_one, ENNReal.toReal_ofNat]
  congr 1
  rw [abs_of_pos (inv_pos.mpr (pow_pos hr d)), Real.inv_rpow (le_of_lt (pow_pos hr d))]
  rw [← Real.rpow_natCast, ← Real.rpow_mul hr.le, ← Real.rpow_neg hr.le]
  congr 1
  ring

/-- An ordinary Lebesgue L2 cap input belongs to the normalized cap L2 space. -/
theorem cap_input_memLp {d : ℕ} (t : Fin d → ℝ) (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume.restrict (scaledCube t c r hr.ne'))) :
    MemLp f 2 (capProbability t c r hr.ne') := by
  rw [capProbability_eq]
  exact (Lp.memLp f).smul_measure ENNReal.ofReal_ne_top

/-- The same actual cap function, now interpreted with normalized measure. -/
noncomputable def normalizedCapInput {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : 0 < r) (f : Lp ℂ 2 (volume.restrict (scaledCube t c r hr.ne'))) :
    Lp ℂ 2 (capProbability t c r hr.ne') :=
  (cap_input_memLp t c r hr f).toLp f

theorem normalizedCapInput_coe {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : 0 < r) (f : Lp ℂ 2 (volume.restrict (scaledCube t c r hr.ne'))) :
    normalizedCapInput t c r hr f =ᵐ[capProbability t c r hr.ne'] f :=
  (cap_input_memLp t c r hr f).coeFn_toLp

theorem normalizedCapInput_norm {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : 0 < r) (f : Lp ℂ 2 (volume.restrict (scaledCube t c r hr.ne'))) :
    ‖normalizedCapInput t c r hr f‖ = r ^ (-(d : ℝ) / 2) * ‖f‖ := by
  rw [Lp.norm_def, eLpNorm_congr_ae (normalizedCapInput_coe t c r hr f),
    capProbability_eLpNorm t c r hr, Lp.norm_def]

/-- Parseval for coefficients extracted from an ordinary Lebesgue L2 cap input,
including the exact scale factor rather than a comparability constant. -/
theorem cap_lebesgue_fourier_energy {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : 0 < r) (f : Lp ℂ 2 (volume.restrict (scaledCube t c r hr.ne'))) :
    (∑' ν, ‖capFourierCoeff t c r hr.ne' (normalizedCapInput t c r hr f) ν‖ ^ 2) =
      r ^ (-(d : ℝ)) * ‖f‖ ^ 2 := by
  rw [cap_fourier_energy, normalizedCapInput_norm, mul_pow, ← Real.rpow_natCast,
    ← Real.rpow_mul hr.le]
  congr 2
  push_cast
  ring

end N2Restriction
