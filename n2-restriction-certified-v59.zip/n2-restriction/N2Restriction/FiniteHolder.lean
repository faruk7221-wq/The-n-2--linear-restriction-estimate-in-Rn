import N2Restriction.PositiveAnalysis

/-! The sequence inequality used in Lemma 7.1 and the product Hölder
estimate used on the selected functions in (7.15). -/

namespace N2Restriction
open MeasureTheory
open scoped ENNReal NNReal BigOperators

lemma sum_rpow_le_rpow_sum {I : Type*} (s : Finset I) (f : I → ℝ≥0∞)
    {r : ℝ} (hr : 1 ≤ r) :
    (∑ i ∈ s, f i ^ r) ≤ (∑ i ∈ s, f i) ^ r := by
  classical
  induction s using Finset.induction_on with
  | empty => simp [ENNReal.zero_rpow_of_pos (show 0 < r by linarith)]
  | @insert i s hi ih =>
      simp only [Finset.sum_insert hi]
      exact (add_le_add_left ih _).trans (ENNReal.add_rpow_le_rpow_add _ _ hr)

/-- Monotonicity of sequence quasi-norms, valid below exponent one too. -/
theorem finite_lp_monotone {I : Type*} (s : Finset I) (f : I → ℝ≥0∞)
    {q p : ℝ} (hq : 0 < q) (hqp : q ≤ p) :
    (∑ i ∈ s, f i ^ p) ^ (1 / p) ≤ (∑ i ∈ s, f i ^ q) ^ (1 / q) := by
  have hp : 0 < p := hq.trans_le hqp
  have hr : 1 ≤ p / q := (le_div_iff₀ hq).2 (by simpa using hqp)
  have he : q * (p / q) = p := by field_simp
  have he' : (p / q) * (1 / p) = 1 / q := by field_simp
  calc
    (∑ i ∈ s, f i ^ p) ^ (1 / p) =
        (∑ i ∈ s, (f i ^ q) ^ (p / q)) ^ (1 / p) := by
      simp only [← ENNReal.rpow_mul, he]
    _ ≤ ((∑ i ∈ s, f i ^ q) ^ (p / q)) ^ (1 / p) :=
      ENNReal.rpow_le_rpow (sum_rpow_le_rpow_sum s (fun i => f i ^ q) hr) (by positivity)
    _ = (∑ i ∈ s, f i ^ q) ^ (1 / q) := by rw [← ENNReal.rpow_mul, he']

/-- Integral product Hölder at exponent 2/k. This is the step applied to
Gi in (7.14)--(7.15), with the selected functions themselves as inputs. -/
theorem product_holder_integral {X : Type*} [MeasurableSpace X]
    (μ : Measure X) {k : ℕ} (hk : 0 < k)
    (G : Fin k → X → ℝ≥0∞) (hG : ∀ i, AEMeasurable (G i) μ) :
    (∫⁻ x, (∏ i, G i x) ^ (2 / (k : ℝ)) ∂μ) ^ ((k : ℝ) / 2) ≤
      ∏ i, (∫⁻ x, G i x ^ (2 : ℝ) ∂μ) ^ (1 / 2 : ℝ) := by
  have hkR : (0 : ℝ) < k := by exact_mod_cast hk
  have hw : (∑ _i : Fin k, (1 / (k : ℝ))) = 1 := by
    simp [ne_of_gt hkR]
  have hh := ENNReal.lintegral_prod_norm_pow_le (μ := μ) Finset.univ
    (f := fun i x => G i x ^ (2 : ℝ)) (p := fun _ => 1 / (k : ℝ))
    (fun i _ => (hG i).pow_const _) hw (fun _ _ => by positivity)
  have hid : (1 / (k : ℝ)) * ((k : ℝ) / 2) = 1 / 2 := by field_simp
  have hid' : (2 : ℝ) * (1 / (k : ℝ)) = 2 / (k : ℝ) := by ring
  have hlhs : (∫⁻ x, (∏ i, G i x) ^ (2 / (k : ℝ)) ∂μ) =
      ∫⁻ x, ∏ i, (G i x ^ (2 : ℝ)) ^ (1 / (k : ℝ)) ∂μ := by
    congr 1
    funext x
    rw [← ENNReal.prod_rpow_of_nonneg (by positivity)]
    simp only [← ENNReal.rpow_mul, hid']
  rw [hlhs]
  have h := ENNReal.rpow_le_rpow hh (show 0 ≤ (k : ℝ) / 2 by positivity)
  simpa only [← ENNReal.prod_rpow_of_nonneg (show 0 ≤ (k : ℝ) / 2 by positivity),
    ← ENNReal.rpow_mul, hid] using h

/-- The complete finite sequence estimate in Lemma 7.1.
The original packet energies enter via the summed squares on the right. -/
theorem nontangent_sequence_bound {k L : ℕ} (hk : 0 < k)
    (b : Fin k → Fin L → ℝ≥0∞) {p : ℝ} (hp : 2 / (k : ℝ) ≤ p) :
    (∑ l, (∏ i, b i l) ^ p) ^ (1 / p) ≤
      ∏ i, (∑ l, b i l ^ (2 : ℝ)) ^ (1 / 2 : ℝ) := by
  have hkR : (0 : ℝ) < k := by exact_mod_cast hk
  have hq : 0 < 2 / (k : ℝ) := by positivity
  apply (finite_lp_monotone Finset.univ (fun l => ∏ i, b i l) hq hp).trans
  have h := product_holder_integral (Measure.count : Measure (Fin L)) hk b
    (fun i => (measurable_of_countable (b i)).aemeasurable)
  simpa only [lintegral_count, tsum_fintype, one_div_div, mul_one] using h

end N2Restriction
