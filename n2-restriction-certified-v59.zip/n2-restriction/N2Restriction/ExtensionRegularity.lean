import N2Restriction.Extension

namespace N2Restriction
open MeasureTheory
open scoped ENNReal NNReal BigOperators

/-- Absolute integrability of the oscillatory integrand, without any smoothness
assumption on the frequency parametrization. -/
lemma integrable_extension_kernel {n : ℕ} {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} {ζ : Ω → Ambient n} {f : Ω → ℂ}
    (hζ : Measurable ζ) (hf : Integrable f μ) (x : Ambient n) :
    Integrable (fun ω => Complex.exp ((inner ℝ x (ζ ω) : ℂ) * Complex.I) * f ω) μ := by
  have hk : Measurable (fun ω => Complex.exp ((inner ℝ x (ζ ω) : ℂ) * Complex.I)) := by
    fun_prop
  refine hf.norm.mono' (hk.aestronglyMeasurable.mul hf.aestronglyMeasurable) ?_
  exact Filter.Eventually.of_forall (fun ω => by simp)

/-- Dominated convergence gives continuity of the actual Fourier extension. -/
theorem continuous_extension {n : ℕ} {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} {ζ : Ω → Ambient n} {f : Ω → ℂ}
    (hζ : Measurable ζ) (hf : Integrable f μ) : Continuous (extension μ ζ f) := by
  unfold extension
  apply continuous_of_dominated
    (fun x => (integrable_extension_kernel hζ hf x).aestronglyMeasurable)
    (fun x => Filter.Eventually.of_forall (fun ω =>
      show ‖Complex.exp ((inner ℝ x (ζ ω) : ℂ) * Complex.I) * f ω‖ ≤ ‖f ω‖ by
        simp)) hf.norm
  exact Filter.Eventually.of_forall (fun ω => by fun_prop)

/-- On finite patches every L2 input has a continuous extension. -/
lemma continuous_extension_of_memLp {n : ℕ} {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsFiniteMeasure μ] {ζ : Ω → Ambient n} {f : Ω → ℂ}
    (hζ : Measurable ζ) (hf : MemLp f 2 μ) : Continuous (extension μ ζ f) := by
  exact continuous_extension hζ (hf.integrable (by norm_num))

/-- In particular the product used in the restriction inequality is measurable. -/
theorem continuous_extensionProduct {n k : ℕ} {Ω : Fin k → Type*}
    [∀ i, MeasurableSpace (Ω i)] {μ : ∀ i, Measure (Ω i)}
    [∀ i, IsFiniteMeasure (μ i)] {ζ : ∀ i, Ω i → Ambient n}
    {f : ∀ i, Ω i → ℂ} (hζ : ∀ i, Measurable (ζ i))
    (hf : ∀ i, MemLp (f i) 2 (μ i)) : Continuous (extensionProduct μ ζ f) := by
  exact continuous_finset_prod _ (fun i _ => continuous_extension_of_memLp (hζ i) (hf i))

end N2Restriction
