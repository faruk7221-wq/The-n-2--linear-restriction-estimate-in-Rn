import N2Restriction.CoverBallEstimate
import N2Restriction.SurfaceMeasure

namespace N2Restriction
open MeasureTheory Set

/-- Concrete data for a compact rotated patch of a locally smooth graph.
No Plancherel estimate or surface-density identity is an assumed field. -/
structure LocalGraphPatch (d : ℕ) where
  rotation : Ambient (d + 1) ≃ₗᵢ[ℝ] Ambient (d + 1)
  domain : Set (Ambient d)
  open_domain : IsOpen domain
  phase : Ambient d → ℝ
  smooth_phase : ContDiffOn ℝ (⊤ : ℕ∞) phase domain
  center : Ambient d
  innerRadius : ℝ
  outerRadius : ℝ
  positive_inner : 0 < innerRadius
  radii_lt : innerRadius < outerRadius
  ball_inside : Metric.closedBall center outerRadius ⊆ domain
  support : Set (Ambient d)
  compact_support : IsCompact support
  support_inside : support ⊆ Metric.closedBall center innerRadius

namespace LocalGraphPatch

def carrier {d : ℕ} (P : LocalGraphPatch d) : Set (Ambient (d + 1)) :=
  P.rotation '' ((fun x => graphPoint x (P.phase x)) '' P.support)

theorem compact_carrier {d : ℕ} (P : LocalGraphPatch d) : IsCompact P.carrier := by
  obtain ⟨G, _, he⟩ := exists_local_surfaceGraphChart P.open_domain P.smooth_phase P.center
    P.positive_inner P.radii_lt P.ball_inside
  have himg : (fun x => graphPoint x (P.phase x)) '' P.support = G.parametrization '' P.support := by
    apply image_congr
    intro x hx
    change graphPoint x (P.phase x) = graphPoint x (G.phase x)
    rw [he (P.support_inside hx)]
  rw [carrier, himg]
  exact (P.compact_support.image (graphMap_lipschitz G.lipschitz).continuous).image P.rotation.continuous

/-- The graph's actual Hausdorff measure satisfies a bound for every original L2 input. -/
theorem exists_ball_bound {d : ℕ} (P : LocalGraphPatch d) :
    ∃ C : ℝ, 0 ≤ C ∧ HasBallEnergyBound
      ((Measure.hausdorffMeasure (d : ℝ)).restrict P.carrier) C :=
  rotated_local_graph_patch_ball_estimate P.rotation P.open_domain P.smooth_phase P.center
    P.positive_inner P.radii_lt P.ball_inside P.compact_support P.support_inside

end LocalGraphPatch

/-- For the article's regular-level-set measure, only construction of a compatible graph
cover remains: the analytic assembly and norm transport are discharged here. -/
theorem SmoothPatch.ball_bound_of_graph_cover {d m : ℕ} (S : SmoothPatch (d + 1))
    (P : Fin m → LocalGraphPatch d) (hcover : S.support ⊆ ⋃ j, (P j).carrier) :
    ∃ C : ℝ, 0 ≤ C ∧ HasBallEnergyBound S.surfaceMeasure C := by
  have hdim : ((d + 1 : ℕ) : ℝ) - 1 = (d : ℝ) := by push_cast; ring
  have hμ : S.surfaceMeasure = (Measure.hausdorffMeasure (d : ℝ)).restrict S.support := by
    rw [SmoothPatch.surfaceMeasure, hdim]
  haveI : IsFiniteMeasure S.surfaceMeasure := S.isFiniteMeasure_surfaceMeasure (by omega)
  rw [hμ] at *
  exact exists_ball_bound_of_finite_cover (Measure.hausdorffMeasure (d : ℝ)) S.support
    S.compact_support.measurableSet (fun j => (P j).carrier)
    (fun j => (P j).compact_carrier.measurableSet) hcover (fun j => (P j).exists_ball_bound)

end N2Restriction
