import N2Restriction.CapCutoffFourier
import N2Restriction.ScaledCutoff
import Mathlib.Analysis.Real.Pi.Bounds

namespace N2Restriction
open MeasureTheory Set

/-- The centered Fourier cube has side 2πr, larger than the cutoff support of radius 2r. -/
noncomputable def packetFrequencyCube {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r) :
    Set (Ambient d) := scaledCube (fun _ => -(1 / 2 : ℝ)) c (2 * Real.pi * r) (by positivity)

theorem mem_packetFrequencyCube {d : ℕ} (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (ξ : Ambient d) : ξ ∈ packetFrequencyCube c r hr ↔
      ∀ j, -(Real.pi * r) < (ξ - c) j ∧ (ξ - c) j ≤ Real.pi * r := by
  change ξ ∈ capAffine c (2 * Real.pi * r) (by positivity) '' unitCube (fun _ => -(1 / 2 : ℝ)) ↔ _
  rw [show (capAffine c (2 * Real.pi * r) (by positivity) : (Fin d → ℝ) → Ambient d) =
    (capAffine c (2 * Real.pi * r) (by positivity)).toEquiv from rfl, Set.mem_image_equiv]
  change (capAffine c (2 * Real.pi * r) (by positivity)).symm ξ ∈
    unitCube (fun _ => -(1 / 2 : ℝ)) ↔ _
  rw [capAffine_symm_apply]
  simp only [unitCube, mem_pi, mem_univ, forall_true_left, mem_Ioc,
    WithLp.ofLp_smul, Pi.smul_apply, PiLp.ofLp_apply, smul_eq_mul]
  have hp : 0 < 2 * Real.pi * r := by positivity
  apply forall_congr'
  intro j
  rw [mul_comm ((2 * Real.pi * r)⁻¹), ← div_eq_mul_inv,
    lt_div_iff₀ hp, div_le_iff₀ hp]
  constructor <;> intro h <;> constructor <;> nlinarith [h.1, h.2]

/-- Even the closed outer cutoff ball lies inside the half-open Fourier cube. -/
theorem closedBall_subset_packetFrequencyCube {d : ℕ} (c : Ambient d)
    (r : ℝ) (hr : 0 < r) : Metric.closedBall c (2 * r) ⊆ packetFrequencyCube c r hr := by
  intro ξ hξ
  rw [mem_packetFrequencyCube]
  intro j
  have hn : ‖ξ - c‖ ≤ 2 * r := by simpa only [Metric.mem_closedBall, dist_eq_norm] using hξ
  have hj := (PiLp.norm_apply_le (ξ - c) j).trans hn
  rw [Real.norm_eq_abs, abs_le] at hj
  have hp : 2 * r < Real.pi * r := mul_lt_mul_of_pos_right (lt_trans (by norm_num : (2 : ℝ) < 3) Real.pi_gt_three) hr
  constructor <;> linarith [hj.1, hj.2]

/-- Zero extension from this Fourier cube does not cut off any nonzero frequency bump. -/
theorem frequencyBump_zero_outside_packetCube {d : ℕ} (c : Ambient d)
    (r : ℝ) (hr : 0 < r) {ξ : Ambient d} (hξ : ξ ∉ packetFrequencyCube c r hr) :
    frequencyBump c r hr ξ = 0 := by
  apply (frequencyBump c r hr).zero_of_le_dist
  by_contra h
  apply hξ
  apply closedBall_subset_packetFrequencyCube c r hr
  exact le_of_lt (lt_of_not_ge h)

/-- The actual cutoff-modulated graph atom has no periodic copies outside its frequency cube. -/
theorem reference_graphAtom_zero_outside_packetCube {d : ℕ} (c : Ambient d)
    (r : ℝ) (hr : 0 < r) (v : Ambient d) {ξ : Ambient d}
    (hξ : ξ ∉ packetFrequencyCube c r hr) :
    graphAtom (fun η => (referenceBump d η : ℂ)) c r v ξ = 0 := by
  simp only [graphAtom]
  rw [← frequencyBump_rescale c hr, frequencyBump_zero_outside_packetCube c r hr hξ]
  simp

end N2Restriction
