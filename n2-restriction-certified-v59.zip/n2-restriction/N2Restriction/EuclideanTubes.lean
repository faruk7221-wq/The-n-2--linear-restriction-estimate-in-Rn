import N2Restriction.GraphPackets
import Mathlib.Topology.MetricSpace.HausdorffDistance

namespace N2Restriction

theorem graphPoint_sub {d : ℕ} (u w : Ambient d) (t s : ℝ) :
    graphPoint u t - graphPoint w s = graphPoint (u - w) (t - s) := by
  ext j
  refine Fin.cases ?_ (fun k => ?_) j <;> simp [graphPoint]

theorem graphPoint_norm_sq {d : ℕ} (u : Ambient d) (t : ℝ) :
    ‖graphPoint u t‖ ^ 2 = ‖u‖ ^ 2 + t ^ 2 := by
  rw [← real_inner_self_eq_norm_sq, graphPoint_inner,
    real_inner_self_eq_norm_sq, pow_two]
  ring

theorem graphPoint_dist_sq {d : ℕ} (u w : Ambient d) (t s : ℝ) :
    dist (graphPoint u t) (graphPoint w s) ^ 2 = ‖u - w‖ ^ 2 + (t - s) ^ 2 := by
  rw [dist_eq_norm, graphPoint_sub, graphPoint_norm_sq]

theorem graphPoint_dist_same_height {d : ℕ} (u w : Ambient d) (t : ℝ) :
    dist (graphPoint u t) (graphPoint w t) = ‖u - w‖ := by
  have h := graphPoint_dist_sq u w t t
  have h₁ := dist_nonneg (x := graphPoint u t) (y := graphPoint w t)
  have h₂ := norm_nonneg (u - w)
  nlinarith

/-- The infinite affine axis of a graph packet. -/
def packetAxis {d : ℕ} (c v : Ambient d) : Set (Ambient (d + 1)) :=
  Set.range (fun s : ℝ => graphPoint (-v - s • c) s)

theorem packetAxis_nonempty {d : ℕ} (c v : Ambient d) :
    (packetAxis c v).Nonempty := ⟨_, ⟨0, rfl⟩⟩

theorem packetAxis_dist_le_offset {d : ℕ} (c v u : Ambient d) (t : ℝ) :
    Metric.infDist (graphPoint u t) (packetAxis c v) ≤ ‖u + v + t • c‖ := by
  have h := Metric.infDist_le_dist_of_mem (x := graphPoint u t)
    (s := packetAxis c v) (Set.mem_range_self t)
  rw [graphPoint_dist_same_height] at h
  convert h using 1
  congr 1
  abel

/-- Sharp operator-norm bound for the transverse graph coordinate. -/
theorem graph_transverse_norm_le {d : ℕ} (c w : Ambient d) (s : ℝ) :
    ‖w + s • c‖ ≤ Real.sqrt (1 + ‖c‖ ^ 2) * ‖graphPoint w s‖ := by
  have htri := norm_add_le w (s • c)
  rw [norm_smul, Real.norm_eq_abs] at htri
  have hs := Real.sq_sqrt (show 0 ≤ 1 + ‖c‖ ^ 2 by positivity)
  have hg := graphPoint_norm_sq w s
  have ha : |s| ^ 2 = s ^ 2 := sq_abs s
  have hcs := sq_nonneg (‖w‖ * ‖c‖ - |s|)
  have hnon : 0 ≤ Real.sqrt (1 + ‖c‖ ^ 2) * ‖graphPoint w s‖ := by positivity
  have hsq : (‖w‖ + |s| * ‖c‖) ^ 2 ≤
      (Real.sqrt (1 + ‖c‖ ^ 2) * ‖graphPoint w s‖) ^ 2 := by
    rw [mul_pow, hs, hg]
    nlinarith
  have hn : 0 ≤ ‖w‖ + |s| * ‖c‖ := by positivity
  nlinarith

theorem packetAxis_offset_le_dist {d : ℕ} (c v u : Ambient d) (t : ℝ) :
    ‖u + v + t • c‖ ≤ Real.sqrt (1 + ‖c‖ ^ 2) *
      Metric.infDist (graphPoint u t) (packetAxis c v) := by
  have hK : 0 < Real.sqrt (1 + ‖c‖ ^ 2) := Real.sqrt_pos.2 (by positivity)
  rw [mul_comm]
  apply (div_le_iff₀ hK).mp
  apply (Metric.le_infDist (packetAxis_nonempty c v)).2
  rintro y ⟨s, rfl⟩
  apply (div_le_iff₀ hK).2
  have h := graph_transverse_norm_le c (u - (-v - s • c)) (t - s)
  rw [← graphPoint_sub, ← dist_eq_norm] at h
  have he : u - (-v - s • c) + (t - s) • c = u + v + t • c := by
    rw [sub_smul]
    abel
  rw [he] at h
  simpa only [mul_comm] using h

/-- On bounded graph slopes the two tube conventions have one common factor. -/
theorem packetAxis_offset_le_uniform_dist {d : ℕ} {K : ℝ} (hK : 0 ≤ K)
    (c v u : Ambient d) (t : ℝ) (hc : ‖c‖ ≤ K) :
    ‖u + v + t • c‖ ≤ Real.sqrt (1 + K ^ 2) *
      Metric.infDist (graphPoint u t) (packetAxis c v) := by
  apply (packetAxis_offset_le_dist c v u t).trans
  apply mul_le_mul_of_nonneg_right _ Metric.infDist_nonneg
  apply Real.sqrt_le_sqrt
  nlinarith [norm_nonneg c]

theorem packetAxis_distance_between {d : ℕ} (c v : Ambient d) (s t : ℝ) :
    dist (graphPoint (-v - s • c) s) (graphPoint (-v - t • c) t) =
      Real.sqrt (1 + ‖c‖ ^ 2) * |s - t| := by
  have h := graphPoint_dist_sq (-v - s • c) (-v - t • c) s t
  have he : (-v - s • c) - (-v - t • c) = -(s - t) • c := by
    simp only [neg_smul, sub_smul]
    abel
  rw [he, norm_smul, Real.norm_eq_abs, abs_neg] at h
  have hs := Real.sq_sqrt (show 0 ≤ 1 + ‖c‖ ^ 2 by positivity)
  have ha := sq_abs (s - t)
  have hn : 0 ≤ Real.sqrt (1 + ‖c‖ ^ 2) * |s - t| := by positivity
  have hd := dist_nonneg (x := graphPoint (-v - s • c) s)
    (y := graphPoint (-v - t • c) t)
  nlinarith [sq_nonneg (Real.sqrt (1 + ‖c‖ ^ 2) * |s - t|)]

/-- The height-truncated axis has Euclidean length at most 2R sqrt(1+K²). -/
theorem packetAxis_segment_distance_bound {d : ℕ} {K R : ℝ}
    (hK : 0 ≤ K) (c v : Ambient d) (hc : ‖c‖ ≤ K)
    (s t : ℝ) (hs : |s| ≤ R) (ht : |t| ≤ R) :
    dist (graphPoint (-v - s • c) s) (graphPoint (-v - t • c) t) ≤
      2 * R * Real.sqrt (1 + K ^ 2) := by
  rw [packetAxis_distance_between]
  have hst : |s - t| ≤ 2 * R := by
    calc |s - t| ≤ |s| + |t| := abs_sub s t
         _ ≤ 2 * R := by linarith
  have hc' : Real.sqrt (1 + ‖c‖ ^ 2) ≤ Real.sqrt (1 + K ^ 2) := by
    apply Real.sqrt_le_sqrt
    nlinarith [norm_nonneg c]
  calc
    _ ≤ Real.sqrt (1 + K ^ 2) * (2 * R) :=
      mul_le_mul hc' hst (abs_nonneg _) (Real.sqrt_nonneg _)
    _ = _ := by ring

/-- The graph packet axis is normal to every tangent direction of slope c. -/
theorem packetAxis_direction_normal {d : ℕ} (c η : Ambient d) :
    inner ℝ (graphPoint (-c) 1) (graphPoint η (inner ℝ c η)) = 0 := by
  rw [graphPoint_inner, inner_neg_left]
  ring

/-- A finite packet axis, parametrized by the physical height interval. -/
def packetSegment {d : ℕ} (c v : Ambient d) (R : ℝ) : Set (Ambient (d + 1)) :=
  (fun s : ℝ => graphPoint (-v - s • c) s) '' Set.Icc (-R) R

theorem packetSegment_subset_axis {d : ℕ} (c v : Ambient d) (R : ℝ) :
    packetSegment c v R ⊆ packetAxis c v := by
  rintro y ⟨s, _, rfl⟩
  exact Set.mem_range_self s

theorem packetSegment_nonempty {d : ℕ} (c v : Ambient d) {R : ℝ} (hR : 0 ≤ R) :
    (packetSegment c v R).Nonempty := by
  exact ⟨_, ⟨0, ⟨by linarith, hR⟩, rfl⟩⟩

theorem packetSegment_dist_le_offset {d : ℕ} (c v u : Ambient d)
    {R t : ℝ} (ht : |t| ≤ R) :
    Metric.infDist (graphPoint u t) (packetSegment c v R) ≤ ‖u + v + t • c‖ := by
  have h := Metric.infDist_le_dist_of_mem (x := graphPoint u t)
    (s := packetSegment c v R) ⟨t, abs_le.mp ht, rfl⟩
  rw [graphPoint_dist_same_height] at h
  convert h using 1
  congr 1
  abel

theorem packetSegment_offset_le_dist {d : ℕ} (c v u : Ambient d)
    {R : ℝ} (hR : 0 ≤ R) (t : ℝ) :
    ‖u + v + t • c‖ ≤ Real.sqrt (1 + ‖c‖ ^ 2) *
      Metric.infDist (graphPoint u t) (packetSegment c v R) := by
  apply (packetAxis_offset_le_dist c v u t).trans
  exact mul_le_mul_of_nonneg_left
    (Metric.infDist_le_infDist_of_subset (packetSegment_subset_axis c v R)
      (packetSegment_nonempty c v hR)) (Real.sqrt_nonneg _)

theorem packetSegment_pairwise_distance {d : ℕ} {K R : ℝ} (hK : 0 ≤ K)
    (c v : Ambient d) (hc : ‖c‖ ≤ K) {x y : Ambient (d + 1)}
    (hx : x ∈ packetSegment c v R) (hy : y ∈ packetSegment c v R) :
    dist x y ≤ 2 * R * Real.sqrt (1 + K ^ 2) := by
  obtain ⟨s, hs, rfl⟩ := hx
  obtain ⟨t, ht, rfl⟩ := hy
  exact packetAxis_segment_distance_bound hK c v hc s t (abs_le.mpr hs) (abs_le.mpr ht)

/-- The same-height point on the finite axis gives an explicit enclosing ball. -/
theorem packet_offset_tube_bounded {d : ℕ} {R ρ K : ℝ} (hK : 0 ≤ K)
    (c v u : Ambient d) (hc : ‖c‖ ≤ K) (t : ℝ) (ht : |t| ≤ R)
    (hu : ‖u + v + t • c‖ ≤ ρ) :
    dist (graphPoint u t) (graphPoint (-v) 0) ≤ ρ + R * Real.sqrt (1 + K ^ 2) := by
  have hsame : dist (graphPoint u t) (graphPoint (-v - t • c) t) ≤ ρ := by
    rw [graphPoint_dist_same_height]
    convert hu using 1
    congr 1
    abel
  have haxis := packetAxis_distance_between c v t 0
  simp only [zero_smul, sub_zero] at haxis
  have hc' : Real.sqrt (1 + ‖c‖ ^ 2) ≤ Real.sqrt (1 + K ^ 2) := by
    apply Real.sqrt_le_sqrt
    nlinarith [norm_nonneg c]
  calc
    _ ≤ dist (graphPoint u t) (graphPoint (-v - t • c) t) +
        dist (graphPoint (-v - t • c) t) (graphPoint (-v) 0) := dist_triangle _ _ _
    _ ≤ ρ + Real.sqrt (1 + ‖c‖ ^ 2) * |t| := by rw [haxis]; gcongr
    _ ≤ ρ + Real.sqrt (1 + K ^ 2) * R := by
      exact add_le_add_left (mul_le_mul hc' ht (abs_nonneg _) (Real.sqrt_nonneg _)) ρ
    _ = _ := by ring

/-- Compact cap-center sets supply a common geometric comparison constant. -/
theorem compact_packetAxis_comparison {d : ℕ} {Q : Set (Ambient d)} (hQ : IsCompact Q) :
    ∃ K : ℝ, 0 < K ∧ ∀ c ∈ Q, ∀ v u : Ambient d, ∀ t : ℝ,
      ‖u + v + t • c‖ ≤ K * Metric.infDist (graphPoint u t) (packetAxis c v) := by
  obtain ⟨B, hB, hb⟩ := hQ.isBounded.exists_pos_norm_le
  refine ⟨Real.sqrt (1 + B ^ 2), Real.sqrt_pos.2 (by positivity), ?_⟩
  intro c hc v u t
  exact packetAxis_offset_le_uniform_dist hB.le c v u t (hb c hc)

end N2Restriction
