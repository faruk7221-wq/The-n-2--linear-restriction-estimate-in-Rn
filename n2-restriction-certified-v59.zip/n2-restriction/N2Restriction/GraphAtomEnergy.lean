import N2Restriction.GraphPackets

namespace N2Restriction
open MeasureTheory

/-- The actual normalized, modulated frequency input for a graph packet. -/
noncomputable def graphAtom {d : ℕ} (χ : Ambient d → ℂ) (c : Ambient d)
    (r : ℝ) (v ξ : Ambient d) : ℂ :=
  (r ^ (-(d : ℝ) / 2) : ℝ) * Complex.exp ((inner ℝ v ξ : ℂ) * Complex.I) *
    χ (r⁻¹ • (ξ - c))

/-- Moving the normalization inside the integral gives the original extension. -/
theorem extension_graphAtom {d : ℕ} (φ : Ambient d → ℝ) (χ : Ambient d → ℂ)
    (c : Ambient d) (r : ℝ) (v u : Ambient d) (t : ℝ) :
    extension volume (fun ξ => graphPoint ξ (φ ξ)) (graphAtom χ c r v)
      (graphPoint u t) = graphPacket φ χ c r v u t := by
  rw [graphPacket_eq_extension]
  unfold extension graphAtom
  rw [← integral_const_mul]
  apply integral_congr_ae
  filter_upwards with ξ
  ring

theorem norm_graphAtom {d : ℕ} (χ : Ambient d → ℂ) (c : Ambient d)
    {r : ℝ} (hr : 0 < r) (v ξ : Ambient d) :
    ‖graphAtom χ c r v ξ‖ = r ^ (-(d : ℝ) / 2) * ‖χ (r⁻¹ • (ξ - c))‖ := by
  simp only [graphAtom, norm_mul, Complex.norm_exp_ofReal_mul_I, mul_one,
    Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (Real.rpow_nonneg hr.le _)]

/-- Exact Euclidean L2 mass of every normalized atom, independent of cap center,
scale and modulation. No comparability assumption is supplied. -/
theorem graphAtom_L2_mass {d : ℕ} (χ : Ambient d → ℂ) (c : Ambient d)
    {r : ℝ} (hr : 0 < r) (v : Ambient d) :
    (∫ ξ, ‖graphAtom χ c r v ξ‖ ^ 2) = ∫ η, ‖χ η‖ ^ 2 := by
  have hI : (∫ ξ, ‖χ (r⁻¹ • (ξ - c))‖ ^ 2) =
      r ^ d * ∫ η, ‖χ η‖ ^ 2 := by
    rw [integral_sub_right_eq_self (fun ξ => ‖χ (r⁻¹ • ξ)‖ ^ 2) c]
    have ht := Measure.integral_comp_inv_smul_of_nonneg
      (volume : Measure (Ambient d)) (fun η => ‖χ η‖ ^ 2) hr.le
    simpa only [Ambient, finrank_euclideanSpace, Fintype.card_fin, smul_eq_mul] using ht
  have hscale : (r ^ (-(d : ℝ) / 2)) ^ 2 * r ^ d = 1 := by
    rw [← Real.rpow_natCast, ← Real.rpow_mul hr.le, ← Real.rpow_natCast r d,
      ← Real.rpow_add hr]
    have he : -(d : ℝ) / 2 * (2 : ℕ) + d = 0 := by push_cast; ring
    rw [he, Real.rpow_zero]
  simp_rw [norm_graphAtom χ c hr v, mul_pow]
  rw [integral_const_mul, hI, ← mul_assoc, hscale, one_mul]

/-- Multiplying by a coefficient gives exactly its squared modulus times the
reference cutoff energy. -/
theorem graphAtom_coefficient_energy {d : ℕ} (χ : Ambient d → ℂ) (c : Ambient d)
    {r : ℝ} (hr : 0 < r) (v : Ambient d) (z : ℂ) :
    (∫ ξ, ‖z * graphAtom χ c r v ξ‖ ^ 2) = ‖z‖ ^ 2 * ∫ η, ‖χ η‖ ^ 2 := by
  simp_rw [norm_mul, mul_pow]
  rw [integral_const_mul, graphAtom_L2_mass χ c hr v]

/-- Compact cutoff support survives the actual affine rescaling and modulation. -/
theorem graphAtom_hasCompactSupport {d : ℕ} {χ : Ambient d → ℂ}
    (hs : HasCompactSupport χ) (c : Ambient d) {r : ℝ} (hr : 0 < r) (v : Ambient d) :
    HasCompactSupport (graphAtom χ c r v) := by
  let e : Ambient d ≃ₜ Ambient d := (Homeomorph.subRight c).trans
    (Homeomorph.smul (Units.mk0 r⁻¹ (inv_ne_zero hr.ne')))
  have he : ∀ ξ, e ξ = r⁻¹ • (ξ - c) := fun _ => rfl
  have hc : HasCompactSupport (fun ξ => χ (r⁻¹ • (ξ - c))) := by
    simpa only [Function.comp_def, he] using hs.comp_homeomorph e
  exact hc.mul_left

/-- The constructed smooth compact atoms are legitimate L2 inputs. -/
theorem graphAtom_memLp {d : ℕ} {χ : Ambient d → ℂ}
    (hχ : Continuous χ) (hs : HasCompactSupport χ)
    (c : Ambient d) {r : ℝ} (hr : 0 < r) (v : Ambient d) :
    MemLp (graphAtom χ c r v) 2 volume := by
  have hc : Continuous (graphAtom χ c r v) := by unfold graphAtom; fun_prop
  exact hc.memLp_of_hasCompactSupport (graphAtom_hasCompactSupport hs c hr v)

end N2Restriction
