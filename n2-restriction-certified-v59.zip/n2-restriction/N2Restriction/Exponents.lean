import N2Restriction.Basic

/-! Exact exponent calculations in (1.2), (6.6), (6.11)--(6.14),
(7.11), (7.16)--(7.17), and (9.1). All variables here are real, so
there are no truncated natural-number subtractions. -/

namespace N2Restriction

noncomputable def critical (k : ℝ) : ℝ := 2 * (k + 1) / k ^ 2
noncomputable def baseline (k : ℝ) : ℝ := 2 / (k - 1)
noncomputable def lower (k : ℝ) : ℝ := 2 / k
noncomputable def theta (k : ℝ) : ℝ := k / (k + 1)
noncomputable def cellular (k s t p : ℝ) : ℝ := s - p / 2 * (k * (s - 1) + t)
noncomputable def expected (n k : ℝ) : ℝ := 2 * (n + k) / (k * (n + k - 2))
noncomputable def sigma (k τ η : ℝ) : ℝ := theta k * (2 * τ + η)

lemma critical_pos {k : ℝ} (hk : 0 < k) : 0 < critical k := by
  unfold critical
  positivity

lemma lower_lt_critical {k : ℝ} (hk : 0 < k) : lower k < critical k := by
  unfold lower critical
  rw [div_lt_div_iff₀ hk (sq_pos_of_pos hk)]
  nlinarith

lemma critical_lt_baseline {k : ℝ} (hk : 1 < k) : critical k < baseline k := by
  unfold critical baseline
  rw [div_lt_div_iff₀ (sq_pos_of_pos (by linarith)) (by linarith)]
  nlinarith

lemma baseline_le_one {k : ℝ} (hk : 3 ≤ k) : baseline k ≤ 1 := by
  unfold baseline
  exact (div_le_one (by linarith)).2 (by linarith)

lemma exponent_range {k : ℝ} (hk : 3 ≤ k) :
    0 < lower k ∧ lower k < critical k ∧ critical k < baseline k ∧ baseline k ≤ 1 := by
  refine ⟨by unfold lower; positivity, lower_lt_critical (by linarith),
    critical_lt_baseline (by linarith), baseline_le_one hk⟩

lemma theta_range {k : ℝ} (hk : 0 < k) : 0 < theta k ∧ theta k < 1 := by
  unfold theta
  constructor
  · positivity
  · exact (div_lt_one (by linarith)).2 (by linarith)

lemma interpolation_identity {k : ℝ} (hk : 1 < k) :
    1 / critical k = theta k / baseline k + (1 - theta k) / lower k := by
  unfold critical theta baseline lower
  field_simp
  ring

lemma cancellation_identity {k : ℝ} (hk : 0 < k) :
    -(theta k) / 2 + (1 - theta k) * k / 2 = 0 := by
  unfold theta
  field_simp
  ring

lemma tangential_loss_identity {k τ η : ℝ} (hk : 0 < k) :
    theta k * (-1 / 2 + 2 * τ + η) + (1 - theta k) * k / 2 = sigma k τ η := by
  have h := cancellation_identity hk
  unfold sigma
  nlinarith

lemma cellular_top {k : ℝ} (hk : 0 < k) :
    cellular k (k + 2) 0 (critical k) = -1 / k := by
  unfold cellular critical
  field_simp
  ring

lemma cellular_next {k : ℝ} (hk : 0 < k) :
    cellular k (k + 1) 0 (critical k) = 0 := by
  unfold cellular critical
  field_simp
  ring

lemma cellular_lower_boundary {k s : ℝ} (hk : 0 < k) :
    cellular k s (k - s + 1) (critical k) = (s - k - 1) / k ^ 2 := by
  unfold cellular critical
  field_simp
  ring

lemma cellular_antitone_t {k s t₁ t₂ p : ℝ} (hp : 0 ≤ p) (ht : t₁ ≤ t₂) :
    cellular k s t₂ p ≤ cellular k s t₁ p := by
  unfold cellular
  nlinarith

lemma cellular_strict_p {k s t p₁ p₂ : ℝ}
    (hcoef : 0 < k * (s - 1) + t) (hp : p₁ < p₂) :
    cellular k s t p₂ < cellular k s t p₁ := by
  unfold cellular
  nlinarith

/-- Every nonterminal configuration needed in Section 6 contracts.
The top dimension is k+2; s,t are natural dimensions/counts. -/
theorem nonterminal_cellular_negative {k s t : ℕ} {p : ℝ}
    (hk : 3 ≤ k) (hs : 1 ≤ s) (hsmax : s ≤ k + 2)
    (ht : k + 1 ≤ s + t) (hp : critical k < p) :
    cellular k s t p < 0 := by
  have hkR : (0 : ℝ) < k := by exact_mod_cast (show 0 < k by omega)
  have hsR : (1 : ℝ) ≤ s := by exact_mod_cast hs
  have htR : (k : ℝ) + 1 ≤ s + t := by exact_mod_cast ht
  have ht0 : (0 : ℝ) ≤ t := Nat.cast_nonneg t
  have hc : 0 < (k : ℝ) * ((s : ℝ) - 1) + t := by
    by_cases h : s = 1
    · subst s
      simp only [Nat.cast_one, sub_self, mul_zero, zero_add]
      norm_num at htR
      linarith
    · have : (2 : ℝ) ≤ s := by exact_mod_cast (show 2 ≤ s by omega)
      nlinarith
  have hstrict := cellular_strict_p hc hp
  apply lt_of_lt_of_le hstrict
  by_cases htop : s = k + 2
  · subst s
    simp only [Nat.cast_add, Nat.cast_ofNat]
    exact (cellular_antitone_t (le_of_lt (critical_pos hkR)) ht0).trans
      (by rw [cellular_top hkR]; exact le_of_lt (div_neg_of_neg_of_pos (by norm_num) hkR))
  by_cases hnext : s = k + 1
  · subst s
    simp only [Nat.cast_add, Nat.cast_one]
    exact (cellular_antitone_t (le_of_lt (critical_pos hkR)) ht0).trans
      (by rw [cellular_next hkR])
  have hsle : s ≤ k := by omega
  have hsleR : (s : ℝ) ≤ k := by exact_mod_cast hsle
  have hmono := cellular_antitone_t (k := (k : ℝ)) (s := (s : ℝ))
    (p := critical k) (le_of_lt (critical_pos hkR)) (show (k : ℝ) - s + 1 ≤ t by linarith)
  apply hmono.trans
  rw [cellular_lower_boundary hkR]
  apply div_nonpos_of_nonpos_of_nonneg <;> nlinarith [sq_nonneg (k : ℝ)]

/-- The configurations not covered by the strict nonterminal count are
exactly s+t=k; this includes the feasibility condition (6.5). -/
lemma terminal_classification {k s t : ℕ} (hfeas : k ≤ s + t) :
    ¬ k + 1 ≤ s + t ↔ s + t = k := by omega

lemma expected_n2 {k : ℝ} (hk : 0 < k) : expected (k + 2) k = critical k := by
  unfold expected critical
  rw [show k + 2 + k - 2 = 2 * k by ring]
  field_simp [ne_of_gt hk]
  ring

lemma next_range_identity {n k : ℝ} (hk : 0 < k) (hn : 2 < n + k) :
    cellular k (k + 1) 0 (expected n k) = (n - k - 2) / (n + k - 2) := by
  have hden : n + k - 2 ≠ 0 := ne_of_gt (by linarith)
  unfold cellular expected
  field_simp [ne_of_gt hk, hden]
  ring

lemma next_range_obstruction {n k : ℝ} (hk : 0 < k) (hn : k + 2 < n) :
    0 < cellular k (k + 1) 0 (expected n k) := by
  rw [next_range_identity hk (by linarith)]
  apply div_pos <;> linarith

example : critical 3 = 8 / 9 := by norm_num [critical]
example : critical 4 = 5 / 8 := by norm_num [critical]
example : critical 5 = 12 / 25 := by norm_num [critical]
example : critical 6 = 7 / 18 := by norm_num [critical]
example : cellular 3 4 0 (expected 6 3) = 1 / 7 := by norm_num [cellular, expected]

/-- Choose the small parameters before fixing all geometric constants. -/
theorem choose_small_parameters {k ε : ℝ} (hk : 0 < k) (hε : 0 < ε) :
    ∃ τ η : ℝ, 0 < τ ∧ τ < 1 / 20 ∧ 0 < η ∧ sigma k τ η < ε / 2 := by
  let τ := min (1 / 40 : ℝ) (ε / 16)
  let η := ε / 8
  have hτ : 0 < τ := by dsimp [τ]; positivity
  have hτ1 : τ ≤ 1 / 40 := min_le_left _ _
  have hτ2 : τ ≤ ε / 16 := min_le_right _ _
  have hη : 0 < η := by dsimp [η]; positivity
  obtain ⟨hθ, hθ1⟩ := theta_range hk
  refine ⟨τ, η, hτ, by linarith, hη, ?_⟩
  unfold sigma
  have h := mul_lt_mul_of_pos_right hθ1 (show 0 < 2 * τ + η by linarith)
  dsimp [η] at *
  linarith

end N2Restriction
