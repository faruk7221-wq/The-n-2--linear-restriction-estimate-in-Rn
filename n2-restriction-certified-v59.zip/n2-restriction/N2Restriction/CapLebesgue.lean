import N2Restriction.CapNormalization

namespace N2Restriction
open MeasureTheory Set

/-- Undo the cap probability normalization exactly. -/
theorem capLebesgue_eq {d : ℕ} (t : Fin d → ℝ) (c : Ambient d) (r : ℝ) (hr : 0 < r) :
    volume.restrict (scaledCube t c r hr.ne') = ENNReal.ofReal (r ^ d) • capProbability t c r hr.ne' := by
  rw [capProbability_eq, smul_smul, ← ENNReal.ofReal_mul (by positivity)]
  rw [abs_of_pos (inv_pos.mpr (pow_pos hr d)), mul_inv_cancel₀ (pow_ne_zero d hr.ne')]
  simp

theorem capProbability_ae_eq {d : ℕ} (t : Fin d → ℝ) (c : Ambient d) (r : ℝ) (hr : 0 < r) :
    ae (capProbability t c r hr.ne') = ae (volume.restrict (scaledCube t c r hr.ne')) := by
  rw [capProbability_eq, Measure.ae_smul_measure_eq]
  exact ne_of_gt (ENNReal.ofReal_pos.mpr (abs_pos.mpr (inv_ne_zero (pow_ne_zero d hr.ne'))))

theorem cap_lebesgue_memLp {d : ℕ} (t : Fin d → ℝ) (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (capProbability t c r hr.ne')) :
    MemLp f 2 (volume.restrict (scaledCube t c r hr.ne')) := by
  rw [capLebesgue_eq t c r hr]
  exact (Lp.memLp f).smul_measure ENNReal.ofReal_ne_top

/-- Interpret a cap function using ordinary, unnormalized Lebesgue measure. -/
noncomputable def capLebesgueL2 {d : ℕ} (t : Fin d → ℝ) (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (capProbability t c r hr.ne')) :
    Lp ℂ 2 (volume.restrict (scaledCube t c r hr.ne')) :=
  (cap_lebesgue_memLp t c r hr f).toLp f

theorem capLebesgueL2_coe {d : ℕ} (t : Fin d → ℝ) (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (capProbability t c r hr.ne')) :
    capLebesgueL2 t c r hr f =ᵐ[volume.restrict (scaledCube t c r hr.ne')] f :=
  (cap_lebesgue_memLp t c r hr f).coeFn_toLp

theorem capLebesgueL2_norm {d : ℕ} (t : Fin d → ℝ) (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (capProbability t c r hr.ne')) :
    ‖capLebesgueL2 t c r hr f‖ = r ^ ((d : ℝ) / 2) * ‖f‖ := by
  rw [Lp.norm_def, eLpNorm_congr_ae (capLebesgueL2_coe t c r hr f), Lp.norm_def,
    capProbability_eLpNorm t c r hr, ← mul_assoc, ← Real.rpow_add hr]
  rw [show (d : ℝ) / 2 + -(d : ℝ) / 2 = 0 by ring, Real.rpow_zero, one_mul]

theorem capLebesgueL2_add {d : ℕ} (t : Fin d → ℝ) (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f g : Lp ℂ 2 (capProbability t c r hr.ne')) :
    capLebesgueL2 t c r hr (f + g) = capLebesgueL2 t c r hr f + capLebesgueL2 t c r hr g := by
  apply Lp.ext
  have hadd := Lp.coeFn_add f g
  rw [capProbability_ae_eq t c r hr] at hadd
  filter_upwards [capLebesgueL2_coe t c r hr (f + g), capLebesgueL2_coe t c r hr f,
    capLebesgueL2_coe t c r hr g, hadd,
    Lp.coeFn_add (capLebesgueL2 t c r hr f) (capLebesgueL2 t c r hr g)] with ξ h₁ h₂ h₃ h₄ h₅
  simp only [h₁, h₂, h₃, h₄, h₅, Pi.add_apply]

theorem capLebesgueL2_smul {d : ℕ} (t : Fin d → ℝ) (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (z : ℂ) (f : Lp ℂ 2 (capProbability t c r hr.ne')) :
    capLebesgueL2 t c r hr (z • f) = z • capLebesgueL2 t c r hr f := by
  apply Lp.ext
  have hsmul := Lp.coeFn_smul z f
  rw [capProbability_ae_eq t c r hr] at hsmul
  filter_upwards [capLebesgueL2_coe t c r hr (z • f), capLebesgueL2_coe t c r hr f,
    hsmul, Lp.coeFn_smul z (capLebesgueL2 t c r hr f)] with ξ h₁ h₂ h₃ h₄
  simp only [h₁, h₂, h₃, h₄, Pi.smul_apply]

/-- Bounded conversion to ordinary Lebesgue L2, retaining the actual input function. -/
noncomputable def capLebesgueOperator {d : ℕ} (t : Fin d → ℝ) (c : Ambient d) (r : ℝ) (hr : 0 < r) :
    Lp ℂ 2 (capProbability t c r hr.ne') →L[ℂ] Lp ℂ 2 (volume.restrict (scaledCube t c r hr.ne')) :=
  LinearMap.mkContinuous
    { toFun := capLebesgueL2 t c r hr
      map_add' := capLebesgueL2_add t c r hr
      map_smul' := capLebesgueL2_smul t c r hr }
    (r ^ ((d : ℝ) / 2)) (fun f => (capLebesgueL2_norm t c r hr f).le)

theorem capLebesgue_normalizedInput {d : ℕ} (t : Fin d → ℝ) (c : Ambient d) (r : ℝ) (hr : 0 < r)
    (f : Lp ℂ 2 (volume.restrict (scaledCube t c r hr.ne'))) :
    capLebesgueOperator t c r hr (normalizedCapInput t c r hr f) = f := by
  apply Lp.ext
  have h := normalizedCapInput_coe t c r hr f
  rw [capProbability_ae_eq t c r hr] at h
  exact (capLebesgueL2_coe t c r hr _).trans h

/-- Fourier reconstruction in ordinary Lebesgue L2, for the original cap input. -/
theorem cap_lebesgue_reconstruction {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : 0 < r) (f : Lp ℂ 2 (volume.restrict (scaledCube t c r hr.ne'))) :
    HasSum (fun ν => capFourierCoeff t c r hr.ne' (normalizedCapInput t c r hr f) ν •
      capLebesgueOperator t c r hr (capFourierAtom t c r hr.ne' ν)) f := by
  simpa only [capLebesgue_normalizedInput] using
    cap_fourier_synthesis t c r hr.ne' (capLebesgueOperator t c r hr) (normalizedCapInput t c r hr f)

/-- The unnormalized Fourier mode has the square-root-volume norm of its cube. -/
theorem cap_lebesgue_atom_norm {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : 0 < r) (ν : Fin d → ℤ) :
    ‖capLebesgueOperator t c r hr (capFourierAtom t c r hr.ne' ν)‖ = r ^ ((d : ℝ) / 2) := by
  change ‖capLebesgueL2 t c r hr _‖ = _
  rw [capLebesgueL2_norm, cap_fourier_atom_norm, mul_one]

/-- Normalize a Fourier mode to unit norm for ordinary Lebesgue measure. -/
theorem cap_lebesgue_normalized_atom_norm {d : ℕ} (t : Fin d → ℝ) (c : Ambient d)
    (r : ℝ) (hr : 0 < r) (ν : Fin d → ℤ) :
    ‖((r ^ (-(d : ℝ) / 2) : ℝ) : ℂ) •
      capLebesgueOperator t c r hr (capFourierAtom t c r hr.ne' ν)‖ = 1 := by
  rw [norm_smul, Complex.norm_real, Real.norm_eq_abs,
    abs_of_nonneg (Real.rpow_nonneg hr.le _), cap_lebesgue_atom_norm, ← Real.rpow_add hr]
  rw [show -(d : ℝ) / 2 + (d : ℝ) / 2 = 0 by ring, Real.rpow_zero]

end N2Restriction
