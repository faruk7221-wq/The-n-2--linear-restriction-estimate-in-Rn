import N2Restriction.CapLebesgue

namespace N2Restriction
open MeasureTheory Set
variable {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω) (s : Set Ω) (hs : MeasurableSet s)

/-- Zero extension from a measurable frequency domain. -/
noncomputable def zeroExtendL2 (f : Lp ℂ 2 (μ.restrict s)) : Lp ℂ 2 μ :=
  ((memLp_indicator_iff_restrict hs).mpr (Lp.memLp f)).toLp (s.indicator f)

theorem zeroExtendL2_coe (f : Lp ℂ 2 (μ.restrict s)) :
    zeroExtendL2 μ s hs f =ᵐ[μ] s.indicator f := MemLp.coeFn_toLp _

theorem zeroExtendL2_norm (f : Lp ℂ 2 (μ.restrict s)) : ‖zeroExtendL2 μ s hs f‖ = ‖f‖ := by
  rw [Lp.norm_def, eLpNorm_congr_ae (zeroExtendL2_coe μ s hs f),
    eLpNorm_indicator_eq_eLpNorm_restrict hs, Lp.norm_def]

theorem zeroExtendL2_add (f g : Lp ℂ 2 (μ.restrict s)) :
    zeroExtendL2 μ s hs (f + g) = zeroExtendL2 μ s hs f + zeroExtendL2 μ s hs g := by
  apply Lp.ext
  have hadd := (ae_restrict_iff' hs).mp (Lp.coeFn_add f g)
  filter_upwards [zeroExtendL2_coe μ s hs (f + g), zeroExtendL2_coe μ s hs f,
    zeroExtendL2_coe μ s hs g, hadd,
    Lp.coeFn_add (zeroExtendL2 μ s hs f) (zeroExtendL2 μ s hs g)] with x h₁ h₂ h₃ h₄ h₅
  rw [h₅, Pi.add_apply, h₁, h₂, h₃]
  by_cases hx : x ∈ s
  · simp only [indicator_of_mem hx, h₄ hx, Pi.add_apply]
  · simp only [indicator_of_notMem hx, add_zero]

theorem zeroExtendL2_smul (z : ℂ) (f : Lp ℂ 2 (μ.restrict s)) :
    zeroExtendL2 μ s hs (z • f) = z • zeroExtendL2 μ s hs f := by
  apply Lp.ext
  have hsmul := (ae_restrict_iff' hs).mp (Lp.coeFn_smul z f)
  filter_upwards [zeroExtendL2_coe μ s hs (z • f), zeroExtendL2_coe μ s hs f,
    hsmul, Lp.coeFn_smul z (zeroExtendL2 μ s hs f)] with x h₁ h₂ h₃ h₄
  rw [h₄, Pi.smul_apply, h₁, h₂]
  by_cases hx : x ∈ s
  · simp only [indicator_of_mem hx, h₃ hx, Pi.smul_apply]
  · simp only [indicator_of_notMem hx, smul_zero]

/-- Zero extension is a linear isometry, so it preserves L2 convergence exactly. -/
noncomputable def zeroExtendIsometry : Lp ℂ 2 (μ.restrict s) →ₗᵢ[ℂ] Lp ℂ 2 μ where
  toFun := zeroExtendL2 μ s hs
  map_add' := zeroExtendL2_add μ s hs
  map_smul' := zeroExtendL2_smul μ s hs
  norm_map' := zeroExtendL2_norm μ s hs

theorem zeroExtendL2_vanishes (f : Lp ℂ 2 (μ.restrict s)) :
    ∀ᵐ x ∂μ, x ∉ s → zeroExtendL2 μ s hs f x = 0 := by
  filter_upwards [zeroExtendL2_coe μ s hs f] with x hx hxs
  rw [hx, indicator_of_notMem hxs]

end N2Restriction
