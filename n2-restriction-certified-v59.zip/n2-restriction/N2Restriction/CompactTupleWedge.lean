import N2Restriction.NearbyWedge

/-! A compact parameter space for the nearby-plane wedge when the frequency
tuple varies over the compact supports of all patches. -/

namespace N2Restriction

set_option maxHeartbeats 800000

/-- The compact family of supported frequency tuples. -/
def supportedTupleSet {k : ℕ} (S : Fin k → SmoothPatch (k + 2)) :
    Set (Fin k → Ambient (k + 2)) :=
  {z | ∀ j, z j ∈ (S j).support}

theorem isCompact_supportedTupleSet {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) : IsCompact (supportedTupleSet S) := by
  exact isCompact_pi_infinite fun j => (S j).compact_support

/-- Supported tuples equipped with a frame for their common tangent and a
frame for a nearby plane. -/
def tupleWedgeBaseSet {k : ℕ} (S : Fin k → SmoothPatch (k + 2)) :
    Set ((Fin k → Ambient (k + 2)) ×
      ((Ambient (k + 2) × Ambient (k + 2)) ×
        (Ambient (k + 2) × Ambient (k + 2)))) :=
  supportedTupleSet S ×ˢ
    (orthonormalPairSet (k + 2) ×ˢ orthonormalPairSet (k + 2))

abbrev TupleWedgeBase {k : ℕ} (S : Fin k → SmoothPatch (k + 2)) :=
  {r : (Fin k → Ambient (k + 2)) ×
    ((Ambient (k + 2) × Ambient (k + 2)) ×
      (Ambient (k + 2) × Ambient (k + 2))) // r ∈ tupleWedgeBaseSet S}

theorem isCompact_tupleWedgeBaseSet {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) : IsCompact (tupleWedgeBaseSet S) := by
  exact (isCompact_supportedTupleSet S).prod
    ((isCompact_orthonormalPairSet (k + 2)).prod
      (isCompact_orthonormalPairSet (k + 2)))

/-- Closed frame conditions for a supported tuple: the first pair is tangent
to every normal, the second pair is tangent to the selected normal, and the
two frame planes obey the curvature-scaled gap. -/
def tupleWedgeAdmissible {k : ℕ} (S : Fin k → SmoothPatch (k + 2))
    (i : Fin k) (κ : ℝ)
    (r : (Fin k → Ambient (k + 2)) ×
      ((Ambient (k + 2) × Ambient (k + 2)) ×
        (Ambient (k + 2) × Ambient (k + 2)))) : Prop :=
  (∀ j, inner ℝ ((S j).normal (r.1 j)) r.2.1.1 = 0) ∧
  (∀ j, inner ℝ ((S j).normal (r.1 j)) r.2.1.2 = 0) ∧
  inner ℝ ((S i).normal (r.1 i)) r.2.2.1 = 0 ∧
  inner ℝ ((S i).normal (r.1 i)) r.2.2.2 = 0 ∧
  ‖pairProjection r.2.1 - pairProjection r.2.2‖ *
    ‖(S i).shape (r.1 i)‖ ≤ κ / 2

def tupleNearbyWedgeFrameSet {k : ℕ} (S : Fin k → SmoothPatch (k + 2))
    (i : Fin k) (κ : ℝ) : Set (TupleWedgeBase S) :=
  {r | tupleWedgeAdmissible S i κ r.1}

theorem isClosed_tupleNearbyWedgeFrameSet {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) (i : Fin k) (κ : ℝ) :
    IsClosed (tupleNearbyWedgeFrameSet S i κ) := by
  let B := TupleWedgeBase S
  let z : B → Fin k → Ambient (k + 2) := fun r => r.1.1
  let p : B → Ambient (k + 2) × Ambient (k + 2) := fun r => r.1.2.1
  let q : B → Ambient (k + 2) × Ambient (k + 2) := fun r => r.1.2.2
  have hz : Continuous z := continuous_fst.comp continuous_subtype_val
  have hp : Continuous p := continuous_fst.comp (continuous_snd.comp continuous_subtype_val)
  have hq : Continuous q := continuous_snd.comp (continuous_snd.comp continuous_subtype_val)
  have hzj : ∀ j, Continuous (fun r : B => z r j) := fun j =>
    (continuous_apply j).comp hz
  have hNj : ∀ j, Continuous (fun r : B => (S j).normal (z r j)) := by
    intro j
    have hNOn : ContinuousOn (S j).normal (S j).support :=
      (S j).smooth_normal.continuousOn.mono
        (fun x hx => (S j).support_inside hx)
    exact hNOn.comp_continuous (hzj j) (fun r => r.2.1 j)
  have hNi : Continuous (fun r : B => (S i).normal (z r i)) := hNj i
  have hp₁ : Continuous (fun r : B => (p r).1) := continuous_fst.comp hp
  have hp₂ : Continuous (fun r : B => (p r).2) := continuous_snd.comp hp
  have hq₁ : Continuous (fun r : B => (q r).1) := continuous_fst.comp hq
  have hq₂ : Continuous (fun r : B => (q r).2) := continuous_snd.comp hq
  have hTan₁ : IsClosed {r : B | ∀ j,
      inner ℝ ((S j).normal (z r j)) (p r).1 = 0} := by
    rw [show {r : B | ∀ j, inner ℝ ((S j).normal (z r j)) (p r).1 = 0} =
      ⋂ j, {r : B | inner ℝ ((S j).normal (z r j)) (p r).1 = 0} by
        ext r
        simp]
    apply isClosed_iInter
    intro j
    exact isClosed_eq ((hNj j).inner hp₁) continuous_const
  have hTan₂ : IsClosed {r : B | ∀ j,
      inner ℝ ((S j).normal (z r j)) (p r).2 = 0} := by
    rw [show {r : B | ∀ j, inner ℝ ((S j).normal (z r j)) (p r).2 = 0} =
      ⋂ j, {r : B | inner ℝ ((S j).normal (z r j)) (p r).2 = 0} by
        ext r
        simp]
    apply isClosed_iInter
    intro j
    exact isClosed_eq ((hNj j).inner hp₂) continuous_const
  have hQ₁ : IsClosed {r : B |
      inner ℝ ((S i).normal (z r i)) (q r).1 = 0} :=
    isClosed_eq (hNi.inner hq₁) continuous_const
  have hQ₂ : IsClosed {r : B |
      inner ℝ ((S i).normal (z r i)) (q r).2 = 0} :=
    isClosed_eq (hNi.inner hq₂) continuous_const
  have hShapeOn : ContinuousOn (S i).shape (S i).support := by
    unfold SmoothPatch.shape
    exact (S i).smooth_normal.continuousOn_fderiv_of_isOpen
      (S i).open_neighborhood (by simp) |>.neg |>.mono
        (fun x hx => (S i).support_inside hx)
  have hShape : Continuous (fun r : B => (S i).shape (z r i)) :=
    hShapeOn.comp_continuous (hzj i) (fun r => r.2.1 i)
  have hPW : Continuous (fun r : B => pairProjection (p r)) :=
    (continuous_pairProjection (k + 2)).comp hp
  have hPQ : Continuous (fun r : B => pairProjection (q r)) :=
    (continuous_pairProjection (k + 2)).comp hq
  have hGap : Continuous (fun r : B =>
      ‖pairProjection (p r) - pairProjection (q r)‖ *
        ‖(S i).shape (z r i)‖) := (hPW.sub hPQ).norm.mul hShape.norm
  change IsClosed
    ({r : B | ∀ j, inner ℝ ((S j).normal (z r j)) (p r).1 = 0} ∩
      ({r : B | ∀ j, inner ℝ ((S j).normal (z r j)) (p r).2 = 0} ∩
        ({r : B | inner ℝ ((S i).normal (z r i)) (q r).1 = 0} ∩
          ({r : B | inner ℝ ((S i).normal (z r i)) (q r).2 = 0} ∩
            {r : B | ‖pairProjection (p r) - pairProjection (q r)‖ *
              ‖(S i).shape (z r i)‖ ≤ κ / 2}))))
  exact hTan₁.inter (hTan₂.inter (hQ₁.inter (hQ₂.inter
    (isClosed_le hGap continuous_const))))

theorem isCompact_tupleNearbyWedgeFrameSet {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) (i : Fin k) (κ : ℝ) :
    IsCompact (tupleNearbyWedgeFrameSet S i κ) := by
  letI : CompactSpace (TupleWedgeBase S) :=
    isCompact_iff_compactSpace.mp (isCompact_tupleWedgeBaseSet S)
  exact (isClosed_tupleNearbyWedgeFrameSet S i κ).isCompact

noncomputable def tupleNearbyWedgeVectors {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) (i : Fin k)
    (r : TupleWedgeBase S) : Sum (Fin k) (Fin 2) → Ambient (k + 2) :=
  nearbyWedgeVectors S r.1.1 i r.1.2.2

theorem continuous_tupleNearbyWedgeVectors {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) (i : Fin k) :
    Continuous (fun r : TupleWedgeBase S => tupleNearbyWedgeVectors S i r) := by
  let B := TupleWedgeBase S
  let z : B → Fin k → Ambient (k + 2) := fun r => r.1.1
  let q : B → Ambient (k + 2) × Ambient (k + 2) := fun r => r.1.2.2
  have hz : Continuous z := continuous_fst.comp continuous_subtype_val
  have hzj : ∀ j, Continuous (fun r : B => z r j) := fun j =>
    (continuous_apply j).comp hz
  have hNj : ∀ j, Continuous (fun r : B => (S j).normal (z r j)) := by
    intro j
    have hNOn : ContinuousOn (S j).normal (S j).support :=
      (S j).smooth_normal.continuousOn.mono
        (fun x hx => (S j).support_inside hx)
    exact hNOn.comp_continuous (hzj j) (fun r => r.2.1 j)
  have hShapeOn : ContinuousOn (S i).shape (S i).support := by
    unfold SmoothPatch.shape
    exact (S i).smooth_normal.continuousOn_fderiv_of_isOpen
      (S i).open_neighborhood (by simp) |>.neg |>.mono
        (fun x hx => (S i).support_inside hx)
  have hShape : Continuous (fun r : B => (S i).shape (z r i)) :=
    hShapeOn.comp_continuous (hzj i) (fun r => r.2.1 i)
  have hq : Continuous q := continuous_snd.comp (continuous_snd.comp continuous_subtype_val)
  have hq₁ : Continuous (fun r : B => (q r).1) := continuous_fst.comp hq
  have hq₂ : Continuous (fun r : B => (q r).2) := continuous_snd.comp hq
  have hSq₁ : Continuous (fun r : B => (S i).shape (z r i) ((q r).1)) :=
    hShape.clm_apply hq₁
  have hSq₂ : Continuous (fun r : B => (S i).shape (z r i) ((q r).2)) :=
    hShape.clm_apply hq₂
  change Continuous (fun r : B =>
    nearbyWedgeVectors S (z r) i (q r))
  refine continuous_pi fun a => ?_
  cases a with
  | inl j => simpa [nearbyWedgeVectors] using hNj j
  | inr j =>
    fin_cases j
    · simpa [nearbyWedgeVectors] using hSq₁
    · simpa [nearbyWedgeVectors] using hSq₂

theorem pairPlane_eq_commonTangent_of_tuple_frames {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) {ν κ : ℝ}
    (hgeo : GeometricHypotheses S ν κ)
    (z : Fin k → Ambient (k + 2))
    (hz : ∀ j, z j ∈ (S j).extendedSurface)
    (p : Ambient (k + 2) × Ambient (k + 2))
    (hp : p ∈ orthonormalPairSet (k + 2))
    (ht₁ : ∀ j, inner ℝ ((S j).normal (z j)) p.1 = 0)
    (ht₂ : ∀ j, inner ℝ ((S j).normal (z j)) p.2 = 0) :
    pairPlane p = commonTangent (fun j => (S j).normal (z j)) := by
  let N : Fin k → Ambient (k + 2) := fun j => (S j).normal (z j)
  let W := commonTangent N
  have hp₁ : p.1 ∈ W := mem_commonTangent_of_normal_orthogonality N p.1 ht₁
  have hp₂ : p.2 ∈ W := mem_commonTangent_of_normal_orthogonality N p.2 ht₂
  have hle : pairPlane p ≤ W := by
    change Submodule.span ℝ ({p.1, p.2} : Set (Ambient (k + 2))) ≤ W
    apply Submodule.span_le.mpr
    intro x hx
    simp only [Set.mem_insert_iff, Set.mem_singleton_iff] at hx
    rcases hx with rfl | rfl
    · exact hp₁
    · exact hp₂
  apply Submodule.eq_of_le_of_finrank_eq hle
  rw [pairPlane_finrank_two hp, geometric_commonTangent_two S hgeo z hz]

private theorem tupleNearbyWedgeVectors_independent {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) {ν κ : ℝ}
    (hgeo : GeometricHypotheses S ν κ) (i : Fin k)
    (r : TupleWedgeBase S) (hr : r ∈ tupleNearbyWedgeFrameSet S i κ) :
    LinearIndependent ℝ (tupleNearbyWedgeVectors S i r) := by
  let z := r.1.1
  let p := r.1.2.1
  let q := r.1.2.2
  have hzSupport : ∀ j, z j ∈ (S j).support := r.2.1
  have hz : ∀ j, z j ∈ (S j).extendedSurface := fun j =>
    SmoothPatch.support_in_extendedSurface (S j) (hzSupport j)
  have hp : p ∈ orthonormalPairSet (k + 2) := r.2.2.1
  have hq : q ∈ orthonormalPairSet (k + 2) := r.2.2.2
  have hadm := hr
  change tupleWedgeAdmissible S i κ (z, (p, q)) at hadm
  have hplane := pairPlane_eq_commonTangent_of_tuple_frames S hgeo z hz p hp
    hadm.1 hadm.2.1
  have hproj : pairProjection p =
      (commonTangent (fun j => (S j).normal (z j))).starProjection := by
    rw [pairProjection_eq_planeProjection hp, hplane]
  have hgap :
      ‖(commonTangent (fun j => (S j).normal (z j))).starProjection -
        pairProjection q‖ * ‖(S i).shape (z i)‖ ≤ κ / 2 := by
    rw [← hproj]
    exact hadm.2.2.2.2
  apply geometric_nearby_frame_wedge_independent S hgeo z hz i q hq
  · exact hadm.2.2.1
  · exact hadm.2.2.2.1
  · exact hgap

/-- One positive Gram lower bound works simultaneously for every supported
frequency tuple and every admissible nearby-plane frame, for each selected
surface index. -/
theorem geometric_nearby_frame_wedge_uniform_over_supported_tuples {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) {ν κ : ℝ}
    (hgeo : GeometricHypotheses S ν κ) :
    ∀ i, ∃ c : ℝ, 0 < c ∧ ∀ z : Fin k → Ambient (k + 2),
      (∀ j, z j ∈ (S j).support) → ∀ q ∈ nearbyWedgeFrameSet S z i κ,
        c ≤ Matrix.det (Matrix.gram ℝ (nearbyWedgeVectors S z i q)) := by
  intro i
  obtain ⟨c, hc, hbound⟩ := compact_uniform_gram_det_lower_bound
    (isCompact_tupleNearbyWedgeFrameSet S i κ)
    (tupleNearbyWedgeVectors S i)
    (continuous_tupleNearbyWedgeVectors S i)
    (tupleNearbyWedgeVectors_independent S hgeo i)
  refine ⟨c, hc, fun z hz q hq => ?_⟩
  let N : Fin k → Ambient (k + 2) := fun j => (S j).normal (z j)
  let W := commonTangent N
  have hzExt : ∀ j, z j ∈ (S j).extendedSurface := fun j =>
    SmoothPatch.support_in_extendedSurface (S j) (hz j)
  have hdim : Module.finrank ℝ W = 2 := geometric_commonTangent_two S hgeo z hzExt
  obtain ⟨p, hp, hspan⟩ := exists_orthonormalPair_for_twoPlane W hdim
  have hp₁ : p.1 ∈ W := by
    rw [← hspan]
    exact Submodule.subset_span (Set.mem_insert _ _)
  have hp₂ : p.2 ∈ W := by
    rw [← hspan]
    exact Submodule.subset_span (Set.mem_insert_of_mem _ (Set.mem_singleton _))
  have hproj : pairProjection p = W.starProjection := by
    rw [pairProjection_eq_planeProjection hp, hspan]
  let r : TupleWedgeBase S := ⟨(z, (p, q)), ⟨hz, hp, hq.1⟩⟩
  have hr : r ∈ tupleNearbyWedgeFrameSet S i κ := by
    refine ⟨?_, ?_, hq.2.1, hq.2.2.1, ?_⟩
    · exact fun j => commonTangent_orthogonal N ⟨p.1, hp₁⟩ j
    · exact fun j => commonTangent_orthogonal N ⟨p.2, hp₂⟩ j
    · rw [hproj]
      exact hq.2.2.2
  have h := hbound r hr
  simpa [tupleNearbyWedgeVectors, r] using h

/-- Since there are finitely many surface indices, one constant also works
for all selected indices at once. -/
theorem geometric_nearby_frame_wedge_uniform_over_supported_tuples_all_indices
    {k : ℕ} (hk : 0 < k) (S : Fin k → SmoothPatch (k + 2)) {ν κ : ℝ}
    (hgeo : GeometricHypotheses S ν κ) :
    ∃ c : ℝ, 0 < c ∧ ∀ i z,
      (∀ j, z j ∈ (S j).support) → ∀ q ∈ nearbyWedgeFrameSet S z i κ,
        c ≤ Matrix.det (Matrix.gram ℝ (nearbyWedgeVectors S z i q)) := by
  classical
  have hnon : (Finset.univ : Finset (Fin k)).Nonempty := by
    refine ⟨⟨0, ?_⟩, Finset.mem_univ _⟩
    omega
  choose c hc hbound using fun i =>
    geometric_nearby_frame_wedge_uniform_over_supported_tuples S hgeo i
  let c₀ : ℝ := Finset.univ.inf' hnon c
  have hc₀ : 0 < c₀ := by
    exact (Finset.lt_inf'_iff _).2 (fun i hi => hc i)
  refine ⟨c₀, hc₀, fun i z hz q hq => ?_⟩
  exact (Finset.inf'_le _ (Finset.mem_univ i)).trans (hbound i z hz q hq)

/-- For a finite collection of compact patches, every fixed derivative order
of the normal and defining functions, as well as the shape operators, has a
bound common to all patches and their supported frequencies. -/
theorem uniform_supported_patch_geometry_bounds {k : ℕ}
    (S : Fin k → SmoothPatch (k + 2)) :
    (∀ order : ℕ, ∃ M : ℝ, 0 ≤ M ∧ ∀ i z, z ∈ (S i).support →
      ‖iteratedFDeriv ℝ order (S i).normal z‖ ≤ M) ∧
    (∀ order : ℕ, ∃ D : ℝ, 0 ≤ D ∧ ∀ i z, z ∈ (S i).support →
      ‖iteratedFDeriv ℝ order (S i).defining z‖ ≤ D) ∧
    ∃ A : ℝ, 0 ≤ A ∧ ∀ i z, z ∈ (S i).support → ‖(S i).shape z‖ ≤ A := by
  constructor
  · intro order
    choose M hM hbound using fun i =>
      (S i).iterated_normal_derivative_bound_on_compact (S i).compact_support
        (fun z hz => (S i).support_inside hz)
    let Msum : ℝ := ∑ i : Fin k, M i
    refine ⟨Msum, ?_, fun i z hz => ?_⟩
    · exact Finset.sum_nonneg fun i hi => hM i
    · calc
        ‖iteratedFDeriv ℝ order (S i).normal z‖ ≤ M i := hbound i z hz
        _ ≤ Msum := by
          exact Finset.single_le_sum (f := M) (fun j hj => hM j)
            (Finset.mem_univ i)
  · constructor
    · intro order
      choose D hD hbound using fun i =>
        (S i).iterated_defining_derivative_bound_on_compact
          (S i).compact_support (fun z hz => (S i).support_inside hz)
      let Dsum : ℝ := ∑ i : Fin k, D i
      refine ⟨Dsum, ?_, fun i z hz => ?_⟩
      · exact Finset.sum_nonneg fun i hi => hD i
      · calc
          ‖iteratedFDeriv ℝ order (S i).defining z‖ ≤ D i := hbound i z hz
          _ ≤ Dsum := by
            exact Finset.single_le_sum (f := D) (fun j hj => hD j)
              (Finset.mem_univ i)
    · choose A hA hbound using fun i =>
        (S i).shape_bound_on_compact (S i).compact_support
          (fun z hz => (S i).support_inside hz)
      let Asum : ℝ := ∑ i : Fin k, A i
      refine ⟨Asum, ?_, fun i z hz => ?_⟩
      · exact Finset.sum_nonneg fun i hi => hA i
      · calc
          ‖(S i).shape z‖ ≤ A i := hbound i z hz
          _ ≤ Asum := by
            exact Finset.single_le_sum (f := A) (fun j hj => hA j)
              (Finset.mem_univ i)

private theorem exists_supported_normalScale_lower_bound {n : ℕ}
    (S : SmoothPatch n) :
    ∃ δ : ℝ, 0 < δ ∧ ∀ z ∈ S.support, δ ≤ S.normalScale z := by
  by_cases hne : S.support.Nonempty
  · have hcont : ContinuousOn S.normalScale S.support := by
      intro z hz
      exact (S.differentiableAt_normalScale (S.support_inside hz)).continuousAt.continuousWithinAt
    obtain ⟨z₀, hz₀, hmin⟩ := S.compact_support.exists_isMinOn hne hcont
    refine ⟨S.normalScale z₀, S.positive_normalScale z₀ (S.support_inside hz₀), ?_⟩
    intro z hz
    exact (isMinOn_iff.mp hmin) z hz
  · refine ⟨1, by norm_num, ?_⟩
    intro z hz
    exact False.elim (hne ⟨z, hz⟩)

/-- Positivity of the defining differentials has one common quantitative
lower bound over all supported frequencies and all patches in the finite
tuple. -/
theorem uniform_supported_normal_scale_lower_bound {k : ℕ}
    (hk : 0 < k) (S : Fin k → SmoothPatch (k + 2)) :
    ∃ δ : ℝ, 0 < δ ∧ ∀ i z, z ∈ (S i).support →
      δ ≤ (S i).normalScale z := by
  classical
  have hnon : (Finset.univ : Finset (Fin k)).Nonempty := by
    refine ⟨⟨0, ?_⟩, Finset.mem_univ _⟩
    omega
  choose δ hδ hbound using fun i => exists_supported_normalScale_lower_bound (S i)
  let δ₀ : ℝ := Finset.univ.inf' hnon δ
  have hδ₀ : 0 < δ₀ := (Finset.lt_inf'_iff _).2 (fun i hi => hδ i)
  refine ⟨δ₀, hδ₀, fun i z hz => ?_⟩
  exact (Finset.inf'_le _ (Finset.mem_univ i)).trans (hbound i z hz)

/-- The defining functions have a common positive differential lower bound on
all supported patches, expressed directly in operator norm. -/
theorem uniform_supported_defining_differential_lower_bound {k : ℕ}
    (hk : 0 < k) (S : Fin k → SmoothPatch (k + 2)) :
    ∃ δ : ℝ, 0 < δ ∧ ∀ i z, z ∈ (S i).support →
      δ ≤ ‖fderiv ℝ (S i).defining z‖ := by
  obtain ⟨δ, hδ, hscale⟩ := uniform_supported_normal_scale_lower_bound hk S
  refine ⟨δ, hδ, fun i z hz => ?_⟩
  rw [(S i).norm_fderiv_defining_eq_normalScale ((S i).support_inside hz)]
  exact hscale i z hz

end N2Restriction
