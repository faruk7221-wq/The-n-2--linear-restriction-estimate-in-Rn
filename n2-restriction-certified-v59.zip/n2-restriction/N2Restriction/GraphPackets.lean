import N2Restriction.OscillatoryDecay
import N2Restriction.ScaledCutoff

namespace N2Restriction
open MeasureTheory

/-- Euclidean graph coordinates, with the height coordinate first. -/
def graphPoint {d : ℕ} (u : Ambient d) (t : ℝ) : Ambient (d + 1) :=
  WithLp.toLp 2 (Fin.cons t u)

theorem graphPoint_inner {d : ℕ} (u ξ : Ambient d) (t s : ℝ) :
    inner ℝ (graphPoint u t) (graphPoint ξ s) = inner ℝ u ξ + t * s := by
  simp [graphPoint, PiLp.inner_apply, Fin.sum_univ_succ, mul_comm, add_comm]

/-- Translation and dilation of the actual Lebesgue integral, with its Jacobian. -/
theorem integral_affine_rescale {d : ℕ} (f : Ambient d → ℂ) (c : Ambient d)
    {r : ℝ} (hr : 0 < r) :
    (∫ ξ, f ξ) = (r ^ d : ℂ) * ∫ η, f (c + r • η) := by
  have ht := Measure.integral_comp_smul_of_nonneg (volume : Measure (Ambient d))
    (fun ξ => f (c + ξ)) r (hR := hr.le)
  rw [integral_add_left_eq_self] at ht
  simp only [Ambient, finrank_euclideanSpace, Fintype.card_fin] at ht
  rw [ht, Complex.real_smul, ← Complex.ofReal_pow]
  rw [← mul_assoc, ← Complex.ofReal_mul, mul_inv_cancel₀ (pow_ne_zero _ hr.ne'),
    Complex.ofReal_one, one_mul]

/-- A normalized graph packet before any tube estimate. Its phase is exactly
x'·ξ + t φ(ξ) + v·ξ, and its frequency cutoff is centered at c with scale r. -/
noncomputable def graphPacket {d : ℕ} (φ : Ambient d → ℝ) (χ : Ambient d → ℂ)
    (c : Ambient d) (r : ℝ) (v u : Ambient d) (t : ℝ) : ℂ :=
  (r ^ (-(d : ℝ) / 2) : ℝ) *
    oscillatoryIntegral (fun ξ => t * φ ξ) (fun ξ => χ (r⁻¹ • (ξ - c))) (u + v)

/-- These graph packets are evaluations of the project's original extension
operator, using coordinate Lebesgue measure and a modulated cutoff input. -/
theorem graphPacket_eq_extension {d : ℕ} (φ : Ambient d → ℝ) (χ : Ambient d → ℂ)
    (c : Ambient d) (r : ℝ) (v u : Ambient d) (t : ℝ) :
    graphPacket φ χ c r v u t = (r ^ (-(d : ℝ) / 2) : ℝ) *
      extension volume (fun ξ => graphPoint ξ (φ ξ))
        (fun ξ => Complex.exp ((inner ℝ v ξ : ℂ) * Complex.I) * χ (r⁻¹ • (ξ - c)))
        (graphPoint u t) := by
  unfold graphPacket extension oscillatoryIntegral
  congr 1
  apply integral_congr_ae
  filter_upwards with ξ
  rw [graphPoint_inner, inner_add_left]
  have he : inner ℝ u ξ + inner ℝ v ξ + t * φ ξ =
      (inner ℝ u ξ + t * φ ξ) + inner ℝ v ξ := by ring
  rw [he]
  simp only [Complex.ofReal_add, add_mul, Complex.exp_add, mul_assoc]

/-- Exact rescaled phase identity. The remainder identity is explicit; no
unproved uniform Taylor bound is hidden in this statement. -/
theorem graphPacket_rescale {d : ℕ} (φ : Ambient d → ℝ) (χ : Ambient d → ℂ)
    (c : Ambient d) {r : ℝ} (hr : 0 < r) (g : Ambient d) (ψ : Ambient d → ℝ)
    (hφ : ∀ η, φ (c + r • η) = φ c + r * inner ℝ g η + r ^ 2 * ψ η)
    (v u : Ambient d) (t : ℝ) :
    graphPacket φ χ c r v u t =
      (r ^ ((d : ℝ) / 2) : ℝ) *
        Complex.exp (((inner ℝ (u + v) c + t * φ c : ℝ) : ℂ) * Complex.I) *
        oscillatoryIntegral (fun η => (t * r ^ 2) * ψ η) χ (r • (u + v + t • g)) := by
  have hscale : r ^ (-(d : ℝ) / 2) * r ^ d = r ^ ((d : ℝ) / 2) := by
    rw [← Real.rpow_natCast, ← Real.rpow_add hr]
    congr 1
    ring
  have hphase (η : Ambient d) :
      inner ℝ (u + v) (c + r • η) + t * φ (c + r • η) =
      (inner ℝ (u + v) c + t * φ c) +
        (inner ℝ (r • (u + v + t • g)) η + (t * r ^ 2) * ψ η) := by
    rw [hφ]
    simp only [inner_add_left, inner_add_right, inner_smul_left, inner_smul_right,
      RCLike.conj_to_real]
    ring
  unfold graphPacket oscillatoryIntegral
  rw [integral_affine_rescale _ c hr]
  have hkernel : (fun η : Ambient d =>
      Complex.exp (((inner ℝ (u + v) (c + r • η) + t * φ (c + r • η) : ℝ) : ℂ) * Complex.I) *
        χ (r⁻¹ • (c + r • η - c))) =
      fun η => Complex.exp (((inner ℝ (u + v) c + t * φ c : ℝ) : ℂ) * Complex.I) *
        (Complex.exp (((inner ℝ (r • (u + v + t • g)) η + (t * r ^ 2) * ψ η : ℝ) : ℂ) *
          Complex.I) * χ η) := by
    funext η
    rw [hphase]
    simp only [add_sub_cancel_left, inv_smul_smul₀ hr.ne', Complex.ofReal_add,
      add_mul, Complex.exp_add, mul_assoc]
  rw [hkernel, integral_const_mul]
  push_cast [← hscale]
  ring

/-- The constant phase disappears in the exact packet norm formula. -/
theorem norm_graphPacket_rescale {d : ℕ} (φ : Ambient d → ℝ) (χ : Ambient d → ℂ)
    (c : Ambient d) {r : ℝ} (hr : 0 < r) (g : Ambient d) (ψ : Ambient d → ℝ)
    (hφ : ∀ η, φ (c + r • η) = φ c + r * inner ℝ g η + r ^ 2 * ψ η)
    (v u : Ambient d) (t : ℝ) :
    ‖graphPacket φ χ c r v u t‖ = r ^ ((d : ℝ) / 2) *
      ‖oscillatoryIntegral (fun η => (t * r ^ 2) * ψ η) χ (r • (u + v + t • g))‖ := by
  rw [graphPacket_rescale φ χ c hr g ψ hφ v u t]
  simp only [norm_mul, Complex.norm_exp_ofReal_mul_I, mul_one, Complex.norm_real,
    Real.norm_eq_abs, abs_of_nonneg (Real.rpow_nonneg hr.le _)]

/-- The paraboloid has an exact smooth remainder independent of cap center and
scale. This verifies the phase-family hypothesis in a concrete curved case. -/
theorem paraboloid_rescaled_remainder {d : ℕ} (c η : Ambient d) (r : ℝ) :
    inner ℝ (c + r • η) (c + r • η) / 2 =
      inner ℝ c c / 2 + r * inner ℝ c η + r ^ 2 * (inner ℝ η η / 2) := by
  simp only [inner_add_add_self, inner_smul_left, inner_smul_right, RCLike.conj_to_real]
  rw [real_inner_comm η c]
  ring

/-- Actual normalized paraboloid packets obey the expected tube-distance
bound, uniformly in cap center, positive scale, and |t| r² ≤ 1. -/
theorem paraboloid_packet_decay (d M : ℕ) {χ : Ambient d → ℂ}
    (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hs : HasCompactSupport χ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (c : Ambient d) (r : ℝ), 0 < r →
      ∀ (v u : Ambient d) (t : ℝ), |t * r ^ 2| ≤ 1 →
      ‖graphPacket (fun ξ => inner ℝ ξ ξ / 2) χ c r v u t‖ ≤
        r ^ ((d : ℝ) / 2) * (C / (1 + r * ‖u + v + t • c‖) ^ M) := by
  have ha : ContDiff ℝ (⊤ : ℕ∞) (fun q : ℝ × Ambient d => χ q.2) :=
    hχ.comp contDiff_snd
  have hp : ContDiff ℝ (⊤ : ℕ∞)
      (fun q : ℝ × Ambient d => q.1 * (inner ℝ q.2 q.2 / 2)) :=
    contDiff_fst.mul ((contDiff_inner.comp (contDiff_snd.prodMk contDiff_snd)).div_const 2)
  obtain ⟨C, hC, hb⟩ := compact_family_oscillatory_decay ha hp
    (isCompact_Icc : IsCompact (Set.Icc (-1 : ℝ) 1)) hs (fun _ _ => Set.Subset.rfl) M
  refine ⟨C, hC, fun c r hr v u t ht => ?_⟩
  rw [norm_graphPacket_rescale _ χ c hr c (fun η => inner ℝ η η / 2)
    (fun η => paraboloid_rescaled_remainder c η r) v u t]
  have hparam : t * r ^ 2 ∈ Set.Icc (-1 : ℝ) 1 := abs_le.mp ht
  have hd := hb (t * r ^ 2) hparam (r • (u + v + t • c))
  simp only [norm_smul, Real.norm_eq_abs, abs_of_pos hr] at hd
  exact mul_le_mul_of_nonneg_left hd (Real.rpow_nonneg hr.le _)

/-- The same packet estimate applies to any graph whose rescaled remainders
belong to a fixed smooth compact family. The representation is an explicit
hypothesis and remains to be constructed for the article's general patches. -/
theorem graph_packet_decay_of_compact_remainders {P : Type*}
    [NormedAddCommGroup P] [NormedSpace ℝ P] {d : ℕ}
    {ψ : P × Ambient d → ℝ} (hψ : ContDiff ℝ (⊤ : ℕ∞) ψ)
    {Q : Set P} (hQ : IsCompact Q) {χ : Ambient d → ℂ}
    (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hs : HasCompactSupport χ) (M : ℕ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (φ : Ambient d → ℝ) (c : Ambient d) (r : ℝ), 0 < r →
      ∀ (g : Ambient d) (p : P), p ∈ Q →
      (∀ η, φ (c + r • η) = φ c + r * inner ℝ g η + r ^ 2 * ψ (p, η)) →
      ∀ (v u : Ambient d) (t : ℝ), |t * r ^ 2| ≤ 1 →
      ‖graphPacket φ χ c r v u t‖ ≤
        r ^ ((d : ℝ) / 2) * (C / (1 + r * ‖u + v + t • g‖) ^ M) := by
  have ha : ContDiff ℝ (⊤ : ℕ∞) (fun q : (ℝ × P) × Ambient d => χ q.2) :=
    hχ.comp contDiff_snd
  have hp : ContDiff ℝ (⊤ : ℕ∞)
      (fun q : (ℝ × P) × Ambient d => q.1.1 * ψ (q.1.2, q.2)) :=
    (contDiff_fst.comp contDiff_fst).mul
      (hψ.comp ((contDiff_snd.comp contDiff_fst).prodMk contDiff_snd))
  obtain ⟨C, hC, hb⟩ := compact_family_oscillatory_decay ha hp
    ((isCompact_Icc : IsCompact (Set.Icc (-1 : ℝ) 1)).prod hQ) hs
    (fun _ _ => Set.Subset.rfl) M
  refine ⟨C, hC, fun φ c r hr g p hpp hφ v u t ht => ?_⟩
  rw [norm_graphPacket_rescale φ χ c hr g (fun η => ψ (p, η)) hφ v u t]
  have hd := hb (t * r ^ 2, p) ⟨abs_le.mp ht, hpp⟩ (r • (u + v + t • g))
  simp only [norm_smul, Real.norm_eq_abs, abs_of_pos hr] at hd
  exact mul_le_mul_of_nonneg_left hd (Real.rpow_nonneg hr.le _)

end N2Restriction
