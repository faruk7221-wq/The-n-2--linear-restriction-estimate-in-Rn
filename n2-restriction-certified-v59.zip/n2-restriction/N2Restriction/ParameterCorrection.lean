import N2Restriction.CompactCorrection

namespace N2Restriction
open Filter

/-- The quantitative implicit correction allows the target level to vary.
The same Lipschitz constant works for all nearby points and nearby levels. -/
theorem implicit_nearby_level_correction {E F G : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [CompleteSpace F]
    [NormedAddCommGroup G] [NormedSpace ℝ G] [CompleteSpace G]
    (d : ImplicitFunctionData ℝ E F G) {U : Set E} (hU : U ∈ nhds d.pt) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ q : E × F in nhds (d.pt, d.leftFun d.pt),
      ∃ y ∈ U, d.leftFun y = q.2 ∧ dist q.1 y ≤ C * dist (d.leftFun q.1) q.2 := by
  let A := d.leftDeriv.equivProdOfSurjectiveOfIsCompl d.rightDeriv
    d.left_range d.right_range d.isCompl_ker
  let inv := d.hasStrictFDerivAt.localInverse d.prodFun A d.pt
  obtain ⟨K, V, hV, hLip⟩ := d.hasStrictFDerivAt.to_localInverse.exists_lipschitzOnWith
  have hf : Tendsto (fun q : E × F => d.prodFun q.1)
      (nhds (d.pt, d.leftFun d.pt)) (nhds (d.prodFun d.pt)) :=
    d.hasStrictFDerivAt.continuousAt.tendsto.comp continuousAt_fst
  have hr : Tendsto (fun q : E × F => (q.2, d.rightFun q.1))
      (nhds (d.pt, d.leftFun d.pt)) (nhds (d.prodFun d.pt)) :=
    continuousAt_snd.prodMk (d.right_has_deriv.continuousAt.tendsto.comp continuousAt_fst)
  have hy : Tendsto (fun q : E × F => inv (q.2, d.rightFun q.1))
      (nhds (d.pt, d.leftFun d.pt)) (nhds d.pt) :=
    d.hasStrictFDerivAt.localInverse_tendsto.comp hr
  refine ⟨K, K.property, ?_⟩
  filter_upwards [hf.eventually hV, hr.eventually hV,
    continuousAt_fst.eventually d.hasStrictFDerivAt.eventually_left_inverse,
    hr.eventually d.hasStrictFDerivAt.eventually_right_inverse, hy.eventually hU]
    with q hqV hrV hleft hright hyU
  refine ⟨inv (q.2, d.rightFun q.1), hyU, congrArg Prod.fst hright, ?_⟩
  have hd := hLip.dist_le_mul _ hqV _ hrV
  change dist (inv (d.prodFun q.1)) (inv (q.2, d.rightFun q.1)) ≤
    (K : ℝ) * dist (d.prodFun q.1) (q.2, d.rightFun q.1) at hd
  change inv (d.prodFun q.1) = q.1 at hleft
  rw [hleft] at hd
  simpa [ImplicitFunctionData.prodFun, Prod.dist_eq] using hd

/-- Nearby target levels for any finite-codimensional submersion. -/
theorem submersion_nearby_level_correction {E F : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    {f : E → F} {L : E →L[ℝ] F} {z : E}
    (hf : HasStrictFDerivAt f L z) (hL : Function.Surjective L)
    {U : Set E} (hU : U ∈ nhds z) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ q : E × F in nhds (z, f z),
      ∃ y ∈ U, f y = q.2 ∧ dist q.1 y ≤ C * dist (f q.1) q.2 := by
  letI := FiniteDimensional.complete ℝ F
  exact implicit_nearby_level_correction
    (hf.implicitFunctionDataOfComplemented f L (LinearMap.range_eq_top.mpr hL)
      L.ker_closedComplemented_of_finiteDimensional_range) hU

/-- A jointly smooth constraint can be corrected without changing its parameter.
Surjectivity is required only in the geometric variable, not the parameter. -/
theorem parameter_preserving_local_correction {P E F : Type*}
    [NormedAddCommGroup P] [NormedSpace ℝ P] [FiniteDimensional ℝ P]
    [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    {f : P × E → F} {L : P × E →L[ℝ] F} {z : P × E}
    (hf : HasStrictFDerivAt f L z) (hz : f z = 0)
    (hL : Function.Surjective (fun x : E => L (0, x)))
    {U : Set (P × E)} (hU : U ∈ nhds z) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ q : P × E in nhds z,
      ∃ y : E, (q.1, y) ∈ U ∧ f (q.1, y) = 0 ∧ dist q.2 y ≤ C * ‖f q‖ := by
  letI := FiniteDimensional.complete ℝ P
  let Φ : P × E → P × F := fun q => (q.1, f q)
  let D : P × E →L[ℝ] P × F := (ContinuousLinearMap.fst ℝ P E).prod L
  have hD : HasStrictFDerivAt Φ D z := hasStrictFDerivAt_fst.prodMk hf
  have hsurj : Function.Surjective D := by
    rintro ⟨p, t⟩
    obtain ⟨x, hx⟩ := hL (t - L (p, 0))
    change L (0, x) = t - L (p, 0) at hx
    refine ⟨(p, x), ?_⟩
    apply Prod.ext
    · rfl
    · change L (p, x) = t
      have he : (p, x) = (p, 0) + (0, x) := by simp
      rw [he, map_add, hx]
      abel
  obtain ⟨C, hC, hb⟩ := submersion_nearby_level_correction hD hsurj hU
  have ht : Tendsto (fun q : P × E => (q, (q.1, (0 : F))))
      (nhds z) (nhds (z, Φ z)) := by
    simpa [Φ, hz] using continuousAt_id.prodMk (continuousAt_fst.prodMk continuousAt_const)
  refine ⟨C, hC, ?_⟩
  filter_upwards [ht.eventually hb] with q hq
  obtain ⟨y, hy, heq, hd⟩ := hq
  have hp : y.1 = q.1 := congrArg (fun t : P × F => t.1) heq
  have hfy : f y = 0 := congrArg (fun t : P × F => t.2) heq
  have hey : (q.1, y.2) = y := by rw [← hp]
  refine ⟨y.2, hey.symm ▸ hy, hey.symm ▸ hfy, ?_⟩
  simpa [Φ, Prod.dist_eq, hp] using hd

/-- Uniform correction over a compact parameter-frequency family, with the
parameter kept fixed. This can be instantiated once a plane-coordinate family
of constraints and its vertical regularity are constructed. -/
theorem compact_parameter_correction {P E F : Type*}
    [NormedAddCommGroup P] [NormedSpace ℝ P] [FiniteDimensional ℝ P]
    [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    {f : P × E → F} {K U : Set (P × E)} (hK : IsCompact K) (hU : IsOpen U) (hKU : K ⊆ U)
    (hf : ContinuousOn f K)
    (hreg : ∀ z ∈ K, f z = 0 → ∃ L : P × E →L[ℝ] F,
      HasStrictFDerivAt f L z ∧ Function.Surjective (fun x : E => L (0, x))) :
    ∃ δ C : ℝ, 0 < δ ∧ 0 ≤ C ∧ ∀ q ∈ K, ‖f q‖ < δ →
      ∃ y : E, (q.1, y) ∈ U ∧ f (q.1, y) = 0 ∧ dist q.2 y ≤ C * ‖f q‖ := by
  have hu := compact_uniform_correction_rel (Rel := fun q y : P × E => y.1 = q.1)
    (Z := {y | y ∈ U ∧ f y = 0}) hK hf.norm (fun _ => norm_nonneg _) ?_
  · obtain ⟨δ, C, hδ, hC, hb⟩ := hu
    refine ⟨δ, C, hδ, hC, fun q hq hsmall => ?_⟩
    obtain ⟨y, ⟨hy, hfy⟩, hp, hd⟩ := hb q hq hsmall
    have hey : (q.1, y.2) = y := by rw [← hp]
    refine ⟨y.2, hey.symm ▸ hy, hey.symm ▸ hfy, ?_⟩
    simpa [Prod.dist_eq, hp] using hd
  · intro z hz hzero
    have hz0 := norm_eq_zero.mp hzero
    obtain ⟨L, hL, hsurj⟩ := hreg z hz hz0
    obtain ⟨C, hC, hb⟩ := parameter_preserving_local_correction hL hz0 hsurj (hU.mem_nhds (hKU hz))
    refine ⟨C, hC, ?_⟩
    filter_upwards [mem_nhdsWithin_of_mem_nhds hb] with q hq
    obtain ⟨y, hy, hfy, hd⟩ := hq
    exact ⟨(q.1, y), ⟨hy, hfy⟩, rfl, by simpa [Prod.dist_eq] using hd⟩

end N2Restriction
