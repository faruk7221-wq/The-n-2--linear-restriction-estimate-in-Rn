import N2Restriction.OscillatoryDecay
import Mathlib.Analysis.Calculus.ParametricIntegral

namespace N2Restriction
open MeasureTheory Set Metric

variable {P E : Type} [NormedAddCommGroup P] [NormedSpace ℝ P]
  [FiniteDimensional ℝ P] [NormedAddCommGroup E] [NormedSpace ℝ E]

/-- The parameter derivative, viewed jointly with the integration variable. -/
noncomputable def parameterDerivative (f : P × ℝ → E) (q : P × ℝ) : P →L[ℝ] E :=
  (fderiv ℝ f q).comp (ContinuousLinearMap.inl ℝ P ℝ)

omit [FiniteDimensional ℝ P] in
theorem smooth_parameterDerivative {f : P × ℝ → E}
    (hf : ContDiff ℝ (⊤ : ℕ∞) f) :
    ContDiff ℝ (⊤ : ℕ∞) (parameterDerivative f) := by
  exact (contDiff_infty_iff_fderiv.mp hf).2.clm_comp contDiff_const

omit [FiniteDimensional ℝ P] in
theorem hasFDerivAt_parameter_slice {f : P × ℝ → E}
    (hf : ContDiff ℝ (⊤ : ℕ∞) f) (p : P) (s : ℝ) :
    HasFDerivAt (fun x => f (x, s)) (parameterDerivative f (p, s)) p := by
  have hi : HasFDerivAt (fun x : P => (x, s)) (ContinuousLinearMap.inl ℝ P ℝ) p := by
    simpa using (hasFDerivAt_id p).prodMk (hasFDerivAt_const s p)
  exact (hf.differentiable (by simp) (p, s)).hasFDerivAt.comp p hi

/-- Differentiation under a fixed compact real interval, with domination
derived from joint smoothness on a compact parameter neighborhood. -/
theorem hasFDerivAt_compact_integral {f : P × ℝ → E}
    (hf : ContDiff ℝ (⊤ : ℕ∞) f) (a b : ℝ) (p : P) :
    HasFDerivAt (fun x => ∫ s in Icc a b, f (x, s))
      (∫ s in Icc a b, parameterDerivative f (p, s)) p := by
  have hD := (smooth_parameterDerivative hf).continuous
  obtain ⟨C, hC⟩ := ((isCompact_closedBall p 1).prod
    (isCompact_Icc : IsCompact (Icc a b))).exists_bound_of_continuousOn
    hD.continuousOn
  apply hasFDerivAt_integral_of_dominated_of_fderiv_le (ε := 1)
    (μ := volume.restrict (Icc a b)) (F := fun x s => f (x, s))
    (F' := fun x s => parameterDerivative f (x, s)) (bound := fun _ => C) (by norm_num)
  · exact Filter.Eventually.of_forall fun x =>
      (hf.continuous.comp (continuous_const.prodMk continuous_id)).aestronglyMeasurable
  · exact (hf.continuous.comp (continuous_const.prodMk continuous_id)).continuousOn.integrableOn_compact
      isCompact_Icc
  · exact (hD.comp (continuous_const.prodMk continuous_id)).aestronglyMeasurable
  · filter_upwards [ae_restrict_mem measurableSet_Icc] with s hs
    intro x hx
    exact hC (x, s) ⟨ball_subset_closedBall hx, hs⟩
  · exact continuous_const.integrableOn_Icc
  · exact Filter.Eventually.of_forall fun s x _ => hasFDerivAt_parameter_slice hf x s

/-- Compact-interval integration preserves every finite derivative order. -/
theorem contDiff_nat_compact_integral (n : ℕ) {f : P × ℝ → E}
    (hf : ContDiff ℝ (⊤ : ℕ∞) f) (a b : ℝ) :
    ContDiff ℝ n (fun x => ∫ s in Icc a b, f (x, s)) := by
  induction n generalizing E with
  | zero =>
    rw [Nat.cast_zero, contDiff_zero]
    exact Differentiable.continuous (𝕜 := ℝ)
      (fun x => (hasFDerivAt_compact_integral hf a b x).differentiableAt)
  | succ n ih =>
    rw [Nat.cast_add, Nat.cast_one, contDiff_succ_iff_fderiv]
    refine ⟨fun x => (hasFDerivAt_compact_integral hf a b x).differentiableAt, by simp, ?_⟩
    have he : fderiv ℝ (fun x => ∫ s in Icc a b, f (x, s)) =
        fun x => ∫ s in Icc a b, parameterDerivative f (x, s) := by
      funext x
      exact (hasFDerivAt_compact_integral hf a b x).fderiv
    rw [he]
    exact ih (smooth_parameterDerivative hf)

/-- Jointly smooth integrands have a smooth compact-interval integral, even
at parameter values where a quotient formula for the integral is singular. -/
theorem smooth_compact_integral {f : P × ℝ → E}
    (hf : ContDiff ℝ (⊤ : ℕ∞) f) (a b : ℝ) :
    ContDiff ℝ (⊤ : ℕ∞) (fun x => ∫ s in Icc a b, f (x, s)) := by
  exact contDiff_infty.mpr (fun n => contDiff_nat_compact_integral n hf a b)

end N2Restriction
