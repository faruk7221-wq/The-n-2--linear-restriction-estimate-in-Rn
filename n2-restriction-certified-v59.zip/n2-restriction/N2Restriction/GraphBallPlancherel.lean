import N2Restriction.CompactSurfacePlancherel

namespace N2Restriction
open MeasureTheory Set
open scoped ENNReal

theorem graphPoint_measurePreserving (d : ℕ) : MeasurePreserving (fun p : ℝ × Ambient d => graphPoint p.2 p.1)
    (volume.prod volume) volume := by
  have h1 := (MeasurePreserving.id (volume : Measure ℝ)).prod
    (PiLp.volume_preserving_ofLp (Fin d))
  have h2 := (volume_preserving_piFinSuccAbove (fun _ : Fin (d + 1) => ℝ) 0).symm
  have h3 := PiLp.volume_preserving_toLp (Fin (d + 1))
  convert h3.comp (h2.comp h1) using 1
  funext p
  ext i
  simp [graphPoint, MeasurableEquiv.piFinSuccAbove]
  rfl

/-- positive ambient ball integrals are bounded by iterated horizontal slabs. -/
theorem lintegral_ball_le_slices {d : ℕ} (f : Ambient (d + 1) → ℝ≥0∞) (hf : Measurable f) (x₀ : Ambient (d + 1)) (R : ℝ) :
    (∫⁻ y in Metric.ball x₀ R, f y) ≤
      ∫⁻ t in Icc (x₀ 0 - R) (x₀ 0 + R), ∫⁻ u : Ambient d, f (graphPoint u t) := by
  have hm := graphPoint_measurePreserving d
  rw [← lintegral_indicator measurableSet_ball,
    ← hm.lintegral_comp (hf.indicator measurableSet_ball)]
  have hmeas : Measurable (fun p : ℝ × Ambient d =>
      (Metric.ball x₀ R).indicator f (graphPoint p.2 p.1)) :=
    (hf.indicator measurableSet_ball).comp hm.measurable
  rw [lintegral_prod _ hmeas.aemeasurable]
  rw [← lintegral_indicator measurableSet_Icc]
  apply lintegral_mono
  intro t
  by_cases ht : t ∈ Icc (x₀ 0 - R) (x₀ 0 + R)
  · rw [indicator_of_mem ht]
    apply lintegral_mono
    intro u
    by_cases hu : graphPoint u t ∈ Metric.ball x₀ R
    · simp only [indicator_of_mem hu, le_refl]
    · simp only [indicator_of_notMem hu, zero_le]
  · rw [indicator_of_notMem ht]
    apply le_of_eq
    apply lintegral_eq_zero_of_ae_eq_zero
    filter_upwards with u
    apply indicator_of_notMem
    intro hu
    have hu' : dist (graphPoint u t) x₀ < R := hu
    have ht' : |t - x₀ 0| ≤ dist (graphPoint u t) x₀ := by
      apply (sq_le_sq₀ (abs_nonneg _) dist_nonneg).mp
      have hd := graphPoint_dist_sq u (graphProjection x₀) t (x₀ 0)
      rw [graphPoint_projection_height] at hd
      rw [sq_abs, hd]
      nlinarith [sq_nonneg ‖u - graphProjection x₀‖]
    have habs := abs_le.mp (ht'.trans hu'.le)
    exact ht ⟨by linarith [habs.1], by linarith [habs.2]⟩

/-- finite slice energy controls the ambient ball with its height-length factor. -/
theorem ball_energy_of_slice {d : ℕ} (F : Ambient (d + 1) → ℂ) (hF : Continuous F) (x₀ : Ambient (d + 1)) {C R : ℝ}
    (hC : 0 ≤ C) (hR : 0 ≤ R)
    (hmem : ∀ t : ℝ, MemLp (fun u : Ambient d => F (graphPoint u t)) 2)
    (hbound : ∀ t : ℝ, (∫ u : Ambient d, ‖F (graphPoint u t)‖ ^ 2) ≤ C) :
    (∫ y in Metric.ball x₀ R, ‖F y‖ ^ 2) ≤ 2 * R * C := by
  have hi : IntegrableOn (fun y => ‖F y‖ ^ 2) (Metric.ball x₀ R) volume :=
    ((hF.norm.pow 2).continuousOn.integrableOn_compact (isCompact_closedBall x₀ R)).mono_set
      Metric.ball_subset_closedBall
  apply (ENNReal.ofReal_le_ofReal_iff (by positivity : 0 ≤ 2 * R * C)).mp
  rw [ofReal_integral_eq_lintegral_ofReal hi (ae_of_all _ fun y => sq_nonneg _)]
  have h := lintegral_ball_le_slices (fun y => ENNReal.ofReal (‖F y‖ ^ 2))
    (ENNReal.measurable_ofReal.comp (hF.measurable.norm.pow_const 2)) x₀ R
  apply h.trans
  calc
    _ ≤ ∫⁻ t in Icc (x₀ 0 - R) (x₀ 0 + R), ENNReal.ofReal C := by
      apply lintegral_mono
      intro t
      dsimp only
      rw [← ofReal_integral_eq_lintegral_ofReal
        ((memLp_two_iff_integrable_sq_norm (hmem t).aestronglyMeasurable).mp (hmem t))
        (ae_of_all _ fun u => sq_nonneg _)]
      exact ENNReal.ofReal_le_ofReal (hbound t)
    _ = ENNReal.ofReal (2 * R * C) := by
      rw [setLIntegral_const, Real.volume_Icc]
      rw [show (x₀ 0 + R) - (x₀ 0 - R) = 2 * R by ring, ← ENNReal.ofReal_mul hC]
      congr 1
      ring

/-- actual Hausdorff graph inputs satisfy the local ball estimate at every center. -/
theorem SurfaceGraphChart.compact_ball_energy {d : ℕ} (G : SurfaceGraphChart d)
    (hφ : ContDiff ℝ (⊤ : ℕ∞) G.phase) {K : Set (Ambient d)} (hK : IsCompact K)
    (g : Lp ℂ 2 G.surfaceMeasure)
    (hg : HasFrequencySupport G.surfaceMeasure id (G.parametrization '' K) g)
    (x₀ : Ambient (d + 1)) {R : ℝ} (hR : 0 ≤ R) :
    (∫ y in Metric.ball x₀ R, ‖extension G.surfaceMeasure id g y‖ ^ 2) ≤
      2 * R * (((2 * Real.pi) ^ d * G.density.upper) * ‖g‖ ^ 2) := by
  have hs := G.density.toCoordinate_support (G.pullInput g) id K (G.pull_support g K hg)
  have hi := integrable_of_compact_frequency_support hK _ hs
  have hc : Continuous (extension G.surfaceMeasure id g) := by
    have he : extension G.surfaceMeasure id g =
        extension volume G.parametrization (G.density.toCoordinate (G.pullInput g)) :=
      funext (G.coordinate_extension g)
    rw [he]
    exact continuous_extension G.measurableEmbedding_parametrization.measurable hi
  have hu := G.density.upper_nonneg
  exact ball_energy_of_slice _ hc x₀ (by positivity) hR
    (G.compact_slice_memLp hφ hK g hg) (G.compact_slice_energy hφ hK g hg)

/-- the local ball estimate uses the original restricted patch L2 norm. -/
theorem SurfaceGraphChart.patch_ball_energy {d : ℕ} (G : SurfaceGraphChart d)
    (hφ : ContDiff ℝ (⊤ : ℕ∞) G.phase) {K : Set (Ambient d)} (hK : IsCompact K)
    (himage : MeasurableSet (G.parametrization '' K))
    (g : Lp ℂ 2 (G.surfaceMeasure.restrict (G.parametrization '' K)))
    (x₀ : Ambient (d + 1)) {R : ℝ} (hR : 0 ≤ R) :
    (∫ y in Metric.ball x₀ R,
      ‖extension (G.surfaceMeasure.restrict (G.parametrization '' K)) id g y‖ ^ 2) ≤
      2 * R * (((2 * Real.pi) ^ d * G.density.upper) * ‖g‖ ^ 2) := by
  have h := G.compact_ball_energy hφ hK (G.patchInput himage g)
    (G.patchInput_support himage g) x₀ hR
  simp_rw [G.patchInput_extension] at h
  simpa only [SurfaceGraphChart.patchInput, zeroExtendL2_norm] using h

/-- a genuinely local smooth graph phase gives the original Hausdorff-patch ball estimate. -/
theorem local_graph_patch_ball_estimate {d : ℕ} {U : Set (Ambient d)} (hU : IsOpen U)
    {φ : Ambient d → ℝ} (hφ : ContDiffOn ℝ (⊤ : ℕ∞) φ U)
    (z : Ambient d) {a b : ℝ} (ha : 0 < a) (hab : a < b)
    (hball : Metric.closedBall z b ⊆ U) {K : Set (Ambient d)} (hK : IsCompact K)
    (hsub : K ⊆ Metric.closedBall z a) :
    ∃ C : ℝ, 0 ≤ C ∧
      ∀ (g : Lp ℂ 2 ((Measure.hausdorffMeasure (d : ℝ)).restrict
        ((fun x => graphPoint x (φ x)) '' K))) (x₀ : Ambient (d + 1)) (R : ℝ), 0 ≤ R →
      (∫ y in Metric.ball x₀ R,
        ‖extension ((Measure.hausdorffMeasure (d : ℝ)).restrict
          ((fun x => graphPoint x (φ x)) '' K)) id g y‖ ^ 2) ≤ C * R * ‖g‖ ^ 2 := by
  obtain ⟨G, hG, he⟩ := exists_local_surfaceGraphChart hU hφ z ha hab hball
  have heK : EqOn G.phase φ K := fun x hx => he (hsub hx)
  have hμ := G.surfaceMeasure_local_patch heK
  have hmeas : MeasurableSet (G.parametrization '' K) :=
    (hK.image (graphMap_lipschitz G.lipschitz).continuous).measurableSet
  have hupper := G.density.upper_nonneg
  refine ⟨2 * ((2 * Real.pi) ^ d * G.density.upper), by positivity, ?_⟩
  rw [← hμ]
  intro g x₀ R hR
  exact (G.patch_ball_energy hG hK hmeas g x₀ hR).trans_eq (by ring)

end N2Restriction
