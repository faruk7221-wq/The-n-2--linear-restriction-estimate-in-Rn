# Revision 59: localized normal-geometry certification

The certification is a proof of the named local and global conclusions relative
to eight explicit borrowed mathematical inputs. It is not a proof of those
external theorems. `Certification.lean` exposes the final statement and its
kernel axiom dependencies. Run `./scripts/check.sh` after obtaining the pinned
Lean/mathlib dependencies to rebuild and audit the complete project.

## Defect corrected

Revision 58 retained separate admissibility of the localization plane for each
surface, but discarded closeness to the common tangent plane. Separate
admissibility does not guarantee joint transversality of the localized normal
space and the other surface normals. Consequently, the previous localized
restriction premise was too broad to identify with the cited external result.
The earlier certification language must be read subject to this correction.

## Proof changes

1. `ArticleFrame` now retains its common-tangent projection gap for every tuple
   of support points. The existing terminal-plane construction proves this
   stronger condition; no additional surface hypothesis is introduced.
2. The atlas buffer is chosen within the quantitative joint-transversality
   radius obtained from `GeometricHypotheses`. The constants are fixed before
   choosing the frame, chart indices or frequency points.
3. The certified atlas stores a positive uniform lower bound for the Gram
   determinant of the other surface normals together with an orthonormal basis
   of the actual three-dimensional localized normal space. The atlas constructor
   proves this bound from the existing geometric lemmas.
4. A strict reference margin is retained. Every actual zero-target point has a
   regular zero-level parametrization on one common positive radius, with the
   measured atlas's derivative and inverse-derivative controls.
5. `localized_normal_certificate` applies the normalized normal-space bound to
   those actual target charts and the other measured carriers. The localized
   restriction interface now imports this certificate and quantifies over the
   strengthened atlas. All dependent final estimates are rebuilt.

The conclusion remains `MainLocalGoal ∧ MainGlobalGoal`, through
`mainGoals_of_certified_borrowed_inputs`. The names ending in V55 and V58 are
retained for compatibility; their imported frame and atlas definitions have
the revision 59 meaning.

## Trust boundary

The eight explicit arguments remain:

- `SmoothGraphAreaFormulaInput`
- `WeightedKakeyaExternalGoal`
- `CertifiedLocalizedRestrictionInput` (now restricted to the corrected geometry)
- `UniformTangentCutsInput`
- `UniformProjectedPartitionInput`
- `UniformPolynomialTubeCoverInput`
- `ZeroDimensionalPointCountInput`
- `SurfaceEpsilonRemovalInput`

They are theorem premises, not Lean axioms. In particular, a standard-axiom
report certifies the implication and does not establish these premises.
The external localized restriction estimate, including its uniform analytic
constants, is still borrowed. This revision verifies the missing geometric
applicability condition; it does not formalize the external paper itself.

The certification covers the named main conclusions and their formal dependency
chain. It does not assert an independently checked correspondence for every
ancillary statement or example in the article.

## Verification scope

See `verification/session-v59.json` for exact counts and checks. Every changed
Lean module and every local downstream dependent is freshly compiled. Unchanged
dependencies reuse compiled interfaces from byte-identical pinned sources.
All retained and new theorem inventories are checked against their compiler
axiom reports and source hashes. This is an incremental rebuild, not a new
cold build of mathlib. A hosted CI run is not claimed.

`AuditUnion.lean` checks all 843 main declarations with Lean's own
`CollectAxioms.collect`, using one shared visited set in the checked kernel
environment. This computes the union of their axiom dependencies without
repeating shared dependency traversals. It fails on a missing declaration or
any axiom outside `propext`, `Classical.choice`, and `Quot.sound`. The original
per-declaration `Audit.lean` and audit script remain available unchanged.

For the fast aggregate main audit alone, run `lake env lean AuditUnion.lean`.
