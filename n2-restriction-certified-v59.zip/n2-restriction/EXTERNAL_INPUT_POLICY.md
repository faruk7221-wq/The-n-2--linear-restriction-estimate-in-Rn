**Revision 0.59 — corrected localized normal-geometry certification.**

The localized restriction interface now retains common-tangent closeness and a
proved uniform normalized joint normal-space bound on actual localized charts.
The main conclusions remain conditional on eight explicit borrowed inputs.
See [REVISION_59.md](REVISION_59.md) for the repaired gap and exact trust boundary,
and `Certification.lean` for the final Lean entry point. Run `./scripts/check.sh`
to rebuild and audit all inventories plus that entry point.

The v59 verification record distinguishes fresh affected-module compilation from
retained reports for unchanged sources. Earlier revision counts and claims below
are historical and are superseded where the v59 correction applies.

## Historical revision 58 record

# External input policy — revision 0.58

External inputs are unchanged: standard smooth graph area formula, weighted Kakeya, uniform localized restriction on full certified measured atlases, tangent cuts, projected polynomial partition/generic transversality, polynomial tube covering, dimension-zero point count, and surface epsilon removal. These are explicit theorem arguments, not project axioms. The article-side Fourier decay, energy estimates, recurrence, descent, original-support assembly, and named local/global conclusions are proved internally. Standard-axiom checks certify these implications, not the borrowed mathematical theorems themselves.

Both named main targets are proved relative to these inputs. SurfaceTestDecay is no longer an open or borrowed premise: it is proved with exponent 1/2 from the geometric hypotheses and the standard area formula in the nonempty-support branch. The main global theorem handles empty original supports internally. No external input was added in revision 58.

## Retained policy history (superseded where indicated)

# External input policy — revision 0.57

The standard smooth graph area formula is now an explicit borrowed input, SmoothGraphAreaFormulaInput, as authorized by the user to assume external inputs. It states the actual normalized Hausdorff measure identity for every smooth graph over a compact coordinate set. It contains no Fourier decay, oscillatory estimate, restriction bound, partition construction or article theorem. All Jacobian regularity, amplitude budgets, exact Fourier transfers and decay estimates are proved internally from it. It is a theorem argument, not a project axiom. The previous weighted Kakeya, certified localized restriction, tangent-cut, partition/transversality, covering/counting and conditional epsilon-removal interfaces are retained unchanged.

The exact new contract is continuation/SmoothGraphAreaInputV57.lean. The named local theorem does not require this new input. Full-surface SurfaceTestDecay is still an internal article-side obligation.

## Retained policy history

# External input policy — revision 0.55

Borrowed inputs remain explicit theorem arguments: weighted Kakeya, uniform localized restriction on fully certified measured localization atlases, tangent cuts, projected polynomial partition/generic transversality, tube covering and dimension-zero point count. The conditional global assembly also uses borrowed surface epsilon removal. The certified localized interface retains actual MeasuredTubularChart and ChartNormalCoordinates data, all common derivative/metric/measure bounds, centers, support coverage, zero-target and localization certificates, before the frame/radius/input quantifiers of the analytic assumption. No energy, recurrence, descent, support assembly, local theorem, or SurfaceTestDecay is assumed as a borrowed result.

The revision 54 atlas-provenance gap is closed in the new route. Classical.choice is now applied to a full certified atlas type whose every inhabitant retains measured-chart and normal-coordinate geometry. The reduced atlas is obtained by a proved forgetful construction. The new named local theorem does not use CanonicalLocalizedRestrictionInput or an arbitrary inhabitant of the reduced atlas type.

SurfaceTestDecay remains an internal article-side obligation. No new global Lean axioms are introduced.

## Historical policy (superseded where indicated)

# External input policy — revision 0.54

## Final scope review — authoritative

Final assumption review: mainLocalGoal_of_borrowed_inputs is a checked implication from its stated interfaces. CanonicalLocalizedRestrictionInput is assumed on canonicalArticleLocalizationAtlas, defined by Classical.choice of Nonempty ArticleLocalizationAtlas. That reduced structure forgets full measured-chart provenance. The present source therefore does not yet certify that this interface is exactly an instance of article External input 1. Restore a data-bearing atlas constructor retaining its full MeasuredTubularChart/ChartNormalCoordinates certificates, and specialize the borrowed theorem there. Until then, the named local goal is CONDITIONAL on the stated localized interface, not fully certified relative only to the intended borrowed theorems. Original-support assembly and endpoint arguments themselves are proved. Global SurfaceTestDecay (8.4) also remains open.

The following milestones are to be read subject to this qualification; earlier completion wording is superseded.


## Revision 0.54 authoritative update

Explicit borrowed inputs: weighted multilinear Kakeya; uniform localized restriction at baseline on the internally constructed canonical article localization atlas; uniform tangent cuts; projected polynomial partition/generic transversality; polynomial tube covering; dimension-zero point count. The global conditional route also uses the existing borrowed surface epsilon-removal theorem. CanonicalLocalizedRestrictionInput repackages the localized input ONLY on the actual internally chosen atlas; it does not assume restriction on every arbitrary reduced ArticleLocalizationAtlas. Internal energy, descent, recurrence, original-support assembly, MainLocalGoal and SurfaceTestDecay are not external inputs.

The named local implication is checked under the stated interfaces; certification of the localized atlas input remains open. MainGlobalGoal is conditional on the article-side SurfaceTestDecay; that conditional premise is not accepted as external and remains work to prove.


## Historical policy notes (superseded where indicated)

At the user's direction, borrowed theorems are assumptions. The goal is a checked proof of the article's contribution relative to those assumptions. This does not permit assuming the article's own lemmas, selected-input estimates, or recurrence.

No global Lean axioms are added. Borrowed statements are named propositions passed as explicit theorem arguments, so the assumptions remain visible in each theorem's type. A standard-axiom audit therefore certifies the conditional implication, not an independent proof of the borrowed mathematics.

| Article input | Current interface and treatment |
|---|---|
| External input 1, uniform localized restriction | `ArticleLocalizationAtlas.UniformLocalizedInput`. Assumed for the chosen atlas, at the baseline exponent. Its coefficient precedes the plane, selected factor, chart tuple, width, radius, center and input. This is the chart estimate (2.2), not the article's strip estimate or main recurrence. |
| External input 2, weighted Kakeya | Already proved in v36. Retained; no further development of this external result is needed. |
| External input 3(3), algebraic transverse-tube covering | `AlgebraicTubeCoverInput`. Assumed for the fixed variety and tangent spaces, with constants independent of the new partition polynomial and scale. The angle transfer, sign separation, packing and resulting cell count are proved in v38. |
| Other parts of External input 3 | May be assumed when used. Exact partitioning, tangent-plane-cut and zero-dimensional interfaces still need to be integrated into the descent. Their external proofs are out of scope. |
| External input 4, epsilon removal | `SurfaceEpsilonRemovalInput`. Assumed. Local restriction and `SurfaceTestDecay` remain explicit article-side obligations. |

## What the new localization result establishes

`exists_article_localization_atlas` constructs uniformly finite measured carriers and genuine zero-level reference targets, with a common strip threshold and displacement bound. `corollary43_small_width` proves the C*mu strip estimate for original Hausdorff-measured inputs from a supplied `UniformLocalizedInput` for that atlas. `baseline_integral_localization` gives the integral form used in (7.13), on sets contained in a ball, with gain mu^q0.

This is a proved application relative to the specialized external chart estimate. It does not prove that every object satisfying the reduced `ArticleLocalizationAtlas` interface meets the borrowed theorem's full smoothness and transversality hypotheses. The earlier measured-chart and normal-wedge certificates remain available, but their complete packaging into one external theorem application is not claimed in v38. In particular, no universal assumption asserting localized restriction for every arbitrary atlas is introduced.

## What remains part of the article

- Lemma 5.1 is proved in revision 0.40, including maximal continuation and the polynomial independent-gradient adapter. No lifting existence is assumed.
- Full dimension-descent stages remain open. Revision 0.40 proves wall mass selection, regular transverse intersection dimension loss, and the selected-extension mass update. Generic-cut transversality remains an explicit external-input premise; polynomial degree bookkeeping and cut/net assignment remain to be packaged.
- Aggregating the new bounded-Hilbert-synthesis cell budgets across the actual surface atlas/caps.
- Tangent-plane selection, tangent cap support and the remaining local Plancherel/lattice-ball estimates in Section 7.
- Establishing the actual extension-operator recurrence in Section 8.
- Fourier decay of compact smooth test functions on the fixed extended surfaces (with support inside the open chart neighborhood), needed to invoke the assumed epsilon-removal input.
- Final local and global theorem proofs. Both remain unproved.


## Revision 0.41 clarification

The polynomial wall degree bookkeeping, finite plane net and measurable witness assignment are now proved. The tangent-cut and factor-wall alternatives construct full polynomial stages with explicit constants. Componentwise tangent oscillation, regular bounded-degree tangent cuts, generic factor transversality and algebraic tube covering remain visible borrowed premises. Actual graph-packet near/far cell budgets are aggregated across caps internally, using support overlap rather than a cap-count bound. Connecting all cap inputs to the global surface atlas and finishing the non-wall analytic branch remain obligations.


## Revision 0.42 clarification

The original-surface atlas/cap energy and normal-axis adapters, actual binary packet choice, projected reset measure, omitted-packet rapid tails, finite-buffer margin local estimate at R/2, product-error cell-mass estimate and direct atlas substantial-cell selection are now proved. No new borrowed theorem or global axiom was introduced. The local best constant is used by its supremum definition; no bound for that constant or recurrence is assumed as a theorem. The complete partition/Markov/D-power assembly, repeated-stage margin uniformity, terminal configurations and final main theorems remain open. Historical open-item lists above are superseded by this paragraph and CONTINUATION_HANDOFF.md.


## Revision 0.43 clarification (authoritative)

The actual reset-partition non-wall estimate is now assembled on the fixed atlas-buffer class, with internal substantial-cell selection, degree exponent, packet tails, rapid-error normalization and the zero-mass case. `reset_partition_wall_or_cells` derives retained cell mass from the away-region cover; retained mass is a branch premise, not an extra borrowed theorem. The external partition's label/count/degree/per-cell upper-mass data and algebraic tube covering stay explicit. Full invocation/coverage packaging, common changing-margin compatibility, uniform complete descent, terminal estimates and both main theorems remain open. No global axioms or assumed article-side energy/recurrence conclusions were introduced.

The canonical trimmed sign-cell measurability, wall separation and away-region coverage are now proved internally by `canonical_trimmed_sign_cells`. Matching the external projected partition data to those canonical cells remains packaging work. The Section 8 adapter must control support relative to each original admissible input; the fixed-buffer containment theorem is not substituted for that statement.


## Revision 0.44 clarification (authoritative)

Relative essential-support enlargement, original chart support preservation, child admissibility and fixed-class geometry are now proved article-side results. No additional external margin theorem is assumed. The inherited-margin non-wall estimate keeps borrowed partition/tube-cover data explicit. Full common-class mass/descent assembly and terminal arguments remain open; the completed same-class LOCAL adapter is not a completed recurrence.


## Revision 0.45 clarification (authoritative)

Same-class non-wall mass propagation, constructed caps/chart inputs, contracting-degree choice, robust near-plane rank, nonzero-mass feasible counts and selected-stage classification are proved article-side results. Finite-point child-radius analysis is proved conditional on geometric finite-point coverage. `UniformAlgebraicTubeCoverInput` records the full width/angle scaling of External input 3(3), with constants fixed before width and angle; the resulting nontangent ball multiplicity estimate is proved. This external interface is a proposition passed explicitly, not a global axiom. The actual partition output and tube-cover assumptions remain explicit. The full descent and terminal analytic assembly are article contributions and remain unfinished.


## Revision 0.46 clarification (authoritative)

Lemma 7.2's plane construction, full-neighborhood directional subdivision, cube witness geometry, actual tangent packet normal strip, and actual nontangent witness extraction/multiplicity are proved article-side. Only the previously specified angular-uniform algebraic tube-cover input is assumed in the new nontangent multiplicity theorem. The main terminal analytic bounds, stage assembly, finite dimension descent and recurrences remain article-side obligations and have not been assumed.


## Revision 0.47 clarification (authoritative)

Lemma 7.1's complete nontangent analytic estimate is proved for the actual original-packet selection, with its cap families, bounded-overlap lattice cover, energy and analytic summation constructed internally. UniformAlgebraicTubeCoverInput remains an explicit borrowed hypothesis. The actual tangent/nontangent split, selected tangent cube support and uniform original-input rapid product error are also proved. Proposition 7.3, retained-stage construction, finite dimension descent and recurrences remain article-side obligations and are not assumed.


## Revision 0.48 clarification (authoritative)

The actual Ftan bounds (7.9), (7.10), the square-function energy (7.15), and the localized actual tangent-cube integral step of (7.13) are proved with the contracts above. Fixed-patch support and terminal geometry are explicit invariants with separately proved adapters. The borrowed UniformLocalizedInput remains explicit; local Plancherel and packet retention are proved internally. Do not assume (7.8), the full Proposition 7.3, finite stage descent or the final recurrences.


## Revision 0.49 clarification (authoritative)

The actual tangent integral is now proved through localized restriction, rapid cube-error assembly, ball/binary/grid summation and the borrowed finite directional Kakeya estimate, with original-input norms. Terminal geometric frame data and scale conditions remain explicit. Final normalized (7.8), terminal descent, recurrences and the main theorem remain unfinished; do not assume them.


## Revision 0.50 clarification (authoritative)

Normalized actual tangent endpoint bounds and critical/above-critical bounds are now proved. Terminal polynomial cube frames are constructed, including empty-subpatch zero branches. The original selected-product terminal recurrence uses the retained proved nontangent estimate, the new proved tangent estimate and one internally proved retention error. Its external premises remain the borrowed weighted Kakeya, localized restriction, and algebraic tube-cover input. Polynomial regularity, terminal dimension count, near-reference angles and plane-witness region are explicit stage invariants. The finite wall/non-wall descent, zero-dimensional polynomial point construction, final MarginRecurrences and main theorems are still unfinished.


## Revision 0.51 clarification (authoritative)

The literal zero-dimensional cardinality theorem of External Input 3(4) is now `ZeroDimensionalPointCountInput`. It is passed explicitly, not proved or added as a global axiom. Regular/nonempty polynomial stages internally have codimension at most ambient dimension, and dimension-zero stages have equal codimension and ambient dimension. The borrowed product-of-degrees bound therefore gives a finite exact zero set with at most D^n points. Actual stage coverage and the selected-input estimates (6.15), including constructed original caps/charts and the explicit rooted accumulated error, are proved from it. Optional isolation/discreteness lemmas are not used as substitutes for the borrowed algebraic point count.

The terminal analytic chain now uses the same subdivision as reference-normal feasibility, and one constructed-data theorem supplies both zero/terminal outcomes. Stage budgets, a numerical contracting-degree schedule and a well-founded descent assembly principle are proved. The schedule still requires finite coefficient tables derived uniformly from old budgets. The actual bounded one-step partition alternative remains an internal obligation, not an additional borrowed input; it is not yet proved. The exact origin-mass/L2/all-center adapters to MarginRecurrences retain the still-unproved original-input mass estimate as their premise. The actual full descent, original-input recurrence and both main theorems remain open.


## Revision 0.52 clarification (authoritative)

The actual tangent-cut/away/plane/binary preparation and the actual contracting one-partition alternative are now proved, relative to explicit degree-uniform borrowed algebraic inputs. UniformTangentCutsInput is Input 3(2). UniformProjectedPartitionInput packages Input 3(1) and its generic regular-value transversality background, with geometric degree/count/sign-mass data only. UniformPolynomialTubeCoverInput is Input 3(3), with an internally proved fixed-angle normalization. These do not assume the article's selected-input energy bounds, cellular estimate, one-partition analytic alternative, finite iteration or recurrence. Actual density finiteness/absolute continuity, canonical trimmed-cell geometry, wall/cell mass retention, energy and omitted-packet estimates, degree contraction and genuine polynomial wall-stage construction are proved applications. Constants and the chosen degree precede R. The full finite hierarchy/grouped admissible-stage hstep, common threshold/rapid-error envelope, original-input MarginRecurrences and both main theorems remain unfinished.


## Revision 0.53 authoritative update

No new external assumptions were introduced. The actual grouped step, full finite polynomial dimension iteration, same-chart original-input reconstruction, original-input mass inequality on chosen piece margin classes and separate-scale scalar closure are now proved internally. The strict-range subpatch margin estimates are derived from them. The main local/global theorem remains open because the compatible interior cover must be propagated and assembled on the original supports. The literal borrowed algebraic and Kakeya/localized restriction inputs remain explicit parameters, outside the user's requested formalization scope.


## Revision 0.54 authoritative update

Explicit borrowed inputs: weighted multilinear Kakeya; uniform localized restriction at baseline on the internally constructed canonical article localization atlas; uniform tangent cuts; projected polynomial partition/generic transversality; polynomial tube covering; dimension-zero point count. The global conditional route also uses the existing borrowed surface epsilon-removal theorem. CanonicalLocalizedRestrictionInput repackages the localized input ONLY on the actual internally chosen atlas; it does not assume restriction on every arbitrary reduced ArticleLocalizationAtlas. Internal energy, descent, recurrence, original-support assembly, MainLocalGoal and SurfaceTestDecay are not external inputs.

The named local implication is checked under the stated interfaces; certification of the localized atlas input remains open. MainGlobalGoal is conditional on the article-side SurfaceTestDecay; that conditional premise is not accepted as external and remains work to prove.


